<?php
	print $_ENV[$_GET["env"]];
?>
