<?php
$a = '0';
var_dump(isset($a['b']));
$simpleString = preg_match('//', '', $a->a);
$simpleString["wrong"] = "f";
echo "ok\n";
?>
