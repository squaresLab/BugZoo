<?php 
error_reporting(0);
print_r($_POST);
print_r($_FILES);
?>
