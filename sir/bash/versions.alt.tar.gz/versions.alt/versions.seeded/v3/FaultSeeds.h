//#define FAULTY_F_KP_3
//#define FAULTY_F_KP_8
//#define FAULTY_F_SK_1
//#define FAULTY_F_SK_7
//#define FAULTY_F_SPK_4
//#define FAULTY_F_SPK_5
