#include <stdlib.h>
#include <stdio.h>

void f1() {
	printf("This is function 1.");
}

void f2() {
	printf("This is function 2.");
}

void f3() {
	printf("This is function 3.");
}

void f4() {
	printf("This is function 4.");
}

void f5() {
	printf("This is function 5.");

}

void f6() {
	printf("This is function 6.");
}

main() {
  fprintf("This is a c file.\n");
  fprintf("It has several errors.")
  fprintf("This is the first error.";
  fprintf"This is the second error.");
  fprintf"This is the last error.";
}
