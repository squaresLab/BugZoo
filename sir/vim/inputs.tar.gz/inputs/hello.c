#include <stdio.h>

main() {
  printf("Hi there!";
  printf "How are you doing");
  not_exist();
  x = 99;
  double value = 0.0;
}
