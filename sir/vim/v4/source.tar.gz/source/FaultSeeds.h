//#define FAULTY_F_KL_31
//#define FAULTY_F_KL_36
//#define FAULTY_F_JD_1
//#define FAULTY_F_JD_2