#define __strtol strtoll
#define __strtol_t long long int
#define __xstrtol xstrtoll
#define STRTOL_T_MINIMUM LONG_LONG_MIN
#define STRTOL_T_MAXIMUM LONG_LONG_MAX
#include "xstrtol.c"
