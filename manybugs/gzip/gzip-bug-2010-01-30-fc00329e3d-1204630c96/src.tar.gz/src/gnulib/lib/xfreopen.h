#include <stdio.h>
void xfreopen (char const *filename, char const *mode, FILE *fp);
