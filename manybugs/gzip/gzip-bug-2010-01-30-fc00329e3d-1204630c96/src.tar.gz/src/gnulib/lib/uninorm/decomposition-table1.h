/* DO NOT EDIT! GENERATED AUTOMATICALLY! */
/* Decomposition of Unicode characters.  */
/* Generated automatically by gen-uni-tables.c for Unicode 5.1.0.  */

extern const unsigned char gl_uninorm_decomp_chars_table[];

#define decomp_header_0 10
#define decomp_header_1 191
#define decomp_header_2 5
#define decomp_header_3 31
#define decomp_header_4 31

typedef struct
  {
    int level1[191];
    int level2[18 << 5];
    unsigned short level3[254 << 5];
  }
decomp_index_table_t;
extern const decomp_index_table_t gl_uninorm_decomp_index_table;
