#define inttostr umaxtostr
#define inttype uintmax_t
#define inttype_is_signed 0
#include "inttostr.c"
