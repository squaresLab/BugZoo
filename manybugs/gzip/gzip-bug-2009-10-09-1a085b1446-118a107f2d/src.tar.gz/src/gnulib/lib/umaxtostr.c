#define inttostr umaxtostr
#define inttype uintmax_t
#include "inttostr.c"
