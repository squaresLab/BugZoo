void *_coverage_fout ;
typedef unsigned int size_t;
typedef unsigned char __u_char;
typedef unsigned short __u_short;
typedef unsigned int __u_int;
typedef unsigned long __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;
typedef long long __quad_t;
typedef unsigned long long __u_quad_t;
typedef __u_quad_t __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef __u_quad_t __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long __off_t;
typedef __quad_t __off64_t;
typedef int __pid_t;
struct __anonstruct___fsid_t_1 {
   int __val[2] ;
};
typedef struct __anonstruct___fsid_t_1 __fsid_t;
typedef long __clock_t;
typedef unsigned long __rlim_t;
typedef __u_quad_t __rlim64_t;
typedef unsigned int __id_t;
typedef long __time_t;
typedef unsigned int __useconds_t;
typedef long __suseconds_t;
typedef int __daddr_t;
typedef long __swblk_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void *__timer_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef __quad_t __blkcnt64_t;
typedef unsigned long __fsblkcnt_t;
typedef __u_quad_t __fsblkcnt64_t;
typedef unsigned long __fsfilcnt_t;
typedef __u_quad_t __fsfilcnt64_t;
typedef int __ssize_t;
typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;
typedef int __intptr_t;
typedef unsigned int __socklen_t;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_3 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_2 {
   int __count ;
   union __anonunion___value_3 __value ;
};
typedef struct __anonstruct___mbstate_t_2 __mbstate_t;
struct __anonstruct__G_fpos_t_4 {
   __off_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos_t_4 _G_fpos_t;
struct __anonstruct__G_fpos64_t_5 {
   __off64_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos64_t_5 _G_fpos64_t;
typedef short _G_int16_t;
typedef int _G_int32_t;
typedef unsigned short _G_uint16_t;
typedef unsigned int _G_uint32_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_jump_t;
struct _IO_jump_t;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
enum __codecvt_result {
    __codecvt_ok = 0,
    __codecvt_partial = 1,
    __codecvt_error = 2,
    __codecvt_noconv = 3
} ;
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15U * sizeof(int ) - 4U * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
struct _IO_FILE_plus;
struct _IO_FILE_plus;
typedef __ssize_t __io_read_fn(void *__cookie , char *__buf , size_t __nbytes );
typedef __ssize_t __io_write_fn(void *__cookie , char const   *__buf ,
                                size_t __n );
typedef int __io_seek_fn(void *__cookie , __off64_t *__pos , int __w );
typedef int __io_close_fn(void *__cookie );
typedef __gnuc_va_list va_list;
typedef __off_t off_t;
typedef __ssize_t ssize_t;
typedef _G_fpos_t fpos_t;
typedef unsigned long mp_limb_t;
typedef long mp_limb_signed_t;
typedef unsigned long mp_bitcnt_t;
struct __anonstruct___mpz_struct_6 {
   int _mp_alloc ;
   int _mp_size ;
   mp_limb_t *_mp_d ;
};
typedef struct __anonstruct___mpz_struct_6 __mpz_struct;
typedef __mpz_struct MP_INT;
typedef __mpz_struct mpz_t[1];
typedef mp_limb_t *mp_ptr;
typedef mp_limb_t const   *mp_srcptr;
typedef long mp_size_t;
typedef long mp_exp_t;
struct __anonstruct___mpq_struct_7 {
   __mpz_struct _mp_num ;
   __mpz_struct _mp_den ;
};
typedef struct __anonstruct___mpq_struct_7 __mpq_struct;
typedef __mpq_struct MP_RAT;
typedef __mpq_struct mpq_t[1];
struct __anonstruct___mpf_struct_8 {
   int _mp_prec ;
   int _mp_size ;
   mp_exp_t _mp_exp ;
   mp_limb_t *_mp_d ;
};
typedef struct __anonstruct___mpf_struct_8 __mpf_struct;
typedef __mpf_struct mpf_t[1];
enum __anonenum_gmp_randalg_t_9 {
    GMP_RAND_ALG_DEFAULT = 0,
    GMP_RAND_ALG_LC = 0
} ;
typedef enum __anonenum_gmp_randalg_t_9 gmp_randalg_t;
union __anonunion__mp_algdata_11 {
   void *_mp_lc ;
};
struct __anonstruct___gmp_randstate_struct_10 {
   mpz_t _mp_seed ;
   gmp_randalg_t _mp_alg ;
   union __anonunion__mp_algdata_11 _mp_algdata ;
};
typedef struct __anonstruct___gmp_randstate_struct_10 __gmp_randstate_struct;
typedef __gmp_randstate_struct gmp_randstate_t[1];
typedef __mpz_struct const   *mpz_srcptr;
typedef __mpz_struct *mpz_ptr;
typedef __mpf_struct const   *mpf_srcptr;
typedef __mpf_struct *mpf_ptr;
typedef __mpq_struct const   *mpq_srcptr;
typedef __mpq_struct *mpq_ptr;
enum __anonenum_12 {
    GMP_ERROR_NONE = 0,
    GMP_ERROR_UNSUPPORTED_ARGUMENT = 1,
    GMP_ERROR_DIVISION_BY_ZERO = 2,
    GMP_ERROR_SQRT_OF_NEGATIVE = 4,
    GMP_ERROR_INVALID_ARGUMENT = 8
} ;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef signed char int_least8_t;
typedef short int_least16_t;
typedef int int_least32_t;
typedef long long int_least64_t;
typedef unsigned char uint_least8_t;
typedef unsigned short uint_least16_t;
typedef unsigned int uint_least32_t;
typedef unsigned long long uint_least64_t;
typedef signed char int_fast8_t;
typedef int int_fast16_t;
typedef int int_fast32_t;
typedef long long int_fast64_t;
typedef unsigned char uint_fast8_t;
typedef unsigned int uint_fast16_t;
typedef unsigned int uint_fast32_t;
typedef unsigned long long uint_fast64_t;
typedef int intptr_t;
typedef unsigned int uintptr_t;
typedef long long intmax_t;
typedef unsigned long long uintmax_t;
typedef long __gwchar_t;
struct __anonstruct_imaxdiv_t_13 {
   long long quot ;
   long long rem ;
};
typedef struct __anonstruct_imaxdiv_t_13 imaxdiv_t;
typedef uint_least32_t gmp_uint_least32_t;
typedef intptr_t gmp_intptr_t;
struct __anonstruct_gmp_pi1_t_14 {
   mp_limb_t inv32 ;
};
typedef struct __anonstruct_gmp_pi1_t_14 gmp_pi1_t;
struct __anonstruct_gmp_pi2_t_15 {
   mp_limb_t inv21 ;
   mp_limb_t inv32 ;
   mp_limb_t inv53 ;
};
typedef struct __anonstruct_gmp_pi2_t_15 gmp_pi2_t;
union tmp_align_t {
   mp_limb_t l ;
   char *p ;
};
struct tmp_reentrant_t {
   struct tmp_reentrant_t *next ;
   size_t size ;
};
typedef __gmp_randstate_struct *gmp_randstate_ptr;
typedef __gmp_randstate_struct const   *gmp_randstate_srcptr;
struct __anonstruct_gmp_randfnptr_t_16 {
   void (*randseed_fn)(__gmp_randstate_struct * , mpz_srcptr  ) ;
   void (*randget_fn)(__gmp_randstate_struct * , mp_ptr  , unsigned long  ) ;
   void (*randclear_fn)(__gmp_randstate_struct * ) ;
   void (*randiset_fn)(gmp_randstate_ptr  , gmp_randstate_srcptr  ) ;
};
typedef struct __anonstruct_gmp_randfnptr_t_16 gmp_randfnptr_t;
enum toom6_flags {
    toom6_all_pos = 0,
    toom6_vm1_neg = 1,
    toom6_vm2_neg = 2
} ;
enum toom7_flags {
    toom7_w1_neg = 1,
    toom7_w3_neg = 2
} ;
struct __anonstruct_gmp_primesieve_t_17 {
   unsigned long d ;
   unsigned long s0 ;
   unsigned long sqrt_s0 ;
   unsigned char s[513] ;
};
typedef struct __anonstruct_gmp_primesieve_t_17 gmp_primesieve_t;
struct fft_table_nk {
   unsigned int n : 27 ;
   unsigned int k : 5 ;
};
struct bases {
   int chars_per_limb ;
   double chars_per_bit_exactly ;
   mp_limb_t big_base ;
   mp_limb_t big_base_inverted ;
};
typedef unsigned char UQItype;
typedef int SItype;
typedef unsigned int USItype;
typedef long long DItype;
typedef unsigned long long UDItype;
typedef mp_limb_t UWtype;
typedef unsigned int UHWtype;
struct __anonstruct_s_18 {
   gmp_uint_least32_t manl : 32 ;
   gmp_uint_least32_t manh : 20 ;
   gmp_uint_least32_t exp : 11 ;
   gmp_uint_least32_t sig : 1 ;
};
union ieee_double_extract {
   struct __anonstruct_s_18 s ;
   double d ;
};
struct hgcd_matrix1 {
   mp_limb_t u[2][2] ;
};
struct hgcd_matrix {
   mp_size_t alloc ;
   mp_size_t n ;
   mp_ptr p[2][2] ;
};
typedef void gcd_subdiv_step_hook(void * , mp_srcptr  , mp_size_t  ,
                                  mp_srcptr  , mp_size_t  , int  );
struct gcdext_ctx {
   mp_ptr gp ;
   mp_size_t gn ;
   mp_ptr up ;
   mp_size_t *usize ;
   mp_size_t un ;
   mp_ptr u0 ;
   mp_ptr u1 ;
   mp_ptr tp ;
};
struct powers {
   mp_ptr p ;
   mp_size_t n ;
   mp_size_t shift ;
   size_t digits_in_base ;
   int base ;
};
typedef struct powers powers_t;
struct doprnt_params_t {
   int base ;
   int conv ;
   char const   *expfmt ;
   int exptimes4 ;
   char fill ;
   int justify ;
   int prec ;
   int showbase ;
   int showpoint ;
   int showtrailing ;
   char sign ;
   int width ;
};
typedef int (*gmp_doscan_scan_t)(void * , char const   *  , ...);
typedef void *(*gmp_doscan_step_t)(void * , int  );
typedef int (*gmp_doscan_get_t)(void * );
typedef int (*gmp_doscan_unget_t)(int  , void * );
struct gmp_doscan_funs_t {
   int (*scan)(void * , char const   *  , ...) ;
   void *(*step)(void * , int  ) ;
   int (*get)(void * ) ;
   int (*unget)(int  , void * ) ;
};
extern struct _IO_FILE_plus _IO_2_1_stdin_ ;
extern struct _IO_FILE_plus _IO_2_1_stdout_ ;
extern struct _IO_FILE_plus _IO_2_1_stderr_ ;
extern int __underflow(_IO_FILE * ) ;
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_feof(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_ferror(_IO_FILE *__fp ) ;
extern int _IO_peekc_locked(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) void _IO_flockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) void _IO_funlockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) int _IO_ftrylockfile(_IO_FILE * ) ;
extern int _IO_vfscanf(_IO_FILE * __restrict   , char const   * __restrict   ,
                       __gnuc_va_list  , int * __restrict   ) ;
extern int _IO_vfprintf(_IO_FILE * __restrict   , char const   * __restrict   ,
                        __gnuc_va_list  ) ;
extern __ssize_t _IO_padn(_IO_FILE * , int  , __ssize_t  ) ;
extern size_t _IO_sgetn(_IO_FILE * , void * , size_t  ) ;
extern __off64_t _IO_seekoff(_IO_FILE * , __off64_t  , int  , int  ) ;
extern __off64_t _IO_seekpos(_IO_FILE * , __off64_t  , int  ) ;
extern  __attribute__((__nothrow__)) void _IO_free_backup_area(_IO_FILE * ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
extern  __attribute__((__nothrow__)) int remove(char const   *__filename ) ;
extern  __attribute__((__nothrow__)) int rename(char const   *__old ,
                                                char const   *__new ) ;
extern  __attribute__((__nothrow__)) int renameat(int __oldfd ,
                                                  char const   *__old ,
                                                  int __newfd ,
                                                  char const   *__new ) ;
extern FILE *tmpfile(void) ;
extern  __attribute__((__nothrow__)) char *tmpnam(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tmpnam_r(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tempnam(char const   *__dir ,
                                                   char const   *__pfx )  __attribute__((__malloc__)) ;
extern int fclose(FILE *__stream ) ;
extern int fflush(FILE *__stream ) ;
extern int fflush_unlocked(FILE *__stream ) ;
extern FILE *freopen(char const   * __restrict  __filename ,
                     char const   * __restrict  __modes ,
                     FILE * __restrict  __stream ) ;
extern  __attribute__((__nothrow__)) FILE *fdopen(int __fd ,
                                                  char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *fmemopen(void *__s , size_t __len ,
                                                    char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *open_memstream(char **__bufloc ,
                                                          size_t *__sizeloc ) ;
extern  __attribute__((__nothrow__)) void setbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) int setvbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ,
                                                 int __modes , size_t __n ) ;
extern  __attribute__((__nothrow__)) void setbuffer(FILE * __restrict  __stream ,
                                                    char * __restrict  __buf ,
                                                    size_t __size ) ;
extern  __attribute__((__nothrow__)) void setlinebuf(FILE *__stream ) ;
extern int fprintf(FILE * __restrict  __stream ,
                   char const   * __restrict  __format  , ...) ;
extern int printf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sprintf(char * __restrict  __s ,
                                                 char const   * __restrict  __format 
                                                 , ...) ;
extern int vfprintf(FILE * __restrict  __s ,
                    char const   * __restrict  __format , __gnuc_va_list __arg ) ;
__inline extern int __attribute__((__gnu_inline__))  vprintf(char const   * __restrict  __fmt ,
                                                             __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vsprintf(char * __restrict  __s ,
                                                  char const   * __restrict  __format ,
                                                  __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  snprintf)(char * __restrict  __s ,
                                                                             size_t __maxlen ,
                                                                             char const   * __restrict  __format 
                                                                             , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsnprintf)(char * __restrict  __s ,
                                                                              size_t __maxlen ,
                                                                              char const   * __restrict  __format ,
                                                                              __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  vdprintf)(int __fd ,
                                               char const   * __restrict  __fmt ,
                                               __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  dprintf)(int __fd ,
                                              char const   * __restrict  __fmt 
                                              , ...) ;
extern int fscanf(FILE * __restrict  __stream ,
                  char const   * __restrict  __format  , ...)  __asm__("__isoc99_fscanf")  ;
extern int scanf(char const   * __restrict  __format  , ...)  __asm__("__isoc99_scanf")  ;
extern  __attribute__((__nothrow__)) int sscanf(char const   * __restrict  __s ,
                                                char const   * __restrict  __format 
                                                , ...)  __asm__("__isoc99_sscanf")  ;
extern int ( /* format attribute */  vfscanf)(FILE * __restrict  __s ,
                                              char const   * __restrict  __format ,
                                              __gnuc_va_list __arg )  __asm__("__isoc99_vfscanf")  ;
extern int ( /* format attribute */  vscanf)(char const   * __restrict  __format ,
                                             __gnuc_va_list __arg )  __asm__("__isoc99_vscanf")  ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsscanf)(char const   * __restrict  __s ,
                                                                            char const   * __restrict  __format ,
                                                                            __gnuc_va_list __arg )  __asm__("__isoc99_vsscanf")  ;
extern int fgetc(FILE *__stream ) ;
extern int getc(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  getchar(void) ;
__inline extern int __attribute__((__gnu_inline__))  getc_unlocked(FILE *__fp ) ;
__inline extern int __attribute__((__gnu_inline__))  getchar_unlocked(void) ;
__inline extern int __attribute__((__gnu_inline__))  fgetc_unlocked(FILE *__fp ) ;
extern int fputc(int __c , FILE *__stream ) ;
extern int putc(int __c , FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  putchar(int __c ) ;
__inline extern int __attribute__((__gnu_inline__))  fputc_unlocked(int __c ,
                                                                    FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  putc_unlocked(int __c ,
                                                                   FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  putchar_unlocked(int __c ) ;
extern int getw(FILE *__stream ) ;
extern int putw(int __w , FILE *__stream ) ;
extern char *fgets(char * __restrict  __s , int __n ,
                   FILE * __restrict  __stream ) ;
extern char *gets(char *__s ) ;
extern __ssize_t __getdelim(char ** __restrict  __lineptr ,
                            size_t * __restrict  __n , int __delimiter ,
                            FILE * __restrict  __stream ) ;
extern __ssize_t getdelim(char ** __restrict  __lineptr ,
                          size_t * __restrict  __n , int __delimiter ,
                          FILE * __restrict  __stream ) ;
extern __ssize_t getline(char ** __restrict  __lineptr ,
                         size_t * __restrict  __n , FILE * __restrict  __stream ) ;
extern int fputs(char const   * __restrict  __s , FILE * __restrict  __stream ) ;
extern int puts(char const   *__s ) ;
extern int ungetc(int __c , FILE *__stream ) ;
extern size_t fread(void * __restrict  __ptr , size_t __size , size_t __n ,
                    FILE * __restrict  __stream ) ;
extern size_t fwrite(void const   * __restrict  __ptr , size_t __size ,
                     size_t __n , FILE * __restrict  __s ) ;
extern size_t fread_unlocked(void * __restrict  __ptr , size_t __size ,
                             size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite_unlocked(void const   * __restrict  __ptr , size_t __size ,
                              size_t __n , FILE * __restrict  __stream ) ;
extern int fseek(FILE *__stream , long __off , int __whence ) ;
extern long ftell(FILE *__stream ) ;
extern void rewind(FILE *__stream ) ;
extern int fseeko(FILE *__stream , __off_t __off , int __whence ) ;
extern __off_t ftello(FILE *__stream ) ;
extern int fgetpos(FILE * __restrict  __stream , fpos_t * __restrict  __pos ) ;
extern int fsetpos(FILE *__stream , fpos_t const   *__pos ) ;
extern  __attribute__((__nothrow__)) void clearerr(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int feof(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ferror(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void clearerr_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  feof_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ferror_unlocked(FILE *__stream ) ;
extern void perror(char const   *__s ) ;
extern int sys_nerr ;
extern char const   * const  sys_errlist[] ;
extern  __attribute__((__nothrow__)) int fileno(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int fileno_unlocked(FILE *__stream ) ;
extern FILE *popen(char const   *__command , char const   *__modes ) ;
extern int pclose(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) char *ctermid(char *__s ) ;
extern  __attribute__((__nothrow__)) void flockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ftrylockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void funlockfile(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  vprintf(char const   * __restrict  __fmt ,
                                                             __gnuc_va_list __arg ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1\n");
  fflush(_coverage_fout);
  tmp = vfprintf((FILE */* __restrict  */)stdout, __fmt, __arg);
  fprintf(_coverage_fout, "2\n");
  fflush(_coverage_fout);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  getchar(void) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3\n");
  fflush(_coverage_fout);
  tmp = _IO_getc(stdin);
  fprintf(_coverage_fout, "4\n");
  fflush(_coverage_fout);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  fgetc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "10\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "11\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "5\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "6\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "7\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "8\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "9\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "12\n");
  fflush(_coverage_fout);
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  getc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "18\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "19\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "13\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "14\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "15\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "16\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "17\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "20\n");
  fflush(_coverage_fout);
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  getchar_unlocked(void) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "26\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )stdin->_IO_read_ptr >= (unsigned int )stdin->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "27\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "21\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(stdin);
    fprintf(_coverage_fout, "22\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "23\n");
    fflush(_coverage_fout);
    tmp___1 = stdin->_IO_read_ptr;
    fprintf(_coverage_fout, "24\n");
    fflush(_coverage_fout);
    (stdin->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "25\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "28\n");
  fflush(_coverage_fout);
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  putchar(int __c ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "29\n");
  fflush(_coverage_fout);
  tmp = _IO_putc(__c, stdout);
  fprintf(_coverage_fout, "30\n");
  fflush(_coverage_fout);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  fputc_unlocked(int __c ,
                                                                    FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "38\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "39\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "31\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "32\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "33\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "34\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "35\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "36\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "37\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "40\n");
  fflush(_coverage_fout);
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern int __attribute__((__gnu_inline__))  putc_unlocked(int __c ,
                                                                   FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "48\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "49\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "41\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "42\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "43\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "44\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "45\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "46\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "47\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "50\n");
  fflush(_coverage_fout);
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern int __attribute__((__gnu_inline__))  putchar_unlocked(int __c ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "58\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )stdout->_IO_write_ptr >= (unsigned int )stdout->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "59\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "51\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "52\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "53\n");
    fflush(_coverage_fout);
    tmp___1 = stdout->_IO_write_ptr;
    fprintf(_coverage_fout, "54\n");
    fflush(_coverage_fout);
    (stdout->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "55\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "56\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "57\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "60\n");
  fflush(_coverage_fout);
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  feof_unlocked(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  feof_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "61\n");
  fflush(_coverage_fout);
  return ((int __attribute__((__gnu_inline__))  )((__stream->_flags & 0x10) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ferror_unlocked(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  ferror_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "62\n");
  fflush(_coverage_fout);
  return ((int __attribute__((__gnu_inline__))  )((__stream->_flags & 0x20) != 0));
}
}
extern void __gmp_set_memory_functions(void *(*)(size_t  ) ,
                                       void *(*)(void * , size_t  , size_t  ) ,
                                       void (*)(void * , size_t  ) ) ;
extern void __gmp_get_memory_functions(void *(**)(size_t  ) ,
                                       void *(**)(void * , size_t  , size_t  ) ,
                                       void (**)(void * , size_t  ) ) ;
extern int const   __gmp_bits_per_limb ;
extern int __gmp_errno ;
extern char const   * const  __gmp_version ;
extern void __gmp_randinit(__gmp_randstate_struct * , gmp_randalg_t   , ...) ;
extern void __gmp_randinit_default(__gmp_randstate_struct * ) ;
extern void __gmp_randinit_lc_2exp(__gmp_randstate_struct * , mpz_srcptr  ,
                                   unsigned long  , mp_bitcnt_t  ) ;
extern int __gmp_randinit_lc_2exp_size(__gmp_randstate_struct * , mp_bitcnt_t  ) ;
extern void __gmp_randinit_mt(__gmp_randstate_struct * ) ;
extern void __gmp_randinit_set(__gmp_randstate_struct * ,
                               __gmp_randstate_struct const   * ) ;
extern void __gmp_randseed(__gmp_randstate_struct * , mpz_srcptr  ) ;
extern void __gmp_randseed_ui(__gmp_randstate_struct * , unsigned long  ) ;
extern void __gmp_randclear(__gmp_randstate_struct * ) ;
extern unsigned long __gmp_urandomb_ui(__gmp_randstate_struct * ,
                                       unsigned long  ) ;
extern unsigned long __gmp_urandomm_ui(__gmp_randstate_struct * ,
                                       unsigned long  ) ;
extern int __gmp_asprintf(char ** , char const   *  , ...) ;
extern int __gmp_fprintf(FILE * , char const   *  , ...) ;
extern int __gmp_printf(char const   *  , ...) ;
extern int __gmp_snprintf(char * , size_t  , char const   *  , ...) ;
extern int __gmp_sprintf(char * , char const   *  , ...) ;
extern int __gmp_fscanf(FILE * , char const   *  , ...) ;
extern int __gmp_scanf(char const   *  , ...) ;
extern int __gmp_sscanf(char const   * , char const   *  , ...) ;
extern void *__gmpz_realloc(mpz_ptr  , mp_size_t  ) ;
__inline extern void __attribute__((__gnu_inline__))  __gmpz_abs(mpz_ptr __gmp_w ,
                                                                 mpz_srcptr __gmp_u ) ;
extern void __gmpz_add(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_add_ui(mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
extern void __gmpz_addmul(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_addmul_ui(mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
extern void __gmpz_and(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_array_init(mpz_ptr  , mp_size_t  , mp_size_t  ) ;
extern void __gmpz_bin_ui(mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
extern void __gmpz_bin_uiui(mpz_ptr  , unsigned long  , unsigned long  ) ;
extern void __gmpz_cdiv_q(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_cdiv_q_2exp(mpz_ptr  , mpz_srcptr  , mp_bitcnt_t  ) ;
extern unsigned long __gmpz_cdiv_q_ui(mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
extern void __gmpz_cdiv_qr(mpz_ptr  , mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern unsigned long __gmpz_cdiv_qr_ui(mpz_ptr  , mpz_ptr  , mpz_srcptr  ,
                                       unsigned long  ) ;
extern void __gmpz_cdiv_r(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_cdiv_r_2exp(mpz_ptr  , mpz_srcptr  , mp_bitcnt_t  ) ;
extern unsigned long __gmpz_cdiv_r_ui(mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
extern unsigned long __gmpz_cdiv_ui(mpz_srcptr  , unsigned long  )  __attribute__((__pure__)) ;
extern void __gmpz_clear(mpz_ptr  ) ;
extern void __gmpz_clears(mpz_ptr   , ...) ;
extern void __gmpz_clrbit(mpz_ptr  , mp_bitcnt_t  ) ;
extern int __gmpz_cmp(mpz_srcptr  , mpz_srcptr  )  __attribute__((__pure__)) ;
extern int __gmpz_cmp_d(mpz_srcptr  , double  )  __attribute__((__pure__)) ;
extern int __gmpz_cmp_si(mpz_srcptr  , long  )  __attribute__((__pure__)) ;
extern int __gmpz_cmp_ui(mpz_srcptr  , unsigned long  )  __attribute__((__pure__)) ;
extern int __gmpz_cmpabs(mpz_srcptr  , mpz_srcptr  )  __attribute__((__pure__)) ;
extern int __gmpz_cmpabs_d(mpz_srcptr  , double  )  __attribute__((__pure__)) ;
extern int __gmpz_cmpabs_ui(mpz_srcptr  , unsigned long  )  __attribute__((__pure__)) ;
extern void __gmpz_com(mpz_ptr  , mpz_srcptr  ) ;
extern void __gmpz_combit(mpz_ptr  , mp_bitcnt_t  ) ;
extern int __gmpz_congruent_p(mpz_srcptr  , mpz_srcptr  , mpz_srcptr  )  __attribute__((__pure__)) ;
extern int __gmpz_congruent_2exp_p(mpz_srcptr  , mpz_srcptr  , mp_bitcnt_t  )  __attribute__((__pure__)) ;
extern int __gmpz_congruent_ui_p(mpz_srcptr  , unsigned long  , unsigned long  )  __attribute__((__pure__)) ;
extern void __gmpz_divexact(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_divexact_ui(mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
extern int __gmpz_divisible_p(mpz_srcptr  , mpz_srcptr  )  __attribute__((__pure__)) ;
extern int __gmpz_divisible_ui_p(mpz_srcptr  , unsigned long  )  __attribute__((__pure__)) ;
extern int __gmpz_divisible_2exp_p(mpz_srcptr  , mp_bitcnt_t  )  __attribute__((__pure__)) ;
extern void __gmpz_dump(mpz_srcptr  ) ;
extern void *__gmpz_export(void * , size_t * , int  , size_t  , int  , size_t  ,
                           mpz_srcptr  ) ;
extern void __gmpz_fac_ui(mpz_ptr  , unsigned long  ) ;
extern void __gmpz_fdiv_q(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_fdiv_q_2exp(mpz_ptr  , mpz_srcptr  , mp_bitcnt_t  ) ;
extern unsigned long __gmpz_fdiv_q_ui(mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
extern void __gmpz_fdiv_qr(mpz_ptr  , mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern unsigned long __gmpz_fdiv_qr_ui(mpz_ptr  , mpz_ptr  , mpz_srcptr  ,
                                       unsigned long  ) ;
extern void __gmpz_fdiv_r(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_fdiv_r_2exp(mpz_ptr  , mpz_srcptr  , mp_bitcnt_t  ) ;
extern unsigned long __gmpz_fdiv_r_ui(mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
extern unsigned long __gmpz_fdiv_ui(mpz_srcptr  , unsigned long  )  __attribute__((__pure__)) ;
extern void __gmpz_fib_ui(mpz_ptr  , unsigned long  ) ;
extern void __gmpz_fib2_ui(mpz_ptr  , mpz_ptr  , unsigned long  ) ;
extern int __gmpz_fits_sint_p(mpz_srcptr  )  __attribute__((__pure__)) ;
extern int __gmpz_fits_slong_p(mpz_srcptr  )  __attribute__((__pure__)) ;
extern int __gmpz_fits_sshort_p(mpz_srcptr  )  __attribute__((__pure__)) ;
__inline extern int __attribute__((__gnu_inline__))  __gmpz_fits_uint_p(mpz_srcptr __gmp_z )  __attribute__((__pure__)) ;
__inline extern int __attribute__((__gnu_inline__))  __gmpz_fits_ulong_p(mpz_srcptr __gmp_z )  __attribute__((__pure__)) ;
__inline extern int __attribute__((__gnu_inline__))  __gmpz_fits_ushort_p(mpz_srcptr __gmp_z )  __attribute__((__pure__)) ;
extern void __gmpz_gcd(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern unsigned long __gmpz_gcd_ui(mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
void __gmpz_gcdext(mpz_ptr g , mpz_ptr s , mpz_ptr t , mpz_srcptr a ,
                   mpz_srcptr b ) ;
extern double __gmpz_get_d(mpz_srcptr  )  __attribute__((__pure__)) ;
extern double __gmpz_get_d_2exp(long * , mpz_srcptr  ) ;
extern long __gmpz_get_si(mpz_srcptr  )  __attribute__((__pure__)) ;
extern char *__gmpz_get_str(char * , int  , mpz_srcptr  ) ;
__inline extern unsigned long __attribute__((__gnu_inline__))  __gmpz_get_ui(mpz_srcptr __gmp_z )  __attribute__((__pure__)) ;
__inline extern mp_limb_t __attribute__((__gnu_inline__))  __gmpz_getlimbn(mpz_srcptr __gmp_z ,
                                                                           mp_size_t __gmp_n )  __attribute__((__pure__)) ;
extern mp_bitcnt_t __gmpz_hamdist(mpz_srcptr  , mpz_srcptr  )  __attribute__((__pure__)) ;
extern void __gmpz_import(mpz_ptr  , size_t  , int  , size_t  , int  , size_t  ,
                          void const   * ) ;
extern void __gmpz_init(mpz_ptr  ) ;
extern void __gmpz_init2(mpz_ptr  , mp_bitcnt_t  ) ;
extern void __gmpz_inits(mpz_ptr   , ...) ;
extern void __gmpz_init_set(mpz_ptr  , mpz_srcptr  ) ;
extern void __gmpz_init_set_d(mpz_ptr  , double  ) ;
extern void __gmpz_init_set_si(mpz_ptr  , long  ) ;
extern int __gmpz_init_set_str(mpz_ptr  , char const   * , int  ) ;
extern void __gmpz_init_set_ui(mpz_ptr  , unsigned long  ) ;
extern size_t __gmpz_inp_raw(mpz_ptr  , FILE * ) ;
extern size_t __gmpz_inp_str(mpz_ptr  , FILE * , int  ) ;
extern int __gmpz_invert(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_ior(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern int __gmpz_jacobi(mpz_srcptr  , mpz_srcptr  )  __attribute__((__pure__)) ;
extern int __gmpz_kronecker_si(mpz_srcptr  , long  )  __attribute__((__pure__)) ;
extern int __gmpz_kronecker_ui(mpz_srcptr  , unsigned long  )  __attribute__((__pure__)) ;
extern int __gmpz_si_kronecker(long  , mpz_srcptr  )  __attribute__((__pure__)) ;
extern int __gmpz_ui_kronecker(unsigned long  , mpz_srcptr  )  __attribute__((__pure__)) ;
extern void __gmpz_lcm(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_lcm_ui(mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
extern void __gmpz_lucnum_ui(mpz_ptr  , unsigned long  ) ;
extern void __gmpz_lucnum2_ui(mpz_ptr  , mpz_ptr  , unsigned long  ) ;
extern int __gmpz_millerrabin(mpz_srcptr  , int  )  __attribute__((__pure__)) ;
extern void __gmpz_mod(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_mul(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_mul_2exp(mpz_ptr  , mpz_srcptr  , mp_bitcnt_t  ) ;
extern void __gmpz_mul_si(mpz_ptr  , mpz_srcptr  , long  ) ;
extern void __gmpz_mul_ui(mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
__inline extern void __attribute__((__gnu_inline__))  __gmpz_neg(mpz_ptr __gmp_w ,
                                                                 mpz_srcptr __gmp_u ) ;
extern void __gmpz_nextprime(mpz_ptr  , mpz_srcptr  ) ;
extern size_t __gmpz_out_raw(FILE * , mpz_srcptr  ) ;
extern size_t __gmpz_out_str(FILE * , int  , mpz_srcptr  ) ;
extern int __gmpz_perfect_power_p(mpz_srcptr  )  __attribute__((__pure__)) ;
__inline extern int __attribute__((__gnu_inline__))  __gmpz_perfect_square_p(mpz_srcptr __gmp_a )  __attribute__((__pure__)) ;
__inline extern mp_bitcnt_t __attribute__((__gnu_inline__))  __gmpz_popcount(mpz_srcptr __gmp_u )  __attribute__((__pure__)) ;
extern void __gmpz_pow_ui(mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
extern void __gmpz_powm(mpz_ptr  , mpz_srcptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_powm_sec(mpz_ptr  , mpz_srcptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_powm_ui(mpz_ptr  , mpz_srcptr  , unsigned long  ,
                           mpz_srcptr  ) ;
extern int __gmpz_probab_prime_p(mpz_srcptr  , int  )  __attribute__((__pure__)) ;
extern void __gmpz_random(mpz_ptr  , mp_size_t  ) ;
extern void __gmpz_random2(mpz_ptr  , mp_size_t  ) ;
extern void __gmpz_realloc2(mpz_ptr  , mp_bitcnt_t  ) ;
extern mp_bitcnt_t __gmpz_remove(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern int __gmpz_root(mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
extern void __gmpz_rootrem(mpz_ptr  , mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
extern void __gmpz_rrandomb(mpz_ptr  , __gmp_randstate_struct * , mp_bitcnt_t  ) ;
extern mp_bitcnt_t __gmpz_scan0(mpz_srcptr  , mp_bitcnt_t  )  __attribute__((__pure__)) ;
extern mp_bitcnt_t __gmpz_scan1(mpz_srcptr  , mp_bitcnt_t  )  __attribute__((__pure__)) ;
extern void __gmpz_set(mpz_ptr  , mpz_srcptr  ) ;
extern void __gmpz_set_d(mpz_ptr  , double  ) ;
extern void __gmpz_set_f(mpz_ptr  , mpf_srcptr  ) ;
__inline extern void __attribute__((__gnu_inline__))  __gmpz_set_q(mpz_ptr __gmp_w ,
                                                                   mpq_srcptr __gmp_u ) ;
extern void __gmpz_set_si(mpz_ptr  , long  ) ;
extern int __gmpz_set_str(mpz_ptr  , char const   * , int  ) ;
extern void __gmpz_set_ui(mpz_ptr  , unsigned long  ) ;
extern void __gmpz_setbit(mpz_ptr  , mp_bitcnt_t  ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __gmpz_size(mpz_srcptr __gmp_z )  __attribute__((__pure__)) ;
extern size_t __gmpz_sizeinbase(mpz_srcptr  , int  )  __attribute__((__pure__)) ;
extern void __gmpz_sqrt(mpz_ptr  , mpz_srcptr  ) ;
extern void __gmpz_sqrtrem(mpz_ptr  , mpz_ptr  , mpz_srcptr  ) ;
extern void __gmpz_sub(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_sub_ui(mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
extern void __gmpz_ui_sub(mpz_ptr  , unsigned long  , mpz_srcptr  ) ;
extern void __gmpz_submul(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_submul_ui(mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
extern void __gmpz_swap(mpz_ptr  , mpz_ptr  ) ;
extern unsigned long __gmpz_tdiv_ui(mpz_srcptr  , unsigned long  )  __attribute__((__pure__)) ;
extern void __gmpz_tdiv_q(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_tdiv_q_2exp(mpz_ptr  , mpz_srcptr  , mp_bitcnt_t  ) ;
extern unsigned long __gmpz_tdiv_q_ui(mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
extern void __gmpz_tdiv_qr(mpz_ptr  , mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern unsigned long __gmpz_tdiv_qr_ui(mpz_ptr  , mpz_ptr  , mpz_srcptr  ,
                                       unsigned long  ) ;
extern void __gmpz_tdiv_r(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern void __gmpz_tdiv_r_2exp(mpz_ptr  , mpz_srcptr  , mp_bitcnt_t  ) ;
extern unsigned long __gmpz_tdiv_r_ui(mpz_ptr  , mpz_srcptr  , unsigned long  ) ;
extern int __gmpz_tstbit(mpz_srcptr  , mp_bitcnt_t  )  __attribute__((__pure__)) ;
extern void __gmpz_ui_pow_ui(mpz_ptr  , unsigned long  , unsigned long  ) ;
extern void __gmpz_urandomb(mpz_ptr  , __gmp_randstate_struct * , mp_bitcnt_t  ) ;
extern void __gmpz_urandomm(mpz_ptr  , __gmp_randstate_struct * , mpz_srcptr  ) ;
extern void __gmpz_xor(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
__inline extern void __attribute__((__gnu_inline__))  __gmpq_abs(mpq_ptr __gmp_w ,
                                                                 mpq_srcptr __gmp_u ) ;
extern void __gmpq_add(mpq_ptr  , mpq_srcptr  , mpq_srcptr  ) ;
extern void __gmpq_canonicalize(mpq_ptr  ) ;
extern void __gmpq_clear(mpq_ptr  ) ;
extern void __gmpq_clears(mpq_ptr   , ...) ;
extern int __gmpq_cmp(mpq_srcptr  , mpq_srcptr  )  __attribute__((__pure__)) ;
extern int __gmpq_cmp_si(mpq_srcptr  , long  , unsigned long  )  __attribute__((__pure__)) ;
extern int __gmpq_cmp_ui(mpq_srcptr  , unsigned long  , unsigned long  )  __attribute__((__pure__)) ;
extern void __gmpq_div(mpq_ptr  , mpq_srcptr  , mpq_srcptr  ) ;
extern void __gmpq_div_2exp(mpq_ptr  , mpq_srcptr  , mp_bitcnt_t  ) ;
extern int __gmpq_equal(mpq_srcptr  , mpq_srcptr  )  __attribute__((__pure__)) ;
extern void __gmpq_get_num(mpz_ptr  , mpq_srcptr  ) ;
extern void __gmpq_get_den(mpz_ptr  , mpq_srcptr  ) ;
extern double __gmpq_get_d(mpq_srcptr  )  __attribute__((__pure__)) ;
extern char *__gmpq_get_str(char * , int  , mpq_srcptr  ) ;
extern void __gmpq_init(mpq_ptr  ) ;
extern void __gmpq_inits(mpq_ptr   , ...) ;
extern size_t __gmpq_inp_str(mpq_ptr  , FILE * , int  ) ;
extern void __gmpq_inv(mpq_ptr  , mpq_srcptr  ) ;
extern void __gmpq_mul(mpq_ptr  , mpq_srcptr  , mpq_srcptr  ) ;
extern void __gmpq_mul_2exp(mpq_ptr  , mpq_srcptr  , mp_bitcnt_t  ) ;
__inline extern void __attribute__((__gnu_inline__))  __gmpq_neg(mpq_ptr __gmp_w ,
                                                                 mpq_srcptr __gmp_u ) ;
extern size_t __gmpq_out_str(FILE * , int  , mpq_srcptr  ) ;
extern void __gmpq_set(mpq_ptr  , mpq_srcptr  ) ;
extern void __gmpq_set_d(mpq_ptr  , double  ) ;
extern void __gmpq_set_den(mpq_ptr  , mpz_srcptr  ) ;
extern void __gmpq_set_f(mpq_ptr  , mpf_srcptr  ) ;
extern void __gmpq_set_num(mpq_ptr  , mpz_srcptr  ) ;
extern void __gmpq_set_si(mpq_ptr  , long  , unsigned long  ) ;
extern int __gmpq_set_str(mpq_ptr  , char const   * , int  ) ;
extern void __gmpq_set_ui(mpq_ptr  , unsigned long  , unsigned long  ) ;
extern void __gmpq_set_z(mpq_ptr  , mpz_srcptr  ) ;
extern void __gmpq_sub(mpq_ptr  , mpq_srcptr  , mpq_srcptr  ) ;
extern void __gmpq_swap(mpq_ptr  , mpq_ptr  ) ;
extern void __gmpf_abs(mpf_ptr  , mpf_srcptr  ) ;
extern void __gmpf_add(mpf_ptr  , mpf_srcptr  , mpf_srcptr  ) ;
extern void __gmpf_add_ui(mpf_ptr  , mpf_srcptr  , unsigned long  ) ;
extern void __gmpf_ceil(mpf_ptr  , mpf_srcptr  ) ;
extern void __gmpf_clear(mpf_ptr  ) ;
extern void __gmpf_clears(mpf_ptr   , ...) ;
extern int __gmpf_cmp(mpf_srcptr  , mpf_srcptr  )  __attribute__((__pure__)) ;
extern int __gmpf_cmp_d(mpf_srcptr  , double  )  __attribute__((__pure__)) ;
extern int __gmpf_cmp_si(mpf_srcptr  , long  )  __attribute__((__pure__)) ;
extern int __gmpf_cmp_ui(mpf_srcptr  , unsigned long  )  __attribute__((__pure__)) ;
extern void __gmpf_div(mpf_ptr  , mpf_srcptr  , mpf_srcptr  ) ;
extern void __gmpf_div_2exp(mpf_ptr  , mpf_srcptr  , mp_bitcnt_t  ) ;
extern void __gmpf_div_ui(mpf_ptr  , mpf_srcptr  , unsigned long  ) ;
extern void __gmpf_dump(mpf_srcptr  ) ;
extern int __gmpf_eq(mpf_srcptr  , mpf_srcptr  , mp_bitcnt_t  )  __attribute__((__pure__)) ;
extern int __gmpf_fits_sint_p(mpf_srcptr  )  __attribute__((__pure__)) ;
extern int __gmpf_fits_slong_p(mpf_srcptr  )  __attribute__((__pure__)) ;
extern int __gmpf_fits_sshort_p(mpf_srcptr  )  __attribute__((__pure__)) ;
extern int __gmpf_fits_uint_p(mpf_srcptr  )  __attribute__((__pure__)) ;
extern int __gmpf_fits_ulong_p(mpf_srcptr  )  __attribute__((__pure__)) ;
extern int __gmpf_fits_ushort_p(mpf_srcptr  )  __attribute__((__pure__)) ;
extern void __gmpf_floor(mpf_ptr  , mpf_srcptr  ) ;
extern double __gmpf_get_d(mpf_srcptr  )  __attribute__((__pure__)) ;
extern double __gmpf_get_d_2exp(long * , mpf_srcptr  ) ;
extern mp_bitcnt_t __gmpf_get_default_prec(void)  __attribute__((__pure__)) ;
extern mp_bitcnt_t __gmpf_get_prec(mpf_srcptr  )  __attribute__((__pure__)) ;
extern long __gmpf_get_si(mpf_srcptr  )  __attribute__((__pure__)) ;
extern char *__gmpf_get_str(char * , mp_exp_t * , int  , size_t  , mpf_srcptr  ) ;
extern unsigned long __gmpf_get_ui(mpf_srcptr  )  __attribute__((__pure__)) ;
extern void __gmpf_init(mpf_ptr  ) ;
extern void __gmpf_init2(mpf_ptr  , mp_bitcnt_t  ) ;
extern void __gmpf_inits(mpf_ptr   , ...) ;
extern void __gmpf_init_set(mpf_ptr  , mpf_srcptr  ) ;
extern void __gmpf_init_set_d(mpf_ptr  , double  ) ;
extern void __gmpf_init_set_si(mpf_ptr  , long  ) ;
extern int __gmpf_init_set_str(mpf_ptr  , char const   * , int  ) ;
extern void __gmpf_init_set_ui(mpf_ptr  , unsigned long  ) ;
extern size_t __gmpf_inp_str(mpf_ptr  , FILE * , int  ) ;
extern int __gmpf_integer_p(mpf_srcptr  )  __attribute__((__pure__)) ;
extern void __gmpf_mul(mpf_ptr  , mpf_srcptr  , mpf_srcptr  ) ;
extern void __gmpf_mul_2exp(mpf_ptr  , mpf_srcptr  , mp_bitcnt_t  ) ;
extern void __gmpf_mul_ui(mpf_ptr  , mpf_srcptr  , unsigned long  ) ;
extern void __gmpf_neg(mpf_ptr  , mpf_srcptr  ) ;
extern size_t __gmpf_out_str(FILE * , int  , size_t  , mpf_srcptr  ) ;
extern void __gmpf_pow_ui(mpf_ptr  , mpf_srcptr  , unsigned long  ) ;
extern void __gmpf_random2(mpf_ptr  , mp_size_t  , mp_exp_t  ) ;
extern void __gmpf_reldiff(mpf_ptr  , mpf_srcptr  , mpf_srcptr  ) ;
extern void __gmpf_set(mpf_ptr  , mpf_srcptr  ) ;
extern void __gmpf_set_d(mpf_ptr  , double  ) ;
extern void __gmpf_set_default_prec(mp_bitcnt_t  ) ;
extern void __gmpf_set_prec(mpf_ptr  , mp_bitcnt_t  ) ;
extern void __gmpf_set_prec_raw(mpf_ptr  , mp_bitcnt_t  ) ;
extern void __gmpf_set_q(mpf_ptr  , mpq_srcptr  ) ;
extern void __gmpf_set_si(mpf_ptr  , long  ) ;
extern int __gmpf_set_str(mpf_ptr  , char const   * , int  ) ;
extern void __gmpf_set_ui(mpf_ptr  , unsigned long  ) ;
extern void __gmpf_set_z(mpf_ptr  , mpz_srcptr  ) ;
extern size_t __gmpf_size(mpf_srcptr  )  __attribute__((__pure__)) ;
extern void __gmpf_sqrt(mpf_ptr  , mpf_srcptr  ) ;
extern void __gmpf_sqrt_ui(mpf_ptr  , unsigned long  ) ;
extern void __gmpf_sub(mpf_ptr  , mpf_srcptr  , mpf_srcptr  ) ;
extern void __gmpf_sub_ui(mpf_ptr  , mpf_srcptr  , unsigned long  ) ;
extern void __gmpf_swap(mpf_ptr  , mpf_ptr  ) ;
extern void __gmpf_trunc(mpf_ptr  , mpf_srcptr  ) ;
extern void __gmpf_ui_div(mpf_ptr  , unsigned long  , mpf_srcptr  ) ;
extern void __gmpf_ui_sub(mpf_ptr  , unsigned long  , mpf_srcptr  ) ;
extern void __gmpf_urandomb(__mpf_struct * , __gmp_randstate_struct * ,
                            mp_bitcnt_t  ) ;
__inline extern mp_limb_t __attribute__((__gnu_inline__))  __gmpn_add(mp_ptr __gmp_wp ,
                                                                      mp_srcptr __gmp_xp ,
                                                                      mp_size_t __gmp_xsize ,
                                                                      mp_srcptr __gmp_yp ,
                                                                      mp_size_t __gmp_ysize ) ;
__inline extern mp_limb_t __attribute__((__gnu_inline__))  __gmpn_add_1(mp_ptr __gmp_dst ,
                                                                        mp_srcptr __gmp_src ,
                                                                        mp_size_t __gmp_size ,
                                                                        mp_limb_t __gmp_n ) ;
extern mp_limb_t __gmpn_add_n(mp_ptr  , mp_srcptr  , mp_srcptr  , mp_size_t  ) ;
extern mp_limb_t __gmpn_addmul_1(mp_ptr  , mp_srcptr  , mp_size_t  , mp_limb_t  ) ;
__inline extern int __attribute__((__gnu_inline__))  __gmpn_cmp(mp_srcptr __gmp_xp ,
                                                                mp_srcptr __gmp_yp ,
                                                                mp_size_t __gmp_size )  __attribute__((__pure__)) ;
extern mp_limb_t __gmpn_divexact_by3c(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                      mp_limb_t  ) ;
extern mp_limb_t __gmpn_divrem(mp_ptr  , mp_size_t  , mp_ptr  , mp_size_t  ,
                               mp_srcptr  , mp_size_t  ) ;
extern mp_limb_t __gmpn_divrem_1(mp_ptr  , mp_size_t  , mp_srcptr  ,
                                 mp_size_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_divrem_2(mp_ptr  , mp_size_t  , mp_ptr  , mp_size_t  ,
                                 mp_srcptr  ) ;
extern mp_limb_t __gmpn_div_qr_2(mp_ptr  , mp_ptr  , mp_srcptr  , mp_size_t  ,
                                 mp_srcptr  ) ;
extern mp_size_t __gmpn_gcd(mp_ptr  , mp_ptr  , mp_size_t  , mp_ptr  ,
                            mp_size_t  ) ;
extern mp_limb_t __gmpn_gcd_1(mp_srcptr  , mp_size_t  , mp_limb_t  )  __attribute__((__pure__)) ;
extern mp_limb_t __gmpn_gcdext_1(mp_limb_signed_t * , mp_limb_signed_t * ,
                                 mp_limb_t  , mp_limb_t  ) ;
extern mp_size_t __gmpn_gcdext(mp_ptr  , mp_ptr  , mp_size_t * , mp_ptr  ,
                               mp_size_t  , mp_ptr  , mp_size_t  ) ;
extern size_t __gmpn_get_str(unsigned char * , int  , mp_ptr  , mp_size_t  ) ;
extern mp_bitcnt_t __gmpn_hamdist(mp_srcptr  , mp_srcptr  , mp_size_t  )  __attribute__((__pure__)) ;
extern mp_limb_t __gmpn_lshift(mp_ptr  , mp_srcptr  , mp_size_t  ,
                               unsigned int  ) ;
extern mp_limb_t __gmpn_mod_1(mp_srcptr  , mp_size_t  , mp_limb_t  )  __attribute__((__pure__)) ;
extern mp_limb_t __gmpn_mul(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                            mp_size_t  ) ;
extern mp_limb_t __gmpn_mul_1(mp_ptr  , mp_srcptr  , mp_size_t  , mp_limb_t  ) ;
extern void __gmpn_mul_n(mp_ptr  , mp_srcptr  , mp_srcptr  , mp_size_t  ) ;
extern void __gmpn_sqr(mp_ptr  , mp_srcptr  , mp_size_t  ) ;
__inline extern mp_limb_t __attribute__((__gnu_inline__))  __gmpn_neg(mp_ptr __gmp_rp ,
                                                                      mp_srcptr __gmp_up ,
                                                                      mp_size_t __gmp_n ) ;
extern void __gmpn_com(mp_ptr  , mp_srcptr  , mp_size_t  ) ;
extern int __gmpn_perfect_square_p(mp_srcptr  , mp_size_t  )  __attribute__((__pure__)) ;
extern int __gmpn_perfect_power_p(mp_srcptr  , mp_size_t  )  __attribute__((__pure__)) ;
extern mp_bitcnt_t __gmpn_popcount(mp_srcptr  , mp_size_t  )  __attribute__((__pure__)) ;
extern mp_size_t __gmpn_pow_1(mp_ptr  , mp_srcptr  , mp_size_t  , mp_limb_t  ,
                              mp_ptr  ) ;
extern mp_limb_t __gmpn_preinv_mod_1(mp_srcptr  , mp_size_t  , mp_limb_t  ,
                                     mp_limb_t  )  __attribute__((__pure__)) ;
extern void __gmpn_random(mp_ptr  , mp_size_t  ) ;
extern void __gmpn_random2(mp_ptr  , mp_size_t  ) ;
extern mp_limb_t __gmpn_rshift(mp_ptr  , mp_srcptr  , mp_size_t  ,
                               unsigned int  ) ;
extern mp_bitcnt_t __gmpn_scan0(mp_srcptr  , mp_bitcnt_t  )  __attribute__((__pure__)) ;
extern mp_bitcnt_t __gmpn_scan1(mp_srcptr  , mp_bitcnt_t  )  __attribute__((__pure__)) ;
extern mp_size_t __gmpn_set_str(mp_ptr  , unsigned char const   * , size_t  ,
                                int  ) ;
extern mp_size_t __gmpn_sqrtrem(mp_ptr  , mp_ptr  , mp_srcptr  , mp_size_t  ) ;
__inline extern mp_limb_t __attribute__((__gnu_inline__))  __gmpn_sub(mp_ptr __gmp_wp ,
                                                                      mp_srcptr __gmp_xp ,
                                                                      mp_size_t __gmp_xsize ,
                                                                      mp_srcptr __gmp_yp ,
                                                                      mp_size_t __gmp_ysize ) ;
__inline extern mp_limb_t __attribute__((__gnu_inline__))  __gmpn_sub_1(mp_ptr __gmp_dst ,
                                                                        mp_srcptr __gmp_src ,
                                                                        mp_size_t __gmp_size ,
                                                                        mp_limb_t __gmp_n ) ;
extern mp_limb_t __gmpn_sub_n(mp_ptr  , mp_srcptr  , mp_srcptr  , mp_size_t  ) ;
extern mp_limb_t __gmpn_submul_1(mp_ptr  , mp_srcptr  , mp_size_t  , mp_limb_t  ) ;
extern void __gmpn_tdiv_qr(mp_ptr  , mp_ptr  , mp_size_t  , mp_srcptr  ,
                           mp_size_t  , mp_srcptr  , mp_size_t  ) ;
extern void __gmpn_and_n(mp_ptr  , mp_srcptr  , mp_srcptr  , mp_size_t  ) ;
extern void __gmpn_andn_n(mp_ptr  , mp_srcptr  , mp_srcptr  , mp_size_t  ) ;
extern void __gmpn_nand_n(mp_ptr  , mp_srcptr  , mp_srcptr  , mp_size_t  ) ;
extern void __gmpn_ior_n(mp_ptr  , mp_srcptr  , mp_srcptr  , mp_size_t  ) ;
extern void __gmpn_iorn_n(mp_ptr  , mp_srcptr  , mp_srcptr  , mp_size_t  ) ;
extern void __gmpn_nior_n(mp_ptr  , mp_srcptr  , mp_srcptr  , mp_size_t  ) ;
extern void __gmpn_xor_n(mp_ptr  , mp_srcptr  , mp_srcptr  , mp_size_t  ) ;
extern void __gmpn_xnor_n(mp_ptr  , mp_srcptr  , mp_srcptr  , mp_size_t  ) ;
extern void __gmpn_copyi(mp_ptr  , mp_srcptr  , mp_size_t  ) ;
extern void __gmpn_copyd(mp_ptr  , mp_srcptr  , mp_size_t  ) ;
extern void __gmpn_zero(mp_ptr  , mp_size_t  ) ;
__inline extern void __attribute__((__gnu_inline__))  __gmpz_abs(mpz_ptr __gmp_w ,
                                                                 mpz_srcptr __gmp_u ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "67\n");
  fflush(_coverage_fout);
  if ((unsigned int )__gmp_w != (unsigned int )__gmp_u) {
    fprintf(_coverage_fout, "63\n");
    fflush(_coverage_fout);
    __gmpz_set(__gmp_w, __gmp_u);
  } else {
    fprintf(_coverage_fout, "64\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "68\n");
  fflush(_coverage_fout);
  if (__gmp_w->_mp_size >= 0) {
    fprintf(_coverage_fout, "65\n");
    fflush(_coverage_fout);
    __gmp_w->_mp_size = __gmp_w->_mp_size;
  } else {
    fprintf(_coverage_fout, "66\n");
    fflush(_coverage_fout);
    __gmp_w->_mp_size = - __gmp_w->_mp_size;
  }
  fprintf(_coverage_fout, "69\n");
  fflush(_coverage_fout);
  return;
}
}
__inline extern int __attribute__((__gnu_inline__))  __gmpz_fits_uint_p(mpz_srcptr __gmp_z )  __attribute__((__pure__)) ;
__inline extern int __attribute__((__gnu_inline__))  __gmpz_fits_uint_p(mpz_srcptr __gmp_z ) 
{ mp_size_t __gmp_n ;
  mp_ptr __gmp_p ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "76\n");
  fflush(_coverage_fout);
  __gmp_n = (mp_size_t )__gmp_z->_mp_size;
  fprintf(_coverage_fout, "77\n");
  fflush(_coverage_fout);
  __gmp_p = (mp_ptr )__gmp_z->_mp_d;
  fprintf(_coverage_fout, "78\n");
  fflush(_coverage_fout);
  if (__gmp_n == 0L) {
    fprintf(_coverage_fout, "70\n");
    fflush(_coverage_fout);
    tmp = 1;
  } else {
    fprintf(_coverage_fout, "75\n");
    fflush(_coverage_fout);
    if (__gmp_n == 1L) {
      fprintf(_coverage_fout, "73\n");
      fflush(_coverage_fout);
      if (*(__gmp_p + 0) <= 4294967295UL) {
        fprintf(_coverage_fout, "71\n");
        fflush(_coverage_fout);
        tmp = 1;
      } else {
        fprintf(_coverage_fout, "72\n");
        fflush(_coverage_fout);
        tmp = 0;
      }
    } else {
      fprintf(_coverage_fout, "74\n");
      fflush(_coverage_fout);
      tmp = 0;
    }
  }
  fprintf(_coverage_fout, "79\n");
  fflush(_coverage_fout);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  __gmpz_fits_ulong_p(mpz_srcptr __gmp_z )  __attribute__((__pure__)) ;
__inline extern int __attribute__((__gnu_inline__))  __gmpz_fits_ulong_p(mpz_srcptr __gmp_z ) 
{ mp_size_t __gmp_n ;
  mp_ptr __gmp_p ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "86\n");
  fflush(_coverage_fout);
  __gmp_n = (mp_size_t )__gmp_z->_mp_size;
  fprintf(_coverage_fout, "87\n");
  fflush(_coverage_fout);
  __gmp_p = (mp_ptr )__gmp_z->_mp_d;
  fprintf(_coverage_fout, "88\n");
  fflush(_coverage_fout);
  if (__gmp_n == 0L) {
    fprintf(_coverage_fout, "80\n");
    fflush(_coverage_fout);
    tmp = 1;
  } else {
    fprintf(_coverage_fout, "85\n");
    fflush(_coverage_fout);
    if (__gmp_n == 1L) {
      fprintf(_coverage_fout, "83\n");
      fflush(_coverage_fout);
      if (*(__gmp_p + 0) <= 4294967295UL) {
        fprintf(_coverage_fout, "81\n");
        fflush(_coverage_fout);
        tmp = 1;
      } else {
        fprintf(_coverage_fout, "82\n");
        fflush(_coverage_fout);
        tmp = 0;
      }
    } else {
      fprintf(_coverage_fout, "84\n");
      fflush(_coverage_fout);
      tmp = 0;
    }
  }
  fprintf(_coverage_fout, "89\n");
  fflush(_coverage_fout);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  __gmpz_fits_ushort_p(mpz_srcptr __gmp_z )  __attribute__((__pure__)) ;
__inline extern int __attribute__((__gnu_inline__))  __gmpz_fits_ushort_p(mpz_srcptr __gmp_z ) 
{ mp_size_t __gmp_n ;
  mp_ptr __gmp_p ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "96\n");
  fflush(_coverage_fout);
  __gmp_n = (mp_size_t )__gmp_z->_mp_size;
  fprintf(_coverage_fout, "97\n");
  fflush(_coverage_fout);
  __gmp_p = (mp_ptr )__gmp_z->_mp_d;
  fprintf(_coverage_fout, "98\n");
  fflush(_coverage_fout);
  if (__gmp_n == 0L) {
    fprintf(_coverage_fout, "90\n");
    fflush(_coverage_fout);
    tmp = 1;
  } else {
    fprintf(_coverage_fout, "95\n");
    fflush(_coverage_fout);
    if (__gmp_n == 1L) {
      fprintf(_coverage_fout, "93\n");
      fflush(_coverage_fout);
      if (*(__gmp_p + 0) <= 65535UL) {
        fprintf(_coverage_fout, "91\n");
        fflush(_coverage_fout);
        tmp = 1;
      } else {
        fprintf(_coverage_fout, "92\n");
        fflush(_coverage_fout);
        tmp = 0;
      }
    } else {
      fprintf(_coverage_fout, "94\n");
      fflush(_coverage_fout);
      tmp = 0;
    }
  }
  fprintf(_coverage_fout, "99\n");
  fflush(_coverage_fout);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern unsigned long __attribute__((__gnu_inline__))  __gmpz_get_ui(mpz_srcptr __gmp_z )  __attribute__((__pure__)) ;
__inline extern unsigned long __attribute__((__gnu_inline__))  __gmpz_get_ui(mpz_srcptr __gmp_z ) 
{ mp_ptr __gmp_p ;
  mp_size_t __gmp_n ;
  mp_limb_t __gmp_l ;
  mp_limb_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "102\n");
  fflush(_coverage_fout);
  __gmp_p = (mp_ptr )__gmp_z->_mp_d;
  fprintf(_coverage_fout, "103\n");
  fflush(_coverage_fout);
  __gmp_n = (mp_size_t )__gmp_z->_mp_size;
  fprintf(_coverage_fout, "104\n");
  fflush(_coverage_fout);
  __gmp_l = *(__gmp_p + 0);
  fprintf(_coverage_fout, "105\n");
  fflush(_coverage_fout);
  if (__gmp_n != 0L) {
    fprintf(_coverage_fout, "100\n");
    fflush(_coverage_fout);
    tmp = __gmp_l;
  } else {
    fprintf(_coverage_fout, "101\n");
    fflush(_coverage_fout);
    tmp = 0UL;
  }
  fprintf(_coverage_fout, "106\n");
  fflush(_coverage_fout);
  return ((unsigned long __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern mp_limb_t __attribute__((__gnu_inline__))  __gmpz_getlimbn(mpz_srcptr __gmp_z ,
                                                                           mp_size_t __gmp_n )  __attribute__((__pure__)) ;
__inline extern mp_limb_t __attribute__((__gnu_inline__))  __gmpz_getlimbn(mpz_srcptr __gmp_z ,
                                                                           mp_size_t __gmp_n ) 
{ mp_limb_t __gmp_result ;
  int tmp ;
  int tmp___0 ;
  long tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "116\n");
  fflush(_coverage_fout);
  __gmp_result = (mp_limb_t )0;
  fprintf(_coverage_fout, "117\n");
  fflush(_coverage_fout);
  if (__gmp_n >= 0L) {
    fprintf(_coverage_fout, "111\n");
    fflush(_coverage_fout);
    if (__gmp_z->_mp_size >= 0) {
      fprintf(_coverage_fout, "107\n");
      fflush(_coverage_fout);
      tmp = __gmp_z->_mp_size;
    } else {
      fprintf(_coverage_fout, "108\n");
      fflush(_coverage_fout);
      tmp = - __gmp_z->_mp_size;
    }
    fprintf(_coverage_fout, "112\n");
    fflush(_coverage_fout);
    if (__gmp_n < (mp_size_t )tmp) {
      fprintf(_coverage_fout, "109\n");
      fflush(_coverage_fout);
      tmp___0 = 1;
    } else {
      fprintf(_coverage_fout, "110\n");
      fflush(_coverage_fout);
      tmp___0 = 0;
    }
  } else {
    fprintf(_coverage_fout, "113\n");
    fflush(_coverage_fout);
    tmp___0 = 0;
  }
  fprintf(_coverage_fout, "118\n");
  fflush(_coverage_fout);
  tmp___1 = __builtin_expect((long )(tmp___0 != 0), 1L);
  fprintf(_coverage_fout, "119\n");
  fflush(_coverage_fout);
  if (tmp___1) {
    fprintf(_coverage_fout, "114\n");
    fflush(_coverage_fout);
    __gmp_result = *(__gmp_z->_mp_d + __gmp_n);
  } else {
    fprintf(_coverage_fout, "115\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "120\n");
  fflush(_coverage_fout);
  return ((unsigned long __attribute__((__gnu_inline__))  )__gmp_result);
}
}
__inline extern void __attribute__((__gnu_inline__))  __gmpz_neg(mpz_ptr __gmp_w ,
                                                                 mpz_srcptr __gmp_u ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "123\n");
  fflush(_coverage_fout);
  if ((unsigned int )__gmp_w != (unsigned int )__gmp_u) {
    fprintf(_coverage_fout, "121\n");
    fflush(_coverage_fout);
    __gmpz_set(__gmp_w, __gmp_u);
  } else {
    fprintf(_coverage_fout, "122\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "124\n");
  fflush(_coverage_fout);
  __gmp_w->_mp_size = - __gmp_w->_mp_size;
  fprintf(_coverage_fout, "125\n");
  fflush(_coverage_fout);
  return;
}
}
__inline extern int __attribute__((__gnu_inline__))  __gmpz_perfect_square_p(mpz_srcptr __gmp_a )  __attribute__((__pure__)) ;
__inline extern int __attribute__((__gnu_inline__))  __gmpz_perfect_square_p(mpz_srcptr __gmp_a ) 
{ mp_size_t __gmp_asize ;
  int __gmp_result ;
  long tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "128\n");
  fflush(_coverage_fout);
  __gmp_asize = (long )__gmp_a->_mp_size;
  fprintf(_coverage_fout, "129\n");
  fflush(_coverage_fout);
  __gmp_result = __gmp_asize >= 0L;
  fprintf(_coverage_fout, "130\n");
  fflush(_coverage_fout);
  tmp = __builtin_expect((long )((__gmp_asize > 0L) != 0), 1L);
  fprintf(_coverage_fout, "131\n");
  fflush(_coverage_fout);
  if (tmp) {
    fprintf(_coverage_fout, "126\n");
    fflush(_coverage_fout);
    __gmp_result = __gmpn_perfect_square_p((mp_limb_t const   *)__gmp_a->_mp_d,
                                           __gmp_asize);
  } else {
    fprintf(_coverage_fout, "127\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "132\n");
  fflush(_coverage_fout);
  return ((int __attribute__((__gnu_inline__))  )__gmp_result);
}
}
__inline extern mp_bitcnt_t __attribute__((__gnu_inline__))  __gmpz_popcount(mpz_srcptr __gmp_u )  __attribute__((__pure__)) ;
__inline extern mp_bitcnt_t __attribute__((__gnu_inline__))  __gmpz_popcount(mpz_srcptr __gmp_u ) 
{ mp_size_t __gmp_usize ;
  mp_bitcnt_t __gmp_result ;
  long tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "137\n");
  fflush(_coverage_fout);
  __gmp_usize = (long )__gmp_u->_mp_size;
  fprintf(_coverage_fout, "138\n");
  fflush(_coverage_fout);
  if (__gmp_usize < 0L) {
    fprintf(_coverage_fout, "133\n");
    fflush(_coverage_fout);
    __gmp_result = ~ 0UL;
  } else {
    fprintf(_coverage_fout, "134\n");
    fflush(_coverage_fout);
    __gmp_result = 0UL;
  }
  fprintf(_coverage_fout, "139\n");
  fflush(_coverage_fout);
  tmp = __builtin_expect((long )((__gmp_usize > 0L) != 0), 1L);
  fprintf(_coverage_fout, "140\n");
  fflush(_coverage_fout);
  if (tmp) {
    fprintf(_coverage_fout, "135\n");
    fflush(_coverage_fout);
    __gmp_result = __gmpn_popcount((mp_limb_t const   *)__gmp_u->_mp_d,
                                   __gmp_usize);
  } else {
    fprintf(_coverage_fout, "136\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "141\n");
  fflush(_coverage_fout);
  return ((unsigned long __attribute__((__gnu_inline__))  )__gmp_result);
}
}
__inline extern void __attribute__((__gnu_inline__))  __gmpz_set_q(mpz_ptr __gmp_w ,
                                                                   mpq_srcptr __gmp_u ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "142\n");
  fflush(_coverage_fout);
  __gmpz_tdiv_q(__gmp_w, & __gmp_u->_mp_num, & __gmp_u->_mp_den);
  fprintf(_coverage_fout, "143\n");
  fflush(_coverage_fout);
  return;
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __gmpz_size(mpz_srcptr __gmp_z )  __attribute__((__pure__)) ;
__inline extern size_t __attribute__((__gnu_inline__))  __gmpz_size(mpz_srcptr __gmp_z ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "146\n");
  fflush(_coverage_fout);
  if (__gmp_z->_mp_size >= 0) {
    fprintf(_coverage_fout, "144\n");
    fflush(_coverage_fout);
    tmp = __gmp_z->_mp_size;
  } else {
    fprintf(_coverage_fout, "145\n");
    fflush(_coverage_fout);
    tmp = - __gmp_z->_mp_size;
  }
  fprintf(_coverage_fout, "147\n");
  fflush(_coverage_fout);
  return ((unsigned int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern void __attribute__((__gnu_inline__))  __gmpq_abs(mpq_ptr __gmp_w ,
                                                                 mpq_srcptr __gmp_u ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "152\n");
  fflush(_coverage_fout);
  if ((unsigned int )__gmp_w != (unsigned int )__gmp_u) {
    fprintf(_coverage_fout, "148\n");
    fflush(_coverage_fout);
    __gmpq_set(__gmp_w, __gmp_u);
  } else {
    fprintf(_coverage_fout, "149\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "153\n");
  fflush(_coverage_fout);
  if (__gmp_w->_mp_num._mp_size >= 0) {
    fprintf(_coverage_fout, "150\n");
    fflush(_coverage_fout);
    __gmp_w->_mp_num._mp_size = __gmp_w->_mp_num._mp_size;
  } else {
    fprintf(_coverage_fout, "151\n");
    fflush(_coverage_fout);
    __gmp_w->_mp_num._mp_size = - __gmp_w->_mp_num._mp_size;
  }
  fprintf(_coverage_fout, "154\n");
  fflush(_coverage_fout);
  return;
}
}
__inline extern void __attribute__((__gnu_inline__))  __gmpq_neg(mpq_ptr __gmp_w ,
                                                                 mpq_srcptr __gmp_u ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "157\n");
  fflush(_coverage_fout);
  if ((unsigned int )__gmp_w != (unsigned int )__gmp_u) {
    fprintf(_coverage_fout, "155\n");
    fflush(_coverage_fout);
    __gmpq_set(__gmp_w, __gmp_u);
  } else {
    fprintf(_coverage_fout, "156\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "158\n");
  fflush(_coverage_fout);
  __gmp_w->_mp_num._mp_size = - __gmp_w->_mp_num._mp_size;
  fprintf(_coverage_fout, "159\n");
  fflush(_coverage_fout);
  return;
}
}
__inline extern mp_limb_t __attribute__((__gnu_inline__))  __gmpn_add(mp_ptr __gmp_wp ,
                                                                      mp_srcptr __gmp_xp ,
                                                                      mp_size_t __gmp_xsize ,
                                                                      mp_srcptr __gmp_yp ,
                                                                      mp_size_t __gmp_ysize ) 
{ mp_limb_t __gmp_c ;
  mp_size_t __gmp_i ;
  mp_limb_t __gmp_x ;
  mp_size_t tmp ;
  mp_limb_t tmp___0 ;
  mp_limb_t tmp___1 ;
  mp_size_t __gmp_j ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "188\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "183\n");
    fflush(_coverage_fout);
    __gmp_i = __gmp_ysize;
    fprintf(_coverage_fout, "184\n");
    fflush(_coverage_fout);
    if (__gmp_i != 0L) {
      fprintf(_coverage_fout, "172\n");
      fflush(_coverage_fout);
      tmp___1 = __gmpn_add_n(__gmp_wp, __gmp_xp, __gmp_yp, __gmp_i);
      fprintf(_coverage_fout, "173\n");
      fflush(_coverage_fout);
      if (tmp___1) {
        fprintf(_coverage_fout, "170\n");
        fflush(_coverage_fout);
        while (1) {
          fprintf(_coverage_fout, "163\n");
          fflush(_coverage_fout);
          if (__gmp_i >= __gmp_xsize) {
            fprintf(_coverage_fout, "160\n");
            fflush(_coverage_fout);
            __gmp_c = 1UL;
            goto __gmp_done;
          } else {
            fprintf(_coverage_fout, "161\n");
            fflush(_coverage_fout);

          }
          fprintf(_coverage_fout, "164\n");
          fflush(_coverage_fout);
          __gmp_x = (unsigned long )*(__gmp_xp + __gmp_i);
          fprintf(_coverage_fout, "165\n");
          fflush(_coverage_fout);
          tmp = __gmp_i;
          fprintf(_coverage_fout, "166\n");
          fflush(_coverage_fout);
          __gmp_i ++;
          fprintf(_coverage_fout, "167\n");
          fflush(_coverage_fout);
          tmp___0 = (__gmp_x + 1UL) & 4294967295UL;
          fprintf(_coverage_fout, "168\n");
          fflush(_coverage_fout);
          *(__gmp_wp + tmp) = tmp___0;
          fprintf(_coverage_fout, "169\n");
          fflush(_coverage_fout);
          if (tmp___0 == 0UL) {
            fprintf(_coverage_fout, "162\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        }
      } else {
        fprintf(_coverage_fout, "171\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "174\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "185\n");
    fflush(_coverage_fout);
    if ((unsigned int )__gmp_wp != (unsigned int )__gmp_xp) {
      fprintf(_coverage_fout, "181\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "179\n");
        fflush(_coverage_fout);
        __gmp_j = __gmp_i;
        fprintf(_coverage_fout, "180\n");
        fflush(_coverage_fout);
        while (1) {
          fprintf(_coverage_fout, "176\n");
          fflush(_coverage_fout);
          if (__gmp_j < __gmp_xsize) {
            fprintf(_coverage_fout, "175\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
          fprintf(_coverage_fout, "177\n");
          fflush(_coverage_fout);
          *(__gmp_wp + __gmp_j) = (unsigned long )*(__gmp_xp + __gmp_j);
          fprintf(_coverage_fout, "178\n");
          fflush(_coverage_fout);
          __gmp_j ++;
        }
        break;
      }
    } else {
      fprintf(_coverage_fout, "182\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "186\n");
    fflush(_coverage_fout);
    __gmp_c = 0UL;
    fprintf(_coverage_fout, "187\n");
    fflush(_coverage_fout);
    __gmp_done: ;
    break;
  }
  fprintf(_coverage_fout, "189\n");
  fflush(_coverage_fout);
  return ((unsigned long __attribute__((__gnu_inline__))  )__gmp_c);
}
}
__inline extern mp_limb_t __attribute__((__gnu_inline__))  __gmpn_add_1(mp_ptr __gmp_dst ,
                                                                        mp_srcptr __gmp_src ,
                                                                        mp_size_t __gmp_size ,
                                                                        mp_limb_t __gmp_n ) 
{ mp_limb_t __gmp_c ;
  mp_size_t __gmp_i ;
  mp_limb_t __gmp_x ;
  mp_limb_t __gmp_r ;
  mp_size_t __gmp_j ;
  mp_size_t __gmp_j___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "225\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "221\n");
    fflush(_coverage_fout);
    __gmp_x = (unsigned long )*(__gmp_src + 0);
    fprintf(_coverage_fout, "222\n");
    fflush(_coverage_fout);
    __gmp_r = __gmp_x + __gmp_n;
    fprintf(_coverage_fout, "223\n");
    fflush(_coverage_fout);
    *(__gmp_dst + 0) = __gmp_r;
    fprintf(_coverage_fout, "224\n");
    fflush(_coverage_fout);
    if (__gmp_r < __gmp_n) {
      fprintf(_coverage_fout, "208\n");
      fflush(_coverage_fout);
      __gmp_c = 1UL;
      fprintf(_coverage_fout, "209\n");
      fflush(_coverage_fout);
      __gmp_i = 1L;
      fprintf(_coverage_fout, "210\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "202\n");
        fflush(_coverage_fout);
        if (__gmp_i < __gmp_size) {
          fprintf(_coverage_fout, "190\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "203\n");
        fflush(_coverage_fout);
        __gmp_x = (unsigned long )*(__gmp_src + __gmp_i);
        fprintf(_coverage_fout, "204\n");
        fflush(_coverage_fout);
        __gmp_r = __gmp_x + 1UL;
        fprintf(_coverage_fout, "205\n");
        fflush(_coverage_fout);
        *(__gmp_dst + __gmp_i) = __gmp_r;
        fprintf(_coverage_fout, "206\n");
        fflush(_coverage_fout);
        __gmp_i ++;
        fprintf(_coverage_fout, "207\n");
        fflush(_coverage_fout);
        if (! (__gmp_r < 1UL)) {
          fprintf(_coverage_fout, "199\n");
          fflush(_coverage_fout);
          if ((unsigned int )__gmp_src != (unsigned int )__gmp_dst) {
            fprintf(_coverage_fout, "197\n");
            fflush(_coverage_fout);
            while (1) {
              fprintf(_coverage_fout, "195\n");
              fflush(_coverage_fout);
              __gmp_j = __gmp_i;
              fprintf(_coverage_fout, "196\n");
              fflush(_coverage_fout);
              while (1) {
                fprintf(_coverage_fout, "192\n");
                fflush(_coverage_fout);
                if (__gmp_j < __gmp_size) {
                  fprintf(_coverage_fout, "191\n");
                  fflush(_coverage_fout);

                } else {
                  break;
                }
                fprintf(_coverage_fout, "193\n");
                fflush(_coverage_fout);
                *(__gmp_dst + __gmp_j) = (unsigned long )*(__gmp_src + __gmp_j);
                fprintf(_coverage_fout, "194\n");
                fflush(_coverage_fout);
                __gmp_j ++;
              }
              break;
            }
          } else {
            fprintf(_coverage_fout, "198\n");
            fflush(_coverage_fout);

          }
          fprintf(_coverage_fout, "200\n");
          fflush(_coverage_fout);
          __gmp_c = 0UL;
          break;
        } else {
          fprintf(_coverage_fout, "201\n");
          fflush(_coverage_fout);

        }
      }
    } else {
      fprintf(_coverage_fout, "219\n");
      fflush(_coverage_fout);
      if ((unsigned int )__gmp_src != (unsigned int )__gmp_dst) {
        fprintf(_coverage_fout, "217\n");
        fflush(_coverage_fout);
        while (1) {
          fprintf(_coverage_fout, "215\n");
          fflush(_coverage_fout);
          __gmp_j___0 = 1L;
          fprintf(_coverage_fout, "216\n");
          fflush(_coverage_fout);
          while (1) {
            fprintf(_coverage_fout, "212\n");
            fflush(_coverage_fout);
            if (__gmp_j___0 < __gmp_size) {
              fprintf(_coverage_fout, "211\n");
              fflush(_coverage_fout);

            } else {
              break;
            }
            fprintf(_coverage_fout, "213\n");
            fflush(_coverage_fout);
            *(__gmp_dst + __gmp_j___0) = (unsigned long )*(__gmp_src + __gmp_j___0);
            fprintf(_coverage_fout, "214\n");
            fflush(_coverage_fout);
            __gmp_j___0 ++;
          }
          break;
        }
      } else {
        fprintf(_coverage_fout, "218\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "220\n");
      fflush(_coverage_fout);
      __gmp_c = 0UL;
    }
    break;
  }
  fprintf(_coverage_fout, "226\n");
  fflush(_coverage_fout);
  return ((unsigned long __attribute__((__gnu_inline__))  )__gmp_c);
}
}
__inline extern int __attribute__((__gnu_inline__))  __gmpn_cmp(mp_srcptr __gmp_xp ,
                                                                mp_srcptr __gmp_yp ,
                                                                mp_size_t __gmp_size )  __attribute__((__pure__)) ;
__inline extern int __attribute__((__gnu_inline__))  __gmpn_cmp(mp_srcptr __gmp_xp ,
                                                                mp_srcptr __gmp_yp ,
                                                                mp_size_t __gmp_size ) 
{ int __gmp_result ;
  mp_size_t __gmp_i ;
  mp_limb_t __gmp_x ;
  mp_limb_t __gmp_y ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "240\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "237\n");
    fflush(_coverage_fout);
    __gmp_result = 0;
    fprintf(_coverage_fout, "238\n");
    fflush(_coverage_fout);
    __gmp_i = __gmp_size;
    fprintf(_coverage_fout, "239\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "232\n");
      fflush(_coverage_fout);
      __gmp_i --;
      fprintf(_coverage_fout, "233\n");
      fflush(_coverage_fout);
      if (__gmp_i >= 0L) {
        fprintf(_coverage_fout, "227\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "234\n");
      fflush(_coverage_fout);
      __gmp_x = (unsigned long )*(__gmp_xp + __gmp_i);
      fprintf(_coverage_fout, "235\n");
      fflush(_coverage_fout);
      __gmp_y = (unsigned long )*(__gmp_yp + __gmp_i);
      fprintf(_coverage_fout, "236\n");
      fflush(_coverage_fout);
      if (__gmp_x != __gmp_y) {
        fprintf(_coverage_fout, "230\n");
        fflush(_coverage_fout);
        if (__gmp_x > __gmp_y) {
          fprintf(_coverage_fout, "228\n");
          fflush(_coverage_fout);
          __gmp_result = 1;
        } else {
          fprintf(_coverage_fout, "229\n");
          fflush(_coverage_fout);
          __gmp_result = -1;
        }
        break;
      } else {
        fprintf(_coverage_fout, "231\n");
        fflush(_coverage_fout);

      }
    }
    break;
  }
  fprintf(_coverage_fout, "241\n");
  fflush(_coverage_fout);
  return ((int __attribute__((__gnu_inline__))  )__gmp_result);
}
}
__inline extern mp_limb_t __attribute__((__gnu_inline__))  __gmpn_sub(mp_ptr __gmp_wp ,
                                                                      mp_srcptr __gmp_xp ,
                                                                      mp_size_t __gmp_xsize ,
                                                                      mp_srcptr __gmp_yp ,
                                                                      mp_size_t __gmp_ysize ) 
{ mp_limb_t __gmp_c ;
  mp_size_t __gmp_i ;
  mp_limb_t __gmp_x ;
  mp_size_t tmp ;
  mp_limb_t tmp___0 ;
  mp_size_t __gmp_j ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "269\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "264\n");
    fflush(_coverage_fout);
    __gmp_i = __gmp_ysize;
    fprintf(_coverage_fout, "265\n");
    fflush(_coverage_fout);
    if (__gmp_i != 0L) {
      fprintf(_coverage_fout, "253\n");
      fflush(_coverage_fout);
      tmp___0 = __gmpn_sub_n(__gmp_wp, __gmp_xp, __gmp_yp, __gmp_i);
      fprintf(_coverage_fout, "254\n");
      fflush(_coverage_fout);
      if (tmp___0) {
        fprintf(_coverage_fout, "251\n");
        fflush(_coverage_fout);
        while (1) {
          fprintf(_coverage_fout, "245\n");
          fflush(_coverage_fout);
          if (__gmp_i >= __gmp_xsize) {
            fprintf(_coverage_fout, "242\n");
            fflush(_coverage_fout);
            __gmp_c = 1UL;
            goto __gmp_done;
          } else {
            fprintf(_coverage_fout, "243\n");
            fflush(_coverage_fout);

          }
          fprintf(_coverage_fout, "246\n");
          fflush(_coverage_fout);
          __gmp_x = (unsigned long )*(__gmp_xp + __gmp_i);
          fprintf(_coverage_fout, "247\n");
          fflush(_coverage_fout);
          tmp = __gmp_i;
          fprintf(_coverage_fout, "248\n");
          fflush(_coverage_fout);
          __gmp_i ++;
          fprintf(_coverage_fout, "249\n");
          fflush(_coverage_fout);
          *(__gmp_wp + tmp) = (__gmp_x - 1UL) & 4294967295UL;
          fprintf(_coverage_fout, "250\n");
          fflush(_coverage_fout);
          if (__gmp_x == 0UL) {
            fprintf(_coverage_fout, "244\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        }
      } else {
        fprintf(_coverage_fout, "252\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "255\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "266\n");
    fflush(_coverage_fout);
    if ((unsigned int )__gmp_wp != (unsigned int )__gmp_xp) {
      fprintf(_coverage_fout, "262\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "260\n");
        fflush(_coverage_fout);
        __gmp_j = __gmp_i;
        fprintf(_coverage_fout, "261\n");
        fflush(_coverage_fout);
        while (1) {
          fprintf(_coverage_fout, "257\n");
          fflush(_coverage_fout);
          if (__gmp_j < __gmp_xsize) {
            fprintf(_coverage_fout, "256\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
          fprintf(_coverage_fout, "258\n");
          fflush(_coverage_fout);
          *(__gmp_wp + __gmp_j) = (unsigned long )*(__gmp_xp + __gmp_j);
          fprintf(_coverage_fout, "259\n");
          fflush(_coverage_fout);
          __gmp_j ++;
        }
        break;
      }
    } else {
      fprintf(_coverage_fout, "263\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "267\n");
    fflush(_coverage_fout);
    __gmp_c = 0UL;
    fprintf(_coverage_fout, "268\n");
    fflush(_coverage_fout);
    __gmp_done: ;
    break;
  }
  fprintf(_coverage_fout, "270\n");
  fflush(_coverage_fout);
  return ((unsigned long __attribute__((__gnu_inline__))  )__gmp_c);
}
}
__inline extern mp_limb_t __attribute__((__gnu_inline__))  __gmpn_sub_1(mp_ptr __gmp_dst ,
                                                                        mp_srcptr __gmp_src ,
                                                                        mp_size_t __gmp_size ,
                                                                        mp_limb_t __gmp_n ) 
{ mp_limb_t __gmp_c ;
  mp_size_t __gmp_i ;
  mp_limb_t __gmp_x ;
  mp_limb_t __gmp_r ;
  mp_size_t __gmp_j ;
  mp_size_t __gmp_j___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "306\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "302\n");
    fflush(_coverage_fout);
    __gmp_x = (unsigned long )*(__gmp_src + 0);
    fprintf(_coverage_fout, "303\n");
    fflush(_coverage_fout);
    __gmp_r = __gmp_x - __gmp_n;
    fprintf(_coverage_fout, "304\n");
    fflush(_coverage_fout);
    *(__gmp_dst + 0) = __gmp_r;
    fprintf(_coverage_fout, "305\n");
    fflush(_coverage_fout);
    if (__gmp_x < __gmp_n) {
      fprintf(_coverage_fout, "289\n");
      fflush(_coverage_fout);
      __gmp_c = 1UL;
      fprintf(_coverage_fout, "290\n");
      fflush(_coverage_fout);
      __gmp_i = 1L;
      fprintf(_coverage_fout, "291\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "283\n");
        fflush(_coverage_fout);
        if (__gmp_i < __gmp_size) {
          fprintf(_coverage_fout, "271\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "284\n");
        fflush(_coverage_fout);
        __gmp_x = (unsigned long )*(__gmp_src + __gmp_i);
        fprintf(_coverage_fout, "285\n");
        fflush(_coverage_fout);
        __gmp_r = __gmp_x - 1UL;
        fprintf(_coverage_fout, "286\n");
        fflush(_coverage_fout);
        *(__gmp_dst + __gmp_i) = __gmp_r;
        fprintf(_coverage_fout, "287\n");
        fflush(_coverage_fout);
        __gmp_i ++;
        fprintf(_coverage_fout, "288\n");
        fflush(_coverage_fout);
        if (! (__gmp_x < 1UL)) {
          fprintf(_coverage_fout, "280\n");
          fflush(_coverage_fout);
          if ((unsigned int )__gmp_src != (unsigned int )__gmp_dst) {
            fprintf(_coverage_fout, "278\n");
            fflush(_coverage_fout);
            while (1) {
              fprintf(_coverage_fout, "276\n");
              fflush(_coverage_fout);
              __gmp_j = __gmp_i;
              fprintf(_coverage_fout, "277\n");
              fflush(_coverage_fout);
              while (1) {
                fprintf(_coverage_fout, "273\n");
                fflush(_coverage_fout);
                if (__gmp_j < __gmp_size) {
                  fprintf(_coverage_fout, "272\n");
                  fflush(_coverage_fout);

                } else {
                  break;
                }
                fprintf(_coverage_fout, "274\n");
                fflush(_coverage_fout);
                *(__gmp_dst + __gmp_j) = (unsigned long )*(__gmp_src + __gmp_j);
                fprintf(_coverage_fout, "275\n");
                fflush(_coverage_fout);
                __gmp_j ++;
              }
              break;
            }
          } else {
            fprintf(_coverage_fout, "279\n");
            fflush(_coverage_fout);

          }
          fprintf(_coverage_fout, "281\n");
          fflush(_coverage_fout);
          __gmp_c = 0UL;
          break;
        } else {
          fprintf(_coverage_fout, "282\n");
          fflush(_coverage_fout);

        }
      }
    } else {
      fprintf(_coverage_fout, "300\n");
      fflush(_coverage_fout);
      if ((unsigned int )__gmp_src != (unsigned int )__gmp_dst) {
        fprintf(_coverage_fout, "298\n");
        fflush(_coverage_fout);
        while (1) {
          fprintf(_coverage_fout, "296\n");
          fflush(_coverage_fout);
          __gmp_j___0 = 1L;
          fprintf(_coverage_fout, "297\n");
          fflush(_coverage_fout);
          while (1) {
            fprintf(_coverage_fout, "293\n");
            fflush(_coverage_fout);
            if (__gmp_j___0 < __gmp_size) {
              fprintf(_coverage_fout, "292\n");
              fflush(_coverage_fout);

            } else {
              break;
            }
            fprintf(_coverage_fout, "294\n");
            fflush(_coverage_fout);
            *(__gmp_dst + __gmp_j___0) = (unsigned long )*(__gmp_src + __gmp_j___0);
            fprintf(_coverage_fout, "295\n");
            fflush(_coverage_fout);
            __gmp_j___0 ++;
          }
          break;
        }
      } else {
        fprintf(_coverage_fout, "299\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "301\n");
      fflush(_coverage_fout);
      __gmp_c = 0UL;
    }
    break;
  }
  fprintf(_coverage_fout, "307\n");
  fflush(_coverage_fout);
  return ((unsigned long __attribute__((__gnu_inline__))  )__gmp_c);
}
}
__inline extern mp_limb_t __attribute__((__gnu_inline__))  __gmpn_neg(mp_ptr __gmp_rp ,
                                                                      mp_srcptr __gmp_up ,
                                                                      mp_size_t __gmp_n ) 
{ mp_limb_t __gmp_ul ;
  mp_limb_t __gmp_cy ;
  mp_srcptr tmp ;
  mp_ptr tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "318\n");
  fflush(_coverage_fout);
  __gmp_cy = 0UL;
  fprintf(_coverage_fout, "319\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "309\n");
    fflush(_coverage_fout);
    tmp = __gmp_up;
    fprintf(_coverage_fout, "310\n");
    fflush(_coverage_fout);
    __gmp_up ++;
    fprintf(_coverage_fout, "311\n");
    fflush(_coverage_fout);
    __gmp_ul = (unsigned long )*tmp;
    fprintf(_coverage_fout, "312\n");
    fflush(_coverage_fout);
    tmp___0 = __gmp_rp;
    fprintf(_coverage_fout, "313\n");
    fflush(_coverage_fout);
    __gmp_rp ++;
    fprintf(_coverage_fout, "314\n");
    fflush(_coverage_fout);
    *tmp___0 = - __gmp_ul - __gmp_cy;
    fprintf(_coverage_fout, "315\n");
    fflush(_coverage_fout);
    __gmp_cy |= (unsigned long )(__gmp_ul != 0UL);
    fprintf(_coverage_fout, "316\n");
    fflush(_coverage_fout);
    __gmp_n --;
    fprintf(_coverage_fout, "317\n");
    fflush(_coverage_fout);
    if (__gmp_n != 0L) {
      fprintf(_coverage_fout, "308\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
  }
  fprintf(_coverage_fout, "320\n");
  fflush(_coverage_fout);
  return ((unsigned long __attribute__((__gnu_inline__))  )__gmp_cy);
}
}
extern  __attribute__((__nothrow__)) intmax_t imaxabs(intmax_t __n )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) imaxdiv_t imaxdiv(intmax_t __numer ,
                                                       intmax_t __denom )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) intmax_t __attribute__((__gnu_inline__))  strtoimax(char const   * __restrict  nptr ,
                                                                                                  char ** __restrict  endptr ,
                                                                                                  int base ) ;
__inline extern  __attribute__((__nothrow__)) uintmax_t __attribute__((__gnu_inline__))  strtoumax(char const   * __restrict  nptr ,
                                                                                                   char ** __restrict  endptr ,
                                                                                                   int base ) ;
__inline extern  __attribute__((__nothrow__)) intmax_t __attribute__((__gnu_inline__))  wcstoimax(__gwchar_t const   * __restrict  nptr ,
                                                                                                  __gwchar_t ** __restrict  endptr ,
                                                                                                  int base ) ;
__inline extern  __attribute__((__nothrow__)) uintmax_t __attribute__((__gnu_inline__))  wcstoumax(__gwchar_t const   * __restrict  nptr ,
                                                                                                   __gwchar_t ** __restrict  endptr ,
                                                                                                   int base ) ;
extern  __attribute__((__nothrow__)) long long __strtoll_internal(char const   * __restrict  __nptr ,
                                                                  char ** __restrict  __endptr ,
                                                                  int __base ,
                                                                  int __group )  __attribute__((__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) intmax_t __attribute__((__gnu_inline__))  strtoimax(char const   * __restrict  nptr ,
                                                                                                  char ** __restrict  endptr ,
                                                                                                  int base ) ;
__inline extern intmax_t __attribute__((__gnu_inline__))  strtoimax(char const   * __restrict  nptr ,
                                                                    char ** __restrict  endptr ,
                                                                    int base ) 
{ long long tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "321\n");
  fflush(_coverage_fout);
  tmp = __strtoll_internal(nptr, endptr, base, 0);
  fprintf(_coverage_fout, "322\n");
  fflush(_coverage_fout);
  return ((long long __attribute__((__gnu_inline__))  )tmp);
}
}
extern  __attribute__((__nothrow__)) unsigned long long __strtoull_internal(char const   * __restrict  __nptr ,
                                                                            char ** __restrict  __endptr ,
                                                                            int __base ,
                                                                            int __group )  __attribute__((__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) uintmax_t __attribute__((__gnu_inline__))  strtoumax(char const   * __restrict  nptr ,
                                                                                                   char ** __restrict  endptr ,
                                                                                                   int base ) ;
__inline extern uintmax_t __attribute__((__gnu_inline__))  strtoumax(char const   * __restrict  nptr ,
                                                                     char ** __restrict  endptr ,
                                                                     int base ) 
{ unsigned long long tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "323\n");
  fflush(_coverage_fout);
  tmp = __strtoull_internal(nptr, endptr, base, 0);
  fprintf(_coverage_fout, "324\n");
  fflush(_coverage_fout);
  return ((unsigned long long __attribute__((__gnu_inline__))  )tmp);
}
}
extern  __attribute__((__nothrow__)) long long __wcstoll_internal(__gwchar_t const   * __restrict  __nptr ,
                                                                  __gwchar_t ** __restrict  __endptr ,
                                                                  int __base ,
                                                                  int __group )  __attribute__((__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) intmax_t __attribute__((__gnu_inline__))  wcstoimax(__gwchar_t const   * __restrict  nptr ,
                                                                                                  __gwchar_t ** __restrict  endptr ,
                                                                                                  int base ) ;
__inline extern intmax_t __attribute__((__gnu_inline__))  wcstoimax(__gwchar_t const   * __restrict  nptr ,
                                                                    __gwchar_t ** __restrict  endptr ,
                                                                    int base ) 
{ long long tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "325\n");
  fflush(_coverage_fout);
  tmp = __wcstoll_internal(nptr, endptr, base, 0);
  fprintf(_coverage_fout, "326\n");
  fflush(_coverage_fout);
  return ((long long __attribute__((__gnu_inline__))  )tmp);
}
}
extern  __attribute__((__nothrow__)) unsigned long long __wcstoull_internal(__gwchar_t const   * __restrict  __nptr ,
                                                                            __gwchar_t ** __restrict  __endptr ,
                                                                            int __base ,
                                                                            int __group )  __attribute__((__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) uintmax_t __attribute__((__gnu_inline__))  wcstoumax(__gwchar_t const   * __restrict  nptr ,
                                                                                                   __gwchar_t ** __restrict  endptr ,
                                                                                                   int base ) ;
__inline extern uintmax_t __attribute__((__gnu_inline__))  wcstoumax(__gwchar_t const   * __restrict  nptr ,
                                                                     __gwchar_t ** __restrict  endptr ,
                                                                     int base ) 
{ unsigned long long tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "327\n");
  fflush(_coverage_fout);
  tmp = __wcstoull_internal(nptr, endptr, base, 0);
  fprintf(_coverage_fout, "328\n");
  fflush(_coverage_fout);
  return ((unsigned long long __attribute__((__gnu_inline__))  )tmp);
}
}
extern void *__gmp_tmp_reentrant_alloc(struct tmp_reentrant_t ** , size_t  )  __attribute__((__malloc__)) ;
extern void __gmp_tmp_reentrant_free(struct tmp_reentrant_t * ) ;
extern void *(*__gmp_allocate_func)(size_t  ) ;
extern void *(*__gmp_reallocate_func)(void * , size_t  , size_t  ) ;
extern void (*__gmp_free_func)(void * , size_t  ) ;
extern void *__gmp_default_allocate(size_t  ) ;
extern void *__gmp_default_reallocate(void * , size_t  , size_t  ) ;
extern void __gmp_default_free(void * , size_t  ) ;
extern void ( __attribute__((__regparm__(1))) __gmpz_aorsmul_1)(mp_size_t  ,
                                                                mpz_ptr  ,
                                                                mpz_srcptr  ,
                                                                mp_limb_t  ) ;
extern void __gmpz_n_pow_ui(mpz_ptr  , mp_srcptr  , mp_size_t  , unsigned long  ) ;
extern mp_limb_t __gmpn_addmul_1c(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                  mp_limb_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_addmul_2(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ) ;
extern mp_limb_t __gmpn_addmul_3(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ) ;
extern mp_limb_t __gmpn_addmul_4(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ) ;
extern mp_limb_t __gmpn_addmul_5(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ) ;
extern mp_limb_t __gmpn_addmul_6(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ) ;
extern mp_limb_t __gmpn_addmul_7(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ) ;
extern mp_limb_t __gmpn_addmul_8(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ) ;
extern mp_limb_t __gmpn_addmul_2s(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                  mp_srcptr  ) ;
extern mp_limb_t __gmpn_addlsh1_n(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                  mp_size_t  ) ;
extern mp_limb_t __gmpn_addlsh1_nc(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                   mp_size_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_addlsh1_n_ip1(mp_ptr  , mp_srcptr  , mp_size_t  ) ;
extern mp_limb_t __gmpn_addlsh1_nc_ip1(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                       mp_limb_t  ) ;
extern mp_limb_t __gmpn_addlsh2_n(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                  mp_size_t  ) ;
extern mp_limb_t __gmpn_addlsh2_nc(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                   mp_size_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_addlsh2_n_ip1(mp_ptr  , mp_srcptr  , mp_size_t  ) ;
extern mp_limb_t __gmpn_addlsh2_nc_ip1(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                       mp_limb_t  ) ;
extern mp_limb_t __gmpn_addlsh_n(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                 mp_size_t  , unsigned int  ) ;
extern mp_limb_t __gmpn_addlsh_nc(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                  mp_size_t  , unsigned int  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_addlsh_n_ip1(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                     unsigned int  ) ;
extern mp_limb_t __gmpn_addlsh_nc_ip1(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                      unsigned int  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_sublsh1_n(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                  mp_size_t  ) ;
extern mp_limb_t __gmpn_sublsh1_nc(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                   mp_size_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_sublsh1_n_ip1(mp_ptr  , mp_srcptr  , mp_size_t  ) ;
extern mp_limb_t __gmpn_sublsh1_nc_ip1(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                       mp_limb_t  ) ;
extern mp_limb_signed_t __gmpn_rsblsh1_n(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                         mp_size_t  ) ;
extern mp_limb_signed_t __gmpn_rsblsh1_nc(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                          mp_size_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_sublsh2_n(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                  mp_size_t  ) ;
extern mp_limb_t __gmpn_sublsh2_nc(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                   mp_size_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_sublsh2_n_ip1(mp_ptr  , mp_srcptr  , mp_size_t  ) ;
extern mp_limb_t __gmpn_sublsh2_nc_ip1(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                       mp_limb_t  ) ;
extern mp_limb_t __gmpn_sublsh_n(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                 mp_size_t  , unsigned int  ) ;
extern mp_limb_t __gmpn_sublsh_n_ip1(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                     unsigned int  ) ;
extern mp_limb_t __gmpn_sublsh_nc_ip1(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                      unsigned int  , mp_limb_t  ) ;
extern mp_limb_signed_t __gmpn_rsblsh2_n(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                         mp_size_t  ) ;
extern mp_limb_signed_t __gmpn_rsblsh2_nc(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                          mp_size_t  , mp_limb_t  ) ;
extern mp_limb_signed_t __gmpn_rsblsh_n(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                        mp_size_t  , unsigned int  ) ;
extern mp_limb_signed_t __gmpn_rsblsh_nc(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                         mp_size_t  , unsigned int  ,
                                         mp_limb_t  ) ;
extern mp_limb_t __gmpn_rsh1add_n(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                  mp_size_t  ) ;
extern mp_limb_t __gmpn_rsh1add_nc(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                   mp_size_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_rsh1sub_n(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                  mp_size_t  ) ;
extern mp_limb_t __gmpn_rsh1sub_nc(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                   mp_size_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_lshiftc(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                unsigned int  ) ;
extern mp_limb_t __gmpn_add_n_sub_n(mp_ptr  , mp_ptr  , mp_srcptr  ,
                                    mp_srcptr  , mp_size_t  ) ;
extern mp_limb_t __gmpn_add_n_sub_nc(mp_ptr  , mp_ptr  , mp_srcptr  ,
                                     mp_srcptr  , mp_size_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_addaddmul_1msb0(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                        mp_size_t  , mp_limb_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_divrem_1c(mp_ptr  , mp_size_t  , mp_srcptr  ,
                                  mp_size_t  , mp_limb_t  , mp_limb_t  ) ;
extern void __gmpn_dump(mp_srcptr  , mp_size_t  ) ;
extern mp_size_t __gmpn_fib2_ui(mp_ptr  , mp_ptr  , unsigned long  ) ;
extern int __gmpn_jacobi_base(mp_limb_t  , mp_limb_t  , int  )  __attribute__((__const__)) ;
extern int __gmpn_jacobi_lehmer(mp_ptr  , mp_ptr  , mp_size_t  , unsigned int  ,
                                mp_ptr  ) ;
extern mp_limb_t __gmpn_mod_1c(mp_srcptr  , mp_size_t  , mp_limb_t  ,
                               mp_limb_t  )  __attribute__((__pure__)) ;
extern mp_limb_t __gmpn_mul_1c(mp_ptr  , mp_srcptr  , mp_size_t  , mp_limb_t  ,
                               mp_limb_t  ) ;
extern mp_limb_t __gmpn_mul_2(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ) ;
extern mp_limb_t __gmpn_mul_3(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ) ;
extern mp_limb_t __gmpn_mul_4(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ) ;
extern mp_limb_t __gmpn_mul_5(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ) ;
extern mp_limb_t __gmpn_mul_6(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ) ;
extern void __gmpn_mul_basecase(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                                mp_size_t  ) ;
extern void __gmpn_mullo_n(mp_ptr  , mp_srcptr  , mp_srcptr  , mp_size_t  ) ;
extern void __gmpn_mullo_basecase(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                  mp_size_t  ) ;
extern void __gmpn_sqr_basecase(mp_ptr  , mp_srcptr  , mp_size_t  ) ;
extern mp_limb_t __gmpn_submul_1c(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                  mp_limb_t  , mp_limb_t  ) ;
extern void __gmpn_redc_1(mp_ptr  , mp_ptr  , mp_srcptr  , mp_size_t  ,
                          mp_limb_t  ) ;
extern void __gmpn_redc_2(mp_ptr  , mp_ptr  , mp_srcptr  , mp_size_t  ,
                          mp_srcptr  ) ;
extern void __gmpn_redc_n(mp_ptr  , mp_ptr  , mp_srcptr  , mp_size_t  ,
                          mp_srcptr  ) ;
extern void __gmpn_mod_1_1p_cps(mp_limb_t * , mp_limb_t  ) ;
extern mp_limb_t __gmpn_mod_1_1p(mp_srcptr  , mp_size_t  , mp_limb_t  ,
                                 mp_limb_t * )  __attribute__((__pure__)) ;
extern void __gmpn_mod_1s_2p_cps(mp_limb_t * , mp_limb_t  ) ;
extern mp_limb_t __gmpn_mod_1s_2p(mp_srcptr  , mp_size_t  , mp_limb_t  ,
                                  mp_limb_t * )  __attribute__((__pure__)) ;
extern void __gmpn_mod_1s_3p_cps(mp_limb_t * , mp_limb_t  ) ;
extern mp_limb_t __gmpn_mod_1s_3p(mp_srcptr  , mp_size_t  , mp_limb_t  ,
                                  mp_limb_t * )  __attribute__((__pure__)) ;
extern void __gmpn_mod_1s_4p_cps(mp_limb_t * , mp_limb_t  ) ;
extern mp_limb_t __gmpn_mod_1s_4p(mp_srcptr  , mp_size_t  , mp_limb_t  ,
                                  mp_limb_t * )  __attribute__((__pure__)) ;
extern void __gmpn_bc_mulmod_bnm1(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                  mp_size_t  , mp_ptr  ) ;
extern void __gmpn_mulmod_bnm1(mp_ptr  , mp_size_t  , mp_srcptr  , mp_size_t  ,
                               mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern mp_size_t __gmpn_mulmod_bnm1_next_size(mp_size_t  )  __attribute__((__const__)) ;
__inline static mp_size_t mpn_mulmod_bnm1_itch(mp_size_t rn , mp_size_t an ,
                                               mp_size_t bn ) 
{ mp_size_t n ;
  mp_size_t itch ;
  mp_size_t tmp ;
  mp_size_t tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "334\n");
  fflush(_coverage_fout);
  n = rn >> 1;
  fprintf(_coverage_fout, "335\n");
  fflush(_coverage_fout);
  if (an > n) {
    fprintf(_coverage_fout, "331\n");
    fflush(_coverage_fout);
    if (bn > n) {
      fprintf(_coverage_fout, "329\n");
      fflush(_coverage_fout);
      tmp = rn;
    } else {
      fprintf(_coverage_fout, "330\n");
      fflush(_coverage_fout);
      tmp = n;
    }
    fprintf(_coverage_fout, "332\n");
    fflush(_coverage_fout);
    tmp___0 = tmp;
  } else {
    fprintf(_coverage_fout, "333\n");
    fflush(_coverage_fout);
    tmp___0 = 0L;
  }
  fprintf(_coverage_fout, "336\n");
  fflush(_coverage_fout);
  itch = (rn + 4L) + tmp___0;
  fprintf(_coverage_fout, "337\n");
  fflush(_coverage_fout);
  return (itch);
}
}
extern void __gmpn_sqrmod_bnm1(mp_ptr  , mp_size_t  , mp_srcptr  , mp_size_t  ,
                               mp_ptr  ) ;
extern mp_size_t __gmpn_sqrmod_bnm1_next_size(mp_size_t  )  __attribute__((__const__)) ;
__inline static mp_size_t mpn_sqrmod_bnm1_itch(mp_size_t rn , mp_size_t an ) 
{ mp_size_t n ;
  mp_size_t itch ;
  mp_size_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "340\n");
  fflush(_coverage_fout);
  n = rn >> 1;
  fprintf(_coverage_fout, "341\n");
  fflush(_coverage_fout);
  if (an > n) {
    fprintf(_coverage_fout, "338\n");
    fflush(_coverage_fout);
    tmp = an;
  } else {
    fprintf(_coverage_fout, "339\n");
    fflush(_coverage_fout);
    tmp = 0L;
  }
  fprintf(_coverage_fout, "342\n");
  fflush(_coverage_fout);
  itch = (rn + 3L) + tmp;
  fprintf(_coverage_fout, "343\n");
  fflush(_coverage_fout);
  return (itch);
}
}
extern void __gmp_randinit_mt_noseed(__gmp_randstate_struct * ) ;
extern char __gmp_rands_initialized ;
extern gmp_randstate_t __gmp_rands ;
extern void __gmpn_sqr_diagonal(mp_ptr  , mp_srcptr  , mp_size_t  ) ;
extern void __gmpn_sqr_diag_addlsh1(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                    mp_size_t  ) ;
extern void __gmpn_toom_interpolate_5pts(mp_ptr  , mp_ptr  , mp_ptr  ,
                                         mp_size_t  , mp_size_t  , int  ,
                                         mp_limb_t  ) ;
extern void __gmpn_toom_interpolate_6pts(mp_ptr  , mp_size_t  ,
                                         enum toom6_flags  , mp_ptr  , mp_ptr  ,
                                         mp_ptr  , mp_size_t  ) ;
extern void __gmpn_toom_interpolate_7pts(mp_ptr  , mp_size_t  ,
                                         enum toom7_flags  , mp_ptr  , mp_ptr  ,
                                         mp_ptr  , mp_ptr  , mp_size_t  ,
                                         mp_ptr  ) ;
extern void __gmpn_toom_interpolate_8pts(mp_ptr  , mp_size_t  , mp_ptr  ,
                                         mp_ptr  , mp_size_t  , mp_ptr  ) ;
extern void __gmpn_toom_interpolate_12pts(mp_ptr  , mp_ptr  , mp_ptr  ,
                                          mp_ptr  , mp_size_t  , mp_size_t  ,
                                          int  , mp_ptr  ) ;
extern void __gmpn_toom_interpolate_16pts(mp_ptr  , mp_ptr  , mp_ptr  ,
                                          mp_ptr  , mp_ptr  , mp_size_t  ,
                                          mp_size_t  , int  , mp_ptr  ) ;
extern void __gmpn_toom_couple_handling(mp_ptr  , mp_size_t  , mp_ptr  , int  ,
                                        mp_size_t  , int  , int  ) ;
extern int __gmpn_toom_eval_dgr3_pm1(mp_ptr  , mp_ptr  , mp_srcptr  ,
                                     mp_size_t  , mp_size_t  , mp_ptr  ) ;
extern int __gmpn_toom_eval_dgr3_pm2(mp_ptr  , mp_ptr  , mp_srcptr  ,
                                     mp_size_t  , mp_size_t  , mp_ptr  ) ;
extern int __gmpn_toom_eval_pm1(mp_ptr  , mp_ptr  , unsigned int  , mp_srcptr  ,
                                mp_size_t  , mp_size_t  , mp_ptr  ) ;
extern int __gmpn_toom_eval_pm2(mp_ptr  , mp_ptr  , unsigned int  , mp_srcptr  ,
                                mp_size_t  , mp_size_t  , mp_ptr  ) ;
extern int __gmpn_toom_eval_pm2exp(mp_ptr  , mp_ptr  , unsigned int  ,
                                   mp_srcptr  , mp_size_t  , mp_size_t  ,
                                   unsigned int  , mp_ptr  ) ;
extern int __gmpn_toom_eval_pm2rexp(mp_ptr  , mp_ptr  , unsigned int  ,
                                    mp_srcptr  , mp_size_t  , mp_size_t  ,
                                    unsigned int  , mp_ptr  ) ;
extern void __gmpn_toom22_mul(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                              mp_size_t  , mp_ptr  ) ;
extern void __gmpn_toom32_mul(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                              mp_size_t  , mp_ptr  ) ;
extern void __gmpn_toom42_mul(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                              mp_size_t  , mp_ptr  ) ;
extern void __gmpn_toom52_mul(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                              mp_size_t  , mp_ptr  ) ;
extern void __gmpn_toom62_mul(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                              mp_size_t  , mp_ptr  ) ;
extern void __gmpn_toom2_sqr(mp_ptr  , mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern void __gmpn_toom33_mul(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                              mp_size_t  , mp_ptr  ) ;
extern void __gmpn_toom43_mul(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                              mp_size_t  , mp_ptr  ) ;
extern void __gmpn_toom53_mul(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                              mp_size_t  , mp_ptr  ) ;
extern void __gmpn_toom63_mul(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                              mp_size_t  , mp_ptr  ) ;
extern void __gmpn_toom3_sqr(mp_ptr  , mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern void __gmpn_toom44_mul(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                              mp_size_t  , mp_ptr  ) ;
extern void __gmpn_toom4_sqr(mp_ptr  , mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern void __gmpn_toom6h_mul(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                              mp_size_t  , mp_ptr  ) ;
extern void __gmpn_toom6_sqr(mp_ptr  , mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern void __gmpn_toom8h_mul(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                              mp_size_t  , mp_ptr  ) ;
extern void __gmpn_toom8_sqr(mp_ptr  , mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern int __gmpn_fft_best_k(mp_size_t  , int  )  __attribute__((__const__)) ;
extern mp_limb_t __gmpn_mul_fft(mp_ptr  , mp_size_t  , mp_srcptr  , mp_size_t  ,
                                mp_srcptr  , mp_size_t  , int  ) ;
extern void __gmpn_mul_fft_full(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                                mp_size_t  ) ;
extern void __gmpn_nussbaumer_mul(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                  mp_srcptr  , mp_size_t  ) ;
extern mp_size_t __gmpn_fft_next_size(mp_size_t  , int  )  __attribute__((__const__)) ;
extern mp_limb_t __gmpn_div_qr_2n_pi1(mp_ptr  , mp_ptr  , mp_srcptr  ,
                                      mp_size_t  , mp_limb_t  , mp_limb_t  ,
                                      mp_limb_t  ) ;
extern mp_limb_t __gmpn_div_qr_2u_pi1(mp_ptr  , mp_ptr  , mp_srcptr  ,
                                      mp_size_t  , mp_limb_t  , mp_limb_t  ,
                                      int  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_sbpi1_div_qr(mp_ptr  , mp_ptr  , mp_size_t  ,
                                     mp_srcptr  , mp_size_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_sbpi1_div_q(mp_ptr  , mp_ptr  , mp_size_t  ,
                                    mp_srcptr  , mp_size_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_sbpi1_divappr_q(mp_ptr  , mp_ptr  , mp_size_t  ,
                                        mp_srcptr  , mp_size_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_dcpi1_div_qr(mp_ptr  , mp_ptr  , mp_size_t  ,
                                     mp_srcptr  , mp_size_t  , gmp_pi1_t * ) ;
extern mp_limb_t __gmpn_dcpi1_div_qr_n(mp_ptr  , mp_ptr  , mp_srcptr  ,
                                       mp_size_t  , gmp_pi1_t * , mp_ptr  ) ;
extern mp_limb_t __gmpn_dcpi1_div_q(mp_ptr  , mp_ptr  , mp_size_t  ,
                                    mp_srcptr  , mp_size_t  , gmp_pi1_t * ) ;
extern mp_limb_t __gmpn_dcpi1_divappr_q(mp_ptr  , mp_ptr  , mp_size_t  ,
                                        mp_srcptr  , mp_size_t  , gmp_pi1_t * ) ;
extern mp_limb_t __gmpn_dcpi1_divappr_q_n(mp_ptr  , mp_ptr  , mp_srcptr  ,
                                          mp_size_t  , gmp_pi1_t * , mp_ptr  ) ;
extern mp_limb_t __gmpn_mu_div_qr(mp_ptr  , mp_ptr  , mp_srcptr  , mp_size_t  ,
                                  mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern mp_size_t __gmpn_mu_div_qr_itch(mp_size_t  , mp_size_t  , int  ) ;
extern mp_size_t __gmpn_mu_div_qr_choose_in(mp_size_t  , mp_size_t  , int  ) ;
extern mp_limb_t __gmpn_preinv_mu_div_qr(mp_ptr  , mp_ptr  , mp_srcptr  ,
                                         mp_size_t  , mp_srcptr  , mp_size_t  ,
                                         mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern mp_size_t __gmpn_preinv_mu_div_qr_itch(mp_size_t  , mp_size_t  ,
                                              mp_size_t  ) ;
extern mp_limb_t __gmpn_mu_divappr_q(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                     mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern mp_size_t __gmpn_mu_divappr_q_itch(mp_size_t  , mp_size_t  , int  ) ;
extern mp_size_t __gmpn_mu_divappr_q_choose_in(mp_size_t  , mp_size_t  , int  ) ;
extern mp_limb_t __gmpn_preinv_mu_divappr_q(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                            mp_srcptr  , mp_size_t  ,
                                            mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern mp_limb_t __gmpn_mu_div_q(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                 mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern mp_size_t __gmpn_mu_div_q_itch(mp_size_t  , mp_size_t  , int  ) ;
extern void __gmpn_div_q(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                         mp_size_t  , mp_ptr  ) ;
extern void __gmpn_invert(mp_ptr  , mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern mp_limb_t __gmpn_ni_invertappr(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                      mp_ptr  ) ;
extern mp_limb_t __gmpn_invertappr(mp_ptr  , mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern void __gmpn_binvert(mp_ptr  , mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern mp_size_t __gmpn_binvert_itch(mp_size_t  ) ;
extern mp_limb_t __gmpn_bdiv_q_1(mp_ptr  , mp_srcptr  , mp_size_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_pi1_bdiv_q_1(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                     mp_limb_t  , mp_limb_t  , int  ) ;
extern mp_limb_t __gmpn_sbpi1_bdiv_qr(mp_ptr  , mp_ptr  , mp_size_t  ,
                                      mp_srcptr  , mp_size_t  , mp_limb_t  ) ;
extern void __gmpn_sbpi1_bdiv_q(mp_ptr  , mp_ptr  , mp_size_t  , mp_srcptr  ,
                                mp_size_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_dcpi1_bdiv_qr(mp_ptr  , mp_ptr  , mp_size_t  ,
                                      mp_srcptr  , mp_size_t  , mp_limb_t  ) ;
extern mp_size_t __gmpn_dcpi1_bdiv_qr_n_itch(mp_size_t  ) ;
extern mp_limb_t __gmpn_dcpi1_bdiv_qr_n(mp_ptr  , mp_ptr  , mp_srcptr  ,
                                        mp_size_t  , mp_limb_t  , mp_ptr  ) ;
extern void __gmpn_dcpi1_bdiv_q(mp_ptr  , mp_ptr  , mp_size_t  , mp_srcptr  ,
                                mp_size_t  , mp_limb_t  ) ;
extern mp_size_t __gmpn_dcpi1_bdiv_q_n_itch(mp_size_t  ) ;
extern void __gmpn_dcpi1_bdiv_q_n(mp_ptr  , mp_ptr  , mp_srcptr  , mp_size_t  ,
                                  mp_limb_t  , mp_ptr  ) ;
extern mp_limb_t __gmpn_mu_bdiv_qr(mp_ptr  , mp_ptr  , mp_srcptr  , mp_size_t  ,
                                   mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern mp_size_t __gmpn_mu_bdiv_qr_itch(mp_size_t  , mp_size_t  ) ;
extern void __gmpn_mu_bdiv_q(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                             mp_size_t  , mp_ptr  ) ;
extern mp_size_t __gmpn_mu_bdiv_q_itch(mp_size_t  , mp_size_t  ) ;
extern mp_limb_t __gmpn_bdiv_qr(mp_ptr  , mp_ptr  , mp_srcptr  , mp_size_t  ,
                                mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern mp_size_t __gmpn_bdiv_qr_itch(mp_size_t  , mp_size_t  ) ;
extern void __gmpn_bdiv_q(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                          mp_size_t  , mp_ptr  ) ;
extern mp_size_t __gmpn_bdiv_q_itch(mp_size_t  , mp_size_t  ) ;
extern void __gmpn_divexact(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                            mp_size_t  ) ;
extern mp_size_t __gmpn_divexact_itch(mp_size_t  , mp_size_t  ) ;
extern mp_limb_t __gmpn_bdiv_dbm1c(mp_ptr  , mp_srcptr  , mp_size_t  ,
                                   mp_limb_t  , mp_limb_t  ) ;
extern void __gmpn_powm(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                        mp_size_t  , mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern void __gmpn_powlo(mp_ptr  , mp_srcptr  , mp_srcptr  , mp_size_t  ,
                         mp_size_t  , mp_ptr  ) ;
extern void __gmpn_powm_sec(mp_ptr  , mp_srcptr  , mp_size_t  , mp_srcptr  ,
                            mp_size_t  , mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern mp_size_t __gmpn_powm_sec_itch(mp_size_t  , mp_size_t  , mp_size_t  ) ;
extern void __gmpn_tabselect(mp_limb_t volatile   * , mp_limb_t volatile   * ,
                             mp_size_t  , mp_size_t  , mp_size_t  ) ;
extern void __gmpn_redc_1_sec(mp_ptr  , mp_ptr  , mp_srcptr  , mp_size_t  ,
                              mp_limb_t  ) ;
extern mp_limb_t __gmpn_addcnd_n(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                 mp_size_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_subcnd_n(mp_ptr  , mp_srcptr  , mp_srcptr  ,
                                 mp_size_t  , mp_limb_t  ) ;
extern void __gmpz_divexact_gcd(mpz_ptr  , mpz_srcptr  , mpz_srcptr  ) ;
extern size_t __gmpz_inp_str_nowhite(mpz_ptr  , FILE * , int  , int  , size_t  ) ;
extern int __gmpn_divisible_p(mp_srcptr  , mp_size_t  , mp_srcptr  , mp_size_t  )  __attribute__((__pure__)) ;
extern mp_size_t __gmpn_rootrem(mp_ptr  , mp_ptr  , mp_srcptr  , mp_size_t  ,
                                mp_limb_t  ) ;
extern mp_limb_t const   __gmp_fib_table[] ;
extern void __gmp_init_primesieve(gmp_primesieve_t * ) ;
extern unsigned long __gmp_nextprime(gmp_primesieve_t * ) ;
extern void __gmp_assert_header(char const   * , int  ) ;
extern  __attribute__((__noreturn__)) void __gmp_assert_fail(char const   * ,
                                                             int  ,
                                                             char const   * ) ;
extern mp_limb_t __gmpn_trialdiv(mp_srcptr  , mp_size_t  , mp_size_t  , int * ) ;
extern mp_bitcnt_t __gmpn_remove(mp_ptr  , mp_size_t * , mp_ptr  , mp_size_t  ,
                                 mp_ptr  , mp_size_t  , mp_bitcnt_t  ) ;
extern struct bases  const  __gmpn_bases[257] ;
extern mp_limb_t __gmpn_invert_limb(mp_limb_t  )  __attribute__((__const__)) ;
extern mp_limb_t __gmpn_preinv_divrem_1(mp_ptr  , mp_size_t  , mp_srcptr  ,
                                        mp_size_t  , mp_limb_t  , mp_limb_t  ,
                                        int  ) ;
extern mp_limb_t __gmpn_mod_34lsub1(mp_srcptr  , mp_size_t  )  __attribute__((__pure__)) ;
extern void __gmpn_divexact_1(mp_ptr  , mp_srcptr  , mp_size_t  , mp_limb_t  ) ;
extern mp_limb_t __gmpn_modexact_1c_odd(mp_srcptr  , mp_size_t  , mp_limb_t  ,
                                        mp_limb_t  )  __attribute__((__pure__)) ;
extern mp_limb_t __gmpn_modexact_1_odd(mp_srcptr  , mp_size_t  , mp_limb_t  )  __attribute__((__pure__)) ;
extern unsigned char const   __gmp_binvert_limb_table[128] ;
extern int __gmp_extract_double(mp_ptr  , double  ) ;
extern double __gmpn_get_d(mp_srcptr  , mp_size_t  , mp_size_t  , long  )  __attribute__((__pure__)) ;
extern unsigned char const   __gmp_digit_value_tab[] ;
extern int __gmp_junk ;
extern int const   __gmp_0 ;
extern  __attribute__((__noreturn__)) void __gmp_exception(int  ) ;
extern  __attribute__((__noreturn__)) void __gmp_divide_by_zero(void) ;
extern  __attribute__((__noreturn__)) void __gmp_sqrt_of_negative(void) ;
extern  __attribute__((__noreturn__)) void __gmp_invalid_operation(void) ;
extern unsigned char const   __gmp_jacobi_table[208] ;
__inline static unsigned int mpn_jacobi_init(unsigned int a , unsigned int b ,
                                             unsigned int s ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "344\n");
  fflush(_coverage_fout);
  while (1) {
    break;
  }
  fprintf(_coverage_fout, "345\n");
  fflush(_coverage_fout);
  while (1) {
    break;
  }
  fprintf(_coverage_fout, "346\n");
  fflush(_coverage_fout);
  return ((((a & 3U) << 2) + (b & 2U)) + s);
}
}
__inline static int mpn_jacobi_finish(unsigned int bits ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "347\n");
  fflush(_coverage_fout);
  while (1) {
    break;
  }
  fprintf(_coverage_fout, "348\n");
  fflush(_coverage_fout);
  return ((int )(1U - 2U * (bits & 1U)));
}
}
__inline static unsigned int mpn_jacobi_update(unsigned int bits ,
                                               unsigned int denominator ,
                                               unsigned int q ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "349\n");
  fflush(_coverage_fout);
  while (1) {
    break;
  }
  fprintf(_coverage_fout, "350\n");
  fflush(_coverage_fout);
  while (1) {
    break;
  }
  fprintf(_coverage_fout, "351\n");
  fflush(_coverage_fout);
  while (1) {
    break;
  }
  fprintf(_coverage_fout, "352\n");
  fflush(_coverage_fout);
  bits = (unsigned int )__gmp_jacobi_table[((bits << 3) + (denominator << 2)) + q];
  fprintf(_coverage_fout, "353\n");
  fflush(_coverage_fout);
  return (bits);
}
}
extern void __gmpn_matrix22_mul(mp_ptr  , mp_ptr  , mp_ptr  , mp_ptr  ,
                                mp_size_t  , mp_srcptr  , mp_srcptr  ,
                                mp_srcptr  , mp_srcptr  , mp_size_t  , mp_ptr  ) ;
extern void __gmpn_matrix22_mul_strassen(mp_ptr  , mp_ptr  , mp_ptr  , mp_ptr  ,
                                         mp_size_t  , mp_srcptr  , mp_srcptr  ,
                                         mp_srcptr  , mp_srcptr  , mp_size_t  ,
                                         mp_ptr  ) ;
extern mp_size_t __gmpn_matrix22_mul_itch(mp_size_t  , mp_size_t  ) ;
extern int __gmpn_hgcd2(mp_limb_t  , mp_limb_t  , mp_limb_t  , mp_limb_t  ,
                        struct hgcd_matrix1 * ) ;
extern mp_size_t __gmpn_hgcd_mul_matrix1_vector(struct hgcd_matrix1  const  * ,
                                                mp_ptr  , mp_srcptr  , mp_ptr  ,
                                                mp_size_t  ) ;
extern mp_size_t __gmpn_matrix22_mul1_inverse_vector(struct hgcd_matrix1  const  * ,
                                                     mp_ptr  , mp_srcptr  ,
                                                     mp_ptr  , mp_size_t  ) ;
extern void __gmpn_hgcd_matrix_init(struct hgcd_matrix * , mp_size_t  , mp_ptr  ) ;
extern void __gmpn_hgcd_matrix_mul(struct hgcd_matrix * ,
                                   struct hgcd_matrix  const  * , mp_ptr  ) ;
extern mp_size_t __gmpn_hgcd_matrix_adjust(struct hgcd_matrix * , mp_size_t  ,
                                           mp_ptr  , mp_ptr  , mp_size_t  ,
                                           mp_ptr  ) ;
extern mp_size_t __gmpn_hgcd_itch(mp_size_t  ) ;
extern mp_size_t __gmpn_hgcd(mp_ptr  , mp_ptr  , mp_size_t  ,
                             struct hgcd_matrix * , mp_ptr  ) ;
extern mp_size_t __gmpn_gcd_subdiv_step(mp_ptr  , mp_ptr  , mp_size_t  ,
                                        gcd_subdiv_step_hook * , void * ,
                                        mp_ptr  ) ;
extern gcd_subdiv_step_hook __gmpn_gcdext_hook ;
extern mp_size_t __gmpn_gcdext_lehmer_n(mp_ptr  , mp_ptr  , mp_size_t * ,
                                        mp_ptr  , mp_ptr  , mp_size_t  ,
                                        mp_ptr  ) ;
extern mp_size_t __gmpn_dc_set_str(mp_ptr  , unsigned char const   * , size_t  ,
                                   powers_t const   * , mp_ptr  ) ;
extern mp_size_t __gmpn_bc_set_str(mp_ptr  , unsigned char const   * , size_t  ,
                                   int  ) ;
extern void __gmpn_set_str_compute_powtab(powers_t * , mp_ptr  , mp_size_t  ,
                                          int  ) ;
extern mp_size_t __gmp_default_fp_limb_precision ;
extern struct gmp_doscan_funs_t  const  __gmp_fscanf_funs ;
extern struct gmp_doscan_funs_t  const  __gmp_sscanf_funs ;
extern void __gmpn_cpuvec_init(void) ;
extern mp_limb_t __gmpn_add_nc(mp_ptr  , mp_srcptr  , mp_srcptr  , mp_size_t  ,
                               mp_limb_t  ) ;
extern mp_limb_t __gmpn_sub_nc(mp_ptr  , mp_srcptr  , mp_srcptr  , mp_size_t  ,
                               mp_limb_t  ) ;
__inline static int mpn_zero_p(mp_srcptr ap , mp_size_t n ) 
{ mp_size_t i ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "360\n");
  fflush(_coverage_fout);
  i = n - 1L;
  fprintf(_coverage_fout, "361\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "357\n");
    fflush(_coverage_fout);
    if (i >= 0L) {
      fprintf(_coverage_fout, "354\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "358\n");
    fflush(_coverage_fout);
    if (*(ap + i) != 0UL) {
      fprintf(_coverage_fout, "355\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "356\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "359\n");
    fflush(_coverage_fout);
    i --;
  }
  fprintf(_coverage_fout, "362\n");
  fflush(_coverage_fout);
  return (1);
}
}
__inline static mp_size_t mpn_toom6h_mul_itch(mp_size_t an , mp_size_t bn ) 
{ mp_size_t estimatedN ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "363\n");
  fflush(_coverage_fout);
  estimatedN = (long )((unsigned long )(an + bn) / 10UL + 1UL);
  fprintf(_coverage_fout, "364\n");
  fflush(_coverage_fout);
  return ((estimatedN * 6L - 252L) * 2L + 788L);
}
}
__inline static mp_size_t mpn_toom8h_mul_itch(mp_size_t an , mp_size_t bn ) 
{ mp_size_t estimatedN ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "367\n");
  fflush(_coverage_fout);
  estimatedN = (long )((unsigned long )(an + bn) / 14UL + 1UL);
  fprintf(_coverage_fout, "368\n");
  fflush(_coverage_fout);
  if ((5715 >> 3) + 192 > 1046) {
    fprintf(_coverage_fout, "365\n");
    fflush(_coverage_fout);
    tmp = (5715 >> 3) + 192;
  } else {
    fprintf(_coverage_fout, "366\n");
    fflush(_coverage_fout);
    tmp = 1046;
  }
  fprintf(_coverage_fout, "369\n");
  fflush(_coverage_fout);
  return ((((estimatedN * 8L) * 15L >> 3) - (mp_size_t )(5715 >> 3)) + (mp_size_t )tmp);
}
}
__inline static mp_size_t mpn_toom32_mul_itch(mp_size_t an , mp_size_t bn ) 
{ mp_size_t n ;
  unsigned long tmp ;
  mp_size_t itch ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "372\n");
  fflush(_coverage_fout);
  if (2L * an >= 3L * bn) {
    fprintf(_coverage_fout, "370\n");
    fflush(_coverage_fout);
    tmp = (unsigned long )(an - 1L) / 3UL;
  } else {
    fprintf(_coverage_fout, "371\n");
    fflush(_coverage_fout);
    tmp = (unsigned long )((bn - 1L) >> 1);
  }
  fprintf(_coverage_fout, "373\n");
  fflush(_coverage_fout);
  n = (mp_size_t )(1UL + tmp);
  fprintf(_coverage_fout, "374\n");
  fflush(_coverage_fout);
  itch = 2L * n + 1L;
  fprintf(_coverage_fout, "375\n");
  fflush(_coverage_fout);
  return (itch);
}
}
__inline static mp_size_t mpn_toom42_mul_itch(mp_size_t an , mp_size_t bn ) 
{ mp_size_t n ;
  mp_size_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "378\n");
  fflush(_coverage_fout);
  if (an >= 2L * bn) {
    fprintf(_coverage_fout, "376\n");
    fflush(_coverage_fout);
    tmp = (an + 3L) >> 2;
  } else {
    fprintf(_coverage_fout, "377\n");
    fflush(_coverage_fout);
    tmp = (bn + 1L) >> 1;
  }
  fprintf(_coverage_fout, "379\n");
  fflush(_coverage_fout);
  n = tmp;
  fprintf(_coverage_fout, "380\n");
  fflush(_coverage_fout);
  return (6L * n + 3L);
}
}
__inline static mp_size_t mpn_toom43_mul_itch(mp_size_t an , mp_size_t bn ) 
{ mp_size_t n ;
  unsigned long tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "383\n");
  fflush(_coverage_fout);
  if (3L * an >= 4L * bn) {
    fprintf(_coverage_fout, "381\n");
    fflush(_coverage_fout);
    tmp = (unsigned long )((an - 1L) >> 2);
  } else {
    fprintf(_coverage_fout, "382\n");
    fflush(_coverage_fout);
    tmp = (unsigned long )(bn - 1L) / 3UL;
  }
  fprintf(_coverage_fout, "384\n");
  fflush(_coverage_fout);
  n = (mp_size_t )(1UL + tmp);
  fprintf(_coverage_fout, "385\n");
  fflush(_coverage_fout);
  return (6L * n + 4L);
}
}
__inline static mp_size_t mpn_toom52_mul_itch(mp_size_t an , mp_size_t bn ) 
{ mp_size_t n ;
  unsigned long tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "388\n");
  fflush(_coverage_fout);
  if (2L * an >= 5L * bn) {
    fprintf(_coverage_fout, "386\n");
    fflush(_coverage_fout);
    tmp = (unsigned long )(an - 1L) / 5UL;
  } else {
    fprintf(_coverage_fout, "387\n");
    fflush(_coverage_fout);
    tmp = (unsigned long )((bn - 1L) >> 1);
  }
  fprintf(_coverage_fout, "389\n");
  fflush(_coverage_fout);
  n = (mp_size_t )(1UL + tmp);
  fprintf(_coverage_fout, "390\n");
  fflush(_coverage_fout);
  return (6L * n + 4L);
}
}
__inline static mp_size_t mpn_toom53_mul_itch(mp_size_t an , mp_size_t bn ) 
{ mp_size_t n ;
  unsigned long tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "393\n");
  fflush(_coverage_fout);
  if (3L * an >= 5L * bn) {
    fprintf(_coverage_fout, "391\n");
    fflush(_coverage_fout);
    tmp = (unsigned long )(an - 1L) / 5UL;
  } else {
    fprintf(_coverage_fout, "392\n");
    fflush(_coverage_fout);
    tmp = (unsigned long )(bn - 1L) / 3UL;
  }
  fprintf(_coverage_fout, "394\n");
  fflush(_coverage_fout);
  n = (mp_size_t )(1UL + tmp);
  fprintf(_coverage_fout, "395\n");
  fflush(_coverage_fout);
  return (10L * n + 10L);
}
}
__inline static mp_size_t mpn_toom62_mul_itch(mp_size_t an , mp_size_t bn ) 
{ mp_size_t n ;
  unsigned long tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "398\n");
  fflush(_coverage_fout);
  if (an >= 3L * bn) {
    fprintf(_coverage_fout, "396\n");
    fflush(_coverage_fout);
    tmp = (unsigned long )(an - 1L) / 6UL;
  } else {
    fprintf(_coverage_fout, "397\n");
    fflush(_coverage_fout);
    tmp = (unsigned long )((bn - 1L) >> 1);
  }
  fprintf(_coverage_fout, "399\n");
  fflush(_coverage_fout);
  n = (mp_size_t )(1UL + tmp);
  fprintf(_coverage_fout, "400\n");
  fflush(_coverage_fout);
  return (10L * n + 10L);
}
}
__inline static mp_size_t mpn_toom63_mul_itch(mp_size_t an , mp_size_t bn ) 
{ mp_size_t n ;
  unsigned long tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "403\n");
  fflush(_coverage_fout);
  if (an >= 2L * bn) {
    fprintf(_coverage_fout, "401\n");
    fflush(_coverage_fout);
    tmp = (unsigned long )(an - 1L) / 6UL;
  } else {
    fprintf(_coverage_fout, "402\n");
    fflush(_coverage_fout);
    tmp = (unsigned long )(bn - 1L) / 3UL;
  }
  fprintf(_coverage_fout, "404\n");
  fflush(_coverage_fout);
  n = (mp_size_t )(1UL + tmp);
  fprintf(_coverage_fout, "405\n");
  fflush(_coverage_fout);
  return (9L * n + 3L);
}
}
void __gmpz_gcdext(mpz_ptr g , mpz_ptr s , mpz_ptr t , mpz_srcptr a ,
                   mpz_srcptr b ) 
{ mp_size_t asize ;
  mp_size_t bsize ;
  mp_srcptr ap ;
  mp_srcptr bp ;
  mp_ptr tmp_ap ;
  mp_ptr tmp_bp ;
  mp_size_t gsize ;
  mp_size_t ssize ;
  mp_size_t tmp_ssize ;
  mp_ptr gp ;
  mp_ptr sp ;
  mp_ptr tmp_gp ;
  mp_ptr tmp_sp ;
  __mpz_struct stmp ;
  __mpz_struct gtmp ;
  struct tmp_reentrant_t *__tmp_marker ;
  mpz_srcptr __mpz_srcptr_swap__tmp ;
  mp_srcptr __mp_srcptr_swap__tmp ;
  mp_size_t __mp_size_t_swap__tmp ;
  mpz_ptr __mpz_ptr_swap__tmp ;
  int __attribute__((__gnu_inline__))  tmp ;
  long tmp___0 ;
  void *tmp___1 ;
  void *tmp___2 ;
  void *tmp___3 ;
  long tmp___4 ;
  long tmp___5 ;
  void *tmp___6 ;
  void *tmp___7 ;
  void *tmp___8 ;
  long tmp___9 ;
  long tmp___10 ;
  void *tmp___11 ;
  void *tmp___12 ;
  void *tmp___13 ;
  long tmp___14 ;
  long tmp___15 ;
  void *tmp___16 ;
  void *tmp___17 ;
  void *tmp___18 ;
  long tmp___19 ;
  mpz_t x ;
  mpz_ptr __x ;
  long tmp___20 ;
  void *tmp___21 ;
  void *tmp___22 ;
  void *tmp___23 ;
  long tmp___24 ;
  long tmp___25 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/gmp-bug-14166-14167/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "523\n");
  fflush(_coverage_fout);
  if (a->_mp_size >= 0) {
    fprintf(_coverage_fout, "406\n");
    fflush(_coverage_fout);
    asize = (long )a->_mp_size;
  } else {
    fprintf(_coverage_fout, "407\n");
    fflush(_coverage_fout);
    asize = (long )(- a->_mp_size);
  }
  fprintf(_coverage_fout, "524\n");
  fflush(_coverage_fout);
  if (b->_mp_size >= 0) {
    fprintf(_coverage_fout, "408\n");
    fflush(_coverage_fout);
    bsize = (long )b->_mp_size;
  } else {
    fprintf(_coverage_fout, "409\n");
    fflush(_coverage_fout);
    bsize = (long )(- b->_mp_size);
  }
  fprintf(_coverage_fout, "525\n");
  fflush(_coverage_fout);
  ap = (mp_limb_t const   *)a->_mp_d;
  fprintf(_coverage_fout, "526\n");
  fflush(_coverage_fout);
  bp = (mp_limb_t const   *)b->_mp_d;
  fprintf(_coverage_fout, "527\n");
  fflush(_coverage_fout);
  if (asize < bsize) {
    goto _L;
  } else {
    fprintf(_coverage_fout, "431\n");
    fflush(_coverage_fout);
    if (asize == bsize) {
      fprintf(_coverage_fout, "428\n");
      fflush(_coverage_fout);
      tmp = __gmpn_cmp(ap, bp, asize);
      fprintf(_coverage_fout, "429\n");
      fflush(_coverage_fout);
      if (tmp < (int __attribute__((__gnu_inline__))  )0) {
        fprintf(_coverage_fout, "424\n");
        fflush(_coverage_fout);
        _L: /* CIL Label */ 
        while (1) {
          fprintf(_coverage_fout, "410\n");
          fflush(_coverage_fout);
          __mpz_srcptr_swap__tmp = a;
          fprintf(_coverage_fout, "411\n");
          fflush(_coverage_fout);
          a = b;
          fprintf(_coverage_fout, "412\n");
          fflush(_coverage_fout);
          b = __mpz_srcptr_swap__tmp;
          break;
        }
        fprintf(_coverage_fout, "425\n");
        fflush(_coverage_fout);
        while (1) {
          fprintf(_coverage_fout, "419\n");
          fflush(_coverage_fout);
          while (1) {
            fprintf(_coverage_fout, "413\n");
            fflush(_coverage_fout);
            __mp_srcptr_swap__tmp = ap;
            fprintf(_coverage_fout, "414\n");
            fflush(_coverage_fout);
            ap = bp;
            fprintf(_coverage_fout, "415\n");
            fflush(_coverage_fout);
            bp = __mp_srcptr_swap__tmp;
            break;
          }
          fprintf(_coverage_fout, "420\n");
          fflush(_coverage_fout);
          while (1) {
            fprintf(_coverage_fout, "416\n");
            fflush(_coverage_fout);
            __mp_size_t_swap__tmp = asize;
            fprintf(_coverage_fout, "417\n");
            fflush(_coverage_fout);
            asize = bsize;
            fprintf(_coverage_fout, "418\n");
            fflush(_coverage_fout);
            bsize = __mp_size_t_swap__tmp;
            break;
          }
          break;
        }
        fprintf(_coverage_fout, "426\n");
        fflush(_coverage_fout);
        while (1) {
          fprintf(_coverage_fout, "421\n");
          fflush(_coverage_fout);
          __mpz_ptr_swap__tmp = s;
          fprintf(_coverage_fout, "422\n");
          fflush(_coverage_fout);
          s = t;
          fprintf(_coverage_fout, "423\n");
          fflush(_coverage_fout);
          t = __mpz_ptr_swap__tmp;
          break;
        }
      } else {
        fprintf(_coverage_fout, "427\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "430\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "528\n");
  fflush(_coverage_fout);
  if (bsize == 0L) {
    fprintf(_coverage_fout, "446\n");
    fflush(_coverage_fout);
    if (a->_mp_size >= 0) {
      fprintf(_coverage_fout, "432\n");
      fflush(_coverage_fout);
      ssize = 1L;
    } else {
      fprintf(_coverage_fout, "433\n");
      fflush(_coverage_fout);
      ssize = -1L;
    }
    fprintf(_coverage_fout, "447\n");
    fflush(_coverage_fout);
    if ((mp_size_t )g->_mp_alloc < asize) {
      fprintf(_coverage_fout, "434\n");
      fflush(_coverage_fout);
      __gmpz_realloc(g, asize);
    } else {
      fprintf(_coverage_fout, "435\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "448\n");
    fflush(_coverage_fout);
    gp = g->_mp_d;
    fprintf(_coverage_fout, "449\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "439\n");
      fflush(_coverage_fout);
      while (1) {
        break;
      }
      fprintf(_coverage_fout, "440\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "436\n");
        fflush(_coverage_fout);
        while (1) {
          break;
        }
        fprintf(_coverage_fout, "437\n");
        fflush(_coverage_fout);
        while (1) {
          break;
        }
        fprintf(_coverage_fout, "438\n");
        fflush(_coverage_fout);
        __gmpn_copyi(gp, ap, asize);
        break;
      }
      break;
    }
    fprintf(_coverage_fout, "450\n");
    fflush(_coverage_fout);
    g->_mp_size = (int )asize;
    fprintf(_coverage_fout, "451\n");
    fflush(_coverage_fout);
    if ((unsigned int )t != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "441\n");
      fflush(_coverage_fout);
      t->_mp_size = 0;
    } else {
      fprintf(_coverage_fout, "442\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "452\n");
    fflush(_coverage_fout);
    if ((unsigned int )s != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "443\n");
      fflush(_coverage_fout);
      s->_mp_size = (int )ssize;
      fprintf(_coverage_fout, "444\n");
      fflush(_coverage_fout);
      *(s->_mp_d + 0) = 1UL;
    } else {
      fprintf(_coverage_fout, "445\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "453\n");
    fflush(_coverage_fout);
    return;
  } else {
    fprintf(_coverage_fout, "454\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "529\n");
  fflush(_coverage_fout);
  __tmp_marker = (struct tmp_reentrant_t *)0;
  fprintf(_coverage_fout, "530\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )(((unsigned long )asize * (unsigned long )sizeof(mp_limb_t ) < 65536UL) != 0),
                             1L);
  fprintf(_coverage_fout, "531\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "455\n");
    fflush(_coverage_fout);
    tmp___1 = __builtin_alloca((unsigned int )((unsigned long )asize * (unsigned long )sizeof(mp_limb_t )));
    fprintf(_coverage_fout, "456\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___1;
  } else {
    fprintf(_coverage_fout, "457\n");
    fflush(_coverage_fout);
    tmp___2 = __gmp_tmp_reentrant_alloc(& __tmp_marker,
                                        (unsigned int )((unsigned long )asize * (unsigned long )sizeof(mp_limb_t )));
    fprintf(_coverage_fout, "458\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___2;
  }
  fprintf(_coverage_fout, "532\n");
  fflush(_coverage_fout);
  tmp_ap = (mp_limb_t *)tmp___3;
  fprintf(_coverage_fout, "533\n");
  fflush(_coverage_fout);
  tmp___9 = __builtin_expect((long )(((unsigned long )bsize * (unsigned long )sizeof(mp_limb_t ) < 65536UL) != 0),
                             1L);
  fprintf(_coverage_fout, "534\n");
  fflush(_coverage_fout);
  if (tmp___9) {
    fprintf(_coverage_fout, "459\n");
    fflush(_coverage_fout);
    tmp___6 = __builtin_alloca((unsigned int )((unsigned long )bsize * (unsigned long )sizeof(mp_limb_t )));
    fprintf(_coverage_fout, "460\n");
    fflush(_coverage_fout);
    tmp___8 = tmp___6;
  } else {
    fprintf(_coverage_fout, "461\n");
    fflush(_coverage_fout);
    tmp___7 = __gmp_tmp_reentrant_alloc(& __tmp_marker,
                                        (unsigned int )((unsigned long )bsize * (unsigned long )sizeof(mp_limb_t )));
    fprintf(_coverage_fout, "462\n");
    fflush(_coverage_fout);
    tmp___8 = tmp___7;
  }
  fprintf(_coverage_fout, "535\n");
  fflush(_coverage_fout);
  tmp_bp = (mp_limb_t *)tmp___8;
  fprintf(_coverage_fout, "536\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "466\n");
    fflush(_coverage_fout);
    while (1) {
      break;
    }
    fprintf(_coverage_fout, "467\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "463\n");
      fflush(_coverage_fout);
      while (1) {
        break;
      }
      fprintf(_coverage_fout, "464\n");
      fflush(_coverage_fout);
      while (1) {
        break;
      }
      fprintf(_coverage_fout, "465\n");
      fflush(_coverage_fout);
      __gmpn_copyi(tmp_ap, ap, asize);
      break;
    }
    break;
  }
  fprintf(_coverage_fout, "537\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "471\n");
    fflush(_coverage_fout);
    while (1) {
      break;
    }
    fprintf(_coverage_fout, "472\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "468\n");
      fflush(_coverage_fout);
      while (1) {
        break;
      }
      fprintf(_coverage_fout, "469\n");
      fflush(_coverage_fout);
      while (1) {
        break;
      }
      fprintf(_coverage_fout, "470\n");
      fflush(_coverage_fout);
      __gmpn_copyi(tmp_bp, bp, bsize);
      break;
    }
    break;
  }
  fprintf(_coverage_fout, "538\n");
  fflush(_coverage_fout);
  tmp___14 = __builtin_expect((long )(((unsigned long )bsize * (unsigned long )sizeof(mp_limb_t ) < 65536UL) != 0),
                              1L);
  fprintf(_coverage_fout, "539\n");
  fflush(_coverage_fout);
  if (tmp___14) {
    fprintf(_coverage_fout, "473\n");
    fflush(_coverage_fout);
    tmp___11 = __builtin_alloca((unsigned int )((unsigned long )bsize * (unsigned long )sizeof(mp_limb_t )));
    fprintf(_coverage_fout, "474\n");
    fflush(_coverage_fout);
    tmp___13 = tmp___11;
  } else {
    fprintf(_coverage_fout, "475\n");
    fflush(_coverage_fout);
    tmp___12 = __gmp_tmp_reentrant_alloc(& __tmp_marker,
                                         (unsigned int )((unsigned long )bsize * (unsigned long )sizeof(mp_limb_t )));
    fprintf(_coverage_fout, "476\n");
    fflush(_coverage_fout);
    tmp___13 = tmp___12;
  }
  fprintf(_coverage_fout, "540\n");
  fflush(_coverage_fout);
  tmp_gp = (mp_limb_t *)tmp___13;
  fprintf(_coverage_fout, "541\n");
  fflush(_coverage_fout);
  tmp___19 = __builtin_expect((long )(((unsigned long )bsize * (unsigned long )sizeof(mp_limb_t ) < 65536UL) != 0),
                              1L);
  fprintf(_coverage_fout, "542\n");
  fflush(_coverage_fout);
  if (tmp___19) {
    fprintf(_coverage_fout, "477\n");
    fflush(_coverage_fout);
    tmp___16 = __builtin_alloca((unsigned int )((unsigned long )bsize * (unsigned long )sizeof(mp_limb_t )));
    fprintf(_coverage_fout, "478\n");
    fflush(_coverage_fout);
    tmp___18 = tmp___16;
  } else {
    fprintf(_coverage_fout, "479\n");
    fflush(_coverage_fout);
    tmp___17 = __gmp_tmp_reentrant_alloc(& __tmp_marker,
                                         (unsigned int )((unsigned long )bsize * (unsigned long )sizeof(mp_limb_t )));
    fprintf(_coverage_fout, "480\n");
    fflush(_coverage_fout);
    tmp___18 = tmp___17;
  }
  fprintf(_coverage_fout, "543\n");
  fflush(_coverage_fout);
  tmp_sp = (mp_limb_t *)tmp___18;
  fprintf(_coverage_fout, "544\n");
  fflush(_coverage_fout);
  gsize = __gmpn_gcdext(tmp_gp, tmp_sp, & tmp_ssize, tmp_ap, asize, tmp_bp,
                        bsize);
  fprintf(_coverage_fout, "545\n");
  fflush(_coverage_fout);
  if (tmp_ssize >= 0L) {
    fprintf(_coverage_fout, "481\n");
    fflush(_coverage_fout);
    ssize = tmp_ssize;
  } else {
    fprintf(_coverage_fout, "482\n");
    fflush(_coverage_fout);
    ssize = - tmp_ssize;
  }
  fprintf(_coverage_fout, "546\n");
  fflush(_coverage_fout);
  gtmp._mp_d = tmp_gp;
  fprintf(_coverage_fout, "547\n");
  fflush(_coverage_fout);
  gtmp._mp_size = (int )gsize;
  fprintf(_coverage_fout, "548\n");
  fflush(_coverage_fout);
  stmp._mp_d = tmp_sp;
  fprintf(_coverage_fout, "549\n");
  fflush(_coverage_fout);
  if ((tmp_ssize ^ (long )a->_mp_size) >= 0L) {
    fprintf(_coverage_fout, "483\n");
    fflush(_coverage_fout);
    stmp._mp_size = (int )ssize;
  } else {
    fprintf(_coverage_fout, "484\n");
    fflush(_coverage_fout);
    stmp._mp_size = (int )(- ssize);
  }
  fprintf(_coverage_fout, "550\n");
  fflush(_coverage_fout);
  if ((unsigned int )t != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "495\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "489\n");
      fflush(_coverage_fout);
      __x = x;
      fprintf(_coverage_fout, "490\n");
      fflush(_coverage_fout);
      while (1) {
        break;
      }
      fprintf(_coverage_fout, "491\n");
      fflush(_coverage_fout);
      __x->_mp_alloc = (int )((ssize + asize) + 1L);
      fprintf(_coverage_fout, "492\n");
      fflush(_coverage_fout);
      tmp___24 = __builtin_expect((long )(((unsigned long )((ssize + asize) + 1L) * (unsigned long )sizeof(mp_limb_t ) < 65536UL) != 0),
                                  1L);
      fprintf(_coverage_fout, "493\n");
      fflush(_coverage_fout);
      if (tmp___24) {
        fprintf(_coverage_fout, "485\n");
        fflush(_coverage_fout);
        tmp___21 = __builtin_alloca((unsigned int )((unsigned long )((ssize + asize) + 1L) * (unsigned long )sizeof(mp_limb_t )));
        fprintf(_coverage_fout, "486\n");
        fflush(_coverage_fout);
        tmp___23 = tmp___21;
      } else {
        fprintf(_coverage_fout, "487\n");
        fflush(_coverage_fout);
        tmp___22 = __gmp_tmp_reentrant_alloc(& __tmp_marker,
                                             (unsigned int )((unsigned long )((ssize + asize) + 1L) * (unsigned long )sizeof(mp_limb_t )));
        fprintf(_coverage_fout, "488\n");
        fflush(_coverage_fout);
        tmp___23 = tmp___22;
      }
      fprintf(_coverage_fout, "494\n");
      fflush(_coverage_fout);
      __x->_mp_d = (mp_limb_t *)tmp___23;
      break;
    }
    fprintf(_coverage_fout, "496\n");
    fflush(_coverage_fout);
    __gmpz_mul(x, (__mpz_struct const   *)(& stmp), a);
    fprintf(_coverage_fout, "497\n");
    fflush(_coverage_fout);
    __gmpz_sub(x, (__mpz_struct const   *)(& gtmp), (__mpz_struct const   *)(x));
    fprintf(_coverage_fout, "498\n");
    fflush(_coverage_fout);
    __gmpz_divexact(t, (__mpz_struct const   *)(x), b);
  } else {
    fprintf(_coverage_fout, "499\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "551\n");
  fflush(_coverage_fout);
  if ((unsigned int )s != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "507\n");
    fflush(_coverage_fout);
    if ((mp_size_t )s->_mp_alloc < ssize) {
      fprintf(_coverage_fout, "500\n");
      fflush(_coverage_fout);
      __gmpz_realloc(s, ssize);
    } else {
      fprintf(_coverage_fout, "501\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "508\n");
    fflush(_coverage_fout);
    sp = s->_mp_d;
    fprintf(_coverage_fout, "509\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "505\n");
      fflush(_coverage_fout);
      while (1) {
        break;
      }
      fprintf(_coverage_fout, "506\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "502\n");
        fflush(_coverage_fout);
        while (1) {
          break;
        }
        fprintf(_coverage_fout, "503\n");
        fflush(_coverage_fout);
        while (1) {
          break;
        }
        fprintf(_coverage_fout, "504\n");
        fflush(_coverage_fout);
        __gmpn_copyi(sp, (mp_limb_t const   *)tmp_sp, ssize);
        break;
      }
      break;
    }
    fprintf(_coverage_fout, "510\n");
    fflush(_coverage_fout);
    s->_mp_size = stmp._mp_size;
  } else {
    fprintf(_coverage_fout, "511\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "552\n");
  fflush(_coverage_fout);
  if ((mp_size_t )g->_mp_alloc < gsize) {
    fprintf(_coverage_fout, "512\n");
    fflush(_coverage_fout);
    __gmpz_realloc(g, gsize);
  } else {
    fprintf(_coverage_fout, "513\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "553\n");
  fflush(_coverage_fout);
  gp = g->_mp_d;
  fprintf(_coverage_fout, "554\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "517\n");
    fflush(_coverage_fout);
    while (1) {
      break;
    }
    fprintf(_coverage_fout, "518\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "514\n");
      fflush(_coverage_fout);
      while (1) {
        break;
      }
      fprintf(_coverage_fout, "515\n");
      fflush(_coverage_fout);
      while (1) {
        break;
      }
      fprintf(_coverage_fout, "516\n");
      fflush(_coverage_fout);
      __gmpn_copyi(gp, (mp_limb_t const   *)tmp_gp, gsize);
      break;
    }
    break;
  }
  fprintf(_coverage_fout, "555\n");
  fflush(_coverage_fout);
  g->_mp_size = (int )gsize;
  fprintf(_coverage_fout, "556\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "521\n");
    fflush(_coverage_fout);
    tmp___25 = __builtin_expect((long )(((unsigned int )__tmp_marker != (unsigned int )((struct tmp_reentrant_t *)0)) != 0),
                                0L);
    fprintf(_coverage_fout, "522\n");
    fflush(_coverage_fout);
    if (tmp___25) {
      fprintf(_coverage_fout, "519\n");
      fflush(_coverage_fout);
      __gmp_tmp_reentrant_free(__tmp_marker);
    } else {
      fprintf(_coverage_fout, "520\n");
      fflush(_coverage_fout);

    }
    break;
  }
  fprintf(_coverage_fout, "557\n");
  fflush(_coverage_fout);
  return;
}
}
