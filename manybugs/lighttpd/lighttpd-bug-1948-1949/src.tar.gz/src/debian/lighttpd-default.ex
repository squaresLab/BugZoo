# Defaults for lighttpd initscript
# sourced by /etc/init.d/lighttpd
# installed at /etc/default/lighttpd by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
