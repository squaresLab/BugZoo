#
# Regular cron jobs for the lighttpd package
#
0 4	* * *	root	lighttpd_maintenance
