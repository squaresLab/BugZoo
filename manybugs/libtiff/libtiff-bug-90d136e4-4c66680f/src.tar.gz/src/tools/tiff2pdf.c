void *_coverage_fout ;
typedef unsigned int size_t;
typedef unsigned char __u_char;
typedef unsigned short __u_short;
typedef unsigned int __u_int;
typedef unsigned long __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;
typedef long long __quad_t;
typedef unsigned long long __u_quad_t;
typedef __u_quad_t __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef __u_quad_t __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long __off_t;
typedef __quad_t __off64_t;
typedef int __pid_t;
struct __anonstruct___fsid_t_1 {
   int __val[2] ;
};
typedef struct __anonstruct___fsid_t_1 __fsid_t;
typedef long __clock_t;
typedef unsigned long __rlim_t;
typedef __u_quad_t __rlim64_t;
typedef unsigned int __id_t;
typedef long __time_t;
typedef unsigned int __useconds_t;
typedef long __suseconds_t;
typedef int __daddr_t;
typedef long __swblk_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void *__timer_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef __quad_t __blkcnt64_t;
typedef unsigned long __fsblkcnt_t;
typedef __u_quad_t __fsblkcnt64_t;
typedef unsigned long __fsfilcnt_t;
typedef __u_quad_t __fsfilcnt64_t;
typedef int __ssize_t;
typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;
typedef int __intptr_t;
typedef unsigned int __socklen_t;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_3 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_2 {
   int __count ;
   union __anonunion___value_3 __value ;
};
typedef struct __anonstruct___mbstate_t_2 __mbstate_t;
struct __anonstruct__G_fpos_t_4 {
   __off_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos_t_4 _G_fpos_t;
struct __anonstruct__G_fpos64_t_5 {
   __off64_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos64_t_5 _G_fpos64_t;
typedef short _G_int16_t;
typedef int _G_int32_t;
typedef unsigned short _G_uint16_t;
typedef unsigned int _G_uint32_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_jump_t;
struct _IO_jump_t;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
enum __codecvt_result {
    __codecvt_ok = 0,
    __codecvt_partial = 1,
    __codecvt_error = 2,
    __codecvt_noconv = 3
} ;
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15U * sizeof(int ) - 4U * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
struct _IO_FILE_plus;
struct _IO_FILE_plus;
typedef __ssize_t __io_read_fn(void *__cookie , char *__buf , size_t __nbytes );
typedef __ssize_t __io_write_fn(void *__cookie , char const   *__buf ,
                                size_t __n );
typedef int __io_seek_fn(void *__cookie , __off64_t *__pos , int __w );
typedef int __io_close_fn(void *__cookie );
typedef __gnuc_va_list va_list;
typedef __off64_t off_t;
typedef __ssize_t ssize_t;
typedef _G_fpos64_t fpos_t;
typedef long wchar_t;
struct __anonstruct___wait_terminated_6 {
   unsigned int __w_termsig : 7 ;
   unsigned int __w_coredump : 1 ;
   unsigned int __w_retcode : 8 ;
   unsigned int  : 16 ;
};
struct __anonstruct___wait_stopped_7 {
   unsigned int __w_stopval : 8 ;
   unsigned int __w_stopsig : 8 ;
   unsigned int  : 16 ;
};
union wait {
   int w_status ;
   struct __anonstruct___wait_terminated_6 __wait_terminated ;
   struct __anonstruct___wait_stopped_7 __wait_stopped ;
};
union __anonunion___WAIT_STATUS_8 {
   union wait *__uptr ;
   int *__iptr ;
};
typedef union __anonunion___WAIT_STATUS_8  __attribute__((__transparent_union__)) __WAIT_STATUS;
struct __anonstruct_div_t_9 {
   int quot ;
   int rem ;
};
typedef struct __anonstruct_div_t_9 div_t;
struct __anonstruct_ldiv_t_10 {
   long quot ;
   long rem ;
};
typedef struct __anonstruct_ldiv_t_10 ldiv_t;
struct __anonstruct_lldiv_t_11 {
   long long quot ;
   long long rem ;
};
typedef struct __anonstruct_lldiv_t_11 lldiv_t;
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;
typedef __loff_t loff_t;
typedef __ino64_t ino_t;
typedef __dev_t dev_t;
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __nlink_t nlink_t;
typedef __uid_t uid_t;
typedef __pid_t pid_t;
typedef __id_t id_t;
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;
typedef __key_t key_t;
typedef __clock_t clock_t;
typedef __time_t time_t;
typedef __clockid_t clockid_t;
typedef __timer_t timer_t;
typedef unsigned long ulong;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char u_int8_t;
typedef unsigned short u_int16_t;
typedef unsigned int u_int32_t;
typedef unsigned long long u_int64_t;
typedef int register_t;
typedef int __sig_atomic_t;
struct __anonstruct___sigset_t_12 {
   unsigned long __val[1024U / (8U * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_12 __sigset_t;
typedef __sigset_t sigset_t;
struct timespec {
   __time_t tv_sec ;
   long tv_nsec ;
};
struct timeval {
   __time_t tv_sec ;
   __suseconds_t tv_usec ;
};
typedef __suseconds_t suseconds_t;
typedef long __fd_mask;
struct __anonstruct_fd_set_13 {
   __fd_mask __fds_bits[1024 / (8 * (int )sizeof(__fd_mask ))] ;
};
typedef struct __anonstruct_fd_set_13 fd_set;
typedef __fd_mask fd_mask;
typedef __blksize_t blksize_t;
typedef __blkcnt64_t blkcnt_t;
typedef __fsblkcnt64_t fsblkcnt_t;
typedef __fsfilcnt64_t fsfilcnt_t;
typedef unsigned long pthread_t;
union __anonunion_pthread_attr_t_14 {
   char __size[36] ;
   long __align ;
};
typedef union __anonunion_pthread_attr_t_14 pthread_attr_t;
struct __pthread_internal_slist {
   struct __pthread_internal_slist *__next ;
};
typedef struct __pthread_internal_slist __pthread_slist_t;
union __anonunion____missing_field_name_16 {
   int __spins ;
   __pthread_slist_t __list ;
};
struct __pthread_mutex_s {
   int __lock ;
   unsigned int __count ;
   int __owner ;
   int __kind ;
   unsigned int __nusers ;
   union __anonunion____missing_field_name_16 __annonCompField1 ;
};
union __anonunion_pthread_mutex_t_15 {
   struct __pthread_mutex_s __data ;
   char __size[24] ;
   long __align ;
};
typedef union __anonunion_pthread_mutex_t_15 pthread_mutex_t;
union __anonunion_pthread_mutexattr_t_17 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_mutexattr_t_17 pthread_mutexattr_t;
struct __anonstruct___data_19 {
   int __lock ;
   unsigned int __futex ;
   unsigned long long __total_seq ;
   unsigned long long __wakeup_seq ;
   unsigned long long __woken_seq ;
   void *__mutex ;
   unsigned int __nwaiters ;
   unsigned int __broadcast_seq ;
};
union __anonunion_pthread_cond_t_18 {
   struct __anonstruct___data_19 __data ;
   char __size[48] ;
   long long __align ;
};
typedef union __anonunion_pthread_cond_t_18 pthread_cond_t;
union __anonunion_pthread_condattr_t_20 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_condattr_t_20 pthread_condattr_t;
typedef unsigned int pthread_key_t;
typedef int pthread_once_t;
struct __anonstruct___data_22 {
   int __lock ;
   unsigned int __nr_readers ;
   unsigned int __readers_wakeup ;
   unsigned int __writer_wakeup ;
   unsigned int __nr_readers_queued ;
   unsigned int __nr_writers_queued ;
   unsigned char __flags ;
   unsigned char __shared ;
   unsigned char __pad1 ;
   unsigned char __pad2 ;
   int __writer ;
};
union __anonunion_pthread_rwlock_t_21 {
   struct __anonstruct___data_22 __data ;
   char __size[32] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlock_t_21 pthread_rwlock_t;
union __anonunion_pthread_rwlockattr_t_23 {
   char __size[8] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlockattr_t_23 pthread_rwlockattr_t;
typedef int volatile   pthread_spinlock_t;
union __anonunion_pthread_barrier_t_24 {
   char __size[20] ;
   long __align ;
};
typedef union __anonunion_pthread_barrier_t_24 pthread_barrier_t;
union __anonunion_pthread_barrierattr_t_25 {
   char __size[4] ;
   int __align ;
};
typedef union __anonunion_pthread_barrierattr_t_25 pthread_barrierattr_t;
struct random_data {
   int32_t *fptr ;
   int32_t *rptr ;
   int32_t *state ;
   int rand_type ;
   int rand_deg ;
   int rand_sep ;
   int32_t *end_ptr ;
};
struct drand48_data {
   unsigned short __x[3] ;
   unsigned short __old_x[3] ;
   unsigned short __c ;
   unsigned short __init ;
   unsigned long long __a ;
};
typedef int (*__compar_fn_t)(void const   * , void const   * );
struct __locale_data;
struct __locale_struct {
   struct __locale_data *__locales[13] ;
   unsigned short const   *__ctype_b ;
   int const   *__ctype_tolower ;
   int const   *__ctype_toupper ;
   char const   *__names[13] ;
};
typedef struct __locale_struct *__locale_t;
typedef __locale_t locale_t;
enum __anonenum_26 {
    _ISupper = 256,
    _ISlower = 512,
    _ISalpha = 1024,
    _ISdigit = 2048,
    _ISxdigit = 4096,
    _ISspace = 8192,
    _ISprint = 16384,
    _ISgraph = 32768,
    _ISblank = 1,
    _IScntrl = 2,
    _ISpunct = 4,
    _ISalnum = 8
} ;
struct tm {
   int tm_sec ;
   int tm_min ;
   int tm_hour ;
   int tm_mday ;
   int tm_mon ;
   int tm_year ;
   int tm_wday ;
   int tm_yday ;
   int tm_isdst ;
   long tm_gmtoff ;
   char const   *tm_zone ;
};
struct itimerspec {
   struct timespec it_interval ;
   struct timespec it_value ;
};
struct sigevent;
struct sigevent;
typedef __useconds_t useconds_t;
typedef __intptr_t intptr_t;
typedef __socklen_t socklen_t;
enum __anonenum_27 {
    _PC_LINK_MAX = 0,
    _PC_MAX_CANON = 1,
    _PC_MAX_INPUT = 2,
    _PC_NAME_MAX = 3,
    _PC_PATH_MAX = 4,
    _PC_PIPE_BUF = 5,
    _PC_CHOWN_RESTRICTED = 6,
    _PC_NO_TRUNC = 7,
    _PC_VDISABLE = 8,
    _PC_SYNC_IO = 9,
    _PC_ASYNC_IO = 10,
    _PC_PRIO_IO = 11,
    _PC_SOCK_MAXBUF = 12,
    _PC_FILESIZEBITS = 13,
    _PC_REC_INCR_XFER_SIZE = 14,
    _PC_REC_MAX_XFER_SIZE = 15,
    _PC_REC_MIN_XFER_SIZE = 16,
    _PC_REC_XFER_ALIGN = 17,
    _PC_ALLOC_SIZE_MIN = 18,
    _PC_SYMLINK_MAX = 19,
    _PC_2_SYMLINKS = 20
} ;
enum __anonenum_28 {
    _SC_ARG_MAX = 0,
    _SC_CHILD_MAX = 1,
    _SC_CLK_TCK = 2,
    _SC_NGROUPS_MAX = 3,
    _SC_OPEN_MAX = 4,
    _SC_STREAM_MAX = 5,
    _SC_TZNAME_MAX = 6,
    _SC_JOB_CONTROL = 7,
    _SC_SAVED_IDS = 8,
    _SC_REALTIME_SIGNALS = 9,
    _SC_PRIORITY_SCHEDULING = 10,
    _SC_TIMERS = 11,
    _SC_ASYNCHRONOUS_IO = 12,
    _SC_PRIORITIZED_IO = 13,
    _SC_SYNCHRONIZED_IO = 14,
    _SC_FSYNC = 15,
    _SC_MAPPED_FILES = 16,
    _SC_MEMLOCK = 17,
    _SC_MEMLOCK_RANGE = 18,
    _SC_MEMORY_PROTECTION = 19,
    _SC_MESSAGE_PASSING = 20,
    _SC_SEMAPHORES = 21,
    _SC_SHARED_MEMORY_OBJECTS = 22,
    _SC_AIO_LISTIO_MAX = 23,
    _SC_AIO_MAX = 24,
    _SC_AIO_PRIO_DELTA_MAX = 25,
    _SC_DELAYTIMER_MAX = 26,
    _SC_MQ_OPEN_MAX = 27,
    _SC_MQ_PRIO_MAX = 28,
    _SC_VERSION = 29,
    _SC_PAGESIZE = 30,
    _SC_RTSIG_MAX = 31,
    _SC_SEM_NSEMS_MAX = 32,
    _SC_SEM_VALUE_MAX = 33,
    _SC_SIGQUEUE_MAX = 34,
    _SC_TIMER_MAX = 35,
    _SC_BC_BASE_MAX = 36,
    _SC_BC_DIM_MAX = 37,
    _SC_BC_SCALE_MAX = 38,
    _SC_BC_STRING_MAX = 39,
    _SC_COLL_WEIGHTS_MAX = 40,
    _SC_EQUIV_CLASS_MAX = 41,
    _SC_EXPR_NEST_MAX = 42,
    _SC_LINE_MAX = 43,
    _SC_RE_DUP_MAX = 44,
    _SC_CHARCLASS_NAME_MAX = 45,
    _SC_2_VERSION = 46,
    _SC_2_C_BIND = 47,
    _SC_2_C_DEV = 48,
    _SC_2_FORT_DEV = 49,
    _SC_2_FORT_RUN = 50,
    _SC_2_SW_DEV = 51,
    _SC_2_LOCALEDEF = 52,
    _SC_PII = 53,
    _SC_PII_XTI = 54,
    _SC_PII_SOCKET = 55,
    _SC_PII_INTERNET = 56,
    _SC_PII_OSI = 57,
    _SC_POLL = 58,
    _SC_SELECT = 59,
    _SC_UIO_MAXIOV = 60,
    _SC_IOV_MAX = 60,
    _SC_PII_INTERNET_STREAM = 61,
    _SC_PII_INTERNET_DGRAM = 62,
    _SC_PII_OSI_COTS = 63,
    _SC_PII_OSI_CLTS = 64,
    _SC_PII_OSI_M = 65,
    _SC_T_IOV_MAX = 66,
    _SC_THREADS = 67,
    _SC_THREAD_SAFE_FUNCTIONS = 68,
    _SC_GETGR_R_SIZE_MAX = 69,
    _SC_GETPW_R_SIZE_MAX = 70,
    _SC_LOGIN_NAME_MAX = 71,
    _SC_TTY_NAME_MAX = 72,
    _SC_THREAD_DESTRUCTOR_ITERATIONS = 73,
    _SC_THREAD_KEYS_MAX = 74,
    _SC_THREAD_STACK_MIN = 75,
    _SC_THREAD_THREADS_MAX = 76,
    _SC_THREAD_ATTR_STACKADDR = 77,
    _SC_THREAD_ATTR_STACKSIZE = 78,
    _SC_THREAD_PRIORITY_SCHEDULING = 79,
    _SC_THREAD_PRIO_INHERIT = 80,
    _SC_THREAD_PRIO_PROTECT = 81,
    _SC_THREAD_PROCESS_SHARED = 82,
    _SC_NPROCESSORS_CONF = 83,
    _SC_NPROCESSORS_ONLN = 84,
    _SC_PHYS_PAGES = 85,
    _SC_AVPHYS_PAGES = 86,
    _SC_ATEXIT_MAX = 87,
    _SC_PASS_MAX = 88,
    _SC_XOPEN_VERSION = 89,
    _SC_XOPEN_XCU_VERSION = 90,
    _SC_XOPEN_UNIX = 91,
    _SC_XOPEN_CRYPT = 92,
    _SC_XOPEN_ENH_I18N = 93,
    _SC_XOPEN_SHM = 94,
    _SC_2_CHAR_TERM = 95,
    _SC_2_C_VERSION = 96,
    _SC_2_UPE = 97,
    _SC_XOPEN_XPG2 = 98,
    _SC_XOPEN_XPG3 = 99,
    _SC_XOPEN_XPG4 = 100,
    _SC_CHAR_BIT = 101,
    _SC_CHAR_MAX = 102,
    _SC_CHAR_MIN = 103,
    _SC_INT_MAX = 104,
    _SC_INT_MIN = 105,
    _SC_LONG_BIT = 106,
    _SC_WORD_BIT = 107,
    _SC_MB_LEN_MAX = 108,
    _SC_NZERO = 109,
    _SC_SSIZE_MAX = 110,
    _SC_SCHAR_MAX = 111,
    _SC_SCHAR_MIN = 112,
    _SC_SHRT_MAX = 113,
    _SC_SHRT_MIN = 114,
    _SC_UCHAR_MAX = 115,
    _SC_UINT_MAX = 116,
    _SC_ULONG_MAX = 117,
    _SC_USHRT_MAX = 118,
    _SC_NL_ARGMAX = 119,
    _SC_NL_LANGMAX = 120,
    _SC_NL_MSGMAX = 121,
    _SC_NL_NMAX = 122,
    _SC_NL_SETMAX = 123,
    _SC_NL_TEXTMAX = 124,
    _SC_XBS5_ILP32_OFF32 = 125,
    _SC_XBS5_ILP32_OFFBIG = 126,
    _SC_XBS5_LP64_OFF64 = 127,
    _SC_XBS5_LPBIG_OFFBIG = 128,
    _SC_XOPEN_LEGACY = 129,
    _SC_XOPEN_REALTIME = 130,
    _SC_XOPEN_REALTIME_THREADS = 131,
    _SC_ADVISORY_INFO = 132,
    _SC_BARRIERS = 133,
    _SC_BASE = 134,
    _SC_C_LANG_SUPPORT = 135,
    _SC_C_LANG_SUPPORT_R = 136,
    _SC_CLOCK_SELECTION = 137,
    _SC_CPUTIME = 138,
    _SC_THREAD_CPUTIME = 139,
    _SC_DEVICE_IO = 140,
    _SC_DEVICE_SPECIFIC = 141,
    _SC_DEVICE_SPECIFIC_R = 142,
    _SC_FD_MGMT = 143,
    _SC_FIFO = 144,
    _SC_PIPE = 145,
    _SC_FILE_ATTRIBUTES = 146,
    _SC_FILE_LOCKING = 147,
    _SC_FILE_SYSTEM = 148,
    _SC_MONOTONIC_CLOCK = 149,
    _SC_MULTI_PROCESS = 150,
    _SC_SINGLE_PROCESS = 151,
    _SC_NETWORKING = 152,
    _SC_READER_WRITER_LOCKS = 153,
    _SC_SPIN_LOCKS = 154,
    _SC_REGEXP = 155,
    _SC_REGEX_VERSION = 156,
    _SC_SHELL = 157,
    _SC_SIGNALS = 158,
    _SC_SPAWN = 159,
    _SC_SPORADIC_SERVER = 160,
    _SC_THREAD_SPORADIC_SERVER = 161,
    _SC_SYSTEM_DATABASE = 162,
    _SC_SYSTEM_DATABASE_R = 163,
    _SC_TIMEOUTS = 164,
    _SC_TYPED_MEMORY_OBJECTS = 165,
    _SC_USER_GROUPS = 166,
    _SC_USER_GROUPS_R = 167,
    _SC_2_PBS = 168,
    _SC_2_PBS_ACCOUNTING = 169,
    _SC_2_PBS_LOCATE = 170,
    _SC_2_PBS_MESSAGE = 171,
    _SC_2_PBS_TRACK = 172,
    _SC_SYMLOOP_MAX = 173,
    _SC_STREAMS = 174,
    _SC_2_PBS_CHECKPOINT = 175,
    _SC_V6_ILP32_OFF32 = 176,
    _SC_V6_ILP32_OFFBIG = 177,
    _SC_V6_LP64_OFF64 = 178,
    _SC_V6_LPBIG_OFFBIG = 179,
    _SC_HOST_NAME_MAX = 180,
    _SC_TRACE = 181,
    _SC_TRACE_EVENT_FILTER = 182,
    _SC_TRACE_INHERIT = 183,
    _SC_TRACE_LOG = 184,
    _SC_LEVEL1_ICACHE_SIZE = 185,
    _SC_LEVEL1_ICACHE_ASSOC = 186,
    _SC_LEVEL1_ICACHE_LINESIZE = 187,
    _SC_LEVEL1_DCACHE_SIZE = 188,
    _SC_LEVEL1_DCACHE_ASSOC = 189,
    _SC_LEVEL1_DCACHE_LINESIZE = 190,
    _SC_LEVEL2_CACHE_SIZE = 191,
    _SC_LEVEL2_CACHE_ASSOC = 192,
    _SC_LEVEL2_CACHE_LINESIZE = 193,
    _SC_LEVEL3_CACHE_SIZE = 194,
    _SC_LEVEL3_CACHE_ASSOC = 195,
    _SC_LEVEL3_CACHE_LINESIZE = 196,
    _SC_LEVEL4_CACHE_SIZE = 197,
    _SC_LEVEL4_CACHE_ASSOC = 198,
    _SC_LEVEL4_CACHE_LINESIZE = 199,
    _SC_IPV6 = 235,
    _SC_RAW_SOCKETS = 236,
    _SC_V7_ILP32_OFF32 = 237,
    _SC_V7_ILP32_OFFBIG = 238,
    _SC_V7_LP64_OFF64 = 239,
    _SC_V7_LPBIG_OFFBIG = 240,
    _SC_SS_REPL_MAX = 241,
    _SC_TRACE_EVENT_NAME_MAX = 242,
    _SC_TRACE_NAME_MAX = 243,
    _SC_TRACE_SYS_MAX = 244,
    _SC_TRACE_USER_EVENT_MAX = 245,
    _SC_XOPEN_STREAMS = 246,
    _SC_THREAD_ROBUST_PRIO_INHERIT = 247,
    _SC_THREAD_ROBUST_PRIO_PROTECT = 248
} ;
enum __anonenum_29 {
    _CS_PATH = 0,
    _CS_V6_WIDTH_RESTRICTED_ENVS = 1,
    _CS_GNU_LIBC_VERSION = 2,
    _CS_GNU_LIBPTHREAD_VERSION = 3,
    _CS_V5_WIDTH_RESTRICTED_ENVS = 4,
    _CS_V7_WIDTH_RESTRICTED_ENVS = 5,
    _CS_LFS_CFLAGS = 1000,
    _CS_LFS_LDFLAGS = 1001,
    _CS_LFS_LIBS = 1002,
    _CS_LFS_LINTFLAGS = 1003,
    _CS_LFS64_CFLAGS = 1004,
    _CS_LFS64_LDFLAGS = 1005,
    _CS_LFS64_LIBS = 1006,
    _CS_LFS64_LINTFLAGS = 1007,
    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,
    _CS_XBS5_ILP32_OFF32_LDFLAGS = 1101,
    _CS_XBS5_ILP32_OFF32_LIBS = 1102,
    _CS_XBS5_ILP32_OFF32_LINTFLAGS = 1103,
    _CS_XBS5_ILP32_OFFBIG_CFLAGS = 1104,
    _CS_XBS5_ILP32_OFFBIG_LDFLAGS = 1105,
    _CS_XBS5_ILP32_OFFBIG_LIBS = 1106,
    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS = 1107,
    _CS_XBS5_LP64_OFF64_CFLAGS = 1108,
    _CS_XBS5_LP64_OFF64_LDFLAGS = 1109,
    _CS_XBS5_LP64_OFF64_LIBS = 1110,
    _CS_XBS5_LP64_OFF64_LINTFLAGS = 1111,
    _CS_XBS5_LPBIG_OFFBIG_CFLAGS = 1112,
    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS = 1113,
    _CS_XBS5_LPBIG_OFFBIG_LIBS = 1114,
    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS = 1115,
    _CS_POSIX_V6_ILP32_OFF32_CFLAGS = 1116,
    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS = 1117,
    _CS_POSIX_V6_ILP32_OFF32_LIBS = 1118,
    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS = 1119,
    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS = 1120,
    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS = 1121,
    _CS_POSIX_V6_ILP32_OFFBIG_LIBS = 1122,
    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS = 1123,
    _CS_POSIX_V6_LP64_OFF64_CFLAGS = 1124,
    _CS_POSIX_V6_LP64_OFF64_LDFLAGS = 1125,
    _CS_POSIX_V6_LP64_OFF64_LIBS = 1126,
    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS = 1127,
    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS = 1128,
    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS = 1129,
    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS = 1130,
    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS = 1131,
    _CS_POSIX_V7_ILP32_OFF32_CFLAGS = 1132,
    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS = 1133,
    _CS_POSIX_V7_ILP32_OFF32_LIBS = 1134,
    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS = 1135,
    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS = 1136,
    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS = 1137,
    _CS_POSIX_V7_ILP32_OFFBIG_LIBS = 1138,
    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS = 1139,
    _CS_POSIX_V7_LP64_OFF64_CFLAGS = 1140,
    _CS_POSIX_V7_LP64_OFF64_LDFLAGS = 1141,
    _CS_POSIX_V7_LP64_OFF64_LIBS = 1142,
    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS = 1143,
    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS = 1144,
    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS = 1145,
    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS = 1146,
    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS = 1147,
    _CS_V6_ENV = 1148,
    _CS_V7_ENV = 1149
} ;
struct flock {
   short l_type ;
   short l_whence ;
   __off64_t l_start ;
   __off64_t l_len ;
   __pid_t l_pid ;
};
struct stat {
   __dev_t st_dev ;
   unsigned short __pad1 ;
   __ino_t __st_ino ;
   __mode_t st_mode ;
   __nlink_t st_nlink ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   __dev_t st_rdev ;
   unsigned short __pad2 ;
   __off64_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt64_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __ino64_t st_ino ;
};
enum __anonenum_ACTION_30 {
    FIND = 0,
    ENTER = 1
} ;
typedef enum __anonenum_ACTION_30 ACTION;
struct entry {
   char *key ;
   void *data ;
};
typedef struct entry ENTRY;
struct _ENTRY;
struct _ENTRY;
enum __anonenum_VISIT_31 {
    preorder = 0,
    postorder = 1,
    endorder = 2,
    leaf = 3
} ;
typedef enum __anonenum_VISIT_31 VISIT;
typedef void (*__action_fn_t)(void const   *__nodep , VISIT __value ,
                              int __level );
typedef signed char int8;
typedef unsigned char uint8;
typedef short int16;
typedef unsigned short uint16;
typedef int int32;
typedef unsigned int uint32;
typedef long long int64;
typedef unsigned long long uint64;
typedef int uint16_vap;
struct __anonstruct_TIFFHeaderCommon_32 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
};
typedef struct __anonstruct_TIFFHeaderCommon_32 TIFFHeaderCommon;
struct __anonstruct_TIFFHeaderClassic_33 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint32 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderClassic_33 TIFFHeaderClassic;
struct __anonstruct_TIFFHeaderBig_34 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint16 tiff_offsetsize ;
   uint16 tiff_unused ;
   uint64 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderBig_34 TIFFHeaderBig;
enum __anonenum_TIFFDataType_35 {
    TIFF_NOTYPE = 0,
    TIFF_BYTE = 1,
    TIFF_ASCII = 2,
    TIFF_SHORT = 3,
    TIFF_LONG = 4,
    TIFF_RATIONAL = 5,
    TIFF_SBYTE = 6,
    TIFF_UNDEFINED = 7,
    TIFF_SSHORT = 8,
    TIFF_SLONG = 9,
    TIFF_SRATIONAL = 10,
    TIFF_FLOAT = 11,
    TIFF_DOUBLE = 12,
    TIFF_IFD = 13,
    TIFF_LONG8 = 16,
    TIFF_SLONG8 = 17,
    TIFF_IFD8 = 18
} ;
typedef enum __anonenum_TIFFDataType_35 TIFFDataType;
struct tiff;
typedef struct tiff TIFF;
typedef long tmsize_t;
typedef uint64 toff_t;
typedef uint32 ttag_t;
typedef uint16 tdir_t;
typedef uint16 tsample_t;
typedef uint32 tstrile_t;
typedef tstrile_t tstrip_t;
typedef tstrile_t ttile_t;
typedef tmsize_t tsize_t;
typedef void *tdata_t;
typedef void *thandle_t;
typedef unsigned char TIFFRGBValue;
struct __anonstruct_TIFFDisplay_36 {
   float d_mat[3][3] ;
   float d_YCR ;
   float d_YCG ;
   float d_YCB ;
   uint32 d_Vrwr ;
   uint32 d_Vrwg ;
   uint32 d_Vrwb ;
   float d_Y0R ;
   float d_Y0G ;
   float d_Y0B ;
   float d_gammaR ;
   float d_gammaG ;
   float d_gammaB ;
};
typedef struct __anonstruct_TIFFDisplay_36 TIFFDisplay;
struct __anonstruct_TIFFYCbCrToRGB_37 {
   TIFFRGBValue *clamptab ;
   int *Cr_r_tab ;
   int *Cb_b_tab ;
   int32 *Cr_g_tab ;
   int32 *Cb_g_tab ;
   int32 *Y_tab ;
};
typedef struct __anonstruct_TIFFYCbCrToRGB_37 TIFFYCbCrToRGB;
struct __anonstruct_TIFFCIELabToRGB_38 {
   int range ;
   float rstep ;
   float gstep ;
   float bstep ;
   float X0 ;
   float Y0 ;
   float Z0 ;
   TIFFDisplay display ;
   float Yr2r[1501] ;
   float Yg2g[1501] ;
   float Yb2b[1501] ;
};
typedef struct __anonstruct_TIFFCIELabToRGB_38 TIFFCIELabToRGB;
struct _TIFFRGBAImage;
typedef struct _TIFFRGBAImage TIFFRGBAImage;
typedef void (*tileContigRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                  uint32  , uint32  , uint32  , int32  ,
                                  int32  , unsigned char * );
typedef void (*tileSeparateRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                    uint32  , uint32  , uint32  , int32  ,
                                    int32  , unsigned char * , unsigned char * ,
                                    unsigned char * , unsigned char * );
union __anonunion_put_39 {
   void (*any)(TIFFRGBAImage * ) ;
   void (*contig)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                  uint32  , int32  , int32  , unsigned char * ) ;
   void (*separate)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                    uint32  , int32  , int32  , unsigned char * ,
                    unsigned char * , unsigned char * , unsigned char * ) ;
};
struct _TIFFRGBAImage {
   TIFF *tif ;
   int stoponerr ;
   int isContig ;
   int alpha ;
   uint32 width ;
   uint32 height ;
   uint16 bitspersample ;
   uint16 samplesperpixel ;
   uint16 orientation ;
   uint16 req_orientation ;
   uint16 photometric ;
   uint16 *redcmap ;
   uint16 *greencmap ;
   uint16 *bluecmap ;
   int (*get)(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
   union __anonunion_put_39 put ;
   TIFFRGBValue *Map ;
   uint32 **BWmap ;
   uint32 **PALmap ;
   TIFFYCbCrToRGB *ycbcr ;
   TIFFCIELabToRGB *cielab ;
   uint8 *UaToAa ;
   uint8 *Bitdepth16To8 ;
   int row_offset ;
   int col_offset ;
};
typedef int (*TIFFInitMethod)(TIFF * , int  );
struct __anonstruct_TIFFCodec_40 {
   char *name ;
   uint16 scheme ;
   int (*init)(TIFF * , int  ) ;
};
typedef struct __anonstruct_TIFFCodec_40 TIFFCodec;
typedef void (*TIFFErrorHandler)(char const   * , char const   * , va_list  );
typedef void (*TIFFErrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  );
typedef tmsize_t (*TIFFReadWriteProc)(thandle_t  , void * , tmsize_t  );
typedef toff_t (*TIFFSeekProc)(thandle_t  , toff_t  , int  );
typedef int (*TIFFCloseProc)(thandle_t  );
typedef toff_t (*TIFFSizeProc)(thandle_t  );
typedef int (*TIFFMapFileProc)(thandle_t  , void **base , toff_t *size );
typedef void (*TIFFUnmapFileProc)(thandle_t  , void *base , toff_t size );
typedef void (*TIFFExtendProc)(TIFF * );
struct _TIFFField;
typedef struct _TIFFField TIFFField;
struct _TIFFFieldArray;
typedef struct _TIFFFieldArray TIFFFieldArray;
typedef int (*TIFFVSetMethod)(TIFF * , uint32  , va_list  );
typedef int (*TIFFVGetMethod)(TIFF * , uint32  , va_list  );
typedef void (*TIFFPrintMethod)(TIFF * , FILE * , long  );
struct __anonstruct_TIFFTagMethods_41 {
   int (*vsetfield)(TIFF * , uint32  , va_list  ) ;
   int (*vgetfield)(TIFF * , uint32  , va_list  ) ;
   void (*printdir)(TIFF * , FILE * , long  ) ;
};
typedef struct __anonstruct_TIFFTagMethods_41 TIFFTagMethods;
struct __anonstruct_TIFFFieldInfo_42 {
   ttag_t field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
};
typedef struct __anonstruct_TIFFFieldInfo_42 TIFFFieldInfo;
struct __anonstruct_TIFFTagValue_43 {
   TIFFField const   *info ;
   int count ;
   void *value ;
};
typedef struct __anonstruct_TIFFTagValue_43 TIFFTagValue;
struct __anonstruct_TIFFDirectory_44 {
   unsigned long td_fieldsset[4] ;
   uint32 td_imagewidth ;
   uint32 td_imagelength ;
   uint32 td_imagedepth ;
   uint32 td_tilewidth ;
   uint32 td_tilelength ;
   uint32 td_tiledepth ;
   uint32 td_subfiletype ;
   uint16 td_bitspersample ;
   uint16 td_sampleformat ;
   uint16 td_compression ;
   uint16 td_photometric ;
   uint16 td_threshholding ;
   uint16 td_fillorder ;
   uint16 td_orientation ;
   uint16 td_samplesperpixel ;
   uint32 td_rowsperstrip ;
   uint16 td_minsamplevalue ;
   uint16 td_maxsamplevalue ;
   double td_sminsamplevalue ;
   double td_smaxsamplevalue ;
   float td_xresolution ;
   float td_yresolution ;
   uint16 td_resolutionunit ;
   uint16 td_planarconfig ;
   float td_xposition ;
   float td_yposition ;
   uint16 td_pagenumber[2] ;
   uint16 *td_colormap[3] ;
   uint16 td_halftonehints[2] ;
   uint16 td_extrasamples ;
   uint16 *td_sampleinfo ;
   uint32 td_stripsperimage ;
   uint32 td_nstrips ;
   uint64 *td_stripoffset ;
   uint64 *td_stripbytecount ;
   int td_stripbytecountsorted ;
   uint16 td_nsubifd ;
   uint64 *td_subifd ;
   uint16 td_ycbcrsubsampling[2] ;
   uint16 td_ycbcrpositioning ;
   uint16 *td_transferfunction[3] ;
   float *td_refblackwhite ;
   int td_inknameslen ;
   char *td_inknames ;
   int td_customValueCount ;
   TIFFTagValue *td_customValues ;
};
typedef struct __anonstruct_TIFFDirectory_44 TIFFDirectory;
enum __anonenum_TIFFSetGetFieldType_45 {
    TIFF_SETGET_UNDEFINED = 0,
    TIFF_SETGET_ASCII = 1,
    TIFF_SETGET_UINT8 = 2,
    TIFF_SETGET_SINT8 = 3,
    TIFF_SETGET_UINT16 = 4,
    TIFF_SETGET_SINT16 = 5,
    TIFF_SETGET_UINT32 = 6,
    TIFF_SETGET_SINT32 = 7,
    TIFF_SETGET_UINT64 = 8,
    TIFF_SETGET_SINT64 = 9,
    TIFF_SETGET_FLOAT = 10,
    TIFF_SETGET_DOUBLE = 11,
    TIFF_SETGET_IFD8 = 12,
    TIFF_SETGET_INT = 13,
    TIFF_SETGET_UINT16_PAIR = 14,
    TIFF_SETGET_C0_ASCII = 15,
    TIFF_SETGET_C0_UINT8 = 16,
    TIFF_SETGET_C0_SINT8 = 17,
    TIFF_SETGET_C0_UINT16 = 18,
    TIFF_SETGET_C0_SINT16 = 19,
    TIFF_SETGET_C0_UINT32 = 20,
    TIFF_SETGET_C0_SINT32 = 21,
    TIFF_SETGET_C0_UINT64 = 22,
    TIFF_SETGET_C0_SINT64 = 23,
    TIFF_SETGET_C0_FLOAT = 24,
    TIFF_SETGET_C0_DOUBLE = 25,
    TIFF_SETGET_C0_IFD8 = 26,
    TIFF_SETGET_C16_ASCII = 27,
    TIFF_SETGET_C16_UINT8 = 28,
    TIFF_SETGET_C16_SINT8 = 29,
    TIFF_SETGET_C16_UINT16 = 30,
    TIFF_SETGET_C16_SINT16 = 31,
    TIFF_SETGET_C16_UINT32 = 32,
    TIFF_SETGET_C16_SINT32 = 33,
    TIFF_SETGET_C16_UINT64 = 34,
    TIFF_SETGET_C16_SINT64 = 35,
    TIFF_SETGET_C16_FLOAT = 36,
    TIFF_SETGET_C16_DOUBLE = 37,
    TIFF_SETGET_C16_IFD8 = 38,
    TIFF_SETGET_C32_ASCII = 39,
    TIFF_SETGET_C32_UINT8 = 40,
    TIFF_SETGET_C32_SINT8 = 41,
    TIFF_SETGET_C32_UINT16 = 42,
    TIFF_SETGET_C32_SINT16 = 43,
    TIFF_SETGET_C32_UINT32 = 44,
    TIFF_SETGET_C32_SINT32 = 45,
    TIFF_SETGET_C32_UINT64 = 46,
    TIFF_SETGET_C32_SINT64 = 47,
    TIFF_SETGET_C32_FLOAT = 48,
    TIFF_SETGET_C32_DOUBLE = 49,
    TIFF_SETGET_C32_IFD8 = 50,
    TIFF_SETGET_OTHER = 51
} ;
typedef enum __anonenum_TIFFSetGetFieldType_45 TIFFSetGetFieldType;
enum __anonenum_TIFFFieldArrayType_46 {
    tfiatImage = 0,
    tfiatExif = 1,
    tfiatOther = 2
} ;
typedef enum __anonenum_TIFFFieldArrayType_46 TIFFFieldArrayType;
struct _TIFFFieldArray {
   TIFFFieldArrayType type ;
   uint32 allocated_size ;
   uint32 count ;
   TIFFField *fields ;
};
struct _TIFFField {
   uint32 field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   uint32 reserved ;
   TIFFSetGetFieldType set_field_type ;
   TIFFSetGetFieldType get_field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
   TIFFFieldArray *field_subfields ;
};
union __anonunion_tdir_offset_48 {
   uint16 toff_short ;
   uint32 toff_long ;
   uint64 toff_long8 ;
};
struct __anonstruct_TIFFDirEntry_47 {
   uint16 tdir_tag ;
   uint16 tdir_type ;
   uint64 tdir_count ;
   union __anonunion_tdir_offset_48 tdir_offset ;
};
typedef struct __anonstruct_TIFFDirEntry_47 TIFFDirEntry;
struct client_info {
   struct client_info *next ;
   void *data ;
   char *name ;
};
typedef struct client_info TIFFClientInfoLink;
typedef unsigned char tidataval_t;
typedef tidataval_t *tidata_t;
typedef void (*TIFFVoidMethod)(TIFF * );
typedef int (*TIFFBoolMethod)(TIFF * );
typedef int (*TIFFPreMethod)(TIFF * , uint16  );
typedef int (*TIFFCodeMethod)(TIFF *tif , uint8 *buf , tmsize_t size ,
                              uint16 sample );
typedef int (*TIFFSeekMethod)(TIFF * , uint32  );
typedef void (*TIFFPostMethod)(TIFF *tif , uint8 *buf , tmsize_t size );
typedef uint32 (*TIFFStripMethod)(TIFF * , uint32  );
typedef void (*TIFFTileMethod)(TIFF * , uint32 * , uint32 * );
union __anonunion_tif_header_49 {
   TIFFHeaderCommon common ;
   TIFFHeaderClassic classic ;
   TIFFHeaderBig big ;
};
struct tiff {
   char *tif_name ;
   int tif_fd ;
   int tif_mode ;
   uint32 tif_flags ;
   uint64 tif_diroff ;
   uint64 tif_nextdiroff ;
   uint64 *tif_dirlist ;
   uint16 tif_dirlistsize ;
   uint16 tif_dirnumber ;
   TIFFDirectory tif_dir ;
   TIFFDirectory tif_customdir ;
   union __anonunion_tif_header_49 tif_header ;
   uint16 tif_header_size ;
   uint32 tif_row ;
   uint16 tif_curdir ;
   uint32 tif_curstrip ;
   uint64 tif_curoff ;
   uint64 tif_dataoff ;
   uint16 tif_nsubifd ;
   uint64 tif_subifdoff ;
   uint32 tif_col ;
   uint32 tif_curtile ;
   tmsize_t tif_tilesize ;
   int tif_decodestatus ;
   int (*tif_fixuptags)(TIFF * ) ;
   int (*tif_setupdecode)(TIFF * ) ;
   int (*tif_predecode)(TIFF * , uint16  ) ;
   int (*tif_setupencode)(TIFF * ) ;
   int tif_encodestatus ;
   int (*tif_preencode)(TIFF * , uint16  ) ;
   int (*tif_postencode)(TIFF * ) ;
   int (*tif_decoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_decodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_encodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_decodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   void (*tif_close)(TIFF * ) ;
   int (*tif_seek)(TIFF * , uint32  ) ;
   void (*tif_cleanup)(TIFF * ) ;
   uint32 (*tif_defstripsize)(TIFF * , uint32  ) ;
   void (*tif_deftilesize)(TIFF * , uint32 * , uint32 * ) ;
   uint8 *tif_data ;
   tmsize_t tif_scanlinesize ;
   tmsize_t tif_scanlineskew ;
   uint8 *tif_rawdata ;
   tmsize_t tif_rawdatasize ;
   tmsize_t tif_rawdataoff ;
   tmsize_t tif_rawdataloaded ;
   uint8 *tif_rawcp ;
   tmsize_t tif_rawcc ;
   uint8 *tif_base ;
   tmsize_t tif_size ;
   int (*tif_mapproc)(thandle_t  , void **base , toff_t *size ) ;
   void (*tif_unmapproc)(thandle_t  , void *base , toff_t size ) ;
   thandle_t tif_clientdata ;
   tmsize_t (*tif_readproc)(thandle_t  , void * , tmsize_t  ) ;
   tmsize_t (*tif_writeproc)(thandle_t  , void * , tmsize_t  ) ;
   toff_t (*tif_seekproc)(thandle_t  , toff_t  , int  ) ;
   int (*tif_closeproc)(thandle_t  ) ;
   toff_t (*tif_sizeproc)(thandle_t  ) ;
   void (*tif_postdecode)(TIFF *tif , uint8 *buf , tmsize_t size ) ;
   TIFFField **tif_fields ;
   size_t tif_nfields ;
   TIFFField const   *tif_foundfield ;
   TIFFTagMethods tif_tagmethods ;
   TIFFClientInfoLink *tif_clientinfo ;
   TIFFFieldArray *tif_fieldscompat ;
   size_t tif_nfieldscompat ;
};
enum __anonenum_t2p_cs_t_50 {
    T2P_CS_BILEVEL = 1,
    T2P_CS_GRAY = 2,
    T2P_CS_RGB = 4,
    T2P_CS_CMYK = 8,
    T2P_CS_LAB = 16,
    T2P_CS_PALETTE = 4096,
    T2P_CS_CALGRAY = 32,
    T2P_CS_CALRGB = 64,
    T2P_CS_ICCBASED = 128
} ;
typedef enum __anonenum_t2p_cs_t_50 t2p_cs_t;
enum __anonenum_t2p_compress_t_51 {
    T2P_COMPRESS_NONE = 0,
    T2P_COMPRESS_G4 = 1,
    T2P_COMPRESS_ZIP = 4
} ;
typedef enum __anonenum_t2p_compress_t_51 t2p_compress_t;
enum __anonenum_t2p_transcode_t_52 {
    T2P_TRANSCODE_RAW = 1,
    T2P_TRANSCODE_ENCODE = 2
} ;
typedef enum __anonenum_t2p_transcode_t_52 t2p_transcode_t;
enum __anonenum_t2p_sample_t_53 {
    T2P_SAMPLE_NOTHING = 0,
    T2P_SAMPLE_ABGR_TO_RGB = 1,
    T2P_SAMPLE_RGBA_TO_RGB = 2,
    T2P_SAMPLE_RGBAA_TO_RGB = 4,
    T2P_SAMPLE_YCBCR_TO_RGB = 8,
    T2P_SAMPLE_YCBCR_TO_LAB = 16,
    T2P_SAMPLE_REALIZE_PALETTE = 32,
    T2P_SAMPLE_SIGNED_TO_UNSIGNED = 64,
    T2P_SAMPLE_LAB_SIGNED_TO_UNSIGNED = 64,
    T2P_SAMPLE_PLANAR_SEPARATE_TO_CONTIG = 256
} ;
typedef enum __anonenum_t2p_sample_t_53 t2p_sample_t;
enum __anonenum_t2p_err_t_54 {
    T2P_ERR_OK = 0,
    T2P_ERR_ERROR = 1
} ;
typedef enum __anonenum_t2p_err_t_54 t2p_err_t;
struct __anonstruct_T2P_PAGE_55 {
   tdir_t page_directory ;
   uint32 page_number ;
   ttile_t page_tilecount ;
   uint32 page_extra ;
};
typedef struct __anonstruct_T2P_PAGE_55 T2P_PAGE;
struct __anonstruct_T2P_BOX_56 {
   float x1 ;
   float y1 ;
   float x2 ;
   float y2 ;
   float mat[9] ;
};
typedef struct __anonstruct_T2P_BOX_56 T2P_BOX;
struct __anonstruct_T2P_TILE_57 {
   T2P_BOX tile_box ;
};
typedef struct __anonstruct_T2P_TILE_57 T2P_TILE;
struct __anonstruct_T2P_TILES_58 {
   ttile_t tiles_tilecount ;
   uint32 tiles_tilewidth ;
   uint32 tiles_tilelength ;
   uint32 tiles_tilecountx ;
   uint32 tiles_tilecounty ;
   uint32 tiles_edgetilewidth ;
   uint32 tiles_edgetilelength ;
   T2P_TILE *tiles_tiles ;
};
typedef struct __anonstruct_T2P_TILES_58 T2P_TILES;
struct __anonstruct_T2P_59 {
   t2p_err_t t2p_error ;
   T2P_PAGE *tiff_pages ;
   T2P_TILES *tiff_tiles ;
   tdir_t tiff_pagecount ;
   uint16 tiff_compression ;
   uint16 tiff_photometric ;
   uint16 tiff_fillorder ;
   uint16 tiff_bitspersample ;
   uint16 tiff_samplesperpixel ;
   uint16 tiff_planar ;
   uint32 tiff_width ;
   uint32 tiff_length ;
   float tiff_xres ;
   float tiff_yres ;
   uint16 tiff_orientation ;
   toff_t tiff_dataoffset ;
   tsize_t tiff_datasize ;
   uint16 tiff_resunit ;
   uint16 pdf_centimeters ;
   uint16 pdf_overrideres ;
   uint16 pdf_overridepagesize ;
   float pdf_defaultxres ;
   float pdf_defaultyres ;
   float pdf_xres ;
   float pdf_yres ;
   float pdf_defaultpagewidth ;
   float pdf_defaultpagelength ;
   float pdf_pagewidth ;
   float pdf_pagelength ;
   float pdf_imagewidth ;
   float pdf_imagelength ;
   T2P_BOX pdf_mediabox ;
   T2P_BOX pdf_imagebox ;
   uint16 pdf_majorversion ;
   uint16 pdf_minorversion ;
   uint32 pdf_catalog ;
   uint32 pdf_pages ;
   uint32 pdf_info ;
   uint32 pdf_palettecs ;
   uint16 pdf_fitwindow ;
   uint32 pdf_startxref ;
   unsigned char *pdf_fileid ;
   char pdf_datetime[17] ;
   char pdf_creator[512] ;
   char pdf_author[512] ;
   char pdf_title[512] ;
   char pdf_subject[512] ;
   char pdf_keywords[512] ;
   t2p_cs_t pdf_colorspace ;
   uint16 pdf_colorspace_invert ;
   uint16 pdf_switchdecode ;
   uint16 pdf_palettesize ;
   unsigned char *pdf_palette ;
   int pdf_labrange[4] ;
   t2p_compress_t pdf_defaultcompression ;
   uint16 pdf_defaultcompressionquality ;
   t2p_compress_t pdf_compression ;
   uint16 pdf_compressionquality ;
   uint16 pdf_nopassthrough ;
   t2p_transcode_t pdf_transcode ;
   t2p_sample_t pdf_sample ;
   uint32 *pdf_xrefoffsets ;
   uint32 pdf_xrefcount ;
   tdir_t pdf_page ;
   float tiff_whitechromaticities[2] ;
   float tiff_primarychromaticities[6] ;
   float tiff_referenceblackwhite[2] ;
   float *tiff_transferfunction[3] ;
   int pdf_image_interpolate ;
   uint16 tiff_transferfunctioncount ;
   uint32 pdf_icccs ;
   uint32 tiff_iccprofilelength ;
   tdata_t tiff_iccprofile ;
   FILE *outputfile ;
   int outputdisable ;
   tsize_t outputwritten ;
};
typedef struct __anonstruct_T2P_59 T2P;
extern struct _IO_FILE_plus _IO_2_1_stdin_ ;
extern struct _IO_FILE_plus _IO_2_1_stdout_ ;
extern struct _IO_FILE_plus _IO_2_1_stderr_ ;
extern int __underflow(_IO_FILE * ) ;
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_feof(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_ferror(_IO_FILE *__fp ) ;
extern int _IO_peekc_locked(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) void _IO_flockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) void _IO_funlockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) int _IO_ftrylockfile(_IO_FILE * ) ;
extern int _IO_vfscanf(_IO_FILE * __restrict   , char const   * __restrict   ,
                       __gnuc_va_list  , int * __restrict   ) ;
extern int _IO_vfprintf(_IO_FILE * __restrict   , char const   * __restrict   ,
                        __gnuc_va_list  ) ;
extern __ssize_t _IO_padn(_IO_FILE * , int  , __ssize_t  ) ;
extern size_t _IO_sgetn(_IO_FILE * , void * , size_t  ) ;
extern __off64_t _IO_seekoff(_IO_FILE * , __off64_t  , int  , int  ) ;
extern __off64_t _IO_seekpos(_IO_FILE * , __off64_t  , int  ) ;
extern  __attribute__((__nothrow__)) void _IO_free_backup_area(_IO_FILE * ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
extern  __attribute__((__nothrow__)) int remove(char const   *__filename ) ;
extern  __attribute__((__nothrow__)) int rename(char const   *__old ,
                                                char const   *__new ) ;
extern  __attribute__((__nothrow__)) int renameat(int __oldfd ,
                                                  char const   *__old ,
                                                  int __newfd ,
                                                  char const   *__new ) ;
extern FILE *tmpfile(void)  __asm__("tmpfile64")  ;
extern  __attribute__((__nothrow__)) char *tmpnam(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tmpnam_r(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tempnam(char const   *__dir ,
                                                   char const   *__pfx )  __attribute__((__malloc__)) ;
extern int fclose(FILE *__stream ) ;
extern int fflush(FILE *__stream ) ;
extern int fflush_unlocked(FILE *__stream ) ;
extern FILE *freopen(char const   * __restrict  __filename ,
                     char const   * __restrict  __modes ,
                     FILE * __restrict  __stream )  __asm__("freopen64")  ;
extern  __attribute__((__nothrow__)) FILE *fdopen(int __fd ,
                                                  char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *fmemopen(void *__s , size_t __len ,
                                                    char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *open_memstream(char **__bufloc ,
                                                          size_t *__sizeloc ) ;
extern  __attribute__((__nothrow__)) void setbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) int setvbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ,
                                                 int __modes , size_t __n ) ;
extern  __attribute__((__nothrow__)) void setbuffer(FILE * __restrict  __stream ,
                                                    char * __restrict  __buf ,
                                                    size_t __size ) ;
extern  __attribute__((__nothrow__)) void setlinebuf(FILE *__stream ) ;
extern int fprintf(FILE * __restrict  __stream ,
                   char const   * __restrict  __format  , ...) ;
extern int printf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sprintf(char * __restrict  __s ,
                                                 char const   * __restrict  __format 
                                                 , ...) ;
extern int vfprintf(FILE * __restrict  __s ,
                    char const   * __restrict  __format , __gnuc_va_list __arg ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vsprintf(char * __restrict  __s ,
                                                  char const   * __restrict  __format ,
                                                  __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  snprintf)(char * __restrict  __s ,
                                                                             size_t __maxlen ,
                                                                             char const   * __restrict  __format 
                                                                             , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsnprintf)(char * __restrict  __s ,
                                                                              size_t __maxlen ,
                                                                              char const   * __restrict  __format ,
                                                                              __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  vdprintf)(int __fd ,
                                               char const   * __restrict  __fmt ,
                                               __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  dprintf)(int __fd ,
                                              char const   * __restrict  __fmt 
                                              , ...) ;
extern int fscanf(FILE * __restrict  __stream ,
                  char const   * __restrict  __format  , ...)  __asm__("__isoc99_fscanf")  ;
extern int scanf(char const   * __restrict  __format  , ...)  __asm__("__isoc99_scanf")  ;
extern  __attribute__((__nothrow__)) int sscanf(char const   * __restrict  __s ,
                                                char const   * __restrict  __format 
                                                , ...)  __asm__("__isoc99_sscanf")  ;
extern int ( /* format attribute */  vfscanf)(FILE * __restrict  __s ,
                                              char const   * __restrict  __format ,
                                              __gnuc_va_list __arg )  __asm__("__isoc99_vfscanf")  ;
extern int ( /* format attribute */  vscanf)(char const   * __restrict  __format ,
                                             __gnuc_va_list __arg )  __asm__("__isoc99_vscanf")  ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsscanf)(char const   * __restrict  __s ,
                                                                            char const   * __restrict  __format ,
                                                                            __gnuc_va_list __arg )  __asm__("__isoc99_vsscanf")  ;
extern int fgetc(FILE *__stream ) ;
extern int getc(FILE *__stream ) ;
__inline extern int getchar(void) ;
__inline extern int getc_unlocked(FILE *__fp ) ;
__inline extern int getchar_unlocked(void) ;
__inline extern int fgetc_unlocked(FILE *__fp ) ;
extern int fputc(int __c , FILE *__stream ) ;
extern int putc(int __c , FILE *__stream ) ;
__inline extern int putchar(int __c ) ;
__inline extern int fputc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putchar_unlocked(int __c ) ;
extern int getw(FILE *__stream ) ;
extern int putw(int __w , FILE *__stream ) ;
extern char *fgets(char * __restrict  __s , int __n ,
                   FILE * __restrict  __stream ) ;
extern char *gets(char *__s ) ;
extern __ssize_t __getdelim(char ** __restrict  __lineptr ,
                            size_t * __restrict  __n , int __delimiter ,
                            FILE * __restrict  __stream ) ;
extern __ssize_t getdelim(char ** __restrict  __lineptr ,
                          size_t * __restrict  __n , int __delimiter ,
                          FILE * __restrict  __stream ) ;
extern __ssize_t getline(char ** __restrict  __lineptr ,
                         size_t * __restrict  __n , FILE * __restrict  __stream ) ;
extern int fputs(char const   * __restrict  __s , FILE * __restrict  __stream ) ;
extern int puts(char const   *__s ) ;
extern int ungetc(int __c , FILE *__stream ) ;
extern size_t fread(void * __restrict  __ptr , size_t __size , size_t __n ,
                    FILE * __restrict  __stream ) ;
extern size_t fwrite(void const   * __restrict  __ptr , size_t __size ,
                     size_t __n , FILE * __restrict  __s ) ;
extern size_t fread_unlocked(void * __restrict  __ptr , size_t __size ,
                             size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite_unlocked(void const   * __restrict  __ptr , size_t __size ,
                              size_t __n , FILE * __restrict  __stream ) ;
extern int fseek(FILE *__stream , long __off , int __whence ) ;
extern long ftell(FILE *__stream ) ;
extern void rewind(FILE *__stream ) ;
extern int fseeko(FILE *__stream , __off64_t __off , int __whence )  __asm__("fseeko64")  ;
extern __off64_t ftello(FILE *__stream )  __asm__("ftello64")  ;
extern int fgetpos(FILE * __restrict  __stream , fpos_t * __restrict  __pos )  __asm__("fgetpos64")  ;
extern int fsetpos(FILE *__stream , fpos_t const   *__pos )  __asm__("fsetpos64")  ;
extern  __attribute__((__nothrow__)) void clearerr(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int feof(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ferror(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void clearerr_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
extern void perror(char const   *__s ) ;
extern int sys_nerr ;
extern char const   * const  sys_errlist[] ;
extern  __attribute__((__nothrow__)) int fileno(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int fileno_unlocked(FILE *__stream ) ;
extern FILE *popen(char const   *__command , char const   *__modes ) ;
extern int pclose(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) char *ctermid(char *__s ) ;
extern  __attribute__((__nothrow__)) void flockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ftrylockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void funlockfile(FILE *__stream ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1\n");
  fflush(_coverage_fout);
  tmp = vfprintf((FILE */* __restrict  */)stdout, __fmt, __arg);
  fprintf(_coverage_fout, "2\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int getchar(void) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3\n");
  fflush(_coverage_fout);
  tmp = _IO_getc(stdin);
  fprintf(_coverage_fout, "4\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int fgetc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "10\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "11\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "5\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "6\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "7\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "8\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "9\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "12\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int getc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "18\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "19\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "13\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "14\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "15\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "16\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "17\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "20\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int getchar_unlocked(void) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "26\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )stdin->_IO_read_ptr >= (unsigned int )stdin->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "27\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "21\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(stdin);
    fprintf(_coverage_fout, "22\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "23\n");
    fflush(_coverage_fout);
    tmp___1 = stdin->_IO_read_ptr;
    fprintf(_coverage_fout, "24\n");
    fflush(_coverage_fout);
    (stdin->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "25\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "28\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int putchar(int __c ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "29\n");
  fflush(_coverage_fout);
  tmp = _IO_putc(__c, stdout);
  fprintf(_coverage_fout, "30\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int fputc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "38\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "39\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "31\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "32\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "33\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "34\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "35\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "36\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "37\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "40\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern int putc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "48\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "49\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "41\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "42\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "43\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "44\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "45\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "46\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "47\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "50\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern int putchar_unlocked(int __c ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "58\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )stdout->_IO_write_ptr >= (unsigned int )stdout->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "59\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "51\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "52\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "53\n");
    fflush(_coverage_fout);
    tmp___1 = stdout->_IO_write_ptr;
    fprintf(_coverage_fout, "54\n");
    fflush(_coverage_fout);
    (stdout->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "55\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "56\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "57\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "60\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern int feof_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "61\n");
  fflush(_coverage_fout);
  return ((__stream->_flags & 0x10) != 0);
}
}
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
__inline extern int ferror_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "62\n");
  fflush(_coverage_fout);
  return ((__stream->_flags & 0x20) != 0);
}
}
extern  __attribute__((__nothrow__)) size_t __ctype_get_mb_cur_max(void) ;
__inline extern  __attribute__((__nothrow__)) double atof(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) int atoi(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) long atol(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) long long atoll(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) double strtod(char const   * __restrict  __nptr ,
                                                   char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) float strtof(char const   * __restrict  __nptr ,
                                                  char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long double strtold(char const   * __restrict  __nptr ,
                                                         char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long strtol(char const   * __restrict  __nptr ,
                                                 char ** __restrict  __endptr ,
                                                 int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long strtoul(char const   * __restrict  __nptr ,
                                                           char ** __restrict  __endptr ,
                                                           int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long long strtoq(char const   * __restrict  __nptr ,
                                                      char ** __restrict  __endptr ,
                                                      int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long long strtouq(char const   * __restrict  __nptr ,
                                                                char ** __restrict  __endptr ,
                                                                int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long long strtoll(char const   * __restrict  __nptr ,
                                                       char ** __restrict  __endptr ,
                                                       int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long long strtoull(char const   * __restrict  __nptr ,
                                                                 char ** __restrict  __endptr ,
                                                                 int __base )  __attribute__((__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) double atof(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern double atof(char const   *__nptr ) 
{ double tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "63\n");
  fflush(_coverage_fout);
  tmp = strtod((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)));
  fprintf(_coverage_fout, "64\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int atoi(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern int atoi(char const   *__nptr ) 
{ long tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "65\n");
  fflush(_coverage_fout);
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  fprintf(_coverage_fout, "66\n");
  fflush(_coverage_fout);
  return ((int )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long atol(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern long atol(char const   *__nptr ) 
{ long tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "67\n");
  fflush(_coverage_fout);
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  fprintf(_coverage_fout, "68\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long long atoll(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern long long atoll(char const   *__nptr ) 
{ long long tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "69\n");
  fflush(_coverage_fout);
  tmp = strtoll((char const   */* __restrict  */)__nptr,
                (char **/* __restrict  */)((char **)((void *)0)), 10);
  fprintf(_coverage_fout, "70\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
extern  __attribute__((__nothrow__)) char *l64a(long __n ) ;
extern  __attribute__((__nothrow__)) long a64l(char const   *__s )  __attribute__((__pure__,
__nonnull__(1))) ;
extern int select(int __nfds , fd_set * __restrict  __readfds ,
                  fd_set * __restrict  __writefds ,
                  fd_set * __restrict  __exceptfds ,
                  struct timeval * __restrict  __timeout ) ;
extern int pselect(int __nfds , fd_set * __restrict  __readfds ,
                   fd_set * __restrict  __writefds ,
                   fd_set * __restrict  __exceptfds ,
                   struct timespec  const  * __restrict  __timeout ,
                   __sigset_t const   * __restrict  __sigmask ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_major(unsigned long long __dev ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "71\n");
  fflush(_coverage_fout);
  return ((unsigned int )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_minor(unsigned long long __dev ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "72\n");
  fflush(_coverage_fout);
  return ((unsigned int )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                   unsigned int __minor ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "73\n");
  fflush(_coverage_fout);
  return (((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32));
}
}
extern  __attribute__((__nothrow__)) long random(void) ;
extern  __attribute__((__nothrow__)) void srandom(unsigned int __seed ) ;
extern  __attribute__((__nothrow__)) char *initstate(unsigned int __seed ,
                                                     char *__statebuf ,
                                                     size_t __statelen )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *setstate(char *__statebuf )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int random_r(struct random_data * __restrict  __buf ,
                                                  int32_t * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int srandom_r(unsigned int __seed ,
                                                   struct random_data *__buf )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int initstate_r(unsigned int __seed ,
                                                     char * __restrict  __statebuf ,
                                                     size_t __statelen ,
                                                     struct random_data * __restrict  __buf )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) int setstate_r(char * __restrict  __statebuf ,
                                                    struct random_data * __restrict  __buf )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int rand(void) ;
extern  __attribute__((__nothrow__)) void srand(unsigned int __seed ) ;
extern  __attribute__((__nothrow__)) int rand_r(unsigned int *__seed ) ;
extern  __attribute__((__nothrow__)) double drand48(void) ;
extern  __attribute__((__nothrow__)) double erand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long lrand48(void) ;
extern  __attribute__((__nothrow__)) long nrand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long mrand48(void) ;
extern  __attribute__((__nothrow__)) long jrand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void srand48(long __seedval ) ;
extern  __attribute__((__nothrow__)) unsigned short *seed48(unsigned short *__seed16v )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void lcong48(unsigned short *__param )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int drand48_r(struct drand48_data * __restrict  __buffer ,
                                                   double * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int erand48_r(unsigned short *__xsubi ,
                                                   struct drand48_data * __restrict  __buffer ,
                                                   double * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int lrand48_r(struct drand48_data * __restrict  __buffer ,
                                                   long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int nrand48_r(unsigned short *__xsubi ,
                                                   struct drand48_data * __restrict  __buffer ,
                                                   long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int mrand48_r(struct drand48_data * __restrict  __buffer ,
                                                   long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int jrand48_r(unsigned short *__xsubi ,
                                                   struct drand48_data * __restrict  __buffer ,
                                                   long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int srand48_r(long __seedval ,
                                                   struct drand48_data *__buffer )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int seed48_r(unsigned short *__seed16v ,
                                                  struct drand48_data *__buffer )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int lcong48_r(unsigned short *__param ,
                                                   struct drand48_data *__buffer )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *malloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *calloc(size_t __nmemb ,
                                                  size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *realloc(void *__ptr , size_t __size )  __attribute__((__warn_unused_result__)) ;
extern  __attribute__((__nothrow__)) void free(void *__ptr ) ;
extern  __attribute__((__nothrow__)) void cfree(void *__ptr ) ;
extern  __attribute__((__nothrow__)) void *alloca(size_t __size ) ;
extern  __attribute__((__nothrow__)) void *valloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) int posix_memalign(void **__memptr ,
                                                        size_t __alignment ,
                                                        size_t __size )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__, __noreturn__)) void abort(void) ;
extern  __attribute__((__nothrow__)) int atexit(void (*__func)(void) )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int on_exit(void (*__func)(int __status ,
                                                                void *__arg ) ,
                                                 void *__arg )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__, __noreturn__)) void exit(int __status ) ;
extern  __attribute__((__nothrow__, __noreturn__)) void _Exit(int __status ) ;
extern  __attribute__((__nothrow__)) char *getenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *__secure_getenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int putenv(char *__string )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int setenv(char const   *__name ,
                                                char const   *__value ,
                                                int __replace )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int unsetenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int clearenv(void) ;
extern  __attribute__((__nothrow__)) char *mktemp(char *__template )  __attribute__((__nonnull__(1))) ;
extern int mkstemp(char *__template )  __asm__("mkstemp64") __attribute__((__nonnull__(1))) ;
extern int mkstemps(char *__template , int __suffixlen )  __asm__("mkstemps64") __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *mkdtemp(char *__template )  __attribute__((__nonnull__(1))) ;
extern int system(char const   *__command ) ;
extern  __attribute__((__nothrow__)) char *realpath(char const   * __restrict  __name ,
                                                    char * __restrict  __resolved ) ;
extern void *bsearch(void const   *__key , void const   *__base ,
                     size_t __nmemb , size_t __size ,
                     int (*__compar)(void const   * , void const   * ) )  __attribute__((__nonnull__(1,2,5))) ;
extern void qsort(void *__base , size_t __nmemb , size_t __size ,
                  int (*__compar)(void const   * , void const   * ) )  __attribute__((__nonnull__(1,4))) ;
extern  __attribute__((__nothrow__)) int abs(int __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long labs(long __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long long llabs(long long __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) div_t div(int __numer , int __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) ldiv_t ldiv(long __numer , long __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) lldiv_t lldiv(long long __numer ,
                                                   long long __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) char *ecvt(double __value , int __ndigit ,
                                                int * __restrict  __decpt ,
                                                int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *fcvt(double __value , int __ndigit ,
                                                int * __restrict  __decpt ,
                                                int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *gcvt(double __value , int __ndigit ,
                                                char *__buf )  __attribute__((__nonnull__(3))) ;
extern  __attribute__((__nothrow__)) char *qecvt(long double __value ,
                                                 int __ndigit ,
                                                 int * __restrict  __decpt ,
                                                 int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *qfcvt(long double __value ,
                                                 int __ndigit ,
                                                 int * __restrict  __decpt ,
                                                 int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *qgcvt(long double __value ,
                                                 int __ndigit , char *__buf )  __attribute__((__nonnull__(3))) ;
extern  __attribute__((__nothrow__)) int ecvt_r(double __value , int __ndigit ,
                                                int * __restrict  __decpt ,
                                                int * __restrict  __sign ,
                                                char * __restrict  __buf ,
                                                size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int fcvt_r(double __value , int __ndigit ,
                                                int * __restrict  __decpt ,
                                                int * __restrict  __sign ,
                                                char * __restrict  __buf ,
                                                size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int qecvt_r(long double __value ,
                                                 int __ndigit ,
                                                 int * __restrict  __decpt ,
                                                 int * __restrict  __sign ,
                                                 char * __restrict  __buf ,
                                                 size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int qfcvt_r(long double __value ,
                                                 int __ndigit ,
                                                 int * __restrict  __decpt ,
                                                 int * __restrict  __sign ,
                                                 char * __restrict  __buf ,
                                                 size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int mblen(char const   *__s , size_t __n ) ;
extern  __attribute__((__nothrow__)) int mbtowc(wchar_t * __restrict  __pwc ,
                                                char const   * __restrict  __s ,
                                                size_t __n ) ;
extern  __attribute__((__nothrow__)) int wctomb(char *__s , wchar_t __wchar ) ;
extern  __attribute__((__nothrow__)) size_t mbstowcs(wchar_t * __restrict  __pwcs ,
                                                     char const   * __restrict  __s ,
                                                     size_t __n ) ;
extern  __attribute__((__nothrow__)) size_t wcstombs(char * __restrict  __s ,
                                                     wchar_t const   * __restrict  __pwcs ,
                                                     size_t __n ) ;
extern  __attribute__((__nothrow__)) int rpmatch(char const   *__response )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int getsubopt(char ** __restrict  __optionp ,
                                                   char * const  * __restrict  __tokens ,
                                                   char ** __restrict  __valuep )  __attribute__((__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) int getloadavg(double *__loadavg ,
                                                    int __nelem )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void *memcpy(void * __restrict  __dest ,
                                                  void const   * __restrict  __src ,
                                                  size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memmove(void *__dest ,
                                                   void const   *__src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memccpy(void * __restrict  __dest ,
                                                   void const   * __restrict  __src ,
                                                   int __c , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memset(void *__s , int __c ,
                                                  size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int memcmp(void const   *__s1 ,
                                                void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memchr(void const   *__s , int __c ,
                                                  size_t __n )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strcat(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncat(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcmp(char const   *__s1 ,
                                                char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncmp(char const   *__s1 ,
                                                 char const   *__s2 ,
                                                 size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcoll(char const   *__s1 ,
                                                 char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm(char * __restrict  __dest ,
                                                    char const   * __restrict  __src ,
                                                    size_t __n )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int strcoll_l(char const   *__s1 ,
                                                   char const   *__s2 ,
                                                   __locale_t __l )  __attribute__((__pure__,
__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm_l(char *__dest ,
                                                      char const   *__src ,
                                                      size_t __n ,
                                                      __locale_t __l )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) char *strdup(char const   *__s )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strndup(char const   *__string ,
                                                   size_t __n )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strrchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strcspn(char const   *__s ,
                                                    char const   *__reject )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strspn(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strpbrk(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strstr(char const   *__haystack ,
                                                  char const   *__needle )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strtok(char * __restrict  __s ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *__strtok_r(char * __restrict  __s ,
                                                      char const   * __restrict  __delim ,
                                                      char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) char *strtok_r(char * __restrict  __s ,
                                                    char const   * __restrict  __delim ,
                                                    char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) size_t strlen(char const   *__s )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strnlen(char const   *__string ,
                                                    size_t __maxlen )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strerror(int __errnum ) ;
extern  __attribute__((__nothrow__)) int strerror_r(int __errnum , char *__buf ,
                                                    size_t __buflen )  __asm__("__xpg_strerror_r") __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *strerror_l(int __errnum ,
                                                      __locale_t __l ) ;
extern  __attribute__((__nothrow__)) void __bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void bcopy(void const   *__src ,
                                                void *__dest , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int bcmp(void const   *__s1 ,
                                              void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *index(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *rindex(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int ffs(int __i )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int strcasecmp(char const   *__s1 ,
                                                    char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncasecmp(char const   *__s1 ,
                                                     char const   *__s2 ,
                                                     size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsep(char ** __restrict  __stringp ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsignal(int __sig ) ;
extern  __attribute__((__nothrow__)) char *__stpcpy(char * __restrict  __dest ,
                                                    char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *__stpncpy(char * __restrict  __dest ,
                                                     char const   * __restrict  __src ,
                                                     size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern void *__rawmemchr(void const   *__s , int __c ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "78\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "79\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "76\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "75\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject) {
        fprintf(_coverage_fout, "74\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "77\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "80\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) ;
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "86\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "87\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "84\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "83\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        fprintf(_coverage_fout, "82\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          fprintf(_coverage_fout, "81\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "85\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "88\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) ;
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "95\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "96\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "93\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "92\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        fprintf(_coverage_fout, "91\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          fprintf(_coverage_fout, "90\n");
          fflush(_coverage_fout);
          if ((int const   )*(__s + __result) != (int const   )__reject3) {
            fprintf(_coverage_fout, "89\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "94\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "97\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) ;
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "101\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "102\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "99\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept) {
      fprintf(_coverage_fout, "98\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "100\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "103\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "109\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "110\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "107\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      fprintf(_coverage_fout, "104\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "106\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        fprintf(_coverage_fout, "105\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    }
    fprintf(_coverage_fout, "108\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "111\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "119\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "120\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "117\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      fprintf(_coverage_fout, "112\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "116\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        fprintf(_coverage_fout, "113\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "115\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) == (int const   )__accept3) {
          fprintf(_coverage_fout, "114\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      }
    }
    fprintf(_coverage_fout, "118\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "121\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "129\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "125\n");
    fflush(_coverage_fout);
    if ((int const   )*__s != 0) {
      fprintf(_coverage_fout, "124\n");
      fflush(_coverage_fout);
      if ((int const   )*__s != (int const   )__accept1) {
        fprintf(_coverage_fout, "123\n");
        fflush(_coverage_fout);
        if ((int const   )*__s != (int const   )__accept2) {
          fprintf(_coverage_fout, "122\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "126\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "130\n");
  fflush(_coverage_fout);
  if ((int const   )*__s == 0) {
    fprintf(_coverage_fout, "127\n");
    fflush(_coverage_fout);
    tmp = (char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "128\n");
    fflush(_coverage_fout);
    tmp = (char *)((unsigned int )__s);
  }
  fprintf(_coverage_fout, "131\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "140\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "136\n");
    fflush(_coverage_fout);
    if ((int const   )*__s != 0) {
      fprintf(_coverage_fout, "135\n");
      fflush(_coverage_fout);
      if ((int const   )*__s != (int const   )__accept1) {
        fprintf(_coverage_fout, "134\n");
        fflush(_coverage_fout);
        if ((int const   )*__s != (int const   )__accept2) {
          fprintf(_coverage_fout, "133\n");
          fflush(_coverage_fout);
          if ((int const   )*__s != (int const   )__accept3) {
            fprintf(_coverage_fout, "132\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "137\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "141\n");
  fflush(_coverage_fout);
  if ((int const   )*__s == 0) {
    fprintf(_coverage_fout, "138\n");
    fflush(_coverage_fout);
    tmp = (char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "139\n");
    fflush(_coverage_fout);
    tmp = (char *)((unsigned int )__s);
  }
  fprintf(_coverage_fout, "142\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) ;
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) 
{ char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "160\n");
  fflush(_coverage_fout);
  if ((unsigned int )__s == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "143\n");
    fflush(_coverage_fout);
    __s = *__nextp;
  } else {
    fprintf(_coverage_fout, "144\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "161\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "146\n");
    fflush(_coverage_fout);
    if ((int )*__s == (int )__sep) {
      fprintf(_coverage_fout, "145\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "147\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "162\n");
  fflush(_coverage_fout);
  __result = (char *)((void *)0);
  fprintf(_coverage_fout, "163\n");
  fflush(_coverage_fout);
  if ((int )*__s != 0) {
    fprintf(_coverage_fout, "155\n");
    fflush(_coverage_fout);
    tmp = __s;
    fprintf(_coverage_fout, "156\n");
    fflush(_coverage_fout);
    __s ++;
    fprintf(_coverage_fout, "157\n");
    fflush(_coverage_fout);
    __result = tmp;
    fprintf(_coverage_fout, "158\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "151\n");
      fflush(_coverage_fout);
      if ((int )*__s != 0) {
        fprintf(_coverage_fout, "148\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "152\n");
      fflush(_coverage_fout);
      tmp___0 = __s;
      fprintf(_coverage_fout, "153\n");
      fflush(_coverage_fout);
      __s ++;
      fprintf(_coverage_fout, "154\n");
      fflush(_coverage_fout);
      if ((int )*tmp___0 == (int )__sep) {
        fprintf(_coverage_fout, "149\n");
        fflush(_coverage_fout);
        *(__s + -1) = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "150\n");
        fflush(_coverage_fout);

      }
    }
  } else {
    fprintf(_coverage_fout, "159\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "164\n");
  fflush(_coverage_fout);
  *__nextp = __s;
  fprintf(_coverage_fout, "165\n");
  fflush(_coverage_fout);
  return (__result);
}
}
extern char *__strsep_g(char **__stringp , char const   *__delim ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) 
{ register char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  void *tmp___1 ;
  char *tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "175\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "176\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "170\n");
    fflush(_coverage_fout);
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    fprintf(_coverage_fout, "171\n");
    fflush(_coverage_fout);
    tmp___0 = tmp___2;
    fprintf(_coverage_fout, "172\n");
    fflush(_coverage_fout);
    *__s = tmp___0;
    fprintf(_coverage_fout, "173\n");
    fflush(_coverage_fout);
    if ((unsigned int )tmp___0 != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "166\n");
      fflush(_coverage_fout);
      tmp = *__s;
      fprintf(_coverage_fout, "167\n");
      fflush(_coverage_fout);
      (*__s) ++;
      fprintf(_coverage_fout, "168\n");
      fflush(_coverage_fout);
      *tmp = (char )'\000';
    } else {
      fprintf(_coverage_fout, "169\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "174\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "177\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) ;
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "195\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "196\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "191\n");
    fflush(_coverage_fout);
    __cp = __retval;
    fprintf(_coverage_fout, "192\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "188\n");
      fflush(_coverage_fout);
      if ((int )*__cp == 0) {
        fprintf(_coverage_fout, "178\n");
        fflush(_coverage_fout);
        __cp = (char *)((void *)0);
        break;
      } else {
        fprintf(_coverage_fout, "179\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "189\n");
      fflush(_coverage_fout);
      if ((int )*__cp == (int )__reject1) {
        fprintf(_coverage_fout, "180\n");
        fflush(_coverage_fout);
        tmp = __cp;
        fprintf(_coverage_fout, "181\n");
        fflush(_coverage_fout);
        __cp ++;
        fprintf(_coverage_fout, "182\n");
        fflush(_coverage_fout);
        *tmp = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "187\n");
        fflush(_coverage_fout);
        if ((int )*__cp == (int )__reject2) {
          fprintf(_coverage_fout, "183\n");
          fflush(_coverage_fout);
          tmp = __cp;
          fprintf(_coverage_fout, "184\n");
          fflush(_coverage_fout);
          __cp ++;
          fprintf(_coverage_fout, "185\n");
          fflush(_coverage_fout);
          *tmp = (char )'\000';
          break;
        } else {
          fprintf(_coverage_fout, "186\n");
          fflush(_coverage_fout);

        }
      }
      fprintf(_coverage_fout, "190\n");
      fflush(_coverage_fout);
      __cp ++;
    }
    fprintf(_coverage_fout, "193\n");
    fflush(_coverage_fout);
    *__s = __cp;
  } else {
    fprintf(_coverage_fout, "194\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "197\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) ;
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "219\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "220\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "215\n");
    fflush(_coverage_fout);
    __cp = __retval;
    fprintf(_coverage_fout, "216\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "212\n");
      fflush(_coverage_fout);
      if ((int )*__cp == 0) {
        fprintf(_coverage_fout, "198\n");
        fflush(_coverage_fout);
        __cp = (char *)((void *)0);
        break;
      } else {
        fprintf(_coverage_fout, "199\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "213\n");
      fflush(_coverage_fout);
      if ((int )*__cp == (int )__reject1) {
        fprintf(_coverage_fout, "200\n");
        fflush(_coverage_fout);
        tmp = __cp;
        fprintf(_coverage_fout, "201\n");
        fflush(_coverage_fout);
        __cp ++;
        fprintf(_coverage_fout, "202\n");
        fflush(_coverage_fout);
        *tmp = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "211\n");
        fflush(_coverage_fout);
        if ((int )*__cp == (int )__reject2) {
          fprintf(_coverage_fout, "203\n");
          fflush(_coverage_fout);
          tmp = __cp;
          fprintf(_coverage_fout, "204\n");
          fflush(_coverage_fout);
          __cp ++;
          fprintf(_coverage_fout, "205\n");
          fflush(_coverage_fout);
          *tmp = (char )'\000';
          break;
        } else {
          fprintf(_coverage_fout, "210\n");
          fflush(_coverage_fout);
          if ((int )*__cp == (int )__reject3) {
            fprintf(_coverage_fout, "206\n");
            fflush(_coverage_fout);
            tmp = __cp;
            fprintf(_coverage_fout, "207\n");
            fflush(_coverage_fout);
            __cp ++;
            fprintf(_coverage_fout, "208\n");
            fflush(_coverage_fout);
            *tmp = (char )'\000';
            break;
          } else {
            fprintf(_coverage_fout, "209\n");
            fflush(_coverage_fout);

          }
        }
      }
      fprintf(_coverage_fout, "214\n");
      fflush(_coverage_fout);
      __cp ++;
    }
    fprintf(_coverage_fout, "217\n");
    fflush(_coverage_fout);
    *__s = __cp;
  } else {
    fprintf(_coverage_fout, "218\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "221\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
extern  __attribute__((__nothrow__)) char *__strdup(char const   *__string )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strndup(char const   *__string ,
                                                     size_t __n )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) unsigned short const   **__ctype_b_loc(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) __int32_t const   **__ctype_tolower_loc(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) __int32_t const   **__ctype_toupper_loc(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int isalnum(int  ) ;
extern  __attribute__((__nothrow__)) int isalpha(int  ) ;
extern  __attribute__((__nothrow__)) int iscntrl(int  ) ;
extern  __attribute__((__nothrow__)) int isdigit(int  ) ;
extern  __attribute__((__nothrow__)) int islower(int  ) ;
extern  __attribute__((__nothrow__)) int isgraph(int  ) ;
extern  __attribute__((__nothrow__)) int isprint(int  ) ;
extern  __attribute__((__nothrow__)) int ispunct(int  ) ;
extern  __attribute__((__nothrow__)) int isspace(int  ) ;
extern  __attribute__((__nothrow__)) int isupper(int  ) ;
extern  __attribute__((__nothrow__)) int isxdigit(int  ) ;
__inline extern  __attribute__((__nothrow__)) int tolower(int __c ) ;
__inline extern  __attribute__((__nothrow__)) int toupper(int __c ) ;
extern  __attribute__((__nothrow__)) int isblank(int  ) ;
extern  __attribute__((__nothrow__)) int isascii(int __c ) ;
extern  __attribute__((__nothrow__)) int toascii(int __c ) ;
extern  __attribute__((__nothrow__)) int _toupper(int  ) ;
extern  __attribute__((__nothrow__)) int _tolower(int  ) ;
__inline extern  __attribute__((__nothrow__)) int tolower(int __c ) ;
__inline extern int tolower(int __c ) 
{ __int32_t const   **tmp ;
  __int32_t tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "227\n");
  fflush(_coverage_fout);
  if (__c >= -128) {
    fprintf(_coverage_fout, "225\n");
    fflush(_coverage_fout);
    if (__c < 256) {
      fprintf(_coverage_fout, "222\n");
      fflush(_coverage_fout);
      tmp = __ctype_tolower_loc();
      fprintf(_coverage_fout, "223\n");
      fflush(_coverage_fout);
      tmp___0 = *(*tmp + __c);
    } else {
      fprintf(_coverage_fout, "224\n");
      fflush(_coverage_fout);
      tmp___0 = (int const   )__c;
    }
  } else {
    fprintf(_coverage_fout, "226\n");
    fflush(_coverage_fout);
    tmp___0 = (int const   )__c;
  }
  fprintf(_coverage_fout, "228\n");
  fflush(_coverage_fout);
  return ((int )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int toupper(int __c ) ;
__inline extern int toupper(int __c ) 
{ __int32_t const   **tmp ;
  __int32_t tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "234\n");
  fflush(_coverage_fout);
  if (__c >= -128) {
    fprintf(_coverage_fout, "232\n");
    fflush(_coverage_fout);
    if (__c < 256) {
      fprintf(_coverage_fout, "229\n");
      fflush(_coverage_fout);
      tmp = __ctype_toupper_loc();
      fprintf(_coverage_fout, "230\n");
      fflush(_coverage_fout);
      tmp___0 = *(*tmp + __c);
    } else {
      fprintf(_coverage_fout, "231\n");
      fflush(_coverage_fout);
      tmp___0 = (int const   )__c;
    }
  } else {
    fprintf(_coverage_fout, "233\n");
    fflush(_coverage_fout);
    tmp___0 = (int const   )__c;
  }
  fprintf(_coverage_fout, "235\n");
  fflush(_coverage_fout);
  return ((int )tmp___0);
}
}
extern  __attribute__((__nothrow__)) int isalnum_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isalpha_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int iscntrl_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isdigit_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int islower_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isgraph_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isprint_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int ispunct_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isspace_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isupper_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isxdigit_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isblank_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int __tolower_l(int __c , __locale_t __l ) ;
extern  __attribute__((__nothrow__)) int tolower_l(int __c , __locale_t __l ) ;
extern  __attribute__((__nothrow__)) int __toupper_l(int __c , __locale_t __l ) ;
extern  __attribute__((__nothrow__)) int toupper_l(int __c , __locale_t __l ) ;
extern  __attribute__((__nothrow__)) clock_t clock(void) ;
extern  __attribute__((__nothrow__)) time_t time(time_t *__timer ) ;
extern  __attribute__((__nothrow__)) double difftime(time_t __time1 ,
                                                     time_t __time0 )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) time_t mktime(struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) size_t strftime(char * __restrict  __s ,
                                                     size_t __maxsize ,
                                                     char const   * __restrict  __format ,
                                                     struct tm  const  * __restrict  __tp ) ;
extern  __attribute__((__nothrow__)) size_t strftime_l(char * __restrict  __s ,
                                                       size_t __maxsize ,
                                                       char const   * __restrict  __format ,
                                                       struct tm  const  * __restrict  __tp ,
                                                       __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) struct tm *gmtime(time_t const   *__timer ) ;
extern  __attribute__((__nothrow__)) struct tm *localtime(time_t const   *__timer ) ;
extern  __attribute__((__nothrow__)) struct tm *gmtime_r(time_t const   * __restrict  __timer ,
                                                         struct tm * __restrict  __tp ) ;
extern  __attribute__((__nothrow__)) struct tm *localtime_r(time_t const   * __restrict  __timer ,
                                                            struct tm * __restrict  __tp ) ;
extern  __attribute__((__nothrow__)) char *asctime(struct tm  const  *__tp ) ;
extern  __attribute__((__nothrow__)) char *ctime(time_t const   *__timer ) ;
extern  __attribute__((__nothrow__)) char *asctime_r(struct tm  const  * __restrict  __tp ,
                                                     char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) char *ctime_r(time_t const   * __restrict  __timer ,
                                                   char * __restrict  __buf ) ;
extern char *__tzname[2] ;
extern int __daylight ;
extern long __timezone ;
extern char *tzname[2] ;
extern  __attribute__((__nothrow__)) void tzset(void) ;
extern int daylight ;
extern long timezone ;
extern  __attribute__((__nothrow__)) int stime(time_t const   *__when ) ;
extern  __attribute__((__nothrow__)) time_t timegm(struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) time_t timelocal(struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) int dysize(int __year )  __attribute__((__const__)) ;
extern int nanosleep(struct timespec  const  *__requested_time ,
                     struct timespec *__remaining ) ;
extern  __attribute__((__nothrow__)) int clock_getres(clockid_t __clock_id ,
                                                      struct timespec *__res ) ;
extern  __attribute__((__nothrow__)) int clock_gettime(clockid_t __clock_id ,
                                                       struct timespec *__tp ) ;
extern  __attribute__((__nothrow__)) int clock_settime(clockid_t __clock_id ,
                                                       struct timespec  const  *__tp ) ;
extern int clock_nanosleep(clockid_t __clock_id , int __flags ,
                           struct timespec  const  *__req ,
                           struct timespec *__rem ) ;
extern  __attribute__((__nothrow__)) int clock_getcpuclockid(pid_t __pid ,
                                                             clockid_t *__clock_id ) ;
extern  __attribute__((__nothrow__)) int timer_create(clockid_t __clock_id ,
                                                      struct sigevent * __restrict  __evp ,
                                                      timer_t * __restrict  __timerid ) ;
extern  __attribute__((__nothrow__)) int timer_delete(timer_t __timerid ) ;
extern  __attribute__((__nothrow__)) int timer_settime(timer_t __timerid ,
                                                       int __flags ,
                                                       struct itimerspec  const  * __restrict  __value ,
                                                       struct itimerspec * __restrict  __ovalue ) ;
extern  __attribute__((__nothrow__)) int timer_gettime(timer_t __timerid ,
                                                       struct itimerspec *__value ) ;
extern  __attribute__((__nothrow__)) int timer_getoverrun(timer_t __timerid ) ;
extern  __attribute__((__nothrow__)) int *__errno_location(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int access(char const   *__name ,
                                                int __type )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int faccessat(int __fd ,
                                                   char const   *__file ,
                                                   int __type , int __flag )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) __off64_t lseek(int __fd ,
                                                     __off64_t __offset ,
                                                     int __whence )  __asm__("lseek64")  ;
extern int close(int __fd ) ;
extern ssize_t read(int __fd , void *__buf , size_t __nbytes ) ;
extern ssize_t write(int __fd , void const   *__buf , size_t __n ) ;
extern ssize_t pread(int __fd , void *__buf , size_t __nbytes ,
                     __off64_t __offset )  __asm__("pread64")  ;
extern ssize_t pwrite(int __fd , void const   *__buf , size_t __nbytes ,
                      __off64_t __offset )  __asm__("pwrite64")  ;
extern  __attribute__((__nothrow__)) int pipe(int *__pipedes ) ;
extern  __attribute__((__nothrow__)) unsigned int alarm(unsigned int __seconds ) ;
extern unsigned int sleep(unsigned int __seconds ) ;
extern  __attribute__((__nothrow__)) __useconds_t ualarm(__useconds_t __value ,
                                                         __useconds_t __interval ) ;
extern int usleep(__useconds_t __useconds ) ;
extern int pause(void) ;
extern  __attribute__((__nothrow__)) int chown(char const   *__file ,
                                               __uid_t __owner ,
                                               __gid_t __group )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int fchown(int __fd , __uid_t __owner ,
                                                __gid_t __group ) ;
extern  __attribute__((__nothrow__)) int lchown(char const   *__file ,
                                                __uid_t __owner ,
                                                __gid_t __group )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int fchownat(int __fd ,
                                                  char const   *__file ,
                                                  __uid_t __owner ,
                                                  __gid_t __group , int __flag )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int chdir(char const   *__path )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int fchdir(int __fd ) ;
extern  __attribute__((__nothrow__)) char *getcwd(char *__buf , size_t __size ) ;
extern  __attribute__((__nothrow__)) char *getwd(char *__buf )  __attribute__((__nonnull__(1),
__deprecated__)) ;
extern  __attribute__((__nothrow__)) int dup(int __fd ) ;
extern  __attribute__((__nothrow__)) int dup2(int __fd , int __fd2 ) ;
extern char **__environ ;
extern  __attribute__((__nothrow__)) int execve(char const   *__path ,
                                                char * const  *__argv ,
                                                char * const  *__envp )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int fexecve(int __fd ,
                                                 char * const  *__argv ,
                                                 char * const  *__envp )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int execv(char const   *__path ,
                                               char * const  *__argv )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execle(char const   *__path ,
                                                char const   *__arg  , ...)  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execl(char const   *__path ,
                                               char const   *__arg  , ...)  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execvp(char const   *__file ,
                                                char * const  *__argv )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execlp(char const   *__file ,
                                                char const   *__arg  , ...)  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int nice(int __inc ) ;
extern  __attribute__((__noreturn__)) void _exit(int __status ) ;
extern  __attribute__((__nothrow__)) long pathconf(char const   *__path ,
                                                   int __name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long fpathconf(int __fd , int __name ) ;
extern  __attribute__((__nothrow__)) long sysconf(int __name ) ;
extern  __attribute__((__nothrow__)) size_t confstr(int __name , char *__buf ,
                                                    size_t __len ) ;
extern  __attribute__((__nothrow__)) __pid_t getpid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getppid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getpgrp(void) ;
extern  __attribute__((__nothrow__)) __pid_t __getpgid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) __pid_t getpgid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) int setpgid(__pid_t __pid , __pid_t __pgid ) ;
extern  __attribute__((__nothrow__)) int setpgrp(void) ;
extern  __attribute__((__nothrow__)) __pid_t setsid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getsid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) __uid_t getuid(void) ;
extern  __attribute__((__nothrow__)) __uid_t geteuid(void) ;
extern  __attribute__((__nothrow__)) __gid_t getgid(void) ;
extern  __attribute__((__nothrow__)) __gid_t getegid(void) ;
extern  __attribute__((__nothrow__)) int getgroups(int __size , __gid_t *__list ) ;
extern  __attribute__((__nothrow__)) int setuid(__uid_t __uid ) ;
extern  __attribute__((__nothrow__)) int setreuid(__uid_t __ruid ,
                                                  __uid_t __euid ) ;
extern  __attribute__((__nothrow__)) int seteuid(__uid_t __uid ) ;
extern  __attribute__((__nothrow__)) int setgid(__gid_t __gid ) ;
extern  __attribute__((__nothrow__)) int setregid(__gid_t __rgid ,
                                                  __gid_t __egid ) ;
extern  __attribute__((__nothrow__)) int setegid(__gid_t __gid ) ;
extern  __attribute__((__nothrow__)) __pid_t fork(void) ;
extern  __attribute__((__nothrow__)) __pid_t vfork(void) ;
extern  __attribute__((__nothrow__)) char *ttyname(int __fd ) ;
extern  __attribute__((__nothrow__)) int ttyname_r(int __fd , char *__buf ,
                                                   size_t __buflen )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int isatty(int __fd ) ;
extern  __attribute__((__nothrow__)) int ttyslot(void) ;
extern  __attribute__((__nothrow__)) int link(char const   *__from ,
                                              char const   *__to )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int linkat(int __fromfd ,
                                                char const   *__from ,
                                                int __tofd ,
                                                char const   *__to ,
                                                int __flags )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) int symlink(char const   *__from ,
                                                 char const   *__to )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) ssize_t readlink(char const   * __restrict  __path ,
                                                      char * __restrict  __buf ,
                                                      size_t __len )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int symlinkat(char const   *__from ,
                                                   int __tofd ,
                                                   char const   *__to )  __attribute__((__nonnull__(1,3))) ;
extern  __attribute__((__nothrow__)) ssize_t readlinkat(int __fd ,
                                                        char const   * __restrict  __path ,
                                                        char * __restrict  __buf ,
                                                        size_t __len )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) int unlink(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int unlinkat(int __fd ,
                                                  char const   *__name ,
                                                  int __flag )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int rmdir(char const   *__path )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) __pid_t tcgetpgrp(int __fd ) ;
extern  __attribute__((__nothrow__)) int tcsetpgrp(int __fd , __pid_t __pgrp_id ) ;
extern char *getlogin(void) ;
extern int getlogin_r(char *__name , size_t __name_len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int setlogin(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern char *optarg ;
extern int optind ;
extern int opterr ;
extern int optopt ;
extern  __attribute__((__nothrow__)) int getopt(int ___argc ,
                                                char * const  *___argv ,
                                                char const   *__shortopts ) ;
extern  __attribute__((__nothrow__)) int gethostname(char *__name ,
                                                     size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int sethostname(char const   *__name ,
                                                     size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int sethostid(long __id ) ;
extern  __attribute__((__nothrow__)) int getdomainname(char *__name ,
                                                       size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int setdomainname(char const   *__name ,
                                                       size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int vhangup(void) ;
extern  __attribute__((__nothrow__)) int revoke(char const   *__file )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int profil(unsigned short *__sample_buffer ,
                                                size_t __size ,
                                                size_t __offset ,
                                                unsigned int __scale )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int acct(char const   *__name ) ;
extern  __attribute__((__nothrow__)) char *getusershell(void) ;
extern  __attribute__((__nothrow__)) void endusershell(void) ;
extern  __attribute__((__nothrow__)) void setusershell(void) ;
extern  __attribute__((__nothrow__)) int daemon(int __nochdir , int __noclose ) ;
extern  __attribute__((__nothrow__)) int chroot(char const   *__path )  __attribute__((__nonnull__(1))) ;
extern char *getpass(char const   *__prompt )  __attribute__((__nonnull__(1))) ;
extern int fsync(int __fd ) ;
extern long gethostid(void) ;
extern  __attribute__((__nothrow__)) void sync(void) ;
extern  __attribute__((__nothrow__)) int getpagesize(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int getdtablesize(void) ;
extern  __attribute__((__nothrow__)) int truncate(char const   *__file ,
                                                  __off64_t __length )  __asm__("truncate64") __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int ftruncate(int __fd ,
                                                   __off64_t __length )  __asm__("ftruncate64")  ;
extern  __attribute__((__nothrow__)) int brk(void *__addr ) ;
extern  __attribute__((__nothrow__)) void *sbrk(intptr_t __delta ) ;
extern  __attribute__((__nothrow__)) long syscall(long __sysno  , ...) ;
extern int lockf(int __fd , int __cmd , __off64_t __len )  __asm__("lockf64")  ;
extern int fdatasync(int __fildes ) ;
extern int fcntl(int __fd , int __cmd  , ...) ;
extern int open(char const   *__file , int __oflag  , ...)  __asm__("open64") __attribute__((__nonnull__(1))) ;
extern int openat(int __fd , char const   *__file , int __oflag  , ...)  __asm__("openat64") __attribute__((__nonnull__(2))) ;
extern int creat(char const   *__file , __mode_t __mode )  __asm__("creat64") __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int posix_fadvise(int __fd ,
                                                       __off64_t __offset ,
                                                       __off64_t __len ,
                                                       int __advise )  __asm__("posix_fadvise64")  ;
extern int posix_fallocate(int __fd , __off64_t __offset , __off64_t __len )  __asm__("posix_fallocate64")  ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_fail(char const   *__assertion ,
                                  char const   *__file , unsigned int __line ,
                                  char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_perror_fail(int __errnum , char const   *__file ,
                                         unsigned int __line ,
                                         char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert(char const   *__assertion , char const   *__file ,
                             int __line ) ;
extern  __attribute__((__nothrow__)) void insque(void *__elem , void *__prev ) ;
extern  __attribute__((__nothrow__)) void remque(void *__elem ) ;
extern  __attribute__((__nothrow__)) ENTRY *hsearch(ENTRY __item ,
                                                    ACTION __action ) ;
extern  __attribute__((__nothrow__)) int hcreate(size_t __nel ) ;
extern  __attribute__((__nothrow__)) void hdestroy(void) ;
extern void *tsearch(void const   *__key , void **__rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void *tfind(void const   *__key , void * const  *__rootp ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *tdelete(void const   * __restrict  __key ,
                     void ** __restrict  __rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void twalk(void const   *__root ,
                  void (*__action)(void const   *__nodep , VISIT __value ,
                                   int __level ) ) ;
extern void *lfind(void const   *__key , void const   *__base ,
                   size_t *__nmemb , size_t __size ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *lsearch(void const   *__key , void *__base , size_t *__nmemb ,
                     size_t __size , int (*__compar)(void const   * ,
                                                     void const   * ) ) ;
extern char const   *TIFFGetVersion(void) ;
extern TIFFCodec const   *TIFFFindCODEC(uint16  ) ;
extern TIFFCodec *TIFFRegisterCODEC(uint16  , char const   * ,
                                    int (*)(TIFF * , int  ) ) ;
extern void TIFFUnRegisterCODEC(TIFFCodec * ) ;
extern int TIFFIsCODECConfigured(uint16  ) ;
extern TIFFCodec *TIFFGetConfiguredCODECs(void) ;
extern void *_TIFFmalloc(tmsize_t s ) ;
extern void *_TIFFrealloc(void *p , tmsize_t s ) ;
extern void _TIFFmemset(void *p , int v , tmsize_t c ) ;
extern void _TIFFmemcpy(void *d , void const   *s , tmsize_t c ) ;
extern int _TIFFmemcmp(void const   *p1 , void const   *p2 , tmsize_t c ) ;
extern void _TIFFfree(void *p ) ;
extern int TIFFGetTagListCount(TIFF * ) ;
extern uint32 TIFFGetTagListEntry(TIFF * , int tag_index ) ;
extern TIFFField const   *TIFFFindField(TIFF * , uint32  , TIFFDataType  ) ;
extern TIFFField const   *TIFFFieldWithTag(TIFF * , uint32  ) ;
extern TIFFField const   *TIFFFieldWithName(TIFF * , char const   * ) ;
extern TIFFTagMethods *TIFFAccessTagMethods(TIFF * ) ;
extern void *TIFFGetClientInfo(TIFF * , char const   * ) ;
extern void TIFFSetClientInfo(TIFF * , void * , char const   * ) ;
extern void TIFFCleanup(TIFF *tif ) ;
extern void TIFFClose(TIFF *tif ) ;
extern int TIFFFlush(TIFF *tif ) ;
extern int TIFFFlushData(TIFF *tif ) ;
extern int TIFFGetField(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFVGetField(TIFF *tif , uint32 tag , va_list ap ) ;
extern int TIFFGetFieldDefaulted(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFVGetFieldDefaulted(TIFF *tif , uint32 tag , va_list ap ) ;
extern int TIFFReadDirectory(TIFF *tif ) ;
extern int TIFFReadCustomDirectory(TIFF *tif , toff_t diroff ,
                                   TIFFFieldArray const   *infoarray ) ;
extern int TIFFReadEXIFDirectory(TIFF *tif , toff_t diroff ) ;
extern uint64 TIFFScanlineSize64(TIFF *tif ) ;
extern tmsize_t TIFFScanlineSize(TIFF *tif ) ;
extern uint64 TIFFRasterScanlineSize64(TIFF *tif ) ;
extern tmsize_t TIFFRasterScanlineSize(TIFF *tif ) ;
extern uint64 TIFFStripSize64(TIFF *tif ) ;
extern tmsize_t TIFFStripSize(TIFF *tif ) ;
extern uint64 TIFFRawStripSize64(TIFF *tif , uint32 strip ) ;
extern tmsize_t TIFFRawStripSize(TIFF *tif , uint32 strip ) ;
extern uint64 TIFFVStripSize64(TIFF *tif , uint32 nrows ) ;
extern tmsize_t TIFFVStripSize(TIFF *tif , uint32 nrows ) ;
extern uint64 TIFFTileRowSize64(TIFF *tif ) ;
extern tmsize_t TIFFTileRowSize(TIFF *tif ) ;
extern uint64 TIFFTileSize64(TIFF *tif ) ;
extern tmsize_t TIFFTileSize(TIFF *tif ) ;
extern uint64 TIFFVTileSize64(TIFF *tif , uint32 nrows ) ;
extern tmsize_t TIFFVTileSize(TIFF *tif , uint32 nrows ) ;
extern uint32 TIFFDefaultStripSize(TIFF *tif , uint32 request ) ;
extern void TIFFDefaultTileSize(TIFF * , uint32 * , uint32 * ) ;
extern int TIFFFileno(TIFF * ) ;
extern int TIFFSetFileno(TIFF * , int  ) ;
extern thandle_t TIFFClientdata(TIFF * ) ;
extern thandle_t TIFFSetClientdata(TIFF * , thandle_t  ) ;
extern int TIFFGetMode(TIFF * ) ;
extern int TIFFSetMode(TIFF * , int  ) ;
extern int TIFFIsTiled(TIFF * ) ;
extern int TIFFIsByteSwapped(TIFF * ) ;
extern int TIFFIsUpSampled(TIFF * ) ;
extern int TIFFIsMSB2LSB(TIFF * ) ;
extern int TIFFIsBigEndian(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetReadProc(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetWriteProc(TIFF * ) ;
extern TIFFSeekProc TIFFGetSeekProc(TIFF * ) ;
extern TIFFCloseProc TIFFGetCloseProc(TIFF * ) ;
extern TIFFSizeProc TIFFGetSizeProc(TIFF * ) ;
extern TIFFMapFileProc TIFFGetMapFileProc(TIFF * ) ;
extern TIFFUnmapFileProc TIFFGetUnmapFileProc(TIFF * ) ;
extern uint32 TIFFCurrentRow(TIFF * ) ;
extern uint16 TIFFCurrentDirectory(TIFF * ) ;
extern uint16 TIFFNumberOfDirectories(TIFF * ) ;
extern uint64 TIFFCurrentDirOffset(TIFF * ) ;
extern uint32 TIFFCurrentStrip(TIFF * ) ;
extern uint32 TIFFCurrentTile(TIFF *tif ) ;
extern int TIFFReadBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
extern int TIFFWriteBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
extern int TIFFSetupStrips(TIFF * ) ;
extern int TIFFWriteCheck(TIFF * , int  , char const   * ) ;
extern void TIFFFreeDirectory(TIFF * ) ;
extern int TIFFCreateDirectory(TIFF * ) ;
extern int TIFFLastDirectory(TIFF * ) ;
extern int TIFFSetDirectory(TIFF * , uint16  ) ;
extern int TIFFSetSubDirectory(TIFF * , uint64  ) ;
extern int TIFFUnlinkDirectory(TIFF * , uint16  ) ;
extern int TIFFSetField(TIFF * , uint32   , ...) ;
extern int TIFFVSetField(TIFF * , uint32  , va_list  ) ;
extern int TIFFUnsetField(TIFF * , uint32  ) ;
extern int TIFFWriteDirectory(TIFF * ) ;
extern int TIFFCheckpointDirectory(TIFF * ) ;
extern int TIFFRewriteDirectory(TIFF * ) ;
extern void TIFFPrintDirectory(TIFF * , FILE * , long  ) ;
extern int TIFFReadScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) ;
extern int TIFFWriteScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) ;
extern int TIFFReadRGBAImage(TIFF * , uint32  , uint32  , uint32 * , int  ) ;
extern int TIFFReadRGBAImageOriented(TIFF * , uint32  , uint32  , uint32 * ,
                                     int  , int  ) ;
extern int TIFFReadRGBAStrip(TIFF * , uint32  , uint32 * ) ;
extern int TIFFReadRGBATile(TIFF * , uint32  , uint32  , uint32 * ) ;
extern int TIFFRGBAImageOK(TIFF * , char * ) ;
extern int TIFFRGBAImageBegin(TIFFRGBAImage * , TIFF * , int  , char * ) ;
extern int TIFFRGBAImageGet(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
extern void TIFFRGBAImageEnd(TIFFRGBAImage * ) ;
extern TIFF *TIFFOpen(char const   * , char const   * ) ;
extern TIFF *TIFFFdOpen(int  , char const   * , char const   * ) ;
extern TIFF *TIFFClientOpen(char const   * , char const   * , thandle_t  ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            toff_t (*)(thandle_t  , toff_t  , int  ) ,
                            int (*)(thandle_t  ) , toff_t (*)(thandle_t  ) ,
                            int (*)(thandle_t  , void **base , toff_t *size ) ,
                            void (*)(thandle_t  , void *base , toff_t size ) ) ;
extern char const   *TIFFFileName(TIFF * ) ;
extern char const   *TIFFSetFileName(TIFF * , char const   * ) ;
extern void ( /* format attribute */  TIFFError)(char const   * ,
                                                 char const   *  , ...) ;
extern void ( /* format attribute */  TIFFErrorExt)(thandle_t  ,
                                                    char const   * ,
                                                    char const   *  , ...) ;
extern void ( /* format attribute */  TIFFWarning)(char const   * ,
                                                   char const   *  , ...) ;
extern void ( /* format attribute */  TIFFWarningExt)(thandle_t  ,
                                                      char const   * ,
                                                      char const   *  , ...) ;
extern TIFFErrorHandler TIFFSetErrorHandler(void (*)(char const   * ,
                                                     char const   * , va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetErrorHandlerExt(void (*)(thandle_t  ,
                                                           char const   * ,
                                                           char const   * ,
                                                           va_list  ) ) ;
extern TIFFErrorHandler TIFFSetWarningHandler(void (*)(char const   * ,
                                                       char const   * ,
                                                       va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetWarningHandlerExt(void (*)(thandle_t  ,
                                                             char const   * ,
                                                             char const   * ,
                                                             va_list  ) ) ;
extern TIFFExtendProc TIFFSetTagExtender(void (*)(TIFF * ) ) ;
extern uint32 TIFFComputeTile(TIFF *tif , uint32 x , uint32 y , uint32 z ,
                              uint16 s ) ;
extern int TIFFCheckTile(TIFF *tif , uint32 x , uint32 y , uint32 z , uint16 s ) ;
extern uint32 TIFFNumberOfTiles(TIFF * ) ;
extern tmsize_t TIFFReadTile(TIFF *tif , void *buf , uint32 x , uint32 y ,
                             uint32 z , uint16 s ) ;
extern tmsize_t TIFFWriteTile(TIFF *tif , void *buf , uint32 x , uint32 y ,
                              uint32 z , uint16 s ) ;
extern uint32 TIFFComputeStrip(TIFF * , uint32  , uint16  ) ;
extern uint32 TIFFNumberOfStrips(TIFF * ) ;
extern tmsize_t TIFFReadEncodedStrip(TIFF *tif , uint32 strip , void *buf ,
                                     tmsize_t size ) ;
extern tmsize_t TIFFReadRawStrip(TIFF *tif , uint32 strip , void *buf ,
                                 tmsize_t size ) ;
extern tmsize_t TIFFReadEncodedTile(TIFF *tif , uint32 tile , void *buf ,
                                    tmsize_t size ) ;
extern tmsize_t TIFFReadRawTile(TIFF *tif , uint32 tile , void *buf ,
                                tmsize_t size ) ;
extern tmsize_t TIFFWriteEncodedStrip(TIFF *tif , uint32 strip , void *data ,
                                      tmsize_t cc ) ;
extern tmsize_t TIFFWriteRawStrip(TIFF *tif , uint32 strip , void *data ,
                                  tmsize_t cc ) ;
extern tmsize_t TIFFWriteEncodedTile(TIFF *tif , uint32 tile , void *data ,
                                     tmsize_t cc ) ;
extern tmsize_t TIFFWriteRawTile(TIFF *tif , uint32 tile , void *data ,
                                 tmsize_t cc ) ;
extern int TIFFDataWidth(TIFFDataType  ) ;
extern void TIFFSetWriteOffset(TIFF *tif , toff_t off ) ;
extern void TIFFSwabShort(uint16 * ) ;
extern void TIFFSwabLong(uint32 * ) ;
extern void TIFFSwabLong8(uint64 * ) ;
extern void TIFFSwabFloat(float * ) ;
extern void TIFFSwabDouble(double * ) ;
extern void TIFFSwabArrayOfShort(uint16 *wp , tmsize_t n ) ;
extern void TIFFSwabArrayOfTriples(uint8 *tp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong(uint32 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong8(uint64 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfFloat(float *fp , tmsize_t n ) ;
extern void TIFFSwabArrayOfDouble(double *dp , tmsize_t n ) ;
extern void TIFFReverseBits(uint8 *cp , tmsize_t n ) ;
extern unsigned char const   *TIFFGetBitRevTable(int  ) ;
extern double LogL16toY(int  ) ;
extern double LogL10toY(int  ) ;
extern void XYZtoRGB24(float * , uint8 * ) ;
extern int uv_decode(double * , double * , int  ) ;
extern void LogLuv24toXYZ(uint32  , float * ) ;
extern void LogLuv32toXYZ(uint32  , float * ) ;
extern int LogL16fromY(double  , int  ) ;
extern int LogL10fromY(double  , int  ) ;
extern int uv_encode(double  , double  , int  ) ;
extern uint32 LogLuv24fromXYZ(float * , int  ) ;
extern uint32 LogLuv32fromXYZ(float * , int  ) ;
extern int TIFFCIELabToRGBInit(TIFFCIELabToRGB * , TIFFDisplay const   * ,
                               float * ) ;
extern void TIFFCIELabToXYZ(TIFFCIELabToRGB * , uint32  , int32  , int32  ,
                            float * , float * , float * ) ;
extern void TIFFXYZToRGB(TIFFCIELabToRGB * , float  , float  , float  ,
                         uint32 * , uint32 * , uint32 * ) ;
extern int TIFFYCbCrToRGBInit(TIFFYCbCrToRGB * , float * , float * ) ;
extern void TIFFYCbCrtoRGB(TIFFYCbCrToRGB * , uint32  , int32  , int32  ,
                           uint32 * , uint32 * , uint32 * ) ;
extern int TIFFMergeFieldInfo(TIFF * , TIFFFieldInfo const   * , uint32  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfo(TIFF * , uint32  ,
                                                TIFFDataType  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfoByName(TIFF * , char const   * ,
                                                      TIFFDataType  ) ;
extern TIFFFieldArray const   *_TIFFGetFields(void) ;
extern TIFFFieldArray const   *_TIFFGetExifFields(void) ;
extern void _TIFFSetupFields(TIFF *tif , TIFFFieldArray const   *infoarray ) ;
extern void _TIFFPrintFieldInfo(TIFF * , FILE * ) ;
extern int _TIFFMergeFields(TIFF * , TIFFField const   * , uint32  ) ;
extern TIFFField const   *_TIFFFindOrRegisterField(TIFF * , uint32  ,
                                                   TIFFDataType  ) ;
extern TIFFField *_TIFFCreateAnonField(TIFF * , uint32  , TIFFDataType  ) ;
extern int _TIFFgetMode(char const   *mode , char const   *module ) ;
extern int _TIFFNoRowEncode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoStripEncode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoTileEncode(TIFF * , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoRowDecode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoStripDecode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoTileDecode(TIFF * , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern void _TIFFNoPostDecode(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern int _TIFFNoPreCode(TIFF *tif , uint16 s ) ;
extern int _TIFFNoSeek(TIFF *tif , uint32 off ) ;
extern void _TIFFSwab16BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab24BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab32BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab64BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern int TIFFFlushData1(TIFF *tif ) ;
extern int TIFFDefaultDirectory(TIFF *tif ) ;
extern void _TIFFSetDefaultCompressionState(TIFF *tif ) ;
extern int _TIFFRewriteField(TIFF * , uint16  , TIFFDataType  , tmsize_t  ,
                             void * ) ;
extern int TIFFSetCompressionScheme(TIFF *tif , int scheme ) ;
extern int TIFFSetDefaultCompressionState(TIFF *tif ) ;
extern uint32 _TIFFDefaultStripSize(TIFF *tif , uint32 s ) ;
extern void _TIFFDefaultTileSize(TIFF *tif , uint32 *tw , uint32 *th ) ;
extern int _TIFFDataSize(TIFFDataType type ) ;
extern void _TIFFsetByteArray(void ** , void * , uint32  ) ;
extern void _TIFFsetString(char ** , char * ) ;
extern void _TIFFsetShortArray(uint16 ** , uint16 * , uint32  ) ;
extern void _TIFFsetLongArray(uint32 ** , uint32 * , uint32  ) ;
extern void _TIFFsetFloatArray(float ** , float * , uint32  ) ;
extern void _TIFFsetDoubleArray(double ** , double * , uint32  ) ;
extern void _TIFFprintAscii(FILE * , char const   * ) ;
extern void _TIFFprintAsciiTag(FILE * , char const   * , char const   * ) ;
extern void (*_TIFFwarningHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFerrorHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFwarningHandlerExt)(thandle_t  , char const   * ,
                                      char const   * , va_list  ) ;
extern void (*_TIFFerrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  ) ;
extern void *_TIFFCheckMalloc(TIFF *tif , tmsize_t nmemb , tmsize_t elem_size ,
                              char const   *what ) ;
extern void *_TIFFCheckRealloc(TIFF *tif , void *buffer , tmsize_t nmemb ,
                               tmsize_t elem_size , char const   *what ) ;
extern double _TIFFUInt64ToDouble(uint64  ) ;
extern float _TIFFUInt64ToFloat(uint64  ) ;
extern int TIFFInitDumpMode(TIFF * , int  ) ;
extern int TIFFInitPackBits(TIFF * , int  ) ;
extern int TIFFInitCCITTRLE(TIFF * , int  ) ;
extern int TIFFInitCCITTRLEW(TIFF * , int  ) ;
extern int TIFFInitCCITTFax3(TIFF * , int  ) ;
extern int TIFFInitCCITTFax4(TIFF * , int  ) ;
extern int TIFFInitThunderScan(TIFF * , int  ) ;
extern int TIFFInitNeXT(TIFF * , int  ) ;
extern int TIFFInitLZW(TIFF * , int  ) ;
extern int TIFFInitZIP(TIFF * , int  ) ;
extern int TIFFInitPixarLog(TIFF * , int  ) ;
extern int TIFFInitSGILog(TIFF * , int  ) ;
extern TIFFCodec _TIFFBuiltinCODECS[] ;
void tiff2pdf_usage(void) ;
int tiff2pdf_match_paper_size(float *width , float *length , char *papersize ) ;
T2P *t2p_init(void) ;
void t2p_validate(T2P *t2p ) ;
tsize_t t2p_write_pdf(T2P *t2p , TIFF *input , TIFF *output ) ;
void t2p_free(T2P *t2p ) ;
void t2p_read_tiff_init(T2P *t2p , TIFF *input ) ;
int t2p_cmp_t2p_page(void const   *e1 , void const   *e2 ) ;
void t2p_read_tiff_data(T2P *t2p , TIFF *input ) ;
void t2p_read_tiff_size(T2P *t2p , TIFF *input ) ;
void t2p_read_tiff_size_tile(T2P *t2p , TIFF *input , ttile_t tile ) ;
int t2p_tile_is_right_edge(T2P_TILES tiles , ttile_t tile ) ;
int t2p_tile_is_bottom_edge(T2P_TILES tiles , ttile_t tile ) ;
int t2p_tile_is_edge(T2P_TILES tiles , ttile_t tile ) ;
int t2p_tile_is_corner_edge(T2P_TILES tiles , ttile_t tile ) ;
tsize_t t2p_readwrite_pdf_image(T2P *t2p , TIFF *input , TIFF *output ) ;
tsize_t t2p_readwrite_pdf_image_tile(T2P *t2p , TIFF *input , TIFF *output ,
                                     ttile_t tile ) ;
void t2p_tile_collapse_left(tdata_t buffer , tsize_t scanwidth ,
                            uint32 tilewidth , uint32 edgetilewidth ,
                            uint32 tilelength ) ;
void t2p_write_advance_directory(T2P *t2p , TIFF *output ) ;
tsize_t t2p_sample_planar_separate_to_contig(T2P *t2p , unsigned char *buffer ,
                                             unsigned char *samplebuffer ,
                                             tsize_t samplebuffersize ) ;
tsize_t t2p_sample_realize_palette(T2P *t2p , unsigned char *buffer ) ;
tsize_t t2p_sample_abgr_to_rgb(tdata_t data , uint32 samplecount ) ;
tsize_t t2p_sample_rgba_to_rgb(tdata_t data , uint32 samplecount ) ;
tsize_t t2p_sample_rgbaa_to_rgb(tdata_t data , uint32 samplecount ) ;
tsize_t t2p_sample_lab_signed_to_unsigned(tdata_t buffer , uint32 samplecount ) ;
tsize_t t2p_write_pdf_header(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_obj_start(uint32 number , TIFF *output ) ;
tsize_t t2p_write_pdf_obj_end(TIFF *output ) ;
tsize_t t2p_write_pdf_name(unsigned char *name , TIFF *output ) ;
tsize_t t2p_write_pdf_string(char *pdfstr , TIFF *output ) ;
tsize_t t2p_write_pdf_stream(tdata_t buffer , tsize_t len , TIFF *output ) ;
tsize_t t2p_write_pdf_stream_start(TIFF *output ) ;
tsize_t t2p_write_pdf_stream_end(TIFF *output ) ;
tsize_t t2p_write_pdf_stream_dict(tsize_t len , uint32 number , TIFF *output ) ;
tsize_t t2p_write_pdf_stream_dict_start(TIFF *output ) ;
tsize_t t2p_write_pdf_stream_dict_end(TIFF *output ) ;
tsize_t t2p_write_pdf_stream_length(tsize_t len , TIFF *output ) ;
tsize_t t2p_write_pdf_catalog(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_info(T2P *t2p , TIFF *input , TIFF *output ) ;
void t2p_pdf_currenttime(T2P *t2p ) ;
void t2p_pdf_tifftime(T2P *t2p , TIFF *input ) ;
tsize_t t2p_write_pdf_pages(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_page(uint32 object , T2P *t2p , TIFF *output ) ;
void t2p_compose_pdf_page(T2P *t2p ) ;
void t2p_compose_pdf_page_orient(T2P_BOX *boxp , uint16 orientation ) ;
void t2p_compose_pdf_page_orient_flip(T2P_BOX *boxp , uint16 orientation ) ;
extern tsize_t t2p_write_pdf_page_content(T2P * , TIFF * ) ;
tsize_t t2p_write_pdf_xobject_stream_dict(ttile_t tile , T2P *t2p ,
                                          TIFF *output ) ;
tsize_t t2p_write_pdf_xobject_cs(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_transfer(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_transfer_dict(T2P *t2p , TIFF *output , uint16 i ) ;
tsize_t t2p_write_pdf_transfer_stream(T2P *t2p , TIFF *output , uint16 i ) ;
tsize_t t2p_write_pdf_xobject_calcs(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_xobject_icccs(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_xobject_icccs_dict(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_xobject_icccs_stream(T2P *t2p , TIFF *output ) ;
extern tsize_t t2p_write_pdf_xobject_cs_stream(T2P * , TIFF * ) ;
tsize_t t2p_write_pdf_xobject_decode(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_xobject_stream_filter(ttile_t tile , T2P *t2p ,
                                            TIFF *output ) ;
tsize_t t2p_write_pdf_xreftable(T2P *t2p , TIFF *output ) ;
tsize_t t2p_write_pdf_trailer(T2P *t2p , TIFF *output ) ;
static void t2p_disable(TIFF *tif ) 
{ T2P *t2p ;
  thandle_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "236\n");
  fflush(_coverage_fout);
  tmp = TIFFClientdata(tif);
  fprintf(_coverage_fout, "237\n");
  fflush(_coverage_fout);
  t2p = (T2P *)tmp;
  fprintf(_coverage_fout, "238\n");
  fflush(_coverage_fout);
  t2p->outputdisable = 1;
  fprintf(_coverage_fout, "239\n");
  fflush(_coverage_fout);
  return;
}
}
static void t2p_enable(TIFF *tif ) 
{ T2P *t2p ;
  thandle_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "240\n");
  fflush(_coverage_fout);
  tmp = TIFFClientdata(tif);
  fprintf(_coverage_fout, "241\n");
  fflush(_coverage_fout);
  t2p = (T2P *)tmp;
  fprintf(_coverage_fout, "242\n");
  fflush(_coverage_fout);
  t2p->outputdisable = 0;
  fprintf(_coverage_fout, "243\n");
  fflush(_coverage_fout);
  return;
}
}
static tmsize_t t2pReadFile(TIFF *tif , tdata_t data , tmsize_t size ) 
{ thandle_t client ;
  thandle_t tmp ;
  tmsize_t (*proc)(thandle_t  , void * , tmsize_t  ) ;
  TIFFReadWriteProc tmp___0 ;
  tmsize_t tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "247\n");
  fflush(_coverage_fout);
  tmp = TIFFClientdata(tif);
  fprintf(_coverage_fout, "248\n");
  fflush(_coverage_fout);
  client = tmp;
  fprintf(_coverage_fout, "249\n");
  fflush(_coverage_fout);
  tmp___0 = TIFFGetReadProc(tif);
  fprintf(_coverage_fout, "250\n");
  fflush(_coverage_fout);
  proc = tmp___0;
  fprintf(_coverage_fout, "251\n");
  fflush(_coverage_fout);
  if (proc) {
    fprintf(_coverage_fout, "244\n");
    fflush(_coverage_fout);
    tmp___1 = (*proc)(client, data, size);
    fprintf(_coverage_fout, "245\n");
    fflush(_coverage_fout);
    return (tmp___1);
  } else {
    fprintf(_coverage_fout, "246\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "252\n");
  fflush(_coverage_fout);
  return (-1L);
}
}
static tmsize_t t2pWriteFile(TIFF *tif , tdata_t data , tmsize_t size ) 
{ thandle_t client ;
  thandle_t tmp ;
  tmsize_t (*proc)(thandle_t  , void * , tmsize_t  ) ;
  TIFFReadWriteProc tmp___0 ;
  tmsize_t tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "256\n");
  fflush(_coverage_fout);
  tmp = TIFFClientdata(tif);
  fprintf(_coverage_fout, "257\n");
  fflush(_coverage_fout);
  client = tmp;
  fprintf(_coverage_fout, "258\n");
  fflush(_coverage_fout);
  tmp___0 = TIFFGetWriteProc(tif);
  fprintf(_coverage_fout, "259\n");
  fflush(_coverage_fout);
  proc = tmp___0;
  fprintf(_coverage_fout, "260\n");
  fflush(_coverage_fout);
  if (proc) {
    fprintf(_coverage_fout, "253\n");
    fflush(_coverage_fout);
    tmp___1 = (*proc)(client, data, size);
    fprintf(_coverage_fout, "254\n");
    fflush(_coverage_fout);
    return (tmp___1);
  } else {
    fprintf(_coverage_fout, "255\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "261\n");
  fflush(_coverage_fout);
  return (-1L);
}
}
static uint64 t2pSeekFile(TIFF *tif , toff_t offset , int whence ) 
{ thandle_t client ;
  thandle_t tmp ;
  toff_t (*proc)(thandle_t  , toff_t  , int  ) ;
  TIFFSeekProc tmp___0 ;
  toff_t tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "265\n");
  fflush(_coverage_fout);
  tmp = TIFFClientdata(tif);
  fprintf(_coverage_fout, "266\n");
  fflush(_coverage_fout);
  client = tmp;
  fprintf(_coverage_fout, "267\n");
  fflush(_coverage_fout);
  tmp___0 = TIFFGetSeekProc(tif);
  fprintf(_coverage_fout, "268\n");
  fflush(_coverage_fout);
  proc = tmp___0;
  fprintf(_coverage_fout, "269\n");
  fflush(_coverage_fout);
  if (proc) {
    fprintf(_coverage_fout, "262\n");
    fflush(_coverage_fout);
    tmp___1 = (*proc)(client, offset, whence);
    fprintf(_coverage_fout, "263\n");
    fflush(_coverage_fout);
    return (tmp___1);
  } else {
    fprintf(_coverage_fout, "264\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "270\n");
  fflush(_coverage_fout);
  return (0xffffffffffffffffULL);
}
}
static tmsize_t t2p_readproc(thandle_t handle , tdata_t data , tmsize_t size ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "271\n");
  fflush(_coverage_fout);
  return (-1L);
}
}
static tmsize_t t2p_writeproc(thandle_t handle , tdata_t data , tmsize_t size ) 
{ T2P *t2p ;
  tsize_t written ;
  size_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "279\n");
  fflush(_coverage_fout);
  t2p = (T2P *)handle;
  fprintf(_coverage_fout, "280\n");
  fflush(_coverage_fout);
  if (t2p->outputdisable <= 0) {
    fprintf(_coverage_fout, "277\n");
    fflush(_coverage_fout);
    if (t2p->outputfile) {
      fprintf(_coverage_fout, "272\n");
      fflush(_coverage_fout);
      tmp = fwrite((void const   */* __restrict  */)data, 1U,
                   (unsigned int )size, (FILE */* __restrict  */)t2p->outputfile);
      fprintf(_coverage_fout, "273\n");
      fflush(_coverage_fout);
      written = (tsize_t )tmp;
      fprintf(_coverage_fout, "274\n");
      fflush(_coverage_fout);
      t2p->outputwritten += written;
      fprintf(_coverage_fout, "275\n");
      fflush(_coverage_fout);
      return (written);
    } else {
      fprintf(_coverage_fout, "276\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "278\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "281\n");
  fflush(_coverage_fout);
  return (size);
}
}
static uint64 t2p_seekproc(thandle_t handle , uint64 offset , int whence ) 
{ T2P *t2p ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "287\n");
  fflush(_coverage_fout);
  t2p = (T2P *)handle;
  fprintf(_coverage_fout, "288\n");
  fflush(_coverage_fout);
  if (t2p->outputdisable <= 0) {
    fprintf(_coverage_fout, "285\n");
    fflush(_coverage_fout);
    if (t2p->outputfile) {
      fprintf(_coverage_fout, "282\n");
      fflush(_coverage_fout);
      tmp = fseek(t2p->outputfile, (long )offset, whence);
      fprintf(_coverage_fout, "283\n");
      fflush(_coverage_fout);
      return ((unsigned long long )tmp);
    } else {
      fprintf(_coverage_fout, "284\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "286\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "289\n");
  fflush(_coverage_fout);
  return (offset);
}
}
static int t2p_closeproc(thandle_t handle ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "290\n");
  fflush(_coverage_fout);
  return (0);
}
}
static uint64 t2p_sizeproc(thandle_t handle ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "291\n");
  fflush(_coverage_fout);
  return (0xffffffffffffffffULL);
}
}
static int t2p_mapproc(thandle_t handle , void **data , toff_t *offset ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "292\n");
  fflush(_coverage_fout);
  return (-1);
}
}
static void t2p_unmapproc(thandle_t handle , void *data , toff_t offset ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "293\n");
  fflush(_coverage_fout);
  return;
}
}
int main(int argc , char **argv ) 
{ char const   *outfilename ;
  T2P *t2p ;
  TIFF *input ;
  TIFF *output ;
  tsize_t written ;
  int c ;
  int ret ;
  int tmp ;
  double tmp___0 ;
  float tmp___1 ;
  double tmp___2 ;
  float tmp___3 ;
  double tmp___4 ;
  float tmp___5 ;
  double tmp___6 ;
  float tmp___7 ;
  int tmp___8 ;
  size_t tmp___9 ;
  int tmp___10 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "387\n");
  fflush(_coverage_fout);
  outfilename = (char const   *)((void *)0);
  fprintf(_coverage_fout, "388\n");
  fflush(_coverage_fout);
  t2p = (T2P *)((void *)0);
  fprintf(_coverage_fout, "389\n");
  fflush(_coverage_fout);
  input = (TIFF *)((void *)0);
  fprintf(_coverage_fout, "390\n");
  fflush(_coverage_fout);
  output = (TIFF *)((void *)0);
  fprintf(_coverage_fout, "391\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "392\n");
  fflush(_coverage_fout);
  ret = 0;
  fprintf(_coverage_fout, "393\n");
  fflush(_coverage_fout);
  t2p = t2p_init();
  fprintf(_coverage_fout, "394\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "294\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "Can\'t initialize context");
    goto fail;
  } else {
    fprintf(_coverage_fout, "295\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "395\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "359\n");
    fflush(_coverage_fout);
    if (argv) {
      fprintf(_coverage_fout, "297\n");
      fflush(_coverage_fout);
      c = getopt(argc, (char * const  *)argv,
                 "o:q:u:x:y:w:l:r:p:e:c:a:t:s:k:jzndifbh");
      fprintf(_coverage_fout, "298\n");
      fflush(_coverage_fout);
      if (c != -1) {
        fprintf(_coverage_fout, "296\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    } else {
      break;
    }
    switch (c) {
    fprintf(_coverage_fout, "318\n");
    fflush(_coverage_fout);
    case 111: 
    outfilename = (char const   *)optarg;
    break;
    fprintf(_coverage_fout, "319\n");
    fflush(_coverage_fout);
    case 106: 
    TIFFWarning("tiff2pdf",
                "JPEG support in libtiff required for JPEG compression, ignoring option");
    break;
    fprintf(_coverage_fout, "320\n");
    fflush(_coverage_fout);
    case 122: 
    t2p->pdf_defaultcompression = (enum __anonenum_t2p_compress_t_51 )4;
    break;
    fprintf(_coverage_fout, "321\n");
    fflush(_coverage_fout);
    case 113: 
    tmp = atoi((char const   *)optarg);
    fprintf(_coverage_fout, "322\n");
    fflush(_coverage_fout);
    t2p->pdf_defaultcompressionquality = (unsigned short )tmp;
    break;
    fprintf(_coverage_fout, "323\n");
    fflush(_coverage_fout);
    case 110: 
    t2p->pdf_nopassthrough = (unsigned short)1;
    break;
    fprintf(_coverage_fout, "324\n");
    fflush(_coverage_fout);
    case 100: 
    t2p->pdf_defaultcompression = (enum __anonenum_t2p_compress_t_51 )0;
    break;
    fprintf(_coverage_fout, "325\n");
    fflush(_coverage_fout);
    case 117: 
    if ((int )*(optarg + 0) == 109) {
      fprintf(_coverage_fout, "299\n");
      fflush(_coverage_fout);
      t2p->pdf_centimeters = (unsigned short)1;
    } else {
      fprintf(_coverage_fout, "300\n");
      fflush(_coverage_fout);

    }
    break;
    fprintf(_coverage_fout, "326\n");
    fflush(_coverage_fout);
    case 120: 
    tmp___0 = atof((char const   *)optarg);
    fprintf(_coverage_fout, "327\n");
    fflush(_coverage_fout);
    if (t2p->pdf_centimeters) {
      fprintf(_coverage_fout, "301\n");
      fflush(_coverage_fout);
      tmp___1 = 2.54F;
    } else {
      fprintf(_coverage_fout, "302\n");
      fflush(_coverage_fout);
      tmp___1 = 1.0F;
    }
    fprintf(_coverage_fout, "328\n");
    fflush(_coverage_fout);
    t2p->pdf_defaultxres = (float )tmp___0 / tmp___1;
    break;
    fprintf(_coverage_fout, "329\n");
    fflush(_coverage_fout);
    case 121: 
    tmp___2 = atof((char const   *)optarg);
    fprintf(_coverage_fout, "330\n");
    fflush(_coverage_fout);
    if (t2p->pdf_centimeters) {
      fprintf(_coverage_fout, "303\n");
      fflush(_coverage_fout);
      tmp___3 = 2.54F;
    } else {
      fprintf(_coverage_fout, "304\n");
      fflush(_coverage_fout);
      tmp___3 = 1.0F;
    }
    fprintf(_coverage_fout, "331\n");
    fflush(_coverage_fout);
    t2p->pdf_defaultyres = (float )tmp___2 / tmp___3;
    break;
    fprintf(_coverage_fout, "332\n");
    fflush(_coverage_fout);
    case 119: 
    t2p->pdf_overridepagesize = (unsigned short)1;
    fprintf(_coverage_fout, "333\n");
    fflush(_coverage_fout);
    tmp___4 = atof((char const   *)optarg);
    fprintf(_coverage_fout, "334\n");
    fflush(_coverage_fout);
    if (t2p->pdf_centimeters) {
      fprintf(_coverage_fout, "305\n");
      fflush(_coverage_fout);
      tmp___5 = 2.54F;
    } else {
      fprintf(_coverage_fout, "306\n");
      fflush(_coverage_fout);
      tmp___5 = 1.0F;
    }
    fprintf(_coverage_fout, "335\n");
    fflush(_coverage_fout);
    t2p->pdf_defaultpagewidth = ((float )tmp___4 * 72.0F) / tmp___5;
    break;
    fprintf(_coverage_fout, "336\n");
    fflush(_coverage_fout);
    case 108: 
    t2p->pdf_overridepagesize = (unsigned short)1;
    fprintf(_coverage_fout, "337\n");
    fflush(_coverage_fout);
    tmp___6 = atof((char const   *)optarg);
    fprintf(_coverage_fout, "338\n");
    fflush(_coverage_fout);
    if (t2p->pdf_centimeters) {
      fprintf(_coverage_fout, "307\n");
      fflush(_coverage_fout);
      tmp___7 = 2.54F;
    } else {
      fprintf(_coverage_fout, "308\n");
      fflush(_coverage_fout);
      tmp___7 = 1.0F;
    }
    fprintf(_coverage_fout, "339\n");
    fflush(_coverage_fout);
    t2p->pdf_defaultpagelength = ((float )tmp___6 * 72.0F) / tmp___7;
    break;
    fprintf(_coverage_fout, "340\n");
    fflush(_coverage_fout);
    case 114: 
    if ((int )*(optarg + 0) == 111) {
      fprintf(_coverage_fout, "309\n");
      fflush(_coverage_fout);
      t2p->pdf_overrideres = (unsigned short)1;
    } else {
      fprintf(_coverage_fout, "310\n");
      fflush(_coverage_fout);

    }
    break;
    fprintf(_coverage_fout, "341\n");
    fflush(_coverage_fout);
    case 112: 
    tmp___8 = tiff2pdf_match_paper_size(& t2p->pdf_defaultpagewidth,
                                        & t2p->pdf_defaultpagelength, optarg);
    fprintf(_coverage_fout, "342\n");
    fflush(_coverage_fout);
    if (tmp___8) {
      fprintf(_coverage_fout, "311\n");
      fflush(_coverage_fout);
      t2p->pdf_overridepagesize = (unsigned short)1;
    } else {
      fprintf(_coverage_fout, "312\n");
      fflush(_coverage_fout);
      TIFFWarning("tiff2pdf", "Unknown paper size %s, ignoring option", optarg);
    }
    break;
    fprintf(_coverage_fout, "343\n");
    fflush(_coverage_fout);
    case 105: 
    t2p->pdf_colorspace_invert = (unsigned short)1;
    break;
    fprintf(_coverage_fout, "344\n");
    fflush(_coverage_fout);
    case 102: 
    t2p->pdf_fitwindow = (unsigned short)1;
    break;
    fprintf(_coverage_fout, "345\n");
    fflush(_coverage_fout);
    case 101: 
    tmp___9 = strlen((char const   *)optarg);
    fprintf(_coverage_fout, "346\n");
    fflush(_coverage_fout);
    if (tmp___9 == 0U) {
      fprintf(_coverage_fout, "313\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[0] = (char )'\000';
    } else {
      fprintf(_coverage_fout, "314\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[0] = (char )'D';
      fprintf(_coverage_fout, "315\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[1] = (char )':';
      fprintf(_coverage_fout, "316\n");
      fflush(_coverage_fout);
      __builtin_strncpy(t2p->pdf_datetime + 2, (char const   *)optarg,
                        sizeof(t2p->pdf_datetime) - 3U);
      fprintf(_coverage_fout, "317\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[sizeof(t2p->pdf_datetime) - 1U] = (char )'\000';
    }
    break;
    fprintf(_coverage_fout, "347\n");
    fflush(_coverage_fout);
    case 99: 
    __builtin_strncpy(t2p->pdf_creator, (char const   *)optarg,
                      sizeof(t2p->pdf_creator) - 1U);
    fprintf(_coverage_fout, "348\n");
    fflush(_coverage_fout);
    t2p->pdf_creator[sizeof(t2p->pdf_creator) - 1U] = (char )'\000';
    break;
    fprintf(_coverage_fout, "349\n");
    fflush(_coverage_fout);
    case 97: 
    __builtin_strncpy(t2p->pdf_author, (char const   *)optarg,
                      sizeof(t2p->pdf_author) - 1U);
    fprintf(_coverage_fout, "350\n");
    fflush(_coverage_fout);
    t2p->pdf_author[sizeof(t2p->pdf_author) - 1U] = (char )'\000';
    break;
    fprintf(_coverage_fout, "351\n");
    fflush(_coverage_fout);
    case 116: 
    __builtin_strncpy(t2p->pdf_title, (char const   *)optarg,
                      sizeof(t2p->pdf_title) - 1U);
    fprintf(_coverage_fout, "352\n");
    fflush(_coverage_fout);
    t2p->pdf_title[sizeof(t2p->pdf_title) - 1U] = (char )'\000';
    break;
    fprintf(_coverage_fout, "353\n");
    fflush(_coverage_fout);
    case 115: 
    __builtin_strncpy(t2p->pdf_subject, (char const   *)optarg,
                      sizeof(t2p->pdf_subject) - 1U);
    fprintf(_coverage_fout, "354\n");
    fflush(_coverage_fout);
    t2p->pdf_subject[sizeof(t2p->pdf_subject) - 1U] = (char )'\000';
    break;
    fprintf(_coverage_fout, "355\n");
    fflush(_coverage_fout);
    case 107: 
    __builtin_strncpy(t2p->pdf_keywords, (char const   *)optarg,
                      sizeof(t2p->pdf_keywords) - 1U);
    fprintf(_coverage_fout, "356\n");
    fflush(_coverage_fout);
    t2p->pdf_keywords[sizeof(t2p->pdf_keywords) - 1U] = (char )'\000';
    break;
    fprintf(_coverage_fout, "357\n");
    fflush(_coverage_fout);
    case 98: 
    t2p->pdf_image_interpolate = 1;
    break;
    fprintf(_coverage_fout, "358\n");
    fflush(_coverage_fout);
    case 104: 
    case 63: 
    tiff2pdf_usage();
    goto success;
    break;
    }
  }
  fprintf(_coverage_fout, "396\n");
  fflush(_coverage_fout);
  if (argc > optind) {
    fprintf(_coverage_fout, "362\n");
    fflush(_coverage_fout);
    tmp___10 = optind;
    fprintf(_coverage_fout, "363\n");
    fflush(_coverage_fout);
    optind ++;
    fprintf(_coverage_fout, "364\n");
    fflush(_coverage_fout);
    input = TIFFOpen((char const   *)*(argv + tmp___10), "r");
    fprintf(_coverage_fout, "365\n");
    fflush(_coverage_fout);
    if ((unsigned int )input == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "360\n");
      fflush(_coverage_fout);
      TIFFError("tiff2pdf", "Can\'t open input file %s for reading",
                *(argv + (optind - 1)));
      goto fail;
    } else {
      fprintf(_coverage_fout, "361\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "366\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "No input file specified");
    fprintf(_coverage_fout, "367\n");
    fflush(_coverage_fout);
    tiff2pdf_usage();
    goto fail;
  }
  fprintf(_coverage_fout, "397\n");
  fflush(_coverage_fout);
  if (argc > optind) {
    fprintf(_coverage_fout, "368\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "No support for multiple input files");
    fprintf(_coverage_fout, "369\n");
    fflush(_coverage_fout);
    tiff2pdf_usage();
    goto fail;
  } else {
    fprintf(_coverage_fout, "370\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "398\n");
  fflush(_coverage_fout);
  t2p->outputdisable = 0;
  fprintf(_coverage_fout, "399\n");
  fflush(_coverage_fout);
  if (outfilename) {
    fprintf(_coverage_fout, "373\n");
    fflush(_coverage_fout);
    t2p->outputfile = fopen((char const   */* __restrict  */)outfilename,
                            (char const   */* __restrict  */)"wb");
    fprintf(_coverage_fout, "374\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->outputfile == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "371\n");
      fflush(_coverage_fout);
      TIFFError("tiff2pdf", "Can\'t open output file %s for writing",
                outfilename);
      goto fail;
    } else {
      fprintf(_coverage_fout, "372\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "375\n");
    fflush(_coverage_fout);
    outfilename = "-";
    fprintf(_coverage_fout, "376\n");
    fflush(_coverage_fout);
    t2p->outputfile = stdout;
  }
  fprintf(_coverage_fout, "400\n");
  fflush(_coverage_fout);
  output = TIFFClientOpen(outfilename, "w", (void *)t2p, & t2p_readproc,
                          & t2p_writeproc, & t2p_seekproc, & t2p_closeproc,
                          & t2p_sizeproc, & t2p_mapproc, & t2p_unmapproc);
  fprintf(_coverage_fout, "401\n");
  fflush(_coverage_fout);
  if ((unsigned int )output == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "377\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "Can\'t initialize output descriptor");
    goto fail;
  } else {
    fprintf(_coverage_fout, "378\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "402\n");
  fflush(_coverage_fout);
  t2p_validate(t2p);
  fprintf(_coverage_fout, "403\n");
  fflush(_coverage_fout);
  t2pSeekFile(output, 0ULL, 0);
  fprintf(_coverage_fout, "404\n");
  fflush(_coverage_fout);
  written = t2p_write_pdf(t2p, input, output);
  fprintf(_coverage_fout, "405\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->t2p_error != 0U) {
    fprintf(_coverage_fout, "379\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "An error occurred creating output PDF file");
    goto fail;
  } else {
    fprintf(_coverage_fout, "380\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "406\n");
  fflush(_coverage_fout);
  fail: 
  ret = 1;
  fprintf(_coverage_fout, "407\n");
  fflush(_coverage_fout);
  success: 
  if ((unsigned int )input != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "381\n");
    fflush(_coverage_fout);
    TIFFClose(input);
  } else {
    fprintf(_coverage_fout, "382\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "408\n");
  fflush(_coverage_fout);
  if ((unsigned int )output != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "383\n");
    fflush(_coverage_fout);
    TIFFClose(output);
  } else {
    fprintf(_coverage_fout, "384\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "409\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "385\n");
    fflush(_coverage_fout);
    t2p_free(t2p);
  } else {
    fprintf(_coverage_fout, "386\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "410\n");
  fflush(_coverage_fout);
  return (ret);
}
}
void tiff2pdf_usage(void) 
{ char *lines[25] ;
  int i ;
  char const   *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "415\n");
  fflush(_coverage_fout);
  lines[0] = (char *)"usage:  tiff2pdf [options] input.tiff";
  fprintf(_coverage_fout, "416\n");
  fflush(_coverage_fout);
  lines[1] = (char *)"options:";
  fprintf(_coverage_fout, "417\n");
  fflush(_coverage_fout);
  lines[2] = (char *)" -o: output to file name";
  fprintf(_coverage_fout, "418\n");
  fflush(_coverage_fout);
  lines[3] = (char *)" -z: compress with Zip/Deflate";
  fprintf(_coverage_fout, "419\n");
  fflush(_coverage_fout);
  lines[4] = (char *)" -q: compression quality";
  fprintf(_coverage_fout, "420\n");
  fflush(_coverage_fout);
  lines[5] = (char *)" -n: no compressed data passthrough";
  fprintf(_coverage_fout, "421\n");
  fflush(_coverage_fout);
  lines[6] = (char *)" -d: do not compress (decompress)";
  fprintf(_coverage_fout, "422\n");
  fflush(_coverage_fout);
  lines[7] = (char *)" -i: invert colors";
  fprintf(_coverage_fout, "423\n");
  fflush(_coverage_fout);
  lines[8] = (char *)" -u: set distance unit, \'i\' for inch, \'m\' for centimeter";
  fprintf(_coverage_fout, "424\n");
  fflush(_coverage_fout);
  lines[9] = (char *)" -x: set x resolution default in dots per unit";
  fprintf(_coverage_fout, "425\n");
  fflush(_coverage_fout);
  lines[10] = (char *)" -y: set y resolution default in dots per unit";
  fprintf(_coverage_fout, "426\n");
  fflush(_coverage_fout);
  lines[11] = (char *)" -w: width in units";
  fprintf(_coverage_fout, "427\n");
  fflush(_coverage_fout);
  lines[12] = (char *)" -l: length in units";
  fprintf(_coverage_fout, "428\n");
  fflush(_coverage_fout);
  lines[13] = (char *)" -r: \'d\' for resolution default, \'o\' for resolution override";
  fprintf(_coverage_fout, "429\n");
  fflush(_coverage_fout);
  lines[14] = (char *)" -p: paper size, eg \"letter\", \"legal\", \"A4\"";
  fprintf(_coverage_fout, "430\n");
  fflush(_coverage_fout);
  lines[15] = (char *)" -f: set PDF \"Fit Window\" user preference";
  fprintf(_coverage_fout, "431\n");
  fflush(_coverage_fout);
  lines[16] = (char *)" -e: date, overrides image or current date/time default, YYYYMMDDHHMMSS";
  fprintf(_coverage_fout, "432\n");
  fflush(_coverage_fout);
  lines[17] = (char *)" -c: sets document creator, overrides image software default";
  fprintf(_coverage_fout, "433\n");
  fflush(_coverage_fout);
  lines[18] = (char *)" -a: sets document author, overrides image artist default";
  fprintf(_coverage_fout, "434\n");
  fflush(_coverage_fout);
  lines[19] = (char *)" -t: sets document title, overrides image document name default";
  fprintf(_coverage_fout, "435\n");
  fflush(_coverage_fout);
  lines[20] = (char *)" -s: sets document subject, overrides image image description default";
  fprintf(_coverage_fout, "436\n");
  fflush(_coverage_fout);
  lines[21] = (char *)" -k: sets document keywords";
  fprintf(_coverage_fout, "437\n");
  fflush(_coverage_fout);
  lines[22] = (char *)" -b: set PDF \"Interpolate\" user preference";
  fprintf(_coverage_fout, "438\n");
  fflush(_coverage_fout);
  lines[23] = (char *)" -h: usage";
  fprintf(_coverage_fout, "439\n");
  fflush(_coverage_fout);
  lines[24] = (char *)((void *)0);
  fprintf(_coverage_fout, "440\n");
  fflush(_coverage_fout);
  i = 0;
  fprintf(_coverage_fout, "441\n");
  fflush(_coverage_fout);
  tmp = TIFFGetVersion();
  fprintf(_coverage_fout, "442\n");
  fflush(_coverage_fout);
  fprintf((FILE */* __restrict  */)stderr,
          (char const   */* __restrict  */)"%s\n\n", tmp);
  fprintf(_coverage_fout, "443\n");
  fflush(_coverage_fout);
  i = 0;
  fprintf(_coverage_fout, "444\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "412\n");
    fflush(_coverage_fout);
    if ((unsigned int )lines[i] != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "411\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "413\n");
    fflush(_coverage_fout);
    fprintf((FILE */* __restrict  */)stderr,
            (char const   */* __restrict  */)"%s\n", lines[i]);
    fprintf(_coverage_fout, "414\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "445\n");
  fflush(_coverage_fout);
  return;
}
}
int tiff2pdf_match_paper_size(float *width , float *length , char *papersize ) 
{ size_t i ;
  size_t len ;
  char const   *sizes[80] ;
  int widths[80] ;
  int lengths[80] ;
  int __res ;
  int __c ;
  __int32_t const   **tmp ;
  __int32_t const   **tmp___0 ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  unsigned char const   *__s2 ;
  register int __result ;
  int tmp___4 ;
  unsigned char const   *__s1 ;
  register int __result___0 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "480\n");
  fflush(_coverage_fout);
  sizes[0] = "LETTER";
  fprintf(_coverage_fout, "481\n");
  fflush(_coverage_fout);
  sizes[1] = "A4";
  fprintf(_coverage_fout, "482\n");
  fflush(_coverage_fout);
  sizes[2] = "LEGAL";
  fprintf(_coverage_fout, "483\n");
  fflush(_coverage_fout);
  sizes[3] = "EXECUTIVE";
  fprintf(_coverage_fout, "484\n");
  fflush(_coverage_fout);
  sizes[4] = "LETTER";
  fprintf(_coverage_fout, "485\n");
  fflush(_coverage_fout);
  sizes[5] = "LEGAL";
  fprintf(_coverage_fout, "486\n");
  fflush(_coverage_fout);
  sizes[6] = "LEDGER";
  fprintf(_coverage_fout, "487\n");
  fflush(_coverage_fout);
  sizes[7] = "TABLOID";
  fprintf(_coverage_fout, "488\n");
  fflush(_coverage_fout);
  sizes[8] = "A";
  fprintf(_coverage_fout, "489\n");
  fflush(_coverage_fout);
  sizes[9] = "B";
  fprintf(_coverage_fout, "490\n");
  fflush(_coverage_fout);
  sizes[10] = "C";
  fprintf(_coverage_fout, "491\n");
  fflush(_coverage_fout);
  sizes[11] = "D";
  fprintf(_coverage_fout, "492\n");
  fflush(_coverage_fout);
  sizes[12] = "E";
  fprintf(_coverage_fout, "493\n");
  fflush(_coverage_fout);
  sizes[13] = "F";
  fprintf(_coverage_fout, "494\n");
  fflush(_coverage_fout);
  sizes[14] = "G";
  fprintf(_coverage_fout, "495\n");
  fflush(_coverage_fout);
  sizes[15] = "H";
  fprintf(_coverage_fout, "496\n");
  fflush(_coverage_fout);
  sizes[16] = "J";
  fprintf(_coverage_fout, "497\n");
  fflush(_coverage_fout);
  sizes[17] = "K";
  fprintf(_coverage_fout, "498\n");
  fflush(_coverage_fout);
  sizes[18] = "A10";
  fprintf(_coverage_fout, "499\n");
  fflush(_coverage_fout);
  sizes[19] = "A9";
  fprintf(_coverage_fout, "500\n");
  fflush(_coverage_fout);
  sizes[20] = "A8";
  fprintf(_coverage_fout, "501\n");
  fflush(_coverage_fout);
  sizes[21] = "A7";
  fprintf(_coverage_fout, "502\n");
  fflush(_coverage_fout);
  sizes[22] = "A6";
  fprintf(_coverage_fout, "503\n");
  fflush(_coverage_fout);
  sizes[23] = "A5";
  fprintf(_coverage_fout, "504\n");
  fflush(_coverage_fout);
  sizes[24] = "A4";
  fprintf(_coverage_fout, "505\n");
  fflush(_coverage_fout);
  sizes[25] = "A3";
  fprintf(_coverage_fout, "506\n");
  fflush(_coverage_fout);
  sizes[26] = "A2";
  fprintf(_coverage_fout, "507\n");
  fflush(_coverage_fout);
  sizes[27] = "A1";
  fprintf(_coverage_fout, "508\n");
  fflush(_coverage_fout);
  sizes[28] = "A0";
  fprintf(_coverage_fout, "509\n");
  fflush(_coverage_fout);
  sizes[29] = "2A0";
  fprintf(_coverage_fout, "510\n");
  fflush(_coverage_fout);
  sizes[30] = "4A0";
  fprintf(_coverage_fout, "511\n");
  fflush(_coverage_fout);
  sizes[31] = "2A";
  fprintf(_coverage_fout, "512\n");
  fflush(_coverage_fout);
  sizes[32] = "4A";
  fprintf(_coverage_fout, "513\n");
  fflush(_coverage_fout);
  sizes[33] = "B10";
  fprintf(_coverage_fout, "514\n");
  fflush(_coverage_fout);
  sizes[34] = "B9";
  fprintf(_coverage_fout, "515\n");
  fflush(_coverage_fout);
  sizes[35] = "B8";
  fprintf(_coverage_fout, "516\n");
  fflush(_coverage_fout);
  sizes[36] = "B7";
  fprintf(_coverage_fout, "517\n");
  fflush(_coverage_fout);
  sizes[37] = "B6";
  fprintf(_coverage_fout, "518\n");
  fflush(_coverage_fout);
  sizes[38] = "B5";
  fprintf(_coverage_fout, "519\n");
  fflush(_coverage_fout);
  sizes[39] = "B4";
  fprintf(_coverage_fout, "520\n");
  fflush(_coverage_fout);
  sizes[40] = "B3";
  fprintf(_coverage_fout, "521\n");
  fflush(_coverage_fout);
  sizes[41] = "B2";
  fprintf(_coverage_fout, "522\n");
  fflush(_coverage_fout);
  sizes[42] = "B1";
  fprintf(_coverage_fout, "523\n");
  fflush(_coverage_fout);
  sizes[43] = "B0";
  fprintf(_coverage_fout, "524\n");
  fflush(_coverage_fout);
  sizes[44] = "JISB10";
  fprintf(_coverage_fout, "525\n");
  fflush(_coverage_fout);
  sizes[45] = "JISB9";
  fprintf(_coverage_fout, "526\n");
  fflush(_coverage_fout);
  sizes[46] = "JISB8";
  fprintf(_coverage_fout, "527\n");
  fflush(_coverage_fout);
  sizes[47] = "JISB7";
  fprintf(_coverage_fout, "528\n");
  fflush(_coverage_fout);
  sizes[48] = "JISB6";
  fprintf(_coverage_fout, "529\n");
  fflush(_coverage_fout);
  sizes[49] = "JISB5";
  fprintf(_coverage_fout, "530\n");
  fflush(_coverage_fout);
  sizes[50] = "JISB4";
  fprintf(_coverage_fout, "531\n");
  fflush(_coverage_fout);
  sizes[51] = "JISB3";
  fprintf(_coverage_fout, "532\n");
  fflush(_coverage_fout);
  sizes[52] = "JISB2";
  fprintf(_coverage_fout, "533\n");
  fflush(_coverage_fout);
  sizes[53] = "JISB1";
  fprintf(_coverage_fout, "534\n");
  fflush(_coverage_fout);
  sizes[54] = "JISB0";
  fprintf(_coverage_fout, "535\n");
  fflush(_coverage_fout);
  sizes[55] = "C10";
  fprintf(_coverage_fout, "536\n");
  fflush(_coverage_fout);
  sizes[56] = "C9";
  fprintf(_coverage_fout, "537\n");
  fflush(_coverage_fout);
  sizes[57] = "C8";
  fprintf(_coverage_fout, "538\n");
  fflush(_coverage_fout);
  sizes[58] = "C7";
  fprintf(_coverage_fout, "539\n");
  fflush(_coverage_fout);
  sizes[59] = "C6";
  fprintf(_coverage_fout, "540\n");
  fflush(_coverage_fout);
  sizes[60] = "C5";
  fprintf(_coverage_fout, "541\n");
  fflush(_coverage_fout);
  sizes[61] = "C4";
  fprintf(_coverage_fout, "542\n");
  fflush(_coverage_fout);
  sizes[62] = "C3";
  fprintf(_coverage_fout, "543\n");
  fflush(_coverage_fout);
  sizes[63] = "C2";
  fprintf(_coverage_fout, "544\n");
  fflush(_coverage_fout);
  sizes[64] = "C1";
  fprintf(_coverage_fout, "545\n");
  fflush(_coverage_fout);
  sizes[65] = "C0";
  fprintf(_coverage_fout, "546\n");
  fflush(_coverage_fout);
  sizes[66] = "RA2";
  fprintf(_coverage_fout, "547\n");
  fflush(_coverage_fout);
  sizes[67] = "RA1";
  fprintf(_coverage_fout, "548\n");
  fflush(_coverage_fout);
  sizes[68] = "RA0";
  fprintf(_coverage_fout, "549\n");
  fflush(_coverage_fout);
  sizes[69] = "SRA4";
  fprintf(_coverage_fout, "550\n");
  fflush(_coverage_fout);
  sizes[70] = "SRA3";
  fprintf(_coverage_fout, "551\n");
  fflush(_coverage_fout);
  sizes[71] = "SRA2";
  fprintf(_coverage_fout, "552\n");
  fflush(_coverage_fout);
  sizes[72] = "SRA1";
  fprintf(_coverage_fout, "553\n");
  fflush(_coverage_fout);
  sizes[73] = "SRA0";
  fprintf(_coverage_fout, "554\n");
  fflush(_coverage_fout);
  sizes[74] = "A3EXTRA";
  fprintf(_coverage_fout, "555\n");
  fflush(_coverage_fout);
  sizes[75] = "A4EXTRA";
  fprintf(_coverage_fout, "556\n");
  fflush(_coverage_fout);
  sizes[76] = "STATEMENT";
  fprintf(_coverage_fout, "557\n");
  fflush(_coverage_fout);
  sizes[77] = "FOLIO";
  fprintf(_coverage_fout, "558\n");
  fflush(_coverage_fout);
  sizes[78] = "QUARTO";
  fprintf(_coverage_fout, "559\n");
  fflush(_coverage_fout);
  sizes[79] = (char const   *)((void *)0);
  fprintf(_coverage_fout, "560\n");
  fflush(_coverage_fout);
  widths[0] = 612;
  fprintf(_coverage_fout, "561\n");
  fflush(_coverage_fout);
  widths[1] = 595;
  fprintf(_coverage_fout, "562\n");
  fflush(_coverage_fout);
  widths[2] = 612;
  fprintf(_coverage_fout, "563\n");
  fflush(_coverage_fout);
  widths[3] = 522;
  fprintf(_coverage_fout, "564\n");
  fflush(_coverage_fout);
  widths[4] = 612;
  fprintf(_coverage_fout, "565\n");
  fflush(_coverage_fout);
  widths[5] = 612;
  fprintf(_coverage_fout, "566\n");
  fflush(_coverage_fout);
  widths[6] = 792;
  fprintf(_coverage_fout, "567\n");
  fflush(_coverage_fout);
  widths[7] = 792;
  fprintf(_coverage_fout, "568\n");
  fflush(_coverage_fout);
  widths[8] = 612;
  fprintf(_coverage_fout, "569\n");
  fflush(_coverage_fout);
  widths[9] = 792;
  fprintf(_coverage_fout, "570\n");
  fflush(_coverage_fout);
  widths[10] = 1224;
  fprintf(_coverage_fout, "571\n");
  fflush(_coverage_fout);
  widths[11] = 1584;
  fprintf(_coverage_fout, "572\n");
  fflush(_coverage_fout);
  widths[12] = 2448;
  fprintf(_coverage_fout, "573\n");
  fflush(_coverage_fout);
  widths[13] = 2016;
  fprintf(_coverage_fout, "574\n");
  fflush(_coverage_fout);
  widths[14] = 792;
  fprintf(_coverage_fout, "575\n");
  fflush(_coverage_fout);
  widths[15] = 2016;
  fprintf(_coverage_fout, "576\n");
  fflush(_coverage_fout);
  widths[16] = 2448;
  fprintf(_coverage_fout, "577\n");
  fflush(_coverage_fout);
  widths[17] = 2880;
  fprintf(_coverage_fout, "578\n");
  fflush(_coverage_fout);
  widths[18] = 74;
  fprintf(_coverage_fout, "579\n");
  fflush(_coverage_fout);
  widths[19] = 105;
  fprintf(_coverage_fout, "580\n");
  fflush(_coverage_fout);
  widths[20] = 147;
  fprintf(_coverage_fout, "581\n");
  fflush(_coverage_fout);
  widths[21] = 210;
  fprintf(_coverage_fout, "582\n");
  fflush(_coverage_fout);
  widths[22] = 298;
  fprintf(_coverage_fout, "583\n");
  fflush(_coverage_fout);
  widths[23] = 420;
  fprintf(_coverage_fout, "584\n");
  fflush(_coverage_fout);
  widths[24] = 595;
  fprintf(_coverage_fout, "585\n");
  fflush(_coverage_fout);
  widths[25] = 842;
  fprintf(_coverage_fout, "586\n");
  fflush(_coverage_fout);
  widths[26] = 1191;
  fprintf(_coverage_fout, "587\n");
  fflush(_coverage_fout);
  widths[27] = 1684;
  fprintf(_coverage_fout, "588\n");
  fflush(_coverage_fout);
  widths[28] = 2384;
  fprintf(_coverage_fout, "589\n");
  fflush(_coverage_fout);
  widths[29] = 3370;
  fprintf(_coverage_fout, "590\n");
  fflush(_coverage_fout);
  widths[30] = 4768;
  fprintf(_coverage_fout, "591\n");
  fflush(_coverage_fout);
  widths[31] = 3370;
  fprintf(_coverage_fout, "592\n");
  fflush(_coverage_fout);
  widths[32] = 4768;
  fprintf(_coverage_fout, "593\n");
  fflush(_coverage_fout);
  widths[33] = 88;
  fprintf(_coverage_fout, "594\n");
  fflush(_coverage_fout);
  widths[34] = 125;
  fprintf(_coverage_fout, "595\n");
  fflush(_coverage_fout);
  widths[35] = 176;
  fprintf(_coverage_fout, "596\n");
  fflush(_coverage_fout);
  widths[36] = 249;
  fprintf(_coverage_fout, "597\n");
  fflush(_coverage_fout);
  widths[37] = 354;
  fprintf(_coverage_fout, "598\n");
  fflush(_coverage_fout);
  widths[38] = 499;
  fprintf(_coverage_fout, "599\n");
  fflush(_coverage_fout);
  widths[39] = 709;
  fprintf(_coverage_fout, "600\n");
  fflush(_coverage_fout);
  widths[40] = 1001;
  fprintf(_coverage_fout, "601\n");
  fflush(_coverage_fout);
  widths[41] = 1417;
  fprintf(_coverage_fout, "602\n");
  fflush(_coverage_fout);
  widths[42] = 2004;
  fprintf(_coverage_fout, "603\n");
  fflush(_coverage_fout);
  widths[43] = 2835;
  fprintf(_coverage_fout, "604\n");
  fflush(_coverage_fout);
  widths[44] = 91;
  fprintf(_coverage_fout, "605\n");
  fflush(_coverage_fout);
  widths[45] = 128;
  fprintf(_coverage_fout, "606\n");
  fflush(_coverage_fout);
  widths[46] = 181;
  fprintf(_coverage_fout, "607\n");
  fflush(_coverage_fout);
  widths[47] = 258;
  fprintf(_coverage_fout, "608\n");
  fflush(_coverage_fout);
  widths[48] = 363;
  fprintf(_coverage_fout, "609\n");
  fflush(_coverage_fout);
  widths[49] = 516;
  fprintf(_coverage_fout, "610\n");
  fflush(_coverage_fout);
  widths[50] = 729;
  fprintf(_coverage_fout, "611\n");
  fflush(_coverage_fout);
  widths[51] = 1032;
  fprintf(_coverage_fout, "612\n");
  fflush(_coverage_fout);
  widths[52] = 1460;
  fprintf(_coverage_fout, "613\n");
  fflush(_coverage_fout);
  widths[53] = 2064;
  fprintf(_coverage_fout, "614\n");
  fflush(_coverage_fout);
  widths[54] = 2920;
  fprintf(_coverage_fout, "615\n");
  fflush(_coverage_fout);
  widths[55] = 79;
  fprintf(_coverage_fout, "616\n");
  fflush(_coverage_fout);
  widths[56] = 113;
  fprintf(_coverage_fout, "617\n");
  fflush(_coverage_fout);
  widths[57] = 162;
  fprintf(_coverage_fout, "618\n");
  fflush(_coverage_fout);
  widths[58] = 230;
  fprintf(_coverage_fout, "619\n");
  fflush(_coverage_fout);
  widths[59] = 323;
  fprintf(_coverage_fout, "620\n");
  fflush(_coverage_fout);
  widths[60] = 459;
  fprintf(_coverage_fout, "621\n");
  fflush(_coverage_fout);
  widths[61] = 649;
  fprintf(_coverage_fout, "622\n");
  fflush(_coverage_fout);
  widths[62] = 918;
  fprintf(_coverage_fout, "623\n");
  fflush(_coverage_fout);
  widths[63] = 1298;
  fprintf(_coverage_fout, "624\n");
  fflush(_coverage_fout);
  widths[64] = 1298;
  fprintf(_coverage_fout, "625\n");
  fflush(_coverage_fout);
  widths[65] = 2599;
  fprintf(_coverage_fout, "626\n");
  fflush(_coverage_fout);
  widths[66] = 1219;
  fprintf(_coverage_fout, "627\n");
  fflush(_coverage_fout);
  widths[67] = 1729;
  fprintf(_coverage_fout, "628\n");
  fflush(_coverage_fout);
  widths[68] = 2438;
  fprintf(_coverage_fout, "629\n");
  fflush(_coverage_fout);
  widths[69] = 638;
  fprintf(_coverage_fout, "630\n");
  fflush(_coverage_fout);
  widths[70] = 907;
  fprintf(_coverage_fout, "631\n");
  fflush(_coverage_fout);
  widths[71] = 1276;
  fprintf(_coverage_fout, "632\n");
  fflush(_coverage_fout);
  widths[72] = 1814;
  fprintf(_coverage_fout, "633\n");
  fflush(_coverage_fout);
  widths[73] = 2551;
  fprintf(_coverage_fout, "634\n");
  fflush(_coverage_fout);
  widths[74] = 914;
  fprintf(_coverage_fout, "635\n");
  fflush(_coverage_fout);
  widths[75] = 667;
  fprintf(_coverage_fout, "636\n");
  fflush(_coverage_fout);
  widths[76] = 396;
  fprintf(_coverage_fout, "637\n");
  fflush(_coverage_fout);
  widths[77] = 612;
  fprintf(_coverage_fout, "638\n");
  fflush(_coverage_fout);
  widths[78] = 609;
  fprintf(_coverage_fout, "639\n");
  fflush(_coverage_fout);
  widths[79] = 0;
  fprintf(_coverage_fout, "640\n");
  fflush(_coverage_fout);
  lengths[0] = 792;
  fprintf(_coverage_fout, "641\n");
  fflush(_coverage_fout);
  lengths[1] = 842;
  fprintf(_coverage_fout, "642\n");
  fflush(_coverage_fout);
  lengths[2] = 1008;
  fprintf(_coverage_fout, "643\n");
  fflush(_coverage_fout);
  lengths[3] = 756;
  fprintf(_coverage_fout, "644\n");
  fflush(_coverage_fout);
  lengths[4] = 792;
  fprintf(_coverage_fout, "645\n");
  fflush(_coverage_fout);
  lengths[5] = 1008;
  fprintf(_coverage_fout, "646\n");
  fflush(_coverage_fout);
  lengths[6] = 1224;
  fprintf(_coverage_fout, "647\n");
  fflush(_coverage_fout);
  lengths[7] = 1224;
  fprintf(_coverage_fout, "648\n");
  fflush(_coverage_fout);
  lengths[8] = 792;
  fprintf(_coverage_fout, "649\n");
  fflush(_coverage_fout);
  lengths[9] = 1224;
  fprintf(_coverage_fout, "650\n");
  fflush(_coverage_fout);
  lengths[10] = 1584;
  fprintf(_coverage_fout, "651\n");
  fflush(_coverage_fout);
  lengths[11] = 2448;
  fprintf(_coverage_fout, "652\n");
  fflush(_coverage_fout);
  lengths[12] = 3168;
  fprintf(_coverage_fout, "653\n");
  fflush(_coverage_fout);
  lengths[13] = 2880;
  fprintf(_coverage_fout, "654\n");
  fflush(_coverage_fout);
  lengths[14] = 6480;
  fprintf(_coverage_fout, "655\n");
  fflush(_coverage_fout);
  lengths[15] = 10296;
  fprintf(_coverage_fout, "656\n");
  fflush(_coverage_fout);
  lengths[16] = 12672;
  fprintf(_coverage_fout, "657\n");
  fflush(_coverage_fout);
  lengths[17] = 10296;
  fprintf(_coverage_fout, "658\n");
  fflush(_coverage_fout);
  lengths[18] = 105;
  fprintf(_coverage_fout, "659\n");
  fflush(_coverage_fout);
  lengths[19] = 147;
  fprintf(_coverage_fout, "660\n");
  fflush(_coverage_fout);
  lengths[20] = 210;
  fprintf(_coverage_fout, "661\n");
  fflush(_coverage_fout);
  lengths[21] = 298;
  fprintf(_coverage_fout, "662\n");
  fflush(_coverage_fout);
  lengths[22] = 420;
  fprintf(_coverage_fout, "663\n");
  fflush(_coverage_fout);
  lengths[23] = 595;
  fprintf(_coverage_fout, "664\n");
  fflush(_coverage_fout);
  lengths[24] = 842;
  fprintf(_coverage_fout, "665\n");
  fflush(_coverage_fout);
  lengths[25] = 1191;
  fprintf(_coverage_fout, "666\n");
  fflush(_coverage_fout);
  lengths[26] = 1684;
  fprintf(_coverage_fout, "667\n");
  fflush(_coverage_fout);
  lengths[27] = 2384;
  fprintf(_coverage_fout, "668\n");
  fflush(_coverage_fout);
  lengths[28] = 3370;
  fprintf(_coverage_fout, "669\n");
  fflush(_coverage_fout);
  lengths[29] = 4768;
  fprintf(_coverage_fout, "670\n");
  fflush(_coverage_fout);
  lengths[30] = 6741;
  fprintf(_coverage_fout, "671\n");
  fflush(_coverage_fout);
  lengths[31] = 4768;
  fprintf(_coverage_fout, "672\n");
  fflush(_coverage_fout);
  lengths[32] = 6741;
  fprintf(_coverage_fout, "673\n");
  fflush(_coverage_fout);
  lengths[33] = 125;
  fprintf(_coverage_fout, "674\n");
  fflush(_coverage_fout);
  lengths[34] = 176;
  fprintf(_coverage_fout, "675\n");
  fflush(_coverage_fout);
  lengths[35] = 249;
  fprintf(_coverage_fout, "676\n");
  fflush(_coverage_fout);
  lengths[36] = 354;
  fprintf(_coverage_fout, "677\n");
  fflush(_coverage_fout);
  lengths[37] = 499;
  fprintf(_coverage_fout, "678\n");
  fflush(_coverage_fout);
  lengths[38] = 709;
  fprintf(_coverage_fout, "679\n");
  fflush(_coverage_fout);
  lengths[39] = 1001;
  fprintf(_coverage_fout, "680\n");
  fflush(_coverage_fout);
  lengths[40] = 1417;
  fprintf(_coverage_fout, "681\n");
  fflush(_coverage_fout);
  lengths[41] = 2004;
  fprintf(_coverage_fout, "682\n");
  fflush(_coverage_fout);
  lengths[42] = 2835;
  fprintf(_coverage_fout, "683\n");
  fflush(_coverage_fout);
  lengths[43] = 4008;
  fprintf(_coverage_fout, "684\n");
  fflush(_coverage_fout);
  lengths[44] = 128;
  fprintf(_coverage_fout, "685\n");
  fflush(_coverage_fout);
  lengths[45] = 181;
  fprintf(_coverage_fout, "686\n");
  fflush(_coverage_fout);
  lengths[46] = 258;
  fprintf(_coverage_fout, "687\n");
  fflush(_coverage_fout);
  lengths[47] = 363;
  fprintf(_coverage_fout, "688\n");
  fflush(_coverage_fout);
  lengths[48] = 516;
  fprintf(_coverage_fout, "689\n");
  fflush(_coverage_fout);
  lengths[49] = 729;
  fprintf(_coverage_fout, "690\n");
  fflush(_coverage_fout);
  lengths[50] = 1032;
  fprintf(_coverage_fout, "691\n");
  fflush(_coverage_fout);
  lengths[51] = 1460;
  fprintf(_coverage_fout, "692\n");
  fflush(_coverage_fout);
  lengths[52] = 2064;
  fprintf(_coverage_fout, "693\n");
  fflush(_coverage_fout);
  lengths[53] = 2920;
  fprintf(_coverage_fout, "694\n");
  fflush(_coverage_fout);
  lengths[54] = 4127;
  fprintf(_coverage_fout, "695\n");
  fflush(_coverage_fout);
  lengths[55] = 113;
  fprintf(_coverage_fout, "696\n");
  fflush(_coverage_fout);
  lengths[56] = 162;
  fprintf(_coverage_fout, "697\n");
  fflush(_coverage_fout);
  lengths[57] = 230;
  fprintf(_coverage_fout, "698\n");
  fflush(_coverage_fout);
  lengths[58] = 323;
  fprintf(_coverage_fout, "699\n");
  fflush(_coverage_fout);
  lengths[59] = 459;
  fprintf(_coverage_fout, "700\n");
  fflush(_coverage_fout);
  lengths[60] = 649;
  fprintf(_coverage_fout, "701\n");
  fflush(_coverage_fout);
  lengths[61] = 918;
  fprintf(_coverage_fout, "702\n");
  fflush(_coverage_fout);
  lengths[62] = 1298;
  fprintf(_coverage_fout, "703\n");
  fflush(_coverage_fout);
  lengths[63] = 1837;
  fprintf(_coverage_fout, "704\n");
  fflush(_coverage_fout);
  lengths[64] = 1837;
  fprintf(_coverage_fout, "705\n");
  fflush(_coverage_fout);
  lengths[65] = 3677;
  fprintf(_coverage_fout, "706\n");
  fflush(_coverage_fout);
  lengths[66] = 1729;
  fprintf(_coverage_fout, "707\n");
  fflush(_coverage_fout);
  lengths[67] = 2438;
  fprintf(_coverage_fout, "708\n");
  fflush(_coverage_fout);
  lengths[68] = 3458;
  fprintf(_coverage_fout, "709\n");
  fflush(_coverage_fout);
  lengths[69] = 907;
  fprintf(_coverage_fout, "710\n");
  fflush(_coverage_fout);
  lengths[70] = 1276;
  fprintf(_coverage_fout, "711\n");
  fflush(_coverage_fout);
  lengths[71] = 1814;
  fprintf(_coverage_fout, "712\n");
  fflush(_coverage_fout);
  lengths[72] = 2551;
  fprintf(_coverage_fout, "713\n");
  fflush(_coverage_fout);
  lengths[73] = 3628;
  fprintf(_coverage_fout, "714\n");
  fflush(_coverage_fout);
  lengths[74] = 1262;
  fprintf(_coverage_fout, "715\n");
  fflush(_coverage_fout);
  lengths[75] = 914;
  fprintf(_coverage_fout, "716\n");
  fflush(_coverage_fout);
  lengths[76] = 612;
  fprintf(_coverage_fout, "717\n");
  fflush(_coverage_fout);
  lengths[77] = 936;
  fprintf(_coverage_fout, "718\n");
  fflush(_coverage_fout);
  lengths[78] = 780;
  fprintf(_coverage_fout, "719\n");
  fflush(_coverage_fout);
  lengths[79] = 0;
  fprintf(_coverage_fout, "720\n");
  fflush(_coverage_fout);
  len = strlen((char const   *)papersize);
  fprintf(_coverage_fout, "721\n");
  fflush(_coverage_fout);
  i = 0U;
  fprintf(_coverage_fout, "722\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "450\n");
    fflush(_coverage_fout);
    if (i < len) {
      fprintf(_coverage_fout, "446\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "451\n");
    fflush(_coverage_fout);
    if (sizeof(*(papersize + i)) > 1U) {
      fprintf(_coverage_fout, "447\n");
      fflush(_coverage_fout);
      __res = toupper((int )*(papersize + i));
    } else {
      fprintf(_coverage_fout, "448\n");
      fflush(_coverage_fout);
      tmp___0 = __ctype_toupper_loc();
      fprintf(_coverage_fout, "449\n");
      fflush(_coverage_fout);
      __res = (int )*(*tmp___0 + (int )*(papersize + i));
    }
    fprintf(_coverage_fout, "452\n");
    fflush(_coverage_fout);
    *(papersize + i) = (char )__res;
    fprintf(_coverage_fout, "453\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "723\n");
  fflush(_coverage_fout);
  i = 0U;
  fprintf(_coverage_fout, "724\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "476\n");
    fflush(_coverage_fout);
    if ((unsigned int )sizes[i] != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "454\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "477\n");
    fflush(_coverage_fout);
    if (0) {
      fprintf(_coverage_fout, "466\n");
      fflush(_coverage_fout);
      __s1_len = strlen((char const   *)papersize);
      fprintf(_coverage_fout, "467\n");
      fflush(_coverage_fout);
      __s2_len = strlen(sizes[i]);
      fprintf(_coverage_fout, "468\n");
      fflush(_coverage_fout);
      if (! ((unsigned int )((void const   *)((char const   *)papersize + 1)) - (unsigned int )((void const   *)((char const   *)papersize)) == 1U)) {
        goto _L___0;
      } else {
        fprintf(_coverage_fout, "461\n");
        fflush(_coverage_fout);
        if (__s1_len >= 4U) {
          fprintf(_coverage_fout, "459\n");
          fflush(_coverage_fout);
          _L___0: /* CIL Label */ 
          if (! ((unsigned int )((void const   *)(sizes[i] + 1)) - (unsigned int )((void const   *)sizes[i]) == 1U)) {
            fprintf(_coverage_fout, "455\n");
            fflush(_coverage_fout);
            tmp___7 = 1;
          } else {
            fprintf(_coverage_fout, "458\n");
            fflush(_coverage_fout);
            if (__s2_len >= 4U) {
              fprintf(_coverage_fout, "456\n");
              fflush(_coverage_fout);
              tmp___7 = 1;
            } else {
              fprintf(_coverage_fout, "457\n");
              fflush(_coverage_fout);
              tmp___7 = 0;
            }
          }
        } else {
          fprintf(_coverage_fout, "460\n");
          fflush(_coverage_fout);
          tmp___7 = 0;
        }
      }
      fprintf(_coverage_fout, "469\n");
      fflush(_coverage_fout);
      if (tmp___7) {
        fprintf(_coverage_fout, "462\n");
        fflush(_coverage_fout);
        tmp___2 = __builtin_strcmp((char const   *)papersize, sizes[i]);
        fprintf(_coverage_fout, "463\n");
        fflush(_coverage_fout);
        tmp___6 = tmp___2;
      } else {
        fprintf(_coverage_fout, "464\n");
        fflush(_coverage_fout);
        tmp___5 = __builtin_strcmp((char const   *)papersize, sizes[i]);
        fprintf(_coverage_fout, "465\n");
        fflush(_coverage_fout);
        tmp___6 = tmp___5;
      }
    } else {
      fprintf(_coverage_fout, "470\n");
      fflush(_coverage_fout);
      tmp___5 = __builtin_strcmp((char const   *)papersize, sizes[i]);
      fprintf(_coverage_fout, "471\n");
      fflush(_coverage_fout);
      tmp___6 = tmp___5;
    }
    fprintf(_coverage_fout, "478\n");
    fflush(_coverage_fout);
    if (tmp___6 == 0) {
      fprintf(_coverage_fout, "472\n");
      fflush(_coverage_fout);
      *width = (float )widths[i];
      fprintf(_coverage_fout, "473\n");
      fflush(_coverage_fout);
      *length = (float )lengths[i];
      fprintf(_coverage_fout, "474\n");
      fflush(_coverage_fout);
      return (1);
    } else {
      fprintf(_coverage_fout, "475\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "479\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "725\n");
  fflush(_coverage_fout);
  return (0);
}
}
T2P *t2p_init(void) 
{ T2P *t2p ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "729\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )sizeof(T2P ));
  fprintf(_coverage_fout, "730\n");
  fflush(_coverage_fout);
  t2p = (T2P *)tmp;
  fprintf(_coverage_fout, "731\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "726\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "Can\'t allocate %lu bytes of memory for t2p_init",
              (unsigned long )sizeof(T2P ));
    fprintf(_coverage_fout, "727\n");
    fflush(_coverage_fout);
    return ((T2P *)((void *)0));
  } else {
    fprintf(_coverage_fout, "728\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "732\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)t2p, 0x00, (long )sizeof(T2P ));
  fprintf(_coverage_fout, "733\n");
  fflush(_coverage_fout);
  t2p->pdf_majorversion = (unsigned short)1;
  fprintf(_coverage_fout, "734\n");
  fflush(_coverage_fout);
  t2p->pdf_minorversion = (unsigned short)1;
  fprintf(_coverage_fout, "735\n");
  fflush(_coverage_fout);
  t2p->pdf_defaultxres = (float )300.0;
  fprintf(_coverage_fout, "736\n");
  fflush(_coverage_fout);
  t2p->pdf_defaultyres = (float )300.0;
  fprintf(_coverage_fout, "737\n");
  fflush(_coverage_fout);
  t2p->pdf_defaultpagewidth = (float )612.0;
  fprintf(_coverage_fout, "738\n");
  fflush(_coverage_fout);
  t2p->pdf_defaultpagelength = (float )792.0;
  fprintf(_coverage_fout, "739\n");
  fflush(_coverage_fout);
  t2p->pdf_xrefcount = 3U;
  fprintf(_coverage_fout, "740\n");
  fflush(_coverage_fout);
  return (t2p);
}
}
void t2p_free(T2P *t2p ) 
{ int i ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "766\n");
  fflush(_coverage_fout);
  i = 0;
  fprintf(_coverage_fout, "767\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "757\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_xrefoffsets != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "741\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)t2p->pdf_xrefoffsets);
    } else {
      fprintf(_coverage_fout, "742\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "758\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->tiff_pages != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "743\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)t2p->tiff_pages);
    } else {
      fprintf(_coverage_fout, "744\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "759\n");
    fflush(_coverage_fout);
    i = 0;
    fprintf(_coverage_fout, "760\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "748\n");
      fflush(_coverage_fout);
      if (i < (int )t2p->tiff_pagecount) {
        fprintf(_coverage_fout, "745\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "749\n");
      fflush(_coverage_fout);
      if ((unsigned int )(t2p->tiff_tiles + i)->tiles_tiles != (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "746\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)(t2p->tiff_tiles + i)->tiles_tiles);
      } else {
        fprintf(_coverage_fout, "747\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "750\n");
      fflush(_coverage_fout);
      i ++;
    }
    fprintf(_coverage_fout, "761\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->tiff_tiles != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "751\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)t2p->tiff_tiles);
    } else {
      fprintf(_coverage_fout, "752\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "762\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_palette != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "753\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)t2p->pdf_palette);
    } else {
      fprintf(_coverage_fout, "754\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "763\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_fileid != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "755\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)t2p->pdf_fileid);
    } else {
      fprintf(_coverage_fout, "756\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "764\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)t2p);
  } else {
    fprintf(_coverage_fout, "765\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "768\n");
  fflush(_coverage_fout);
  return;
}
}
void t2p_validate(T2P *t2p ) 
{ uint16 m ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "788\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_defaultcompression == 4U) {
    fprintf(_coverage_fout, "782\n");
    fflush(_coverage_fout);
    m = (uint16 )((int )t2p->pdf_defaultcompressionquality % 100);
    fprintf(_coverage_fout, "783\n");
    fflush(_coverage_fout);
    if ((int )t2p->pdf_defaultcompressionquality / 100 > 9) {
      fprintf(_coverage_fout, "769\n");
      fflush(_coverage_fout);
      t2p->pdf_defaultcompressionquality = (unsigned short)0;
    } else {
      fprintf(_coverage_fout, "775\n");
      fflush(_coverage_fout);
      if ((int )m > 1) {
        fprintf(_coverage_fout, "771\n");
        fflush(_coverage_fout);
        if ((int )m < 10) {
          fprintf(_coverage_fout, "770\n");
          fflush(_coverage_fout);
          t2p->pdf_defaultcompressionquality = (unsigned short)0;
        } else {
          goto _L;
        }
      } else {
        fprintf(_coverage_fout, "774\n");
        fflush(_coverage_fout);
        _L: /* CIL Label */ 
        if ((int )m > 15) {
          fprintf(_coverage_fout, "772\n");
          fflush(_coverage_fout);
          t2p->pdf_defaultcompressionquality = (unsigned short)0;
        } else {
          fprintf(_coverage_fout, "773\n");
          fflush(_coverage_fout);

        }
      }
    }
    fprintf(_coverage_fout, "784\n");
    fflush(_coverage_fout);
    if ((int )t2p->pdf_defaultcompressionquality % 100 != 0) {
      fprintf(_coverage_fout, "776\n");
      fflush(_coverage_fout);
      t2p->pdf_defaultcompressionquality = (unsigned short )((int )t2p->pdf_defaultcompressionquality / 100);
      fprintf(_coverage_fout, "777\n");
      fflush(_coverage_fout);
      t2p->pdf_defaultcompressionquality = (unsigned short )((int )t2p->pdf_defaultcompressionquality * 100);
      fprintf(_coverage_fout, "778\n");
      fflush(_coverage_fout);
      TIFFError("tiff2pdf",
                "PNG Group predictor differencing not implemented, assuming compression quality %u",
                t2p->pdf_defaultcompressionquality);
    } else {
      fprintf(_coverage_fout, "779\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "785\n");
    fflush(_coverage_fout);
    t2p->pdf_defaultcompressionquality = (unsigned short )((int )t2p->pdf_defaultcompressionquality % 100);
    fprintf(_coverage_fout, "786\n");
    fflush(_coverage_fout);
    if ((int )t2p->pdf_minorversion < 2) {
      fprintf(_coverage_fout, "780\n");
      fflush(_coverage_fout);
      t2p->pdf_minorversion = (unsigned short)2;
    } else {
      fprintf(_coverage_fout, "781\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "787\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "789\n");
  fflush(_coverage_fout);
  return;
}
}
void t2p_read_tiff_init(T2P *t2p , TIFF *input ) 
{ tdir_t directorycount ;
  tdir_t i ;
  uint16 pagen ;
  uint16 paged ;
  uint16 xuint16 ;
  void *tmp ;
  char const   *tmp___0 ;
  void *tmp___1 ;
  char const   *tmp___2 ;
  uint32 subfiletype ;
  char const   *tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  uint32 tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  void *tmp___16 ;
  char const   *tmp___17 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "908\n");
  fflush(_coverage_fout);
  directorycount = (tdir_t )0;
  fprintf(_coverage_fout, "909\n");
  fflush(_coverage_fout);
  i = (tdir_t )0;
  fprintf(_coverage_fout, "910\n");
  fflush(_coverage_fout);
  pagen = (uint16 )0;
  fprintf(_coverage_fout, "911\n");
  fflush(_coverage_fout);
  paged = (uint16 )0;
  fprintf(_coverage_fout, "912\n");
  fflush(_coverage_fout);
  xuint16 = (uint16 )0;
  fprintf(_coverage_fout, "913\n");
  fflush(_coverage_fout);
  directorycount = TIFFNumberOfDirectories(input);
  fprintf(_coverage_fout, "914\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((unsigned int )directorycount * sizeof(T2P_PAGE )));
  fprintf(_coverage_fout, "915\n");
  fflush(_coverage_fout);
  t2p->tiff_pages = (T2P_PAGE *)tmp;
  fprintf(_coverage_fout, "916\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->tiff_pages == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "790\n");
    fflush(_coverage_fout);
    tmp___0 = TIFFFileName(input);
    fprintf(_coverage_fout, "791\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf",
              "Can\'t allocate %lu bytes of memory for tiff_pages array, %s",
              (unsigned long )directorycount * (unsigned long )sizeof(T2P_PAGE ),
              tmp___0);
    fprintf(_coverage_fout, "792\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "793\n");
    fflush(_coverage_fout);
    return;
  } else {
    fprintf(_coverage_fout, "794\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "917\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)t2p->tiff_pages, 0x00,
              (long )((unsigned int )directorycount * sizeof(T2P_PAGE )));
  fprintf(_coverage_fout, "918\n");
  fflush(_coverage_fout);
  tmp___1 = _TIFFmalloc((long )((unsigned int )directorycount * sizeof(T2P_TILES )));
  fprintf(_coverage_fout, "919\n");
  fflush(_coverage_fout);
  t2p->tiff_tiles = (T2P_TILES *)tmp___1;
  fprintf(_coverage_fout, "920\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->tiff_tiles == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "795\n");
    fflush(_coverage_fout);
    tmp___2 = TIFFFileName(input);
    fprintf(_coverage_fout, "796\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf",
              "Can\'t allocate %lu bytes of memory for tiff_tiles array, %s",
              (unsigned long )directorycount * (unsigned long )sizeof(T2P_TILES ),
              tmp___2);
    fprintf(_coverage_fout, "797\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "798\n");
    fflush(_coverage_fout);
    return;
  } else {
    fprintf(_coverage_fout, "799\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "921\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)t2p->tiff_tiles, 0x00,
              (long )((unsigned int )directorycount * sizeof(T2P_TILES )));
  fprintf(_coverage_fout, "922\n");
  fflush(_coverage_fout);
  i = (unsigned short)0;
  fprintf(_coverage_fout, "923\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "820\n");
    fflush(_coverage_fout);
    if ((int )i < (int )directorycount) {
      fprintf(_coverage_fout, "800\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "821\n");
    fflush(_coverage_fout);
    subfiletype = (uint32 )0;
    fprintf(_coverage_fout, "822\n");
    fflush(_coverage_fout);
    tmp___4 = TIFFSetDirectory(input, i);
    fprintf(_coverage_fout, "823\n");
    fflush(_coverage_fout);
    if (tmp___4) {
      fprintf(_coverage_fout, "801\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "802\n");
      fflush(_coverage_fout);
      tmp___3 = TIFFFileName(input);
      fprintf(_coverage_fout, "803\n");
      fflush(_coverage_fout);
      TIFFError("tiff2pdf", "Can\'t set directory %u of input file %s", i,
                tmp___3);
      fprintf(_coverage_fout, "804\n");
      fflush(_coverage_fout);
      return;
    }
    fprintf(_coverage_fout, "824\n");
    fflush(_coverage_fout);
    tmp___5 = TIFFGetField(input, 297U, & pagen, & paged);
    fprintf(_coverage_fout, "825\n");
    fflush(_coverage_fout);
    if (tmp___5) {
      fprintf(_coverage_fout, "809\n");
      fflush(_coverage_fout);
      if ((int )pagen > (int )paged) {
        fprintf(_coverage_fout, "807\n");
        fflush(_coverage_fout);
        if ((int )paged != 0) {
          fprintf(_coverage_fout, "805\n");
          fflush(_coverage_fout);
          (t2p->tiff_pages + t2p->tiff_pagecount)->page_number = (unsigned int )paged;
        } else {
          fprintf(_coverage_fout, "806\n");
          fflush(_coverage_fout);
          (t2p->tiff_pages + t2p->tiff_pagecount)->page_number = (unsigned int )pagen;
        }
      } else {
        fprintf(_coverage_fout, "808\n");
        fflush(_coverage_fout);
        (t2p->tiff_pages + t2p->tiff_pagecount)->page_number = (unsigned int )pagen;
      }
      goto ispage2;
    } else {
      fprintf(_coverage_fout, "810\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "826\n");
    fflush(_coverage_fout);
    tmp___6 = TIFFGetField(input, 254U, & subfiletype);
    fprintf(_coverage_fout, "827\n");
    fflush(_coverage_fout);
    if (tmp___6) {
      fprintf(_coverage_fout, "812\n");
      fflush(_coverage_fout);
      if ((subfiletype & 2U) != 0U) {
        goto ispage;
      } else {
        fprintf(_coverage_fout, "811\n");
        fflush(_coverage_fout);
        if (subfiletype == 0U) {
          goto ispage;
        } else {
          goto isnotpage;
        }
      }
    } else {
      fprintf(_coverage_fout, "813\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "828\n");
    fflush(_coverage_fout);
    tmp___7 = TIFFGetField(input, 255U, & subfiletype);
    fprintf(_coverage_fout, "829\n");
    fflush(_coverage_fout);
    if (tmp___7) {
      fprintf(_coverage_fout, "816\n");
      fflush(_coverage_fout);
      if (subfiletype == 1U) {
        goto ispage;
      } else {
        fprintf(_coverage_fout, "815\n");
        fflush(_coverage_fout);
        if (subfiletype == 3U) {
          goto ispage;
        } else {
          fprintf(_coverage_fout, "814\n");
          fflush(_coverage_fout);
          if (subfiletype == 0U) {
            goto ispage;
          } else {
            goto isnotpage;
          }
        }
      }
    } else {
      fprintf(_coverage_fout, "817\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "830\n");
    fflush(_coverage_fout);
    ispage: 
    (t2p->tiff_pages + t2p->tiff_pagecount)->page_number = (unsigned int )t2p->tiff_pagecount;
    fprintf(_coverage_fout, "831\n");
    fflush(_coverage_fout);
    ispage2: 
    (t2p->tiff_pages + t2p->tiff_pagecount)->page_directory = i;
    fprintf(_coverage_fout, "832\n");
    fflush(_coverage_fout);
    tmp___8 = TIFFIsTiled(input);
    fprintf(_coverage_fout, "833\n");
    fflush(_coverage_fout);
    if (tmp___8) {
      fprintf(_coverage_fout, "818\n");
      fflush(_coverage_fout);
      (t2p->tiff_pages + t2p->tiff_pagecount)->page_tilecount = TIFFNumberOfTiles(input);
    } else {
      fprintf(_coverage_fout, "819\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "834\n");
    fflush(_coverage_fout);
    t2p->tiff_pagecount = (tdir_t )((int )t2p->tiff_pagecount + 1);
    fprintf(_coverage_fout, "835\n");
    fflush(_coverage_fout);
    isnotpage: 
    i = (tdir_t )((int )i + 1);
  }
  fprintf(_coverage_fout, "924\n");
  fflush(_coverage_fout);
  qsort((void *)t2p->tiff_pages, (unsigned int )t2p->tiff_pagecount,
        sizeof(T2P_PAGE ), & t2p_cmp_t2p_page);
  fprintf(_coverage_fout, "925\n");
  fflush(_coverage_fout);
  i = (unsigned short)0;
  fprintf(_coverage_fout, "926\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "892\n");
    fflush(_coverage_fout);
    if ((int )i < (int )t2p->tiff_pagecount) {
      fprintf(_coverage_fout, "836\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "893\n");
    fflush(_coverage_fout);
    t2p->pdf_xrefcount += 5U;
    fprintf(_coverage_fout, "894\n");
    fflush(_coverage_fout);
    TIFFSetDirectory(input, (t2p->tiff_pages + i)->page_directory);
    fprintf(_coverage_fout, "895\n");
    fflush(_coverage_fout);
    tmp___9 = TIFFGetField(input, 262U, & xuint16);
    fprintf(_coverage_fout, "896\n");
    fflush(_coverage_fout);
    if (tmp___9) {
      fprintf(_coverage_fout, "839\n");
      fflush(_coverage_fout);
      if ((int )xuint16 == 3) {
        fprintf(_coverage_fout, "837\n");
        fflush(_coverage_fout);
        ((t2p->tiff_pages + i)->page_extra) ++;
        fprintf(_coverage_fout, "838\n");
        fflush(_coverage_fout);
        (t2p->pdf_xrefcount) ++;
      } else {
        goto _L;
      }
    } else {
      fprintf(_coverage_fout, "843\n");
      fflush(_coverage_fout);
      _L: /* CIL Label */ 
      tmp___10 = TIFFGetField(input, 346U, & xuint16);
      fprintf(_coverage_fout, "844\n");
      fflush(_coverage_fout);
      if (tmp___10) {
        fprintf(_coverage_fout, "840\n");
        fflush(_coverage_fout);
        ((t2p->tiff_pages + i)->page_extra) ++;
        fprintf(_coverage_fout, "841\n");
        fflush(_coverage_fout);
        (t2p->pdf_xrefcount) ++;
      } else {
        fprintf(_coverage_fout, "842\n");
        fflush(_coverage_fout);

      }
    }
    fprintf(_coverage_fout, "897\n");
    fflush(_coverage_fout);
    tmp___12 = TIFFGetField(input, 259U, & xuint16);
    fprintf(_coverage_fout, "898\n");
    fflush(_coverage_fout);
    if (tmp___12) {
      fprintf(_coverage_fout, "856\n");
      fflush(_coverage_fout);
      if ((int )xuint16 == 32946) {
        goto _L___1;
      } else {
        fprintf(_coverage_fout, "855\n");
        fflush(_coverage_fout);
        if ((int )xuint16 == 8) {
          fprintf(_coverage_fout, "853\n");
          fflush(_coverage_fout);
          _L___1: /* CIL Label */ 
          if ((t2p->tiff_pages + i)->page_tilecount != 0U) {
            goto _L___0;
          } else {
            fprintf(_coverage_fout, "851\n");
            fflush(_coverage_fout);
            tmp___11 = TIFFNumberOfStrips(input);
            fprintf(_coverage_fout, "852\n");
            fflush(_coverage_fout);
            if (tmp___11 == 1U) {
              fprintf(_coverage_fout, "849\n");
              fflush(_coverage_fout);
              _L___0: /* CIL Label */ 
              if ((int )t2p->pdf_nopassthrough == 0) {
                fprintf(_coverage_fout, "847\n");
                fflush(_coverage_fout);
                if ((int )t2p->pdf_minorversion < 2) {
                  fprintf(_coverage_fout, "845\n");
                  fflush(_coverage_fout);
                  t2p->pdf_minorversion = (unsigned short)2;
                } else {
                  fprintf(_coverage_fout, "846\n");
                  fflush(_coverage_fout);

                }
              } else {
                fprintf(_coverage_fout, "848\n");
                fflush(_coverage_fout);

              }
            } else {
              fprintf(_coverage_fout, "850\n");
              fflush(_coverage_fout);

            }
          }
        } else {
          fprintf(_coverage_fout, "854\n");
          fflush(_coverage_fout);

        }
      }
    } else {
      fprintf(_coverage_fout, "857\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "899\n");
    fflush(_coverage_fout);
    tmp___13 = TIFFGetField(input, 301U, & t2p->tiff_transferfunction[0],
                            & t2p->tiff_transferfunction[1],
                            & t2p->tiff_transferfunction[2]);
    fprintf(_coverage_fout, "900\n");
    fflush(_coverage_fout);
    if (tmp___13) {
      fprintf(_coverage_fout, "866\n");
      fflush(_coverage_fout);
      if ((unsigned int )t2p->tiff_transferfunction[1] != (unsigned int )t2p->tiff_transferfunction[0]) {
        fprintf(_coverage_fout, "858\n");
        fflush(_coverage_fout);
        t2p->tiff_transferfunctioncount = (unsigned short)3;
        fprintf(_coverage_fout, "859\n");
        fflush(_coverage_fout);
        (t2p->tiff_pages + i)->page_extra += 4U;
        fprintf(_coverage_fout, "860\n");
        fflush(_coverage_fout);
        t2p->pdf_xrefcount += 4U;
      } else {
        fprintf(_coverage_fout, "861\n");
        fflush(_coverage_fout);
        t2p->tiff_transferfunctioncount = (unsigned short)1;
        fprintf(_coverage_fout, "862\n");
        fflush(_coverage_fout);
        (t2p->tiff_pages + i)->page_extra += 2U;
        fprintf(_coverage_fout, "863\n");
        fflush(_coverage_fout);
        t2p->pdf_xrefcount += 2U;
      }
      fprintf(_coverage_fout, "867\n");
      fflush(_coverage_fout);
      if ((int )t2p->pdf_minorversion < 2) {
        fprintf(_coverage_fout, "864\n");
        fflush(_coverage_fout);
        t2p->pdf_minorversion = (unsigned short)2;
      } else {
        fprintf(_coverage_fout, "865\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "868\n");
      fflush(_coverage_fout);
      t2p->tiff_transferfunctioncount = (unsigned short)0;
    }
    fprintf(_coverage_fout, "901\n");
    fflush(_coverage_fout);
    tmp___14 = TIFFGetField(input, 34675U, & t2p->tiff_iccprofilelength,
                            & t2p->tiff_iccprofile);
    fprintf(_coverage_fout, "902\n");
    fflush(_coverage_fout);
    if (tmp___14 != 0) {
      fprintf(_coverage_fout, "871\n");
      fflush(_coverage_fout);
      ((t2p->tiff_pages + i)->page_extra) ++;
      fprintf(_coverage_fout, "872\n");
      fflush(_coverage_fout);
      (t2p->pdf_xrefcount) ++;
      fprintf(_coverage_fout, "873\n");
      fflush(_coverage_fout);
      if ((int )t2p->pdf_minorversion < 3) {
        fprintf(_coverage_fout, "869\n");
        fflush(_coverage_fout);
        t2p->pdf_minorversion = (unsigned short)3;
      } else {
        fprintf(_coverage_fout, "870\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "874\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "903\n");
    fflush(_coverage_fout);
    (t2p->tiff_tiles + i)->tiles_tilecount = (t2p->tiff_pages + i)->page_tilecount;
    fprintf(_coverage_fout, "904\n");
    fflush(_coverage_fout);
    tmp___15 = TIFFGetField(input, 284U, & xuint16);
    fprintf(_coverage_fout, "905\n");
    fflush(_coverage_fout);
    if (tmp___15 != 0) {
      fprintf(_coverage_fout, "878\n");
      fflush(_coverage_fout);
      if ((int )xuint16 == 2) {
        fprintf(_coverage_fout, "875\n");
        fflush(_coverage_fout);
        TIFFGetField(input, 277U, & xuint16);
        fprintf(_coverage_fout, "876\n");
        fflush(_coverage_fout);
        (t2p->tiff_tiles + i)->tiles_tilecount /= (ttile_t )xuint16;
      } else {
        fprintf(_coverage_fout, "877\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "879\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "906\n");
    fflush(_coverage_fout);
    if ((t2p->tiff_tiles + i)->tiles_tilecount > 0U) {
      fprintf(_coverage_fout, "885\n");
      fflush(_coverage_fout);
      t2p->pdf_xrefcount += ((t2p->tiff_tiles + i)->tiles_tilecount - 1U) * 2U;
      fprintf(_coverage_fout, "886\n");
      fflush(_coverage_fout);
      TIFFGetField(input, 322U, & (t2p->tiff_tiles + i)->tiles_tilewidth);
      fprintf(_coverage_fout, "887\n");
      fflush(_coverage_fout);
      TIFFGetField(input, 323U, & (t2p->tiff_tiles + i)->tiles_tilelength);
      fprintf(_coverage_fout, "888\n");
      fflush(_coverage_fout);
      tmp___16 = _TIFFmalloc((long )((t2p->tiff_tiles + i)->tiles_tilecount * sizeof(T2P_TILE )));
      fprintf(_coverage_fout, "889\n");
      fflush(_coverage_fout);
      (t2p->tiff_tiles + i)->tiles_tiles = (T2P_TILE *)tmp___16;
      fprintf(_coverage_fout, "890\n");
      fflush(_coverage_fout);
      if ((unsigned int )(t2p->tiff_tiles + i)->tiles_tiles == (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "880\n");
        fflush(_coverage_fout);
        tmp___17 = TIFFFileName(input);
        fprintf(_coverage_fout, "881\n");
        fflush(_coverage_fout);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_read_tiff_init, %s",
                  (unsigned long )(t2p->tiff_tiles + i)->tiles_tilecount * (unsigned long )sizeof(T2P_TILE ),
                  tmp___17);
        fprintf(_coverage_fout, "882\n");
        fflush(_coverage_fout);
        t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
        fprintf(_coverage_fout, "883\n");
        fflush(_coverage_fout);
        return;
      } else {
        fprintf(_coverage_fout, "884\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "891\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "907\n");
    fflush(_coverage_fout);
    i = (tdir_t )((int )i + 1);
  }
  fprintf(_coverage_fout, "927\n");
  fflush(_coverage_fout);
  return;
}
}
int t2p_cmp_t2p_page(void const   *e1 , void const   *e2 ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "928\n");
  fflush(_coverage_fout);
  return ((int )(((T2P_PAGE *)e1)->page_number - ((T2P_PAGE *)e2)->page_number));
}
}
void t2p_read_tiff_data(T2P *t2p , TIFF *input ) 
{ int i ;
  uint16 *r ;
  uint16 *g ;
  uint16 *b ;
  uint16 *a ;
  uint16 xuint16 ;
  uint16 *xuint16p ;
  float *xfloatp ;
  char const   *tmp ;
  char const   *tmp___0 ;
  char const   *tmp___1 ;
  int tmp___2 ;
  char const   *tmp___3 ;
  int tmp___4 ;
  char const   *tmp___5 ;
  char const   *tmp___6 ;
  char const   *tmp___7 ;
  char const   *tmp___8 ;
  char const   *tmp___9 ;
  int tmp___10 ;
  char const   *tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  char const   *tmp___14 ;
  int tmp___15 ;
  char const   *tmp___16 ;
  char const   *tmp___17 ;
  char const   *tmp___18 ;
  char const   *tmp___19 ;
  char const   *tmp___20 ;
  int tmp___21 ;
  void *tmp___22 ;
  char const   *tmp___23 ;
  int tmp___24 ;
  char const   *tmp___25 ;
  int tmp___26 ;
  char const   *tmp___27 ;
  char const   *tmp___28 ;
  char const   *tmp___29 ;
  int tmp___30 ;
  void *tmp___31 ;
  char const   *tmp___32 ;
  char const   *tmp___33 ;
  char const   *tmp___34 ;
  char const   *tmp___35 ;
  char const   *tmp___36 ;
  char const   *tmp___37 ;
  int tmp___38 ;
  char const   *tmp___39 ;
  int tmp___40 ;
  int tmp___41 ;
  int tmp___42 ;
  uint32 tmp___43 ;
  int tmp___44 ;
  uint32 tmp___45 ;
  int tmp___46 ;
  int tmp___47 ;
  int tmp___48 ;
  int tmp___49 ;
  int tmp___50 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1242\n");
  fflush(_coverage_fout);
  i = 0;
  fprintf(_coverage_fout, "1243\n");
  fflush(_coverage_fout);
  t2p->pdf_transcode = (enum __anonenum_t2p_transcode_t_52 )2;
  fprintf(_coverage_fout, "1244\n");
  fflush(_coverage_fout);
  t2p->pdf_sample = (enum __anonenum_t2p_sample_t_53 )0;
  fprintf(_coverage_fout, "1245\n");
  fflush(_coverage_fout);
  t2p->pdf_switchdecode = t2p->pdf_colorspace_invert;
  fprintf(_coverage_fout, "1246\n");
  fflush(_coverage_fout);
  TIFFSetDirectory(input, (t2p->tiff_pages + t2p->pdf_page)->page_directory);
  fprintf(_coverage_fout, "1247\n");
  fflush(_coverage_fout);
  TIFFGetField(input, 256U, & t2p->tiff_width);
  fprintf(_coverage_fout, "1248\n");
  fflush(_coverage_fout);
  if (t2p->tiff_width == 0U) {
    fprintf(_coverage_fout, "929\n");
    fflush(_coverage_fout);
    tmp = TIFFFileName(input);
    fprintf(_coverage_fout, "930\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "No support for %s with zero width", tmp);
    fprintf(_coverage_fout, "931\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "932\n");
    fflush(_coverage_fout);
    return;
  } else {
    fprintf(_coverage_fout, "933\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1249\n");
  fflush(_coverage_fout);
  TIFFGetField(input, 257U, & t2p->tiff_length);
  fprintf(_coverage_fout, "1250\n");
  fflush(_coverage_fout);
  if (t2p->tiff_length == 0U) {
    fprintf(_coverage_fout, "934\n");
    fflush(_coverage_fout);
    tmp___0 = TIFFFileName(input);
    fprintf(_coverage_fout, "935\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "No support for %s with zero length", tmp___0);
    fprintf(_coverage_fout, "936\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "937\n");
    fflush(_coverage_fout);
    return;
  } else {
    fprintf(_coverage_fout, "938\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1251\n");
  fflush(_coverage_fout);
  tmp___2 = TIFFGetField(input, 259U, & t2p->tiff_compression);
  fprintf(_coverage_fout, "1252\n");
  fflush(_coverage_fout);
  if (tmp___2 == 0) {
    fprintf(_coverage_fout, "939\n");
    fflush(_coverage_fout);
    tmp___1 = TIFFFileName(input);
    fprintf(_coverage_fout, "940\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "No support for %s with no compression tag", tmp___1);
    fprintf(_coverage_fout, "941\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "942\n");
    fflush(_coverage_fout);
    return;
  } else {
    fprintf(_coverage_fout, "943\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1253\n");
  fflush(_coverage_fout);
  tmp___4 = TIFFIsCODECConfigured(t2p->tiff_compression);
  fprintf(_coverage_fout, "1254\n");
  fflush(_coverage_fout);
  if (tmp___4 == 0) {
    fprintf(_coverage_fout, "944\n");
    fflush(_coverage_fout);
    tmp___3 = TIFFFileName(input);
    fprintf(_coverage_fout, "945\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf",
              "No support for %s with compression type %u:  not configured",
              tmp___3, t2p->tiff_compression);
    fprintf(_coverage_fout, "946\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "947\n");
    fflush(_coverage_fout);
    return;
  } else {
    fprintf(_coverage_fout, "948\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1255\n");
  fflush(_coverage_fout);
  TIFFGetFieldDefaulted(input, 258U, & t2p->tiff_bitspersample);
  switch ((int )t2p->tiff_bitspersample) {
  case 1: 
  case 2: 
  case 4: 
  case 8: 
  break;
  fprintf(_coverage_fout, "949\n");
  fflush(_coverage_fout);
  case 0: 
  tmp___5 = TIFFFileName(input);
  fprintf(_coverage_fout, "950\n");
  fflush(_coverage_fout);
  TIFFWarning("tiff2pdf", "Image %s has 0 bits per sample, assuming 1", tmp___5);
  fprintf(_coverage_fout, "951\n");
  fflush(_coverage_fout);
  t2p->tiff_bitspersample = (unsigned short)1;
  break;
  fprintf(_coverage_fout, "952\n");
  fflush(_coverage_fout);
  default: 
  tmp___6 = TIFFFileName(input);
  fprintf(_coverage_fout, "953\n");
  fflush(_coverage_fout);
  TIFFError("tiff2pdf", "No support for %s with %u bits per sample", tmp___6,
            t2p->tiff_bitspersample);
  fprintf(_coverage_fout, "954\n");
  fflush(_coverage_fout);
  t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
  fprintf(_coverage_fout, "955\n");
  fflush(_coverage_fout);
  return;
  }
  fprintf(_coverage_fout, "1256\n");
  fflush(_coverage_fout);
  TIFFGetFieldDefaulted(input, 277U, & t2p->tiff_samplesperpixel);
  fprintf(_coverage_fout, "1257\n");
  fflush(_coverage_fout);
  if ((int )t2p->tiff_samplesperpixel > 4) {
    fprintf(_coverage_fout, "956\n");
    fflush(_coverage_fout);
    tmp___7 = TIFFFileName(input);
    fprintf(_coverage_fout, "957\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "No support for %s with %u samples per pixel",
              tmp___7, t2p->tiff_samplesperpixel);
    fprintf(_coverage_fout, "958\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "959\n");
    fflush(_coverage_fout);
    return;
  } else {
    fprintf(_coverage_fout, "960\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1258\n");
  fflush(_coverage_fout);
  if ((int )t2p->tiff_samplesperpixel == 0) {
    fprintf(_coverage_fout, "961\n");
    fflush(_coverage_fout);
    tmp___8 = TIFFFileName(input);
    fprintf(_coverage_fout, "962\n");
    fflush(_coverage_fout);
    TIFFWarning("tiff2pdf", "Image %s has 0 samples per pixel, assuming 1",
                tmp___8);
    fprintf(_coverage_fout, "963\n");
    fflush(_coverage_fout);
    t2p->tiff_samplesperpixel = (unsigned short)1;
  } else {
    fprintf(_coverage_fout, "964\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1259\n");
  fflush(_coverage_fout);
  tmp___10 = TIFFGetField(input, 339U, & xuint16);
  fprintf(_coverage_fout, "1260\n");
  fflush(_coverage_fout);
  if (tmp___10 != 0) {
    switch ((int )xuint16) {
    case 0: 
    case 1: 
    case 4: 
    break;
    fprintf(_coverage_fout, "965\n");
    fflush(_coverage_fout);
    default: 
    tmp___9 = TIFFFileName(input);
    fprintf(_coverage_fout, "966\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "No support for %s with sample format %u", tmp___9,
              xuint16);
    fprintf(_coverage_fout, "967\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "968\n");
    fflush(_coverage_fout);
    return;
    break;
    }
  } else {
    fprintf(_coverage_fout, "969\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1261\n");
  fflush(_coverage_fout);
  TIFFGetFieldDefaulted(input, 266U, & t2p->tiff_fillorder);
  fprintf(_coverage_fout, "1262\n");
  fflush(_coverage_fout);
  tmp___12 = TIFFGetField(input, 262U, & t2p->tiff_photometric);
  fprintf(_coverage_fout, "1263\n");
  fflush(_coverage_fout);
  if (tmp___12 == 0) {
    fprintf(_coverage_fout, "970\n");
    fflush(_coverage_fout);
    tmp___11 = TIFFFileName(input);
    fprintf(_coverage_fout, "971\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf",
              "No support for %s with no photometric interpretation tag",
              tmp___11);
    fprintf(_coverage_fout, "972\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "973\n");
    fflush(_coverage_fout);
    return;
  } else {
    fprintf(_coverage_fout, "974\n");
    fflush(_coverage_fout);

  }
  switch ((int )t2p->tiff_photometric) {
  fprintf(_coverage_fout, "1079\n");
  fflush(_coverage_fout);
  case 0: 
  case 1: 
  if ((int )t2p->tiff_bitspersample == 1) {
    fprintf(_coverage_fout, "977\n");
    fflush(_coverage_fout);
    t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )1;
    fprintf(_coverage_fout, "978\n");
    fflush(_coverage_fout);
    if ((int )t2p->tiff_photometric == 0) {
      fprintf(_coverage_fout, "975\n");
      fflush(_coverage_fout);
      t2p->pdf_switchdecode = (unsigned short )((int )t2p->pdf_switchdecode ^ 1);
    } else {
      fprintf(_coverage_fout, "976\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "981\n");
    fflush(_coverage_fout);
    t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )2;
    fprintf(_coverage_fout, "982\n");
    fflush(_coverage_fout);
    if ((int )t2p->tiff_photometric == 0) {
      fprintf(_coverage_fout, "979\n");
      fflush(_coverage_fout);
      t2p->pdf_switchdecode = (unsigned short )((int )t2p->pdf_switchdecode ^ 1);
    } else {
      fprintf(_coverage_fout, "980\n");
      fflush(_coverage_fout);

    }
  }
  break;
  fprintf(_coverage_fout, "1080\n");
  fflush(_coverage_fout);
  case 2: 
  t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )4;
  fprintf(_coverage_fout, "1081\n");
  fflush(_coverage_fout);
  if ((int )t2p->tiff_samplesperpixel == 3) {
    break;
  } else {
    fprintf(_coverage_fout, "983\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1082\n");
  fflush(_coverage_fout);
  tmp___13 = TIFFGetField(input, 346U, & xuint16);
  fprintf(_coverage_fout, "1083\n");
  fflush(_coverage_fout);
  if (tmp___13) {
    fprintf(_coverage_fout, "985\n");
    fflush(_coverage_fout);
    if ((int )xuint16 == 1) {
      goto photometric_palette;
    } else {
      fprintf(_coverage_fout, "984\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "986\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1084\n");
  fflush(_coverage_fout);
  if ((int )t2p->tiff_samplesperpixel > 3) {
    fprintf(_coverage_fout, "1008\n");
    fflush(_coverage_fout);
    if ((int )t2p->tiff_samplesperpixel == 4) {
      fprintf(_coverage_fout, "998\n");
      fflush(_coverage_fout);
      t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )4;
      fprintf(_coverage_fout, "999\n");
      fflush(_coverage_fout);
      tmp___15 = TIFFGetField(input, 338U, & xuint16, & xuint16p);
      fprintf(_coverage_fout, "1000\n");
      fflush(_coverage_fout);
      if (tmp___15) {
        fprintf(_coverage_fout, "996\n");
        fflush(_coverage_fout);
        if ((int )xuint16 == 1) {
          fprintf(_coverage_fout, "991\n");
          fflush(_coverage_fout);
          if ((int )*(xuint16p + 0) == 1) {
            fprintf(_coverage_fout, "987\n");
            fflush(_coverage_fout);
            t2p->pdf_sample = (enum __anonenum_t2p_sample_t_53 )4;
            break;
          } else {
            fprintf(_coverage_fout, "988\n");
            fflush(_coverage_fout);

          }
          fprintf(_coverage_fout, "992\n");
          fflush(_coverage_fout);
          if ((int )*(xuint16p + 0) == 2) {
            fprintf(_coverage_fout, "989\n");
            fflush(_coverage_fout);
            t2p->pdf_sample = (enum __anonenum_t2p_sample_t_53 )2;
            break;
          } else {
            fprintf(_coverage_fout, "990\n");
            fflush(_coverage_fout);

          }
          fprintf(_coverage_fout, "993\n");
          fflush(_coverage_fout);
          tmp___14 = TIFFFileName(input);
          fprintf(_coverage_fout, "994\n");
          fflush(_coverage_fout);
          TIFFWarning("tiff2pdf",
                      "RGB image %s has 4 samples per pixel, assuming RGBA",
                      tmp___14);
          break;
        } else {
          fprintf(_coverage_fout, "995\n");
          fflush(_coverage_fout);

        }
      } else {
        fprintf(_coverage_fout, "997\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1001\n");
      fflush(_coverage_fout);
      t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )8;
      fprintf(_coverage_fout, "1002\n");
      fflush(_coverage_fout);
      t2p->pdf_switchdecode = (unsigned short )((int )t2p->pdf_switchdecode ^ 1);
      fprintf(_coverage_fout, "1003\n");
      fflush(_coverage_fout);
      tmp___16 = TIFFFileName(input);
      fprintf(_coverage_fout, "1004\n");
      fflush(_coverage_fout);
      TIFFWarning("tiff2pdf",
                  "RGB image %s has 4 samples per pixel, assuming inverse CMYK",
                  tmp___16);
      break;
    } else {
      fprintf(_coverage_fout, "1005\n");
      fflush(_coverage_fout);
      tmp___17 = TIFFFileName(input);
      fprintf(_coverage_fout, "1006\n");
      fflush(_coverage_fout);
      TIFFError("tiff2pdf",
                "No support for RGB image %s with %u samples per pixel",
                tmp___17, t2p->tiff_samplesperpixel);
      fprintf(_coverage_fout, "1007\n");
      fflush(_coverage_fout);
      t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
      break;
    }
  } else {
    fprintf(_coverage_fout, "1009\n");
    fflush(_coverage_fout);
    tmp___18 = TIFFFileName(input);
    fprintf(_coverage_fout, "1010\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf",
              "No support for RGB image %s with %u samples per pixel", tmp___18,
              t2p->tiff_samplesperpixel);
    fprintf(_coverage_fout, "1011\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    break;
  }
  fprintf(_coverage_fout, "1085\n");
  fflush(_coverage_fout);
  case 3: 
  photometric_palette: 
  if ((int )t2p->tiff_samplesperpixel != 1) {
    fprintf(_coverage_fout, "1012\n");
    fflush(_coverage_fout);
    tmp___19 = TIFFFileName(input);
    fprintf(_coverage_fout, "1013\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf",
              "No support for palettized image %s with not one sample per pixel",
              tmp___19);
    fprintf(_coverage_fout, "1014\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "1015\n");
    fflush(_coverage_fout);
    return;
  } else {
    fprintf(_coverage_fout, "1016\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1086\n");
  fflush(_coverage_fout);
  t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )4100;
  fprintf(_coverage_fout, "1087\n");
  fflush(_coverage_fout);
  t2p->pdf_palettesize = (unsigned short )(0x0001 << (int )t2p->tiff_bitspersample);
  fprintf(_coverage_fout, "1088\n");
  fflush(_coverage_fout);
  tmp___21 = TIFFGetField(input, 320U, & r, & g, & b);
  fprintf(_coverage_fout, "1089\n");
  fflush(_coverage_fout);
  if (tmp___21) {
    fprintf(_coverage_fout, "1017\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1018\n");
    fflush(_coverage_fout);
    tmp___20 = TIFFFileName(input);
    fprintf(_coverage_fout, "1019\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "Palettized image %s has no color map", tmp___20);
    fprintf(_coverage_fout, "1020\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "1021\n");
    fflush(_coverage_fout);
    return;
  }
  fprintf(_coverage_fout, "1090\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_palette != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1022\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)t2p->pdf_palette);
    fprintf(_coverage_fout, "1023\n");
    fflush(_coverage_fout);
    t2p->pdf_palette = (unsigned char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "1024\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1091\n");
  fflush(_coverage_fout);
  tmp___22 = _TIFFmalloc((long )((int )t2p->pdf_palettesize * 3));
  fprintf(_coverage_fout, "1092\n");
  fflush(_coverage_fout);
  t2p->pdf_palette = (unsigned char *)tmp___22;
  fprintf(_coverage_fout, "1093\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_palette == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1025\n");
    fflush(_coverage_fout);
    tmp___23 = TIFFFileName(input);
    fprintf(_coverage_fout, "1026\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf",
              "Can\'t allocate %u bytes of memory for t2p_read_tiff_image, %s",
              t2p->pdf_palettesize, tmp___23);
    fprintf(_coverage_fout, "1027\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "1028\n");
    fflush(_coverage_fout);
    return;
  } else {
    fprintf(_coverage_fout, "1029\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1094\n");
  fflush(_coverage_fout);
  i = 0;
  fprintf(_coverage_fout, "1095\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1031\n");
    fflush(_coverage_fout);
    if (i < (int )t2p->pdf_palettesize) {
      fprintf(_coverage_fout, "1030\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1032\n");
    fflush(_coverage_fout);
    *(t2p->pdf_palette + i * 3) = (unsigned char )((int )*(r + i) >> 8);
    fprintf(_coverage_fout, "1033\n");
    fflush(_coverage_fout);
    *(t2p->pdf_palette + (i * 3 + 1)) = (unsigned char )((int )*(g + i) >> 8);
    fprintf(_coverage_fout, "1034\n");
    fflush(_coverage_fout);
    *(t2p->pdf_palette + (i * 3 + 2)) = (unsigned char )((int )*(b + i) >> 8);
    fprintf(_coverage_fout, "1035\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "1096\n");
  fflush(_coverage_fout);
  t2p->pdf_palettesize = (unsigned short )((int )t2p->pdf_palettesize * 3);
  break;
  fprintf(_coverage_fout, "1097\n");
  fflush(_coverage_fout);
  case 5: 
  tmp___24 = TIFFGetField(input, 346U, & xuint16);
  fprintf(_coverage_fout, "1098\n");
  fflush(_coverage_fout);
  if (tmp___24) {
    fprintf(_coverage_fout, "1037\n");
    fflush(_coverage_fout);
    if ((int )xuint16 == 1) {
      goto photometric_palette_cmyk;
    } else {
      fprintf(_coverage_fout, "1036\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "1038\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1099\n");
  fflush(_coverage_fout);
  tmp___26 = TIFFGetField(input, 332U, & xuint16);
  fprintf(_coverage_fout, "1100\n");
  fflush(_coverage_fout);
  if (tmp___26) {
    fprintf(_coverage_fout, "1044\n");
    fflush(_coverage_fout);
    if ((int )xuint16 != 1) {
      fprintf(_coverage_fout, "1039\n");
      fflush(_coverage_fout);
      tmp___25 = TIFFFileName(input);
      fprintf(_coverage_fout, "1040\n");
      fflush(_coverage_fout);
      TIFFError("tiff2pdf", "No support for %s because its inkset is not CMYK",
                tmp___25);
      fprintf(_coverage_fout, "1041\n");
      fflush(_coverage_fout);
      t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
      fprintf(_coverage_fout, "1042\n");
      fflush(_coverage_fout);
      return;
    } else {
      fprintf(_coverage_fout, "1043\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "1045\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1101\n");
  fflush(_coverage_fout);
  if ((int )t2p->tiff_samplesperpixel == 4) {
    fprintf(_coverage_fout, "1046\n");
    fflush(_coverage_fout);
    t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )8;
  } else {
    fprintf(_coverage_fout, "1047\n");
    fflush(_coverage_fout);
    tmp___27 = TIFFFileName(input);
    fprintf(_coverage_fout, "1048\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf",
              "No support for %s because it has %u samples per pixel", tmp___27,
              t2p->tiff_samplesperpixel);
    fprintf(_coverage_fout, "1049\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "1050\n");
    fflush(_coverage_fout);
    return;
  }
  break;
  fprintf(_coverage_fout, "1102\n");
  fflush(_coverage_fout);
  photometric_palette_cmyk: 
  if ((int )t2p->tiff_samplesperpixel != 1) {
    fprintf(_coverage_fout, "1051\n");
    fflush(_coverage_fout);
    tmp___28 = TIFFFileName(input);
    fprintf(_coverage_fout, "1052\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf",
              "No support for palettized CMYK image %s with not one sample per pixel",
              tmp___28);
    fprintf(_coverage_fout, "1053\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "1054\n");
    fflush(_coverage_fout);
    return;
  } else {
    fprintf(_coverage_fout, "1055\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1103\n");
  fflush(_coverage_fout);
  t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )4104;
  fprintf(_coverage_fout, "1104\n");
  fflush(_coverage_fout);
  t2p->pdf_palettesize = (unsigned short )(0x0001 << (int )t2p->tiff_bitspersample);
  fprintf(_coverage_fout, "1105\n");
  fflush(_coverage_fout);
  tmp___30 = TIFFGetField(input, 320U, & r, & g, & b, & a);
  fprintf(_coverage_fout, "1106\n");
  fflush(_coverage_fout);
  if (tmp___30) {
    fprintf(_coverage_fout, "1056\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1057\n");
    fflush(_coverage_fout);
    tmp___29 = TIFFFileName(input);
    fprintf(_coverage_fout, "1058\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "Palettized image %s has no color map", tmp___29);
    fprintf(_coverage_fout, "1059\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "1060\n");
    fflush(_coverage_fout);
    return;
  }
  fprintf(_coverage_fout, "1107\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_palette != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1061\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)t2p->pdf_palette);
    fprintf(_coverage_fout, "1062\n");
    fflush(_coverage_fout);
    t2p->pdf_palette = (unsigned char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "1063\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1108\n");
  fflush(_coverage_fout);
  tmp___31 = _TIFFmalloc((long )((int )t2p->pdf_palettesize * 4));
  fprintf(_coverage_fout, "1109\n");
  fflush(_coverage_fout);
  t2p->pdf_palette = (unsigned char *)tmp___31;
  fprintf(_coverage_fout, "1110\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_palette == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1064\n");
    fflush(_coverage_fout);
    tmp___32 = TIFFFileName(input);
    fprintf(_coverage_fout, "1065\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf",
              "Can\'t allocate %u bytes of memory for t2p_read_tiff_image, %s",
              t2p->pdf_palettesize, tmp___32);
    fprintf(_coverage_fout, "1066\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "1067\n");
    fflush(_coverage_fout);
    return;
  } else {
    fprintf(_coverage_fout, "1068\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1111\n");
  fflush(_coverage_fout);
  i = 0;
  fprintf(_coverage_fout, "1112\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1070\n");
    fflush(_coverage_fout);
    if (i < (int )t2p->pdf_palettesize) {
      fprintf(_coverage_fout, "1069\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1071\n");
    fflush(_coverage_fout);
    *(t2p->pdf_palette + i * 4) = (unsigned char )((int )*(r + i) >> 8);
    fprintf(_coverage_fout, "1072\n");
    fflush(_coverage_fout);
    *(t2p->pdf_palette + (i * 4 + 1)) = (unsigned char )((int )*(g + i) >> 8);
    fprintf(_coverage_fout, "1073\n");
    fflush(_coverage_fout);
    *(t2p->pdf_palette + (i * 4 + 2)) = (unsigned char )((int )*(b + i) >> 8);
    fprintf(_coverage_fout, "1074\n");
    fflush(_coverage_fout);
    *(t2p->pdf_palette + (i * 4 + 3)) = (unsigned char )((int )*(a + i) >> 8);
    fprintf(_coverage_fout, "1075\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "1113\n");
  fflush(_coverage_fout);
  t2p->pdf_palettesize = (unsigned short )((int )t2p->pdf_palettesize * 4);
  break;
  fprintf(_coverage_fout, "1114\n");
  fflush(_coverage_fout);
  case 6: 
  t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )4;
  fprintf(_coverage_fout, "1115\n");
  fflush(_coverage_fout);
  if ((int )t2p->tiff_samplesperpixel == 1) {
    fprintf(_coverage_fout, "1076\n");
    fflush(_coverage_fout);
    t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )2;
    fprintf(_coverage_fout, "1077\n");
    fflush(_coverage_fout);
    t2p->tiff_photometric = (unsigned short)1;
    break;
  } else {
    fprintf(_coverage_fout, "1078\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1116\n");
  fflush(_coverage_fout);
  t2p->pdf_sample = (enum __anonenum_t2p_sample_t_53 )8;
  break;
  fprintf(_coverage_fout, "1117\n");
  fflush(_coverage_fout);
  case 8: 
  t2p->pdf_labrange[0] = -127;
  fprintf(_coverage_fout, "1118\n");
  fflush(_coverage_fout);
  t2p->pdf_labrange[1] = 127;
  fprintf(_coverage_fout, "1119\n");
  fflush(_coverage_fout);
  t2p->pdf_labrange[2] = -127;
  fprintf(_coverage_fout, "1120\n");
  fflush(_coverage_fout);
  t2p->pdf_labrange[3] = 127;
  fprintf(_coverage_fout, "1121\n");
  fflush(_coverage_fout);
  t2p->pdf_sample = (enum __anonenum_t2p_sample_t_53 )64;
  fprintf(_coverage_fout, "1122\n");
  fflush(_coverage_fout);
  t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )16;
  break;
  fprintf(_coverage_fout, "1123\n");
  fflush(_coverage_fout);
  case 9: 
  t2p->pdf_labrange[0] = 0;
  fprintf(_coverage_fout, "1124\n");
  fflush(_coverage_fout);
  t2p->pdf_labrange[1] = 255;
  fprintf(_coverage_fout, "1125\n");
  fflush(_coverage_fout);
  t2p->pdf_labrange[2] = 0;
  fprintf(_coverage_fout, "1126\n");
  fflush(_coverage_fout);
  t2p->pdf_labrange[3] = 255;
  fprintf(_coverage_fout, "1127\n");
  fflush(_coverage_fout);
  t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )16;
  break;
  fprintf(_coverage_fout, "1128\n");
  fflush(_coverage_fout);
  case 10: 
  t2p->pdf_labrange[0] = -85;
  fprintf(_coverage_fout, "1129\n");
  fflush(_coverage_fout);
  t2p->pdf_labrange[1] = 85;
  fprintf(_coverage_fout, "1130\n");
  fflush(_coverage_fout);
  t2p->pdf_labrange[2] = -75;
  fprintf(_coverage_fout, "1131\n");
  fflush(_coverage_fout);
  t2p->pdf_labrange[3] = 124;
  fprintf(_coverage_fout, "1132\n");
  fflush(_coverage_fout);
  t2p->pdf_sample = (enum __anonenum_t2p_sample_t_53 )64;
  fprintf(_coverage_fout, "1133\n");
  fflush(_coverage_fout);
  t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )16;
  break;
  fprintf(_coverage_fout, "1134\n");
  fflush(_coverage_fout);
  case 32844: 
  case 32845: 
  tmp___33 = TIFFFileName(input);
  fprintf(_coverage_fout, "1135\n");
  fflush(_coverage_fout);
  TIFFError("tiff2pdf",
            "No support for %s with photometric interpretation LogL/LogLuv",
            tmp___33);
  fprintf(_coverage_fout, "1136\n");
  fflush(_coverage_fout);
  t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
  fprintf(_coverage_fout, "1137\n");
  fflush(_coverage_fout);
  return;
  fprintf(_coverage_fout, "1138\n");
  fflush(_coverage_fout);
  default: 
  tmp___34 = TIFFFileName(input);
  fprintf(_coverage_fout, "1139\n");
  fflush(_coverage_fout);
  TIFFError("tiff2pdf", "No support for %s with photometric interpretation %u",
            tmp___34, t2p->tiff_photometric);
  fprintf(_coverage_fout, "1140\n");
  fflush(_coverage_fout);
  t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
  fprintf(_coverage_fout, "1141\n");
  fflush(_coverage_fout);
  return;
  }
  fprintf(_coverage_fout, "1264\n");
  fflush(_coverage_fout);
  tmp___38 = TIFFGetField(input, 284U, & t2p->tiff_planar);
  fprintf(_coverage_fout, "1265\n");
  fflush(_coverage_fout);
  if (tmp___38) {
    switch ((int )t2p->tiff_planar) {
    fprintf(_coverage_fout, "1147\n");
    fflush(_coverage_fout);
    case 0: 
    tmp___35 = TIFFFileName(input);
    fprintf(_coverage_fout, "1148\n");
    fflush(_coverage_fout);
    TIFFWarning("tiff2pdf", "Image %s has planar configuration 0, assuming 1",
                tmp___35);
    fprintf(_coverage_fout, "1149\n");
    fflush(_coverage_fout);
    t2p->tiff_planar = (unsigned short)1;
    case 1: 
    break;
    fprintf(_coverage_fout, "1150\n");
    fflush(_coverage_fout);
    case 2: 
    t2p->pdf_sample = (enum __anonenum_t2p_sample_t_53 )256;
    fprintf(_coverage_fout, "1151\n");
    fflush(_coverage_fout);
    if ((int )t2p->tiff_bitspersample != 8) {
      fprintf(_coverage_fout, "1142\n");
      fflush(_coverage_fout);
      tmp___36 = TIFFFileName(input);
      fprintf(_coverage_fout, "1143\n");
      fflush(_coverage_fout);
      TIFFError("tiff2pdf",
                "No support for %s with separated planar configuration and %u bits per sample",
                tmp___36, t2p->tiff_bitspersample);
      fprintf(_coverage_fout, "1144\n");
      fflush(_coverage_fout);
      t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
      fprintf(_coverage_fout, "1145\n");
      fflush(_coverage_fout);
      return;
    } else {
      fprintf(_coverage_fout, "1146\n");
      fflush(_coverage_fout);

    }
    break;
    fprintf(_coverage_fout, "1152\n");
    fflush(_coverage_fout);
    default: 
    tmp___37 = TIFFFileName(input);
    fprintf(_coverage_fout, "1153\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "No support for %s with planar configuration %u",
              tmp___37, t2p->tiff_planar);
    fprintf(_coverage_fout, "1154\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "1155\n");
    fflush(_coverage_fout);
    return;
    }
  } else {
    fprintf(_coverage_fout, "1156\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1266\n");
  fflush(_coverage_fout);
  TIFFGetFieldDefaulted(input, 274U, & t2p->tiff_orientation);
  fprintf(_coverage_fout, "1267\n");
  fflush(_coverage_fout);
  if ((int )t2p->tiff_orientation > 8) {
    fprintf(_coverage_fout, "1157\n");
    fflush(_coverage_fout);
    tmp___39 = TIFFFileName(input);
    fprintf(_coverage_fout, "1158\n");
    fflush(_coverage_fout);
    TIFFWarning("tiff2pdf", "Image %s has orientation %u, assuming 0", tmp___39,
                t2p->tiff_orientation);
    fprintf(_coverage_fout, "1159\n");
    fflush(_coverage_fout);
    t2p->tiff_orientation = (unsigned short)0;
  } else {
    fprintf(_coverage_fout, "1160\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1268\n");
  fflush(_coverage_fout);
  tmp___40 = TIFFGetField(input, 282U, & t2p->tiff_xres);
  fprintf(_coverage_fout, "1269\n");
  fflush(_coverage_fout);
  if (tmp___40 == 0) {
    fprintf(_coverage_fout, "1161\n");
    fflush(_coverage_fout);
    t2p->tiff_xres = (float )0.0;
  } else {
    fprintf(_coverage_fout, "1162\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1270\n");
  fflush(_coverage_fout);
  tmp___41 = TIFFGetField(input, 283U, & t2p->tiff_yres);
  fprintf(_coverage_fout, "1271\n");
  fflush(_coverage_fout);
  if (tmp___41 == 0) {
    fprintf(_coverage_fout, "1163\n");
    fflush(_coverage_fout);
    t2p->tiff_yres = (float )0.0;
  } else {
    fprintf(_coverage_fout, "1164\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1272\n");
  fflush(_coverage_fout);
  TIFFGetFieldDefaulted(input, 296U, & t2p->tiff_resunit);
  fprintf(_coverage_fout, "1273\n");
  fflush(_coverage_fout);
  if ((int )t2p->tiff_resunit == 3) {
    fprintf(_coverage_fout, "1165\n");
    fflush(_coverage_fout);
    t2p->tiff_xres *= 2.54F;
    fprintf(_coverage_fout, "1166\n");
    fflush(_coverage_fout);
    t2p->tiff_yres *= 2.54F;
  } else {
    fprintf(_coverage_fout, "1172\n");
    fflush(_coverage_fout);
    if ((int )t2p->tiff_resunit != 2) {
      fprintf(_coverage_fout, "1170\n");
      fflush(_coverage_fout);
      if ((int )t2p->pdf_centimeters != 0) {
        fprintf(_coverage_fout, "1167\n");
        fflush(_coverage_fout);
        t2p->tiff_xres *= 2.54F;
        fprintf(_coverage_fout, "1168\n");
        fflush(_coverage_fout);
        t2p->tiff_yres *= 2.54F;
      } else {
        fprintf(_coverage_fout, "1169\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "1171\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "1274\n");
  fflush(_coverage_fout);
  t2p_compose_pdf_page(t2p);
  fprintf(_coverage_fout, "1275\n");
  fflush(_coverage_fout);
  t2p->pdf_transcode = (enum __anonenum_t2p_transcode_t_52 )2;
  fprintf(_coverage_fout, "1276\n");
  fflush(_coverage_fout);
  if ((int )t2p->pdf_nopassthrough == 0) {
    fprintf(_coverage_fout, "1194\n");
    fflush(_coverage_fout);
    if ((int )t2p->tiff_compression == 4) {
      fprintf(_coverage_fout, "1180\n");
      fflush(_coverage_fout);
      tmp___42 = TIFFIsTiled(input);
      fprintf(_coverage_fout, "1181\n");
      fflush(_coverage_fout);
      if (tmp___42) {
        fprintf(_coverage_fout, "1173\n");
        fflush(_coverage_fout);
        t2p->pdf_transcode = (enum __anonenum_t2p_transcode_t_52 )1;
        fprintf(_coverage_fout, "1174\n");
        fflush(_coverage_fout);
        t2p->pdf_compression = (enum __anonenum_t2p_compress_t_51 )1;
      } else {
        fprintf(_coverage_fout, "1178\n");
        fflush(_coverage_fout);
        tmp___43 = TIFFNumberOfStrips(input);
        fprintf(_coverage_fout, "1179\n");
        fflush(_coverage_fout);
        if (tmp___43 == 1U) {
          fprintf(_coverage_fout, "1175\n");
          fflush(_coverage_fout);
          t2p->pdf_transcode = (enum __anonenum_t2p_transcode_t_52 )1;
          fprintf(_coverage_fout, "1176\n");
          fflush(_coverage_fout);
          t2p->pdf_compression = (enum __anonenum_t2p_compress_t_51 )1;
        } else {
          fprintf(_coverage_fout, "1177\n");
          fflush(_coverage_fout);

        }
      }
    } else {
      fprintf(_coverage_fout, "1182\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1195\n");
    fflush(_coverage_fout);
    if ((int )t2p->tiff_compression == 8) {
      goto _L;
    } else {
      fprintf(_coverage_fout, "1193\n");
      fflush(_coverage_fout);
      if ((int )t2p->tiff_compression == 32946) {
        fprintf(_coverage_fout, "1190\n");
        fflush(_coverage_fout);
        _L: /* CIL Label */ 
        tmp___44 = TIFFIsTiled(input);
        fprintf(_coverage_fout, "1191\n");
        fflush(_coverage_fout);
        if (tmp___44) {
          fprintf(_coverage_fout, "1183\n");
          fflush(_coverage_fout);
          t2p->pdf_transcode = (enum __anonenum_t2p_transcode_t_52 )1;
          fprintf(_coverage_fout, "1184\n");
          fflush(_coverage_fout);
          t2p->pdf_compression = (enum __anonenum_t2p_compress_t_51 )4;
        } else {
          fprintf(_coverage_fout, "1188\n");
          fflush(_coverage_fout);
          tmp___45 = TIFFNumberOfStrips(input);
          fprintf(_coverage_fout, "1189\n");
          fflush(_coverage_fout);
          if (tmp___45 == 1U) {
            fprintf(_coverage_fout, "1185\n");
            fflush(_coverage_fout);
            t2p->pdf_transcode = (enum __anonenum_t2p_transcode_t_52 )1;
            fprintf(_coverage_fout, "1186\n");
            fflush(_coverage_fout);
            t2p->pdf_compression = (enum __anonenum_t2p_compress_t_51 )4;
          } else {
            fprintf(_coverage_fout, "1187\n");
            fflush(_coverage_fout);

          }
        }
      } else {
        fprintf(_coverage_fout, "1192\n");
        fflush(_coverage_fout);

      }
    }
  } else {
    fprintf(_coverage_fout, "1196\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1277\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_transcode != 1U) {
    fprintf(_coverage_fout, "1197\n");
    fflush(_coverage_fout);
    t2p->pdf_compression = t2p->pdf_defaultcompression;
  } else {
    fprintf(_coverage_fout, "1198\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1278\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_sample & 32U) {
    fprintf(_coverage_fout, "1203\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_colorspace & 8U) {
      fprintf(_coverage_fout, "1199\n");
      fflush(_coverage_fout);
      t2p->tiff_samplesperpixel = (unsigned short)4;
      fprintf(_coverage_fout, "1200\n");
      fflush(_coverage_fout);
      t2p->tiff_photometric = (unsigned short)5;
    } else {
      fprintf(_coverage_fout, "1201\n");
      fflush(_coverage_fout);
      t2p->tiff_samplesperpixel = (unsigned short)3;
      fprintf(_coverage_fout, "1202\n");
      fflush(_coverage_fout);
      t2p->tiff_photometric = (unsigned short)2;
    }
  } else {
    fprintf(_coverage_fout, "1204\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1279\n");
  fflush(_coverage_fout);
  tmp___46 = TIFFGetField(input, 301U, & t2p->tiff_transferfunction[0],
                          & t2p->tiff_transferfunction[1],
                          & t2p->tiff_transferfunction[2]);
  fprintf(_coverage_fout, "1280\n");
  fflush(_coverage_fout);
  if (tmp___46) {
    fprintf(_coverage_fout, "1207\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->tiff_transferfunction[1] != (unsigned int )t2p->tiff_transferfunction[0]) {
      fprintf(_coverage_fout, "1205\n");
      fflush(_coverage_fout);
      t2p->tiff_transferfunctioncount = (unsigned short)3;
    } else {
      fprintf(_coverage_fout, "1206\n");
      fflush(_coverage_fout);
      t2p->tiff_transferfunctioncount = (unsigned short)1;
    }
  } else {
    fprintf(_coverage_fout, "1208\n");
    fflush(_coverage_fout);
    t2p->tiff_transferfunctioncount = (unsigned short)0;
  }
  fprintf(_coverage_fout, "1281\n");
  fflush(_coverage_fout);
  tmp___47 = TIFFGetField(input, 318U, & xfloatp);
  fprintf(_coverage_fout, "1282\n");
  fflush(_coverage_fout);
  if (tmp___47 != 0) {
    fprintf(_coverage_fout, "1213\n");
    fflush(_coverage_fout);
    t2p->tiff_whitechromaticities[0] = *(xfloatp + 0);
    fprintf(_coverage_fout, "1214\n");
    fflush(_coverage_fout);
    t2p->tiff_whitechromaticities[1] = *(xfloatp + 1);
    fprintf(_coverage_fout, "1215\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_colorspace & 2U) {
      fprintf(_coverage_fout, "1209\n");
      fflush(_coverage_fout);
      t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )((unsigned int )t2p->pdf_colorspace | 32U);
    } else {
      fprintf(_coverage_fout, "1210\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1216\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_colorspace & 4U) {
      fprintf(_coverage_fout, "1211\n");
      fflush(_coverage_fout);
      t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )((unsigned int )t2p->pdf_colorspace | 64U);
    } else {
      fprintf(_coverage_fout, "1212\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "1217\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1283\n");
  fflush(_coverage_fout);
  tmp___48 = TIFFGetField(input, 319U, & xfloatp);
  fprintf(_coverage_fout, "1284\n");
  fflush(_coverage_fout);
  if (tmp___48 != 0) {
    fprintf(_coverage_fout, "1220\n");
    fflush(_coverage_fout);
    t2p->tiff_primarychromaticities[0] = *(xfloatp + 0);
    fprintf(_coverage_fout, "1221\n");
    fflush(_coverage_fout);
    t2p->tiff_primarychromaticities[1] = *(xfloatp + 1);
    fprintf(_coverage_fout, "1222\n");
    fflush(_coverage_fout);
    t2p->tiff_primarychromaticities[2] = *(xfloatp + 2);
    fprintf(_coverage_fout, "1223\n");
    fflush(_coverage_fout);
    t2p->tiff_primarychromaticities[3] = *(xfloatp + 3);
    fprintf(_coverage_fout, "1224\n");
    fflush(_coverage_fout);
    t2p->tiff_primarychromaticities[4] = *(xfloatp + 4);
    fprintf(_coverage_fout, "1225\n");
    fflush(_coverage_fout);
    t2p->tiff_primarychromaticities[5] = *(xfloatp + 5);
    fprintf(_coverage_fout, "1226\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_colorspace & 4U) {
      fprintf(_coverage_fout, "1218\n");
      fflush(_coverage_fout);
      t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )((unsigned int )t2p->pdf_colorspace | 64U);
    } else {
      fprintf(_coverage_fout, "1219\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "1227\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1285\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_colorspace & 16U) {
    fprintf(_coverage_fout, "1232\n");
    fflush(_coverage_fout);
    tmp___49 = TIFFGetField(input, 318U, & xfloatp);
    fprintf(_coverage_fout, "1233\n");
    fflush(_coverage_fout);
    if (tmp___49 != 0) {
      fprintf(_coverage_fout, "1228\n");
      fflush(_coverage_fout);
      t2p->tiff_whitechromaticities[0] = *(xfloatp + 0);
      fprintf(_coverage_fout, "1229\n");
      fflush(_coverage_fout);
      t2p->tiff_whitechromaticities[1] = *(xfloatp + 1);
    } else {
      fprintf(_coverage_fout, "1230\n");
      fflush(_coverage_fout);
      t2p->tiff_whitechromaticities[0] = 0.3457F;
      fprintf(_coverage_fout, "1231\n");
      fflush(_coverage_fout);
      t2p->tiff_whitechromaticities[1] = 0.3585F;
    }
  } else {
    fprintf(_coverage_fout, "1234\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1286\n");
  fflush(_coverage_fout);
  tmp___50 = TIFFGetField(input, 34675U, & t2p->tiff_iccprofilelength,
                          & t2p->tiff_iccprofile);
  fprintf(_coverage_fout, "1287\n");
  fflush(_coverage_fout);
  if (tmp___50 != 0) {
    fprintf(_coverage_fout, "1235\n");
    fflush(_coverage_fout);
    t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )((unsigned int )t2p->pdf_colorspace | 128U);
  } else {
    fprintf(_coverage_fout, "1236\n");
    fflush(_coverage_fout);
    t2p->tiff_iccprofilelength = 0U;
    fprintf(_coverage_fout, "1237\n");
    fflush(_coverage_fout);
    t2p->tiff_iccprofile = (void *)0;
  }
  fprintf(_coverage_fout, "1288\n");
  fflush(_coverage_fout);
  if ((int )t2p->tiff_bitspersample == 1) {
    fprintf(_coverage_fout, "1240\n");
    fflush(_coverage_fout);
    if ((int )t2p->tiff_samplesperpixel == 1) {
      fprintf(_coverage_fout, "1238\n");
      fflush(_coverage_fout);
      t2p->pdf_compression = (enum __anonenum_t2p_compress_t_51 )1;
    } else {
      fprintf(_coverage_fout, "1239\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "1241\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1289\n");
  fflush(_coverage_fout);
  return;
}
}
void t2p_read_tiff_size(T2P *t2p , TIFF *input ) 
{ uint64 *sbc ;
  tmsize_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1303\n");
  fflush(_coverage_fout);
  sbc = (uint64 *)((void *)0);
  fprintf(_coverage_fout, "1304\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_transcode == 1U) {
    fprintf(_coverage_fout, "1298\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_compression == 1U) {
      fprintf(_coverage_fout, "1290\n");
      fflush(_coverage_fout);
      TIFFGetField(input, 279U, & sbc);
      fprintf(_coverage_fout, "1291\n");
      fflush(_coverage_fout);
      t2p->tiff_datasize = (long )*(sbc + 0);
      fprintf(_coverage_fout, "1292\n");
      fflush(_coverage_fout);
      return;
    } else {
      fprintf(_coverage_fout, "1293\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1299\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_compression == 4U) {
      fprintf(_coverage_fout, "1294\n");
      fflush(_coverage_fout);
      TIFFGetField(input, 279U, & sbc);
      fprintf(_coverage_fout, "1295\n");
      fflush(_coverage_fout);
      t2p->tiff_datasize = (long )*(sbc + 0);
      fprintf(_coverage_fout, "1296\n");
      fflush(_coverage_fout);
      return;
    } else {
      fprintf(_coverage_fout, "1297\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "1300\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1305\n");
  fflush(_coverage_fout);
  tmp = TIFFScanlineSize(input);
  fprintf(_coverage_fout, "1306\n");
  fflush(_coverage_fout);
  t2p->tiff_datasize = (long )((unsigned long )tmp * (unsigned long )t2p->tiff_length);
  fprintf(_coverage_fout, "1307\n");
  fflush(_coverage_fout);
  if ((int )t2p->tiff_planar == 2) {
    fprintf(_coverage_fout, "1301\n");
    fflush(_coverage_fout);
    t2p->tiff_datasize *= (tsize_t )t2p->tiff_samplesperpixel;
  } else {
    fprintf(_coverage_fout, "1302\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1308\n");
  fflush(_coverage_fout);
  return;
}
}
void t2p_read_tiff_size_tile(T2P *t2p , TIFF *input , ttile_t tile ) 
{ uint64 *tbc ;
  uint16 edge ;
  int tmp ;
  int tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1318\n");
  fflush(_coverage_fout);
  tbc = (uint64 *)((void *)0);
  fprintf(_coverage_fout, "1319\n");
  fflush(_coverage_fout);
  edge = (uint16 )0;
  fprintf(_coverage_fout, "1320\n");
  fflush(_coverage_fout);
  tmp = t2p_tile_is_right_edge(*(t2p->tiff_tiles + t2p->pdf_page), tile);
  fprintf(_coverage_fout, "1321\n");
  fflush(_coverage_fout);
  edge = (unsigned short )((int )edge | tmp);
  fprintf(_coverage_fout, "1322\n");
  fflush(_coverage_fout);
  tmp___0 = t2p_tile_is_bottom_edge(*(t2p->tiff_tiles + t2p->pdf_page), tile);
  fprintf(_coverage_fout, "1323\n");
  fflush(_coverage_fout);
  edge = (unsigned short )((int )edge | tmp___0);
  fprintf(_coverage_fout, "1324\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_transcode == 1U) {
    fprintf(_coverage_fout, "1314\n");
    fflush(_coverage_fout);
    if (edge) {
      fprintf(_coverage_fout, "1309\n");
      fflush(_coverage_fout);
      t2p->tiff_datasize = TIFFTileSize(input);
      fprintf(_coverage_fout, "1310\n");
      fflush(_coverage_fout);
      return;
    } else {
      fprintf(_coverage_fout, "1311\n");
      fflush(_coverage_fout);
      TIFFGetField(input, 325U, & tbc);
      fprintf(_coverage_fout, "1312\n");
      fflush(_coverage_fout);
      t2p->tiff_datasize = (long )*(tbc + tile);
      fprintf(_coverage_fout, "1313\n");
      fflush(_coverage_fout);
      return;
    }
  } else {
    fprintf(_coverage_fout, "1315\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1325\n");
  fflush(_coverage_fout);
  t2p->tiff_datasize = TIFFTileSize(input);
  fprintf(_coverage_fout, "1326\n");
  fflush(_coverage_fout);
  if ((int )t2p->tiff_planar == 2) {
    fprintf(_coverage_fout, "1316\n");
    fflush(_coverage_fout);
    t2p->tiff_datasize *= (tsize_t )t2p->tiff_samplesperpixel;
  } else {
    fprintf(_coverage_fout, "1317\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1327\n");
  fflush(_coverage_fout);
  return;
}
}
int t2p_tile_is_right_edge(T2P_TILES tiles , ttile_t tile ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1332\n");
  fflush(_coverage_fout);
  if ((tile + 1U) % tiles.tiles_tilecountx == 0U) {
    fprintf(_coverage_fout, "1330\n");
    fflush(_coverage_fout);
    if (tiles.tiles_edgetilewidth != 0U) {
      fprintf(_coverage_fout, "1328\n");
      fflush(_coverage_fout);
      return (1);
    } else {
      fprintf(_coverage_fout, "1329\n");
      fflush(_coverage_fout);
      return (0);
    }
  } else {
    fprintf(_coverage_fout, "1331\n");
    fflush(_coverage_fout);
    return (0);
  }
}
}
int t2p_tile_is_bottom_edge(T2P_TILES tiles , ttile_t tile ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1337\n");
  fflush(_coverage_fout);
  if (tile + 1U > tiles.tiles_tilecount - tiles.tiles_tilecountx) {
    fprintf(_coverage_fout, "1335\n");
    fflush(_coverage_fout);
    if (tiles.tiles_edgetilelength != 0U) {
      fprintf(_coverage_fout, "1333\n");
      fflush(_coverage_fout);
      return (1);
    } else {
      fprintf(_coverage_fout, "1334\n");
      fflush(_coverage_fout);
      return (0);
    }
  } else {
    fprintf(_coverage_fout, "1336\n");
    fflush(_coverage_fout);
    return (0);
  }
}
}
int t2p_tile_is_edge(T2P_TILES tiles , ttile_t tile ) 
{ int tmp ;
  int tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1338\n");
  fflush(_coverage_fout);
  tmp = t2p_tile_is_right_edge(tiles, tile);
  fprintf(_coverage_fout, "1339\n");
  fflush(_coverage_fout);
  tmp___0 = t2p_tile_is_bottom_edge(tiles, tile);
  fprintf(_coverage_fout, "1340\n");
  fflush(_coverage_fout);
  return (tmp | tmp___0);
}
}
int t2p_tile_is_corner_edge(T2P_TILES tiles , ttile_t tile ) 
{ int tmp ;
  int tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1341\n");
  fflush(_coverage_fout);
  tmp = t2p_tile_is_right_edge(tiles, tile);
  fprintf(_coverage_fout, "1342\n");
  fflush(_coverage_fout);
  tmp___0 = t2p_tile_is_bottom_edge(tiles, tile);
  fprintf(_coverage_fout, "1343\n");
  fflush(_coverage_fout);
  return (tmp & tmp___0);
}
}
tsize_t t2p_readwrite_pdf_image(T2P *t2p , TIFF *input , TIFF *output ) 
{ tsize_t written ;
  unsigned char *buffer ;
  unsigned char *samplebuffer ;
  tsize_t bufferoffset ;
  tsize_t samplebufferoffset ;
  tsize_t read___0 ;
  tstrip_t i ;
  tstrip_t j ;
  tstrip_t stripcount ;
  tsize_t stripsize ;
  tsize_t sepstripcount ;
  tsize_t sepstripsize ;
  void *tmp ;
  char const   *tmp___0 ;
  void *tmp___1 ;
  char const   *tmp___2 ;
  void *tmp___3 ;
  char const   *tmp___4 ;
  char const   *tmp___5 ;
  uint32 tmp___6 ;
  void *tmp___7 ;
  char const   *tmp___8 ;
  void *tmp___9 ;
  char const   *tmp___10 ;
  char const   *tmp___11 ;
  void *tmp___12 ;
  char const   *tmp___13 ;
  char const   *tmp___14 ;
  void *tmp___15 ;
  char const   *tmp___16 ;
  void *tmp___17 ;
  char const   *tmp___18 ;
  char const   *tmp___19 ;
  int tmp___20 ;
  char const   *tmp___21 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1536\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "1537\n");
  fflush(_coverage_fout);
  buffer = (unsigned char *)((void *)0);
  fprintf(_coverage_fout, "1538\n");
  fflush(_coverage_fout);
  samplebuffer = (unsigned char *)((void *)0);
  fprintf(_coverage_fout, "1539\n");
  fflush(_coverage_fout);
  bufferoffset = (tsize_t )0;
  fprintf(_coverage_fout, "1540\n");
  fflush(_coverage_fout);
  samplebufferoffset = (tsize_t )0;
  fprintf(_coverage_fout, "1541\n");
  fflush(_coverage_fout);
  read___0 = (tsize_t )0;
  fprintf(_coverage_fout, "1542\n");
  fflush(_coverage_fout);
  i = (tstrip_t )0;
  fprintf(_coverage_fout, "1543\n");
  fflush(_coverage_fout);
  j = (tstrip_t )0;
  fprintf(_coverage_fout, "1544\n");
  fflush(_coverage_fout);
  stripcount = (tstrip_t )0;
  fprintf(_coverage_fout, "1545\n");
  fflush(_coverage_fout);
  stripsize = (tsize_t )0;
  fprintf(_coverage_fout, "1546\n");
  fflush(_coverage_fout);
  sepstripcount = (tsize_t )0;
  fprintf(_coverage_fout, "1547\n");
  fflush(_coverage_fout);
  sepstripsize = (tsize_t )0;
  fprintf(_coverage_fout, "1548\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_transcode == 1U) {
    fprintf(_coverage_fout, "1377\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_compression == 1U) {
      fprintf(_coverage_fout, "1351\n");
      fflush(_coverage_fout);
      tmp = _TIFFmalloc(t2p->tiff_datasize);
      fprintf(_coverage_fout, "1352\n");
      fflush(_coverage_fout);
      buffer = (unsigned char *)tmp;
      fprintf(_coverage_fout, "1353\n");
      fflush(_coverage_fout);
      if ((unsigned int )buffer == (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "1344\n");
        fflush(_coverage_fout);
        tmp___0 = TIFFFileName(input);
        fprintf(_coverage_fout, "1345\n");
        fflush(_coverage_fout);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image, %s",
                  (unsigned long )t2p->tiff_datasize, tmp___0);
        fprintf(_coverage_fout, "1346\n");
        fflush(_coverage_fout);
        t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
        fprintf(_coverage_fout, "1347\n");
        fflush(_coverage_fout);
        return (0L);
      } else {
        fprintf(_coverage_fout, "1348\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1354\n");
      fflush(_coverage_fout);
      TIFFReadRawStrip(input, 0U, (void *)buffer, t2p->tiff_datasize);
      fprintf(_coverage_fout, "1355\n");
      fflush(_coverage_fout);
      if ((int )t2p->tiff_fillorder == 2) {
        fprintf(_coverage_fout, "1349\n");
        fflush(_coverage_fout);
        TIFFReverseBits(buffer, t2p->tiff_datasize);
      } else {
        fprintf(_coverage_fout, "1350\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1356\n");
      fflush(_coverage_fout);
      t2pWriteFile(output, (void *)buffer, t2p->tiff_datasize);
      fprintf(_coverage_fout, "1357\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)buffer);
      fprintf(_coverage_fout, "1358\n");
      fflush(_coverage_fout);
      return (t2p->tiff_datasize);
    } else {
      fprintf(_coverage_fout, "1359\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1378\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_compression == 4U) {
      fprintf(_coverage_fout, "1367\n");
      fflush(_coverage_fout);
      tmp___1 = _TIFFmalloc(t2p->tiff_datasize);
      fprintf(_coverage_fout, "1368\n");
      fflush(_coverage_fout);
      buffer = (unsigned char *)tmp___1;
      fprintf(_coverage_fout, "1369\n");
      fflush(_coverage_fout);
      if ((unsigned int )buffer == (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "1360\n");
        fflush(_coverage_fout);
        tmp___2 = TIFFFileName(input);
        fprintf(_coverage_fout, "1361\n");
        fflush(_coverage_fout);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image, %s",
                  (unsigned long )t2p->tiff_datasize, tmp___2);
        fprintf(_coverage_fout, "1362\n");
        fflush(_coverage_fout);
        t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
        fprintf(_coverage_fout, "1363\n");
        fflush(_coverage_fout);
        return (0L);
      } else {
        fprintf(_coverage_fout, "1364\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1370\n");
      fflush(_coverage_fout);
      memset((void *)buffer, 0, (unsigned int )t2p->tiff_datasize);
      fprintf(_coverage_fout, "1371\n");
      fflush(_coverage_fout);
      TIFFReadRawStrip(input, 0U, (void *)buffer, t2p->tiff_datasize);
      fprintf(_coverage_fout, "1372\n");
      fflush(_coverage_fout);
      if ((int )t2p->tiff_fillorder == 2) {
        fprintf(_coverage_fout, "1365\n");
        fflush(_coverage_fout);
        TIFFReverseBits(buffer, t2p->tiff_datasize);
      } else {
        fprintf(_coverage_fout, "1366\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1373\n");
      fflush(_coverage_fout);
      t2pWriteFile(output, (void *)buffer, t2p->tiff_datasize);
      fprintf(_coverage_fout, "1374\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)buffer);
      fprintf(_coverage_fout, "1375\n");
      fflush(_coverage_fout);
      return (t2p->tiff_datasize);
    } else {
      fprintf(_coverage_fout, "1376\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "1379\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1549\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_sample == 0U) {
    fprintf(_coverage_fout, "1397\n");
    fflush(_coverage_fout);
    tmp___3 = _TIFFmalloc(t2p->tiff_datasize);
    fprintf(_coverage_fout, "1398\n");
    fflush(_coverage_fout);
    buffer = (unsigned char *)tmp___3;
    fprintf(_coverage_fout, "1399\n");
    fflush(_coverage_fout);
    if ((unsigned int )buffer == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "1380\n");
      fflush(_coverage_fout);
      tmp___4 = TIFFFileName(input);
      fprintf(_coverage_fout, "1381\n");
      fflush(_coverage_fout);
      TIFFError("tiff2pdf",
                "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image, %s",
                (unsigned long )t2p->tiff_datasize, tmp___4);
      fprintf(_coverage_fout, "1382\n");
      fflush(_coverage_fout);
      t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
      fprintf(_coverage_fout, "1383\n");
      fflush(_coverage_fout);
      return (0L);
    } else {
      fprintf(_coverage_fout, "1384\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1400\n");
    fflush(_coverage_fout);
    memset((void *)buffer, 0, (unsigned int )t2p->tiff_datasize);
    fprintf(_coverage_fout, "1401\n");
    fflush(_coverage_fout);
    stripsize = TIFFStripSize(input);
    fprintf(_coverage_fout, "1402\n");
    fflush(_coverage_fout);
    stripcount = TIFFNumberOfStrips(input);
    fprintf(_coverage_fout, "1403\n");
    fflush(_coverage_fout);
    i = 0U;
    fprintf(_coverage_fout, "1404\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "1392\n");
      fflush(_coverage_fout);
      if (i < stripcount) {
        fprintf(_coverage_fout, "1385\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "1393\n");
      fflush(_coverage_fout);
      read___0 = TIFFReadEncodedStrip(input, i, (void *)(buffer + bufferoffset),
                                      stripsize);
      fprintf(_coverage_fout, "1394\n");
      fflush(_coverage_fout);
      if (read___0 == -1L) {
        fprintf(_coverage_fout, "1386\n");
        fflush(_coverage_fout);
        tmp___5 = TIFFFileName(input);
        fprintf(_coverage_fout, "1387\n");
        fflush(_coverage_fout);
        TIFFError("tiff2pdf", "Error on decoding strip %u of %s", i, tmp___5);
        fprintf(_coverage_fout, "1388\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)buffer);
        fprintf(_coverage_fout, "1389\n");
        fflush(_coverage_fout);
        t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
        fprintf(_coverage_fout, "1390\n");
        fflush(_coverage_fout);
        return (0L);
      } else {
        fprintf(_coverage_fout, "1391\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1395\n");
      fflush(_coverage_fout);
      bufferoffset += read___0;
      fprintf(_coverage_fout, "1396\n");
      fflush(_coverage_fout);
      i ++;
    }
  } else {
    fprintf(_coverage_fout, "1504\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_sample & 256U) {
      fprintf(_coverage_fout, "1435\n");
      fflush(_coverage_fout);
      sepstripsize = TIFFStripSize(input);
      fprintf(_coverage_fout, "1436\n");
      fflush(_coverage_fout);
      tmp___6 = TIFFNumberOfStrips(input);
      fprintf(_coverage_fout, "1437\n");
      fflush(_coverage_fout);
      sepstripcount = (long )tmp___6;
      fprintf(_coverage_fout, "1438\n");
      fflush(_coverage_fout);
      stripsize = sepstripsize * (tsize_t )t2p->tiff_samplesperpixel;
      fprintf(_coverage_fout, "1439\n");
      fflush(_coverage_fout);
      stripcount = (unsigned int )(sepstripcount / (tsize_t )t2p->tiff_samplesperpixel);
      fprintf(_coverage_fout, "1440\n");
      fflush(_coverage_fout);
      tmp___7 = _TIFFmalloc(t2p->tiff_datasize);
      fprintf(_coverage_fout, "1441\n");
      fflush(_coverage_fout);
      buffer = (unsigned char *)tmp___7;
      fprintf(_coverage_fout, "1442\n");
      fflush(_coverage_fout);
      if ((unsigned int )buffer == (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "1405\n");
        fflush(_coverage_fout);
        tmp___8 = TIFFFileName(input);
        fprintf(_coverage_fout, "1406\n");
        fflush(_coverage_fout);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image, %s",
                  (unsigned long )t2p->tiff_datasize, tmp___8);
        fprintf(_coverage_fout, "1407\n");
        fflush(_coverage_fout);
        t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
        fprintf(_coverage_fout, "1408\n");
        fflush(_coverage_fout);
        return (0L);
      } else {
        fprintf(_coverage_fout, "1409\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1443\n");
      fflush(_coverage_fout);
      memset((void *)buffer, 0, (unsigned int )t2p->tiff_datasize);
      fprintf(_coverage_fout, "1444\n");
      fflush(_coverage_fout);
      tmp___9 = _TIFFmalloc(stripsize);
      fprintf(_coverage_fout, "1445\n");
      fflush(_coverage_fout);
      samplebuffer = (unsigned char *)tmp___9;
      fprintf(_coverage_fout, "1446\n");
      fflush(_coverage_fout);
      if ((unsigned int )samplebuffer == (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "1410\n");
        fflush(_coverage_fout);
        tmp___10 = TIFFFileName(input);
        fprintf(_coverage_fout, "1411\n");
        fflush(_coverage_fout);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image, %s",
                  (unsigned long )t2p->tiff_datasize, tmp___10);
        fprintf(_coverage_fout, "1412\n");
        fflush(_coverage_fout);
        t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
        fprintf(_coverage_fout, "1413\n");
        fflush(_coverage_fout);
        return (0L);
      } else {
        fprintf(_coverage_fout, "1414\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1447\n");
      fflush(_coverage_fout);
      i = 0U;
      fprintf(_coverage_fout, "1448\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "1428\n");
        fflush(_coverage_fout);
        if (i < stripcount) {
          fprintf(_coverage_fout, "1415\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "1429\n");
        fflush(_coverage_fout);
        samplebufferoffset = 0L;
        fprintf(_coverage_fout, "1430\n");
        fflush(_coverage_fout);
        j = 0U;
        fprintf(_coverage_fout, "1431\n");
        fflush(_coverage_fout);
        while (1) {
          fprintf(_coverage_fout, "1423\n");
          fflush(_coverage_fout);
          if (j < (tstrip_t )t2p->tiff_samplesperpixel) {
            fprintf(_coverage_fout, "1416\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
          fprintf(_coverage_fout, "1424\n");
          fflush(_coverage_fout);
          read___0 = TIFFReadEncodedStrip(input, i + j * stripcount,
                                          (void *)(samplebuffer + samplebufferoffset),
                                          sepstripsize);
          fprintf(_coverage_fout, "1425\n");
          fflush(_coverage_fout);
          if (read___0 == -1L) {
            fprintf(_coverage_fout, "1417\n");
            fflush(_coverage_fout);
            tmp___11 = TIFFFileName(input);
            fprintf(_coverage_fout, "1418\n");
            fflush(_coverage_fout);
            TIFFError("tiff2pdf", "Error on decoding strip %u of %s",
                      i + j * stripcount, tmp___11);
            fprintf(_coverage_fout, "1419\n");
            fflush(_coverage_fout);
            _TIFFfree((void *)buffer);
            fprintf(_coverage_fout, "1420\n");
            fflush(_coverage_fout);
            t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
            fprintf(_coverage_fout, "1421\n");
            fflush(_coverage_fout);
            return (0L);
          } else {
            fprintf(_coverage_fout, "1422\n");
            fflush(_coverage_fout);

          }
          fprintf(_coverage_fout, "1426\n");
          fflush(_coverage_fout);
          samplebufferoffset += read___0;
          fprintf(_coverage_fout, "1427\n");
          fflush(_coverage_fout);
          j ++;
        }
        fprintf(_coverage_fout, "1432\n");
        fflush(_coverage_fout);
        t2p_sample_planar_separate_to_contig(t2p, buffer + bufferoffset,
                                             samplebuffer, samplebufferoffset);
        fprintf(_coverage_fout, "1433\n");
        fflush(_coverage_fout);
        bufferoffset += samplebufferoffset;
        fprintf(_coverage_fout, "1434\n");
        fflush(_coverage_fout);
        i ++;
      }
      fprintf(_coverage_fout, "1449\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)samplebuffer);
      goto dataready;
    } else {
      fprintf(_coverage_fout, "1450\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1505\n");
    fflush(_coverage_fout);
    tmp___12 = _TIFFmalloc(t2p->tiff_datasize);
    fprintf(_coverage_fout, "1506\n");
    fflush(_coverage_fout);
    buffer = (unsigned char *)tmp___12;
    fprintf(_coverage_fout, "1507\n");
    fflush(_coverage_fout);
    if ((unsigned int )buffer == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "1451\n");
      fflush(_coverage_fout);
      tmp___13 = TIFFFileName(input);
      fprintf(_coverage_fout, "1452\n");
      fflush(_coverage_fout);
      TIFFError("tiff2pdf",
                "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image, %s",
                (unsigned long )t2p->tiff_datasize, tmp___13);
      fprintf(_coverage_fout, "1453\n");
      fflush(_coverage_fout);
      t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
      fprintf(_coverage_fout, "1454\n");
      fflush(_coverage_fout);
      return (0L);
    } else {
      fprintf(_coverage_fout, "1455\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1508\n");
    fflush(_coverage_fout);
    memset((void *)buffer, 0, (unsigned int )t2p->tiff_datasize);
    fprintf(_coverage_fout, "1509\n");
    fflush(_coverage_fout);
    stripsize = TIFFStripSize(input);
    fprintf(_coverage_fout, "1510\n");
    fflush(_coverage_fout);
    stripcount = TIFFNumberOfStrips(input);
    fprintf(_coverage_fout, "1511\n");
    fflush(_coverage_fout);
    i = 0U;
    fprintf(_coverage_fout, "1512\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "1464\n");
      fflush(_coverage_fout);
      if (i < stripcount) {
        fprintf(_coverage_fout, "1456\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "1465\n");
      fflush(_coverage_fout);
      read___0 = TIFFReadEncodedStrip(input, i, (void *)(buffer + bufferoffset),
                                      stripsize);
      fprintf(_coverage_fout, "1466\n");
      fflush(_coverage_fout);
      if (read___0 == -1L) {
        fprintf(_coverage_fout, "1457\n");
        fflush(_coverage_fout);
        tmp___14 = TIFFFileName(input);
        fprintf(_coverage_fout, "1458\n");
        fflush(_coverage_fout);
        TIFFError("tiff2pdf", "Error on decoding strip %u of %s", i, tmp___14);
        fprintf(_coverage_fout, "1459\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)samplebuffer);
        fprintf(_coverage_fout, "1460\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)buffer);
        fprintf(_coverage_fout, "1461\n");
        fflush(_coverage_fout);
        t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
        fprintf(_coverage_fout, "1462\n");
        fflush(_coverage_fout);
        return (0L);
      } else {
        fprintf(_coverage_fout, "1463\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1467\n");
      fflush(_coverage_fout);
      bufferoffset += read___0;
      fprintf(_coverage_fout, "1468\n");
      fflush(_coverage_fout);
      i ++;
    }
    fprintf(_coverage_fout, "1513\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_sample & 32U) {
      fprintf(_coverage_fout, "1475\n");
      fflush(_coverage_fout);
      tmp___15 = _TIFFrealloc((void *)buffer,
                              t2p->tiff_datasize * (tsize_t )t2p->tiff_samplesperpixel);
      fprintf(_coverage_fout, "1476\n");
      fflush(_coverage_fout);
      samplebuffer = (unsigned char *)tmp___15;
      fprintf(_coverage_fout, "1477\n");
      fflush(_coverage_fout);
      if ((unsigned int )samplebuffer == (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "1469\n");
        fflush(_coverage_fout);
        tmp___16 = TIFFFileName(input);
        fprintf(_coverage_fout, "1470\n");
        fflush(_coverage_fout);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image, %s",
                  (unsigned long )t2p->tiff_datasize, tmp___16);
        fprintf(_coverage_fout, "1471\n");
        fflush(_coverage_fout);
        t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
        fprintf(_coverage_fout, "1472\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)buffer);
      } else {
        fprintf(_coverage_fout, "1473\n");
        fflush(_coverage_fout);
        buffer = samplebuffer;
        fprintf(_coverage_fout, "1474\n");
        fflush(_coverage_fout);
        t2p->tiff_datasize *= (tsize_t )t2p->tiff_samplesperpixel;
      }
      fprintf(_coverage_fout, "1478\n");
      fflush(_coverage_fout);
      t2p_sample_realize_palette(t2p, buffer);
    } else {
      fprintf(_coverage_fout, "1479\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1514\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_sample & 2U) {
      fprintf(_coverage_fout, "1480\n");
      fflush(_coverage_fout);
      t2p->tiff_datasize = t2p_sample_rgba_to_rgb((void *)buffer,
                                                  t2p->tiff_width * t2p->tiff_length);
    } else {
      fprintf(_coverage_fout, "1481\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1515\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_sample & 4U) {
      fprintf(_coverage_fout, "1482\n");
      fflush(_coverage_fout);
      t2p->tiff_datasize = t2p_sample_rgbaa_to_rgb((void *)buffer,
                                                   t2p->tiff_width * t2p->tiff_length);
    } else {
      fprintf(_coverage_fout, "1483\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1516\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_sample & 8U) {
      fprintf(_coverage_fout, "1495\n");
      fflush(_coverage_fout);
      tmp___17 = _TIFFrealloc((void *)buffer,
                              (long )((t2p->tiff_width * t2p->tiff_length) * 4U));
      fprintf(_coverage_fout, "1496\n");
      fflush(_coverage_fout);
      samplebuffer = (unsigned char *)tmp___17;
      fprintf(_coverage_fout, "1497\n");
      fflush(_coverage_fout);
      if ((unsigned int )samplebuffer == (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "1484\n");
        fflush(_coverage_fout);
        tmp___18 = TIFFFileName(input);
        fprintf(_coverage_fout, "1485\n");
        fflush(_coverage_fout);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image, %s",
                  (unsigned long )t2p->tiff_datasize, tmp___18);
        fprintf(_coverage_fout, "1486\n");
        fflush(_coverage_fout);
        t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
        fprintf(_coverage_fout, "1487\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)buffer);
        fprintf(_coverage_fout, "1488\n");
        fflush(_coverage_fout);
        return (0L);
      } else {
        fprintf(_coverage_fout, "1489\n");
        fflush(_coverage_fout);
        buffer = samplebuffer;
      }
      fprintf(_coverage_fout, "1498\n");
      fflush(_coverage_fout);
      tmp___20 = TIFFReadRGBAImageOriented(input, t2p->tiff_width,
                                           t2p->tiff_length, (uint32 *)buffer,
                                           1, 0);
      fprintf(_coverage_fout, "1499\n");
      fflush(_coverage_fout);
      if (tmp___20) {
        fprintf(_coverage_fout, "1490\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "1491\n");
        fflush(_coverage_fout);
        tmp___19 = TIFFFileName(input);
        fprintf(_coverage_fout, "1492\n");
        fflush(_coverage_fout);
        TIFFError("tiff2pdf",
                  "Can\'t use TIFFReadRGBAImageOriented to extract RGB image from %s",
                  tmp___19);
        fprintf(_coverage_fout, "1493\n");
        fflush(_coverage_fout);
        t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
        fprintf(_coverage_fout, "1494\n");
        fflush(_coverage_fout);
        return (0L);
      }
      fprintf(_coverage_fout, "1500\n");
      fflush(_coverage_fout);
      t2p->tiff_datasize = t2p_sample_abgr_to_rgb((void *)buffer,
                                                  t2p->tiff_width * t2p->tiff_length);
    } else {
      fprintf(_coverage_fout, "1501\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1517\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_sample & 64U) {
      fprintf(_coverage_fout, "1502\n");
      fflush(_coverage_fout);
      t2p->tiff_datasize = t2p_sample_lab_signed_to_unsigned((void *)buffer,
                                                             t2p->tiff_width * t2p->tiff_length);
    } else {
      fprintf(_coverage_fout, "1503\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "1550\n");
  fflush(_coverage_fout);
  dataready: 
  t2p_disable(output);
  fprintf(_coverage_fout, "1551\n");
  fflush(_coverage_fout);
  TIFFSetField(output, 262U, t2p->tiff_photometric);
  fprintf(_coverage_fout, "1552\n");
  fflush(_coverage_fout);
  TIFFSetField(output, 258U, t2p->tiff_bitspersample);
  fprintf(_coverage_fout, "1553\n");
  fflush(_coverage_fout);
  TIFFSetField(output, 277U, t2p->tiff_samplesperpixel);
  fprintf(_coverage_fout, "1554\n");
  fflush(_coverage_fout);
  TIFFSetField(output, 256U, t2p->tiff_width);
  fprintf(_coverage_fout, "1555\n");
  fflush(_coverage_fout);
  TIFFSetField(output, 257U, t2p->tiff_length);
  fprintf(_coverage_fout, "1556\n");
  fflush(_coverage_fout);
  TIFFSetField(output, 278U, t2p->tiff_length);
  fprintf(_coverage_fout, "1557\n");
  fflush(_coverage_fout);
  TIFFSetField(output, 284U, 1);
  fprintf(_coverage_fout, "1558\n");
  fflush(_coverage_fout);
  TIFFSetField(output, 266U, 1);
  switch ((int )t2p->pdf_compression) {
  fprintf(_coverage_fout, "1522\n");
  fflush(_coverage_fout);
  case 0: 
  TIFFSetField(output, 259U, 1);
  break;
  fprintf(_coverage_fout, "1523\n");
  fflush(_coverage_fout);
  case 1: 
  TIFFSetField(output, 259U, 4);
  break;
  fprintf(_coverage_fout, "1524\n");
  fflush(_coverage_fout);
  case 4: 
  TIFFSetField(output, 259U, 32946);
  fprintf(_coverage_fout, "1525\n");
  fflush(_coverage_fout);
  if ((int )t2p->pdf_defaultcompressionquality % 100 != 0) {
    fprintf(_coverage_fout, "1518\n");
    fflush(_coverage_fout);
    TIFFSetField(output, 317U, (int )t2p->pdf_defaultcompressionquality % 100);
  } else {
    fprintf(_coverage_fout, "1519\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1526\n");
  fflush(_coverage_fout);
  if ((int )t2p->pdf_defaultcompressionquality / 100 != 0) {
    fprintf(_coverage_fout, "1520\n");
    fflush(_coverage_fout);
    TIFFSetField(output, 65557U, (int )t2p->pdf_defaultcompressionquality / 100);
  } else {
    fprintf(_coverage_fout, "1521\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "1527\n");
  fflush(_coverage_fout);
  default: ;
  break;
  }
  fprintf(_coverage_fout, "1559\n");
  fflush(_coverage_fout);
  t2p_enable(output);
  fprintf(_coverage_fout, "1560\n");
  fflush(_coverage_fout);
  t2p->outputwritten = 0L;
  fprintf(_coverage_fout, "1561\n");
  fflush(_coverage_fout);
  bufferoffset = TIFFWriteEncodedStrip(output, 0U, (void *)buffer,
                                       t2p->tiff_datasize);
  fprintf(_coverage_fout, "1562\n");
  fflush(_coverage_fout);
  if ((unsigned int )buffer != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1528\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)buffer);
    fprintf(_coverage_fout, "1529\n");
    fflush(_coverage_fout);
    buffer = (unsigned char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "1530\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1563\n");
  fflush(_coverage_fout);
  if (bufferoffset == -1L) {
    fprintf(_coverage_fout, "1531\n");
    fflush(_coverage_fout);
    tmp___21 = TIFFFileName(output);
    fprintf(_coverage_fout, "1532\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "Error writing encoded strip to output PDF %s",
              tmp___21);
    fprintf(_coverage_fout, "1533\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "1534\n");
    fflush(_coverage_fout);
    return (0L);
  } else {
    fprintf(_coverage_fout, "1535\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1564\n");
  fflush(_coverage_fout);
  written = t2p->outputwritten;
  fprintf(_coverage_fout, "1565\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_readwrite_pdf_image_tile(T2P *t2p , TIFF *input , TIFF *output ,
                                     ttile_t tile ) 
{ uint16 edge ;
  tsize_t written ;
  unsigned char *buffer ;
  tsize_t bufferoffset ;
  unsigned char *samplebuffer ;
  tsize_t samplebufferoffset ;
  tsize_t read___0 ;
  uint16 i ;
  ttile_t tilecount ;
  tsize_t tilesize ;
  ttile_t septilecount ;
  tsize_t septilesize ;
  int tmp ;
  int tmp___0 ;
  void *tmp___1 ;
  char const   *tmp___2 ;
  void *tmp___3 ;
  char const   *tmp___4 ;
  void *tmp___5 ;
  char const   *tmp___6 ;
  char const   *tmp___7 ;
  void *tmp___8 ;
  char const   *tmp___9 ;
  void *tmp___10 ;
  char const   *tmp___11 ;
  char const   *tmp___12 ;
  void *tmp___13 ;
  char const   *tmp___14 ;
  char const   *tmp___15 ;
  char const   *tmp___16 ;
  tmsize_t tmp___17 ;
  int tmp___18 ;
  int tmp___19 ;
  int tmp___20 ;
  tmsize_t tmp___21 ;
  char const   *tmp___22 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1721\n");
  fflush(_coverage_fout);
  edge = (uint16 )0;
  fprintf(_coverage_fout, "1722\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "1723\n");
  fflush(_coverage_fout);
  buffer = (unsigned char *)((void *)0);
  fprintf(_coverage_fout, "1724\n");
  fflush(_coverage_fout);
  bufferoffset = (tsize_t )0;
  fprintf(_coverage_fout, "1725\n");
  fflush(_coverage_fout);
  samplebuffer = (unsigned char *)((void *)0);
  fprintf(_coverage_fout, "1726\n");
  fflush(_coverage_fout);
  samplebufferoffset = (tsize_t )0;
  fprintf(_coverage_fout, "1727\n");
  fflush(_coverage_fout);
  read___0 = (tsize_t )0;
  fprintf(_coverage_fout, "1728\n");
  fflush(_coverage_fout);
  i = (uint16 )0;
  fprintf(_coverage_fout, "1729\n");
  fflush(_coverage_fout);
  tilecount = (ttile_t )0;
  fprintf(_coverage_fout, "1730\n");
  fflush(_coverage_fout);
  tilesize = (tsize_t )0;
  fprintf(_coverage_fout, "1731\n");
  fflush(_coverage_fout);
  septilecount = (ttile_t )0;
  fprintf(_coverage_fout, "1732\n");
  fflush(_coverage_fout);
  septilesize = (tsize_t )0;
  fprintf(_coverage_fout, "1733\n");
  fflush(_coverage_fout);
  tmp = t2p_tile_is_right_edge(*(t2p->tiff_tiles + t2p->pdf_page), tile);
  fprintf(_coverage_fout, "1734\n");
  fflush(_coverage_fout);
  edge = (unsigned short )((int )edge | tmp);
  fprintf(_coverage_fout, "1735\n");
  fflush(_coverage_fout);
  tmp___0 = t2p_tile_is_bottom_edge(*(t2p->tiff_tiles + t2p->pdf_page), tile);
  fprintf(_coverage_fout, "1736\n");
  fflush(_coverage_fout);
  edge = (unsigned short )((int )edge | tmp___0);
  fprintf(_coverage_fout, "1737\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_transcode == 1U) {
    fprintf(_coverage_fout, "1601\n");
    fflush(_coverage_fout);
    if ((int )edge == 0) {
      fprintf(_coverage_fout, "1598\n");
      fflush(_coverage_fout);
      if ((unsigned int )t2p->pdf_compression == 1U) {
        fprintf(_coverage_fout, "1573\n");
        fflush(_coverage_fout);
        tmp___1 = _TIFFmalloc(t2p->tiff_datasize);
        fprintf(_coverage_fout, "1574\n");
        fflush(_coverage_fout);
        buffer = (unsigned char *)tmp___1;
        fprintf(_coverage_fout, "1575\n");
        fflush(_coverage_fout);
        if ((unsigned int )buffer == (unsigned int )((void *)0)) {
          fprintf(_coverage_fout, "1566\n");
          fflush(_coverage_fout);
          tmp___2 = TIFFFileName(input);
          fprintf(_coverage_fout, "1567\n");
          fflush(_coverage_fout);
          TIFFError("tiff2pdf",
                    "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image_tile, %s",
                    (unsigned long )t2p->tiff_datasize, tmp___2);
          fprintf(_coverage_fout, "1568\n");
          fflush(_coverage_fout);
          t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
          fprintf(_coverage_fout, "1569\n");
          fflush(_coverage_fout);
          return (0L);
        } else {
          fprintf(_coverage_fout, "1570\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "1576\n");
        fflush(_coverage_fout);
        TIFFReadRawTile(input, tile, (void *)buffer, t2p->tiff_datasize);
        fprintf(_coverage_fout, "1577\n");
        fflush(_coverage_fout);
        if ((int )t2p->tiff_fillorder == 2) {
          fprintf(_coverage_fout, "1571\n");
          fflush(_coverage_fout);
          TIFFReverseBits(buffer, t2p->tiff_datasize);
        } else {
          fprintf(_coverage_fout, "1572\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "1578\n");
        fflush(_coverage_fout);
        t2pWriteFile(output, (void *)buffer, t2p->tiff_datasize);
        fprintf(_coverage_fout, "1579\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)buffer);
        fprintf(_coverage_fout, "1580\n");
        fflush(_coverage_fout);
        return (t2p->tiff_datasize);
      } else {
        fprintf(_coverage_fout, "1581\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1599\n");
      fflush(_coverage_fout);
      if ((unsigned int )t2p->pdf_compression == 4U) {
        fprintf(_coverage_fout, "1589\n");
        fflush(_coverage_fout);
        tmp___3 = _TIFFmalloc(t2p->tiff_datasize);
        fprintf(_coverage_fout, "1590\n");
        fflush(_coverage_fout);
        buffer = (unsigned char *)tmp___3;
        fprintf(_coverage_fout, "1591\n");
        fflush(_coverage_fout);
        if ((unsigned int )buffer == (unsigned int )((void *)0)) {
          fprintf(_coverage_fout, "1582\n");
          fflush(_coverage_fout);
          tmp___4 = TIFFFileName(input);
          fprintf(_coverage_fout, "1583\n");
          fflush(_coverage_fout);
          TIFFError("tiff2pdf",
                    "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image_tile, %s",
                    (unsigned long )t2p->tiff_datasize, tmp___4);
          fprintf(_coverage_fout, "1584\n");
          fflush(_coverage_fout);
          t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
          fprintf(_coverage_fout, "1585\n");
          fflush(_coverage_fout);
          return (0L);
        } else {
          fprintf(_coverage_fout, "1586\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "1592\n");
        fflush(_coverage_fout);
        TIFFReadRawTile(input, tile, (void *)buffer, t2p->tiff_datasize);
        fprintf(_coverage_fout, "1593\n");
        fflush(_coverage_fout);
        if ((int )t2p->tiff_fillorder == 2) {
          fprintf(_coverage_fout, "1587\n");
          fflush(_coverage_fout);
          TIFFReverseBits(buffer, t2p->tiff_datasize);
        } else {
          fprintf(_coverage_fout, "1588\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "1594\n");
        fflush(_coverage_fout);
        t2pWriteFile(output, (void *)buffer, t2p->tiff_datasize);
        fprintf(_coverage_fout, "1595\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)buffer);
        fprintf(_coverage_fout, "1596\n");
        fflush(_coverage_fout);
        return (t2p->tiff_datasize);
      } else {
        fprintf(_coverage_fout, "1597\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "1600\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "1602\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1738\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_sample == 0U) {
    fprintf(_coverage_fout, "1614\n");
    fflush(_coverage_fout);
    tmp___5 = _TIFFmalloc(t2p->tiff_datasize);
    fprintf(_coverage_fout, "1615\n");
    fflush(_coverage_fout);
    buffer = (unsigned char *)tmp___5;
    fprintf(_coverage_fout, "1616\n");
    fflush(_coverage_fout);
    if ((unsigned int )buffer == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "1603\n");
      fflush(_coverage_fout);
      tmp___6 = TIFFFileName(input);
      fprintf(_coverage_fout, "1604\n");
      fflush(_coverage_fout);
      TIFFError("tiff2pdf",
                "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image_tile, %s",
                (unsigned long )t2p->tiff_datasize, tmp___6);
      fprintf(_coverage_fout, "1605\n");
      fflush(_coverage_fout);
      t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
      fprintf(_coverage_fout, "1606\n");
      fflush(_coverage_fout);
      return (0L);
    } else {
      fprintf(_coverage_fout, "1607\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1617\n");
    fflush(_coverage_fout);
    read___0 = TIFFReadEncodedTile(input, tile, (void *)(buffer + bufferoffset),
                                   t2p->tiff_datasize);
    fprintf(_coverage_fout, "1618\n");
    fflush(_coverage_fout);
    if (read___0 == -1L) {
      fprintf(_coverage_fout, "1608\n");
      fflush(_coverage_fout);
      tmp___7 = TIFFFileName(input);
      fprintf(_coverage_fout, "1609\n");
      fflush(_coverage_fout);
      TIFFError("tiff2pdf", "Error on decoding tile %u of %s", tile, tmp___7);
      fprintf(_coverage_fout, "1610\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)buffer);
      fprintf(_coverage_fout, "1611\n");
      fflush(_coverage_fout);
      t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
      fprintf(_coverage_fout, "1612\n");
      fflush(_coverage_fout);
      return (0L);
    } else {
      fprintf(_coverage_fout, "1613\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "1688\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_sample == 256U) {
      fprintf(_coverage_fout, "1642\n");
      fflush(_coverage_fout);
      septilesize = TIFFTileSize(input);
      fprintf(_coverage_fout, "1643\n");
      fflush(_coverage_fout);
      septilecount = TIFFNumberOfTiles(input);
      fprintf(_coverage_fout, "1644\n");
      fflush(_coverage_fout);
      tilesize = septilesize * (tsize_t )t2p->tiff_samplesperpixel;
      fprintf(_coverage_fout, "1645\n");
      fflush(_coverage_fout);
      tilecount = septilecount / (ttile_t )t2p->tiff_samplesperpixel;
      fprintf(_coverage_fout, "1646\n");
      fflush(_coverage_fout);
      tmp___8 = _TIFFmalloc(t2p->tiff_datasize);
      fprintf(_coverage_fout, "1647\n");
      fflush(_coverage_fout);
      buffer = (unsigned char *)tmp___8;
      fprintf(_coverage_fout, "1648\n");
      fflush(_coverage_fout);
      if ((unsigned int )buffer == (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "1619\n");
        fflush(_coverage_fout);
        tmp___9 = TIFFFileName(input);
        fprintf(_coverage_fout, "1620\n");
        fflush(_coverage_fout);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image_tile, %s",
                  (unsigned long )t2p->tiff_datasize, tmp___9);
        fprintf(_coverage_fout, "1621\n");
        fflush(_coverage_fout);
        t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
        fprintf(_coverage_fout, "1622\n");
        fflush(_coverage_fout);
        return (0L);
      } else {
        fprintf(_coverage_fout, "1623\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1649\n");
      fflush(_coverage_fout);
      tmp___10 = _TIFFmalloc(t2p->tiff_datasize);
      fprintf(_coverage_fout, "1650\n");
      fflush(_coverage_fout);
      samplebuffer = (unsigned char *)tmp___10;
      fprintf(_coverage_fout, "1651\n");
      fflush(_coverage_fout);
      if ((unsigned int )samplebuffer == (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "1624\n");
        fflush(_coverage_fout);
        tmp___11 = TIFFFileName(input);
        fprintf(_coverage_fout, "1625\n");
        fflush(_coverage_fout);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image_tile, %s",
                  (unsigned long )t2p->tiff_datasize, tmp___11);
        fprintf(_coverage_fout, "1626\n");
        fflush(_coverage_fout);
        t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
        fprintf(_coverage_fout, "1627\n");
        fflush(_coverage_fout);
        return (0L);
      } else {
        fprintf(_coverage_fout, "1628\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1652\n");
      fflush(_coverage_fout);
      samplebufferoffset = 0L;
      fprintf(_coverage_fout, "1653\n");
      fflush(_coverage_fout);
      i = (unsigned short)0;
      fprintf(_coverage_fout, "1654\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "1637\n");
        fflush(_coverage_fout);
        if ((int )i < (int )t2p->tiff_samplesperpixel) {
          fprintf(_coverage_fout, "1629\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "1638\n");
        fflush(_coverage_fout);
        read___0 = TIFFReadEncodedTile(input, tile + (ttile_t )i * tilecount,
                                       (void *)(samplebuffer + samplebufferoffset),
                                       septilesize);
        fprintf(_coverage_fout, "1639\n");
        fflush(_coverage_fout);
        if (read___0 == -1L) {
          fprintf(_coverage_fout, "1630\n");
          fflush(_coverage_fout);
          tmp___12 = TIFFFileName(input);
          fprintf(_coverage_fout, "1631\n");
          fflush(_coverage_fout);
          TIFFError("tiff2pdf", "Error on decoding tile %u of %s",
                    tile + (ttile_t )i * tilecount, tmp___12);
          fprintf(_coverage_fout, "1632\n");
          fflush(_coverage_fout);
          _TIFFfree((void *)samplebuffer);
          fprintf(_coverage_fout, "1633\n");
          fflush(_coverage_fout);
          _TIFFfree((void *)buffer);
          fprintf(_coverage_fout, "1634\n");
          fflush(_coverage_fout);
          t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
          fprintf(_coverage_fout, "1635\n");
          fflush(_coverage_fout);
          return (0L);
        } else {
          fprintf(_coverage_fout, "1636\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "1640\n");
        fflush(_coverage_fout);
        samplebufferoffset += read___0;
        fprintf(_coverage_fout, "1641\n");
        fflush(_coverage_fout);
        i = (uint16 )((int )i + 1);
      }
      fprintf(_coverage_fout, "1655\n");
      fflush(_coverage_fout);
      t2p_sample_planar_separate_to_contig(t2p, buffer + bufferoffset,
                                           samplebuffer, samplebufferoffset);
      fprintf(_coverage_fout, "1656\n");
      fflush(_coverage_fout);
      bufferoffset += samplebufferoffset;
      fprintf(_coverage_fout, "1657\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)samplebuffer);
    } else {
      fprintf(_coverage_fout, "1658\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1689\n");
    fflush(_coverage_fout);
    if ((unsigned int )buffer == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "1670\n");
      fflush(_coverage_fout);
      tmp___13 = _TIFFmalloc(t2p->tiff_datasize);
      fprintf(_coverage_fout, "1671\n");
      fflush(_coverage_fout);
      buffer = (unsigned char *)tmp___13;
      fprintf(_coverage_fout, "1672\n");
      fflush(_coverage_fout);
      if ((unsigned int )buffer == (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "1659\n");
        fflush(_coverage_fout);
        tmp___14 = TIFFFileName(input);
        fprintf(_coverage_fout, "1660\n");
        fflush(_coverage_fout);
        TIFFError("tiff2pdf",
                  "Can\'t allocate %lu bytes of memory for t2p_readwrite_pdf_image_tile, %s",
                  (unsigned long )t2p->tiff_datasize, tmp___14);
        fprintf(_coverage_fout, "1661\n");
        fflush(_coverage_fout);
        t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
        fprintf(_coverage_fout, "1662\n");
        fflush(_coverage_fout);
        return (0L);
      } else {
        fprintf(_coverage_fout, "1663\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1673\n");
      fflush(_coverage_fout);
      read___0 = TIFFReadEncodedTile(input, tile,
                                     (void *)(buffer + bufferoffset),
                                     t2p->tiff_datasize);
      fprintf(_coverage_fout, "1674\n");
      fflush(_coverage_fout);
      if (read___0 == -1L) {
        fprintf(_coverage_fout, "1664\n");
        fflush(_coverage_fout);
        tmp___15 = TIFFFileName(input);
        fprintf(_coverage_fout, "1665\n");
        fflush(_coverage_fout);
        TIFFError("tiff2pdf", "Error on decoding tile %u of %s", tile, tmp___15);
        fprintf(_coverage_fout, "1666\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)buffer);
        fprintf(_coverage_fout, "1667\n");
        fflush(_coverage_fout);
        t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
        fprintf(_coverage_fout, "1668\n");
        fflush(_coverage_fout);
        return (0L);
      } else {
        fprintf(_coverage_fout, "1669\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "1675\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1690\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_sample & 2U) {
      fprintf(_coverage_fout, "1676\n");
      fflush(_coverage_fout);
      t2p->tiff_datasize = t2p_sample_rgba_to_rgb((void *)buffer,
                                                  (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilewidth * (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilelength);
    } else {
      fprintf(_coverage_fout, "1677\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1691\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_sample & 4U) {
      fprintf(_coverage_fout, "1678\n");
      fflush(_coverage_fout);
      t2p->tiff_datasize = t2p_sample_rgbaa_to_rgb((void *)buffer,
                                                   (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilewidth * (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilelength);
    } else {
      fprintf(_coverage_fout, "1679\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1692\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_sample & 8U) {
      fprintf(_coverage_fout, "1680\n");
      fflush(_coverage_fout);
      tmp___16 = TIFFFileName(input);
      fprintf(_coverage_fout, "1681\n");
      fflush(_coverage_fout);
      TIFFError("tiff2pdf", "No support for YCbCr to RGB in tile for %s",
                tmp___16);
      fprintf(_coverage_fout, "1682\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)buffer);
      fprintf(_coverage_fout, "1683\n");
      fflush(_coverage_fout);
      t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
      fprintf(_coverage_fout, "1684\n");
      fflush(_coverage_fout);
      return (0L);
    } else {
      fprintf(_coverage_fout, "1685\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1693\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_sample & 64U) {
      fprintf(_coverage_fout, "1686\n");
      fflush(_coverage_fout);
      t2p->tiff_datasize = t2p_sample_lab_signed_to_unsigned((void *)buffer,
                                                             (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilewidth * (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilelength);
    } else {
      fprintf(_coverage_fout, "1687\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "1739\n");
  fflush(_coverage_fout);
  tmp___18 = t2p_tile_is_right_edge(*(t2p->tiff_tiles + t2p->pdf_page), tile);
  fprintf(_coverage_fout, "1740\n");
  fflush(_coverage_fout);
  if (tmp___18 != 0) {
    fprintf(_coverage_fout, "1694\n");
    fflush(_coverage_fout);
    tmp___17 = TIFFTileRowSize(input);
    fprintf(_coverage_fout, "1695\n");
    fflush(_coverage_fout);
    t2p_tile_collapse_left((void *)buffer, tmp___17,
                           (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilewidth,
                           (t2p->tiff_tiles + t2p->pdf_page)->tiles_edgetilewidth,
                           (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilelength);
  } else {
    fprintf(_coverage_fout, "1696\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1741\n");
  fflush(_coverage_fout);
  t2p_disable(output);
  fprintf(_coverage_fout, "1742\n");
  fflush(_coverage_fout);
  TIFFSetField(output, 262U, t2p->tiff_photometric);
  fprintf(_coverage_fout, "1743\n");
  fflush(_coverage_fout);
  TIFFSetField(output, 258U, t2p->tiff_bitspersample);
  fprintf(_coverage_fout, "1744\n");
  fflush(_coverage_fout);
  TIFFSetField(output, 277U, t2p->tiff_samplesperpixel);
  fprintf(_coverage_fout, "1745\n");
  fflush(_coverage_fout);
  tmp___19 = t2p_tile_is_right_edge(*(t2p->tiff_tiles + t2p->pdf_page), tile);
  fprintf(_coverage_fout, "1746\n");
  fflush(_coverage_fout);
  if (tmp___19 == 0) {
    fprintf(_coverage_fout, "1697\n");
    fflush(_coverage_fout);
    TIFFSetField(output, 256U,
                 (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilewidth);
  } else {
    fprintf(_coverage_fout, "1698\n");
    fflush(_coverage_fout);
    TIFFSetField(output, 256U,
                 (t2p->tiff_tiles + t2p->pdf_page)->tiles_edgetilewidth);
  }
  fprintf(_coverage_fout, "1747\n");
  fflush(_coverage_fout);
  tmp___20 = t2p_tile_is_bottom_edge(*(t2p->tiff_tiles + t2p->pdf_page), tile);
  fprintf(_coverage_fout, "1748\n");
  fflush(_coverage_fout);
  if (tmp___20 == 0) {
    fprintf(_coverage_fout, "1699\n");
    fflush(_coverage_fout);
    TIFFSetField(output, 257U,
                 (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilelength);
    fprintf(_coverage_fout, "1700\n");
    fflush(_coverage_fout);
    TIFFSetField(output, 278U,
                 (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilelength);
  } else {
    fprintf(_coverage_fout, "1701\n");
    fflush(_coverage_fout);
    TIFFSetField(output, 257U,
                 (t2p->tiff_tiles + t2p->pdf_page)->tiles_edgetilelength);
    fprintf(_coverage_fout, "1702\n");
    fflush(_coverage_fout);
    TIFFSetField(output, 278U,
                 (t2p->tiff_tiles + t2p->pdf_page)->tiles_edgetilelength);
  }
  fprintf(_coverage_fout, "1749\n");
  fflush(_coverage_fout);
  TIFFSetField(output, 284U, 1);
  fprintf(_coverage_fout, "1750\n");
  fflush(_coverage_fout);
  TIFFSetField(output, 266U, 1);
  switch ((int )t2p->pdf_compression) {
  fprintf(_coverage_fout, "1707\n");
  fflush(_coverage_fout);
  case 0: 
  TIFFSetField(output, 259U, 1);
  break;
  fprintf(_coverage_fout, "1708\n");
  fflush(_coverage_fout);
  case 1: 
  TIFFSetField(output, 259U, 4);
  break;
  fprintf(_coverage_fout, "1709\n");
  fflush(_coverage_fout);
  case 4: 
  TIFFSetField(output, 259U, 32946);
  fprintf(_coverage_fout, "1710\n");
  fflush(_coverage_fout);
  if ((int )t2p->pdf_defaultcompressionquality % 100 != 0) {
    fprintf(_coverage_fout, "1703\n");
    fflush(_coverage_fout);
    TIFFSetField(output, 317U, (int )t2p->pdf_defaultcompressionquality % 100);
  } else {
    fprintf(_coverage_fout, "1704\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1711\n");
  fflush(_coverage_fout);
  if ((int )t2p->pdf_defaultcompressionquality / 100 != 0) {
    fprintf(_coverage_fout, "1705\n");
    fflush(_coverage_fout);
    TIFFSetField(output, 65557U, (int )t2p->pdf_defaultcompressionquality / 100);
  } else {
    fprintf(_coverage_fout, "1706\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "1712\n");
  fflush(_coverage_fout);
  default: ;
  break;
  }
  fprintf(_coverage_fout, "1751\n");
  fflush(_coverage_fout);
  t2p_enable(output);
  fprintf(_coverage_fout, "1752\n");
  fflush(_coverage_fout);
  t2p->outputwritten = 0L;
  fprintf(_coverage_fout, "1753\n");
  fflush(_coverage_fout);
  tmp___21 = TIFFStripSize(output);
  fprintf(_coverage_fout, "1754\n");
  fflush(_coverage_fout);
  bufferoffset = TIFFWriteEncodedStrip(output, 0U, (void *)buffer, tmp___21);
  fprintf(_coverage_fout, "1755\n");
  fflush(_coverage_fout);
  if ((unsigned int )buffer != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1713\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)buffer);
    fprintf(_coverage_fout, "1714\n");
    fflush(_coverage_fout);
    buffer = (unsigned char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "1715\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1756\n");
  fflush(_coverage_fout);
  if (bufferoffset == -1L) {
    fprintf(_coverage_fout, "1716\n");
    fflush(_coverage_fout);
    tmp___22 = TIFFFileName(output);
    fprintf(_coverage_fout, "1717\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "Error writing encoded tile to output PDF %s",
              tmp___22);
    fprintf(_coverage_fout, "1718\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "1719\n");
    fflush(_coverage_fout);
    return (0L);
  } else {
    fprintf(_coverage_fout, "1720\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1757\n");
  fflush(_coverage_fout);
  written = t2p->outputwritten;
  fprintf(_coverage_fout, "1758\n");
  fflush(_coverage_fout);
  return (written);
}
}
void t2p_tile_collapse_left(tdata_t buffer , tsize_t scanwidth ,
                            uint32 tilewidth , uint32 edgetilewidth ,
                            uint32 tilelength ) 
{ uint32 i ;
  tsize_t edgescanwidth ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1763\n");
  fflush(_coverage_fout);
  i = (uint32 )0;
  fprintf(_coverage_fout, "1764\n");
  fflush(_coverage_fout);
  edgescanwidth = (tsize_t )0;
  fprintf(_coverage_fout, "1765\n");
  fflush(_coverage_fout);
  edgescanwidth = (long )(((unsigned long )scanwidth * (unsigned long )edgetilewidth + (unsigned long )(tilewidth - 1U)) / (unsigned long )tilewidth);
  fprintf(_coverage_fout, "1766\n");
  fflush(_coverage_fout);
  i = i;
  fprintf(_coverage_fout, "1767\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1760\n");
    fflush(_coverage_fout);
    if (i < tilelength) {
      fprintf(_coverage_fout, "1759\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1761\n");
    fflush(_coverage_fout);
    _TIFFmemcpy((void *)((char *)buffer + (unsigned long )edgescanwidth * (unsigned long )i),
                (void const   *)((char *)buffer + (unsigned long )scanwidth * (unsigned long )i),
                edgescanwidth);
    fprintf(_coverage_fout, "1762\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "1768\n");
  fflush(_coverage_fout);
  return;
}
}
void t2p_write_advance_directory(T2P *t2p , TIFF *output ) 
{ char const   *tmp ;
  int tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1774\n");
  fflush(_coverage_fout);
  t2p_disable(output);
  fprintf(_coverage_fout, "1775\n");
  fflush(_coverage_fout);
  tmp___0 = TIFFWriteDirectory(output);
  fprintf(_coverage_fout, "1776\n");
  fflush(_coverage_fout);
  if (tmp___0) {
    fprintf(_coverage_fout, "1769\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1770\n");
    fflush(_coverage_fout);
    tmp = TIFFFileName(output);
    fprintf(_coverage_fout, "1771\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "Error writing virtual directory to output PDF %s",
              tmp);
    fprintf(_coverage_fout, "1772\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "1773\n");
    fflush(_coverage_fout);
    return;
  }
  fprintf(_coverage_fout, "1777\n");
  fflush(_coverage_fout);
  t2p_enable(output);
  fprintf(_coverage_fout, "1778\n");
  fflush(_coverage_fout);
  return;
}
}
tsize_t t2p_sample_planar_separate_to_contig(T2P *t2p , unsigned char *buffer ,
                                             unsigned char *samplebuffer ,
                                             tsize_t samplebuffersize ) 
{ tsize_t stride ;
  tsize_t i ;
  tsize_t j ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1788\n");
  fflush(_coverage_fout);
  stride = (tsize_t )0;
  fprintf(_coverage_fout, "1789\n");
  fflush(_coverage_fout);
  i = (tsize_t )0;
  fprintf(_coverage_fout, "1790\n");
  fflush(_coverage_fout);
  j = (tsize_t )0;
  fprintf(_coverage_fout, "1791\n");
  fflush(_coverage_fout);
  stride = samplebuffersize / (tsize_t )t2p->tiff_samplesperpixel;
  fprintf(_coverage_fout, "1792\n");
  fflush(_coverage_fout);
  i = 0L;
  fprintf(_coverage_fout, "1793\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1784\n");
    fflush(_coverage_fout);
    if (i < stride) {
      fprintf(_coverage_fout, "1779\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1785\n");
    fflush(_coverage_fout);
    j = 0L;
    fprintf(_coverage_fout, "1786\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "1781\n");
      fflush(_coverage_fout);
      if (j < (tsize_t )t2p->tiff_samplesperpixel) {
        fprintf(_coverage_fout, "1780\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "1782\n");
      fflush(_coverage_fout);
      *(buffer + (i * (tsize_t )t2p->tiff_samplesperpixel + j)) = *(samplebuffer + (i + j * stride));
      fprintf(_coverage_fout, "1783\n");
      fflush(_coverage_fout);
      j ++;
    }
    fprintf(_coverage_fout, "1787\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "1794\n");
  fflush(_coverage_fout);
  return (samplebuffersize);
}
}
tsize_t t2p_sample_realize_palette(T2P *t2p , unsigned char *buffer ) 
{ uint32 sample_count ;
  uint16 component_count ;
  uint32 palette_offset ;
  uint32 sample_offset ;
  uint32 i ;
  uint32 j ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1806\n");
  fflush(_coverage_fout);
  sample_count = (uint32 )0;
  fprintf(_coverage_fout, "1807\n");
  fflush(_coverage_fout);
  component_count = (uint16 )0;
  fprintf(_coverage_fout, "1808\n");
  fflush(_coverage_fout);
  palette_offset = (uint32 )0;
  fprintf(_coverage_fout, "1809\n");
  fflush(_coverage_fout);
  sample_offset = (uint32 )0;
  fprintf(_coverage_fout, "1810\n");
  fflush(_coverage_fout);
  i = (uint32 )0;
  fprintf(_coverage_fout, "1811\n");
  fflush(_coverage_fout);
  j = (uint32 )0;
  fprintf(_coverage_fout, "1812\n");
  fflush(_coverage_fout);
  sample_count = t2p->tiff_width * t2p->tiff_length;
  fprintf(_coverage_fout, "1813\n");
  fflush(_coverage_fout);
  component_count = t2p->tiff_samplesperpixel;
  fprintf(_coverage_fout, "1814\n");
  fflush(_coverage_fout);
  i = sample_count;
  fprintf(_coverage_fout, "1815\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1800\n");
    fflush(_coverage_fout);
    if (i > 0U) {
      fprintf(_coverage_fout, "1795\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1801\n");
    fflush(_coverage_fout);
    palette_offset = (unsigned int )((int )*(buffer + (i - 1U)) * (int )component_count);
    fprintf(_coverage_fout, "1802\n");
    fflush(_coverage_fout);
    sample_offset = (i - 1U) * (uint32 )component_count;
    fprintf(_coverage_fout, "1803\n");
    fflush(_coverage_fout);
    j = 0U;
    fprintf(_coverage_fout, "1804\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "1797\n");
      fflush(_coverage_fout);
      if (j < (uint32 )component_count) {
        fprintf(_coverage_fout, "1796\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "1798\n");
      fflush(_coverage_fout);
      *(buffer + (sample_offset + j)) = *(t2p->pdf_palette + (palette_offset + j));
      fprintf(_coverage_fout, "1799\n");
      fflush(_coverage_fout);
      j ++;
    }
    fprintf(_coverage_fout, "1805\n");
    fflush(_coverage_fout);
    i --;
  }
  fprintf(_coverage_fout, "1816\n");
  fflush(_coverage_fout);
  return (0L);
}
}
tsize_t t2p_sample_abgr_to_rgb(tdata_t data , uint32 samplecount ) 
{ uint32 i ;
  uint32 sample ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1824\n");
  fflush(_coverage_fout);
  i = (uint32 )0;
  fprintf(_coverage_fout, "1825\n");
  fflush(_coverage_fout);
  sample = (uint32 )0;
  fprintf(_coverage_fout, "1826\n");
  fflush(_coverage_fout);
  i = 0U;
  fprintf(_coverage_fout, "1827\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1818\n");
    fflush(_coverage_fout);
    if (i < samplecount) {
      fprintf(_coverage_fout, "1817\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1819\n");
    fflush(_coverage_fout);
    sample = *((uint32 *)data + i);
    fprintf(_coverage_fout, "1820\n");
    fflush(_coverage_fout);
    *((char *)data + i * 3U) = (char )(sample & 255U);
    fprintf(_coverage_fout, "1821\n");
    fflush(_coverage_fout);
    *((char *)data + (i * 3U + 1U)) = (char )((sample >> 8) & 255U);
    fprintf(_coverage_fout, "1822\n");
    fflush(_coverage_fout);
    *((char *)data + (i * 3U + 2U)) = (char )((sample >> 16) & 255U);
    fprintf(_coverage_fout, "1823\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "1828\n");
  fflush(_coverage_fout);
  return ((long )(i * 3U));
}
}
tsize_t t2p_sample_rgbaa_to_rgb(tdata_t data , uint32 samplecount ) 
{ uint32 i ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1833\n");
  fflush(_coverage_fout);
  i = 0U;
  fprintf(_coverage_fout, "1834\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1830\n");
    fflush(_coverage_fout);
    if (i < samplecount) {
      fprintf(_coverage_fout, "1829\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1831\n");
    fflush(_coverage_fout);
    memcpy((void */* __restrict  */)((uint8 *)data + i * 3U),
           (void const   */* __restrict  */)((uint8 *)data + i * 4U), 3U);
    fprintf(_coverage_fout, "1832\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "1835\n");
  fflush(_coverage_fout);
  return ((long )(i * 3U));
}
}
tsize_t t2p_sample_rgba_to_rgb(tdata_t data , uint32 samplecount ) 
{ uint32 i ;
  uint32 sample ;
  uint8 alpha ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1844\n");
  fflush(_coverage_fout);
  i = (uint32 )0;
  fprintf(_coverage_fout, "1845\n");
  fflush(_coverage_fout);
  sample = (uint32 )0;
  fprintf(_coverage_fout, "1846\n");
  fflush(_coverage_fout);
  alpha = (uint8 )0;
  fprintf(_coverage_fout, "1847\n");
  fflush(_coverage_fout);
  i = 0U;
  fprintf(_coverage_fout, "1848\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1837\n");
    fflush(_coverage_fout);
    if (i < samplecount) {
      fprintf(_coverage_fout, "1836\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1838\n");
    fflush(_coverage_fout);
    sample = *((uint32 *)data + i);
    fprintf(_coverage_fout, "1839\n");
    fflush(_coverage_fout);
    alpha = (unsigned char )(255U - (sample & 255U));
    fprintf(_coverage_fout, "1840\n");
    fflush(_coverage_fout);
    *((uint8 *)data + i * 3U) = (unsigned char )((int )((unsigned char )((sample >> 24) & 255U)) + (int )alpha);
    fprintf(_coverage_fout, "1841\n");
    fflush(_coverage_fout);
    *((uint8 *)data + (i * 3U + 1U)) = (unsigned char )((int )((unsigned char )((sample >> 16) & 255U)) + (int )alpha);
    fprintf(_coverage_fout, "1842\n");
    fflush(_coverage_fout);
    *((uint8 *)data + (i * 3U + 2U)) = (unsigned char )((int )((unsigned char )((sample >> 8) & 255U)) + (int )alpha);
    fprintf(_coverage_fout, "1843\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "1849\n");
  fflush(_coverage_fout);
  return ((long )(i * 3U));
}
}
tsize_t t2p_sample_lab_signed_to_unsigned(tdata_t buffer , uint32 samplecount ) 
{ uint32 i ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1859\n");
  fflush(_coverage_fout);
  i = (uint32 )0;
  fprintf(_coverage_fout, "1860\n");
  fflush(_coverage_fout);
  i = 0U;
  fprintf(_coverage_fout, "1861\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1855\n");
    fflush(_coverage_fout);
    if (i < samplecount) {
      fprintf(_coverage_fout, "1850\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1856\n");
    fflush(_coverage_fout);
    if (((int )*((unsigned char *)buffer + (i * 3U + 1U)) & 0x80) != 0) {
      fprintf(_coverage_fout, "1851\n");
      fflush(_coverage_fout);
      *((unsigned char *)buffer + (i * 3U + 1U)) = (unsigned char )(0x80 + (int )*((char *)buffer + (i * 3U + 1U)));
    } else {
      fprintf(_coverage_fout, "1852\n");
      fflush(_coverage_fout);
      *((unsigned char *)buffer + (i * 3U + 1U)) = (unsigned char )((int )*((unsigned char *)buffer + (i * 3U + 1U)) | 0x80);
    }
    fprintf(_coverage_fout, "1857\n");
    fflush(_coverage_fout);
    if (((int )*((unsigned char *)buffer + (i * 3U + 2U)) & 0x80) != 0) {
      fprintf(_coverage_fout, "1853\n");
      fflush(_coverage_fout);
      *((unsigned char *)buffer + (i * 3U + 2U)) = (unsigned char )(0x80 + (int )*((char *)buffer + (i * 3U + 2U)));
    } else {
      fprintf(_coverage_fout, "1854\n");
      fflush(_coverage_fout);
      *((unsigned char *)buffer + (i * 3U + 2U)) = (unsigned char )((int )*((unsigned char *)buffer + (i * 3U + 2U)) | 0x80);
    }
    fprintf(_coverage_fout, "1858\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "1862\n");
  fflush(_coverage_fout);
  return ((long )(samplecount * 3U));
}
}
tsize_t t2p_write_pdf_header(T2P *t2p , TIFF *output ) 
{ tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1863\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "1864\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "1865\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%%PDF-%u.%u ",
                   (int )t2p->pdf_majorversion & 0xff,
                   (int )t2p->pdf_minorversion & 0xff);
  fprintf(_coverage_fout, "1866\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "1867\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "1868\n");
  fflush(_coverage_fout);
  tmp___0 = t2pWriteFile(output, (void *)"\n%\342\343\317\323\n", 7L);
  fprintf(_coverage_fout, "1869\n");
  fflush(_coverage_fout);
  written += tmp___0;
  fprintf(_coverage_fout, "1870\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_obj_start(uint32 number , TIFF *output ) 
{ tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1871\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "1872\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "1873\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )number);
  fprintf(_coverage_fout, "1874\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "1875\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "1876\n");
  fflush(_coverage_fout);
  tmp___0 = t2pWriteFile(output, (void *)" 0 obj\n", 7L);
  fprintf(_coverage_fout, "1877\n");
  fflush(_coverage_fout);
  written += tmp___0;
  fprintf(_coverage_fout, "1878\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_obj_end(TIFF *output ) 
{ tsize_t written ;
  tmsize_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1879\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "1880\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"endobj\n", 7L);
  fprintf(_coverage_fout, "1881\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "1882\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_name(unsigned char *name , TIFF *output ) 
{ tsize_t written ;
  uint32 i ;
  char buffer[64] ;
  uint16 nextchar ;
  size_t namelen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;
  tmsize_t tmp___11 ;
  tmsize_t tmp___12 ;
  tmsize_t tmp___13 ;
  tmsize_t tmp___14 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1951\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "1952\n");
  fflush(_coverage_fout);
  i = (uint32 )0;
  fprintf(_coverage_fout, "1953\n");
  fflush(_coverage_fout);
  nextchar = (uint16 )0;
  fprintf(_coverage_fout, "1954\n");
  fflush(_coverage_fout);
  namelen = (size_t )0;
  fprintf(_coverage_fout, "1955\n");
  fflush(_coverage_fout);
  namelen = strlen((char const   *)((char *)name));
  fprintf(_coverage_fout, "1956\n");
  fflush(_coverage_fout);
  if (namelen > 126U) {
    fprintf(_coverage_fout, "1883\n");
    fflush(_coverage_fout);
    namelen = 126U;
  } else {
    fprintf(_coverage_fout, "1884\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1957\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"/", 1L);
  fprintf(_coverage_fout, "1958\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "1959\n");
  fflush(_coverage_fout);
  i = 0U;
  fprintf(_coverage_fout, "1960\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1945\n");
    fflush(_coverage_fout);
    if (i < namelen) {
      fprintf(_coverage_fout, "1885\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1946\n");
    fflush(_coverage_fout);
    if ((int )*(name + i) < 0x21) {
      fprintf(_coverage_fout, "1886\n");
      fflush(_coverage_fout);
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", *(name + i));
      fprintf(_coverage_fout, "1887\n");
      fflush(_coverage_fout);
      buffer[sizeof(buffer) - 1U] = (char )'\000';
      fprintf(_coverage_fout, "1888\n");
      fflush(_coverage_fout);
      tmp___0 = t2pWriteFile(output, (void *)(buffer), 3L);
      fprintf(_coverage_fout, "1889\n");
      fflush(_coverage_fout);
      written += tmp___0;
      fprintf(_coverage_fout, "1890\n");
      fflush(_coverage_fout);
      nextchar = (unsigned short)1;
    } else {
      fprintf(_coverage_fout, "1891\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1947\n");
    fflush(_coverage_fout);
    if ((int )*(name + i) > 0x7E) {
      fprintf(_coverage_fout, "1892\n");
      fflush(_coverage_fout);
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", *(name + i));
      fprintf(_coverage_fout, "1893\n");
      fflush(_coverage_fout);
      buffer[sizeof(buffer) - 1U] = (char )'\000';
      fprintf(_coverage_fout, "1894\n");
      fflush(_coverage_fout);
      tmp___1 = t2pWriteFile(output, (void *)(buffer), 3L);
      fprintf(_coverage_fout, "1895\n");
      fflush(_coverage_fout);
      written += tmp___1;
      fprintf(_coverage_fout, "1896\n");
      fflush(_coverage_fout);
      nextchar = (unsigned short)1;
    } else {
      fprintf(_coverage_fout, "1897\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1948\n");
    fflush(_coverage_fout);
    if ((int )nextchar == 0) {
      switch ((int )*(name + i)) {
      fprintf(_coverage_fout, "1898\n");
      fflush(_coverage_fout);
      case 0x23: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", *(name + i));
      fprintf(_coverage_fout, "1899\n");
      fflush(_coverage_fout);
      buffer[sizeof(buffer) - 1U] = (char )'\000';
      fprintf(_coverage_fout, "1900\n");
      fflush(_coverage_fout);
      tmp___2 = t2pWriteFile(output, (void *)(buffer), 3L);
      fprintf(_coverage_fout, "1901\n");
      fflush(_coverage_fout);
      written += tmp___2;
      break;
      fprintf(_coverage_fout, "1902\n");
      fflush(_coverage_fout);
      case 0x25: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", *(name + i));
      fprintf(_coverage_fout, "1903\n");
      fflush(_coverage_fout);
      buffer[sizeof(buffer) - 1U] = (char )'\000';
      fprintf(_coverage_fout, "1904\n");
      fflush(_coverage_fout);
      tmp___3 = t2pWriteFile(output, (void *)(buffer), 3L);
      fprintf(_coverage_fout, "1905\n");
      fflush(_coverage_fout);
      written += tmp___3;
      break;
      fprintf(_coverage_fout, "1906\n");
      fflush(_coverage_fout);
      case 0x28: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", *(name + i));
      fprintf(_coverage_fout, "1907\n");
      fflush(_coverage_fout);
      buffer[sizeof(buffer) - 1U] = (char )'\000';
      fprintf(_coverage_fout, "1908\n");
      fflush(_coverage_fout);
      tmp___4 = t2pWriteFile(output, (void *)(buffer), 3L);
      fprintf(_coverage_fout, "1909\n");
      fflush(_coverage_fout);
      written += tmp___4;
      break;
      fprintf(_coverage_fout, "1910\n");
      fflush(_coverage_fout);
      case 0x29: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", *(name + i));
      fprintf(_coverage_fout, "1911\n");
      fflush(_coverage_fout);
      buffer[sizeof(buffer) - 1U] = (char )'\000';
      fprintf(_coverage_fout, "1912\n");
      fflush(_coverage_fout);
      tmp___5 = t2pWriteFile(output, (void *)(buffer), 3L);
      fprintf(_coverage_fout, "1913\n");
      fflush(_coverage_fout);
      written += tmp___5;
      break;
      fprintf(_coverage_fout, "1914\n");
      fflush(_coverage_fout);
      case 0x2F: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", *(name + i));
      fprintf(_coverage_fout, "1915\n");
      fflush(_coverage_fout);
      buffer[sizeof(buffer) - 1U] = (char )'\000';
      fprintf(_coverage_fout, "1916\n");
      fflush(_coverage_fout);
      tmp___6 = t2pWriteFile(output, (void *)(buffer), 3L);
      fprintf(_coverage_fout, "1917\n");
      fflush(_coverage_fout);
      written += tmp___6;
      break;
      fprintf(_coverage_fout, "1918\n");
      fflush(_coverage_fout);
      case 0x3C: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", *(name + i));
      fprintf(_coverage_fout, "1919\n");
      fflush(_coverage_fout);
      buffer[sizeof(buffer) - 1U] = (char )'\000';
      fprintf(_coverage_fout, "1920\n");
      fflush(_coverage_fout);
      tmp___7 = t2pWriteFile(output, (void *)(buffer), 3L);
      fprintf(_coverage_fout, "1921\n");
      fflush(_coverage_fout);
      written += tmp___7;
      break;
      fprintf(_coverage_fout, "1922\n");
      fflush(_coverage_fout);
      case 0x3E: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", *(name + i));
      fprintf(_coverage_fout, "1923\n");
      fflush(_coverage_fout);
      buffer[sizeof(buffer) - 1U] = (char )'\000';
      fprintf(_coverage_fout, "1924\n");
      fflush(_coverage_fout);
      tmp___8 = t2pWriteFile(output, (void *)(buffer), 3L);
      fprintf(_coverage_fout, "1925\n");
      fflush(_coverage_fout);
      written += tmp___8;
      break;
      fprintf(_coverage_fout, "1926\n");
      fflush(_coverage_fout);
      case 0x5B: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", *(name + i));
      fprintf(_coverage_fout, "1927\n");
      fflush(_coverage_fout);
      buffer[sizeof(buffer) - 1U] = (char )'\000';
      fprintf(_coverage_fout, "1928\n");
      fflush(_coverage_fout);
      tmp___9 = t2pWriteFile(output, (void *)(buffer), 3L);
      fprintf(_coverage_fout, "1929\n");
      fflush(_coverage_fout);
      written += tmp___9;
      break;
      fprintf(_coverage_fout, "1930\n");
      fflush(_coverage_fout);
      case 0x5D: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", *(name + i));
      fprintf(_coverage_fout, "1931\n");
      fflush(_coverage_fout);
      buffer[sizeof(buffer) - 1U] = (char )'\000';
      fprintf(_coverage_fout, "1932\n");
      fflush(_coverage_fout);
      tmp___10 = t2pWriteFile(output, (void *)(buffer), 3L);
      fprintf(_coverage_fout, "1933\n");
      fflush(_coverage_fout);
      written += tmp___10;
      break;
      fprintf(_coverage_fout, "1934\n");
      fflush(_coverage_fout);
      case 0x7B: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", *(name + i));
      fprintf(_coverage_fout, "1935\n");
      fflush(_coverage_fout);
      buffer[sizeof(buffer) - 1U] = (char )'\000';
      fprintf(_coverage_fout, "1936\n");
      fflush(_coverage_fout);
      tmp___11 = t2pWriteFile(output, (void *)(buffer), 3L);
      fprintf(_coverage_fout, "1937\n");
      fflush(_coverage_fout);
      written += tmp___11;
      break;
      fprintf(_coverage_fout, "1938\n");
      fflush(_coverage_fout);
      case 0x7D: 
      sprintf((char */* __restrict  */)(buffer),
              (char const   */* __restrict  */)"#%.2X", *(name + i));
      fprintf(_coverage_fout, "1939\n");
      fflush(_coverage_fout);
      buffer[sizeof(buffer) - 1U] = (char )'\000';
      fprintf(_coverage_fout, "1940\n");
      fflush(_coverage_fout);
      tmp___12 = t2pWriteFile(output, (void *)(buffer), 3L);
      fprintf(_coverage_fout, "1941\n");
      fflush(_coverage_fout);
      written += tmp___12;
      break;
      fprintf(_coverage_fout, "1942\n");
      fflush(_coverage_fout);
      default: 
      tmp___13 = t2pWriteFile(output, (void *)(name + i), 1L);
      fprintf(_coverage_fout, "1943\n");
      fflush(_coverage_fout);
      written += tmp___13;
      }
    } else {
      fprintf(_coverage_fout, "1944\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1949\n");
    fflush(_coverage_fout);
    nextchar = (unsigned short)0;
    fprintf(_coverage_fout, "1950\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "1961\n");
  fflush(_coverage_fout);
  tmp___14 = t2pWriteFile(output, (void *)" ", 1L);
  fprintf(_coverage_fout, "1962\n");
  fflush(_coverage_fout);
  written += tmp___14;
  fprintf(_coverage_fout, "1963\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_string(char *pdfstr , TIFF *output ) 
{ tsize_t written ;
  uint32 i ;
  char buffer[64] ;
  size_t len ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1997\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "1998\n");
  fflush(_coverage_fout);
  i = (uint32 )0;
  fprintf(_coverage_fout, "1999\n");
  fflush(_coverage_fout);
  len = (size_t )0;
  fprintf(_coverage_fout, "2000\n");
  fflush(_coverage_fout);
  len = strlen((char const   *)pdfstr);
  fprintf(_coverage_fout, "2001\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"(", 1L);
  fprintf(_coverage_fout, "2002\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2003\n");
  fflush(_coverage_fout);
  i = 0U;
  fprintf(_coverage_fout, "2004\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1994\n");
    fflush(_coverage_fout);
    if (i < len) {
      fprintf(_coverage_fout, "1964\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1995\n");
    fflush(_coverage_fout);
    if ((int )*(pdfstr + i) & 0x80) {
      fprintf(_coverage_fout, "1965\n");
      fflush(_coverage_fout);
      snprintf((char */* __restrict  */)(buffer), sizeof(buffer),
               (char const   */* __restrict  */)"\\%.3hho", *(pdfstr + i));
      fprintf(_coverage_fout, "1966\n");
      fflush(_coverage_fout);
      tmp___0 = t2pWriteFile(output, (void *)(buffer), 4L);
      fprintf(_coverage_fout, "1967\n");
      fflush(_coverage_fout);
      written += tmp___0;
    } else {
      fprintf(_coverage_fout, "1993\n");
      fflush(_coverage_fout);
      if ((int )*(pdfstr + i) == 127) {
        fprintf(_coverage_fout, "1968\n");
        fflush(_coverage_fout);
        snprintf((char */* __restrict  */)(buffer), sizeof(buffer),
                 (char const   */* __restrict  */)"\\%.3hho", *(pdfstr + i));
        fprintf(_coverage_fout, "1969\n");
        fflush(_coverage_fout);
        tmp___0 = t2pWriteFile(output, (void *)(buffer), 4L);
        fprintf(_coverage_fout, "1970\n");
        fflush(_coverage_fout);
        written += tmp___0;
      } else {
        fprintf(_coverage_fout, "1992\n");
        fflush(_coverage_fout);
        if ((int )*(pdfstr + i) < 32) {
          fprintf(_coverage_fout, "1971\n");
          fflush(_coverage_fout);
          snprintf((char */* __restrict  */)(buffer), sizeof(buffer),
                   (char const   */* __restrict  */)"\\%.3hho", *(pdfstr + i));
          fprintf(_coverage_fout, "1972\n");
          fflush(_coverage_fout);
          tmp___0 = t2pWriteFile(output, (void *)(buffer), 4L);
          fprintf(_coverage_fout, "1973\n");
          fflush(_coverage_fout);
          written += tmp___0;
        } else {
          switch ((int )*(pdfstr + i)) {
          fprintf(_coverage_fout, "1974\n");
          fflush(_coverage_fout);
          case 0x08: 
          tmp___1 = t2pWriteFile(output, (void *)"\\b", 2L);
          fprintf(_coverage_fout, "1975\n");
          fflush(_coverage_fout);
          written += tmp___1;
          break;
          fprintf(_coverage_fout, "1976\n");
          fflush(_coverage_fout);
          case 0x09: 
          tmp___2 = t2pWriteFile(output, (void *)"\\t", 2L);
          fprintf(_coverage_fout, "1977\n");
          fflush(_coverage_fout);
          written += tmp___2;
          break;
          fprintf(_coverage_fout, "1978\n");
          fflush(_coverage_fout);
          case 0x0A: 
          tmp___3 = t2pWriteFile(output, (void *)"\\n", 2L);
          fprintf(_coverage_fout, "1979\n");
          fflush(_coverage_fout);
          written += tmp___3;
          break;
          fprintf(_coverage_fout, "1980\n");
          fflush(_coverage_fout);
          case 0x0C: 
          tmp___4 = t2pWriteFile(output, (void *)"\\f", 2L);
          fprintf(_coverage_fout, "1981\n");
          fflush(_coverage_fout);
          written += tmp___4;
          break;
          fprintf(_coverage_fout, "1982\n");
          fflush(_coverage_fout);
          case 0x0D: 
          tmp___5 = t2pWriteFile(output, (void *)"\\r", 2L);
          fprintf(_coverage_fout, "1983\n");
          fflush(_coverage_fout);
          written += tmp___5;
          break;
          fprintf(_coverage_fout, "1984\n");
          fflush(_coverage_fout);
          case 0x28: 
          tmp___6 = t2pWriteFile(output, (void *)"\\(", 2L);
          fprintf(_coverage_fout, "1985\n");
          fflush(_coverage_fout);
          written += tmp___6;
          break;
          fprintf(_coverage_fout, "1986\n");
          fflush(_coverage_fout);
          case 0x29: 
          tmp___7 = t2pWriteFile(output, (void *)"\\)", 2L);
          fprintf(_coverage_fout, "1987\n");
          fflush(_coverage_fout);
          written += tmp___7;
          break;
          fprintf(_coverage_fout, "1988\n");
          fflush(_coverage_fout);
          case 0x5C: 
          tmp___8 = t2pWriteFile(output, (void *)"\\\\", 2L);
          fprintf(_coverage_fout, "1989\n");
          fflush(_coverage_fout);
          written += tmp___8;
          break;
          fprintf(_coverage_fout, "1990\n");
          fflush(_coverage_fout);
          default: 
          tmp___9 = t2pWriteFile(output, (void *)(pdfstr + i), 1L);
          fprintf(_coverage_fout, "1991\n");
          fflush(_coverage_fout);
          written += tmp___9;
          }
        }
      }
    }
    fprintf(_coverage_fout, "1996\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "2005\n");
  fflush(_coverage_fout);
  tmp___10 = t2pWriteFile(output, (void *)") ", 1L);
  fprintf(_coverage_fout, "2006\n");
  fflush(_coverage_fout);
  written += tmp___10;
  fprintf(_coverage_fout, "2007\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_stream(tdata_t buffer , tsize_t len , TIFF *output ) 
{ tsize_t written ;
  tmsize_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2008\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2009\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, buffer, len);
  fprintf(_coverage_fout, "2010\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2011\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_stream_start(TIFF *output ) 
{ tsize_t written ;
  tmsize_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2012\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2013\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"stream\n", 7L);
  fprintf(_coverage_fout, "2014\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2015\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_stream_end(TIFF *output ) 
{ tsize_t written ;
  tmsize_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2016\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2017\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"\nendstream\n", 11L);
  fprintf(_coverage_fout, "2018\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2019\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_stream_dict(tsize_t len , uint32 number , TIFF *output ) 
{ tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2027\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2028\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "2029\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"/Length ", 8L);
  fprintf(_coverage_fout, "2030\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2031\n");
  fflush(_coverage_fout);
  if (len != 0L) {
    fprintf(_coverage_fout, "2020\n");
    fflush(_coverage_fout);
    tmp___0 = t2p_write_pdf_stream_length(len, output);
    fprintf(_coverage_fout, "2021\n");
    fflush(_coverage_fout);
    written += tmp___0;
  } else {
    fprintf(_coverage_fout, "2022\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )number);
    fprintf(_coverage_fout, "2023\n");
    fflush(_coverage_fout);
    tmp___1 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2024\n");
    fflush(_coverage_fout);
    written += tmp___1;
    fprintf(_coverage_fout, "2025\n");
    fflush(_coverage_fout);
    tmp___2 = t2pWriteFile(output, (void *)" 0 R \n", 6L);
    fprintf(_coverage_fout, "2026\n");
    fflush(_coverage_fout);
    written += tmp___2;
  }
  fprintf(_coverage_fout, "2032\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_stream_dict_start(TIFF *output ) 
{ tsize_t written ;
  tmsize_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2033\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2034\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"<< \n", 4L);
  fprintf(_coverage_fout, "2035\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2036\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_stream_dict_end(TIFF *output ) 
{ tsize_t written ;
  tmsize_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2037\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2038\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)" >>\n", 4L);
  fprintf(_coverage_fout, "2039\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2040\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_stream_length(tsize_t len , TIFF *output ) 
{ tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2041\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2042\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "2043\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu", (unsigned long )len);
  fprintf(_coverage_fout, "2044\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "2045\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2046\n");
  fflush(_coverage_fout);
  tmp___0 = t2pWriteFile(output, (void *)"\n", 1L);
  fprintf(_coverage_fout, "2047\n");
  fflush(_coverage_fout);
  written += tmp___0;
  fprintf(_coverage_fout, "2048\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_catalog(T2P *t2p , TIFF *output ) 
{ tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  unsigned int tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2054\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2055\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "2056\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"<< \n/Type /Catalog \n/Pages ", 27L);
  fprintf(_coverage_fout, "2057\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2058\n");
  fflush(_coverage_fout);
  buflen = snprintf((char */* __restrict  */)(buffer), sizeof(buffer),
                    (char const   */* __restrict  */)"%lu",
                    (unsigned long )t2p->pdf_pages);
  fprintf(_coverage_fout, "2059\n");
  fflush(_coverage_fout);
  if ((unsigned int )buflen < sizeof(buffer) - 1U) {
    fprintf(_coverage_fout, "2049\n");
    fflush(_coverage_fout);
    tmp___0 = (unsigned int )buflen;
  } else {
    fprintf(_coverage_fout, "2050\n");
    fflush(_coverage_fout);
    tmp___0 = sizeof(buffer) - 1U;
  }
  fprintf(_coverage_fout, "2060\n");
  fflush(_coverage_fout);
  tmp___1 = t2pWriteFile(output, (void *)(buffer), (long )tmp___0);
  fprintf(_coverage_fout, "2061\n");
  fflush(_coverage_fout);
  written += tmp___1;
  fprintf(_coverage_fout, "2062\n");
  fflush(_coverage_fout);
  tmp___2 = t2pWriteFile(output, (void *)" 0 R \n", 6L);
  fprintf(_coverage_fout, "2063\n");
  fflush(_coverage_fout);
  written += tmp___2;
  fprintf(_coverage_fout, "2064\n");
  fflush(_coverage_fout);
  if (t2p->pdf_fitwindow) {
    fprintf(_coverage_fout, "2051\n");
    fflush(_coverage_fout);
    tmp___3 = t2pWriteFile(output,
                           (void *)"/ViewerPreferences <</FitWindow true>>\n",
                           39L);
    fprintf(_coverage_fout, "2052\n");
    fflush(_coverage_fout);
    written += tmp___3;
  } else {
    fprintf(_coverage_fout, "2053\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2065\n");
  fflush(_coverage_fout);
  tmp___4 = t2pWriteFile(output, (void *)">>\n", 3L);
  fprintf(_coverage_fout, "2066\n");
  fflush(_coverage_fout);
  written += tmp___4;
  fprintf(_coverage_fout, "2067\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_info(T2P *t2p , TIFF *input , TIFF *output ) 
{ tsize_t written ;
  char *info ;
  char buffer[512] ;
  tmsize_t tmp ;
  tsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tsize_t tmp___2 ;
  size_t tmp___3 ;
  tmsize_t tmp___4 ;
  tsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  tsize_t tmp___8 ;
  tmsize_t tmp___9 ;
  size_t tmp___10 ;
  tmsize_t tmp___11 ;
  tsize_t tmp___12 ;
  tmsize_t tmp___13 ;
  int tmp___14 ;
  tmsize_t tmp___15 ;
  tsize_t tmp___16 ;
  tmsize_t tmp___17 ;
  size_t tmp___18 ;
  tmsize_t tmp___19 ;
  tsize_t tmp___20 ;
  tmsize_t tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;
  tmsize_t tmp___24 ;
  tsize_t tmp___25 ;
  tmsize_t tmp___26 ;
  size_t tmp___27 ;
  tmsize_t tmp___28 ;
  tsize_t tmp___29 ;
  tmsize_t tmp___30 ;
  int tmp___31 ;
  tmsize_t tmp___32 ;
  tsize_t tmp___33 ;
  tmsize_t tmp___34 ;
  size_t tmp___35 ;
  tmsize_t tmp___36 ;
  tsize_t tmp___37 ;
  tmsize_t tmp___38 ;
  int tmp___39 ;
  tmsize_t tmp___40 ;
  tsize_t tmp___41 ;
  tmsize_t tmp___42 ;
  tmsize_t tmp___43 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2170\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2171\n");
  fflush(_coverage_fout);
  if ((int )t2p->pdf_datetime[0] == 0) {
    fprintf(_coverage_fout, "2068\n");
    fflush(_coverage_fout);
    t2p_pdf_tifftime(t2p, input);
  } else {
    fprintf(_coverage_fout, "2069\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2172\n");
  fflush(_coverage_fout);
  tmp___3 = strlen((char const   *)(t2p->pdf_datetime));
  fprintf(_coverage_fout, "2173\n");
  fflush(_coverage_fout);
  if (tmp___3 > 0U) {
    fprintf(_coverage_fout, "2070\n");
    fflush(_coverage_fout);
    tmp = t2pWriteFile(output, (void *)"<< \n/CreationDate ", 18L);
    fprintf(_coverage_fout, "2071\n");
    fflush(_coverage_fout);
    written += tmp;
    fprintf(_coverage_fout, "2072\n");
    fflush(_coverage_fout);
    tmp___0 = t2p_write_pdf_string(t2p->pdf_datetime, output);
    fprintf(_coverage_fout, "2073\n");
    fflush(_coverage_fout);
    written += tmp___0;
    fprintf(_coverage_fout, "2074\n");
    fflush(_coverage_fout);
    tmp___1 = t2pWriteFile(output, (void *)"\n/ModDate ", 10L);
    fprintf(_coverage_fout, "2075\n");
    fflush(_coverage_fout);
    written += tmp___1;
    fprintf(_coverage_fout, "2076\n");
    fflush(_coverage_fout);
    tmp___2 = t2p_write_pdf_string(t2p->pdf_datetime, output);
    fprintf(_coverage_fout, "2077\n");
    fflush(_coverage_fout);
    written += tmp___2;
  } else {
    fprintf(_coverage_fout, "2078\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2174\n");
  fflush(_coverage_fout);
  tmp___4 = t2pWriteFile(output, (void *)"\n/Producer ", 11L);
  fprintf(_coverage_fout, "2175\n");
  fflush(_coverage_fout);
  written += tmp___4;
  fprintf(_coverage_fout, "2176\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)(buffer), 0x00, (long )sizeof(buffer));
  fprintf(_coverage_fout, "2177\n");
  fflush(_coverage_fout);
  snprintf((char */* __restrict  */)(buffer), sizeof(buffer),
           (char const   */* __restrict  */)"libtiff / tiff2pdf - %d", 20100611);
  fprintf(_coverage_fout, "2178\n");
  fflush(_coverage_fout);
  tmp___5 = t2p_write_pdf_string(buffer, output);
  fprintf(_coverage_fout, "2179\n");
  fflush(_coverage_fout);
  written += tmp___5;
  fprintf(_coverage_fout, "2180\n");
  fflush(_coverage_fout);
  tmp___6 = t2pWriteFile(output, (void *)"\n", 1L);
  fprintf(_coverage_fout, "2181\n");
  fflush(_coverage_fout);
  written += tmp___6;
  fprintf(_coverage_fout, "2182\n");
  fflush(_coverage_fout);
  if ((int )t2p->pdf_creator[0] != 0) {
    fprintf(_coverage_fout, "2079\n");
    fflush(_coverage_fout);
    tmp___7 = t2pWriteFile(output, (void *)"/Creator ", 9L);
    fprintf(_coverage_fout, "2080\n");
    fflush(_coverage_fout);
    written += tmp___7;
    fprintf(_coverage_fout, "2081\n");
    fflush(_coverage_fout);
    tmp___8 = t2p_write_pdf_string(t2p->pdf_creator, output);
    fprintf(_coverage_fout, "2082\n");
    fflush(_coverage_fout);
    written += tmp___8;
    fprintf(_coverage_fout, "2083\n");
    fflush(_coverage_fout);
    tmp___9 = t2pWriteFile(output, (void *)"\n", 1L);
    fprintf(_coverage_fout, "2084\n");
    fflush(_coverage_fout);
    written += tmp___9;
  } else {
    fprintf(_coverage_fout, "2098\n");
    fflush(_coverage_fout);
    tmp___14 = TIFFGetField(input, 305U, & info);
    fprintf(_coverage_fout, "2099\n");
    fflush(_coverage_fout);
    if (tmp___14 != 0) {
      fprintf(_coverage_fout, "2096\n");
      fflush(_coverage_fout);
      if (info) {
        fprintf(_coverage_fout, "2087\n");
        fflush(_coverage_fout);
        tmp___10 = strlen((char const   *)info);
        fprintf(_coverage_fout, "2088\n");
        fflush(_coverage_fout);
        if (tmp___10 >= sizeof(t2p->pdf_creator)) {
          fprintf(_coverage_fout, "2085\n");
          fflush(_coverage_fout);
          *(info + (sizeof(t2p->pdf_creator) - 1U)) = (char )'\000';
        } else {
          fprintf(_coverage_fout, "2086\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "2089\n");
        fflush(_coverage_fout);
        tmp___11 = t2pWriteFile(output, (void *)"/Creator ", 9L);
        fprintf(_coverage_fout, "2090\n");
        fflush(_coverage_fout);
        written += tmp___11;
        fprintf(_coverage_fout, "2091\n");
        fflush(_coverage_fout);
        tmp___12 = t2p_write_pdf_string(info, output);
        fprintf(_coverage_fout, "2092\n");
        fflush(_coverage_fout);
        written += tmp___12;
        fprintf(_coverage_fout, "2093\n");
        fflush(_coverage_fout);
        tmp___13 = t2pWriteFile(output, (void *)"\n", 1L);
        fprintf(_coverage_fout, "2094\n");
        fflush(_coverage_fout);
        written += tmp___13;
      } else {
        fprintf(_coverage_fout, "2095\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "2097\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "2183\n");
  fflush(_coverage_fout);
  if ((int )t2p->pdf_author[0] != 0) {
    fprintf(_coverage_fout, "2100\n");
    fflush(_coverage_fout);
    tmp___15 = t2pWriteFile(output, (void *)"/Author ", 8L);
    fprintf(_coverage_fout, "2101\n");
    fflush(_coverage_fout);
    written += tmp___15;
    fprintf(_coverage_fout, "2102\n");
    fflush(_coverage_fout);
    tmp___16 = t2p_write_pdf_string(t2p->pdf_author, output);
    fprintf(_coverage_fout, "2103\n");
    fflush(_coverage_fout);
    written += tmp___16;
    fprintf(_coverage_fout, "2104\n");
    fflush(_coverage_fout);
    tmp___17 = t2pWriteFile(output, (void *)"\n", 1L);
    fprintf(_coverage_fout, "2105\n");
    fflush(_coverage_fout);
    written += tmp___17;
  } else {
    fprintf(_coverage_fout, "2121\n");
    fflush(_coverage_fout);
    tmp___22 = TIFFGetField(input, 315U, & info);
    fprintf(_coverage_fout, "2122\n");
    fflush(_coverage_fout);
    if (tmp___22 != 0) {
      goto _L;
    } else {
      fprintf(_coverage_fout, "2119\n");
      fflush(_coverage_fout);
      tmp___23 = TIFFGetField(input, 33432U, & info);
      fprintf(_coverage_fout, "2120\n");
      fflush(_coverage_fout);
      if (tmp___23 != 0) {
        fprintf(_coverage_fout, "2117\n");
        fflush(_coverage_fout);
        _L: /* CIL Label */ 
        if (info) {
          fprintf(_coverage_fout, "2108\n");
          fflush(_coverage_fout);
          tmp___18 = strlen((char const   *)info);
          fprintf(_coverage_fout, "2109\n");
          fflush(_coverage_fout);
          if (tmp___18 >= sizeof(t2p->pdf_author)) {
            fprintf(_coverage_fout, "2106\n");
            fflush(_coverage_fout);
            *(info + (sizeof(t2p->pdf_author) - 1U)) = (char )'\000';
          } else {
            fprintf(_coverage_fout, "2107\n");
            fflush(_coverage_fout);

          }
          fprintf(_coverage_fout, "2110\n");
          fflush(_coverage_fout);
          tmp___19 = t2pWriteFile(output, (void *)"/Author ", 8L);
          fprintf(_coverage_fout, "2111\n");
          fflush(_coverage_fout);
          written += tmp___19;
          fprintf(_coverage_fout, "2112\n");
          fflush(_coverage_fout);
          tmp___20 = t2p_write_pdf_string(info, output);
          fprintf(_coverage_fout, "2113\n");
          fflush(_coverage_fout);
          written += tmp___20;
          fprintf(_coverage_fout, "2114\n");
          fflush(_coverage_fout);
          tmp___21 = t2pWriteFile(output, (void *)"\n", 1L);
          fprintf(_coverage_fout, "2115\n");
          fflush(_coverage_fout);
          written += tmp___21;
        } else {
          fprintf(_coverage_fout, "2116\n");
          fflush(_coverage_fout);

        }
      } else {
        fprintf(_coverage_fout, "2118\n");
        fflush(_coverage_fout);

      }
    }
  }
  fprintf(_coverage_fout, "2184\n");
  fflush(_coverage_fout);
  if ((int )t2p->pdf_title[0] != 0) {
    fprintf(_coverage_fout, "2123\n");
    fflush(_coverage_fout);
    tmp___24 = t2pWriteFile(output, (void *)"/Title ", 7L);
    fprintf(_coverage_fout, "2124\n");
    fflush(_coverage_fout);
    written += tmp___24;
    fprintf(_coverage_fout, "2125\n");
    fflush(_coverage_fout);
    tmp___25 = t2p_write_pdf_string(t2p->pdf_title, output);
    fprintf(_coverage_fout, "2126\n");
    fflush(_coverage_fout);
    written += tmp___25;
    fprintf(_coverage_fout, "2127\n");
    fflush(_coverage_fout);
    tmp___26 = t2pWriteFile(output, (void *)"\n", 1L);
    fprintf(_coverage_fout, "2128\n");
    fflush(_coverage_fout);
    written += tmp___26;
  } else {
    fprintf(_coverage_fout, "2140\n");
    fflush(_coverage_fout);
    tmp___31 = TIFFGetField(input, 269U, & info);
    fprintf(_coverage_fout, "2141\n");
    fflush(_coverage_fout);
    if (tmp___31 != 0) {
      fprintf(_coverage_fout, "2131\n");
      fflush(_coverage_fout);
      tmp___27 = strlen((char const   *)info);
      fprintf(_coverage_fout, "2132\n");
      fflush(_coverage_fout);
      if (tmp___27 > 511U) {
        fprintf(_coverage_fout, "2129\n");
        fflush(_coverage_fout);
        *(info + 512) = (char )'\000';
      } else {
        fprintf(_coverage_fout, "2130\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "2133\n");
      fflush(_coverage_fout);
      tmp___28 = t2pWriteFile(output, (void *)"/Title ", 7L);
      fprintf(_coverage_fout, "2134\n");
      fflush(_coverage_fout);
      written += tmp___28;
      fprintf(_coverage_fout, "2135\n");
      fflush(_coverage_fout);
      tmp___29 = t2p_write_pdf_string(info, output);
      fprintf(_coverage_fout, "2136\n");
      fflush(_coverage_fout);
      written += tmp___29;
      fprintf(_coverage_fout, "2137\n");
      fflush(_coverage_fout);
      tmp___30 = t2pWriteFile(output, (void *)"\n", 1L);
      fprintf(_coverage_fout, "2138\n");
      fflush(_coverage_fout);
      written += tmp___30;
    } else {
      fprintf(_coverage_fout, "2139\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "2185\n");
  fflush(_coverage_fout);
  if ((int )t2p->pdf_subject[0] != 0) {
    fprintf(_coverage_fout, "2142\n");
    fflush(_coverage_fout);
    tmp___32 = t2pWriteFile(output, (void *)"/Subject ", 9L);
    fprintf(_coverage_fout, "2143\n");
    fflush(_coverage_fout);
    written += tmp___32;
    fprintf(_coverage_fout, "2144\n");
    fflush(_coverage_fout);
    tmp___33 = t2p_write_pdf_string(t2p->pdf_subject, output);
    fprintf(_coverage_fout, "2145\n");
    fflush(_coverage_fout);
    written += tmp___33;
    fprintf(_coverage_fout, "2146\n");
    fflush(_coverage_fout);
    tmp___34 = t2pWriteFile(output, (void *)"\n", 1L);
    fprintf(_coverage_fout, "2147\n");
    fflush(_coverage_fout);
    written += tmp___34;
  } else {
    fprintf(_coverage_fout, "2161\n");
    fflush(_coverage_fout);
    tmp___39 = TIFFGetField(input, 270U, & info);
    fprintf(_coverage_fout, "2162\n");
    fflush(_coverage_fout);
    if (tmp___39 != 0) {
      fprintf(_coverage_fout, "2159\n");
      fflush(_coverage_fout);
      if (info) {
        fprintf(_coverage_fout, "2150\n");
        fflush(_coverage_fout);
        tmp___35 = strlen((char const   *)info);
        fprintf(_coverage_fout, "2151\n");
        fflush(_coverage_fout);
        if (tmp___35 >= sizeof(t2p->pdf_subject)) {
          fprintf(_coverage_fout, "2148\n");
          fflush(_coverage_fout);
          *(info + (sizeof(t2p->pdf_subject) - 1U)) = (char )'\000';
        } else {
          fprintf(_coverage_fout, "2149\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "2152\n");
        fflush(_coverage_fout);
        tmp___36 = t2pWriteFile(output, (void *)"/Subject ", 9L);
        fprintf(_coverage_fout, "2153\n");
        fflush(_coverage_fout);
        written += tmp___36;
        fprintf(_coverage_fout, "2154\n");
        fflush(_coverage_fout);
        tmp___37 = t2p_write_pdf_string(info, output);
        fprintf(_coverage_fout, "2155\n");
        fflush(_coverage_fout);
        written += tmp___37;
        fprintf(_coverage_fout, "2156\n");
        fflush(_coverage_fout);
        tmp___38 = t2pWriteFile(output, (void *)"\n", 1L);
        fprintf(_coverage_fout, "2157\n");
        fflush(_coverage_fout);
        written += tmp___38;
      } else {
        fprintf(_coverage_fout, "2158\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "2160\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "2186\n");
  fflush(_coverage_fout);
  if ((int )t2p->pdf_keywords[0] != 0) {
    fprintf(_coverage_fout, "2163\n");
    fflush(_coverage_fout);
    tmp___40 = t2pWriteFile(output, (void *)"/Keywords ", 10L);
    fprintf(_coverage_fout, "2164\n");
    fflush(_coverage_fout);
    written += tmp___40;
    fprintf(_coverage_fout, "2165\n");
    fflush(_coverage_fout);
    tmp___41 = t2p_write_pdf_string(t2p->pdf_keywords, output);
    fprintf(_coverage_fout, "2166\n");
    fflush(_coverage_fout);
    written += tmp___41;
    fprintf(_coverage_fout, "2167\n");
    fflush(_coverage_fout);
    tmp___42 = t2pWriteFile(output, (void *)"\n", 1L);
    fprintf(_coverage_fout, "2168\n");
    fflush(_coverage_fout);
    written += tmp___42;
  } else {
    fprintf(_coverage_fout, "2169\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2187\n");
  fflush(_coverage_fout);
  tmp___43 = t2pWriteFile(output, (void *)">> \n", 4L);
  fprintf(_coverage_fout, "2188\n");
  fflush(_coverage_fout);
  written += tmp___43;
  fprintf(_coverage_fout, "2189\n");
  fflush(_coverage_fout);
  return (written);
}
}
void t2p_pdf_currenttime(T2P *t2p ) 
{ struct tm *currenttime ;
  time_t timenow ;
  int *tmp ;
  char *tmp___0 ;
  time_t tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2195\n");
  fflush(_coverage_fout);
  tmp___1 = time(& timenow);
  fprintf(_coverage_fout, "2196\n");
  fflush(_coverage_fout);
  if (tmp___1 == -1L) {
    fprintf(_coverage_fout, "2190\n");
    fflush(_coverage_fout);
    tmp = __errno_location();
    fprintf(_coverage_fout, "2191\n");
    fflush(_coverage_fout);
    tmp___0 = strerror(*tmp);
    fprintf(_coverage_fout, "2192\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf", "Can\'t get the current time: %s", tmp___0);
    fprintf(_coverage_fout, "2193\n");
    fflush(_coverage_fout);
    timenow = 0L;
  } else {
    fprintf(_coverage_fout, "2194\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2197\n");
  fflush(_coverage_fout);
  currenttime = localtime((time_t const   *)(& timenow));
  fprintf(_coverage_fout, "2198\n");
  fflush(_coverage_fout);
  snprintf((char */* __restrict  */)(t2p->pdf_datetime),
           sizeof(t2p->pdf_datetime),
           (char const   */* __restrict  */)"D:%.4d%.2d%.2d%.2d%.2d%.2d",
           (currenttime->tm_year + 1900) % 65536,
           (currenttime->tm_mon + 1) % 256, currenttime->tm_mday % 256,
           currenttime->tm_hour % 256, currenttime->tm_min % 256,
           currenttime->tm_sec % 256);
  fprintf(_coverage_fout, "2199\n");
  fflush(_coverage_fout);
  return;
}
}
void t2p_pdf_tifftime(T2P *t2p , TIFF *input ) 
{ char *datetime ;
  int tmp ;
  size_t tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2221\n");
  fflush(_coverage_fout);
  tmp = TIFFGetField(input, 306U, & datetime);
  fprintf(_coverage_fout, "2222\n");
  fflush(_coverage_fout);
  if (tmp != 0) {
    fprintf(_coverage_fout, "2218\n");
    fflush(_coverage_fout);
    tmp___0 = strlen((char const   *)datetime);
    fprintf(_coverage_fout, "2219\n");
    fflush(_coverage_fout);
    if (tmp___0 >= 19U) {
      fprintf(_coverage_fout, "2200\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[0] = (char )'D';
      fprintf(_coverage_fout, "2201\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[1] = (char )':';
      fprintf(_coverage_fout, "2202\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[2] = *(datetime + 0);
      fprintf(_coverage_fout, "2203\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[3] = *(datetime + 1);
      fprintf(_coverage_fout, "2204\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[4] = *(datetime + 2);
      fprintf(_coverage_fout, "2205\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[5] = *(datetime + 3);
      fprintf(_coverage_fout, "2206\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[6] = *(datetime + 5);
      fprintf(_coverage_fout, "2207\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[7] = *(datetime + 6);
      fprintf(_coverage_fout, "2208\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[8] = *(datetime + 8);
      fprintf(_coverage_fout, "2209\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[9] = *(datetime + 9);
      fprintf(_coverage_fout, "2210\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[10] = *(datetime + 11);
      fprintf(_coverage_fout, "2211\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[11] = *(datetime + 12);
      fprintf(_coverage_fout, "2212\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[12] = *(datetime + 14);
      fprintf(_coverage_fout, "2213\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[13] = *(datetime + 15);
      fprintf(_coverage_fout, "2214\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[14] = *(datetime + 17);
      fprintf(_coverage_fout, "2215\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[15] = *(datetime + 18);
      fprintf(_coverage_fout, "2216\n");
      fflush(_coverage_fout);
      t2p->pdf_datetime[16] = (char )'\000';
    } else {
      fprintf(_coverage_fout, "2217\n");
      fflush(_coverage_fout);
      t2p_pdf_currenttime(t2p);
    }
  } else {
    fprintf(_coverage_fout, "2220\n");
    fflush(_coverage_fout);
    t2p_pdf_currenttime(t2p);
  }
  fprintf(_coverage_fout, "2223\n");
  fflush(_coverage_fout);
  return;
}
}
tsize_t t2p_write_pdf_pages(T2P *t2p , TIFF *output ) 
{ tsize_t written ;
  tdir_t i ;
  char buffer[16] ;
  int buflen ;
  int page ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2241\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2242\n");
  fflush(_coverage_fout);
  i = (tdir_t )0;
  fprintf(_coverage_fout, "2243\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "2244\n");
  fflush(_coverage_fout);
  page = 0;
  fprintf(_coverage_fout, "2245\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"<< \n/Type /Pages \n/Kids [ ", 26L);
  fprintf(_coverage_fout, "2246\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2247\n");
  fflush(_coverage_fout);
  page = (int )(t2p->pdf_pages + 1U);
  fprintf(_coverage_fout, "2248\n");
  fflush(_coverage_fout);
  i = (unsigned short)0;
  fprintf(_coverage_fout, "2249\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2230\n");
    fflush(_coverage_fout);
    if ((int )i < (int )t2p->tiff_pagecount) {
      fprintf(_coverage_fout, "2224\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2231\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%d", page);
    fprintf(_coverage_fout, "2232\n");
    fflush(_coverage_fout);
    tmp___0 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2233\n");
    fflush(_coverage_fout);
    written += tmp___0;
    fprintf(_coverage_fout, "2234\n");
    fflush(_coverage_fout);
    tmp___1 = t2pWriteFile(output, (void *)" 0 R ", 5L);
    fprintf(_coverage_fout, "2235\n");
    fflush(_coverage_fout);
    written += tmp___1;
    fprintf(_coverage_fout, "2236\n");
    fflush(_coverage_fout);
    if (((int )i + 1) % 8 == 0) {
      fprintf(_coverage_fout, "2225\n");
      fflush(_coverage_fout);
      tmp___2 = t2pWriteFile(output, (void *)"\n", 1L);
      fprintf(_coverage_fout, "2226\n");
      fflush(_coverage_fout);
      written += tmp___2;
    } else {
      fprintf(_coverage_fout, "2227\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2237\n");
    fflush(_coverage_fout);
    page += 3;
    fprintf(_coverage_fout, "2238\n");
    fflush(_coverage_fout);
    page = (int )((uint32 )page + (t2p->tiff_pages + i)->page_extra);
    fprintf(_coverage_fout, "2239\n");
    fflush(_coverage_fout);
    if ((t2p->tiff_pages + i)->page_tilecount > 0U) {
      fprintf(_coverage_fout, "2228\n");
      fflush(_coverage_fout);
      page = (int )((ttile_t )page + 2U * (t2p->tiff_pages + i)->page_tilecount);
    } else {
      fprintf(_coverage_fout, "2229\n");
      fflush(_coverage_fout);
      page += 2;
    }
    fprintf(_coverage_fout, "2240\n");
    fflush(_coverage_fout);
    i = (tdir_t )((int )i + 1);
  }
  fprintf(_coverage_fout, "2250\n");
  fflush(_coverage_fout);
  tmp___3 = t2pWriteFile(output, (void *)"] \n/Count ", 10L);
  fprintf(_coverage_fout, "2251\n");
  fflush(_coverage_fout);
  written += tmp___3;
  fprintf(_coverage_fout, "2252\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)(buffer), 0x00, 16L);
  fprintf(_coverage_fout, "2253\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%d", t2p->tiff_pagecount);
  fprintf(_coverage_fout, "2254\n");
  fflush(_coverage_fout);
  tmp___4 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "2255\n");
  fflush(_coverage_fout);
  written += tmp___4;
  fprintf(_coverage_fout, "2256\n");
  fflush(_coverage_fout);
  tmp___5 = t2pWriteFile(output, (void *)" \n>> \n", 6L);
  fprintf(_coverage_fout, "2257\n");
  fflush(_coverage_fout);
  written += tmp___5;
  fprintf(_coverage_fout, "2258\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_page(uint32 object , T2P *t2p , TIFF *output ) 
{ unsigned int i ;
  tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;
  tmsize_t tmp___11 ;
  tmsize_t tmp___12 ;
  tmsize_t tmp___13 ;
  tmsize_t tmp___14 ;
  tmsize_t tmp___15 ;
  tmsize_t tmp___16 ;
  tmsize_t tmp___17 ;
  tmsize_t tmp___18 ;
  tmsize_t tmp___19 ;
  tmsize_t tmp___20 ;
  tmsize_t tmp___21 ;
  tmsize_t tmp___22 ;
  tmsize_t tmp___23 ;
  tmsize_t tmp___24 ;
  tmsize_t tmp___25 ;
  tmsize_t tmp___26 ;
  tmsize_t tmp___27 ;
  tmsize_t tmp___28 ;
  tmsize_t tmp___29 ;
  tmsize_t tmp___30 ;
  tmsize_t tmp___31 ;
  tmsize_t tmp___32 ;
  tmsize_t tmp___33 ;
  tmsize_t tmp___34 ;
  tmsize_t tmp___35 ;
  tmsize_t tmp___36 ;
  tmsize_t tmp___37 ;
  tmsize_t tmp___38 ;
  tmsize_t tmp___39 ;
  tmsize_t tmp___40 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2327\n");
  fflush(_coverage_fout);
  i = 0U;
  fprintf(_coverage_fout, "2328\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2329\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "2330\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"<<\n/Type /Page \n/Parent ", 24L);
  fprintf(_coverage_fout, "2331\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2332\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )t2p->pdf_pages);
  fprintf(_coverage_fout, "2333\n");
  fflush(_coverage_fout);
  tmp___0 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "2334\n");
  fflush(_coverage_fout);
  written += tmp___0;
  fprintf(_coverage_fout, "2335\n");
  fflush(_coverage_fout);
  tmp___1 = t2pWriteFile(output, (void *)" 0 R \n", 6L);
  fprintf(_coverage_fout, "2336\n");
  fflush(_coverage_fout);
  written += tmp___1;
  fprintf(_coverage_fout, "2337\n");
  fflush(_coverage_fout);
  tmp___2 = t2pWriteFile(output, (void *)"/MediaBox [", 11L);
  fprintf(_coverage_fout, "2338\n");
  fflush(_coverage_fout);
  written += tmp___2;
  fprintf(_coverage_fout, "2339\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%.4f", t2p->pdf_mediabox.x1);
  fprintf(_coverage_fout, "2340\n");
  fflush(_coverage_fout);
  tmp___3 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "2341\n");
  fflush(_coverage_fout);
  written += tmp___3;
  fprintf(_coverage_fout, "2342\n");
  fflush(_coverage_fout);
  tmp___4 = t2pWriteFile(output, (void *)" ", 1L);
  fprintf(_coverage_fout, "2343\n");
  fflush(_coverage_fout);
  written += tmp___4;
  fprintf(_coverage_fout, "2344\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%.4f", t2p->pdf_mediabox.y1);
  fprintf(_coverage_fout, "2345\n");
  fflush(_coverage_fout);
  tmp___5 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "2346\n");
  fflush(_coverage_fout);
  written += tmp___5;
  fprintf(_coverage_fout, "2347\n");
  fflush(_coverage_fout);
  tmp___6 = t2pWriteFile(output, (void *)" ", 1L);
  fprintf(_coverage_fout, "2348\n");
  fflush(_coverage_fout);
  written += tmp___6;
  fprintf(_coverage_fout, "2349\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%.4f", t2p->pdf_mediabox.x2);
  fprintf(_coverage_fout, "2350\n");
  fflush(_coverage_fout);
  tmp___7 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "2351\n");
  fflush(_coverage_fout);
  written += tmp___7;
  fprintf(_coverage_fout, "2352\n");
  fflush(_coverage_fout);
  tmp___8 = t2pWriteFile(output, (void *)" ", 1L);
  fprintf(_coverage_fout, "2353\n");
  fflush(_coverage_fout);
  written += tmp___8;
  fprintf(_coverage_fout, "2354\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%.4f", t2p->pdf_mediabox.y2);
  fprintf(_coverage_fout, "2355\n");
  fflush(_coverage_fout);
  tmp___9 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "2356\n");
  fflush(_coverage_fout);
  written += tmp___9;
  fprintf(_coverage_fout, "2357\n");
  fflush(_coverage_fout);
  tmp___10 = t2pWriteFile(output, (void *)"] \n", 3L);
  fprintf(_coverage_fout, "2358\n");
  fflush(_coverage_fout);
  written += tmp___10;
  fprintf(_coverage_fout, "2359\n");
  fflush(_coverage_fout);
  tmp___11 = t2pWriteFile(output, (void *)"/Contents ", 10L);
  fprintf(_coverage_fout, "2360\n");
  fflush(_coverage_fout);
  written += tmp___11;
  fprintf(_coverage_fout, "2361\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )(object + 1U));
  fprintf(_coverage_fout, "2362\n");
  fflush(_coverage_fout);
  tmp___12 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "2363\n");
  fflush(_coverage_fout);
  written += tmp___12;
  fprintf(_coverage_fout, "2364\n");
  fflush(_coverage_fout);
  tmp___13 = t2pWriteFile(output, (void *)" 0 R \n", 6L);
  fprintf(_coverage_fout, "2365\n");
  fflush(_coverage_fout);
  written += tmp___13;
  fprintf(_coverage_fout, "2366\n");
  fflush(_coverage_fout);
  tmp___14 = t2pWriteFile(output, (void *)"/Resources << \n", 15L);
  fprintf(_coverage_fout, "2367\n");
  fflush(_coverage_fout);
  written += tmp___14;
  fprintf(_coverage_fout, "2368\n");
  fflush(_coverage_fout);
  if ((t2p->tiff_tiles + t2p->pdf_page)->tiles_tilecount != 0U) {
    fprintf(_coverage_fout, "2283\n");
    fflush(_coverage_fout);
    tmp___15 = t2pWriteFile(output, (void *)"/XObject <<\n", 12L);
    fprintf(_coverage_fout, "2284\n");
    fflush(_coverage_fout);
    written += tmp___15;
    fprintf(_coverage_fout, "2285\n");
    fflush(_coverage_fout);
    i = 0U;
    fprintf(_coverage_fout, "2286\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "2263\n");
      fflush(_coverage_fout);
      if (i < (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilecount) {
        fprintf(_coverage_fout, "2259\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "2264\n");
      fflush(_coverage_fout);
      tmp___16 = t2pWriteFile(output, (void *)"/Im", 3L);
      fprintf(_coverage_fout, "2265\n");
      fflush(_coverage_fout);
      written += tmp___16;
      fprintf(_coverage_fout, "2266\n");
      fflush(_coverage_fout);
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%u",
                       (int )t2p->pdf_page + 1);
      fprintf(_coverage_fout, "2267\n");
      fflush(_coverage_fout);
      tmp___17 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
      fprintf(_coverage_fout, "2268\n");
      fflush(_coverage_fout);
      written += tmp___17;
      fprintf(_coverage_fout, "2269\n");
      fflush(_coverage_fout);
      tmp___18 = t2pWriteFile(output, (void *)"_", 1L);
      fprintf(_coverage_fout, "2270\n");
      fflush(_coverage_fout);
      written += tmp___18;
      fprintf(_coverage_fout, "2271\n");
      fflush(_coverage_fout);
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%u", i + 1U);
      fprintf(_coverage_fout, "2272\n");
      fflush(_coverage_fout);
      tmp___19 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
      fprintf(_coverage_fout, "2273\n");
      fflush(_coverage_fout);
      written += tmp___19;
      fprintf(_coverage_fout, "2274\n");
      fflush(_coverage_fout);
      tmp___20 = t2pWriteFile(output, (void *)" ", 1L);
      fprintf(_coverage_fout, "2275\n");
      fflush(_coverage_fout);
      written += tmp___20;
      fprintf(_coverage_fout, "2276\n");
      fflush(_coverage_fout);
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(((object + 3U) + 2U * i) + (t2p->tiff_pages + t2p->pdf_page)->page_extra));
      fprintf(_coverage_fout, "2277\n");
      fflush(_coverage_fout);
      tmp___21 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
      fprintf(_coverage_fout, "2278\n");
      fflush(_coverage_fout);
      written += tmp___21;
      fprintf(_coverage_fout, "2279\n");
      fflush(_coverage_fout);
      tmp___22 = t2pWriteFile(output, (void *)" 0 R ", 5L);
      fprintf(_coverage_fout, "2280\n");
      fflush(_coverage_fout);
      written += tmp___22;
      fprintf(_coverage_fout, "2281\n");
      fflush(_coverage_fout);
      if (i % 4U == 3U) {
        fprintf(_coverage_fout, "2260\n");
        fflush(_coverage_fout);
        tmp___23 = t2pWriteFile(output, (void *)"\n", 1L);
        fprintf(_coverage_fout, "2261\n");
        fflush(_coverage_fout);
        written += tmp___23;
      } else {
        fprintf(_coverage_fout, "2262\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "2282\n");
      fflush(_coverage_fout);
      i ++;
    }
    fprintf(_coverage_fout, "2287\n");
    fflush(_coverage_fout);
    tmp___24 = t2pWriteFile(output, (void *)">>\n", 3L);
    fprintf(_coverage_fout, "2288\n");
    fflush(_coverage_fout);
    written += tmp___24;
  } else {
    fprintf(_coverage_fout, "2289\n");
    fflush(_coverage_fout);
    tmp___25 = t2pWriteFile(output, (void *)"/XObject <<\n", 12L);
    fprintf(_coverage_fout, "2290\n");
    fflush(_coverage_fout);
    written += tmp___25;
    fprintf(_coverage_fout, "2291\n");
    fflush(_coverage_fout);
    tmp___26 = t2pWriteFile(output, (void *)"/Im", 3L);
    fprintf(_coverage_fout, "2292\n");
    fflush(_coverage_fout);
    written += tmp___26;
    fprintf(_coverage_fout, "2293\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%u",
                     (int )t2p->pdf_page + 1);
    fprintf(_coverage_fout, "2294\n");
    fflush(_coverage_fout);
    tmp___27 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2295\n");
    fflush(_coverage_fout);
    written += tmp___27;
    fprintf(_coverage_fout, "2296\n");
    fflush(_coverage_fout);
    tmp___28 = t2pWriteFile(output, (void *)" ", 1L);
    fprintf(_coverage_fout, "2297\n");
    fflush(_coverage_fout);
    written += tmp___28;
    fprintf(_coverage_fout, "2298\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )(((object + 3U) + 2U * i) + (t2p->tiff_pages + t2p->pdf_page)->page_extra));
    fprintf(_coverage_fout, "2299\n");
    fflush(_coverage_fout);
    tmp___29 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2300\n");
    fflush(_coverage_fout);
    written += tmp___29;
    fprintf(_coverage_fout, "2301\n");
    fflush(_coverage_fout);
    tmp___30 = t2pWriteFile(output, (void *)" 0 R ", 5L);
    fprintf(_coverage_fout, "2302\n");
    fflush(_coverage_fout);
    written += tmp___30;
    fprintf(_coverage_fout, "2303\n");
    fflush(_coverage_fout);
    tmp___31 = t2pWriteFile(output, (void *)">>\n", 3L);
    fprintf(_coverage_fout, "2304\n");
    fflush(_coverage_fout);
    written += tmp___31;
  }
  fprintf(_coverage_fout, "2369\n");
  fflush(_coverage_fout);
  if ((int )t2p->tiff_transferfunctioncount != 0) {
    fprintf(_coverage_fout, "2305\n");
    fflush(_coverage_fout);
    tmp___32 = t2pWriteFile(output, (void *)"/ExtGState <<", 13L);
    fprintf(_coverage_fout, "2306\n");
    fflush(_coverage_fout);
    written += tmp___32;
    fprintf(_coverage_fout, "2307\n");
    fflush(_coverage_fout);
    t2pWriteFile(output, (void *)"/GS1 ", 5L);
    fprintf(_coverage_fout, "2308\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )(object + 3U));
    fprintf(_coverage_fout, "2309\n");
    fflush(_coverage_fout);
    tmp___33 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2310\n");
    fflush(_coverage_fout);
    written += tmp___33;
    fprintf(_coverage_fout, "2311\n");
    fflush(_coverage_fout);
    tmp___34 = t2pWriteFile(output, (void *)" 0 R ", 5L);
    fprintf(_coverage_fout, "2312\n");
    fflush(_coverage_fout);
    written += tmp___34;
    fprintf(_coverage_fout, "2313\n");
    fflush(_coverage_fout);
    tmp___35 = t2pWriteFile(output, (void *)">> \n", 4L);
    fprintf(_coverage_fout, "2314\n");
    fflush(_coverage_fout);
    written += tmp___35;
  } else {
    fprintf(_coverage_fout, "2315\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2370\n");
  fflush(_coverage_fout);
  tmp___36 = t2pWriteFile(output, (void *)"/ProcSet [ ", 11L);
  fprintf(_coverage_fout, "2371\n");
  fflush(_coverage_fout);
  written += tmp___36;
  fprintf(_coverage_fout, "2372\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_colorspace == 1U) {
    fprintf(_coverage_fout, "2316\n");
    fflush(_coverage_fout);
    tmp___37 = t2pWriteFile(output, (void *)"/ImageB ", 8L);
    fprintf(_coverage_fout, "2317\n");
    fflush(_coverage_fout);
    written += tmp___37;
  } else {
    fprintf(_coverage_fout, "2326\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_colorspace == 2U) {
      fprintf(_coverage_fout, "2318\n");
      fflush(_coverage_fout);
      tmp___37 = t2pWriteFile(output, (void *)"/ImageB ", 8L);
      fprintf(_coverage_fout, "2319\n");
      fflush(_coverage_fout);
      written += tmp___37;
    } else {
      fprintf(_coverage_fout, "2323\n");
      fflush(_coverage_fout);
      tmp___38 = t2pWriteFile(output, (void *)"/ImageC ", 8L);
      fprintf(_coverage_fout, "2324\n");
      fflush(_coverage_fout);
      written += tmp___38;
      fprintf(_coverage_fout, "2325\n");
      fflush(_coverage_fout);
      if ((unsigned int )t2p->pdf_colorspace & 4096U) {
        fprintf(_coverage_fout, "2320\n");
        fflush(_coverage_fout);
        tmp___39 = t2pWriteFile(output, (void *)"/ImageI ", 8L);
        fprintf(_coverage_fout, "2321\n");
        fflush(_coverage_fout);
        written += tmp___39;
      } else {
        fprintf(_coverage_fout, "2322\n");
        fflush(_coverage_fout);

      }
    }
  }
  fprintf(_coverage_fout, "2373\n");
  fflush(_coverage_fout);
  tmp___40 = t2pWriteFile(output, (void *)"]\n>>\n>>\n", 8L);
  fprintf(_coverage_fout, "2374\n");
  fflush(_coverage_fout);
  written += tmp___40;
  fprintf(_coverage_fout, "2375\n");
  fflush(_coverage_fout);
  return (written);
}
}
void t2p_compose_pdf_page(T2P *t2p ) 
{ uint32 i ;
  uint32 i2 ;
  T2P_TILE *tiles ;
  T2P_BOX *boxp ;
  uint32 tilecountx ;
  uint32 tilecounty ;
  uint32 tilewidth ;
  uint32 tilelength ;
  int istiled ;
  float f ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2505\n");
  fflush(_coverage_fout);
  i = (uint32 )0;
  fprintf(_coverage_fout, "2506\n");
  fflush(_coverage_fout);
  i2 = (uint32 )0;
  fprintf(_coverage_fout, "2507\n");
  fflush(_coverage_fout);
  tiles = (T2P_TILE *)((void *)0);
  fprintf(_coverage_fout, "2508\n");
  fflush(_coverage_fout);
  boxp = (T2P_BOX *)((void *)0);
  fprintf(_coverage_fout, "2509\n");
  fflush(_coverage_fout);
  tilecountx = (uint32 )0;
  fprintf(_coverage_fout, "2510\n");
  fflush(_coverage_fout);
  tilecounty = (uint32 )0;
  fprintf(_coverage_fout, "2511\n");
  fflush(_coverage_fout);
  tilewidth = (uint32 )0;
  fprintf(_coverage_fout, "2512\n");
  fflush(_coverage_fout);
  tilelength = (uint32 )0;
  fprintf(_coverage_fout, "2513\n");
  fflush(_coverage_fout);
  istiled = 0;
  fprintf(_coverage_fout, "2514\n");
  fflush(_coverage_fout);
  f = (float )0;
  fprintf(_coverage_fout, "2515\n");
  fflush(_coverage_fout);
  t2p->pdf_xres = t2p->tiff_xres;
  fprintf(_coverage_fout, "2516\n");
  fflush(_coverage_fout);
  t2p->pdf_yres = t2p->tiff_yres;
  fprintf(_coverage_fout, "2517\n");
  fflush(_coverage_fout);
  if (t2p->pdf_overrideres) {
    fprintf(_coverage_fout, "2376\n");
    fflush(_coverage_fout);
    t2p->pdf_xres = t2p->pdf_defaultxres;
    fprintf(_coverage_fout, "2377\n");
    fflush(_coverage_fout);
    t2p->pdf_yres = t2p->pdf_defaultyres;
  } else {
    fprintf(_coverage_fout, "2378\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2518\n");
  fflush(_coverage_fout);
  if ((double )t2p->pdf_xres == 0.0) {
    fprintf(_coverage_fout, "2379\n");
    fflush(_coverage_fout);
    t2p->pdf_xres = t2p->pdf_defaultxres;
  } else {
    fprintf(_coverage_fout, "2380\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2519\n");
  fflush(_coverage_fout);
  if ((double )t2p->pdf_yres == 0.0) {
    fprintf(_coverage_fout, "2381\n");
    fflush(_coverage_fout);
    t2p->pdf_yres = t2p->pdf_defaultyres;
  } else {
    fprintf(_coverage_fout, "2382\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2520\n");
  fflush(_coverage_fout);
  if ((int )t2p->tiff_resunit != 3) {
    fprintf(_coverage_fout, "2387\n");
    fflush(_coverage_fout);
    if ((int )t2p->tiff_resunit != 2) {
      fprintf(_coverage_fout, "2383\n");
      fflush(_coverage_fout);
      t2p->pdf_imagewidth = (float )t2p->tiff_width / t2p->pdf_xres;
      fprintf(_coverage_fout, "2384\n");
      fflush(_coverage_fout);
      t2p->pdf_imagelength = (float )t2p->tiff_length / t2p->pdf_yres;
    } else {
      fprintf(_coverage_fout, "2385\n");
      fflush(_coverage_fout);
      t2p->pdf_imagewidth = ((float )t2p->tiff_width * 72.0F) / t2p->pdf_xres;
      fprintf(_coverage_fout, "2386\n");
      fflush(_coverage_fout);
      t2p->pdf_imagelength = ((float )t2p->tiff_length * 72.0F) / t2p->pdf_yres;
    }
  } else {
    fprintf(_coverage_fout, "2388\n");
    fflush(_coverage_fout);
    t2p->pdf_imagewidth = ((float )t2p->tiff_width * 72.0F) / t2p->pdf_xres;
    fprintf(_coverage_fout, "2389\n");
    fflush(_coverage_fout);
    t2p->pdf_imagelength = ((float )t2p->tiff_length * 72.0F) / t2p->pdf_yres;
  }
  fprintf(_coverage_fout, "2521\n");
  fflush(_coverage_fout);
  if ((int )t2p->pdf_overridepagesize != 0) {
    fprintf(_coverage_fout, "2390\n");
    fflush(_coverage_fout);
    t2p->pdf_pagewidth = t2p->pdf_defaultpagewidth;
    fprintf(_coverage_fout, "2391\n");
    fflush(_coverage_fout);
    t2p->pdf_pagelength = t2p->pdf_defaultpagelength;
  } else {
    fprintf(_coverage_fout, "2392\n");
    fflush(_coverage_fout);
    t2p->pdf_pagewidth = t2p->pdf_imagewidth;
    fprintf(_coverage_fout, "2393\n");
    fflush(_coverage_fout);
    t2p->pdf_pagelength = t2p->pdf_imagelength;
  }
  fprintf(_coverage_fout, "2522\n");
  fflush(_coverage_fout);
  t2p->pdf_mediabox.x1 = (float )0.0;
  fprintf(_coverage_fout, "2523\n");
  fflush(_coverage_fout);
  t2p->pdf_mediabox.y1 = (float )0.0;
  fprintf(_coverage_fout, "2524\n");
  fflush(_coverage_fout);
  t2p->pdf_mediabox.x2 = t2p->pdf_pagewidth;
  fprintf(_coverage_fout, "2525\n");
  fflush(_coverage_fout);
  t2p->pdf_mediabox.y2 = t2p->pdf_pagelength;
  fprintf(_coverage_fout, "2526\n");
  fflush(_coverage_fout);
  t2p->pdf_imagebox.x1 = (float )0.0;
  fprintf(_coverage_fout, "2527\n");
  fflush(_coverage_fout);
  t2p->pdf_imagebox.y1 = (float )0.0;
  fprintf(_coverage_fout, "2528\n");
  fflush(_coverage_fout);
  t2p->pdf_imagebox.x2 = t2p->pdf_imagewidth;
  fprintf(_coverage_fout, "2529\n");
  fflush(_coverage_fout);
  t2p->pdf_imagebox.y2 = t2p->pdf_imagelength;
  fprintf(_coverage_fout, "2530\n");
  fflush(_coverage_fout);
  if ((int )t2p->pdf_overridepagesize != 0) {
    fprintf(_coverage_fout, "2394\n");
    fflush(_coverage_fout);
    t2p->pdf_imagebox.x1 += (t2p->pdf_pagewidth - t2p->pdf_imagewidth) / 2.0F;
    fprintf(_coverage_fout, "2395\n");
    fflush(_coverage_fout);
    t2p->pdf_imagebox.y1 += (t2p->pdf_pagelength - t2p->pdf_imagelength) / 2.0F;
    fprintf(_coverage_fout, "2396\n");
    fflush(_coverage_fout);
    t2p->pdf_imagebox.x2 += (t2p->pdf_pagewidth - t2p->pdf_imagewidth) / 2.0F;
    fprintf(_coverage_fout, "2397\n");
    fflush(_coverage_fout);
    t2p->pdf_imagebox.y2 += (t2p->pdf_pagelength - t2p->pdf_imagelength) / 2.0F;
  } else {
    fprintf(_coverage_fout, "2398\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2531\n");
  fflush(_coverage_fout);
  if ((int )t2p->tiff_orientation > 4) {
    fprintf(_coverage_fout, "2399\n");
    fflush(_coverage_fout);
    f = t2p->pdf_mediabox.x2;
    fprintf(_coverage_fout, "2400\n");
    fflush(_coverage_fout);
    t2p->pdf_mediabox.x2 = t2p->pdf_mediabox.y2;
    fprintf(_coverage_fout, "2401\n");
    fflush(_coverage_fout);
    t2p->pdf_mediabox.y2 = f;
  } else {
    fprintf(_coverage_fout, "2402\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2532\n");
  fflush(_coverage_fout);
  if ((t2p->tiff_tiles + t2p->pdf_page)->tiles_tilecount == 0U) {
    fprintf(_coverage_fout, "2403\n");
    fflush(_coverage_fout);
    istiled = 0;
  } else {
    fprintf(_coverage_fout, "2404\n");
    fflush(_coverage_fout);
    istiled = 1;
  }
  fprintf(_coverage_fout, "2533\n");
  fflush(_coverage_fout);
  if (istiled == 0) {
    fprintf(_coverage_fout, "2405\n");
    fflush(_coverage_fout);
    t2p_compose_pdf_page_orient(& t2p->pdf_imagebox, t2p->tiff_orientation);
    fprintf(_coverage_fout, "2406\n");
    fflush(_coverage_fout);
    return;
  } else {
    fprintf(_coverage_fout, "2433\n");
    fflush(_coverage_fout);
    tilewidth = (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilewidth;
    fprintf(_coverage_fout, "2434\n");
    fflush(_coverage_fout);
    tilelength = (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilelength;
    fprintf(_coverage_fout, "2435\n");
    fflush(_coverage_fout);
    tilecountx = ((t2p->tiff_width + tilewidth) - 1U) / tilewidth;
    fprintf(_coverage_fout, "2436\n");
    fflush(_coverage_fout);
    (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilecountx = tilecountx;
    fprintf(_coverage_fout, "2437\n");
    fflush(_coverage_fout);
    tilecounty = ((t2p->tiff_length + tilelength) - 1U) / tilelength;
    fprintf(_coverage_fout, "2438\n");
    fflush(_coverage_fout);
    (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilecounty = tilecounty;
    fprintf(_coverage_fout, "2439\n");
    fflush(_coverage_fout);
    (t2p->tiff_tiles + t2p->pdf_page)->tiles_edgetilewidth = t2p->tiff_width % tilewidth;
    fprintf(_coverage_fout, "2440\n");
    fflush(_coverage_fout);
    (t2p->tiff_tiles + t2p->pdf_page)->tiles_edgetilelength = t2p->tiff_length % tilelength;
    fprintf(_coverage_fout, "2441\n");
    fflush(_coverage_fout);
    tiles = (t2p->tiff_tiles + t2p->pdf_page)->tiles_tiles;
    fprintf(_coverage_fout, "2442\n");
    fflush(_coverage_fout);
    i2 = 0U;
    fprintf(_coverage_fout, "2443\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "2416\n");
      fflush(_coverage_fout);
      if (i2 < tilecounty - 1U) {
        fprintf(_coverage_fout, "2407\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "2417\n");
      fflush(_coverage_fout);
      i = 0U;
      fprintf(_coverage_fout, "2418\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "2409\n");
        fflush(_coverage_fout);
        if (i < tilecountx - 1U) {
          fprintf(_coverage_fout, "2408\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "2410\n");
        fflush(_coverage_fout);
        boxp = & (tiles + (i2 * tilecountx + i))->tile_box;
        fprintf(_coverage_fout, "2411\n");
        fflush(_coverage_fout);
        boxp->x1 = t2p->pdf_imagebox.x1 + ((t2p->pdf_imagewidth * (float )i) * (float )tilewidth) / (float )t2p->tiff_width;
        fprintf(_coverage_fout, "2412\n");
        fflush(_coverage_fout);
        boxp->x2 = t2p->pdf_imagebox.x1 + ((t2p->pdf_imagewidth * (float )(i + 1U)) * (float )tilewidth) / (float )t2p->tiff_width;
        fprintf(_coverage_fout, "2413\n");
        fflush(_coverage_fout);
        boxp->y1 = t2p->pdf_imagebox.y2 - ((t2p->pdf_imagelength * (float )(i2 + 1U)) * (float )tilelength) / (float )t2p->tiff_length;
        fprintf(_coverage_fout, "2414\n");
        fflush(_coverage_fout);
        boxp->y2 = t2p->pdf_imagebox.y2 - ((t2p->pdf_imagelength * (float )i2) * (float )tilelength) / (float )t2p->tiff_length;
        fprintf(_coverage_fout, "2415\n");
        fflush(_coverage_fout);
        i ++;
      }
      fprintf(_coverage_fout, "2419\n");
      fflush(_coverage_fout);
      boxp = & (tiles + (i2 * tilecountx + i))->tile_box;
      fprintf(_coverage_fout, "2420\n");
      fflush(_coverage_fout);
      boxp->x1 = t2p->pdf_imagebox.x1 + ((t2p->pdf_imagewidth * (float )i) * (float )tilewidth) / (float )t2p->tiff_width;
      fprintf(_coverage_fout, "2421\n");
      fflush(_coverage_fout);
      boxp->x2 = t2p->pdf_imagebox.x2;
      fprintf(_coverage_fout, "2422\n");
      fflush(_coverage_fout);
      boxp->y1 = t2p->pdf_imagebox.y2 - ((t2p->pdf_imagelength * (float )(i2 + 1U)) * (float )tilelength) / (float )t2p->tiff_length;
      fprintf(_coverage_fout, "2423\n");
      fflush(_coverage_fout);
      boxp->y2 = t2p->pdf_imagebox.y2 - ((t2p->pdf_imagelength * (float )i2) * (float )tilelength) / (float )t2p->tiff_length;
      fprintf(_coverage_fout, "2424\n");
      fflush(_coverage_fout);
      i2 ++;
    }
    fprintf(_coverage_fout, "2444\n");
    fflush(_coverage_fout);
    i = 0U;
    fprintf(_coverage_fout, "2445\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "2426\n");
      fflush(_coverage_fout);
      if (i < tilecountx - 1U) {
        fprintf(_coverage_fout, "2425\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "2427\n");
      fflush(_coverage_fout);
      boxp = & (tiles + (i2 * tilecountx + i))->tile_box;
      fprintf(_coverage_fout, "2428\n");
      fflush(_coverage_fout);
      boxp->x1 = t2p->pdf_imagebox.x1 + ((t2p->pdf_imagewidth * (float )i) * (float )tilewidth) / (float )t2p->tiff_width;
      fprintf(_coverage_fout, "2429\n");
      fflush(_coverage_fout);
      boxp->x2 = t2p->pdf_imagebox.x1 + ((t2p->pdf_imagewidth * (float )(i + 1U)) * (float )tilewidth) / (float )t2p->tiff_width;
      fprintf(_coverage_fout, "2430\n");
      fflush(_coverage_fout);
      boxp->y1 = t2p->pdf_imagebox.y1;
      fprintf(_coverage_fout, "2431\n");
      fflush(_coverage_fout);
      boxp->y2 = t2p->pdf_imagebox.y2 - ((t2p->pdf_imagelength * (float )i2) * (float )tilelength) / (float )t2p->tiff_length;
      fprintf(_coverage_fout, "2432\n");
      fflush(_coverage_fout);
      i ++;
    }
    fprintf(_coverage_fout, "2446\n");
    fflush(_coverage_fout);
    boxp = & (tiles + (i2 * tilecountx + i))->tile_box;
    fprintf(_coverage_fout, "2447\n");
    fflush(_coverage_fout);
    boxp->x1 = t2p->pdf_imagebox.x1 + ((t2p->pdf_imagewidth * (float )i) * (float )tilewidth) / (float )t2p->tiff_width;
    fprintf(_coverage_fout, "2448\n");
    fflush(_coverage_fout);
    boxp->x2 = t2p->pdf_imagebox.x2;
    fprintf(_coverage_fout, "2449\n");
    fflush(_coverage_fout);
    boxp->y1 = t2p->pdf_imagebox.y1;
    fprintf(_coverage_fout, "2450\n");
    fflush(_coverage_fout);
    boxp->y2 = t2p->pdf_imagebox.y2 - ((t2p->pdf_imagelength * (float )i2) * (float )tilelength) / (float )t2p->tiff_length;
  }
  fprintf(_coverage_fout, "2534\n");
  fflush(_coverage_fout);
  if ((int )t2p->tiff_orientation == 0) {
    goto _L;
  } else {
    fprintf(_coverage_fout, "2459\n");
    fflush(_coverage_fout);
    if ((int )t2p->tiff_orientation == 1) {
      fprintf(_coverage_fout, "2455\n");
      fflush(_coverage_fout);
      _L: /* CIL Label */ 
      i = 0U;
      fprintf(_coverage_fout, "2456\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "2452\n");
        fflush(_coverage_fout);
        if (i < (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilecount) {
          fprintf(_coverage_fout, "2451\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "2453\n");
        fflush(_coverage_fout);
        t2p_compose_pdf_page_orient(& (tiles + i)->tile_box, (unsigned short)0);
        fprintf(_coverage_fout, "2454\n");
        fflush(_coverage_fout);
        i ++;
      }
      fprintf(_coverage_fout, "2457\n");
      fflush(_coverage_fout);
      return;
    } else {
      fprintf(_coverage_fout, "2458\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "2535\n");
  fflush(_coverage_fout);
  i = 0U;
  fprintf(_coverage_fout, "2536\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2493\n");
    fflush(_coverage_fout);
    if (i < (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilecount) {
      fprintf(_coverage_fout, "2460\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2494\n");
    fflush(_coverage_fout);
    boxp = & (tiles + i)->tile_box;
    fprintf(_coverage_fout, "2495\n");
    fflush(_coverage_fout);
    boxp->x1 -= t2p->pdf_imagebox.x1;
    fprintf(_coverage_fout, "2496\n");
    fflush(_coverage_fout);
    boxp->x2 -= t2p->pdf_imagebox.x1;
    fprintf(_coverage_fout, "2497\n");
    fflush(_coverage_fout);
    boxp->y1 -= t2p->pdf_imagebox.y1;
    fprintf(_coverage_fout, "2498\n");
    fflush(_coverage_fout);
    boxp->y2 -= t2p->pdf_imagebox.y1;
    fprintf(_coverage_fout, "2499\n");
    fflush(_coverage_fout);
    if ((int )t2p->tiff_orientation == 2) {
      fprintf(_coverage_fout, "2461\n");
      fflush(_coverage_fout);
      boxp->x1 = (t2p->pdf_imagebox.x2 - t2p->pdf_imagebox.x1) - boxp->x1;
      fprintf(_coverage_fout, "2462\n");
      fflush(_coverage_fout);
      boxp->x2 = (t2p->pdf_imagebox.x2 - t2p->pdf_imagebox.x1) - boxp->x2;
    } else {
      fprintf(_coverage_fout, "2466\n");
      fflush(_coverage_fout);
      if ((int )t2p->tiff_orientation == 3) {
        fprintf(_coverage_fout, "2463\n");
        fflush(_coverage_fout);
        boxp->x1 = (t2p->pdf_imagebox.x2 - t2p->pdf_imagebox.x1) - boxp->x1;
        fprintf(_coverage_fout, "2464\n");
        fflush(_coverage_fout);
        boxp->x2 = (t2p->pdf_imagebox.x2 - t2p->pdf_imagebox.x1) - boxp->x2;
      } else {
        fprintf(_coverage_fout, "2465\n");
        fflush(_coverage_fout);

      }
    }
    fprintf(_coverage_fout, "2500\n");
    fflush(_coverage_fout);
    if ((int )t2p->tiff_orientation == 3) {
      fprintf(_coverage_fout, "2467\n");
      fflush(_coverage_fout);
      boxp->y1 = (t2p->pdf_imagebox.y2 - t2p->pdf_imagebox.y1) - boxp->y1;
      fprintf(_coverage_fout, "2468\n");
      fflush(_coverage_fout);
      boxp->y2 = (t2p->pdf_imagebox.y2 - t2p->pdf_imagebox.y1) - boxp->y2;
    } else {
      fprintf(_coverage_fout, "2472\n");
      fflush(_coverage_fout);
      if ((int )t2p->tiff_orientation == 4) {
        fprintf(_coverage_fout, "2469\n");
        fflush(_coverage_fout);
        boxp->y1 = (t2p->pdf_imagebox.y2 - t2p->pdf_imagebox.y1) - boxp->y1;
        fprintf(_coverage_fout, "2470\n");
        fflush(_coverage_fout);
        boxp->y2 = (t2p->pdf_imagebox.y2 - t2p->pdf_imagebox.y1) - boxp->y2;
      } else {
        fprintf(_coverage_fout, "2471\n");
        fflush(_coverage_fout);

      }
    }
    fprintf(_coverage_fout, "2501\n");
    fflush(_coverage_fout);
    if ((int )t2p->tiff_orientation == 8) {
      fprintf(_coverage_fout, "2473\n");
      fflush(_coverage_fout);
      boxp->y1 = (t2p->pdf_imagebox.y2 - t2p->pdf_imagebox.y1) - boxp->y1;
      fprintf(_coverage_fout, "2474\n");
      fflush(_coverage_fout);
      boxp->y2 = (t2p->pdf_imagebox.y2 - t2p->pdf_imagebox.y1) - boxp->y2;
    } else {
      fprintf(_coverage_fout, "2478\n");
      fflush(_coverage_fout);
      if ((int )t2p->tiff_orientation == 5) {
        fprintf(_coverage_fout, "2475\n");
        fflush(_coverage_fout);
        boxp->y1 = (t2p->pdf_imagebox.y2 - t2p->pdf_imagebox.y1) - boxp->y1;
        fprintf(_coverage_fout, "2476\n");
        fflush(_coverage_fout);
        boxp->y2 = (t2p->pdf_imagebox.y2 - t2p->pdf_imagebox.y1) - boxp->y2;
      } else {
        fprintf(_coverage_fout, "2477\n");
        fflush(_coverage_fout);

      }
    }
    fprintf(_coverage_fout, "2502\n");
    fflush(_coverage_fout);
    if ((int )t2p->tiff_orientation == 5) {
      fprintf(_coverage_fout, "2479\n");
      fflush(_coverage_fout);
      boxp->x1 = (t2p->pdf_imagebox.x2 - t2p->pdf_imagebox.x1) - boxp->x1;
      fprintf(_coverage_fout, "2480\n");
      fflush(_coverage_fout);
      boxp->x2 = (t2p->pdf_imagebox.x2 - t2p->pdf_imagebox.x1) - boxp->x2;
    } else {
      fprintf(_coverage_fout, "2484\n");
      fflush(_coverage_fout);
      if ((int )t2p->tiff_orientation == 6) {
        fprintf(_coverage_fout, "2481\n");
        fflush(_coverage_fout);
        boxp->x1 = (t2p->pdf_imagebox.x2 - t2p->pdf_imagebox.x1) - boxp->x1;
        fprintf(_coverage_fout, "2482\n");
        fflush(_coverage_fout);
        boxp->x2 = (t2p->pdf_imagebox.x2 - t2p->pdf_imagebox.x1) - boxp->x2;
      } else {
        fprintf(_coverage_fout, "2483\n");
        fflush(_coverage_fout);

      }
    }
    fprintf(_coverage_fout, "2503\n");
    fflush(_coverage_fout);
    if ((int )t2p->tiff_orientation > 4) {
      fprintf(_coverage_fout, "2485\n");
      fflush(_coverage_fout);
      f = boxp->x1;
      fprintf(_coverage_fout, "2486\n");
      fflush(_coverage_fout);
      boxp->x1 = boxp->y1;
      fprintf(_coverage_fout, "2487\n");
      fflush(_coverage_fout);
      boxp->y1 = f;
      fprintf(_coverage_fout, "2488\n");
      fflush(_coverage_fout);
      f = boxp->x2;
      fprintf(_coverage_fout, "2489\n");
      fflush(_coverage_fout);
      boxp->x2 = boxp->y2;
      fprintf(_coverage_fout, "2490\n");
      fflush(_coverage_fout);
      boxp->y2 = f;
      fprintf(_coverage_fout, "2491\n");
      fflush(_coverage_fout);
      t2p_compose_pdf_page_orient_flip(boxp, t2p->tiff_orientation);
    } else {
      fprintf(_coverage_fout, "2492\n");
      fflush(_coverage_fout);
      t2p_compose_pdf_page_orient(boxp, t2p->tiff_orientation);
    }
    fprintf(_coverage_fout, "2504\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "2537\n");
  fflush(_coverage_fout);
  return;
}
}
void t2p_compose_pdf_page_orient(T2P_BOX *boxp , uint16 orientation ) 
{ float m1[9] ;
  float f ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2574\n");
  fflush(_coverage_fout);
  f = (float )0.0;
  fprintf(_coverage_fout, "2575\n");
  fflush(_coverage_fout);
  if (boxp->x1 > boxp->x2) {
    fprintf(_coverage_fout, "2538\n");
    fflush(_coverage_fout);
    f = boxp->x1;
    fprintf(_coverage_fout, "2539\n");
    fflush(_coverage_fout);
    boxp->x1 = boxp->x2;
    fprintf(_coverage_fout, "2540\n");
    fflush(_coverage_fout);
    boxp->x2 = f;
  } else {
    fprintf(_coverage_fout, "2541\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2576\n");
  fflush(_coverage_fout);
  if (boxp->y1 > boxp->y2) {
    fprintf(_coverage_fout, "2542\n");
    fflush(_coverage_fout);
    f = boxp->y1;
    fprintf(_coverage_fout, "2543\n");
    fflush(_coverage_fout);
    boxp->y1 = boxp->y2;
    fprintf(_coverage_fout, "2544\n");
    fflush(_coverage_fout);
    boxp->y2 = f;
  } else {
    fprintf(_coverage_fout, "2545\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2577\n");
  fflush(_coverage_fout);
  m1[0] = boxp->x2 - boxp->x1;
  fprintf(_coverage_fout, "2578\n");
  fflush(_coverage_fout);
  boxp->mat[0] = m1[0];
  fprintf(_coverage_fout, "2579\n");
  fflush(_coverage_fout);
  m1[1] = (float )0.0;
  fprintf(_coverage_fout, "2580\n");
  fflush(_coverage_fout);
  boxp->mat[1] = m1[1];
  fprintf(_coverage_fout, "2581\n");
  fflush(_coverage_fout);
  m1[2] = (float )0.0;
  fprintf(_coverage_fout, "2582\n");
  fflush(_coverage_fout);
  boxp->mat[2] = m1[2];
  fprintf(_coverage_fout, "2583\n");
  fflush(_coverage_fout);
  m1[3] = (float )0.0;
  fprintf(_coverage_fout, "2584\n");
  fflush(_coverage_fout);
  boxp->mat[3] = m1[3];
  fprintf(_coverage_fout, "2585\n");
  fflush(_coverage_fout);
  m1[4] = boxp->y2 - boxp->y1;
  fprintf(_coverage_fout, "2586\n");
  fflush(_coverage_fout);
  boxp->mat[4] = m1[4];
  fprintf(_coverage_fout, "2587\n");
  fflush(_coverage_fout);
  m1[5] = (float )0.0;
  fprintf(_coverage_fout, "2588\n");
  fflush(_coverage_fout);
  boxp->mat[5] = m1[5];
  fprintf(_coverage_fout, "2589\n");
  fflush(_coverage_fout);
  m1[6] = boxp->x1;
  fprintf(_coverage_fout, "2590\n");
  fflush(_coverage_fout);
  boxp->mat[6] = m1[6];
  fprintf(_coverage_fout, "2591\n");
  fflush(_coverage_fout);
  m1[7] = boxp->y1;
  fprintf(_coverage_fout, "2592\n");
  fflush(_coverage_fout);
  boxp->mat[7] = m1[7];
  fprintf(_coverage_fout, "2593\n");
  fflush(_coverage_fout);
  m1[8] = (float )1.0;
  fprintf(_coverage_fout, "2594\n");
  fflush(_coverage_fout);
  boxp->mat[8] = m1[8];
  switch ((int )orientation) {
  case 0: 
  case 1: 
  break;
  fprintf(_coverage_fout, "2546\n");
  fflush(_coverage_fout);
  case 2: 
  boxp->mat[0] = 0.0F - m1[0];
  fprintf(_coverage_fout, "2547\n");
  fflush(_coverage_fout);
  boxp->mat[6] += m1[0];
  break;
  fprintf(_coverage_fout, "2548\n");
  fflush(_coverage_fout);
  case 3: 
  boxp->mat[0] = 0.0F - m1[0];
  fprintf(_coverage_fout, "2549\n");
  fflush(_coverage_fout);
  boxp->mat[4] = 0.0F - m1[4];
  fprintf(_coverage_fout, "2550\n");
  fflush(_coverage_fout);
  boxp->mat[6] += m1[0];
  fprintf(_coverage_fout, "2551\n");
  fflush(_coverage_fout);
  boxp->mat[7] += m1[4];
  break;
  fprintf(_coverage_fout, "2552\n");
  fflush(_coverage_fout);
  case 4: 
  boxp->mat[4] = 0.0F - m1[4];
  fprintf(_coverage_fout, "2553\n");
  fflush(_coverage_fout);
  boxp->mat[7] += m1[4];
  break;
  fprintf(_coverage_fout, "2554\n");
  fflush(_coverage_fout);
  case 5: 
  boxp->mat[0] = 0.0F;
  fprintf(_coverage_fout, "2555\n");
  fflush(_coverage_fout);
  boxp->mat[1] = 0.0F - m1[0];
  fprintf(_coverage_fout, "2556\n");
  fflush(_coverage_fout);
  boxp->mat[3] = 0.0F - m1[4];
  fprintf(_coverage_fout, "2557\n");
  fflush(_coverage_fout);
  boxp->mat[4] = 0.0F;
  fprintf(_coverage_fout, "2558\n");
  fflush(_coverage_fout);
  boxp->mat[6] += m1[4];
  fprintf(_coverage_fout, "2559\n");
  fflush(_coverage_fout);
  boxp->mat[7] += m1[0];
  break;
  fprintf(_coverage_fout, "2560\n");
  fflush(_coverage_fout);
  case 6: 
  boxp->mat[0] = 0.0F;
  fprintf(_coverage_fout, "2561\n");
  fflush(_coverage_fout);
  boxp->mat[1] = 0.0F - m1[0];
  fprintf(_coverage_fout, "2562\n");
  fflush(_coverage_fout);
  boxp->mat[3] = m1[4];
  fprintf(_coverage_fout, "2563\n");
  fflush(_coverage_fout);
  boxp->mat[4] = 0.0F;
  fprintf(_coverage_fout, "2564\n");
  fflush(_coverage_fout);
  boxp->mat[7] += m1[0];
  break;
  fprintf(_coverage_fout, "2565\n");
  fflush(_coverage_fout);
  case 7: 
  boxp->mat[0] = 0.0F;
  fprintf(_coverage_fout, "2566\n");
  fflush(_coverage_fout);
  boxp->mat[1] = m1[0];
  fprintf(_coverage_fout, "2567\n");
  fflush(_coverage_fout);
  boxp->mat[3] = m1[4];
  fprintf(_coverage_fout, "2568\n");
  fflush(_coverage_fout);
  boxp->mat[4] = 0.0F;
  break;
  fprintf(_coverage_fout, "2569\n");
  fflush(_coverage_fout);
  case 8: 
  boxp->mat[0] = 0.0F;
  fprintf(_coverage_fout, "2570\n");
  fflush(_coverage_fout);
  boxp->mat[1] = m1[0];
  fprintf(_coverage_fout, "2571\n");
  fflush(_coverage_fout);
  boxp->mat[3] = 0.0F - m1[4];
  fprintf(_coverage_fout, "2572\n");
  fflush(_coverage_fout);
  boxp->mat[4] = 0.0F;
  fprintf(_coverage_fout, "2573\n");
  fflush(_coverage_fout);
  boxp->mat[6] += m1[4];
  break;
  }
  fprintf(_coverage_fout, "2595\n");
  fflush(_coverage_fout);
  return;
}
}
void t2p_compose_pdf_page_orient_flip(T2P_BOX *boxp , uint16 orientation ) 
{ float m1[9] ;
  float f ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2624\n");
  fflush(_coverage_fout);
  f = (float )0.0;
  fprintf(_coverage_fout, "2625\n");
  fflush(_coverage_fout);
  if (boxp->x1 > boxp->x2) {
    fprintf(_coverage_fout, "2596\n");
    fflush(_coverage_fout);
    f = boxp->x1;
    fprintf(_coverage_fout, "2597\n");
    fflush(_coverage_fout);
    boxp->x1 = boxp->x2;
    fprintf(_coverage_fout, "2598\n");
    fflush(_coverage_fout);
    boxp->x2 = f;
  } else {
    fprintf(_coverage_fout, "2599\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2626\n");
  fflush(_coverage_fout);
  if (boxp->y1 > boxp->y2) {
    fprintf(_coverage_fout, "2600\n");
    fflush(_coverage_fout);
    f = boxp->y1;
    fprintf(_coverage_fout, "2601\n");
    fflush(_coverage_fout);
    boxp->y1 = boxp->y2;
    fprintf(_coverage_fout, "2602\n");
    fflush(_coverage_fout);
    boxp->y2 = f;
  } else {
    fprintf(_coverage_fout, "2603\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2627\n");
  fflush(_coverage_fout);
  m1[0] = boxp->x2 - boxp->x1;
  fprintf(_coverage_fout, "2628\n");
  fflush(_coverage_fout);
  boxp->mat[0] = m1[0];
  fprintf(_coverage_fout, "2629\n");
  fflush(_coverage_fout);
  m1[1] = 0.0F;
  fprintf(_coverage_fout, "2630\n");
  fflush(_coverage_fout);
  boxp->mat[1] = m1[1];
  fprintf(_coverage_fout, "2631\n");
  fflush(_coverage_fout);
  m1[2] = 0.0F;
  fprintf(_coverage_fout, "2632\n");
  fflush(_coverage_fout);
  boxp->mat[2] = m1[2];
  fprintf(_coverage_fout, "2633\n");
  fflush(_coverage_fout);
  m1[3] = 0.0F;
  fprintf(_coverage_fout, "2634\n");
  fflush(_coverage_fout);
  boxp->mat[3] = m1[3];
  fprintf(_coverage_fout, "2635\n");
  fflush(_coverage_fout);
  m1[4] = boxp->y2 - boxp->y1;
  fprintf(_coverage_fout, "2636\n");
  fflush(_coverage_fout);
  boxp->mat[4] = m1[4];
  fprintf(_coverage_fout, "2637\n");
  fflush(_coverage_fout);
  m1[5] = 0.0F;
  fprintf(_coverage_fout, "2638\n");
  fflush(_coverage_fout);
  boxp->mat[5] = m1[5];
  fprintf(_coverage_fout, "2639\n");
  fflush(_coverage_fout);
  m1[6] = boxp->x1;
  fprintf(_coverage_fout, "2640\n");
  fflush(_coverage_fout);
  boxp->mat[6] = m1[6];
  fprintf(_coverage_fout, "2641\n");
  fflush(_coverage_fout);
  m1[7] = boxp->y1;
  fprintf(_coverage_fout, "2642\n");
  fflush(_coverage_fout);
  boxp->mat[7] = m1[7];
  fprintf(_coverage_fout, "2643\n");
  fflush(_coverage_fout);
  m1[8] = 1.0F;
  fprintf(_coverage_fout, "2644\n");
  fflush(_coverage_fout);
  boxp->mat[8] = m1[8];
  switch ((int )orientation) {
  fprintf(_coverage_fout, "2604\n");
  fflush(_coverage_fout);
  case 5: 
  boxp->mat[0] = 0.0F;
  fprintf(_coverage_fout, "2605\n");
  fflush(_coverage_fout);
  boxp->mat[1] = 0.0F - m1[4];
  fprintf(_coverage_fout, "2606\n");
  fflush(_coverage_fout);
  boxp->mat[3] = 0.0F - m1[0];
  fprintf(_coverage_fout, "2607\n");
  fflush(_coverage_fout);
  boxp->mat[4] = 0.0F;
  fprintf(_coverage_fout, "2608\n");
  fflush(_coverage_fout);
  boxp->mat[6] += m1[0];
  fprintf(_coverage_fout, "2609\n");
  fflush(_coverage_fout);
  boxp->mat[7] += m1[4];
  break;
  fprintf(_coverage_fout, "2610\n");
  fflush(_coverage_fout);
  case 6: 
  boxp->mat[0] = 0.0F;
  fprintf(_coverage_fout, "2611\n");
  fflush(_coverage_fout);
  boxp->mat[1] = 0.0F - m1[4];
  fprintf(_coverage_fout, "2612\n");
  fflush(_coverage_fout);
  boxp->mat[3] = m1[0];
  fprintf(_coverage_fout, "2613\n");
  fflush(_coverage_fout);
  boxp->mat[4] = 0.0F;
  fprintf(_coverage_fout, "2614\n");
  fflush(_coverage_fout);
  boxp->mat[7] += m1[4];
  break;
  fprintf(_coverage_fout, "2615\n");
  fflush(_coverage_fout);
  case 7: 
  boxp->mat[0] = 0.0F;
  fprintf(_coverage_fout, "2616\n");
  fflush(_coverage_fout);
  boxp->mat[1] = m1[4];
  fprintf(_coverage_fout, "2617\n");
  fflush(_coverage_fout);
  boxp->mat[3] = m1[0];
  fprintf(_coverage_fout, "2618\n");
  fflush(_coverage_fout);
  boxp->mat[4] = 0.0F;
  break;
  fprintf(_coverage_fout, "2619\n");
  fflush(_coverage_fout);
  case 8: 
  boxp->mat[0] = 0.0F;
  fprintf(_coverage_fout, "2620\n");
  fflush(_coverage_fout);
  boxp->mat[1] = m1[4];
  fprintf(_coverage_fout, "2621\n");
  fflush(_coverage_fout);
  boxp->mat[3] = 0.0F - m1[0];
  fprintf(_coverage_fout, "2622\n");
  fflush(_coverage_fout);
  boxp->mat[4] = 0.0F;
  fprintf(_coverage_fout, "2623\n");
  fflush(_coverage_fout);
  boxp->mat[6] += m1[0];
  break;
  }
  fprintf(_coverage_fout, "2645\n");
  fflush(_coverage_fout);
  return;
}
}
tsize_t t2p_write_pdf_page_content_stream(T2P *t2p , TIFF *output ) 
{ tsize_t written ;
  ttile_t i ;
  char buffer[512] ;
  int buflen ;
  T2P_BOX box ;
  char const   *tmp ;
  tsize_t tmp___0 ;
  char const   *tmp___1 ;
  tsize_t tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2665\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2666\n");
  fflush(_coverage_fout);
  i = (ttile_t )0;
  fprintf(_coverage_fout, "2667\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "2668\n");
  fflush(_coverage_fout);
  if ((t2p->tiff_tiles + t2p->pdf_page)->tiles_tilecount > 0U) {
    fprintf(_coverage_fout, "2656\n");
    fflush(_coverage_fout);
    i = 0U;
    fprintf(_coverage_fout, "2657\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "2649\n");
      fflush(_coverage_fout);
      if (i < (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilecount) {
        fprintf(_coverage_fout, "2646\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "2650\n");
      fflush(_coverage_fout);
      box = ((t2p->tiff_tiles + t2p->pdf_page)->tiles_tiles + i)->tile_box;
      fprintf(_coverage_fout, "2651\n");
      fflush(_coverage_fout);
      if (t2p->tiff_transferfunctioncount) {
        fprintf(_coverage_fout, "2647\n");
        fflush(_coverage_fout);
        tmp = "/GS1 gs ";
      } else {
        fprintf(_coverage_fout, "2648\n");
        fflush(_coverage_fout);
        tmp = "";
      }
      fprintf(_coverage_fout, "2652\n");
      fflush(_coverage_fout);
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"q %s %.4f %.4f %.4f %.4f %.4f %.4f cm /Im%d_%ld Do Q\n",
                       tmp, box.mat[0], box.mat[1], box.mat[3], box.mat[4],
                       box.mat[6], box.mat[7], (int )t2p->pdf_page + 1,
                       (long )(i + 1U));
      fprintf(_coverage_fout, "2653\n");
      fflush(_coverage_fout);
      tmp___0 = t2p_write_pdf_stream((void *)(buffer), (long )buflen, output);
      fprintf(_coverage_fout, "2654\n");
      fflush(_coverage_fout);
      written += tmp___0;
      fprintf(_coverage_fout, "2655\n");
      fflush(_coverage_fout);
      i ++;
    }
  } else {
    fprintf(_coverage_fout, "2660\n");
    fflush(_coverage_fout);
    box = t2p->pdf_imagebox;
    fprintf(_coverage_fout, "2661\n");
    fflush(_coverage_fout);
    if (t2p->tiff_transferfunctioncount) {
      fprintf(_coverage_fout, "2658\n");
      fflush(_coverage_fout);
      tmp___1 = "/GS1 gs ";
    } else {
      fprintf(_coverage_fout, "2659\n");
      fflush(_coverage_fout);
      tmp___1 = "";
    }
    fprintf(_coverage_fout, "2662\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"q %s %.4f %.4f %.4f %.4f %.4f %.4f cm /Im%d Do Q\n",
                     tmp___1, box.mat[0], box.mat[1], box.mat[3], box.mat[4],
                     box.mat[6], box.mat[7], (int )t2p->pdf_page + 1);
    fprintf(_coverage_fout, "2663\n");
    fflush(_coverage_fout);
    tmp___2 = t2p_write_pdf_stream((void *)(buffer), (long )buflen, output);
    fprintf(_coverage_fout, "2664\n");
    fflush(_coverage_fout);
    written += tmp___2;
  }
  fprintf(_coverage_fout, "2669\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_stream_dict(ttile_t tile , T2P *t2p ,
                                          TIFF *output ) 
{ tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  int tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  int tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;
  tmsize_t tmp___11 ;
  tmsize_t tmp___12 ;
  tsize_t tmp___13 ;
  tmsize_t tmp___14 ;
  tsize_t tmp___15 ;
  tsize_t tmp___16 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2697\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2698\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "2699\n");
  fflush(_coverage_fout);
  tmp = t2p_write_pdf_stream_dict(0L, t2p->pdf_xrefcount + 1U, output);
  fprintf(_coverage_fout, "2700\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2701\n");
  fflush(_coverage_fout);
  tmp___0 = t2pWriteFile(output,
                         (void *)"/Type /XObject \n/Subtype /Image \n/Name /Im",
                         42L);
  fprintf(_coverage_fout, "2702\n");
  fflush(_coverage_fout);
  written += tmp___0;
  fprintf(_coverage_fout, "2703\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%u",
                   (int )t2p->pdf_page + 1);
  fprintf(_coverage_fout, "2704\n");
  fflush(_coverage_fout);
  tmp___1 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "2705\n");
  fflush(_coverage_fout);
  written += tmp___1;
  fprintf(_coverage_fout, "2706\n");
  fflush(_coverage_fout);
  if (tile != 0U) {
    fprintf(_coverage_fout, "2670\n");
    fflush(_coverage_fout);
    tmp___2 = t2pWriteFile(output, (void *)"_", 1L);
    fprintf(_coverage_fout, "2671\n");
    fflush(_coverage_fout);
    written += tmp___2;
    fprintf(_coverage_fout, "2672\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )tile);
    fprintf(_coverage_fout, "2673\n");
    fflush(_coverage_fout);
    tmp___3 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2674\n");
    fflush(_coverage_fout);
    written += tmp___3;
  } else {
    fprintf(_coverage_fout, "2675\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2707\n");
  fflush(_coverage_fout);
  tmp___4 = t2pWriteFile(output, (void *)"\n/Width ", 8L);
  fprintf(_coverage_fout, "2708\n");
  fflush(_coverage_fout);
  written += tmp___4;
  fprintf(_coverage_fout, "2709\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)(buffer), 0x00, 16L);
  fprintf(_coverage_fout, "2710\n");
  fflush(_coverage_fout);
  if (tile == 0U) {
    fprintf(_coverage_fout, "2676\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )t2p->tiff_width);
  } else {
    fprintf(_coverage_fout, "2679\n");
    fflush(_coverage_fout);
    tmp___5 = t2p_tile_is_right_edge(*(t2p->tiff_tiles + t2p->pdf_page),
                                     tile - 1U);
    fprintf(_coverage_fout, "2680\n");
    fflush(_coverage_fout);
    if (tmp___5 != 0) {
      fprintf(_coverage_fout, "2677\n");
      fflush(_coverage_fout);
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(t2p->tiff_tiles + t2p->pdf_page)->tiles_edgetilewidth);
    } else {
      fprintf(_coverage_fout, "2678\n");
      fflush(_coverage_fout);
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(t2p->tiff_tiles + t2p->pdf_page)->tiles_tilewidth);
    }
  }
  fprintf(_coverage_fout, "2711\n");
  fflush(_coverage_fout);
  tmp___6 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "2712\n");
  fflush(_coverage_fout);
  written += tmp___6;
  fprintf(_coverage_fout, "2713\n");
  fflush(_coverage_fout);
  tmp___7 = t2pWriteFile(output, (void *)"\n/Height ", 9L);
  fprintf(_coverage_fout, "2714\n");
  fflush(_coverage_fout);
  written += tmp___7;
  fprintf(_coverage_fout, "2715\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)(buffer), 0x00, 16L);
  fprintf(_coverage_fout, "2716\n");
  fflush(_coverage_fout);
  if (tile == 0U) {
    fprintf(_coverage_fout, "2681\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )t2p->tiff_length);
  } else {
    fprintf(_coverage_fout, "2684\n");
    fflush(_coverage_fout);
    tmp___8 = t2p_tile_is_bottom_edge(*(t2p->tiff_tiles + t2p->pdf_page),
                                      tile - 1U);
    fprintf(_coverage_fout, "2685\n");
    fflush(_coverage_fout);
    if (tmp___8 != 0) {
      fprintf(_coverage_fout, "2682\n");
      fflush(_coverage_fout);
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(t2p->tiff_tiles + t2p->pdf_page)->tiles_edgetilelength);
    } else {
      fprintf(_coverage_fout, "2683\n");
      fflush(_coverage_fout);
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(t2p->tiff_tiles + t2p->pdf_page)->tiles_tilelength);
    }
  }
  fprintf(_coverage_fout, "2717\n");
  fflush(_coverage_fout);
  tmp___9 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "2718\n");
  fflush(_coverage_fout);
  written += tmp___9;
  fprintf(_coverage_fout, "2719\n");
  fflush(_coverage_fout);
  tmp___10 = t2pWriteFile(output, (void *)"\n/BitsPerComponent ", 19L);
  fprintf(_coverage_fout, "2720\n");
  fflush(_coverage_fout);
  written += tmp___10;
  fprintf(_coverage_fout, "2721\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)(buffer), 0x00, 16L);
  fprintf(_coverage_fout, "2722\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%u",
                   t2p->tiff_bitspersample);
  fprintf(_coverage_fout, "2723\n");
  fflush(_coverage_fout);
  tmp___11 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "2724\n");
  fflush(_coverage_fout);
  written += tmp___11;
  fprintf(_coverage_fout, "2725\n");
  fflush(_coverage_fout);
  tmp___12 = t2pWriteFile(output, (void *)"\n/ColorSpace ", 13L);
  fprintf(_coverage_fout, "2726\n");
  fflush(_coverage_fout);
  written += tmp___12;
  fprintf(_coverage_fout, "2727\n");
  fflush(_coverage_fout);
  tmp___13 = t2p_write_pdf_xobject_cs(t2p, output);
  fprintf(_coverage_fout, "2728\n");
  fflush(_coverage_fout);
  written += tmp___13;
  fprintf(_coverage_fout, "2729\n");
  fflush(_coverage_fout);
  if (t2p->pdf_image_interpolate) {
    fprintf(_coverage_fout, "2686\n");
    fflush(_coverage_fout);
    tmp___14 = t2pWriteFile(output, (void *)"\n/Interpolate true", 18L);
    fprintf(_coverage_fout, "2687\n");
    fflush(_coverage_fout);
    written += tmp___14;
  } else {
    fprintf(_coverage_fout, "2688\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2730\n");
  fflush(_coverage_fout);
  if ((int )t2p->pdf_switchdecode != 0) {
    fprintf(_coverage_fout, "2695\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_colorspace == 1U) {
      fprintf(_coverage_fout, "2692\n");
      fflush(_coverage_fout);
      if ((unsigned int )t2p->pdf_compression == 1U) {
        fprintf(_coverage_fout, "2689\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "2690\n");
        fflush(_coverage_fout);
        tmp___15 = t2p_write_pdf_xobject_decode(t2p, output);
        fprintf(_coverage_fout, "2691\n");
        fflush(_coverage_fout);
        written += tmp___15;
      }
    } else {
      fprintf(_coverage_fout, "2693\n");
      fflush(_coverage_fout);
      tmp___15 = t2p_write_pdf_xobject_decode(t2p, output);
      fprintf(_coverage_fout, "2694\n");
      fflush(_coverage_fout);
      written += tmp___15;
    }
  } else {
    fprintf(_coverage_fout, "2696\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2731\n");
  fflush(_coverage_fout);
  tmp___16 = t2p_write_pdf_xobject_stream_filter(tile, t2p, output);
  fprintf(_coverage_fout, "2732\n");
  fflush(_coverage_fout);
  written += tmp___16;
  fprintf(_coverage_fout, "2733\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_cs(T2P *t2p , TIFF *output ) 
{ tsize_t written ;
  char buffer[128] ;
  int buflen ;
  float X_W ;
  float Y_W ;
  float Z_W ;
  tsize_t tmp ;
  tmsize_t tmp___0 ;
  tsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  tsize_t tmp___9 ;
  tmsize_t tmp___10 ;
  tmsize_t tmp___11 ;
  tmsize_t tmp___12 ;
  tmsize_t tmp___13 ;
  tmsize_t tmp___14 ;
  tmsize_t tmp___15 ;
  tmsize_t tmp___16 ;
  tmsize_t tmp___17 ;
  tmsize_t tmp___18 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2805\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2806\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "2807\n");
  fflush(_coverage_fout);
  X_W = (float )1.0;
  fprintf(_coverage_fout, "2808\n");
  fflush(_coverage_fout);
  Y_W = (float )1.0;
  fprintf(_coverage_fout, "2809\n");
  fflush(_coverage_fout);
  Z_W = (float )1.0;
  fprintf(_coverage_fout, "2810\n");
  fflush(_coverage_fout);
  if (((unsigned int )t2p->pdf_colorspace & 128U) != 0U) {
    fprintf(_coverage_fout, "2734\n");
    fflush(_coverage_fout);
    tmp = t2p_write_pdf_xobject_icccs(t2p, output);
    fprintf(_coverage_fout, "2735\n");
    fflush(_coverage_fout);
    written += tmp;
    fprintf(_coverage_fout, "2736\n");
    fflush(_coverage_fout);
    return (written);
  } else {
    fprintf(_coverage_fout, "2737\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2811\n");
  fflush(_coverage_fout);
  if (((unsigned int )t2p->pdf_colorspace & 4096U) != 0U) {
    fprintf(_coverage_fout, "2738\n");
    fflush(_coverage_fout);
    tmp___0 = t2pWriteFile(output, (void *)"[ /Indexed ", 11L);
    fprintf(_coverage_fout, "2739\n");
    fflush(_coverage_fout);
    written += tmp___0;
    fprintf(_coverage_fout, "2740\n");
    fflush(_coverage_fout);
    t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )((unsigned int )t2p->pdf_colorspace ^ 4096U);
    fprintf(_coverage_fout, "2741\n");
    fflush(_coverage_fout);
    tmp___1 = t2p_write_pdf_xobject_cs(t2p, output);
    fprintf(_coverage_fout, "2742\n");
    fflush(_coverage_fout);
    written += tmp___1;
    fprintf(_coverage_fout, "2743\n");
    fflush(_coverage_fout);
    t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )((unsigned int )t2p->pdf_colorspace | 4096U);
    fprintf(_coverage_fout, "2744\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%u",
                     (0x0001 << (int )t2p->tiff_bitspersample) - 1);
    fprintf(_coverage_fout, "2745\n");
    fflush(_coverage_fout);
    tmp___2 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2746\n");
    fflush(_coverage_fout);
    written += tmp___2;
    fprintf(_coverage_fout, "2747\n");
    fflush(_coverage_fout);
    tmp___3 = t2pWriteFile(output, (void *)" ", 1L);
    fprintf(_coverage_fout, "2748\n");
    fflush(_coverage_fout);
    written += tmp___3;
    fprintf(_coverage_fout, "2749\n");
    fflush(_coverage_fout);
    _TIFFmemset((void *)(buffer), 0x00, 16L);
    fprintf(_coverage_fout, "2750\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )t2p->pdf_palettecs);
    fprintf(_coverage_fout, "2751\n");
    fflush(_coverage_fout);
    tmp___4 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2752\n");
    fflush(_coverage_fout);
    written += tmp___4;
    fprintf(_coverage_fout, "2753\n");
    fflush(_coverage_fout);
    tmp___5 = t2pWriteFile(output, (void *)" 0 R ]\n", 7L);
    fprintf(_coverage_fout, "2754\n");
    fflush(_coverage_fout);
    written += tmp___5;
    fprintf(_coverage_fout, "2755\n");
    fflush(_coverage_fout);
    return (written);
  } else {
    fprintf(_coverage_fout, "2756\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2812\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_colorspace & 1U) {
    fprintf(_coverage_fout, "2757\n");
    fflush(_coverage_fout);
    tmp___6 = t2pWriteFile(output, (void *)"/DeviceGray \n", 13L);
    fprintf(_coverage_fout, "2758\n");
    fflush(_coverage_fout);
    written += tmp___6;
  } else {
    fprintf(_coverage_fout, "2759\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2813\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_colorspace & 2U) {
    fprintf(_coverage_fout, "2764\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_colorspace & 32U) {
      fprintf(_coverage_fout, "2760\n");
      fflush(_coverage_fout);
      tmp___7 = t2p_write_pdf_xobject_calcs(t2p, output);
      fprintf(_coverage_fout, "2761\n");
      fflush(_coverage_fout);
      written += tmp___7;
    } else {
      fprintf(_coverage_fout, "2762\n");
      fflush(_coverage_fout);
      tmp___8 = t2pWriteFile(output, (void *)"/DeviceGray \n", 13L);
      fprintf(_coverage_fout, "2763\n");
      fflush(_coverage_fout);
      written += tmp___8;
    }
  } else {
    fprintf(_coverage_fout, "2765\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2814\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_colorspace & 4U) {
    fprintf(_coverage_fout, "2770\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->pdf_colorspace & 64U) {
      fprintf(_coverage_fout, "2766\n");
      fflush(_coverage_fout);
      tmp___9 = t2p_write_pdf_xobject_calcs(t2p, output);
      fprintf(_coverage_fout, "2767\n");
      fflush(_coverage_fout);
      written += tmp___9;
    } else {
      fprintf(_coverage_fout, "2768\n");
      fflush(_coverage_fout);
      tmp___10 = t2pWriteFile(output, (void *)"/DeviceRGB \n", 12L);
      fprintf(_coverage_fout, "2769\n");
      fflush(_coverage_fout);
      written += tmp___10;
    }
  } else {
    fprintf(_coverage_fout, "2771\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2815\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_colorspace & 8U) {
    fprintf(_coverage_fout, "2772\n");
    fflush(_coverage_fout);
    tmp___11 = t2pWriteFile(output, (void *)"/DeviceCMYK \n", 13L);
    fprintf(_coverage_fout, "2773\n");
    fflush(_coverage_fout);
    written += tmp___11;
  } else {
    fprintf(_coverage_fout, "2774\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2816\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_colorspace & 16U) {
    fprintf(_coverage_fout, "2775\n");
    fflush(_coverage_fout);
    tmp___12 = t2pWriteFile(output, (void *)"[/Lab << \n", 10L);
    fprintf(_coverage_fout, "2776\n");
    fflush(_coverage_fout);
    written += tmp___12;
    fprintf(_coverage_fout, "2777\n");
    fflush(_coverage_fout);
    tmp___13 = t2pWriteFile(output, (void *)"/WhitePoint ", 12L);
    fprintf(_coverage_fout, "2778\n");
    fflush(_coverage_fout);
    written += tmp___13;
    fprintf(_coverage_fout, "2779\n");
    fflush(_coverage_fout);
    X_W = t2p->tiff_whitechromaticities[0];
    fprintf(_coverage_fout, "2780\n");
    fflush(_coverage_fout);
    Y_W = t2p->tiff_whitechromaticities[1];
    fprintf(_coverage_fout, "2781\n");
    fflush(_coverage_fout);
    Z_W = 1.0F - (X_W + Y_W);
    fprintf(_coverage_fout, "2782\n");
    fflush(_coverage_fout);
    X_W /= Y_W;
    fprintf(_coverage_fout, "2783\n");
    fflush(_coverage_fout);
    Z_W /= Y_W;
    fprintf(_coverage_fout, "2784\n");
    fflush(_coverage_fout);
    Y_W = 1.0F;
    fprintf(_coverage_fout, "2785\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"[%.4f %.4f %.4f] \n",
                     X_W, Y_W, Z_W);
    fprintf(_coverage_fout, "2786\n");
    fflush(_coverage_fout);
    tmp___14 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2787\n");
    fflush(_coverage_fout);
    written += tmp___14;
    fprintf(_coverage_fout, "2788\n");
    fflush(_coverage_fout);
    X_W = 0.3457F;
    fprintf(_coverage_fout, "2789\n");
    fflush(_coverage_fout);
    Y_W = 0.3585F;
    fprintf(_coverage_fout, "2790\n");
    fflush(_coverage_fout);
    Z_W = 1.0F - (X_W + Y_W);
    fprintf(_coverage_fout, "2791\n");
    fflush(_coverage_fout);
    X_W /= Y_W;
    fprintf(_coverage_fout, "2792\n");
    fflush(_coverage_fout);
    Z_W /= Y_W;
    fprintf(_coverage_fout, "2793\n");
    fflush(_coverage_fout);
    Y_W = 1.0F;
    fprintf(_coverage_fout, "2794\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"[%.4f %.4f %.4f] \n",
                     X_W, Y_W, Z_W);
    fprintf(_coverage_fout, "2795\n");
    fflush(_coverage_fout);
    tmp___15 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2796\n");
    fflush(_coverage_fout);
    written += tmp___15;
    fprintf(_coverage_fout, "2797\n");
    fflush(_coverage_fout);
    tmp___16 = t2pWriteFile(output, (void *)"/Range ", 7L);
    fprintf(_coverage_fout, "2798\n");
    fflush(_coverage_fout);
    written += tmp___16;
    fprintf(_coverage_fout, "2799\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"[%d %d %d %d] \n",
                     t2p->pdf_labrange[0], t2p->pdf_labrange[1],
                     t2p->pdf_labrange[2], t2p->pdf_labrange[3]);
    fprintf(_coverage_fout, "2800\n");
    fflush(_coverage_fout);
    tmp___17 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2801\n");
    fflush(_coverage_fout);
    written += tmp___17;
    fprintf(_coverage_fout, "2802\n");
    fflush(_coverage_fout);
    tmp___18 = t2pWriteFile(output, (void *)">>] \n", 5L);
    fprintf(_coverage_fout, "2803\n");
    fflush(_coverage_fout);
    written += tmp___18;
  } else {
    fprintf(_coverage_fout, "2804\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2817\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_transfer(T2P *t2p , TIFF *output ) 
{ tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2842\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2843\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "2844\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"<< /Type /ExtGState \n/TR ", 25L);
  fprintf(_coverage_fout, "2845\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2846\n");
  fflush(_coverage_fout);
  if ((int )t2p->tiff_transferfunctioncount == 1) {
    fprintf(_coverage_fout, "2818\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )(t2p->pdf_xrefcount + 1U));
    fprintf(_coverage_fout, "2819\n");
    fflush(_coverage_fout);
    tmp___0 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2820\n");
    fflush(_coverage_fout);
    written += tmp___0;
    fprintf(_coverage_fout, "2821\n");
    fflush(_coverage_fout);
    tmp___1 = t2pWriteFile(output, (void *)" 0 R ", 5L);
    fprintf(_coverage_fout, "2822\n");
    fflush(_coverage_fout);
    written += tmp___1;
  } else {
    fprintf(_coverage_fout, "2823\n");
    fflush(_coverage_fout);
    tmp___2 = t2pWriteFile(output, (void *)"[ ", 2L);
    fprintf(_coverage_fout, "2824\n");
    fflush(_coverage_fout);
    written += tmp___2;
    fprintf(_coverage_fout, "2825\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )(t2p->pdf_xrefcount + 1U));
    fprintf(_coverage_fout, "2826\n");
    fflush(_coverage_fout);
    tmp___3 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2827\n");
    fflush(_coverage_fout);
    written += tmp___3;
    fprintf(_coverage_fout, "2828\n");
    fflush(_coverage_fout);
    tmp___4 = t2pWriteFile(output, (void *)" 0 R ", 5L);
    fprintf(_coverage_fout, "2829\n");
    fflush(_coverage_fout);
    written += tmp___4;
    fprintf(_coverage_fout, "2830\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )(t2p->pdf_xrefcount + 2U));
    fprintf(_coverage_fout, "2831\n");
    fflush(_coverage_fout);
    tmp___5 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2832\n");
    fflush(_coverage_fout);
    written += tmp___5;
    fprintf(_coverage_fout, "2833\n");
    fflush(_coverage_fout);
    tmp___6 = t2pWriteFile(output, (void *)" 0 R ", 5L);
    fprintf(_coverage_fout, "2834\n");
    fflush(_coverage_fout);
    written += tmp___6;
    fprintf(_coverage_fout, "2835\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )(t2p->pdf_xrefcount + 3U));
    fprintf(_coverage_fout, "2836\n");
    fflush(_coverage_fout);
    tmp___7 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2837\n");
    fflush(_coverage_fout);
    written += tmp___7;
    fprintf(_coverage_fout, "2838\n");
    fflush(_coverage_fout);
    tmp___8 = t2pWriteFile(output, (void *)" 0 R ", 5L);
    fprintf(_coverage_fout, "2839\n");
    fflush(_coverage_fout);
    written += tmp___8;
    fprintf(_coverage_fout, "2840\n");
    fflush(_coverage_fout);
    tmp___9 = t2pWriteFile(output, (void *)"/Identity ] ", 12L);
    fprintf(_coverage_fout, "2841\n");
    fflush(_coverage_fout);
    written += tmp___9;
  }
  fprintf(_coverage_fout, "2847\n");
  fflush(_coverage_fout);
  tmp___10 = t2pWriteFile(output, (void *)" >> \n", 5L);
  fprintf(_coverage_fout, "2848\n");
  fflush(_coverage_fout);
  written += tmp___10;
  fprintf(_coverage_fout, "2849\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_transfer_dict(T2P *t2p , TIFF *output , uint16 i ) 
{ tsize_t written ;
  char buffer[32] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tsize_t tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2850\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2851\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "2852\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"/FunctionType 0 \n", 17L);
  fprintf(_coverage_fout, "2853\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2854\n");
  fflush(_coverage_fout);
  tmp___0 = t2pWriteFile(output, (void *)"/Domain [0.0 1.0] \n", 19L);
  fprintf(_coverage_fout, "2855\n");
  fflush(_coverage_fout);
  written += tmp___0;
  fprintf(_coverage_fout, "2856\n");
  fflush(_coverage_fout);
  tmp___1 = t2pWriteFile(output, (void *)"/Range [0.0 1.0] \n", 18L);
  fprintf(_coverage_fout, "2857\n");
  fflush(_coverage_fout);
  written += tmp___1;
  fprintf(_coverage_fout, "2858\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"/Size [%u] \n",
                   1 << (int )t2p->tiff_bitspersample);
  fprintf(_coverage_fout, "2859\n");
  fflush(_coverage_fout);
  tmp___2 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "2860\n");
  fflush(_coverage_fout);
  written += tmp___2;
  fprintf(_coverage_fout, "2861\n");
  fflush(_coverage_fout);
  tmp___3 = t2pWriteFile(output, (void *)"/BitsPerSample 16 \n", 19L);
  fprintf(_coverage_fout, "2862\n");
  fflush(_coverage_fout);
  written += tmp___3;
  fprintf(_coverage_fout, "2863\n");
  fflush(_coverage_fout);
  tmp___4 = t2p_write_pdf_stream_dict(1L << ((int )t2p->tiff_bitspersample + 1),
                                      0U, output);
  fprintf(_coverage_fout, "2864\n");
  fflush(_coverage_fout);
  written += tmp___4;
  fprintf(_coverage_fout, "2865\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_transfer_stream(T2P *t2p , TIFF *output , uint16 i ) 
{ tsize_t written ;
  tsize_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2866\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2867\n");
  fflush(_coverage_fout);
  tmp = t2p_write_pdf_stream((void *)t2p->tiff_transferfunction[i],
                             1L << ((int )t2p->tiff_bitspersample + 1), output);
  fprintf(_coverage_fout, "2868\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2869\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_calcs(T2P *t2p , TIFF *output ) 
{ tsize_t written ;
  char buffer[128] ;
  int buflen ;
  float X_W ;
  float Y_W ;
  float Z_W ;
  float X_R ;
  float Y_R ;
  float Z_R ;
  float X_G ;
  float Y_G ;
  float Z_G ;
  float X_B ;
  float Y_B ;
  float Z_B ;
  float x_w ;
  float y_w ;
  float z_w ;
  float x_r ;
  float y_r ;
  float x_g ;
  float y_g ;
  float x_b ;
  float y_b ;
  float R ;
  float G ;
  float B ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;
  tmsize_t tmp___11 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2927\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2928\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "2929\n");
  fflush(_coverage_fout);
  X_W = (float )0.0;
  fprintf(_coverage_fout, "2930\n");
  fflush(_coverage_fout);
  Y_W = (float )0.0;
  fprintf(_coverage_fout, "2931\n");
  fflush(_coverage_fout);
  Z_W = (float )0.0;
  fprintf(_coverage_fout, "2932\n");
  fflush(_coverage_fout);
  X_R = (float )0.0;
  fprintf(_coverage_fout, "2933\n");
  fflush(_coverage_fout);
  Y_R = (float )0.0;
  fprintf(_coverage_fout, "2934\n");
  fflush(_coverage_fout);
  Z_R = (float )0.0;
  fprintf(_coverage_fout, "2935\n");
  fflush(_coverage_fout);
  X_G = (float )0.0;
  fprintf(_coverage_fout, "2936\n");
  fflush(_coverage_fout);
  Y_G = (float )0.0;
  fprintf(_coverage_fout, "2937\n");
  fflush(_coverage_fout);
  Z_G = (float )0.0;
  fprintf(_coverage_fout, "2938\n");
  fflush(_coverage_fout);
  X_B = (float )0.0;
  fprintf(_coverage_fout, "2939\n");
  fflush(_coverage_fout);
  Y_B = (float )0.0;
  fprintf(_coverage_fout, "2940\n");
  fflush(_coverage_fout);
  Z_B = (float )0.0;
  fprintf(_coverage_fout, "2941\n");
  fflush(_coverage_fout);
  x_w = (float )0.0;
  fprintf(_coverage_fout, "2942\n");
  fflush(_coverage_fout);
  y_w = (float )0.0;
  fprintf(_coverage_fout, "2943\n");
  fflush(_coverage_fout);
  z_w = (float )0.0;
  fprintf(_coverage_fout, "2944\n");
  fflush(_coverage_fout);
  x_r = (float )0.0;
  fprintf(_coverage_fout, "2945\n");
  fflush(_coverage_fout);
  y_r = (float )0.0;
  fprintf(_coverage_fout, "2946\n");
  fflush(_coverage_fout);
  x_g = (float )0.0;
  fprintf(_coverage_fout, "2947\n");
  fflush(_coverage_fout);
  y_g = (float )0.0;
  fprintf(_coverage_fout, "2948\n");
  fflush(_coverage_fout);
  x_b = (float )0.0;
  fprintf(_coverage_fout, "2949\n");
  fflush(_coverage_fout);
  y_b = (float )0.0;
  fprintf(_coverage_fout, "2950\n");
  fflush(_coverage_fout);
  R = (float )1.0;
  fprintf(_coverage_fout, "2951\n");
  fflush(_coverage_fout);
  G = (float )1.0;
  fprintf(_coverage_fout, "2952\n");
  fflush(_coverage_fout);
  B = (float )1.0;
  fprintf(_coverage_fout, "2953\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"[", 1L);
  fprintf(_coverage_fout, "2954\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2955\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_colorspace & 32U) {
    fprintf(_coverage_fout, "2870\n");
    fflush(_coverage_fout);
    tmp___0 = t2pWriteFile(output, (void *)"/CalGray ", 9L);
    fprintf(_coverage_fout, "2871\n");
    fflush(_coverage_fout);
    written += tmp___0;
    fprintf(_coverage_fout, "2872\n");
    fflush(_coverage_fout);
    X_W = t2p->tiff_whitechromaticities[0];
    fprintf(_coverage_fout, "2873\n");
    fflush(_coverage_fout);
    Y_W = t2p->tiff_whitechromaticities[1];
    fprintf(_coverage_fout, "2874\n");
    fflush(_coverage_fout);
    Z_W = 1.0F - (X_W + Y_W);
    fprintf(_coverage_fout, "2875\n");
    fflush(_coverage_fout);
    X_W /= Y_W;
    fprintf(_coverage_fout, "2876\n");
    fflush(_coverage_fout);
    Z_W /= Y_W;
    fprintf(_coverage_fout, "2877\n");
    fflush(_coverage_fout);
    Y_W = 1.0F;
  } else {
    fprintf(_coverage_fout, "2878\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2956\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_colorspace & 64U) {
    fprintf(_coverage_fout, "2879\n");
    fflush(_coverage_fout);
    tmp___1 = t2pWriteFile(output, (void *)"/CalRGB ", 8L);
    fprintf(_coverage_fout, "2880\n");
    fflush(_coverage_fout);
    written += tmp___1;
    fprintf(_coverage_fout, "2881\n");
    fflush(_coverage_fout);
    x_w = t2p->tiff_whitechromaticities[0];
    fprintf(_coverage_fout, "2882\n");
    fflush(_coverage_fout);
    y_w = t2p->tiff_whitechromaticities[1];
    fprintf(_coverage_fout, "2883\n");
    fflush(_coverage_fout);
    x_r = t2p->tiff_primarychromaticities[0];
    fprintf(_coverage_fout, "2884\n");
    fflush(_coverage_fout);
    y_r = t2p->tiff_primarychromaticities[1];
    fprintf(_coverage_fout, "2885\n");
    fflush(_coverage_fout);
    x_g = t2p->tiff_primarychromaticities[2];
    fprintf(_coverage_fout, "2886\n");
    fflush(_coverage_fout);
    y_g = t2p->tiff_primarychromaticities[3];
    fprintf(_coverage_fout, "2887\n");
    fflush(_coverage_fout);
    x_b = t2p->tiff_primarychromaticities[4];
    fprintf(_coverage_fout, "2888\n");
    fflush(_coverage_fout);
    y_b = t2p->tiff_primarychromaticities[5];
    fprintf(_coverage_fout, "2889\n");
    fflush(_coverage_fout);
    z_w = y_w * (((x_g - x_b) * y_r - (x_r - x_b) * y_g) + (x_r - x_g) * y_b);
    fprintf(_coverage_fout, "2890\n");
    fflush(_coverage_fout);
    Y_R = ((y_r / R) * (((x_g - x_b) * y_w - (x_w - x_b) * y_g) + (x_w - x_g) * y_b)) / z_w;
    fprintf(_coverage_fout, "2891\n");
    fflush(_coverage_fout);
    X_R = (Y_R * x_r) / y_r;
    fprintf(_coverage_fout, "2892\n");
    fflush(_coverage_fout);
    Z_R = Y_R * (((float )1 - x_r) / y_r - (float )1);
    fprintf(_coverage_fout, "2893\n");
    fflush(_coverage_fout);
    Y_G = (((0.0F - y_g) / G) * (((x_r - x_b) * y_w - (x_w - x_b) * y_r) + (x_w - x_r) * y_b)) / z_w;
    fprintf(_coverage_fout, "2894\n");
    fflush(_coverage_fout);
    X_G = (Y_G * x_g) / y_g;
    fprintf(_coverage_fout, "2895\n");
    fflush(_coverage_fout);
    Z_G = Y_G * (((float )1 - x_g) / y_g - (float )1);
    fprintf(_coverage_fout, "2896\n");
    fflush(_coverage_fout);
    Y_B = ((y_b / B) * (((x_r - x_g) * y_w - (x_w - x_g) * y_r) + (x_w - x_r) * y_g)) / z_w;
    fprintf(_coverage_fout, "2897\n");
    fflush(_coverage_fout);
    X_B = (Y_B * x_b) / y_b;
    fprintf(_coverage_fout, "2898\n");
    fflush(_coverage_fout);
    Z_B = Y_B * (((float )1 - x_b) / y_b - (float )1);
    fprintf(_coverage_fout, "2899\n");
    fflush(_coverage_fout);
    X_W = (X_R * R + X_G * G) + X_B * B;
    fprintf(_coverage_fout, "2900\n");
    fflush(_coverage_fout);
    Y_W = (Y_R * R + Y_G * G) + Y_B * B;
    fprintf(_coverage_fout, "2901\n");
    fflush(_coverage_fout);
    Z_W = (Z_R * R + Z_G * G) + Z_B * B;
    fprintf(_coverage_fout, "2902\n");
    fflush(_coverage_fout);
    X_W /= Y_W;
    fprintf(_coverage_fout, "2903\n");
    fflush(_coverage_fout);
    Z_W /= Y_W;
    fprintf(_coverage_fout, "2904\n");
    fflush(_coverage_fout);
    Y_W = (float )1.0;
  } else {
    fprintf(_coverage_fout, "2905\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2957\n");
  fflush(_coverage_fout);
  tmp___2 = t2pWriteFile(output, (void *)"<< \n", 4L);
  fprintf(_coverage_fout, "2958\n");
  fflush(_coverage_fout);
  written += tmp___2;
  fprintf(_coverage_fout, "2959\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_colorspace & 32U) {
    fprintf(_coverage_fout, "2906\n");
    fflush(_coverage_fout);
    tmp___3 = t2pWriteFile(output, (void *)"/WhitePoint ", 12L);
    fprintf(_coverage_fout, "2907\n");
    fflush(_coverage_fout);
    written += tmp___3;
    fprintf(_coverage_fout, "2908\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"[%.4f %.4f %.4f] \n",
                     X_W, Y_W, Z_W);
    fprintf(_coverage_fout, "2909\n");
    fflush(_coverage_fout);
    tmp___4 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2910\n");
    fflush(_coverage_fout);
    written += tmp___4;
    fprintf(_coverage_fout, "2911\n");
    fflush(_coverage_fout);
    tmp___5 = t2pWriteFile(output, (void *)"/Gamma 2.2 \n", 12L);
    fprintf(_coverage_fout, "2912\n");
    fflush(_coverage_fout);
    written += tmp___5;
  } else {
    fprintf(_coverage_fout, "2913\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2960\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_colorspace & 64U) {
    fprintf(_coverage_fout, "2914\n");
    fflush(_coverage_fout);
    tmp___6 = t2pWriteFile(output, (void *)"/WhitePoint ", 12L);
    fprintf(_coverage_fout, "2915\n");
    fflush(_coverage_fout);
    written += tmp___6;
    fprintf(_coverage_fout, "2916\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"[%.4f %.4f %.4f] \n",
                     X_W, Y_W, Z_W);
    fprintf(_coverage_fout, "2917\n");
    fflush(_coverage_fout);
    tmp___7 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2918\n");
    fflush(_coverage_fout);
    written += tmp___7;
    fprintf(_coverage_fout, "2919\n");
    fflush(_coverage_fout);
    tmp___8 = t2pWriteFile(output, (void *)"/Matrix ", 8L);
    fprintf(_coverage_fout, "2920\n");
    fflush(_coverage_fout);
    written += tmp___8;
    fprintf(_coverage_fout, "2921\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"[%.4f %.4f %.4f %.4f %.4f %.4f %.4f %.4f %.4f] \n",
                     X_R, Y_R, Z_R, X_G, Y_G, Z_G, X_B, Y_B, Z_B);
    fprintf(_coverage_fout, "2922\n");
    fflush(_coverage_fout);
    tmp___9 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "2923\n");
    fflush(_coverage_fout);
    written += tmp___9;
    fprintf(_coverage_fout, "2924\n");
    fflush(_coverage_fout);
    tmp___10 = t2pWriteFile(output, (void *)"/Gamma [2.2 2.2 2.2] \n", 22L);
    fprintf(_coverage_fout, "2925\n");
    fflush(_coverage_fout);
    written += tmp___10;
  } else {
    fprintf(_coverage_fout, "2926\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2961\n");
  fflush(_coverage_fout);
  tmp___11 = t2pWriteFile(output, (void *)">>] \n", 5L);
  fprintf(_coverage_fout, "2962\n");
  fflush(_coverage_fout);
  written += tmp___11;
  fprintf(_coverage_fout, "2963\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_icccs(T2P *t2p , TIFF *output ) 
{ tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2964\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2965\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "2966\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"[/ICCBased ", 11L);
  fprintf(_coverage_fout, "2967\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2968\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )t2p->pdf_icccs);
  fprintf(_coverage_fout, "2969\n");
  fflush(_coverage_fout);
  tmp___0 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "2970\n");
  fflush(_coverage_fout);
  written += tmp___0;
  fprintf(_coverage_fout, "2971\n");
  fflush(_coverage_fout);
  tmp___1 = t2pWriteFile(output, (void *)" 0 R] \n", 7L);
  fprintf(_coverage_fout, "2972\n");
  fflush(_coverage_fout);
  written += tmp___1;
  fprintf(_coverage_fout, "2973\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_icccs_dict(T2P *t2p , TIFF *output ) 
{ tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tsize_t tmp___2 ;
  tsize_t tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2974\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2975\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "2976\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"/N ", 3L);
  fprintf(_coverage_fout, "2977\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2978\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%u \n",
                   t2p->tiff_samplesperpixel);
  fprintf(_coverage_fout, "2979\n");
  fflush(_coverage_fout);
  tmp___0 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "2980\n");
  fflush(_coverage_fout);
  written += tmp___0;
  fprintf(_coverage_fout, "2981\n");
  fflush(_coverage_fout);
  tmp___1 = t2pWriteFile(output, (void *)"/Alternate ", 11L);
  fprintf(_coverage_fout, "2982\n");
  fflush(_coverage_fout);
  written += tmp___1;
  fprintf(_coverage_fout, "2983\n");
  fflush(_coverage_fout);
  t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )((unsigned int )t2p->pdf_colorspace ^ 128U);
  fprintf(_coverage_fout, "2984\n");
  fflush(_coverage_fout);
  tmp___2 = t2p_write_pdf_xobject_cs(t2p, output);
  fprintf(_coverage_fout, "2985\n");
  fflush(_coverage_fout);
  written += tmp___2;
  fprintf(_coverage_fout, "2986\n");
  fflush(_coverage_fout);
  t2p->pdf_colorspace = (enum __anonenum_t2p_cs_t_50 )((unsigned int )t2p->pdf_colorspace | 128U);
  fprintf(_coverage_fout, "2987\n");
  fflush(_coverage_fout);
  tmp___3 = t2p_write_pdf_stream_dict((long )t2p->tiff_iccprofilelength, 0U,
                                      output);
  fprintf(_coverage_fout, "2988\n");
  fflush(_coverage_fout);
  written += tmp___3;
  fprintf(_coverage_fout, "2989\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_icccs_stream(T2P *t2p , TIFF *output ) 
{ tsize_t written ;
  tsize_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2990\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2991\n");
  fflush(_coverage_fout);
  tmp = t2p_write_pdf_stream(t2p->tiff_iccprofile,
                             (long )t2p->tiff_iccprofilelength, output);
  fprintf(_coverage_fout, "2992\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2993\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_palettecs_stream(T2P *t2p , TIFF *output ) 
{ tsize_t written ;
  tsize_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2994\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "2995\n");
  fflush(_coverage_fout);
  tmp = t2p_write_pdf_stream((void *)t2p->pdf_palette,
                             (long )t2p->pdf_palettesize, output);
  fprintf(_coverage_fout, "2996\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "2997\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_decode(T2P *t2p , TIFF *output ) 
{ tsize_t written ;
  int i ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3003\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "3004\n");
  fflush(_coverage_fout);
  i = 0;
  fprintf(_coverage_fout, "3005\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"/Decode [ ", 10L);
  fprintf(_coverage_fout, "3006\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "3007\n");
  fflush(_coverage_fout);
  i = 0;
  fprintf(_coverage_fout, "3008\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2999\n");
    fflush(_coverage_fout);
    if (i < (int )t2p->tiff_samplesperpixel) {
      fprintf(_coverage_fout, "2998\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3000\n");
    fflush(_coverage_fout);
    tmp___0 = t2pWriteFile(output, (void *)"1 0 ", 4L);
    fprintf(_coverage_fout, "3001\n");
    fflush(_coverage_fout);
    written += tmp___0;
    fprintf(_coverage_fout, "3002\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "3009\n");
  fflush(_coverage_fout);
  tmp___1 = t2pWriteFile(output, (void *)"]\n", 2L);
  fprintf(_coverage_fout, "3010\n");
  fflush(_coverage_fout);
  written += tmp___1;
  fprintf(_coverage_fout, "3011\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_xobject_stream_filter(ttile_t tile , T2P *t2p ,
                                            TIFF *output ) 
{ tsize_t written ;
  char buffer[16] ;
  int buflen ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;
  int tmp___11 ;
  tmsize_t tmp___12 ;
  tmsize_t tmp___13 ;
  tmsize_t tmp___14 ;
  tmsize_t tmp___15 ;
  int tmp___16 ;
  tmsize_t tmp___17 ;
  tmsize_t tmp___18 ;
  tmsize_t tmp___19 ;
  tmsize_t tmp___20 ;
  tmsize_t tmp___21 ;
  tmsize_t tmp___22 ;
  tmsize_t tmp___23 ;
  tmsize_t tmp___24 ;
  tmsize_t tmp___25 ;
  tmsize_t tmp___26 ;
  tmsize_t tmp___27 ;
  tmsize_t tmp___28 ;
  tmsize_t tmp___29 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3094\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "3095\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "3096\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_compression == 0U) {
    fprintf(_coverage_fout, "3012\n");
    fflush(_coverage_fout);
    return (written);
  } else {
    fprintf(_coverage_fout, "3013\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3097\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"/Filter ", 8L);
  fprintf(_coverage_fout, "3098\n");
  fflush(_coverage_fout);
  written += tmp;
  switch ((int )t2p->pdf_compression) {
  fprintf(_coverage_fout, "3080\n");
  fflush(_coverage_fout);
  case 1: 
  tmp___0 = t2pWriteFile(output, (void *)"/CCITTFaxDecode ", 16L);
  fprintf(_coverage_fout, "3081\n");
  fflush(_coverage_fout);
  written += tmp___0;
  fprintf(_coverage_fout, "3082\n");
  fflush(_coverage_fout);
  tmp___1 = t2pWriteFile(output, (void *)"/DecodeParms ", 13L);
  fprintf(_coverage_fout, "3083\n");
  fflush(_coverage_fout);
  written += tmp___1;
  fprintf(_coverage_fout, "3084\n");
  fflush(_coverage_fout);
  tmp___2 = t2pWriteFile(output, (void *)"<< /K -1 ", 9L);
  fprintf(_coverage_fout, "3085\n");
  fflush(_coverage_fout);
  written += tmp___2;
  fprintf(_coverage_fout, "3086\n");
  fflush(_coverage_fout);
  if (tile == 0U) {
    fprintf(_coverage_fout, "3014\n");
    fflush(_coverage_fout);
    tmp___3 = t2pWriteFile(output, (void *)"/Columns ", 9L);
    fprintf(_coverage_fout, "3015\n");
    fflush(_coverage_fout);
    written += tmp___3;
    fprintf(_coverage_fout, "3016\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )t2p->tiff_width);
    fprintf(_coverage_fout, "3017\n");
    fflush(_coverage_fout);
    tmp___4 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "3018\n");
    fflush(_coverage_fout);
    written += tmp___4;
    fprintf(_coverage_fout, "3019\n");
    fflush(_coverage_fout);
    tmp___5 = t2pWriteFile(output, (void *)" /Rows ", 7L);
    fprintf(_coverage_fout, "3020\n");
    fflush(_coverage_fout);
    written += tmp___5;
    fprintf(_coverage_fout, "3021\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )t2p->tiff_length);
    fprintf(_coverage_fout, "3022\n");
    fflush(_coverage_fout);
    tmp___6 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "3023\n");
    fflush(_coverage_fout);
    written += tmp___6;
  } else {
    fprintf(_coverage_fout, "3044\n");
    fflush(_coverage_fout);
    tmp___11 = t2p_tile_is_right_edge(*(t2p->tiff_tiles + t2p->pdf_page),
                                      tile - 1U);
    fprintf(_coverage_fout, "3045\n");
    fflush(_coverage_fout);
    if (tmp___11 == 0) {
      fprintf(_coverage_fout, "3024\n");
      fflush(_coverage_fout);
      tmp___7 = t2pWriteFile(output, (void *)"/Columns ", 9L);
      fprintf(_coverage_fout, "3025\n");
      fflush(_coverage_fout);
      written += tmp___7;
      fprintf(_coverage_fout, "3026\n");
      fflush(_coverage_fout);
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(t2p->tiff_tiles + t2p->pdf_page)->tiles_tilewidth);
      fprintf(_coverage_fout, "3027\n");
      fflush(_coverage_fout);
      tmp___8 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
      fprintf(_coverage_fout, "3028\n");
      fflush(_coverage_fout);
      written += tmp___8;
    } else {
      fprintf(_coverage_fout, "3029\n");
      fflush(_coverage_fout);
      tmp___9 = t2pWriteFile(output, (void *)"/Columns ", 9L);
      fprintf(_coverage_fout, "3030\n");
      fflush(_coverage_fout);
      written += tmp___9;
      fprintf(_coverage_fout, "3031\n");
      fflush(_coverage_fout);
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(t2p->tiff_tiles + t2p->pdf_page)->tiles_edgetilewidth);
      fprintf(_coverage_fout, "3032\n");
      fflush(_coverage_fout);
      tmp___10 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
      fprintf(_coverage_fout, "3033\n");
      fflush(_coverage_fout);
      written += tmp___10;
    }
    fprintf(_coverage_fout, "3046\n");
    fflush(_coverage_fout);
    tmp___16 = t2p_tile_is_bottom_edge(*(t2p->tiff_tiles + t2p->pdf_page),
                                       tile - 1U);
    fprintf(_coverage_fout, "3047\n");
    fflush(_coverage_fout);
    if (tmp___16 == 0) {
      fprintf(_coverage_fout, "3034\n");
      fflush(_coverage_fout);
      tmp___12 = t2pWriteFile(output, (void *)" /Rows ", 7L);
      fprintf(_coverage_fout, "3035\n");
      fflush(_coverage_fout);
      written += tmp___12;
      fprintf(_coverage_fout, "3036\n");
      fflush(_coverage_fout);
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(t2p->tiff_tiles + t2p->pdf_page)->tiles_tilelength);
      fprintf(_coverage_fout, "3037\n");
      fflush(_coverage_fout);
      tmp___13 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
      fprintf(_coverage_fout, "3038\n");
      fflush(_coverage_fout);
      written += tmp___13;
    } else {
      fprintf(_coverage_fout, "3039\n");
      fflush(_coverage_fout);
      tmp___14 = t2pWriteFile(output, (void *)" /Rows ", 7L);
      fprintf(_coverage_fout, "3040\n");
      fflush(_coverage_fout);
      written += tmp___14;
      fprintf(_coverage_fout, "3041\n");
      fflush(_coverage_fout);
      buflen = sprintf((char */* __restrict  */)(buffer),
                       (char const   */* __restrict  */)"%lu",
                       (unsigned long )(t2p->tiff_tiles + t2p->pdf_page)->tiles_edgetilelength);
      fprintf(_coverage_fout, "3042\n");
      fflush(_coverage_fout);
      tmp___15 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
      fprintf(_coverage_fout, "3043\n");
      fflush(_coverage_fout);
      written += tmp___15;
    }
  }
  fprintf(_coverage_fout, "3087\n");
  fflush(_coverage_fout);
  if ((int )t2p->pdf_switchdecode == 0) {
    fprintf(_coverage_fout, "3048\n");
    fflush(_coverage_fout);
    tmp___17 = t2pWriteFile(output, (void *)" /BlackIs1 true ", 16L);
    fprintf(_coverage_fout, "3049\n");
    fflush(_coverage_fout);
    written += tmp___17;
  } else {
    fprintf(_coverage_fout, "3050\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3088\n");
  fflush(_coverage_fout);
  tmp___18 = t2pWriteFile(output, (void *)">>\n", 3L);
  fprintf(_coverage_fout, "3089\n");
  fflush(_coverage_fout);
  written += tmp___18;
  break;
  fprintf(_coverage_fout, "3090\n");
  fflush(_coverage_fout);
  case 4: 
  tmp___19 = t2pWriteFile(output, (void *)"/FlateDecode ", 13L);
  fprintf(_coverage_fout, "3091\n");
  fflush(_coverage_fout);
  written += tmp___19;
  fprintf(_coverage_fout, "3092\n");
  fflush(_coverage_fout);
  if ((int )t2p->pdf_compressionquality % 100) {
    fprintf(_coverage_fout, "3051\n");
    fflush(_coverage_fout);
    tmp___20 = t2pWriteFile(output, (void *)"/DecodeParms ", 13L);
    fprintf(_coverage_fout, "3052\n");
    fflush(_coverage_fout);
    written += tmp___20;
    fprintf(_coverage_fout, "3053\n");
    fflush(_coverage_fout);
    tmp___21 = t2pWriteFile(output, (void *)"<< /Predictor ", 14L);
    fprintf(_coverage_fout, "3054\n");
    fflush(_coverage_fout);
    written += tmp___21;
    fprintf(_coverage_fout, "3055\n");
    fflush(_coverage_fout);
    _TIFFmemset((void *)(buffer), 0x00, 16L);
    fprintf(_coverage_fout, "3056\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%u",
                     (int )t2p->pdf_compressionquality % 100);
    fprintf(_coverage_fout, "3057\n");
    fflush(_coverage_fout);
    tmp___22 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "3058\n");
    fflush(_coverage_fout);
    written += tmp___22;
    fprintf(_coverage_fout, "3059\n");
    fflush(_coverage_fout);
    tmp___23 = t2pWriteFile(output, (void *)" /Columns ", 10L);
    fprintf(_coverage_fout, "3060\n");
    fflush(_coverage_fout);
    written += tmp___23;
    fprintf(_coverage_fout, "3061\n");
    fflush(_coverage_fout);
    _TIFFmemset((void *)(buffer), 0x00, 16L);
    fprintf(_coverage_fout, "3062\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%lu",
                     (unsigned long )t2p->tiff_width);
    fprintf(_coverage_fout, "3063\n");
    fflush(_coverage_fout);
    tmp___24 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "3064\n");
    fflush(_coverage_fout);
    written += tmp___24;
    fprintf(_coverage_fout, "3065\n");
    fflush(_coverage_fout);
    tmp___25 = t2pWriteFile(output, (void *)" /Colors ", 9L);
    fprintf(_coverage_fout, "3066\n");
    fflush(_coverage_fout);
    written += tmp___25;
    fprintf(_coverage_fout, "3067\n");
    fflush(_coverage_fout);
    _TIFFmemset((void *)(buffer), 0x00, 16L);
    fprintf(_coverage_fout, "3068\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%u",
                     t2p->tiff_samplesperpixel);
    fprintf(_coverage_fout, "3069\n");
    fflush(_coverage_fout);
    tmp___26 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "3070\n");
    fflush(_coverage_fout);
    written += tmp___26;
    fprintf(_coverage_fout, "3071\n");
    fflush(_coverage_fout);
    tmp___27 = t2pWriteFile(output, (void *)" /BitsPerComponent ", 19L);
    fprintf(_coverage_fout, "3072\n");
    fflush(_coverage_fout);
    written += tmp___27;
    fprintf(_coverage_fout, "3073\n");
    fflush(_coverage_fout);
    _TIFFmemset((void *)(buffer), 0x00, 16L);
    fprintf(_coverage_fout, "3074\n");
    fflush(_coverage_fout);
    buflen = sprintf((char */* __restrict  */)(buffer),
                     (char const   */* __restrict  */)"%u",
                     t2p->tiff_bitspersample);
    fprintf(_coverage_fout, "3075\n");
    fflush(_coverage_fout);
    tmp___28 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
    fprintf(_coverage_fout, "3076\n");
    fflush(_coverage_fout);
    written += tmp___28;
    fprintf(_coverage_fout, "3077\n");
    fflush(_coverage_fout);
    tmp___29 = t2pWriteFile(output, (void *)">>\n", 3L);
    fprintf(_coverage_fout, "3078\n");
    fflush(_coverage_fout);
    written += tmp___29;
  } else {
    fprintf(_coverage_fout, "3079\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "3093\n");
  fflush(_coverage_fout);
  default: ;
  break;
  }
  fprintf(_coverage_fout, "3099\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_xreftable(T2P *t2p , TIFF *output ) 
{ tsize_t written ;
  char buffer[21] ;
  int buflen ;
  uint32 i ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3106\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "3107\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "3108\n");
  fflush(_coverage_fout);
  i = (uint32 )0;
  fprintf(_coverage_fout, "3109\n");
  fflush(_coverage_fout);
  tmp = t2pWriteFile(output, (void *)"xref\n0 ", 7L);
  fprintf(_coverage_fout, "3110\n");
  fflush(_coverage_fout);
  written += tmp;
  fprintf(_coverage_fout, "3111\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )(t2p->pdf_xrefcount + 1U));
  fprintf(_coverage_fout, "3112\n");
  fflush(_coverage_fout);
  tmp___0 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "3113\n");
  fflush(_coverage_fout);
  written += tmp___0;
  fprintf(_coverage_fout, "3114\n");
  fflush(_coverage_fout);
  tmp___1 = t2pWriteFile(output, (void *)" \n0000000000 65535 f \n", 22L);
  fprintf(_coverage_fout, "3115\n");
  fflush(_coverage_fout);
  written += tmp___1;
  fprintf(_coverage_fout, "3116\n");
  fflush(_coverage_fout);
  i = 0U;
  fprintf(_coverage_fout, "3117\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3101\n");
    fflush(_coverage_fout);
    if (i < t2p->pdf_xrefcount) {
      fprintf(_coverage_fout, "3100\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3102\n");
    fflush(_coverage_fout);
    sprintf((char */* __restrict  */)(buffer),
            (char const   */* __restrict  */)"%.10lu 00000 n \n",
            (unsigned long )*(t2p->pdf_xrefoffsets + i));
    fprintf(_coverage_fout, "3103\n");
    fflush(_coverage_fout);
    tmp___2 = t2pWriteFile(output, (void *)(buffer), 20L);
    fprintf(_coverage_fout, "3104\n");
    fflush(_coverage_fout);
    written += tmp___2;
    fprintf(_coverage_fout, "3105\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "3118\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf_trailer(T2P *t2p , TIFF *output ) 
{ tsize_t written ;
  char buffer[32] ;
  int buflen ;
  char fileidbuf[16] ;
  int i ;
  void *tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;
  tmsize_t tmp___11 ;
  tmsize_t tmp___12 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3127\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "3128\n");
  fflush(_coverage_fout);
  buflen = 0;
  fprintf(_coverage_fout, "3129\n");
  fflush(_coverage_fout);
  i = 0;
  fprintf(_coverage_fout, "3130\n");
  fflush(_coverage_fout);
  *((int *)(fileidbuf) + 0) = rand();
  fprintf(_coverage_fout, "3131\n");
  fflush(_coverage_fout);
  *((int *)(fileidbuf) + 1) = rand();
  fprintf(_coverage_fout, "3132\n");
  fflush(_coverage_fout);
  *((int *)(fileidbuf) + 2) = rand();
  fprintf(_coverage_fout, "3133\n");
  fflush(_coverage_fout);
  *((int *)(fileidbuf) + 3) = rand();
  fprintf(_coverage_fout, "3134\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc(33L);
  fprintf(_coverage_fout, "3135\n");
  fflush(_coverage_fout);
  t2p->pdf_fileid = (unsigned char *)tmp;
  fprintf(_coverage_fout, "3136\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_fileid == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "3119\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf",
              "Can\'t allocate %u bytes of memory for t2p_write_pdf_trailer", 33);
    fprintf(_coverage_fout, "3120\n");
    fflush(_coverage_fout);
    t2p->t2p_error = (enum __anonenum_t2p_err_t_54 )1;
    fprintf(_coverage_fout, "3121\n");
    fflush(_coverage_fout);
    return (0L);
  } else {
    fprintf(_coverage_fout, "3122\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3137\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)t2p->pdf_fileid, 0x00, 33L);
  fprintf(_coverage_fout, "3138\n");
  fflush(_coverage_fout);
  i = 0;
  fprintf(_coverage_fout, "3139\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3124\n");
    fflush(_coverage_fout);
    if (i < 16) {
      fprintf(_coverage_fout, "3123\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3125\n");
    fflush(_coverage_fout);
    sprintf((char */* __restrict  */)((char *)t2p->pdf_fileid + 2 * i),
            (char const   */* __restrict  */)"%.2hhX", fileidbuf[i]);
    fprintf(_coverage_fout, "3126\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "3140\n");
  fflush(_coverage_fout);
  tmp___0 = t2pWriteFile(output, (void *)"trailer\n<<\n/Size ", 17L);
  fprintf(_coverage_fout, "3141\n");
  fflush(_coverage_fout);
  written += tmp___0;
  fprintf(_coverage_fout, "3142\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )(t2p->pdf_xrefcount + 1U));
  fprintf(_coverage_fout, "3143\n");
  fflush(_coverage_fout);
  tmp___1 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "3144\n");
  fflush(_coverage_fout);
  written += tmp___1;
  fprintf(_coverage_fout, "3145\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)(buffer), 0x00, 32L);
  fprintf(_coverage_fout, "3146\n");
  fflush(_coverage_fout);
  tmp___2 = t2pWriteFile(output, (void *)"\n/Root ", 7L);
  fprintf(_coverage_fout, "3147\n");
  fflush(_coverage_fout);
  written += tmp___2;
  fprintf(_coverage_fout, "3148\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )t2p->pdf_catalog);
  fprintf(_coverage_fout, "3149\n");
  fflush(_coverage_fout);
  tmp___3 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "3150\n");
  fflush(_coverage_fout);
  written += tmp___3;
  fprintf(_coverage_fout, "3151\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)(buffer), 0x00, 32L);
  fprintf(_coverage_fout, "3152\n");
  fflush(_coverage_fout);
  tmp___4 = t2pWriteFile(output, (void *)" 0 R \n/Info ", 12L);
  fprintf(_coverage_fout, "3153\n");
  fflush(_coverage_fout);
  written += tmp___4;
  fprintf(_coverage_fout, "3154\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )t2p->pdf_info);
  fprintf(_coverage_fout, "3155\n");
  fflush(_coverage_fout);
  tmp___5 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "3156\n");
  fflush(_coverage_fout);
  written += tmp___5;
  fprintf(_coverage_fout, "3157\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)(buffer), 0x00, 32L);
  fprintf(_coverage_fout, "3158\n");
  fflush(_coverage_fout);
  tmp___6 = t2pWriteFile(output, (void *)" 0 R \n/ID[<", 11L);
  fprintf(_coverage_fout, "3159\n");
  fflush(_coverage_fout);
  written += tmp___6;
  fprintf(_coverage_fout, "3160\n");
  fflush(_coverage_fout);
  tmp___7 = t2pWriteFile(output, (void *)t2p->pdf_fileid, 32L);
  fprintf(_coverage_fout, "3161\n");
  fflush(_coverage_fout);
  written += tmp___7;
  fprintf(_coverage_fout, "3162\n");
  fflush(_coverage_fout);
  tmp___8 = t2pWriteFile(output, (void *)"><", 2L);
  fprintf(_coverage_fout, "3163\n");
  fflush(_coverage_fout);
  written += tmp___8;
  fprintf(_coverage_fout, "3164\n");
  fflush(_coverage_fout);
  tmp___9 = t2pWriteFile(output, (void *)t2p->pdf_fileid, 32L);
  fprintf(_coverage_fout, "3165\n");
  fflush(_coverage_fout);
  written += tmp___9;
  fprintf(_coverage_fout, "3166\n");
  fflush(_coverage_fout);
  tmp___10 = t2pWriteFile(output, (void *)">]\n>>\nstartxref\n", 16L);
  fprintf(_coverage_fout, "3167\n");
  fflush(_coverage_fout);
  written += tmp___10;
  fprintf(_coverage_fout, "3168\n");
  fflush(_coverage_fout);
  buflen = sprintf((char */* __restrict  */)(buffer),
                   (char const   */* __restrict  */)"%lu",
                   (unsigned long )t2p->pdf_startxref);
  fprintf(_coverage_fout, "3169\n");
  fflush(_coverage_fout);
  tmp___11 = t2pWriteFile(output, (void *)(buffer), (long )buflen);
  fprintf(_coverage_fout, "3170\n");
  fflush(_coverage_fout);
  written += tmp___11;
  fprintf(_coverage_fout, "3171\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)(buffer), 0x00, 32L);
  fprintf(_coverage_fout, "3172\n");
  fflush(_coverage_fout);
  tmp___12 = t2pWriteFile(output, (void *)"\n%%EOF\n", 7L);
  fprintf(_coverage_fout, "3173\n");
  fflush(_coverage_fout);
  written += tmp___12;
  fprintf(_coverage_fout, "3174\n");
  fflush(_coverage_fout);
  return (written);
}
}
tsize_t t2p_write_pdf(T2P *t2p , TIFF *input , TIFF *output ) 
{ tsize_t written ;
  ttile_t i2 ;
  tsize_t streamlen ;
  uint16 i ;
  void *tmp ;
  tsize_t tmp___0 ;
  uint32 tmp___1 ;
  tsize_t tmp___2 ;
  tsize_t tmp___3 ;
  tsize_t tmp___4 ;
  uint32 tmp___5 ;
  tsize_t tmp___6 ;
  tsize_t tmp___7 ;
  tsize_t tmp___8 ;
  uint32 tmp___9 ;
  tsize_t tmp___10 ;
  tsize_t tmp___11 ;
  tsize_t tmp___12 ;
  uint32 tmp___13 ;
  tsize_t tmp___14 ;
  tsize_t tmp___15 ;
  tsize_t tmp___16 ;
  uint32 tmp___17 ;
  tsize_t tmp___18 ;
  tsize_t tmp___19 ;
  tsize_t tmp___20 ;
  tsize_t tmp___21 ;
  tsize_t tmp___22 ;
  tsize_t tmp___23 ;
  tsize_t tmp___24 ;
  tsize_t tmp___25 ;
  uint32 tmp___26 ;
  tsize_t tmp___27 ;
  tsize_t tmp___28 ;
  tsize_t tmp___29 ;
  uint32 tmp___30 ;
  tsize_t tmp___31 ;
  tsize_t tmp___32 ;
  tsize_t tmp___33 ;
  uint32 tmp___34 ;
  tsize_t tmp___35 ;
  tsize_t tmp___36 ;
  tsize_t tmp___37 ;
  tsize_t tmp___38 ;
  tsize_t tmp___39 ;
  tsize_t tmp___40 ;
  tsize_t tmp___41 ;
  tsize_t tmp___42 ;
  uint32 tmp___43 ;
  tsize_t tmp___44 ;
  tsize_t tmp___45 ;
  tsize_t tmp___46 ;
  tsize_t tmp___47 ;
  tsize_t tmp___48 ;
  tsize_t tmp___49 ;
  tsize_t tmp___50 ;
  tsize_t tmp___51 ;
  uint32 tmp___52 ;
  tsize_t tmp___53 ;
  tsize_t tmp___54 ;
  tsize_t tmp___55 ;
  tsize_t tmp___56 ;
  tsize_t tmp___57 ;
  tsize_t tmp___58 ;
  tsize_t tmp___59 ;
  tsize_t tmp___60 ;
  uint32 tmp___61 ;
  tsize_t tmp___62 ;
  tsize_t tmp___63 ;
  tsize_t tmp___64 ;
  tsize_t tmp___65 ;
  tsize_t tmp___66 ;
  tsize_t tmp___67 ;
  tsize_t tmp___68 ;
  tsize_t tmp___69 ;
  uint32 tmp___70 ;
  tsize_t tmp___71 ;
  tsize_t tmp___72 ;
  tsize_t tmp___73 ;
  uint32 tmp___74 ;
  tsize_t tmp___75 ;
  tsize_t tmp___76 ;
  tsize_t tmp___77 ;
  tsize_t tmp___78 ;
  tsize_t tmp___79 ;
  tsize_t tmp___80 ;
  tsize_t tmp___81 ;
  tsize_t tmp___82 ;
  uint32 tmp___83 ;
  tsize_t tmp___84 ;
  tsize_t tmp___85 ;
  tsize_t tmp___86 ;
  tsize_t tmp___87 ;
  tsize_t tmp___88 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-90d136e4-4c66680f/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3387\n");
  fflush(_coverage_fout);
  written = (tsize_t )0;
  fprintf(_coverage_fout, "3388\n");
  fflush(_coverage_fout);
  i2 = (ttile_t )0;
  fprintf(_coverage_fout, "3389\n");
  fflush(_coverage_fout);
  streamlen = (tsize_t )0;
  fprintf(_coverage_fout, "3390\n");
  fflush(_coverage_fout);
  i = (uint16 )0;
  fprintf(_coverage_fout, "3391\n");
  fflush(_coverage_fout);
  t2p_read_tiff_init(t2p, input);
  fprintf(_coverage_fout, "3392\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->t2p_error != 0U) {
    fprintf(_coverage_fout, "3175\n");
    fflush(_coverage_fout);
    return (0L);
  } else {
    fprintf(_coverage_fout, "3176\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3393\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )(t2p->pdf_xrefcount * sizeof(uint32 )));
  fprintf(_coverage_fout, "3394\n");
  fflush(_coverage_fout);
  t2p->pdf_xrefoffsets = (uint32 *)tmp;
  fprintf(_coverage_fout, "3395\n");
  fflush(_coverage_fout);
  if ((unsigned int )t2p->pdf_xrefoffsets == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "3177\n");
    fflush(_coverage_fout);
    TIFFError("tiff2pdf",
              "Can\'t allocate %u bytes of memory for t2p_write_pdf",
              t2p->pdf_xrefcount * sizeof(uint32 ));
    fprintf(_coverage_fout, "3178\n");
    fflush(_coverage_fout);
    return (written);
  } else {
    fprintf(_coverage_fout, "3179\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3396\n");
  fflush(_coverage_fout);
  t2p->pdf_xrefcount = 0U;
  fprintf(_coverage_fout, "3397\n");
  fflush(_coverage_fout);
  t2p->pdf_catalog = 1U;
  fprintf(_coverage_fout, "3398\n");
  fflush(_coverage_fout);
  t2p->pdf_info = 2U;
  fprintf(_coverage_fout, "3399\n");
  fflush(_coverage_fout);
  t2p->pdf_pages = 3U;
  fprintf(_coverage_fout, "3400\n");
  fflush(_coverage_fout);
  tmp___0 = t2p_write_pdf_header(t2p, output);
  fprintf(_coverage_fout, "3401\n");
  fflush(_coverage_fout);
  written += tmp___0;
  fprintf(_coverage_fout, "3402\n");
  fflush(_coverage_fout);
  tmp___1 = t2p->pdf_xrefcount;
  fprintf(_coverage_fout, "3403\n");
  fflush(_coverage_fout);
  (t2p->pdf_xrefcount) ++;
  fprintf(_coverage_fout, "3404\n");
  fflush(_coverage_fout);
  *(t2p->pdf_xrefoffsets + tmp___1) = (unsigned int )written;
  fprintf(_coverage_fout, "3405\n");
  fflush(_coverage_fout);
  t2p->pdf_catalog = t2p->pdf_xrefcount;
  fprintf(_coverage_fout, "3406\n");
  fflush(_coverage_fout);
  tmp___2 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
  fprintf(_coverage_fout, "3407\n");
  fflush(_coverage_fout);
  written += tmp___2;
  fprintf(_coverage_fout, "3408\n");
  fflush(_coverage_fout);
  tmp___3 = t2p_write_pdf_catalog(t2p, output);
  fprintf(_coverage_fout, "3409\n");
  fflush(_coverage_fout);
  written += tmp___3;
  fprintf(_coverage_fout, "3410\n");
  fflush(_coverage_fout);
  tmp___4 = t2p_write_pdf_obj_end(output);
  fprintf(_coverage_fout, "3411\n");
  fflush(_coverage_fout);
  written += tmp___4;
  fprintf(_coverage_fout, "3412\n");
  fflush(_coverage_fout);
  tmp___5 = t2p->pdf_xrefcount;
  fprintf(_coverage_fout, "3413\n");
  fflush(_coverage_fout);
  (t2p->pdf_xrefcount) ++;
  fprintf(_coverage_fout, "3414\n");
  fflush(_coverage_fout);
  *(t2p->pdf_xrefoffsets + tmp___5) = (unsigned int )written;
  fprintf(_coverage_fout, "3415\n");
  fflush(_coverage_fout);
  t2p->pdf_info = t2p->pdf_xrefcount;
  fprintf(_coverage_fout, "3416\n");
  fflush(_coverage_fout);
  tmp___6 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
  fprintf(_coverage_fout, "3417\n");
  fflush(_coverage_fout);
  written += tmp___6;
  fprintf(_coverage_fout, "3418\n");
  fflush(_coverage_fout);
  tmp___7 = t2p_write_pdf_info(t2p, input, output);
  fprintf(_coverage_fout, "3419\n");
  fflush(_coverage_fout);
  written += tmp___7;
  fprintf(_coverage_fout, "3420\n");
  fflush(_coverage_fout);
  tmp___8 = t2p_write_pdf_obj_end(output);
  fprintf(_coverage_fout, "3421\n");
  fflush(_coverage_fout);
  written += tmp___8;
  fprintf(_coverage_fout, "3422\n");
  fflush(_coverage_fout);
  tmp___9 = t2p->pdf_xrefcount;
  fprintf(_coverage_fout, "3423\n");
  fflush(_coverage_fout);
  (t2p->pdf_xrefcount) ++;
  fprintf(_coverage_fout, "3424\n");
  fflush(_coverage_fout);
  *(t2p->pdf_xrefoffsets + tmp___9) = (unsigned int )written;
  fprintf(_coverage_fout, "3425\n");
  fflush(_coverage_fout);
  t2p->pdf_pages = t2p->pdf_xrefcount;
  fprintf(_coverage_fout, "3426\n");
  fflush(_coverage_fout);
  tmp___10 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
  fprintf(_coverage_fout, "3427\n");
  fflush(_coverage_fout);
  written += tmp___10;
  fprintf(_coverage_fout, "3428\n");
  fflush(_coverage_fout);
  tmp___11 = t2p_write_pdf_pages(t2p, output);
  fprintf(_coverage_fout, "3429\n");
  fflush(_coverage_fout);
  written += tmp___11;
  fprintf(_coverage_fout, "3430\n");
  fflush(_coverage_fout);
  tmp___12 = t2p_write_pdf_obj_end(output);
  fprintf(_coverage_fout, "3431\n");
  fflush(_coverage_fout);
  written += tmp___12;
  fprintf(_coverage_fout, "3432\n");
  fflush(_coverage_fout);
  t2p->pdf_page = (unsigned short)0;
  fprintf(_coverage_fout, "3433\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3340\n");
    fflush(_coverage_fout);
    if ((int )t2p->pdf_page < (int )t2p->tiff_pagecount) {
      fprintf(_coverage_fout, "3180\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3341\n");
    fflush(_coverage_fout);
    t2p_read_tiff_data(t2p, input);
    fprintf(_coverage_fout, "3342\n");
    fflush(_coverage_fout);
    if ((unsigned int )t2p->t2p_error != 0U) {
      fprintf(_coverage_fout, "3181\n");
      fflush(_coverage_fout);
      return (0L);
    } else {
      fprintf(_coverage_fout, "3182\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3343\n");
    fflush(_coverage_fout);
    tmp___13 = t2p->pdf_xrefcount;
    fprintf(_coverage_fout, "3344\n");
    fflush(_coverage_fout);
    (t2p->pdf_xrefcount) ++;
    fprintf(_coverage_fout, "3345\n");
    fflush(_coverage_fout);
    *(t2p->pdf_xrefoffsets + tmp___13) = (unsigned int )written;
    fprintf(_coverage_fout, "3346\n");
    fflush(_coverage_fout);
    tmp___14 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
    fprintf(_coverage_fout, "3347\n");
    fflush(_coverage_fout);
    written += tmp___14;
    fprintf(_coverage_fout, "3348\n");
    fflush(_coverage_fout);
    tmp___15 = t2p_write_pdf_page(t2p->pdf_xrefcount, t2p, output);
    fprintf(_coverage_fout, "3349\n");
    fflush(_coverage_fout);
    written += tmp___15;
    fprintf(_coverage_fout, "3350\n");
    fflush(_coverage_fout);
    tmp___16 = t2p_write_pdf_obj_end(output);
    fprintf(_coverage_fout, "3351\n");
    fflush(_coverage_fout);
    written += tmp___16;
    fprintf(_coverage_fout, "3352\n");
    fflush(_coverage_fout);
    tmp___17 = t2p->pdf_xrefcount;
    fprintf(_coverage_fout, "3353\n");
    fflush(_coverage_fout);
    (t2p->pdf_xrefcount) ++;
    fprintf(_coverage_fout, "3354\n");
    fflush(_coverage_fout);
    *(t2p->pdf_xrefoffsets + tmp___17) = (unsigned int )written;
    fprintf(_coverage_fout, "3355\n");
    fflush(_coverage_fout);
    tmp___18 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
    fprintf(_coverage_fout, "3356\n");
    fflush(_coverage_fout);
    written += tmp___18;
    fprintf(_coverage_fout, "3357\n");
    fflush(_coverage_fout);
    tmp___19 = t2p_write_pdf_stream_dict_start(output);
    fprintf(_coverage_fout, "3358\n");
    fflush(_coverage_fout);
    written += tmp___19;
    fprintf(_coverage_fout, "3359\n");
    fflush(_coverage_fout);
    tmp___20 = t2p_write_pdf_stream_dict(0L, t2p->pdf_xrefcount + 1U, output);
    fprintf(_coverage_fout, "3360\n");
    fflush(_coverage_fout);
    written += tmp___20;
    fprintf(_coverage_fout, "3361\n");
    fflush(_coverage_fout);
    tmp___21 = t2p_write_pdf_stream_dict_end(output);
    fprintf(_coverage_fout, "3362\n");
    fflush(_coverage_fout);
    written += tmp___21;
    fprintf(_coverage_fout, "3363\n");
    fflush(_coverage_fout);
    tmp___22 = t2p_write_pdf_stream_start(output);
    fprintf(_coverage_fout, "3364\n");
    fflush(_coverage_fout);
    written += tmp___22;
    fprintf(_coverage_fout, "3365\n");
    fflush(_coverage_fout);
    streamlen = written;
    fprintf(_coverage_fout, "3366\n");
    fflush(_coverage_fout);
    tmp___23 = t2p_write_pdf_page_content_stream(t2p, output);
    fprintf(_coverage_fout, "3367\n");
    fflush(_coverage_fout);
    written += tmp___23;
    fprintf(_coverage_fout, "3368\n");
    fflush(_coverage_fout);
    streamlen = written - streamlen;
    fprintf(_coverage_fout, "3369\n");
    fflush(_coverage_fout);
    tmp___24 = t2p_write_pdf_stream_end(output);
    fprintf(_coverage_fout, "3370\n");
    fflush(_coverage_fout);
    written += tmp___24;
    fprintf(_coverage_fout, "3371\n");
    fflush(_coverage_fout);
    tmp___25 = t2p_write_pdf_obj_end(output);
    fprintf(_coverage_fout, "3372\n");
    fflush(_coverage_fout);
    written += tmp___25;
    fprintf(_coverage_fout, "3373\n");
    fflush(_coverage_fout);
    tmp___26 = t2p->pdf_xrefcount;
    fprintf(_coverage_fout, "3374\n");
    fflush(_coverage_fout);
    (t2p->pdf_xrefcount) ++;
    fprintf(_coverage_fout, "3375\n");
    fflush(_coverage_fout);
    *(t2p->pdf_xrefoffsets + tmp___26) = (unsigned int )written;
    fprintf(_coverage_fout, "3376\n");
    fflush(_coverage_fout);
    tmp___27 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
    fprintf(_coverage_fout, "3377\n");
    fflush(_coverage_fout);
    written += tmp___27;
    fprintf(_coverage_fout, "3378\n");
    fflush(_coverage_fout);
    tmp___28 = t2p_write_pdf_stream_length(streamlen, output);
    fprintf(_coverage_fout, "3379\n");
    fflush(_coverage_fout);
    written += tmp___28;
    fprintf(_coverage_fout, "3380\n");
    fflush(_coverage_fout);
    tmp___29 = t2p_write_pdf_obj_end(output);
    fprintf(_coverage_fout, "3381\n");
    fflush(_coverage_fout);
    written += tmp___29;
    fprintf(_coverage_fout, "3382\n");
    fflush(_coverage_fout);
    if ((int )t2p->tiff_transferfunctioncount != 0) {
      fprintf(_coverage_fout, "3207\n");
      fflush(_coverage_fout);
      tmp___30 = t2p->pdf_xrefcount;
      fprintf(_coverage_fout, "3208\n");
      fflush(_coverage_fout);
      (t2p->pdf_xrefcount) ++;
      fprintf(_coverage_fout, "3209\n");
      fflush(_coverage_fout);
      *(t2p->pdf_xrefoffsets + tmp___30) = (unsigned int )written;
      fprintf(_coverage_fout, "3210\n");
      fflush(_coverage_fout);
      tmp___31 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
      fprintf(_coverage_fout, "3211\n");
      fflush(_coverage_fout);
      written += tmp___31;
      fprintf(_coverage_fout, "3212\n");
      fflush(_coverage_fout);
      tmp___32 = t2p_write_pdf_transfer(t2p, output);
      fprintf(_coverage_fout, "3213\n");
      fflush(_coverage_fout);
      written += tmp___32;
      fprintf(_coverage_fout, "3214\n");
      fflush(_coverage_fout);
      tmp___33 = t2p_write_pdf_obj_end(output);
      fprintf(_coverage_fout, "3215\n");
      fflush(_coverage_fout);
      written += tmp___33;
      fprintf(_coverage_fout, "3216\n");
      fflush(_coverage_fout);
      i = (unsigned short)0;
      fprintf(_coverage_fout, "3217\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "3184\n");
        fflush(_coverage_fout);
        if ((int )i < (int )t2p->tiff_transferfunctioncount) {
          fprintf(_coverage_fout, "3183\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "3185\n");
        fflush(_coverage_fout);
        tmp___34 = t2p->pdf_xrefcount;
        fprintf(_coverage_fout, "3186\n");
        fflush(_coverage_fout);
        (t2p->pdf_xrefcount) ++;
        fprintf(_coverage_fout, "3187\n");
        fflush(_coverage_fout);
        *(t2p->pdf_xrefoffsets + tmp___34) = (unsigned int )written;
        fprintf(_coverage_fout, "3188\n");
        fflush(_coverage_fout);
        tmp___35 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
        fprintf(_coverage_fout, "3189\n");
        fflush(_coverage_fout);
        written += tmp___35;
        fprintf(_coverage_fout, "3190\n");
        fflush(_coverage_fout);
        tmp___36 = t2p_write_pdf_stream_dict_start(output);
        fprintf(_coverage_fout, "3191\n");
        fflush(_coverage_fout);
        written += tmp___36;
        fprintf(_coverage_fout, "3192\n");
        fflush(_coverage_fout);
        tmp___37 = t2p_write_pdf_transfer_dict(t2p, output, i);
        fprintf(_coverage_fout, "3193\n");
        fflush(_coverage_fout);
        written += tmp___37;
        fprintf(_coverage_fout, "3194\n");
        fflush(_coverage_fout);
        tmp___38 = t2p_write_pdf_stream_dict_end(output);
        fprintf(_coverage_fout, "3195\n");
        fflush(_coverage_fout);
        written += tmp___38;
        fprintf(_coverage_fout, "3196\n");
        fflush(_coverage_fout);
        tmp___39 = t2p_write_pdf_stream_start(output);
        fprintf(_coverage_fout, "3197\n");
        fflush(_coverage_fout);
        written += tmp___39;
        fprintf(_coverage_fout, "3198\n");
        fflush(_coverage_fout);
        streamlen = written;
        fprintf(_coverage_fout, "3199\n");
        fflush(_coverage_fout);
        tmp___40 = t2p_write_pdf_transfer_stream(t2p, output, i);
        fprintf(_coverage_fout, "3200\n");
        fflush(_coverage_fout);
        written += tmp___40;
        fprintf(_coverage_fout, "3201\n");
        fflush(_coverage_fout);
        streamlen = written - streamlen;
        fprintf(_coverage_fout, "3202\n");
        fflush(_coverage_fout);
        tmp___41 = t2p_write_pdf_stream_end(output);
        fprintf(_coverage_fout, "3203\n");
        fflush(_coverage_fout);
        written += tmp___41;
        fprintf(_coverage_fout, "3204\n");
        fflush(_coverage_fout);
        tmp___42 = t2p_write_pdf_obj_end(output);
        fprintf(_coverage_fout, "3205\n");
        fflush(_coverage_fout);
        written += tmp___42;
        fprintf(_coverage_fout, "3206\n");
        fflush(_coverage_fout);
        i = (uint16 )((int )i + 1);
      }
    } else {
      fprintf(_coverage_fout, "3218\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3383\n");
    fflush(_coverage_fout);
    if (((unsigned int )t2p->pdf_colorspace & 4096U) != 0U) {
      fprintf(_coverage_fout, "3219\n");
      fflush(_coverage_fout);
      tmp___43 = t2p->pdf_xrefcount;
      fprintf(_coverage_fout, "3220\n");
      fflush(_coverage_fout);
      (t2p->pdf_xrefcount) ++;
      fprintf(_coverage_fout, "3221\n");
      fflush(_coverage_fout);
      *(t2p->pdf_xrefoffsets + tmp___43) = (unsigned int )written;
      fprintf(_coverage_fout, "3222\n");
      fflush(_coverage_fout);
      t2p->pdf_palettecs = t2p->pdf_xrefcount;
      fprintf(_coverage_fout, "3223\n");
      fflush(_coverage_fout);
      tmp___44 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
      fprintf(_coverage_fout, "3224\n");
      fflush(_coverage_fout);
      written += tmp___44;
      fprintf(_coverage_fout, "3225\n");
      fflush(_coverage_fout);
      tmp___45 = t2p_write_pdf_stream_dict_start(output);
      fprintf(_coverage_fout, "3226\n");
      fflush(_coverage_fout);
      written += tmp___45;
      fprintf(_coverage_fout, "3227\n");
      fflush(_coverage_fout);
      tmp___46 = t2p_write_pdf_stream_dict((long )t2p->pdf_palettesize, 0U,
                                           output);
      fprintf(_coverage_fout, "3228\n");
      fflush(_coverage_fout);
      written += tmp___46;
      fprintf(_coverage_fout, "3229\n");
      fflush(_coverage_fout);
      tmp___47 = t2p_write_pdf_stream_dict_end(output);
      fprintf(_coverage_fout, "3230\n");
      fflush(_coverage_fout);
      written += tmp___47;
      fprintf(_coverage_fout, "3231\n");
      fflush(_coverage_fout);
      tmp___48 = t2p_write_pdf_stream_start(output);
      fprintf(_coverage_fout, "3232\n");
      fflush(_coverage_fout);
      written += tmp___48;
      fprintf(_coverage_fout, "3233\n");
      fflush(_coverage_fout);
      streamlen = written;
      fprintf(_coverage_fout, "3234\n");
      fflush(_coverage_fout);
      tmp___49 = t2p_write_pdf_xobject_palettecs_stream(t2p, output);
      fprintf(_coverage_fout, "3235\n");
      fflush(_coverage_fout);
      written += tmp___49;
      fprintf(_coverage_fout, "3236\n");
      fflush(_coverage_fout);
      streamlen = written - streamlen;
      fprintf(_coverage_fout, "3237\n");
      fflush(_coverage_fout);
      tmp___50 = t2p_write_pdf_stream_end(output);
      fprintf(_coverage_fout, "3238\n");
      fflush(_coverage_fout);
      written += tmp___50;
      fprintf(_coverage_fout, "3239\n");
      fflush(_coverage_fout);
      tmp___51 = t2p_write_pdf_obj_end(output);
      fprintf(_coverage_fout, "3240\n");
      fflush(_coverage_fout);
      written += tmp___51;
    } else {
      fprintf(_coverage_fout, "3241\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3384\n");
    fflush(_coverage_fout);
    if (((unsigned int )t2p->pdf_colorspace & 128U) != 0U) {
      fprintf(_coverage_fout, "3242\n");
      fflush(_coverage_fout);
      tmp___52 = t2p->pdf_xrefcount;
      fprintf(_coverage_fout, "3243\n");
      fflush(_coverage_fout);
      (t2p->pdf_xrefcount) ++;
      fprintf(_coverage_fout, "3244\n");
      fflush(_coverage_fout);
      *(t2p->pdf_xrefoffsets + tmp___52) = (unsigned int )written;
      fprintf(_coverage_fout, "3245\n");
      fflush(_coverage_fout);
      t2p->pdf_icccs = t2p->pdf_xrefcount;
      fprintf(_coverage_fout, "3246\n");
      fflush(_coverage_fout);
      tmp___53 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
      fprintf(_coverage_fout, "3247\n");
      fflush(_coverage_fout);
      written += tmp___53;
      fprintf(_coverage_fout, "3248\n");
      fflush(_coverage_fout);
      tmp___54 = t2p_write_pdf_stream_dict_start(output);
      fprintf(_coverage_fout, "3249\n");
      fflush(_coverage_fout);
      written += tmp___54;
      fprintf(_coverage_fout, "3250\n");
      fflush(_coverage_fout);
      tmp___55 = t2p_write_pdf_xobject_icccs_dict(t2p, output);
      fprintf(_coverage_fout, "3251\n");
      fflush(_coverage_fout);
      written += tmp___55;
      fprintf(_coverage_fout, "3252\n");
      fflush(_coverage_fout);
      tmp___56 = t2p_write_pdf_stream_dict_end(output);
      fprintf(_coverage_fout, "3253\n");
      fflush(_coverage_fout);
      written += tmp___56;
      fprintf(_coverage_fout, "3254\n");
      fflush(_coverage_fout);
      tmp___57 = t2p_write_pdf_stream_start(output);
      fprintf(_coverage_fout, "3255\n");
      fflush(_coverage_fout);
      written += tmp___57;
      fprintf(_coverage_fout, "3256\n");
      fflush(_coverage_fout);
      streamlen = written;
      fprintf(_coverage_fout, "3257\n");
      fflush(_coverage_fout);
      tmp___58 = t2p_write_pdf_xobject_icccs_stream(t2p, output);
      fprintf(_coverage_fout, "3258\n");
      fflush(_coverage_fout);
      written += tmp___58;
      fprintf(_coverage_fout, "3259\n");
      fflush(_coverage_fout);
      streamlen = written - streamlen;
      fprintf(_coverage_fout, "3260\n");
      fflush(_coverage_fout);
      tmp___59 = t2p_write_pdf_stream_end(output);
      fprintf(_coverage_fout, "3261\n");
      fflush(_coverage_fout);
      written += tmp___59;
      fprintf(_coverage_fout, "3262\n");
      fflush(_coverage_fout);
      tmp___60 = t2p_write_pdf_obj_end(output);
      fprintf(_coverage_fout, "3263\n");
      fflush(_coverage_fout);
      written += tmp___60;
    } else {
      fprintf(_coverage_fout, "3264\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3385\n");
    fflush(_coverage_fout);
    if ((t2p->tiff_tiles + t2p->pdf_page)->tiles_tilecount != 0U) {
      fprintf(_coverage_fout, "3303\n");
      fflush(_coverage_fout);
      i2 = 0U;
      fprintf(_coverage_fout, "3304\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "3268\n");
        fflush(_coverage_fout);
        if (i2 < (t2p->tiff_tiles + t2p->pdf_page)->tiles_tilecount) {
          fprintf(_coverage_fout, "3265\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "3269\n");
        fflush(_coverage_fout);
        tmp___61 = t2p->pdf_xrefcount;
        fprintf(_coverage_fout, "3270\n");
        fflush(_coverage_fout);
        (t2p->pdf_xrefcount) ++;
        fprintf(_coverage_fout, "3271\n");
        fflush(_coverage_fout);
        *(t2p->pdf_xrefoffsets + tmp___61) = (unsigned int )written;
        fprintf(_coverage_fout, "3272\n");
        fflush(_coverage_fout);
        tmp___62 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
        fprintf(_coverage_fout, "3273\n");
        fflush(_coverage_fout);
        written += tmp___62;
        fprintf(_coverage_fout, "3274\n");
        fflush(_coverage_fout);
        tmp___63 = t2p_write_pdf_stream_dict_start(output);
        fprintf(_coverage_fout, "3275\n");
        fflush(_coverage_fout);
        written += tmp___63;
        fprintf(_coverage_fout, "3276\n");
        fflush(_coverage_fout);
        tmp___64 = t2p_write_pdf_xobject_stream_dict(i2 + 1U, t2p, output);
        fprintf(_coverage_fout, "3277\n");
        fflush(_coverage_fout);
        written += tmp___64;
        fprintf(_coverage_fout, "3278\n");
        fflush(_coverage_fout);
        tmp___65 = t2p_write_pdf_stream_dict_end(output);
        fprintf(_coverage_fout, "3279\n");
        fflush(_coverage_fout);
        written += tmp___65;
        fprintf(_coverage_fout, "3280\n");
        fflush(_coverage_fout);
        tmp___66 = t2p_write_pdf_stream_start(output);
        fprintf(_coverage_fout, "3281\n");
        fflush(_coverage_fout);
        written += tmp___66;
        fprintf(_coverage_fout, "3282\n");
        fflush(_coverage_fout);
        streamlen = written;
        fprintf(_coverage_fout, "3283\n");
        fflush(_coverage_fout);
        t2p_read_tiff_size_tile(t2p, input, i2);
        fprintf(_coverage_fout, "3284\n");
        fflush(_coverage_fout);
        tmp___67 = t2p_readwrite_pdf_image_tile(t2p, input, output, i2);
        fprintf(_coverage_fout, "3285\n");
        fflush(_coverage_fout);
        written += tmp___67;
        fprintf(_coverage_fout, "3286\n");
        fflush(_coverage_fout);
        t2p_write_advance_directory(t2p, output);
        fprintf(_coverage_fout, "3287\n");
        fflush(_coverage_fout);
        if ((unsigned int )t2p->t2p_error != 0U) {
          fprintf(_coverage_fout, "3266\n");
          fflush(_coverage_fout);
          return (0L);
        } else {
          fprintf(_coverage_fout, "3267\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "3288\n");
        fflush(_coverage_fout);
        streamlen = written - streamlen;
        fprintf(_coverage_fout, "3289\n");
        fflush(_coverage_fout);
        tmp___68 = t2p_write_pdf_stream_end(output);
        fprintf(_coverage_fout, "3290\n");
        fflush(_coverage_fout);
        written += tmp___68;
        fprintf(_coverage_fout, "3291\n");
        fflush(_coverage_fout);
        tmp___69 = t2p_write_pdf_obj_end(output);
        fprintf(_coverage_fout, "3292\n");
        fflush(_coverage_fout);
        written += tmp___69;
        fprintf(_coverage_fout, "3293\n");
        fflush(_coverage_fout);
        tmp___70 = t2p->pdf_xrefcount;
        fprintf(_coverage_fout, "3294\n");
        fflush(_coverage_fout);
        (t2p->pdf_xrefcount) ++;
        fprintf(_coverage_fout, "3295\n");
        fflush(_coverage_fout);
        *(t2p->pdf_xrefoffsets + tmp___70) = (unsigned int )written;
        fprintf(_coverage_fout, "3296\n");
        fflush(_coverage_fout);
        tmp___71 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
        fprintf(_coverage_fout, "3297\n");
        fflush(_coverage_fout);
        written += tmp___71;
        fprintf(_coverage_fout, "3298\n");
        fflush(_coverage_fout);
        tmp___72 = t2p_write_pdf_stream_length(streamlen, output);
        fprintf(_coverage_fout, "3299\n");
        fflush(_coverage_fout);
        written += tmp___72;
        fprintf(_coverage_fout, "3300\n");
        fflush(_coverage_fout);
        tmp___73 = t2p_write_pdf_obj_end(output);
        fprintf(_coverage_fout, "3301\n");
        fflush(_coverage_fout);
        written += tmp___73;
        fprintf(_coverage_fout, "3302\n");
        fflush(_coverage_fout);
        i2 ++;
      }
    } else {
      fprintf(_coverage_fout, "3307\n");
      fflush(_coverage_fout);
      tmp___74 = t2p->pdf_xrefcount;
      fprintf(_coverage_fout, "3308\n");
      fflush(_coverage_fout);
      (t2p->pdf_xrefcount) ++;
      fprintf(_coverage_fout, "3309\n");
      fflush(_coverage_fout);
      *(t2p->pdf_xrefoffsets + tmp___74) = (unsigned int )written;
      fprintf(_coverage_fout, "3310\n");
      fflush(_coverage_fout);
      tmp___75 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
      fprintf(_coverage_fout, "3311\n");
      fflush(_coverage_fout);
      written += tmp___75;
      fprintf(_coverage_fout, "3312\n");
      fflush(_coverage_fout);
      tmp___76 = t2p_write_pdf_stream_dict_start(output);
      fprintf(_coverage_fout, "3313\n");
      fflush(_coverage_fout);
      written += tmp___76;
      fprintf(_coverage_fout, "3314\n");
      fflush(_coverage_fout);
      tmp___77 = t2p_write_pdf_xobject_stream_dict(0U, t2p, output);
      fprintf(_coverage_fout, "3315\n");
      fflush(_coverage_fout);
      written += tmp___77;
      fprintf(_coverage_fout, "3316\n");
      fflush(_coverage_fout);
      tmp___78 = t2p_write_pdf_stream_dict_end(output);
      fprintf(_coverage_fout, "3317\n");
      fflush(_coverage_fout);
      written += tmp___78;
      fprintf(_coverage_fout, "3318\n");
      fflush(_coverage_fout);
      tmp___79 = t2p_write_pdf_stream_start(output);
      fprintf(_coverage_fout, "3319\n");
      fflush(_coverage_fout);
      written += tmp___79;
      fprintf(_coverage_fout, "3320\n");
      fflush(_coverage_fout);
      streamlen = written;
      fprintf(_coverage_fout, "3321\n");
      fflush(_coverage_fout);
      t2p_read_tiff_size(t2p, input);
      fprintf(_coverage_fout, "3322\n");
      fflush(_coverage_fout);
      tmp___80 = t2p_readwrite_pdf_image(t2p, input, output);
      fprintf(_coverage_fout, "3323\n");
      fflush(_coverage_fout);
      written += tmp___80;
      fprintf(_coverage_fout, "3324\n");
      fflush(_coverage_fout);
      t2p_write_advance_directory(t2p, output);
      fprintf(_coverage_fout, "3325\n");
      fflush(_coverage_fout);
      if ((unsigned int )t2p->t2p_error != 0U) {
        fprintf(_coverage_fout, "3305\n");
        fflush(_coverage_fout);
        return (0L);
      } else {
        fprintf(_coverage_fout, "3306\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "3326\n");
      fflush(_coverage_fout);
      streamlen = written - streamlen;
      fprintf(_coverage_fout, "3327\n");
      fflush(_coverage_fout);
      tmp___81 = t2p_write_pdf_stream_end(output);
      fprintf(_coverage_fout, "3328\n");
      fflush(_coverage_fout);
      written += tmp___81;
      fprintf(_coverage_fout, "3329\n");
      fflush(_coverage_fout);
      tmp___82 = t2p_write_pdf_obj_end(output);
      fprintf(_coverage_fout, "3330\n");
      fflush(_coverage_fout);
      written += tmp___82;
      fprintf(_coverage_fout, "3331\n");
      fflush(_coverage_fout);
      tmp___83 = t2p->pdf_xrefcount;
      fprintf(_coverage_fout, "3332\n");
      fflush(_coverage_fout);
      (t2p->pdf_xrefcount) ++;
      fprintf(_coverage_fout, "3333\n");
      fflush(_coverage_fout);
      *(t2p->pdf_xrefoffsets + tmp___83) = (unsigned int )written;
      fprintf(_coverage_fout, "3334\n");
      fflush(_coverage_fout);
      tmp___84 = t2p_write_pdf_obj_start(t2p->pdf_xrefcount, output);
      fprintf(_coverage_fout, "3335\n");
      fflush(_coverage_fout);
      written += tmp___84;
      fprintf(_coverage_fout, "3336\n");
      fflush(_coverage_fout);
      tmp___85 = t2p_write_pdf_stream_length(streamlen, output);
      fprintf(_coverage_fout, "3337\n");
      fflush(_coverage_fout);
      written += tmp___85;
      fprintf(_coverage_fout, "3338\n");
      fflush(_coverage_fout);
      tmp___86 = t2p_write_pdf_obj_end(output);
      fprintf(_coverage_fout, "3339\n");
      fflush(_coverage_fout);
      written += tmp___86;
    }
    fprintf(_coverage_fout, "3386\n");
    fflush(_coverage_fout);
    t2p->pdf_page = (tdir_t )((int )t2p->pdf_page + 1);
  }
  fprintf(_coverage_fout, "3434\n");
  fflush(_coverage_fout);
  t2p->pdf_startxref = (unsigned int )written;
  fprintf(_coverage_fout, "3435\n");
  fflush(_coverage_fout);
  tmp___87 = t2p_write_pdf_xreftable(t2p, output);
  fprintf(_coverage_fout, "3436\n");
  fflush(_coverage_fout);
  written += tmp___87;
  fprintf(_coverage_fout, "3437\n");
  fflush(_coverage_fout);
  tmp___88 = t2p_write_pdf_trailer(t2p, output);
  fprintf(_coverage_fout, "3438\n");
  fflush(_coverage_fout);
  written += tmp___88;
  fprintf(_coverage_fout, "3439\n");
  fflush(_coverage_fout);
  t2p_disable(output);
  fprintf(_coverage_fout, "3440\n");
  fflush(_coverage_fout);
  return (written);
}
}
