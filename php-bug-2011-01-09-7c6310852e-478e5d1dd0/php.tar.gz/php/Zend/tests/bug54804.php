<?php
namespace a;
require __DIR__ . '/bug54804.inc';
echo 'DONE';
__halt_compiler();
?>
