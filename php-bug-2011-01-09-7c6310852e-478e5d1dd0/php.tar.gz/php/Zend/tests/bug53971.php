<?php
$s = "";
var_dump(isset($s[0][0]));
?>
