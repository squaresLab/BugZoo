<?php
phpinfo(INFO_MODULES);
?>
===DONE===
