typedef unsigned char UChar;
typedef signed char Char;
typedef char HChar;
typedef unsigned short UShort;
typedef short Short;
typedef unsigned int UInt;
typedef int Int;
typedef unsigned long long ULong;
typedef long long Long;
typedef UInt U128[4];
union __anonunion_V128_1 {
   UChar w8[16] ;
   UShort w16[8] ;
   UInt w32[4] ;
   ULong w64[2] ;
};
typedef union __anonunion_V128_1 V128;
typedef float Float;
typedef double Double;
typedef unsigned char Bool;
typedef UInt Addr32;
typedef ULong Addr64;
typedef unsigned long HWord;
typedef __builtin_va_list __gnuc_va_list;
typedef __gnuc_va_list va_list;
typedef unsigned long UWord;
typedef long Word;
typedef UWord Addr;
typedef UWord AddrH;
typedef UWord SizeT;
typedef Word SSizeT;
typedef Word PtrdiffT;
typedef Word OffT;
typedef Long Off64T;
struct __anonstruct_UWordPair_2 {
   UWord uw1 ;
   UWord uw2 ;
};
typedef struct __anonstruct_UWordPair_2 UWordPair;
typedef UInt ThreadId;
struct __anonstruct_SysRes_3 {
   UWord _val ;
   Bool _isError ;
};
typedef struct __anonstruct_SysRes_3 SysRes;
typedef UInt DrdThreadId;
struct __anonstruct_OrigFn_4 {
   unsigned int nraddr ;
};
typedef struct __anonstruct_OrigFn_4 OrigFn;
enum __anonenum_Vg_ClientRequest_5 {
    VG_USERREQ__RUNNING_ON_VALGRIND = 4097,
    VG_USERREQ__DISCARD_TRANSLATIONS = 4098,
    VG_USERREQ__CLIENT_CALL0 = 4353,
    VG_USERREQ__CLIENT_CALL1 = 4354,
    VG_USERREQ__CLIENT_CALL2 = 4355,
    VG_USERREQ__CLIENT_CALL3 = 4356,
    VG_USERREQ__COUNT_ERRORS = 4609,
    VG_USERREQ__MALLOCLIKE_BLOCK = 4865,
    VG_USERREQ__FREELIKE_BLOCK = 4866,
    VG_USERREQ__CREATE_MEMPOOL = 4867,
    VG_USERREQ__DESTROY_MEMPOOL = 4868,
    VG_USERREQ__MEMPOOL_ALLOC = 4869,
    VG_USERREQ__MEMPOOL_FREE = 4870,
    VG_USERREQ__MEMPOOL_TRIM = 4871,
    VG_USERREQ__MOVE_MEMPOOL = 4872,
    VG_USERREQ__MEMPOOL_CHANGE = 4873,
    VG_USERREQ__MEMPOOL_EXISTS = 4874,
    VG_USERREQ__PRINTF = 5121,
    VG_USERREQ__PRINTF_BACKTRACE = 5122,
    VG_USERREQ__PRINTF_VALIST_BY_REF = 5123,
    VG_USERREQ__PRINTF_BACKTRACE_VALIST_BY_REF = 5124,
    VG_USERREQ__STACK_REGISTER = 5377,
    VG_USERREQ__STACK_DEREGISTER = 5378,
    VG_USERREQ__STACK_CHANGE = 5379,
    VG_USERREQ__LOAD_PDB_DEBUGINFO = 5633,
    VG_USERREQ__MAP_IP_TO_SRCLOC = 5889
} ;
typedef enum __anonenum_Vg_ClientRequest_5 Vg_ClientRequest;
enum __anonenum_6 {
    VG_USERREQ__DRD_CLEAN_MEMORY = 1212612608,
    VG_USERREQ__DRD_GET_VALGRIND_THREAD_ID = 1146224640,
    VG_USERREQ__DRD_GET_DRD_THREAD_ID = 1146224641,
    VG_USERREQ__DRD_START_SUPPRESSION = 1146224642,
    VG_USERREQ__DRD_FINISH_SUPPRESSION = 1146224643,
    VG_USERREQ__DRD_START_TRACE_ADDR = 1146224644,
    VG_USERREQ__DRD_STOP_TRACE_ADDR = 1146224645,
    VG_USERREQ__DRD_RECORD_LOADS = 1146224646,
    VG_USERREQ__DRD_RECORD_STORES = 1146224647,
    VG_USERREQ__DRD_SET_THREAD_NAME = 1146224648,
    VG_USERREQ__DRD_ANNOTATION_UNIMP = 1146224649,
    VG_USERREQ__DRD_ANNOTATE_RWLOCK_CREATE = 1212612878,
    VG_USERREQ__DRD_ANNOTATE_RWLOCK_DESTROY = 1212612879,
    VG_USERREQ__DRD_ANNOTATE_RWLOCK_ACQUIRED = 1212612881,
    VG_USERREQ__DRD_ANNOTATE_RWLOCK_RELEASED = 1212612882,
    VG_USERREQ__HELGRIND_ANNOTATION_UNIMP = 1212612896,
    VG_USERREQ__DRD_ANNOTATE_HAPPENS_BEFORE = 1212612897,
    VG_USERREQ__DRD_ANNOTATE_HAPPENS_AFTER = 1212612898
} ;
enum __anonenum_7 {
    VG_USERREQ__SET_PTHREAD_COND_INITIALIZER = 1148321792,
    VG_USERREQ__DRD_START_NEW_SEGMENT = 1148321793,
    VG_USERREQ__SET_PTHREADID = 1148321794,
    VG_USERREQ__SET_JOINABLE = 1148321795,
    VG_USERREQ__ENTERING_PTHREAD_CREATE = 1148321796,
    VG_USERREQ__LEFT_PTHREAD_CREATE = 1148321797,
    VG_USERREQ__POST_THREAD_JOIN = 1148321798,
    VG_USERREQ__PRE_THREAD_CANCEL = 1148321799,
    VG_USERREQ__POST_THREAD_CANCEL = 1148321800,
    VG_USERREQ__PRE_MUTEX_INIT = 1148321801,
    VG_USERREQ__POST_MUTEX_INIT = 1148321802,
    VG_USERREQ__PRE_MUTEX_DESTROY = 1148321803,
    VG_USERREQ__POST_MUTEX_DESTROY = 1148321804,
    VG_USERREQ__PRE_MUTEX_LOCK = 1148321805,
    VG_USERREQ__POST_MUTEX_LOCK = 1148321806,
    VG_USERREQ__PRE_MUTEX_UNLOCK = 1148321807,
    VG_USERREQ__POST_MUTEX_UNLOCK = 1148321808,
    VG_USERREQ__PRE_SPIN_INIT_OR_UNLOCK = 1148321809,
    VG_USERREQ__POST_SPIN_INIT_OR_UNLOCK = 1148321810,
    VG_USERREQ__PRE_COND_INIT = 1148321811,
    VG_USERREQ__POST_COND_INIT = 1148321812,
    VG_USERREQ__PRE_COND_DESTROY = 1148321813,
    VG_USERREQ__POST_COND_DESTROY = 1148321814,
    VG_USERREQ__PRE_COND_WAIT = 1148321815,
    VG_USERREQ__POST_COND_WAIT = 1148321816,
    VG_USERREQ__PRE_COND_SIGNAL = 1148321817,
    VG_USERREQ__POST_COND_SIGNAL = 1148321818,
    VG_USERREQ__PRE_COND_BROADCAST = 1148321819,
    VG_USERREQ__POST_COND_BROADCAST = 1148321820,
    VG_USERREQ__PRE_SEM_INIT = 1148321821,
    VG_USERREQ__POST_SEM_INIT = 1148321822,
    VG_USERREQ__PRE_SEM_DESTROY = 1148321823,
    VG_USERREQ__POST_SEM_DESTROY = 1148321824,
    VG_USERREQ__PRE_SEM_OPEN = 1148321825,
    VG_USERREQ__POST_SEM_OPEN = 1148321826,
    VG_USERREQ__PRE_SEM_CLOSE = 1148321827,
    VG_USERREQ__POST_SEM_CLOSE = 1148321828,
    VG_USERREQ__PRE_SEM_WAIT = 1148321829,
    VG_USERREQ__POST_SEM_WAIT = 1148321830,
    VG_USERREQ__PRE_SEM_POST = 1148321831,
    VG_USERREQ__POST_SEM_POST = 1148321832,
    VG_USERREQ__PRE_BARRIER_INIT = 1148321833,
    VG_USERREQ__POST_BARRIER_INIT = 1148321834,
    VG_USERREQ__PRE_BARRIER_DESTROY = 1148321835,
    VG_USERREQ__POST_BARRIER_DESTROY = 1148321836,
    VG_USERREQ__PRE_BARRIER_WAIT = 1148321837,
    VG_USERREQ__POST_BARRIER_WAIT = 1148321838,
    VG_USERREQ__PRE_RWLOCK_INIT = 1148321839,
    VG_USERREQ__POST_RWLOCK_DESTROY = 1148321840,
    VG_USERREQ__PRE_RWLOCK_RDLOCK = 1148321841,
    VG_USERREQ__POST_RWLOCK_RDLOCK = 1148321842,
    VG_USERREQ__PRE_RWLOCK_WRLOCK = 1148321843,
    VG_USERREQ__POST_RWLOCK_WRLOCK = 1148321844,
    VG_USERREQ__PRE_RWLOCK_UNLOCK = 1148321845,
    VG_USERREQ__POST_RWLOCK_UNLOCK = 1148321846
} ;
enum __anonenum_MutexT_8 {
    mutex_type_unknown = -1,
    mutex_type_invalid_mutex = 0,
    mutex_type_recursive_mutex = 1,
    mutex_type_errorcheck_mutex = 2,
    mutex_type_default_mutex = 3,
    mutex_type_spinlock = 4
} ;
typedef enum __anonenum_MutexT_8 MutexT;
enum __anonenum_RwLockT_9 {
    pthread_rwlock = 1,
    user_rwlock = 2
} ;
typedef enum __anonenum_RwLockT_9 RwLockT;
enum __anonenum_BarrierT_10 {
    pthread_barrier = 1,
    gomp_barrier = 2
} ;
typedef enum __anonenum_BarrierT_10 BarrierT;
struct barrier_info;
struct barrier_info;
struct __anonstruct_VCElem_11 {
   DrdThreadId threadid ;
   UInt count ;
};
typedef struct __anonstruct_VCElem_11 VCElem;
struct __anonstruct_VectorClock_12 {
   unsigned int capacity ;
   unsigned int size ;
   VCElem *vc ;
   VCElem preallocated[8] ;
};
typedef struct __anonstruct_VectorClock_12 VectorClock;
struct _OSet;
typedef struct _OSet OSet;
typedef Word (*OSetCmp_t)(void const   *key , void const   *elem );
typedef void *(*OSetAlloc_t)(HChar *cc , SizeT szB );
typedef void (*OSetFree_t)(void *p );
struct bitmap;
struct bitmap;
enum __anonenum_BmAccessTypeT_13 {
    eLoad = 0,
    eStore = 1,
    eStart = 2,
    eEnd = 3
} ;
typedef enum __anonenum_BmAccessTypeT_13 BmAccessTypeT;
struct bitmap2;
struct bm_cache_elem {
   Addr a1 ;
   struct bitmap2 *bm2 ;
};
struct bitmap {
   struct bm_cache_elem cache[4] ;
   OSet *oset ;
};
struct _ExeContext;
typedef struct _ExeContext ExeContext;
enum __anonenum_VgRes_14 {
    Vg_LowRes = 0,
    Vg_MedRes = 1,
    Vg_HighRes = 2
} ;
typedef enum __anonenum_VgRes_14 VgRes;
typedef Addr *StackTrace;
struct segment {
   struct segment *next ;
   struct segment *prev ;
   DrdThreadId tid ;
   int refcnt ;
   ExeContext *stacktrace ;
   VectorClock vc ;
   struct bitmap bm ;
};
typedef struct segment Segment;
typedef UWord PThreadId;
struct __anonstruct_ThreadInfo_15 {
   Segment *first ;
   Segment *last ;
   ThreadId vg_threadid ;
   PThreadId pt_threadid ;
   Addr stack_min_min ;
   Addr stack_min ;
   Addr stack_startup ;
   Addr stack_max ;
   SizeT stack_size ;
   char name[64] ;
   Bool on_alt_stack ;
   Bool vg_thread_exists ;
   Bool posix_thread_exists ;
   Bool detached_posix_thread ;
   Bool is_recording_loads ;
   Bool is_recording_stores ;
   Int pthread_create_nesting_level ;
   Int synchr_nesting ;
};
typedef struct __anonstruct_ThreadInfo_15 ThreadInfo;
struct cond_info;
struct cond_info;
enum __anonenum_Vg_FnNameKind_16 {
    Vg_FnNameNormal = 0,
    Vg_FnNameMain = 1,
    Vg_FnNameBelowMain = 2
} ;
typedef enum __anonenum_Vg_FnNameKind_16 Vg_FnNameKind;
struct __anonstruct_StackBlock_17 {
   PtrdiffT base ;
   SizeT szB ;
   Bool spRel ;
   Bool isVec ;
   HChar name[16] ;
};
typedef struct __anonstruct_StackBlock_17 StackBlock;
struct __anonstruct_GlobalBlock_18 {
   Addr addr ;
   SizeT szB ;
   Bool isVec ;
   HChar name[16] ;
   HChar soname[16] ;
};
typedef struct __anonstruct_GlobalBlock_18 GlobalBlock;
struct _DebugInfo;
typedef struct _DebugInfo DebugInfo;
enum __anonenum_VgSectKind_19 {
    Vg_SectUnknown = 0,
    Vg_SectText = 1,
    Vg_SectData = 2,
    Vg_SectBSS = 3,
    Vg_SectGOT = 4,
    Vg_SectPLT = 5,
    Vg_SectGOTPLT = 6,
    Vg_SectOPD = 7
} ;
typedef enum __anonenum_VgSectKind_19 VgSectKind;
typedef Int ErrorKind;
struct _Error;
typedef struct _Error Error;
typedef Int SuppKind;
struct _Supp;
typedef struct _Supp Supp;
enum __anonenum_DrdErrorKind_20 {
    DataRaceErr = 1,
    MutexErr = 2,
    CondErr = 3,
    CondDestrErr = 4,
    CondRaceErr = 5,
    CondWaitErr = 6,
    SemaphoreErr = 7,
    BarrierErr = 8,
    RwlockErr = 9,
    HoldtimeErr = 10,
    GenericErr = 11,
    InvalidThreadId = 12,
    UnimpHgClReq = 13,
    UnimpDrdClReq = 14
} ;
typedef enum __anonenum_DrdErrorKind_20 DrdErrorKind;
enum __anonenum_AddrKind_21 {
    eStack = 0,
    eUnknown = 1,
    eMallocd = 2,
    eSegment = 3
} ;
typedef enum __anonenum_AddrKind_21 AddrKind;
struct __anonstruct_AddrInfo_22 {
   AddrKind akind ;
   SizeT size ;
   PtrdiffT rwoffset ;
   ExeContext *lastchange ;
   DrdThreadId stack_tid ;
   DebugInfo *debuginfo ;
   Char name[256] ;
   Char descr[256] ;
};
typedef struct __anonstruct_AddrInfo_22 AddrInfo;
struct __anonstruct_DataRaceErrInfo_23 {
   DrdThreadId tid ;
   Addr addr ;
   SizeT size ;
   BmAccessTypeT access_type ;
};
typedef struct __anonstruct_DataRaceErrInfo_23 DataRaceErrInfo;
struct __anonstruct_MutexErrInfo_24 {
   DrdThreadId tid ;
   Addr mutex ;
   Int recursion_count ;
   DrdThreadId owner ;
};
typedef struct __anonstruct_MutexErrInfo_24 MutexErrInfo;
struct __anonstruct_CondErrInfo_25 {
   DrdThreadId tid ;
   Addr cond ;
};
typedef struct __anonstruct_CondErrInfo_25 CondErrInfo;
struct __anonstruct_CondDestrErrInfo_26 {
   DrdThreadId tid ;
   Addr cond ;
   Addr mutex ;
   DrdThreadId owner ;
};
typedef struct __anonstruct_CondDestrErrInfo_26 CondDestrErrInfo;
struct __anonstruct_CondRaceErrInfo_27 {
   DrdThreadId tid ;
   Addr cond ;
   Addr mutex ;
};
typedef struct __anonstruct_CondRaceErrInfo_27 CondRaceErrInfo;
struct __anonstruct_CondWaitErrInfo_28 {
   DrdThreadId tid ;
   Addr cond ;
   Addr mutex1 ;
   Addr mutex2 ;
};
typedef struct __anonstruct_CondWaitErrInfo_28 CondWaitErrInfo;
struct __anonstruct_SemaphoreErrInfo_29 {
   DrdThreadId tid ;
   Addr semaphore ;
};
typedef struct __anonstruct_SemaphoreErrInfo_29 SemaphoreErrInfo;
struct __anonstruct_BarrierErrInfo_30 {
   DrdThreadId tid ;
   Addr barrier ;
   DrdThreadId other_tid ;
   ExeContext *other_context ;
};
typedef struct __anonstruct_BarrierErrInfo_30 BarrierErrInfo;
struct __anonstruct_RwlockErrInfo_31 {
   DrdThreadId tid ;
   Addr rwlock ;
};
typedef struct __anonstruct_RwlockErrInfo_31 RwlockErrInfo;
struct __anonstruct_HoldtimeErrInfo_32 {
   DrdThreadId tid ;
   Addr synchronization_object ;
   ExeContext *acquired_at ;
   UInt hold_time_ms ;
   UInt threshold_ms ;
};
typedef struct __anonstruct_HoldtimeErrInfo_32 HoldtimeErrInfo;
struct __anonstruct_GenericErrInfo_33 {
   DrdThreadId tid ;
   Addr addr ;
};
typedef struct __anonstruct_GenericErrInfo_33 GenericErrInfo;
struct __anonstruct_InvalidThreadIdInfo_34 {
   DrdThreadId tid ;
   ULong ptid ;
};
typedef struct __anonstruct_InvalidThreadIdInfo_34 InvalidThreadIdInfo;
struct __anonstruct_UnimpClReqInfo_35 {
   DrdThreadId tid ;
   Char *descr ;
};
typedef struct __anonstruct_UnimpClReqInfo_35 UnimpClReqInfo;
struct hb_info;
struct hb_info;
enum __anonenum_IRType_36 {
    Ity_INVALID = 69632,
    Ity_I1 = 69633,
    Ity_I8 = 69634,
    Ity_I16 = 69635,
    Ity_I32 = 69636,
    Ity_I64 = 69637,
    Ity_I128 = 69638,
    Ity_F32 = 69639,
    Ity_F64 = 69640,
    Ity_F128 = 69641,
    Ity_V128 = 69642
} ;
typedef enum __anonenum_IRType_36 IRType;
enum __anonenum_IREndness_37 {
    Iend_LE = 73728,
    Iend_BE = 73729
} ;
typedef enum __anonenum_IREndness_37 IREndness;
enum __anonenum_IRConstTag_38 {
    Ico_U1 = 77824,
    Ico_U8 = 77825,
    Ico_U16 = 77826,
    Ico_U32 = 77827,
    Ico_U64 = 77828,
    Ico_F32 = 77829,
    Ico_F32i = 77830,
    Ico_F64 = 77831,
    Ico_F64i = 77832,
    Ico_V128 = 77833
} ;
typedef enum __anonenum_IRConstTag_38 IRConstTag;
union __anonunion_Ico_39 {
   Bool U1 ;
   UChar U8 ;
   UShort U16 ;
   UInt U32 ;
   ULong U64 ;
   Float F32 ;
   UInt F32i ;
   Double F64 ;
   ULong F64i ;
   UShort V128 ;
};
struct _IRConst {
   IRConstTag tag ;
   union __anonunion_Ico_39 Ico ;
};
typedef struct _IRConst IRConst;
struct __anonstruct_IRCallee_40 {
   Int regparms ;
   HChar *name ;
   void *addr ;
   UInt mcx_mask ;
};
typedef struct __anonstruct_IRCallee_40 IRCallee;
struct __anonstruct_IRRegArray_41 {
   Int base ;
   IRType elemTy ;
   Int nElems ;
};
typedef struct __anonstruct_IRRegArray_41 IRRegArray;
typedef UInt IRTemp;
enum __anonenum_IROp_42 {
    Iop_INVALID = 81920,
    Iop_Add8 = 81921,
    Iop_Add16 = 81922,
    Iop_Add32 = 81923,
    Iop_Add64 = 81924,
    Iop_Sub8 = 81925,
    Iop_Sub16 = 81926,
    Iop_Sub32 = 81927,
    Iop_Sub64 = 81928,
    Iop_Mul8 = 81929,
    Iop_Mul16 = 81930,
    Iop_Mul32 = 81931,
    Iop_Mul64 = 81932,
    Iop_Or8 = 81933,
    Iop_Or16 = 81934,
    Iop_Or32 = 81935,
    Iop_Or64 = 81936,
    Iop_And8 = 81937,
    Iop_And16 = 81938,
    Iop_And32 = 81939,
    Iop_And64 = 81940,
    Iop_Xor8 = 81941,
    Iop_Xor16 = 81942,
    Iop_Xor32 = 81943,
    Iop_Xor64 = 81944,
    Iop_Shl8 = 81945,
    Iop_Shl16 = 81946,
    Iop_Shl32 = 81947,
    Iop_Shl64 = 81948,
    Iop_Shr8 = 81949,
    Iop_Shr16 = 81950,
    Iop_Shr32 = 81951,
    Iop_Shr64 = 81952,
    Iop_Sar8 = 81953,
    Iop_Sar16 = 81954,
    Iop_Sar32 = 81955,
    Iop_Sar64 = 81956,
    Iop_CmpEQ8 = 81957,
    Iop_CmpEQ16 = 81958,
    Iop_CmpEQ32 = 81959,
    Iop_CmpEQ64 = 81960,
    Iop_CmpNE8 = 81961,
    Iop_CmpNE16 = 81962,
    Iop_CmpNE32 = 81963,
    Iop_CmpNE64 = 81964,
    Iop_Not8 = 81965,
    Iop_Not16 = 81966,
    Iop_Not32 = 81967,
    Iop_Not64 = 81968,
    Iop_CasCmpEQ8 = 81969,
    Iop_CasCmpEQ16 = 81970,
    Iop_CasCmpEQ32 = 81971,
    Iop_CasCmpEQ64 = 81972,
    Iop_CasCmpNE8 = 81973,
    Iop_CasCmpNE16 = 81974,
    Iop_CasCmpNE32 = 81975,
    Iop_CasCmpNE64 = 81976,
    Iop_MullS8 = 81977,
    Iop_MullS16 = 81978,
    Iop_MullS32 = 81979,
    Iop_MullS64 = 81980,
    Iop_MullU8 = 81981,
    Iop_MullU16 = 81982,
    Iop_MullU32 = 81983,
    Iop_MullU64 = 81984,
    Iop_Clz64 = 81985,
    Iop_Clz32 = 81986,
    Iop_Ctz64 = 81987,
    Iop_Ctz32 = 81988,
    Iop_CmpLT32S = 81989,
    Iop_CmpLT64S = 81990,
    Iop_CmpLE32S = 81991,
    Iop_CmpLE64S = 81992,
    Iop_CmpLT32U = 81993,
    Iop_CmpLT64U = 81994,
    Iop_CmpLE32U = 81995,
    Iop_CmpLE64U = 81996,
    Iop_CmpNEZ8 = 81997,
    Iop_CmpNEZ16 = 81998,
    Iop_CmpNEZ32 = 81999,
    Iop_CmpNEZ64 = 82000,
    Iop_CmpwNEZ32 = 82001,
    Iop_CmpwNEZ64 = 82002,
    Iop_Left8 = 82003,
    Iop_Left16 = 82004,
    Iop_Left32 = 82005,
    Iop_Left64 = 82006,
    Iop_Max32U = 82007,
    Iop_CmpORD32U = 82008,
    Iop_CmpORD64U = 82009,
    Iop_CmpORD32S = 82010,
    Iop_CmpORD64S = 82011,
    Iop_DivU32 = 82012,
    Iop_DivS32 = 82013,
    Iop_DivU64 = 82014,
    Iop_DivS64 = 82015,
    Iop_DivModU64to32 = 82016,
    Iop_DivModS64to32 = 82017,
    Iop_DivModU128to64 = 82018,
    Iop_DivModS128to64 = 82019,
    Iop_DivModS64to64 = 82020,
    Iop_8Uto16 = 82021,
    Iop_8Uto32 = 82022,
    Iop_8Uto64 = 82023,
    Iop_16Uto32 = 82024,
    Iop_16Uto64 = 82025,
    Iop_32Uto64 = 82026,
    Iop_8Sto16 = 82027,
    Iop_8Sto32 = 82028,
    Iop_8Sto64 = 82029,
    Iop_16Sto32 = 82030,
    Iop_16Sto64 = 82031,
    Iop_32Sto64 = 82032,
    Iop_64to8 = 82033,
    Iop_32to8 = 82034,
    Iop_64to16 = 82035,
    Iop_16to8 = 82036,
    Iop_16HIto8 = 82037,
    Iop_8HLto16 = 82038,
    Iop_32to16 = 82039,
    Iop_32HIto16 = 82040,
    Iop_16HLto32 = 82041,
    Iop_64to32 = 82042,
    Iop_64HIto32 = 82043,
    Iop_32HLto64 = 82044,
    Iop_128to64 = 82045,
    Iop_128HIto64 = 82046,
    Iop_64HLto128 = 82047,
    Iop_Not1 = 82048,
    Iop_32to1 = 82049,
    Iop_64to1 = 82050,
    Iop_1Uto8 = 82051,
    Iop_1Uto32 = 82052,
    Iop_1Uto64 = 82053,
    Iop_1Sto8 = 82054,
    Iop_1Sto16 = 82055,
    Iop_1Sto32 = 82056,
    Iop_1Sto64 = 82057,
    Iop_AddF64 = 82058,
    Iop_SubF64 = 82059,
    Iop_MulF64 = 82060,
    Iop_DivF64 = 82061,
    Iop_AddF32 = 82062,
    Iop_SubF32 = 82063,
    Iop_MulF32 = 82064,
    Iop_DivF32 = 82065,
    Iop_AddF64r32 = 82066,
    Iop_SubF64r32 = 82067,
    Iop_MulF64r32 = 82068,
    Iop_DivF64r32 = 82069,
    Iop_NegF64 = 82070,
    Iop_AbsF64 = 82071,
    Iop_NegF32 = 82072,
    Iop_AbsF32 = 82073,
    Iop_SqrtF64 = 82074,
    Iop_SqrtF64r32 = 82075,
    Iop_SqrtF32 = 82076,
    Iop_CmpF64 = 82077,
    Iop_CmpF32 = 82078,
    Iop_CmpF128 = 82079,
    Iop_F64toI16S = 82080,
    Iop_F64toI32S = 82081,
    Iop_F64toI64S = 82082,
    Iop_F64toI32U = 82083,
    Iop_I16StoF64 = 82084,
    Iop_I32StoF64 = 82085,
    Iop_I64StoF64 = 82086,
    Iop_I32UtoF64 = 82087,
    Iop_F32toI16S = 82088,
    Iop_F32toI32S = 82089,
    Iop_F32toI64S = 82090,
    Iop_I16StoF32 = 82091,
    Iop_I32StoF32 = 82092,
    Iop_I64StoF32 = 82093,
    Iop_F32toF64 = 82094,
    Iop_F64toF32 = 82095,
    Iop_ReinterpF64asI64 = 82096,
    Iop_ReinterpI64asF64 = 82097,
    Iop_ReinterpF32asI32 = 82098,
    Iop_ReinterpI32asF32 = 82099,
    Iop_F64HLtoF128 = 82100,
    Iop_F128HItoF64 = 82101,
    Iop_F128LOtoF64 = 82102,
    Iop_AddF128 = 82103,
    Iop_SubF128 = 82104,
    Iop_MulF128 = 82105,
    Iop_DivF128 = 82106,
    Iop_NegF128 = 82107,
    Iop_AbsF128 = 82108,
    Iop_SqrtF128 = 82109,
    Iop_I32StoF128 = 82110,
    Iop_I64StoF128 = 82111,
    Iop_F32toF128 = 82112,
    Iop_F64toF128 = 82113,
    Iop_F128toI32S = 82114,
    Iop_F128toI64S = 82115,
    Iop_F128toF64 = 82116,
    Iop_F128toF32 = 82117,
    Iop_AtanF64 = 82118,
    Iop_Yl2xF64 = 82119,
    Iop_Yl2xp1F64 = 82120,
    Iop_PRemF64 = 82121,
    Iop_PRemC3210F64 = 82122,
    Iop_PRem1F64 = 82123,
    Iop_PRem1C3210F64 = 82124,
    Iop_ScaleF64 = 82125,
    Iop_SinF64 = 82126,
    Iop_CosF64 = 82127,
    Iop_TanF64 = 82128,
    Iop_2xm1F64 = 82129,
    Iop_RoundF64toInt = 82130,
    Iop_RoundF32toInt = 82131,
    Iop_MAddF32 = 82132,
    Iop_MSubF32 = 82133,
    Iop_MAddF64 = 82134,
    Iop_MSubF64 = 82135,
    Iop_MAddF64r32 = 82136,
    Iop_MSubF64r32 = 82137,
    Iop_Est5FRSqrt = 82138,
    Iop_RoundF64toF64_NEAREST = 82139,
    Iop_RoundF64toF64_NegINF = 82140,
    Iop_RoundF64toF64_PosINF = 82141,
    Iop_RoundF64toF64_ZERO = 82142,
    Iop_TruncF64asF32 = 82143,
    Iop_RoundF64toF32 = 82144,
    Iop_CalcFPRF = 82145,
    Iop_Add16x2 = 82146,
    Iop_Sub16x2 = 82147,
    Iop_QAdd16Sx2 = 82148,
    Iop_QAdd16Ux2 = 82149,
    Iop_QSub16Sx2 = 82150,
    Iop_QSub16Ux2 = 82151,
    Iop_HAdd16Ux2 = 82152,
    Iop_HAdd16Sx2 = 82153,
    Iop_HSub16Ux2 = 82154,
    Iop_HSub16Sx2 = 82155,
    Iop_Add8x4 = 82156,
    Iop_Sub8x4 = 82157,
    Iop_QAdd8Sx4 = 82158,
    Iop_QAdd8Ux4 = 82159,
    Iop_QSub8Sx4 = 82160,
    Iop_QSub8Ux4 = 82161,
    Iop_HAdd8Ux4 = 82162,
    Iop_HAdd8Sx4 = 82163,
    Iop_HSub8Ux4 = 82164,
    Iop_HSub8Sx4 = 82165,
    Iop_Sad8Ux4 = 82166,
    Iop_CmpNEZ16x2 = 82167,
    Iop_CmpNEZ8x4 = 82168,
    Iop_I32UtoFx2 = 82169,
    Iop_I32StoFx2 = 82170,
    Iop_FtoI32Ux2_RZ = 82171,
    Iop_FtoI32Sx2_RZ = 82172,
    Iop_F32ToFixed32Ux2_RZ = 82173,
    Iop_F32ToFixed32Sx2_RZ = 82174,
    Iop_Fixed32UToF32x2_RN = 82175,
    Iop_Fixed32SToF32x2_RN = 82176,
    Iop_Max32Fx2 = 82177,
    Iop_Min32Fx2 = 82178,
    Iop_PwMax32Fx2 = 82179,
    Iop_PwMin32Fx2 = 82180,
    Iop_CmpEQ32Fx2 = 82181,
    Iop_CmpGT32Fx2 = 82182,
    Iop_CmpGE32Fx2 = 82183,
    Iop_Recip32Fx2 = 82184,
    Iop_Recps32Fx2 = 82185,
    Iop_Rsqrte32Fx2 = 82186,
    Iop_Rsqrts32Fx2 = 82187,
    Iop_Neg32Fx2 = 82188,
    Iop_Abs32Fx2 = 82189,
    Iop_CmpNEZ8x8 = 82190,
    Iop_CmpNEZ16x4 = 82191,
    Iop_CmpNEZ32x2 = 82192,
    Iop_Add8x8 = 82193,
    Iop_Add16x4 = 82194,
    Iop_Add32x2 = 82195,
    Iop_QAdd8Ux8 = 82196,
    Iop_QAdd16Ux4 = 82197,
    Iop_QAdd32Ux2 = 82198,
    Iop_QAdd64Ux1 = 82199,
    Iop_QAdd8Sx8 = 82200,
    Iop_QAdd16Sx4 = 82201,
    Iop_QAdd32Sx2 = 82202,
    Iop_QAdd64Sx1 = 82203,
    Iop_PwAdd8x8 = 82204,
    Iop_PwAdd16x4 = 82205,
    Iop_PwAdd32x2 = 82206,
    Iop_PwMax8Sx8 = 82207,
    Iop_PwMax16Sx4 = 82208,
    Iop_PwMax32Sx2 = 82209,
    Iop_PwMax8Ux8 = 82210,
    Iop_PwMax16Ux4 = 82211,
    Iop_PwMax32Ux2 = 82212,
    Iop_PwMin8Sx8 = 82213,
    Iop_PwMin16Sx4 = 82214,
    Iop_PwMin32Sx2 = 82215,
    Iop_PwMin8Ux8 = 82216,
    Iop_PwMin16Ux4 = 82217,
    Iop_PwMin32Ux2 = 82218,
    Iop_PwAddL8Ux8 = 82219,
    Iop_PwAddL16Ux4 = 82220,
    Iop_PwAddL32Ux2 = 82221,
    Iop_PwAddL8Sx8 = 82222,
    Iop_PwAddL16Sx4 = 82223,
    Iop_PwAddL32Sx2 = 82224,
    Iop_Sub8x8 = 82225,
    Iop_Sub16x4 = 82226,
    Iop_Sub32x2 = 82227,
    Iop_QSub8Ux8 = 82228,
    Iop_QSub16Ux4 = 82229,
    Iop_QSub32Ux2 = 82230,
    Iop_QSub64Ux1 = 82231,
    Iop_QSub8Sx8 = 82232,
    Iop_QSub16Sx4 = 82233,
    Iop_QSub32Sx2 = 82234,
    Iop_QSub64Sx1 = 82235,
    Iop_Abs8x8 = 82236,
    Iop_Abs16x4 = 82237,
    Iop_Abs32x2 = 82238,
    Iop_Mul8x8 = 82239,
    Iop_Mul16x4 = 82240,
    Iop_Mul32x2 = 82241,
    Iop_Mul32Fx2 = 82242,
    Iop_MulHi16Ux4 = 82243,
    Iop_MulHi16Sx4 = 82244,
    Iop_PolynomialMul8x8 = 82245,
    Iop_QDMulHi16Sx4 = 82246,
    Iop_QDMulHi32Sx2 = 82247,
    Iop_QRDMulHi16Sx4 = 82248,
    Iop_QRDMulHi32Sx2 = 82249,
    Iop_Avg8Ux8 = 82250,
    Iop_Avg16Ux4 = 82251,
    Iop_Max8Sx8 = 82252,
    Iop_Max16Sx4 = 82253,
    Iop_Max32Sx2 = 82254,
    Iop_Max8Ux8 = 82255,
    Iop_Max16Ux4 = 82256,
    Iop_Max32Ux2 = 82257,
    Iop_Min8Sx8 = 82258,
    Iop_Min16Sx4 = 82259,
    Iop_Min32Sx2 = 82260,
    Iop_Min8Ux8 = 82261,
    Iop_Min16Ux4 = 82262,
    Iop_Min32Ux2 = 82263,
    Iop_CmpEQ8x8 = 82264,
    Iop_CmpEQ16x4 = 82265,
    Iop_CmpEQ32x2 = 82266,
    Iop_CmpGT8Ux8 = 82267,
    Iop_CmpGT16Ux4 = 82268,
    Iop_CmpGT32Ux2 = 82269,
    Iop_CmpGT8Sx8 = 82270,
    Iop_CmpGT16Sx4 = 82271,
    Iop_CmpGT32Sx2 = 82272,
    Iop_Cnt8x8 = 82273,
    Iop_Clz8Sx8 = 82274,
    Iop_Clz16Sx4 = 82275,
    Iop_Clz32Sx2 = 82276,
    Iop_Cls8Sx8 = 82277,
    Iop_Cls16Sx4 = 82278,
    Iop_Cls32Sx2 = 82279,
    Iop_Shl8x8 = 82280,
    Iop_Shl16x4 = 82281,
    Iop_Shl32x2 = 82282,
    Iop_Shr8x8 = 82283,
    Iop_Shr16x4 = 82284,
    Iop_Shr32x2 = 82285,
    Iop_Sar8x8 = 82286,
    Iop_Sar16x4 = 82287,
    Iop_Sar32x2 = 82288,
    Iop_Sal8x8 = 82289,
    Iop_Sal16x4 = 82290,
    Iop_Sal32x2 = 82291,
    Iop_Sal64x1 = 82292,
    Iop_ShlN8x8 = 82293,
    Iop_ShlN16x4 = 82294,
    Iop_ShlN32x2 = 82295,
    Iop_ShrN8x8 = 82296,
    Iop_ShrN16x4 = 82297,
    Iop_ShrN32x2 = 82298,
    Iop_SarN8x8 = 82299,
    Iop_SarN16x4 = 82300,
    Iop_SarN32x2 = 82301,
    Iop_QShl8x8 = 82302,
    Iop_QShl16x4 = 82303,
    Iop_QShl32x2 = 82304,
    Iop_QShl64x1 = 82305,
    Iop_QSal8x8 = 82306,
    Iop_QSal16x4 = 82307,
    Iop_QSal32x2 = 82308,
    Iop_QSal64x1 = 82309,
    Iop_QShlN8Sx8 = 82310,
    Iop_QShlN16Sx4 = 82311,
    Iop_QShlN32Sx2 = 82312,
    Iop_QShlN64Sx1 = 82313,
    Iop_QShlN8x8 = 82314,
    Iop_QShlN16x4 = 82315,
    Iop_QShlN32x2 = 82316,
    Iop_QShlN64x1 = 82317,
    Iop_QSalN8x8 = 82318,
    Iop_QSalN16x4 = 82319,
    Iop_QSalN32x2 = 82320,
    Iop_QSalN64x1 = 82321,
    Iop_QNarrow16Ux4 = 82322,
    Iop_QNarrow16Sx4 = 82323,
    Iop_QNarrow32Sx2 = 82324,
    Iop_InterleaveHI8x8 = 82325,
    Iop_InterleaveHI16x4 = 82326,
    Iop_InterleaveHI32x2 = 82327,
    Iop_InterleaveLO8x8 = 82328,
    Iop_InterleaveLO16x4 = 82329,
    Iop_InterleaveLO32x2 = 82330,
    Iop_InterleaveOddLanes8x8 = 82331,
    Iop_InterleaveEvenLanes8x8 = 82332,
    Iop_InterleaveOddLanes16x4 = 82333,
    Iop_InterleaveEvenLanes16x4 = 82334,
    Iop_CatOddLanes8x8 = 82335,
    Iop_CatOddLanes16x4 = 82336,
    Iop_CatEvenLanes8x8 = 82337,
    Iop_CatEvenLanes16x4 = 82338,
    Iop_GetElem8x8 = 82339,
    Iop_GetElem16x4 = 82340,
    Iop_GetElem32x2 = 82341,
    Iop_SetElem8x8 = 82342,
    Iop_SetElem16x4 = 82343,
    Iop_SetElem32x2 = 82344,
    Iop_Dup8x8 = 82345,
    Iop_Dup16x4 = 82346,
    Iop_Dup32x2 = 82347,
    Iop_Extract64 = 82348,
    Iop_Reverse16_8x8 = 82349,
    Iop_Reverse32_8x8 = 82350,
    Iop_Reverse32_16x4 = 82351,
    Iop_Reverse64_8x8 = 82352,
    Iop_Reverse64_16x4 = 82353,
    Iop_Reverse64_32x2 = 82354,
    Iop_Perm8x8 = 82355,
    Iop_Recip32x2 = 82356,
    Iop_Rsqrte32x2 = 82357,
    Iop_Add32Fx4 = 82358,
    Iop_Sub32Fx4 = 82359,
    Iop_Mul32Fx4 = 82360,
    Iop_Div32Fx4 = 82361,
    Iop_Max32Fx4 = 82362,
    Iop_Min32Fx4 = 82363,
    Iop_Add32Fx2 = 82364,
    Iop_Sub32Fx2 = 82365,
    Iop_CmpEQ32Fx4 = 82366,
    Iop_CmpLT32Fx4 = 82367,
    Iop_CmpLE32Fx4 = 82368,
    Iop_CmpUN32Fx4 = 82369,
    Iop_CmpGT32Fx4 = 82370,
    Iop_CmpGE32Fx4 = 82371,
    Iop_Abs32Fx4 = 82372,
    Iop_PwMax32Fx4 = 82373,
    Iop_PwMin32Fx4 = 82374,
    Iop_Sqrt32Fx4 = 82375,
    Iop_RSqrt32Fx4 = 82376,
    Iop_Neg32Fx4 = 82377,
    Iop_Recip32Fx4 = 82378,
    Iop_Recps32Fx4 = 82379,
    Iop_Rsqrte32Fx4 = 82380,
    Iop_Rsqrts32Fx4 = 82381,
    Iop_I32UtoFx4 = 82382,
    Iop_I32StoFx4 = 82383,
    Iop_FtoI32Ux4_RZ = 82384,
    Iop_FtoI32Sx4_RZ = 82385,
    Iop_QFtoI32Ux4_RZ = 82386,
    Iop_QFtoI32Sx4_RZ = 82387,
    Iop_RoundF32x4_RM = 82388,
    Iop_RoundF32x4_RP = 82389,
    Iop_RoundF32x4_RN = 82390,
    Iop_RoundF32x4_RZ = 82391,
    Iop_F32ToFixed32Ux4_RZ = 82392,
    Iop_F32ToFixed32Sx4_RZ = 82393,
    Iop_Fixed32UToF32x4_RN = 82394,
    Iop_Fixed32SToF32x4_RN = 82395,
    Iop_F32toF16x4 = 82396,
    Iop_F16toF32x4 = 82397,
    Iop_Add32F0x4 = 82398,
    Iop_Sub32F0x4 = 82399,
    Iop_Mul32F0x4 = 82400,
    Iop_Div32F0x4 = 82401,
    Iop_Max32F0x4 = 82402,
    Iop_Min32F0x4 = 82403,
    Iop_CmpEQ32F0x4 = 82404,
    Iop_CmpLT32F0x4 = 82405,
    Iop_CmpLE32F0x4 = 82406,
    Iop_CmpUN32F0x4 = 82407,
    Iop_Recip32F0x4 = 82408,
    Iop_Sqrt32F0x4 = 82409,
    Iop_RSqrt32F0x4 = 82410,
    Iop_Add64Fx2 = 82411,
    Iop_Sub64Fx2 = 82412,
    Iop_Mul64Fx2 = 82413,
    Iop_Div64Fx2 = 82414,
    Iop_Max64Fx2 = 82415,
    Iop_Min64Fx2 = 82416,
    Iop_CmpEQ64Fx2 = 82417,
    Iop_CmpLT64Fx2 = 82418,
    Iop_CmpLE64Fx2 = 82419,
    Iop_CmpUN64Fx2 = 82420,
    Iop_Recip64Fx2 = 82421,
    Iop_Sqrt64Fx2 = 82422,
    Iop_RSqrt64Fx2 = 82423,
    Iop_Add64F0x2 = 82424,
    Iop_Sub64F0x2 = 82425,
    Iop_Mul64F0x2 = 82426,
    Iop_Div64F0x2 = 82427,
    Iop_Max64F0x2 = 82428,
    Iop_Min64F0x2 = 82429,
    Iop_CmpEQ64F0x2 = 82430,
    Iop_CmpLT64F0x2 = 82431,
    Iop_CmpLE64F0x2 = 82432,
    Iop_CmpUN64F0x2 = 82433,
    Iop_Recip64F0x2 = 82434,
    Iop_Sqrt64F0x2 = 82435,
    Iop_RSqrt64F0x2 = 82436,
    Iop_V128to64 = 82437,
    Iop_V128HIto64 = 82438,
    Iop_64HLtoV128 = 82439,
    Iop_64UtoV128 = 82440,
    Iop_SetV128lo64 = 82441,
    Iop_32UtoV128 = 82442,
    Iop_V128to32 = 82443,
    Iop_SetV128lo32 = 82444,
    Iop_NotV128 = 82445,
    Iop_AndV128 = 82446,
    Iop_OrV128 = 82447,
    Iop_XorV128 = 82448,
    Iop_ShlV128 = 82449,
    Iop_ShrV128 = 82450,
    Iop_CmpNEZ8x16 = 82451,
    Iop_CmpNEZ16x8 = 82452,
    Iop_CmpNEZ32x4 = 82453,
    Iop_CmpNEZ64x2 = 82454,
    Iop_Add8x16 = 82455,
    Iop_Add16x8 = 82456,
    Iop_Add32x4 = 82457,
    Iop_Add64x2 = 82458,
    Iop_QAdd8Ux16 = 82459,
    Iop_QAdd16Ux8 = 82460,
    Iop_QAdd32Ux4 = 82461,
    Iop_QAdd64Ux2 = 82462,
    Iop_QAdd8Sx16 = 82463,
    Iop_QAdd16Sx8 = 82464,
    Iop_QAdd32Sx4 = 82465,
    Iop_QAdd64Sx2 = 82466,
    Iop_Sub8x16 = 82467,
    Iop_Sub16x8 = 82468,
    Iop_Sub32x4 = 82469,
    Iop_Sub64x2 = 82470,
    Iop_QSub8Ux16 = 82471,
    Iop_QSub16Ux8 = 82472,
    Iop_QSub32Ux4 = 82473,
    Iop_QSub64Ux2 = 82474,
    Iop_QSub8Sx16 = 82475,
    Iop_QSub16Sx8 = 82476,
    Iop_QSub32Sx4 = 82477,
    Iop_QSub64Sx2 = 82478,
    Iop_Mul8x16 = 82479,
    Iop_Mul16x8 = 82480,
    Iop_Mul32x4 = 82481,
    Iop_MulHi16Ux8 = 82482,
    Iop_MulHi32Ux4 = 82483,
    Iop_MulHi16Sx8 = 82484,
    Iop_MulHi32Sx4 = 82485,
    Iop_MullEven8Ux16 = 82486,
    Iop_MullEven16Ux8 = 82487,
    Iop_MullEven8Sx16 = 82488,
    Iop_MullEven16Sx8 = 82489,
    Iop_Mull8Ux8 = 82490,
    Iop_Mull8Sx8 = 82491,
    Iop_Mull16Ux4 = 82492,
    Iop_Mull16Sx4 = 82493,
    Iop_Mull32Ux2 = 82494,
    Iop_Mull32Sx2 = 82495,
    Iop_QDMulHi16Sx8 = 82496,
    Iop_QDMulHi32Sx4 = 82497,
    Iop_QRDMulHi16Sx8 = 82498,
    Iop_QRDMulHi32Sx4 = 82499,
    Iop_QDMulLong16Sx4 = 82500,
    Iop_QDMulLong32Sx2 = 82501,
    Iop_PolynomialMul8x16 = 82502,
    Iop_PolynomialMull8x8 = 82503,
    Iop_PwAdd8x16 = 82504,
    Iop_PwAdd16x8 = 82505,
    Iop_PwAdd32x4 = 82506,
    Iop_PwAdd32Fx2 = 82507,
    Iop_PwAddL8Ux16 = 82508,
    Iop_PwAddL16Ux8 = 82509,
    Iop_PwAddL32Ux4 = 82510,
    Iop_PwAddL8Sx16 = 82511,
    Iop_PwAddL16Sx8 = 82512,
    Iop_PwAddL32Sx4 = 82513,
    Iop_Abs8x16 = 82514,
    Iop_Abs16x8 = 82515,
    Iop_Abs32x4 = 82516,
    Iop_Avg8Ux16 = 82517,
    Iop_Avg16Ux8 = 82518,
    Iop_Avg32Ux4 = 82519,
    Iop_Avg8Sx16 = 82520,
    Iop_Avg16Sx8 = 82521,
    Iop_Avg32Sx4 = 82522,
    Iop_Max8Sx16 = 82523,
    Iop_Max16Sx8 = 82524,
    Iop_Max32Sx4 = 82525,
    Iop_Max8Ux16 = 82526,
    Iop_Max16Ux8 = 82527,
    Iop_Max32Ux4 = 82528,
    Iop_Min8Sx16 = 82529,
    Iop_Min16Sx8 = 82530,
    Iop_Min32Sx4 = 82531,
    Iop_Min8Ux16 = 82532,
    Iop_Min16Ux8 = 82533,
    Iop_Min32Ux4 = 82534,
    Iop_CmpEQ8x16 = 82535,
    Iop_CmpEQ16x8 = 82536,
    Iop_CmpEQ32x4 = 82537,
    Iop_CmpGT8Sx16 = 82538,
    Iop_CmpGT16Sx8 = 82539,
    Iop_CmpGT32Sx4 = 82540,
    Iop_CmpGT64Sx2 = 82541,
    Iop_CmpGT8Ux16 = 82542,
    Iop_CmpGT16Ux8 = 82543,
    Iop_CmpGT32Ux4 = 82544,
    Iop_Cnt8x16 = 82545,
    Iop_Clz8Sx16 = 82546,
    Iop_Clz16Sx8 = 82547,
    Iop_Clz32Sx4 = 82548,
    Iop_Cls8Sx16 = 82549,
    Iop_Cls16Sx8 = 82550,
    Iop_Cls32Sx4 = 82551,
    Iop_ShlN8x16 = 82552,
    Iop_ShlN16x8 = 82553,
    Iop_ShlN32x4 = 82554,
    Iop_ShlN64x2 = 82555,
    Iop_ShrN8x16 = 82556,
    Iop_ShrN16x8 = 82557,
    Iop_ShrN32x4 = 82558,
    Iop_ShrN64x2 = 82559,
    Iop_SarN8x16 = 82560,
    Iop_SarN16x8 = 82561,
    Iop_SarN32x4 = 82562,
    Iop_SarN64x2 = 82563,
    Iop_Shl8x16 = 82564,
    Iop_Shl16x8 = 82565,
    Iop_Shl32x4 = 82566,
    Iop_Shl64x2 = 82567,
    Iop_Shr8x16 = 82568,
    Iop_Shr16x8 = 82569,
    Iop_Shr32x4 = 82570,
    Iop_Shr64x2 = 82571,
    Iop_Sar8x16 = 82572,
    Iop_Sar16x8 = 82573,
    Iop_Sar32x4 = 82574,
    Iop_Sar64x2 = 82575,
    Iop_Sal8x16 = 82576,
    Iop_Sal16x8 = 82577,
    Iop_Sal32x4 = 82578,
    Iop_Sal64x2 = 82579,
    Iop_Rol8x16 = 82580,
    Iop_Rol16x8 = 82581,
    Iop_Rol32x4 = 82582,
    Iop_QShl8x16 = 82583,
    Iop_QShl16x8 = 82584,
    Iop_QShl32x4 = 82585,
    Iop_QShl64x2 = 82586,
    Iop_QSal8x16 = 82587,
    Iop_QSal16x8 = 82588,
    Iop_QSal32x4 = 82589,
    Iop_QSal64x2 = 82590,
    Iop_QShlN8Sx16 = 82591,
    Iop_QShlN16Sx8 = 82592,
    Iop_QShlN32Sx4 = 82593,
    Iop_QShlN64Sx2 = 82594,
    Iop_QShlN8x16 = 82595,
    Iop_QShlN16x8 = 82596,
    Iop_QShlN32x4 = 82597,
    Iop_QShlN64x2 = 82598,
    Iop_QSalN8x16 = 82599,
    Iop_QSalN16x8 = 82600,
    Iop_QSalN32x4 = 82601,
    Iop_QSalN64x2 = 82602,
    Iop_QNarrow16Ux8 = 82603,
    Iop_QNarrow32Ux4 = 82604,
    Iop_QNarrow16Sx8 = 82605,
    Iop_QNarrow32Sx4 = 82606,
    Iop_Narrow16x8 = 82607,
    Iop_Narrow32x4 = 82608,
    Iop_Shorten16x8 = 82609,
    Iop_Shorten32x4 = 82610,
    Iop_Shorten64x2 = 82611,
    Iop_QShortenS16Sx8 = 82612,
    Iop_QShortenS32Sx4 = 82613,
    Iop_QShortenS64Sx2 = 82614,
    Iop_QShortenU16Sx8 = 82615,
    Iop_QShortenU32Sx4 = 82616,
    Iop_QShortenU64Sx2 = 82617,
    Iop_QShortenU16Ux8 = 82618,
    Iop_QShortenU32Ux4 = 82619,
    Iop_QShortenU64Ux2 = 82620,
    Iop_Longen8Ux8 = 82621,
    Iop_Longen16Ux4 = 82622,
    Iop_Longen32Ux2 = 82623,
    Iop_Longen8Sx8 = 82624,
    Iop_Longen16Sx4 = 82625,
    Iop_Longen32Sx2 = 82626,
    Iop_InterleaveHI8x16 = 82627,
    Iop_InterleaveHI16x8 = 82628,
    Iop_InterleaveHI32x4 = 82629,
    Iop_InterleaveHI64x2 = 82630,
    Iop_InterleaveLO8x16 = 82631,
    Iop_InterleaveLO16x8 = 82632,
    Iop_InterleaveLO32x4 = 82633,
    Iop_InterleaveLO64x2 = 82634,
    Iop_InterleaveOddLanes8x16 = 82635,
    Iop_InterleaveEvenLanes8x16 = 82636,
    Iop_InterleaveOddLanes16x8 = 82637,
    Iop_InterleaveEvenLanes16x8 = 82638,
    Iop_InterleaveOddLanes32x4 = 82639,
    Iop_InterleaveEvenLanes32x4 = 82640,
    Iop_CatOddLanes8x16 = 82641,
    Iop_CatOddLanes16x8 = 82642,
    Iop_CatOddLanes32x4 = 82643,
    Iop_CatEvenLanes8x16 = 82644,
    Iop_CatEvenLanes16x8 = 82645,
    Iop_CatEvenLanes32x4 = 82646,
    Iop_GetElem8x16 = 82647,
    Iop_GetElem16x8 = 82648,
    Iop_GetElem32x4 = 82649,
    Iop_GetElem64x2 = 82650,
    Iop_Dup8x16 = 82651,
    Iop_Dup16x8 = 82652,
    Iop_Dup32x4 = 82653,
    Iop_ExtractV128 = 82654,
    Iop_Reverse16_8x16 = 82655,
    Iop_Reverse32_8x16 = 82656,
    Iop_Reverse32_16x8 = 82657,
    Iop_Reverse64_8x16 = 82658,
    Iop_Reverse64_16x8 = 82659,
    Iop_Reverse64_32x4 = 82660,
    Iop_Perm8x16 = 82661,
    Iop_Recip32x4 = 82662,
    Iop_Rsqrte32x4 = 82663
} ;
typedef enum __anonenum_IROp_42 IROp;
enum __anonenum_IRRoundingMode_43 {
    Irrm_NEAREST = 0,
    Irrm_NegINF = 1,
    Irrm_PosINF = 2,
    Irrm_ZERO = 3
} ;
typedef enum __anonenum_IRRoundingMode_43 IRRoundingMode;
enum __anonenum_IRCmpF64Result_44 {
    Ircr_UN = 69,
    Ircr_LT = 1,
    Ircr_GT = 0,
    Ircr_EQ = 64
} ;
typedef enum __anonenum_IRCmpF64Result_44 IRCmpF64Result;
typedef IRCmpF64Result IRCmpF32Result;
typedef IRCmpF64Result IRCmpF128Result;
enum __anonenum_IRExprTag_45 {
    Iex_Binder = 86016,
    Iex_Get = 86017,
    Iex_GetI = 86018,
    Iex_RdTmp = 86019,
    Iex_Qop = 86020,
    Iex_Triop = 86021,
    Iex_Binop = 86022,
    Iex_Unop = 86023,
    Iex_Load = 86024,
    Iex_Const = 86025,
    Iex_Mux0X = 86026,
    Iex_CCall = 86027
} ;
typedef enum __anonenum_IRExprTag_45 IRExprTag;
struct _IRExpr;
typedef struct _IRExpr IRExpr;
struct __anonstruct_Binder_47 {
   Int binder ;
};
struct __anonstruct_Get_48 {
   Int offset ;
   IRType ty ;
};
struct __anonstruct_GetI_49 {
   IRRegArray *descr ;
   IRExpr *ix ;
   Int bias ;
};
struct __anonstruct_RdTmp_50 {
   IRTemp tmp ;
};
struct __anonstruct_Qop_51 {
   IROp op ;
   IRExpr *arg1 ;
   IRExpr *arg2 ;
   IRExpr *arg3 ;
   IRExpr *arg4 ;
};
struct __anonstruct_Triop_52 {
   IROp op ;
   IRExpr *arg1 ;
   IRExpr *arg2 ;
   IRExpr *arg3 ;
};
struct __anonstruct_Binop_53 {
   IROp op ;
   IRExpr *arg1 ;
   IRExpr *arg2 ;
};
struct __anonstruct_Unop_54 {
   IROp op ;
   IRExpr *arg ;
};
struct __anonstruct_Load_55 {
   IREndness end ;
   IRType ty ;
   IRExpr *addr ;
};
struct __anonstruct_Const_56 {
   IRConst *con ;
};
struct __anonstruct_CCall_57 {
   IRCallee *cee ;
   IRType retty ;
   IRExpr **args ;
};
struct __anonstruct_Mux0X_58 {
   IRExpr *cond ;
   IRExpr *expr0 ;
   IRExpr *exprX ;
};
union __anonunion_Iex_46 {
   struct __anonstruct_Binder_47 Binder ;
   struct __anonstruct_Get_48 Get ;
   struct __anonstruct_GetI_49 GetI ;
   struct __anonstruct_RdTmp_50 RdTmp ;
   struct __anonstruct_Qop_51 Qop ;
   struct __anonstruct_Triop_52 Triop ;
   struct __anonstruct_Binop_53 Binop ;
   struct __anonstruct_Unop_54 Unop ;
   struct __anonstruct_Load_55 Load ;
   struct __anonstruct_Const_56 Const ;
   struct __anonstruct_CCall_57 CCall ;
   struct __anonstruct_Mux0X_58 Mux0X ;
};
struct _IRExpr {
   IRExprTag tag ;
   union __anonunion_Iex_46 Iex ;
};
enum __anonenum_IRJumpKind_59 {
    Ijk_Boring = 90112,
    Ijk_Call = 90113,
    Ijk_Ret = 90114,
    Ijk_ClientReq = 90115,
    Ijk_Yield = 90116,
    Ijk_EmWarn = 90117,
    Ijk_EmFail = 90118,
    Ijk_NoDecode = 90119,
    Ijk_MapFail = 90120,
    Ijk_TInval = 90121,
    Ijk_NoRedir = 90122,
    Ijk_SigTRAP = 90123,
    Ijk_SigSEGV = 90124,
    Ijk_SigBUS = 90125,
    Ijk_Sys_syscall = 90126,
    Ijk_Sys_int32 = 90127,
    Ijk_Sys_int128 = 90128,
    Ijk_Sys_int129 = 90129,
    Ijk_Sys_int130 = 90130,
    Ijk_Sys_sysenter = 90131
} ;
typedef enum __anonenum_IRJumpKind_59 IRJumpKind;
enum __anonenum_IREffect_60 {
    Ifx_None = 94208,
    Ifx_Read = 94209,
    Ifx_Write = 94210,
    Ifx_Modify = 94211
} ;
typedef enum __anonenum_IREffect_60 IREffect;
struct __anonstruct_fxState_62 {
   IREffect fx ;
   Int offset ;
   Int size ;
};
struct __anonstruct_IRDirty_61 {
   IRCallee *cee ;
   IRExpr *guard ;
   IRExpr **args ;
   IRTemp tmp ;
   IREffect mFx ;
   IRExpr *mAddr ;
   Int mSize ;
   Bool needsBBP ;
   Int nFxState ;
   struct __anonstruct_fxState_62 fxState[7] ;
};
typedef struct __anonstruct_IRDirty_61 IRDirty;
enum __anonenum_IRMBusEvent_63 {
    Imbe_Fence = 98304
} ;
typedef enum __anonenum_IRMBusEvent_63 IRMBusEvent;
struct __anonstruct_IRCAS_64 {
   IRTemp oldHi ;
   IRTemp oldLo ;
   IREndness end ;
   IRExpr *addr ;
   IRExpr *expdHi ;
   IRExpr *expdLo ;
   IRExpr *dataHi ;
   IRExpr *dataLo ;
};
typedef struct __anonstruct_IRCAS_64 IRCAS;
enum __anonenum_IRStmtTag_65 {
    Ist_NoOp = 102400,
    Ist_IMark = 102401,
    Ist_AbiHint = 102402,
    Ist_Put = 102403,
    Ist_PutI = 102404,
    Ist_WrTmp = 102405,
    Ist_Store = 102406,
    Ist_CAS = 102407,
    Ist_LLSC = 102408,
    Ist_Dirty = 102409,
    Ist_MBE = 102410,
    Ist_Exit = 102411
} ;
typedef enum __anonenum_IRStmtTag_65 IRStmtTag;
struct __anonstruct_NoOp_67 {

};
struct __anonstruct_IMark_68 {
   Addr64 addr ;
   Int len ;
};
struct __anonstruct_AbiHint_69 {
   IRExpr *base ;
   Int len ;
   IRExpr *nia ;
};
struct __anonstruct_Put_70 {
   Int offset ;
   IRExpr *data ;
};
struct __anonstruct_PutI_71 {
   IRRegArray *descr ;
   IRExpr *ix ;
   Int bias ;
   IRExpr *data ;
};
struct __anonstruct_WrTmp_72 {
   IRTemp tmp ;
   IRExpr *data ;
};
struct __anonstruct_Store_73 {
   IREndness end ;
   IRExpr *addr ;
   IRExpr *data ;
};
struct __anonstruct_CAS_74 {
   IRCAS *details ;
};
struct __anonstruct_LLSC_75 {
   IREndness end ;
   IRTemp result ;
   IRExpr *addr ;
   IRExpr *storedata ;
};
struct __anonstruct_Dirty_76 {
   IRDirty *details ;
};
struct __anonstruct_MBE_77 {
   IRMBusEvent event ;
};
struct __anonstruct_Exit_78 {
   IRExpr *guard ;
   IRJumpKind jk ;
   IRConst *dst ;
};
union __anonunion_Ist_66 {
   struct __anonstruct_NoOp_67 NoOp ;
   struct __anonstruct_IMark_68 IMark ;
   struct __anonstruct_AbiHint_69 AbiHint ;
   struct __anonstruct_Put_70 Put ;
   struct __anonstruct_PutI_71 PutI ;
   struct __anonstruct_WrTmp_72 WrTmp ;
   struct __anonstruct_Store_73 Store ;
   struct __anonstruct_CAS_74 CAS ;
   struct __anonstruct_LLSC_75 LLSC ;
   struct __anonstruct_Dirty_76 Dirty ;
   struct __anonstruct_MBE_77 MBE ;
   struct __anonstruct_Exit_78 Exit ;
};
struct _IRStmt {
   IRStmtTag tag ;
   union __anonunion_Ist_66 Ist ;
};
typedef struct _IRStmt IRStmt;
struct __anonstruct_IRTypeEnv_79 {
   IRType *types ;
   Int types_size ;
   Int types_used ;
};
typedef struct __anonstruct_IRTypeEnv_79 IRTypeEnv;
struct __anonstruct_IRSB_80 {
   IRTypeEnv *tyenv ;
   IRStmt **stmts ;
   Int stmts_size ;
   Int stmts_used ;
   IRExpr *next ;
   IRJumpKind jumpkind ;
};
typedef struct __anonstruct_IRSB_80 IRSB;
enum __anonenum_VexArch_81 {
    VexArch_INVALID = 0,
    VexArchX86 = 1,
    VexArchAMD64 = 2,
    VexArchARM = 3,
    VexArchPPC32 = 4,
    VexArchPPC64 = 5,
    VexArchS390X = 6
} ;
typedef enum __anonenum_VexArch_81 VexArch;
struct __anonstruct_VexArchInfo_82 {
   UInt hwcaps ;
   Int ppc_cache_line_szB ;
   UInt ppc_dcbz_szB ;
   UInt ppc_dcbzl_szB ;
};
typedef struct __anonstruct_VexArchInfo_82 VexArchInfo;
struct __anonstruct_VexAbiInfo_83 {
   Int guest_stack_redzone_size ;
   Bool guest_amd64_assume_fs_is_zero ;
   Bool guest_amd64_assume_gs_is_0x60 ;
   Bool guest_ppc_zap_RZ_at_blr ;
   Bool (*guest_ppc_zap_RZ_at_bl)(Addr64  ) ;
   Bool guest_ppc_sc_continues_at_LR ;
   Bool host_ppc_calls_use_fndescrs ;
   Bool host_ppc32_regalign_int64_args ;
};
typedef struct __anonstruct_VexAbiInfo_83 VexAbiInfo;
struct __anonstruct_VexControl_84 {
   Int iropt_verbosity ;
   Int iropt_level ;
   Bool iropt_precise_memory_exns ;
   Int iropt_unroll_thresh ;
   Int guest_max_insns ;
   Int guest_chase_thresh ;
   Bool guest_chase_cond ;
};
typedef struct __anonstruct_VexControl_84 VexControl;
struct __anonstruct_alwaysDefd_86 {
   Int offset ;
   Int size ;
};
struct __anonstruct_VexGuestLayout_85 {
   Int total_sizeB ;
   Int offset_SP ;
   Int sizeof_SP ;
   Int offset_FP ;
   Int sizeof_FP ;
   Int offset_IP ;
   Int sizeof_IP ;
   Int n_alwaysDefd ;
   struct __anonstruct_alwaysDefd_86 alwaysDefd[24] ;
};
typedef struct __anonstruct_VexGuestLayout_85 VexGuestLayout;
enum __anonenum_VexTranslateResult_87 {
    VexTransOK = 0,
    VexTransAccessFail = 1,
    VexTransOutputFull = 2
} ;
typedef enum __anonenum_VexTranslateResult_87 VexTranslateResult;
struct __anonstruct_VexGuestExtents_88 {
   Addr64 base[3] ;
   UShort len[3] ;
   UShort n_used ;
};
typedef struct __anonstruct_VexGuestExtents_88 VexGuestExtents;
struct __anonstruct_VexTranslateArgs_89 {
   VexArch arch_guest ;
   VexArchInfo archinfo_guest ;
   VexArch arch_host ;
   VexArchInfo archinfo_host ;
   VexAbiInfo abiinfo_both ;
   void *callback_opaque ;
   UChar *guest_bytes ;
   Addr64 guest_bytes_addr ;
   Bool (*chase_into_ok)(void * , Addr64  ) ;
   VexGuestExtents *guest_extents ;
   UChar *host_bytes ;
   Int host_bytes_size ;
   Int *host_bytes_used ;
   IRSB *(*instrument1)(void * , IRSB * , VexGuestLayout * , VexGuestExtents * , IRType gWordTy , IRType hWordTy ) ;
   IRSB *(*instrument2)(void * , IRSB * , VexGuestLayout * , VexGuestExtents * , IRType gWordTy , IRType hWordTy ) ;
   IRSB *(*finaltidy)(IRSB * ) ;
   Bool do_self_check ;
   Bool (*preamble_function)(void * , IRSB * ) ;
   Int traceflags ;
   void *dispatch ;
};
typedef struct __anonstruct_VexTranslateArgs_89 VexTranslateArgs;
struct __anonstruct_VgCallbackClosure_90 {
   Addr64 nraddr ;
   Addr64 readdr ;
   ThreadId tid ;
};
typedef struct __anonstruct_VgCallbackClosure_90 VgCallbackClosure;
enum __anonenum_CorePart_91 {
    Vg_CoreStartup = 1,
    Vg_CoreSignal = 2,
    Vg_CoreSysCall = 3,
    Vg_CoreSysCallArgInMem = 4,
    Vg_CoreTranslate = 5,
    Vg_CoreClientReq = 6
} ;
typedef enum __anonenum_CorePart_91 CorePart;
typedef void (*StartUsingMem)(Addr a1 , SizeT len , UInt ec_uniq );
typedef void (*StopUsingMem)(Addr a1 , SizeT len );
struct mutex_info;
struct mutex_info;
struct _XArray;
typedef struct _XArray XArray;
union drd_clientobj;
union drd_clientobj;
enum __anonenum_ObjType_92 {
    ClientMutex = 1,
    ClientCondvar = 2,
    ClientHbvar = 3,
    ClientSemaphore = 4,
    ClientBarrier = 5,
    ClientRwlock = 6
} ;
typedef enum __anonenum_ObjType_92 ObjType;
struct any {
   Addr a1 ;
   ObjType type ;
   void (*cleanup)(union drd_clientobj * ) ;
   void (*delete_thread)(union drd_clientobj * , DrdThreadId  ) ;
   ExeContext *first_observed_at ;
};
struct mutex_info {
   Addr a1 ;
   ObjType type ;
   void (*cleanup)(union drd_clientobj * ) ;
   void (*delete_thread)(union drd_clientobj * , DrdThreadId  ) ;
   ExeContext *first_observed_at ;
   MutexT mutex_type ;
   int recursion_count ;
   DrdThreadId owner ;
   struct segment *last_locked_segment ;
   ULong acquiry_time_ms ;
   ExeContext *acquired_at ;
};
struct cond_info {
   Addr a1 ;
   ObjType type ;
   void (*cleanup)(union drd_clientobj * ) ;
   void (*delete_thread)(union drd_clientobj * , DrdThreadId  ) ;
   ExeContext *first_observed_at ;
   int waiter_count ;
   Addr mutex ;
};
struct hb_info {
   Addr a1 ;
   ObjType type ;
   void (*cleanup)(union drd_clientobj * ) ;
   void (*delete_thread)(union drd_clientobj * , DrdThreadId  ) ;
   ExeContext *first_observed_at ;
   OSet *oset ;
};
struct semaphore_info {
   Addr a1 ;
   ObjType type ;
   void (*cleanup)(union drd_clientobj * ) ;
   void (*delete_thread)(union drd_clientobj * , DrdThreadId  ) ;
   ExeContext *first_observed_at ;
   UInt waits_to_skip ;
   UInt value ;
   UWord waiters ;
   DrdThreadId last_sem_post_tid ;
   XArray *last_sem_post_seg ;
};
struct barrier_info {
   Addr a1 ;
   ObjType type ;
   void (*cleanup)(union drd_clientobj * ) ;
   void (*delete_thread)(union drd_clientobj * , DrdThreadId  ) ;
   ExeContext *first_observed_at ;
   BarrierT barrier_type ;
   Word count ;
   Word pre_iteration ;
   Word post_iteration ;
   Word pre_waiters_left ;
   Word post_waiters_left ;
   OSet *oset ;
};
struct rwlock_info {
   Addr a1 ;
   ObjType type ;
   void (*cleanup)(union drd_clientobj * ) ;
   void (*delete_thread)(union drd_clientobj * , DrdThreadId  ) ;
   ExeContext *first_observed_at ;
   RwLockT rwlock_type ;
   OSet *thread_info ;
   ULong acquiry_time_ms ;
   ExeContext *acquired_at ;
};
union drd_clientobj {
   struct any any ;
   struct mutex_info mutex ;
   struct cond_info cond ;
   struct hb_info hb ;
   struct semaphore_info semaphore ;
   struct barrier_info barrier ;
   struct rwlock_info rwlock ;
};
typedef union drd_clientobj DrdClientobj;
struct rwlock_info;
struct semaphore_info;
enum __anonenum_VgMsgKind_93 {
    Vg_FailMsg = 0,
    Vg_UserMsg = 1,
    Vg_DebugMsg = 2,
    Vg_ClientMsg = 3
} ;
typedef enum __anonenum_VgMsgKind_93 VgMsgKind;
__inline static Bool toBool(Int x ) 
{ Int r ;
  int tmp ;

  {
  if (x == 0) {
    tmp = 0;
  } else {
    tmp = 1;
  }
  r = tmp;
  return ((unsigned char )r);
}
}
__inline static UChar toUChar(Int x ) 
{ 

  {
  x &= 0xFF;
  return ((unsigned char )x);
}
}
__inline static HChar toHChar(Int x ) 
{ 

  {
  x &= 0xFF;
  return ((char )x);
}
}
__inline static UShort toUShort(Int x ) 
{ 

  {
  x &= 0xFFFF;
  return ((unsigned short )x);
}
}
__inline static Short toShort(Int x ) 
{ 

  {
  x &= 0xFFFF;
  return ((short )x);
}
}
__inline static UInt toUInt(Long x ) 
{ 

  {
  x &= 0xFFFFFFFFLL;
  return ((unsigned int )x);
}
}
__inline static ULong Ptr_to_ULong(void *p ) 
{ UInt w ;

  {
  w = (unsigned int )p;
  return ((unsigned long long )w);
}
}
__inline static void *ULong_to_Ptr(ULong n ) 
{ UInt w ;

  {
  w = (unsigned int )n;
  return ((void *)w);
}
}
__inline static Bool sr_isError(SysRes sr ) 
{ 

  {
  return (sr._isError);
}
}
__inline static UWord sr_Res(SysRes sr ) 
{ UWord tmp ;

  {
  if (sr._isError) {
    tmp = 0UL;
  } else {
    tmp = sr._val;
  }
  return (tmp);
}
}
__inline static UWord sr_ResHI(SysRes sr ) 
{ 

  {
  return (0UL);
}
}
__inline static UWord sr_Err(SysRes sr ) 
{ UWord tmp ;

  {
  if (sr._isError) {
    tmp = sr._val;
  } else {
    tmp = 0UL;
  }
  return (tmp);
}
}
__inline static Bool sr_EQ(SysRes sr1 , SysRes sr2 ) 
{ int tmp ;

  {
  if (sr1._val == sr2._val) {
    if (sr1._isError) {
      if (sr2._isError) {
        tmp = 1;
      } else {
        goto _L;
      }
    } else {
      _L: /* CIL Label */ 
      if (! sr1._isError) {
        if (! sr2._isError) {
          tmp = 1;
        } else {
          tmp = 0;
        }
      } else {
        tmp = 0;
      }
    }
  } else {
    tmp = 0;
  }
  return ((unsigned char )tmp);
}
}
static int ( /* format attribute */  VALGRIND_PRINTF)(char const   *format  , ...)  __attribute__((__unused__)) ;
static int ( /* format attribute */  VALGRIND_PRINTF)(char const   *format  , ...)  __attribute__((__unused__)) ;
static int ( /* format attribute */  VALGRIND_PRINTF)(char const   *format  , ...) 
{ unsigned long _qzz_res ;
  va_list vargs ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;

  {
  __builtin_va_start(vargs, format);
  _zzq_args[0] = (unsigned int volatile   )5123U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )((unsigned long )format));
  _zzq_args[2] = (unsigned int volatile   )((unsigned int )((unsigned long )(& vargs)));
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (0): "cc", "memory");
  _qzz_res = (unsigned long )_zzq_result;
  __builtin_va_end(vargs);
  return ((int )_qzz_res);
}
}
static int ( /* format attribute */  VALGRIND_PRINTF_BACKTRACE)(char const   *format  , ...)  __attribute__((__unused__)) ;
static int ( /* format attribute */  VALGRIND_PRINTF_BACKTRACE)(char const   *format  , ...)  __attribute__((__unused__)) ;
static int ( /* format attribute */  VALGRIND_PRINTF_BACKTRACE)(char const   *format  , ...) 
{ unsigned long _qzz_res ;
  va_list vargs ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;

  {
  __builtin_va_start(vargs, format);
  _zzq_args[0] = (unsigned int volatile   )5124U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )((unsigned long )format));
  _zzq_args[2] = (unsigned int volatile   )((unsigned int )((unsigned long )(& vargs)));
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (0): "cc", "memory");
  _qzz_res = (unsigned long )_zzq_result;
  __builtin_va_end(vargs);
  return ((int )_qzz_res);
}
}
void vgDrd_clientreq_init(void) ;
extern void vgDrd_barrier_set_trace(Bool trace_barrier ) ;
extern void vgDrd_barrier_init(Addr barrier , BarrierT barrier_type , Word count , Bool reinitialization ) ;
extern void vgDrd_barrier_destroy(Addr barrier , BarrierT barrier_type ) ;
extern void vgDrd_barrier_pre_wait(DrdThreadId tid , Addr barrier , BarrierT barrier_type ) ;
extern void vgDrd_barrier_post_wait(DrdThreadId tid , Addr barrier , BarrierT barrier_type , Bool waited , Bool serializing ) ;
extern void vgDrd_barrier_stop_using_mem(Addr a1 , Addr a2 ) ;
extern ULong vgDrd_get_barrier_segment_creation_count(void) ;
extern  __attribute__((__noreturn__)) void vgPlain_exit(Int status ) ;
extern  __attribute__((__noreturn__)) void vgPlain_tool_panic(Char *str ) ;
extern  __attribute__((__noreturn__)) void vgPlain_assert_fail(Bool isCore , Char const   *expr , Char const   *file , Int line , Char const   *fn , HChar const   *format  , ...) ;
extern void vgDrd_vc_init(VectorClock *vc , VCElem const   *vcelem , unsigned int size ) ;
extern void vgDrd_vc_cleanup(VectorClock *vc ) ;
extern void vgDrd_vc_copy(VectorClock *new , VectorClock const   *rhs ) ;
extern void vgDrd_vc_assign(VectorClock *lhs , VectorClock const   *rhs ) ;
extern void vgDrd_vc_increment(VectorClock *vc , DrdThreadId tid ) ;
__inline static Bool vgDrd_vc_lte(VectorClock const   *vc1 , VectorClock const   *vc2 ) ;
extern Bool vgDrd_vc_ordered(VectorClock const   *vc1 , VectorClock const   *vc2 ) ;
extern void vgDrd_vc_min(VectorClock *result , VectorClock const   *rhs ) ;
extern void vgDrd_vc_combine(VectorClock *result , VectorClock const   *rhs ) ;
extern void vgDrd_vc_print(VectorClock const   *vc ) ;
extern char *vgDrd_vc_aprint(VectorClock const   *vc ) ;
extern void vgDrd_vc_check(VectorClock const   *vc ) ;
extern void vgDrd_vc_test(void) ;
__inline static Bool vgDrd_vc_lte(VectorClock const   *vc1 , VectorClock const   *vc2 ) 
{ unsigned int i ;
  unsigned int j ;

  {
  j = 0U;
  i = 0U;
  while (i < (unsigned int )vc1->size) {
    while (1) {
      if (j < (unsigned int )vc2->size) {
        if ((vc2->vc + j)->threadid < (vc1->vc + i)->threadid) {

        } else {
          break;
        }
      } else {
        break;
      }
      j ++;
    }
    if (j >= (unsigned int )vc2->size) {
      return ((unsigned char)0);
    } else {
      if ((vc2->vc + j)->threadid > (vc1->vc + i)->threadid) {
        return ((unsigned char)0);
      } else {

      }
    }
    if ((vc1->vc + i)->count > (vc2->vc + j)->count) {
      return ((unsigned char)0);
    } else {

    }
    i ++;
  }
  return ((unsigned char)1);
}
}
extern OSet *vgPlain_OSetWord_Create(void *(*alloc)(HChar *cc , SizeT szB ) , HChar *cc , void (*_free)(void *p ) ) ;
extern void vgPlain_OSetWord_Destroy(OSet *os ) ;
extern Word vgPlain_OSetWord_Size(OSet *os ) ;
extern void vgPlain_OSetWord_Insert(OSet *os , UWord val ) ;
extern Bool vgPlain_OSetWord_Contains(OSet *os , UWord val ) ;
extern Bool vgPlain_OSetWord_Remove(OSet *os , UWord val ) ;
extern void vgPlain_OSetWord_ResetIter(OSet *os ) ;
extern Bool vgPlain_OSetWord_Next(OSet *os , UWord *val ) ;
extern OSet *vgPlain_OSetGen_Create(PtrdiffT keyOff , Word (*cmp)(void const   *key , void const   *elem ) , void *(*alloc)(HChar *cc , SizeT szB ) , HChar *cc , void (*_free)(void *p ) ) ;
extern void vgPlain_OSetGen_Destroy(OSet *os ) ;
extern void *vgPlain_OSetGen_AllocNode(OSet *os , SizeT elemSize ) ;
extern void vgPlain_OSetGen_FreeNode(OSet *os , void *elem ) ;
extern Word vgPlain_OSetGen_Size(OSet const   *os ) ;
extern void vgPlain_OSetGen_Insert(OSet *os , void *elem ) ;
extern Bool vgPlain_OSetGen_Contains(OSet const   *os , void const   *key ) ;
extern void *vgPlain_OSetGen_Lookup(OSet const   *os , void const   *key ) ;
extern void *vgPlain_OSetGen_LookupWithCmp(OSet *os , void const   *key , Word (*cmp)(void const   *key , void const   *elem ) ) ;
extern void *vgPlain_OSetGen_Remove(OSet *os , void const   *key ) ;
extern void vgPlain_OSetGen_ResetIter(OSet *os ) ;
extern void vgPlain_OSetGen_ResetIterAt(OSet *os , void const   *key ) ;
extern void *vgPlain_OSetGen_Next(OSet *os ) ;
extern struct bitmap *vgDrd_bm_new(void) ;
extern void vgDrd_bm_delete(struct bitmap *bm ) ;
extern void vgDrd_bm_init(struct bitmap *bm ) ;
extern void vgDrd_bm_cleanup(struct bitmap *bm ) ;
extern void vgDrd_bm_access_range(struct bitmap *bm , Addr a1 , Addr a2 , BmAccessTypeT access_type ) ;
extern void vgDrd_bm_access_range_load(struct bitmap *bm , Addr a1 , Addr a2 ) ;
extern void vgDrd_bm_access_load_1(struct bitmap *bm , Addr a1 ) ;
extern void vgDrd_bm_access_load_2(struct bitmap *bm , Addr a1 ) ;
extern void vgDrd_bm_access_load_4(struct bitmap *bm , Addr a1 ) ;
extern void vgDrd_bm_access_load_8(struct bitmap *bm , Addr a1 ) ;
extern void vgDrd_bm_access_range_store(struct bitmap *bm , Addr a1 , Addr a2 ) ;
extern void vgDrd_bm_access_store_1(struct bitmap *bm , Addr a1 ) ;
extern void vgDrd_bm_access_store_2(struct bitmap *bm , Addr a1 ) ;
extern void vgDrd_bm_access_store_4(struct bitmap *bm , Addr a1 ) ;
extern void vgDrd_bm_access_store_8(struct bitmap *bm , Addr a1 ) ;
extern Bool vgDrd_bm_has(struct bitmap *bm , Addr a1 , Addr a2 , BmAccessTypeT access_type ) ;
extern Bool vgDrd_bm_has_any_load(struct bitmap *bm , Addr a1 , Addr a2 ) ;
extern Bool vgDrd_bm_has_any_store(struct bitmap *bm , Addr a1 , Addr a2 ) ;
extern Bool vgDrd_bm_has_any_access(struct bitmap *bm , Addr a1 , Addr a2 ) ;
extern Bool vgDrd_bm_has_1(struct bitmap *bm , Addr address , BmAccessTypeT access_type ) ;
extern void vgDrd_bm_clear(struct bitmap *bm , Addr a1 , Addr a2 ) ;
extern void vgDrd_bm_clear_load(struct bitmap *bm , Addr a1 , Addr a2 ) ;
extern void vgDrd_bm_clear_store(struct bitmap *bm , Addr a1 , Addr a2 ) ;
extern Bool vgDrd_bm_test_and_clear(struct bitmap *bm , Addr a1 , Addr a2 ) ;
extern Bool vgDrd_bm_has_conflict_with(struct bitmap *bm , Addr a1 , Addr a2 , BmAccessTypeT access_type ) ;
extern Bool vgDrd_bm_load_1_has_conflict_with(struct bitmap *bm , Addr a1 ) ;
extern Bool vgDrd_bm_load_2_has_conflict_with(struct bitmap *bm , Addr a1 ) ;
extern Bool vgDrd_bm_load_4_has_conflict_with(struct bitmap *bm , Addr a1 ) ;
extern Bool vgDrd_bm_load_8_has_conflict_with(struct bitmap *bm , Addr a1 ) ;
extern Bool vgDrd_bm_load_has_conflict_with(struct bitmap *bm , Addr a1 , Addr a2 ) ;
extern Bool vgDrd_bm_store_1_has_conflict_with(struct bitmap *bm , Addr a1 ) ;
extern Bool vgDrd_bm_store_2_has_conflict_with(struct bitmap *bm , Addr a1 ) ;
extern Bool vgDrd_bm_store_4_has_conflict_with(struct bitmap *bm , Addr a1 ) ;
extern Bool vgDrd_bm_store_8_has_conflict_with(struct bitmap *bm , Addr a1 ) ;
extern Bool vgDrd_bm_store_has_conflict_with(struct bitmap *bm , Addr a1 , Addr a2 ) ;
extern Bool vgDrd_bm_equal(struct bitmap *lhs , struct bitmap *rhs ) ;
extern void vgDrd_bm_swap(struct bitmap *bm1 , struct bitmap *bm2 ) ;
extern void vgDrd_bm_merge2(struct bitmap *lhs , struct bitmap *rhs ) ;
extern void vgDrd_bm_unmark(struct bitmap *bm ) ;
extern Bool vgDrd_bm_is_marked(struct bitmap *bm , Addr a ) ;
extern void vgDrd_bm_mark(struct bitmap *bm1 , struct bitmap *bm2 ) ;
extern void vgDrd_bm_clear_marked(struct bitmap *bm ) ;
extern void vgDrd_bm_merge2_marked(struct bitmap *lhs , struct bitmap *rhs ) ;
extern void vgDrd_bm_remove_cleared_marked(struct bitmap *bm ) ;
extern int vgDrd_bm_has_races(struct bitmap *bm1 , struct bitmap *bm2 ) ;
extern void vgDrd_bm_report_races(ThreadId tid1 , ThreadId tid2 , struct bitmap *bm1 , struct bitmap *bm2 ) ;
extern void vgDrd_bm_print(struct bitmap *bm ) ;
extern ULong vgDrd_bm_get_bitmap_creation_count(void) ;
extern ULong vgDrd_bm_get_bitmap2_creation_count(void) ;
extern ULong vgDrd_bm_get_bitmap2_merge_count(void) ;
extern void *vgDrd_bm2_alloc_node(HChar *ec , SizeT szB ) ;
extern void vgDrd_bm2_free_node(void *bm2 ) ;
extern ExeContext *vgPlain_record_ExeContext(ThreadId tid , Word first_ip_delta ) ;
extern ExeContext *vgPlain_record_depth_1_ExeContext(ThreadId tid ) ;
extern void vgPlain_apply_ExeContext(void (*action)(UInt n , Addr ip ) , ExeContext *ec , UInt n_ips ) ;
extern Bool vgPlain_eq_ExeContext(VgRes res , ExeContext *e1 , ExeContext *e2 ) ;
extern void vgPlain_pp_ExeContext(ExeContext *ec ) ;
extern UInt vgPlain_get_ECU_from_ExeContext(ExeContext *e ) ;
extern Int vgPlain_get_ExeContext_n_ips(ExeContext *e ) ;
extern ExeContext *vgPlain_get_ExeContext_from_ECU(UInt uniq ) ;
extern ExeContext *vgPlain_make_depth_1_ExeContext_from_Addr(Addr a ) ;
__inline static Bool vgPlain_is_plausible_ECU(UInt ecu ) 
{ int tmp ;

  {
  if (ecu > 0U) {
    if ((ecu & 3U) == 0U) {
      tmp = 1;
    } else {
      tmp = 0;
    }
  } else {
    tmp = 0;
  }
  return ((unsigned char )tmp);
}
}
extern ExeContext *vgPlain_make_ExeContext_from_StackTrace(Addr *ips , UInt n_ips ) ;
extern UInt vgPlain_get_StackTrace(ThreadId tid , StackTrace ips , UInt n_ips , StackTrace sps , StackTrace fps , Word first_ip_delta ) ;
extern void vgPlain_apply_StackTrace(void (*action)(UInt n , Addr ip , void *opaque ) , void *opaque , StackTrace ips , UInt n_ips ) ;
extern void vgPlain_pp_StackTrace(StackTrace ips , UInt n_ips ) ;
extern void vgPlain_get_and_pp_StackTrace(ThreadId tid , UInt n_ips ) ;
extern Segment *vgDrd_sg_new(DrdThreadId creator , DrdThreadId created ) ;
__inline static int vgDrd_sg_get_refcnt(Segment const   *sg ) ;
extern Segment *vgDrd_sg_get(Segment *sg ) ;
extern void vgDrd_sg_put(Segment *sg ) ;
__inline static struct bitmap *vgDrd_sg_bm(Segment *sg ) ;
extern void vgDrd_sg_merge(Segment *sg1 , Segment *sg2 ) ;
extern void vgDrd_sg_print(Segment *sg ) ;
extern Bool vgDrd_sg_get_trace(void) ;
extern void vgDrd_sg_set_trace(Bool trace_segment ) ;
extern ULong vgDrd_sg_get_segments_created_count(void) ;
extern ULong vgDrd_sg_get_segments_alive_count(void) ;
extern ULong vgDrd_sg_get_max_segments_alive_count(void) ;
extern ULong vgDrd_sg_get_segment_merge_count(void) ;
__inline static int vgDrd_sg_get_refcnt(Segment const   *sg ) 
{ 

  {
  return ((int )sg->refcnt);
}
}
__inline static struct bitmap *vgDrd_sg_bm(Segment *sg ) 
{ 

  {
  return (& sg->bm);
}
}
extern ThreadId vgPlain_get_running_tid(void) ;
extern DrdThreadId vgDrd_g_drd_running_tid ;
extern ThreadInfo vgDrd_g_threadinfo[500] ;
extern struct bitmap *vgDrd_g_conflict_set ;
extern void vgDrd_thread_trace_context_switches(Bool t ) ;
extern void vgDrd_thread_trace_conflict_set(Bool t ) ;
extern void vgDrd_thread_trace_conflict_set_bm(Bool t ) ;
extern Bool vgDrd_thread_get_trace_fork_join(void) ;
extern void vgDrd_thread_set_trace_fork_join(Bool t ) ;
extern void vgDrd_thread_set_segment_merging(Bool m ) ;
extern int vgDrd_thread_get_segment_merge_interval(void) ;
extern void vgDrd_thread_set_segment_merge_interval(int i ) ;
extern DrdThreadId vgDrd_VgThreadIdToDrdThreadId(ThreadId tid ) ;
extern DrdThreadId vgDrd_NewVgThreadIdToDrdThreadId(ThreadId tid ) ;
extern DrdThreadId vgDrd_PtThreadIdToDrdThreadId(PThreadId tid ) ;
extern ThreadId vgDrd_DrdThreadIdToVgThreadId(DrdThreadId tid ) ;
extern DrdThreadId vgDrd_thread_pre_create(DrdThreadId creator , ThreadId vg_created ) ;
extern DrdThreadId vgDrd_thread_post_create(ThreadId vg_created ) ;
extern void vgDrd_thread_post_join(DrdThreadId drd_joiner , DrdThreadId drd_joinee ) ;
extern void vgDrd_thread_delete(DrdThreadId tid , Bool detached ) ;
extern void vgDrd_thread_finished(DrdThreadId tid ) ;
extern void vgDrd_drd_thread_atfork_child(DrdThreadId tid ) ;
extern void vgDrd_thread_pre_cancel(DrdThreadId tid ) ;
extern void vgDrd_thread_set_stack_startup(DrdThreadId tid , Addr stack_startup ) ;
extern Addr vgDrd_thread_get_stack_min(DrdThreadId tid ) ;
extern Addr vgDrd_thread_get_stack_min_min(DrdThreadId tid ) ;
extern Addr vgDrd_thread_get_stack_max(DrdThreadId tid ) ;
extern SizeT vgDrd_thread_get_stack_size(DrdThreadId tid ) ;
extern Bool vgDrd_thread_get_on_alt_stack(DrdThreadId tid ) ;
extern void vgDrd_thread_set_on_alt_stack(DrdThreadId tid , Bool on_alt_stack ) ;
extern Int vgDrd_thread_get_threads_on_alt_stack(void) ;
extern void vgDrd_thread_set_pthreadid(DrdThreadId tid , PThreadId ptid ) ;
extern Bool vgDrd_thread_get_joinable(DrdThreadId tid ) ;
extern void vgDrd_thread_set_joinable(DrdThreadId tid , Bool joinable ) ;
extern void vgDrd_thread_entering_pthread_create(DrdThreadId tid ) ;
extern void vgDrd_thread_left_pthread_create(DrdThreadId tid ) ;
extern char const   *vgDrd_thread_get_name(DrdThreadId tid ) ;
extern void vgDrd_thread_set_name(DrdThreadId tid , char const   *name ) ;
extern void vgDrd_thread_set_vg_running_tid(ThreadId vg_tid ) ;
extern void vgDrd_thread_set_running_tid(ThreadId vg_tid , DrdThreadId drd_tid ) ;
extern int vgDrd_thread_enter_synchr(DrdThreadId tid ) ;
extern int vgDrd_thread_leave_synchr(DrdThreadId tid ) ;
extern int vgDrd_thread_get_synchr_nesting_count(DrdThreadId tid ) ;
extern void vgDrd_thread_new_segment(DrdThreadId tid ) ;
extern VectorClock *vgDrd_thread_get_vc(DrdThreadId tid ) ;
extern void vgDrd_thread_get_latest_segment(Segment **sg , DrdThreadId tid ) ;
extern void vgDrd_thread_combine_vc_join(DrdThreadId joiner , DrdThreadId joinee ) ;
extern void vgDrd_thread_new_segment_and_combine_vc(DrdThreadId tid , Segment const   *sg ) ;
extern void vgDrd_thread_update_conflict_set(DrdThreadId tid , VectorClock const   *old_vc ) ;
extern void vgDrd_thread_stop_using_mem(Addr a1 , Addr a2 , Bool dont_clear_access ) ;
extern void vgDrd_thread_set_record_loads(DrdThreadId tid , Bool enabled ) ;
extern void vgDrd_thread_set_record_stores(DrdThreadId tid , Bool enabled ) ;
extern void vgDrd_thread_print_all(void) ;
extern void vgDrd_thread_report_races(DrdThreadId tid ) ;
extern void vgDrd_thread_report_races_segment(DrdThreadId tid , Segment const   *p ) ;
extern void vgDrd_thread_report_all_races(void) ;
extern void vgDrd_thread_report_conflicting_segments(DrdThreadId tid , Addr addr , SizeT size , BmAccessTypeT access_type ) ;
extern ULong vgDrd_thread_get_context_switch_count(void) ;
extern ULong vgDrd_thread_get_report_races_count(void) ;
extern ULong vgDrd_thread_get_discard_ordered_segments_count(void) ;
extern ULong vgDrd_thread_get_compute_conflict_set_count(void) ;
extern ULong vgDrd_thread_get_update_conflict_set_count(void) ;
extern ULong vgDrd_thread_get_update_conflict_set_new_sg_count(void) ;
extern ULong vgDrd_thread_get_update_conflict_set_sync_count(void) ;
extern ULong vgDrd_thread_get_update_conflict_set_join_count(void) ;
extern ULong vgDrd_thread_get_conflict_set_bitmap_creation_count(void) ;
extern ULong vgDrd_thread_get_conflict_set_bitmap2_creation_count(void) ;
__inline static Bool vgDrd_IsValidDrdThreadId(DrdThreadId tid ) 
{ int tmp ;

  {
  if (0 <= (int )tid) {
    if (tid < 500U) {
      if (tid != 0U) {
        if ((int )vgDrd_g_threadinfo[tid].vg_thread_exists == 0) {
          if ((int )vgDrd_g_threadinfo[tid].posix_thread_exists == 0) {
            if ((int )vgDrd_g_threadinfo[tid].detached_posix_thread == 0) {
              tmp = 0;
            } else {
              tmp = 1;
            }
          } else {
            tmp = 1;
          }
        } else {
          tmp = 1;
        }
      } else {
        tmp = 0;
      }
    } else {
      tmp = 0;
    }
  } else {
    tmp = 0;
  }
  return ((unsigned char )tmp);
}
}
__inline static DrdThreadId vgDrd_thread_get_running_tid(void) 
{ 

  {
  return (vgDrd_g_drd_running_tid);
}
}
__inline static struct bitmap *vgDrd_thread_get_conflict_set(void) 
{ 

  {
  return (vgDrd_g_conflict_set);
}
}
__inline static Bool vgDrd_running_thread_inside_pthread_create(void) 
{ 

  {
  return ((unsigned char )(vgDrd_g_threadinfo[vgDrd_g_drd_running_tid].pthread_create_nesting_level > 0));
}
}
__inline static Bool vgDrd_running_thread_is_recording_loads(void) 
{ int tmp ;

  {
  if (vgDrd_g_threadinfo[vgDrd_g_drd_running_tid].synchr_nesting == 0) {
    if (vgDrd_g_threadinfo[vgDrd_g_drd_running_tid].is_recording_loads) {
      tmp = 1;
    } else {
      tmp = 0;
    }
  } else {
    tmp = 0;
  }
  return ((unsigned char )tmp);
}
}
__inline static Bool vgDrd_running_thread_is_recording_stores(void) 
{ int tmp ;

  {
  if (vgDrd_g_threadinfo[vgDrd_g_drd_running_tid].synchr_nesting == 0) {
    if (vgDrd_g_threadinfo[vgDrd_g_drd_running_tid].is_recording_stores) {
      tmp = 1;
    } else {
      tmp = 0;
    }
  } else {
    tmp = 0;
  }
  return ((unsigned char )tmp);
}
}
__inline static void vgDrd_thread_set_stack_min(DrdThreadId tid , Addr stack_min ) 
{ long tmp ;

  {
  vgDrd_g_threadinfo[tid].stack_min = stack_min;
  tmp = __builtin_expect((long )(stack_min < vgDrd_g_threadinfo[tid].stack_min_min), 0L);
  if (tmp) {
    vgDrd_g_threadinfo[tid].stack_min_min = stack_min;
  } else {

  }
  return;
}
}
__inline static Bool vgDrd_thread_address_on_stack(Addr a ) 
{ int tmp ;

  {
  if (vgDrd_g_threadinfo[vgDrd_g_drd_running_tid].stack_min <= a) {
    if (a < vgDrd_g_threadinfo[vgDrd_g_drd_running_tid].stack_max) {
      tmp = 1;
    } else {
      tmp = 0;
    }
  } else {
    tmp = 0;
  }
  return ((unsigned char )tmp);
}
}
__inline static Bool vgDrd_thread_address_on_any_stack(Addr a ) 
{ int i ;

  {
  i = 1;
  while (i < 500) {
    if (vgDrd_g_threadinfo[i].vg_thread_exists) {
      if (vgDrd_g_threadinfo[i].stack_min <= a) {
        if (a < vgDrd_g_threadinfo[i].stack_max) {
          return ((unsigned char)1);
        } else {

        }
      } else {

      }
    } else {

    }
    i ++;
  }
  return ((unsigned char)0);
}
}
__inline static Segment *vgDrd_thread_get_segment(DrdThreadId tid ) 
{ 

  {
  return (vgDrd_g_threadinfo[tid].last);
}
}
__inline static Segment *vgDrd_running_thread_get_segment(void) 
{ Segment *tmp ;

  {
  tmp = vgDrd_thread_get_segment(vgDrd_g_drd_running_tid);
  return (tmp);
}
}
extern Addr vgDrd_pthread_cond_initializer ;
extern int vgDrd_pthread_cond_initializer_size ;
extern void vgDrd_cond_set_report_signal_unlocked(Bool r ) ;
extern void vgDrd_cond_set_trace(Bool trace_cond ) ;
extern struct cond_info *vgDrd_cond_get(Addr cond ) ;
extern void vgDrd_cond_pre_init(Addr cond ) ;
extern void vgDrd_cond_post_destroy(Addr cond ) ;
extern void vgDrd_cond_pre_wait(Addr cond , Addr mutex ) ;
extern void vgDrd_cond_post_wait(Addr cond ) ;
extern void vgDrd_cond_pre_signal(Addr cond ) ;
extern void vgDrd_cond_pre_broadcast(Addr cond ) ;
extern Bool vgPlain_get_filename(Addr a , Char *filename , Int n_filename ) ;
extern Bool vgPlain_get_fnname(Addr a , Char *fnname , Int n_fnname ) ;
extern Bool vgPlain_get_linenum(Addr a , UInt *linenum ) ;
extern Bool vgPlain_get_fnname_w_offset(Addr a , Char *fnname , Int n_fnname ) ;
extern Bool vgPlain_get_filename_linenum(Addr a , Char *filename , Int n_filename , Char *dirname , Int n_dirname , Bool *dirname_available , UInt *linenum ) ;
extern Bool vgPlain_get_fnname_if_entry(Addr a , Char *fnname , Int n_fnname ) ;
extern Vg_FnNameKind vgPlain_get_fnname_kind(Char *name ) ;
extern Vg_FnNameKind vgPlain_get_fnname_kind_from_IP(Addr ip ) ;
extern Bool vgPlain_get_datasym_and_offset(Addr data_addr , Char *dname , Int n_dname , PtrdiffT *offset ) ;
extern Bool vgPlain_get_data_description(void *dname1v , void *dname2v , Addr data_addr ) ;
extern Bool vgPlain_get_objname(Addr a , Char *objname , Int n_objname ) ;
extern Char *vgPlain_describe_IP(Addr eip , Char *buf , Int n_buf ) ;
extern void *vgPlain_di_get_stack_blocks_at_ip(Addr ip , Bool arrays_only ) ;
extern void *vgPlain_di_get_global_blocks_from_dihandle(ULong di_handle , Bool arrays_only ) ;
extern DebugInfo *vgPlain_find_DebugInfo(Addr a ) ;
extern Addr vgPlain_DebugInfo_get_text_avma(DebugInfo const   *di ) ;
extern SizeT vgPlain_DebugInfo_get_text_size(DebugInfo const   *di ) ;
extern Addr vgPlain_DebugInfo_get_plt_avma(DebugInfo const   *di ) ;
extern SizeT vgPlain_DebugInfo_get_plt_size(DebugInfo const   *di ) ;
extern Addr vgPlain_DebugInfo_get_gotplt_avma(DebugInfo const   *di ) ;
extern SizeT vgPlain_DebugInfo_get_gotplt_size(DebugInfo const   *di ) ;
extern UChar const   *vgPlain_DebugInfo_get_soname(DebugInfo const   *di ) ;
extern UChar const   *vgPlain_DebugInfo_get_filename(DebugInfo const   *di ) ;
extern PtrdiffT vgPlain_DebugInfo_get_text_bias(DebugInfo const   *di ) ;
extern DebugInfo const   *vgPlain_next_DebugInfo(DebugInfo const   *di ) ;
extern Int vgPlain_DebugInfo_syms_howmany(DebugInfo const   *di ) ;
extern void vgPlain_DebugInfo_syms_getidx(DebugInfo const   *di , Int idx , Addr *avma , Addr *tocptr , UInt *size , HChar **name , Bool *isText , Bool *isIFunc ) ;
extern HChar const   *vgPlain_pp_SectKind(VgSectKind kind ) ;
extern VgSectKind vgPlain_DebugInfo_sect_kind(UChar *name , SizeT n_name , Addr a ) ;
extern ExeContext *vgPlain_get_error_where(Error *err ) ;
extern ErrorKind vgPlain_get_error_kind(Error *err ) ;
extern Addr vgPlain_get_error_address(Error *err ) ;
extern Char *vgPlain_get_error_string(Error *err ) ;
extern void *vgPlain_get_error_extra(Error *err ) ;
extern void vgPlain_maybe_record_error(ThreadId tid , ErrorKind ekind , Addr a , Char *s , void *extra ) ;
extern Bool vgPlain_unique_error(ThreadId tid , ErrorKind ekind , Addr a , Char *s , void *extra , ExeContext *where , Bool print_error , Bool allow_GDB_attach , Bool count_error ) ;
extern Bool vgPlain_get_line(Int fd , Char **bufpp , SizeT *nBufp , Int *lineno ) ;
extern SuppKind vgPlain_get_supp_kind(Supp *su ) ;
extern Char *vgPlain_get_supp_string(Supp *su ) ;
extern void *vgPlain_get_supp_extra(Supp *su ) ;
extern void vgPlain_set_supp_kind(Supp *su , SuppKind suppkind ) ;
extern void vgPlain_set_supp_string(Supp *su , Char *string ) ;
extern void vgPlain_set_supp_extra(Supp *su , void *extra ) ;
extern void vgDrd_set_show_conflicting_segments(Bool scs ) ;
extern void vgDrd_register_error_handlers(void) ;
extern void vgDrd_hb_set_trace(Bool trace_hb ) ;
extern struct hb_info *vgDrd_hb_get(Addr hb ) ;
extern struct hb_info *vgDrd_hb_get_or_allocate(Addr hb ) ;
extern void vgDrd_hb_init(Addr hb ) ;
extern void vgDrd_hb_destroy(Addr hb ) ;
extern void vgDrd_hb_happens_after(DrdThreadId tid , Addr hb ) ;
extern void vgDrd_hb_happens_before(DrdThreadId tid , Addr hb ) ;
extern void vgDrd_hb_happens_done(DrdThreadId tid , Addr hb ) ;
extern void ppIRType(IRType  ) ;
extern Int sizeofIRType(IRType  ) ;
extern IRConst *IRConst_U1(Bool  ) ;
extern IRConst *IRConst_U8(UChar  ) ;
extern IRConst *IRConst_U16(UShort  ) ;
extern IRConst *IRConst_U32(UInt  ) ;
extern IRConst *IRConst_U64(ULong  ) ;
extern IRConst *IRConst_F32(Float  ) ;
extern IRConst *IRConst_F32i(UInt  ) ;
extern IRConst *IRConst_F64(Double  ) ;
extern IRConst *IRConst_F64i(ULong  ) ;
extern IRConst *IRConst_V128(UShort  ) ;
extern IRConst *deepCopyIRConst(IRConst * ) ;
extern void ppIRConst(IRConst * ) ;
extern Bool eqIRConst(IRConst * , IRConst * ) ;
extern IRCallee *mkIRCallee(Int regparms , HChar *name , void *addr ) ;
extern IRCallee *deepCopyIRCallee(IRCallee * ) ;
extern void ppIRCallee(IRCallee * ) ;
extern IRRegArray *mkIRRegArray(Int  , IRType  , Int  ) ;
extern IRRegArray *deepCopyIRRegArray(IRRegArray * ) ;
extern void ppIRRegArray(IRRegArray * ) ;
extern Bool eqIRRegArray(IRRegArray * , IRRegArray * ) ;
extern void ppIRTemp(IRTemp  ) ;
extern void ppIROp(IROp  ) ;
extern IRExpr *IRExpr_Binder(Int binder ) ;
extern IRExpr *IRExpr_Get(Int off , IRType ty ) ;
extern IRExpr *IRExpr_GetI(IRRegArray *descr , IRExpr *ix , Int bias ) ;
extern IRExpr *IRExpr_RdTmp(IRTemp tmp ) ;
extern IRExpr *IRExpr_Qop(IROp op , IRExpr *arg1 , IRExpr *arg2 , IRExpr *arg3 , IRExpr *arg4 ) ;
extern IRExpr *IRExpr_Triop(IROp op , IRExpr *arg1 , IRExpr *arg2 , IRExpr *arg3 ) ;
extern IRExpr *IRExpr_Binop(IROp op , IRExpr *arg1 , IRExpr *arg2 ) ;
extern IRExpr *IRExpr_Unop(IROp op , IRExpr *arg ) ;
extern IRExpr *IRExpr_Load(IREndness end , IRType ty , IRExpr *addr ) ;
extern IRExpr *IRExpr_Const(IRConst *con ) ;
extern IRExpr *IRExpr_CCall(IRCallee *cee , IRType retty , IRExpr **args ) ;
extern IRExpr *IRExpr_Mux0X(IRExpr *cond , IRExpr *expr0 , IRExpr *exprX ) ;
extern IRExpr *deepCopyIRExpr(IRExpr * ) ;
extern void ppIRExpr(IRExpr * ) ;
extern IRExpr **mkIRExprVec_0(void) ;
extern IRExpr **mkIRExprVec_1(IRExpr * ) ;
extern IRExpr **mkIRExprVec_2(IRExpr * , IRExpr * ) ;
extern IRExpr **mkIRExprVec_3(IRExpr * , IRExpr * , IRExpr * ) ;
extern IRExpr **mkIRExprVec_4(IRExpr * , IRExpr * , IRExpr * , IRExpr * ) ;
extern IRExpr **mkIRExprVec_5(IRExpr * , IRExpr * , IRExpr * , IRExpr * , IRExpr * ) ;
extern IRExpr **mkIRExprVec_6(IRExpr * , IRExpr * , IRExpr * , IRExpr * , IRExpr * , IRExpr * ) ;
extern IRExpr **mkIRExprVec_7(IRExpr * , IRExpr * , IRExpr * , IRExpr * , IRExpr * , IRExpr * , IRExpr * ) ;
extern IRExpr **mkIRExprVec_8(IRExpr * , IRExpr * , IRExpr * , IRExpr * , IRExpr * , IRExpr * , IRExpr * , IRExpr * ) ;
extern IRExpr **shallowCopyIRExprVec(IRExpr ** ) ;
extern IRExpr **deepCopyIRExprVec(IRExpr ** ) ;
extern IRExpr *mkIRExpr_HWord(HWord  ) ;
extern IRExpr *mkIRExprCCall(IRType retty , Int regparms , HChar *name , void *addr , IRExpr **args ) ;
__inline static Bool isIRAtom(IRExpr *e ) 
{ int tmp ;
  Bool tmp___0 ;

  {
  if ((unsigned int )e->tag == 86019U) {
    tmp = 1;
  } else {
    if ((unsigned int )e->tag == 86025U) {
      tmp = 1;
    } else {
      tmp = 0;
    }
  }
  tmp___0 = toBool(tmp);
  return (tmp___0);
}
}
extern Bool eqIRAtom(IRExpr * , IRExpr * ) ;
extern void ppIRJumpKind(IRJumpKind  ) ;
extern void ppIREffect(IREffect  ) ;
extern void ppIRDirty(IRDirty * ) ;
extern IRDirty *emptyIRDirty(void) ;
extern IRDirty *deepCopyIRDirty(IRDirty * ) ;
extern IRDirty *unsafeIRDirty_0_N(Int regparms , HChar *name , void *addr , IRExpr **args ) ;
extern IRDirty *unsafeIRDirty_1_N(IRTemp dst , Int regparms , HChar *name , void *addr , IRExpr **args ) ;
extern void ppIRMBusEvent(IRMBusEvent  ) ;
extern void ppIRCAS(IRCAS *cas ) ;
extern IRCAS *mkIRCAS(IRTemp oldHi , IRTemp oldLo , IREndness end , IRExpr *addr , IRExpr *expdHi , IRExpr *expdLo , IRExpr *dataHi , IRExpr *dataLo ) ;
extern IRCAS *deepCopyIRCAS(IRCAS * ) ;
extern IRStmt *IRStmt_NoOp(void) ;
extern IRStmt *IRStmt_IMark(Addr64 addr , Int len ) ;
extern IRStmt *IRStmt_AbiHint(IRExpr *base , Int len , IRExpr *nia ) ;
extern IRStmt *IRStmt_Put(Int off , IRExpr *data ) ;
extern IRStmt *IRStmt_PutI(IRRegArray *descr , IRExpr *ix , Int bias , IRExpr *data ) ;
extern IRStmt *IRStmt_WrTmp(IRTemp tmp , IRExpr *data ) ;
extern IRStmt *IRStmt_Store(IREndness end , IRExpr *addr , IRExpr *data ) ;
extern IRStmt *IRStmt_CAS(IRCAS *details ) ;
extern IRStmt *IRStmt_LLSC(IREndness end , IRTemp result , IRExpr *addr , IRExpr *storedata ) ;
extern IRStmt *IRStmt_Dirty(IRDirty *details ) ;
extern IRStmt *IRStmt_MBE(IRMBusEvent event ) ;
extern IRStmt *IRStmt_Exit(IRExpr *guard , IRJumpKind jk , IRConst *dst ) ;
extern IRStmt *deepCopyIRStmt(IRStmt * ) ;
extern void ppIRStmt(IRStmt * ) ;
extern IRTemp newIRTemp(IRTypeEnv * , IRType  ) ;
extern IRTypeEnv *deepCopyIRTypeEnv(IRTypeEnv * ) ;
extern void ppIRTypeEnv(IRTypeEnv * ) ;
extern IRSB *emptyIRSB(void) ;
extern IRSB *deepCopyIRSB(IRSB * ) ;
extern IRSB *deepCopyIRSBExceptStmts(IRSB * ) ;
extern void ppIRSB(IRSB * ) ;
extern void addStmtToIRSB(IRSB * , IRStmt * ) ;
extern IRTypeEnv *emptyIRTypeEnv(void) ;
extern IRType typeOfIRConst(IRConst * ) ;
extern IRType typeOfIRTemp(IRTypeEnv * , IRTemp  ) ;
extern IRType typeOfIRExpr(IRTypeEnv * , IRExpr * ) ;
extern void sanityCheckIRSB(IRSB *bb , HChar *caller , Bool require_flatness , IRType guest_word_size ) ;
extern Bool isFlatIRStmt(IRStmt * ) ;
extern Bool isPlausibleIRType(IRType ty ) ;
extern HChar const   *LibVEX_ppVexArch(VexArch  ) ;
extern HChar const   *LibVEX_ppVexHwCaps(VexArch  , UInt  ) ;
extern void LibVEX_default_VexArchInfo(VexArchInfo *vai ) ;
extern void LibVEX_default_VexAbiInfo(VexAbiInfo *vbi ) ;
extern void LibVEX_default_VexControl(VexControl *vcon ) ;
extern HChar *private_LibVEX_alloc_first ;
extern HChar *private_LibVEX_alloc_curr ;
extern HChar *private_LibVEX_alloc_last ;
extern  __attribute__((__noreturn__)) void private_LibVEX_alloc_OOM(void) ;
__inline static void *LibVEX_Alloc(Int nbytes ) 
{ HChar *curr ;
  HChar *next ;
  Int ALIGN ;

  {
  ALIGN = (int )(sizeof(void *) - 1U);
  nbytes = (nbytes + ALIGN) & ~ ALIGN;
  curr = private_LibVEX_alloc_curr;
  next = curr + nbytes;
  if ((unsigned int )next >= (unsigned int )private_LibVEX_alloc_last) {
    private_LibVEX_alloc_OOM();
  } else {

  }
  private_LibVEX_alloc_curr = next;
  return ((void *)curr);
}
}
extern void LibVEX_ShowAllocStats(void) ;
extern void LibVEX_Init( __attribute__((__noreturn__)) void (*failure_exit)(void) , void (*log_bytes)(HChar * , Int nbytes ) , Int debuglevel , Bool valgrind_support , VexControl *vcon ) ;
extern VexTranslateResult LibVEX_Translate(VexTranslateArgs * ) ;
extern void LibVEX_ShowStats(void) ;
extern void (*vgPlain_tl_pre_clo_init)(void) ;
extern void vgPlain_basic_tool_funcs(void (*post_clo_init)(void) , IRSB *(*instrument)(VgCallbackClosure *closure , IRSB *sb_in , VexGuestLayout *layout , VexGuestExtents *vge , IRType gWordTy , IRType hWordTy ) , void (*fini)(Int  ) ) ;
extern void vgPlain_details_name(Char *name ) ;
extern void vgPlain_details_version(Char *version ) ;
extern void vgPlain_details_description(Char *description ) ;
extern void vgPlain_details_copyright_author(Char *copyright_author ) ;
extern void vgPlain_details_avg_translation_sizeB(UInt size ) ;
extern void vgPlain_details_bug_reports_to(Char *bug_reports_to ) ;
extern void vgPlain_needs_libc_freeres(void) ;
extern void vgPlain_needs_core_errors(void) ;
extern void vgPlain_needs_tool_errors(Bool (*eq_Error)(VgRes res , Error *e1 , Error *e2 ) , void (*before_pp_Error)(Error *err ) , void (*pp_Error)(Error *err ) , Bool show_ThreadIDs_for_errors , UInt (*update_extra)(Error *err ) , Bool (*recognised_suppression)(Char *name , Supp *su ) , Bool (*read_extra_suppression_info)(Int fd , Char **bufpp , SizeT *nBufp , Supp *su ) , Bool (*error_matches_suppression)(Error *err , Supp *su ) , Char *(*get_error_name)(Error *err ) , Bool (*print_extra_suppression_info)(Error *err , Char *buf , Int nBuf ) ) ;
extern void vgPlain_needs_superblock_discards(void (*discard_superblock_info)(Addr64 orig_addr , VexGuestExtents extents ) ) ;
extern void vgPlain_needs_command_line_options(Bool (*process_cmd_line_option)(Char *argv ) , void (*print_usage)(void) , void (*print_debug_usage)(void) ) ;
extern void vgPlain_needs_client_requests(Bool (*handle_client_request)(ThreadId tid , UWord *arg_block , UWord *ret ) ) ;
extern void vgPlain_needs_syscall_wrapper(void (*pre_syscall)(ThreadId tid , UInt syscallno , UWord *args , UInt nArgs ) , void (*post_syscall)(ThreadId tid , UInt syscallno , UWord *args , UInt nArgs , SysRes res ) ) ;
extern void vgPlain_needs_sanity_checks(Bool (*cheap_sanity_check)(void) , Bool (*expensive_sanity_check)(void) ) ;
extern void vgPlain_needs_var_info(void) ;
extern void vgPlain_needs_malloc_replacement(void *(*pmalloc)(ThreadId tid , SizeT n ) , void *(*p__builtin_new)(ThreadId tid , SizeT n ) , void *(*p__builtin_vec_new)(ThreadId tid , SizeT n ) , void *(*pmemalign)(ThreadId tid , SizeT align , SizeT n ) , void *(*pcalloc)(ThreadId tid , SizeT nmemb , SizeT size1 ) , void (*pfree)(ThreadId tid , void *p ) , void (*p__builtin_delete)(ThreadId tid , void *p ) , void (*p__builtin_vec_delete)(ThreadId tid , void *p ) , void *(*prealloc)(ThreadId tid , void *p , SizeT new_size ) , SizeT (*pmalloc_usable_size)(ThreadId tid , void *p ) , SizeT client_malloc_redzone_szB ) ;
extern void vgPlain_needs_xml_output(void) ;
extern void vgPlain_needs_final_IR_tidy_pass(IRSB *(*final_tidy)(IRSB * ) ) ;
extern void vgPlain_track_new_mem_startup(void (*f)(Addr a , SizeT len , Bool rr , Bool ww , Bool xx , ULong di_handle ) ) ;
extern void vgPlain_track_new_mem_stack_signal(void (*f)(Addr a , SizeT len , ThreadId tid ) ) ;
extern void vgPlain_track_new_mem_brk(void (*f)(Addr a , SizeT len , ThreadId tid ) ) ;
extern void vgPlain_track_new_mem_mmap(void (*f)(Addr a , SizeT len , Bool rr , Bool ww , Bool xx , ULong di_handle ) ) ;
extern void vgPlain_track_copy_mem_remap(void (*f)(Addr from , Addr to , SizeT len ) ) ;
extern void vgPlain_track_change_mem_mprotect(void (*f)(Addr a , SizeT len , Bool rr , Bool ww , Bool xx ) ) ;
extern void vgPlain_track_die_mem_stack_signal(void (*f)(Addr a , SizeT len ) ) ;
extern void vgPlain_track_die_mem_brk(void (*f)(Addr a , SizeT len ) ) ;
extern void vgPlain_track_die_mem_munmap(void (*f)(Addr a , SizeT len ) ) ;
extern void vgPlain_track_new_mem_stack_4_w_ECU(void ( __attribute__((__regparm__(2))) (*f))(Addr new_ESP , UInt ecu ) ) ;
extern void vgPlain_track_new_mem_stack_8_w_ECU(void ( __attribute__((__regparm__(2))) (*f))(Addr new_ESP , UInt ecu ) ) ;
extern void vgPlain_track_new_mem_stack_12_w_ECU(void ( __attribute__((__regparm__(2))) (*f))(Addr new_ESP , UInt ecu ) ) ;
extern void vgPlain_track_new_mem_stack_16_w_ECU(void ( __attribute__((__regparm__(2))) (*f))(Addr new_ESP , UInt ecu ) ) ;
extern void vgPlain_track_new_mem_stack_32_w_ECU(void ( __attribute__((__regparm__(2))) (*f))(Addr new_ESP , UInt ecu ) ) ;
extern void vgPlain_track_new_mem_stack_112_w_ECU(void ( __attribute__((__regparm__(2))) (*f))(Addr new_ESP , UInt ecu ) ) ;
extern void vgPlain_track_new_mem_stack_128_w_ECU(void ( __attribute__((__regparm__(2))) (*f))(Addr new_ESP , UInt ecu ) ) ;
extern void vgPlain_track_new_mem_stack_144_w_ECU(void ( __attribute__((__regparm__(2))) (*f))(Addr new_ESP , UInt ecu ) ) ;
extern void vgPlain_track_new_mem_stack_160_w_ECU(void ( __attribute__((__regparm__(2))) (*f))(Addr new_ESP , UInt ecu ) ) ;
extern void vgPlain_track_new_mem_stack_w_ECU(void (*f)(Addr a , SizeT len , UInt ecu ) ) ;
extern void vgPlain_track_new_mem_stack_4(void ( __attribute__((__regparm__(1))) (*f))(Addr new_ESP ) ) ;
extern void vgPlain_track_new_mem_stack_8(void ( __attribute__((__regparm__(1))) (*f))(Addr new_ESP ) ) ;
extern void vgPlain_track_new_mem_stack_12(void ( __attribute__((__regparm__(1))) (*f))(Addr new_ESP ) ) ;
extern void vgPlain_track_new_mem_stack_16(void ( __attribute__((__regparm__(1))) (*f))(Addr new_ESP ) ) ;
extern void vgPlain_track_new_mem_stack_32(void ( __attribute__((__regparm__(1))) (*f))(Addr new_ESP ) ) ;
extern void vgPlain_track_new_mem_stack_112(void ( __attribute__((__regparm__(1))) (*f))(Addr new_ESP ) ) ;
extern void vgPlain_track_new_mem_stack_128(void ( __attribute__((__regparm__(1))) (*f))(Addr new_ESP ) ) ;
extern void vgPlain_track_new_mem_stack_144(void ( __attribute__((__regparm__(1))) (*f))(Addr new_ESP ) ) ;
extern void vgPlain_track_new_mem_stack_160(void ( __attribute__((__regparm__(1))) (*f))(Addr new_ESP ) ) ;
extern void vgPlain_track_new_mem_stack(void (*f)(Addr a , SizeT len ) ) ;
extern void vgPlain_track_die_mem_stack_4(void ( __attribute__((__regparm__(1))) (*f))(Addr die_ESP ) ) ;
extern void vgPlain_track_die_mem_stack_8(void ( __attribute__((__regparm__(1))) (*f))(Addr die_ESP ) ) ;
extern void vgPlain_track_die_mem_stack_12(void ( __attribute__((__regparm__(1))) (*f))(Addr die_ESP ) ) ;
extern void vgPlain_track_die_mem_stack_16(void ( __attribute__((__regparm__(1))) (*f))(Addr die_ESP ) ) ;
extern void vgPlain_track_die_mem_stack_32(void ( __attribute__((__regparm__(1))) (*f))(Addr die_ESP ) ) ;
extern void vgPlain_track_die_mem_stack_112(void ( __attribute__((__regparm__(1))) (*f))(Addr die_ESP ) ) ;
extern void vgPlain_track_die_mem_stack_128(void ( __attribute__((__regparm__(1))) (*f))(Addr die_ESP ) ) ;
extern void vgPlain_track_die_mem_stack_144(void ( __attribute__((__regparm__(1))) (*f))(Addr die_ESP ) ) ;
extern void vgPlain_track_die_mem_stack_160(void ( __attribute__((__regparm__(1))) (*f))(Addr die_ESP ) ) ;
extern void vgPlain_track_die_mem_stack(void (*f)(Addr a , SizeT len ) ) ;
extern void vgPlain_track_ban_mem_stack(void (*f)(Addr a , SizeT len ) ) ;
extern void vgPlain_track_pre_mem_read(void (*f)(CorePart part , ThreadId tid , Char *s , Addr a , SizeT size ) ) ;
extern void vgPlain_track_pre_mem_read_asciiz(void (*f)(CorePart part , ThreadId tid , Char *s , Addr a ) ) ;
extern void vgPlain_track_pre_mem_write(void (*f)(CorePart part , ThreadId tid , Char *s , Addr a , SizeT size ) ) ;
extern void vgPlain_track_post_mem_write(void (*f)(CorePart part , ThreadId tid , Addr a , SizeT size ) ) ;
extern void vgPlain_track_pre_reg_read(void (*f)(CorePart part , ThreadId tid , Char *s , PtrdiffT guest_state_offset , SizeT size ) ) ;
extern void vgPlain_track_post_reg_write(void (*f)(CorePart part , ThreadId tid , PtrdiffT guest_state_offset , SizeT size ) ) ;
extern void vgPlain_track_post_reg_write_clientcall_return(void (*f)(ThreadId tid , PtrdiffT guest_state_offset , SizeT size , Addr f ) ) ;
extern void vgPlain_track_start_client_code(void (*f)(ThreadId tid , ULong blocks_dispatched ) ) ;
extern void vgPlain_track_stop_client_code(void (*f)(ThreadId tid , ULong blocks_dispatched ) ) ;
extern void vgPlain_track_pre_thread_ll_create(void (*f)(ThreadId tid , ThreadId child ) ) ;
extern void vgPlain_track_pre_thread_first_insn(void (*f)(ThreadId tid ) ) ;
extern void vgPlain_track_pre_thread_ll_exit(void (*f)(ThreadId tid ) ) ;
extern void vgPlain_track_pre_deliver_signal(void (*f)(ThreadId tid , Int sigNo , Bool alt_stack ) ) ;
extern void vgPlain_track_post_deliver_signal(void (*f)(ThreadId tid , Int sigNo ) ) ;
extern Bool vgDrd_get_check_stack_accesses(void) ;
extern void vgDrd_set_check_stack_accesses(Bool c ) ;
extern Bool vgDrd_get_first_race_only(void) ;
extern void vgDrd_set_first_race_only(Bool fro ) ;
extern IRSB *vgDrd_instrument(VgCallbackClosure *closure , IRSB *bb_in , VexGuestLayout *layout , VexGuestExtents *vge , IRType gWordTy , IRType hWordTy ) ;
extern void vgDrd_trace_mem_access(Addr addr , SizeT size , BmAccessTypeT access_type ) ;
extern void ( __attribute__((__regparm__(2))) vgDrd_trace_load)(Addr addr , SizeT size ) ;
extern void ( __attribute__((__regparm__(2))) vgDrd_trace_store)(Addr addr , SizeT size ) ;
extern void vgDrd_clean_memory(Addr a1 , SizeT len ) ;
extern void vgDrd_register_malloc_wrappers(void (*start_callback)(Addr a1 , SizeT len , UInt ec_uniq ) , void (*stop_callback)(Addr a1 , SizeT len ) ) ;
extern void vgDrd_malloclike_block(ThreadId tid , Addr p , SizeT size ) ;
extern Bool vgDrd_freelike_block(ThreadId tid , Addr p ) ;
extern Bool vgDrd_heap_addrinfo(Addr a , Addr *data , SizeT *size , ExeContext **where ) ;
extern void vgDrd_print_malloc_stats(void) ;
extern void vgDrd_mutex_set_trace(Bool trace_mutex ) ;
extern void vgDrd_mutex_set_lock_threshold(UInt lock_threshold_ms ) ;
extern struct mutex_info *vgDrd_mutex_init(Addr mutex , MutexT mutex_type ) ;
extern void vgDrd_mutex_post_destroy(Addr mutex ) ;
extern void vgDrd_not_a_mutex(Addr mutex ) ;
extern struct mutex_info *vgDrd_mutex_get(Addr mutex ) ;
extern void vgDrd_mutex_pre_lock(Addr mutex , MutexT mutex_type , Bool trylock ) ;
extern void vgDrd_mutex_post_lock(Addr mutex , Bool took_lock , Bool post_cond_wait ) ;
extern void vgDrd_mutex_unlock(Addr mutex , MutexT mutex_type ) ;
extern void vgDrd_spinlock_init_or_unlock(Addr spinlock ) ;
extern char const   *vgDrd_mutex_get_typename(struct mutex_info *p ) ;
extern char const   *vgDrd_mutex_type_name(MutexT mt ) ;
extern Bool vgDrd_mutex_is_locked_by(Addr mutex , DrdThreadId tid ) ;
extern int vgDrd_mutex_get_recursion_count(Addr mutex ) ;
extern ULong vgDrd_get_mutex_lock_count(void) ;
extern ULong vgDrd_get_mutex_segment_creation_count(void) ;
extern XArray *vgPlain_newXA(void *(*alloc_fn)(HChar * , SizeT  ) , HChar *cc , void (*free_fn)(void * ) , Word elemSzB ) ;
extern void vgPlain_deleteXA(XArray * ) ;
extern void vgPlain_setCmpFnXA(XArray * , Int (*compar)(void * , void * ) ) ;
extern Word vgPlain_addToXA(XArray * , void *elem ) ;
extern Word vgPlain_addBytesToXA(XArray *xao , void *bytesV , Word nbytes ) ;
extern void vgPlain_sortXA(XArray * ) ;
extern Bool vgPlain_lookupXA(XArray * , void *key , Word *first , Word *last ) ;
extern Bool vgPlain_lookupXA_UNSAFE(XArray *xao , void *key , Word *first , Word *last , Int (*cmpFn)(void * , void * ) ) ;
extern Word vgPlain_sizeXA(XArray * ) ;
extern void *vgPlain_indexXA(XArray * , Word  ) ;
extern void vgPlain_dropTailXA(XArray * , Word  ) ;
extern void vgPlain_dropHeadXA(XArray * , Word  ) ;
extern XArray *vgPlain_cloneXA(HChar *cc , XArray *xa ) ;
extern void vgPlain_getContentsXA_UNSAFE(XArray *sr , void **ctsP , Word *usedP ) ;
extern void ( /* format attribute */  vgPlain_xaprintf)(XArray *dst , HChar const   *format  , ...) ;
extern void vgPlain_xaprintf_no_f_c(XArray *dst , HChar const   *format  , ...) ;
extern void vgDrd_clientobj_set_trace(Bool trace ) ;
extern void vgDrd_clientobj_init(void) ;
extern void vgDrd_clientobj_cleanup(void) ;
extern DrdClientobj *vgDrd_clientobj_get_any(Addr addr ) ;
extern DrdClientobj *vgDrd_clientobj_get(Addr addr , ObjType t ) ;
extern Bool vgDrd_clientobj_present(Addr a1 , Addr a2 ) ;
extern DrdClientobj *vgDrd_clientobj_add(Addr a1 , ObjType t ) ;
extern Bool vgDrd_clientobj_remove(Addr addr , ObjType t ) ;
extern void vgDrd_clientobj_stop_using_mem(Addr a1 , Addr a2 ) ;
extern void vgDrd_clientobj_delete_thread(DrdThreadId tid ) ;
extern char const   *vgDrd_clientobj_type_name(ObjType t ) ;
extern void vgDrd_rwlock_set_trace(Bool trace_rwlock ) ;
extern void vgDrd_rwlock_set_exclusive_threshold(UInt exclusive_threshold_ms ) ;
extern void vgDrd_rwlock_set_shared_threshold(UInt shared_threshold_ms ) ;
extern struct rwlock_info *vgDrd_rwlock_pre_init(Addr rwlock , RwLockT rwlock_type ) ;
extern void vgDrd_rwlock_post_destroy(Addr rwlock , RwLockT rwlock_type ) ;
extern void vgDrd_rwlock_pre_rdlock(Addr rwlock , RwLockT rwlock_type ) ;
extern void vgDrd_rwlock_post_rdlock(Addr rwlock , RwLockT rwlock_type , Bool took_lock ) ;
extern void vgDrd_rwlock_pre_wrlock(Addr rwlock , RwLockT rwlock_type ) ;
extern void vgDrd_rwlock_post_wrlock(Addr rwlock , RwLockT rwlock_type , Bool took_lock ) ;
extern void vgDrd_rwlock_pre_unlock(Addr rwlock , RwLockT rwlock_type ) ;
extern ULong vgDrd_get_rwlock_segment_creation_count(void) ;
extern void vgDrd_semaphore_set_trace(Bool trace_semaphore ) ;
extern struct semaphore_info *vgDrd_semaphore_init(Addr semaphore , Word pshared , UInt value ) ;
extern void vgDrd_semaphore_destroy(Addr semaphore ) ;
extern struct semaphore_info *vgDrd_semaphore_open(Addr semaphore , Char const   *name , Word oflag , Word mode , UInt value ) ;
extern void vgDrd_semaphore_close(Addr semaphore ) ;
extern void vgDrd_semaphore_pre_wait(Addr semaphore ) ;
extern void vgDrd_semaphore_post_wait(DrdThreadId tid , Addr semaphore , Bool waited ) ;
extern void vgDrd_semaphore_pre_post(DrdThreadId tid , Addr semaphore ) ;
extern void vgDrd_semaphore_post_post(DrdThreadId tid , Addr semaphore , Bool waited ) ;
extern ULong vgDrd_get_semaphore_segment_creation_count(void) ;
extern Bool vgDrd_g_any_address_traced ;
extern void vgDrd_suppression_set_trace(Bool trace_suppression ) ;
extern void vgDrd_suppression_init(void) ;
extern void vgDrd_start_suppression(Addr a1 , Addr a2 , char const   *reason ) ;
extern void vgDrd_finish_suppression(Addr a1 , Addr a2 ) ;
extern Bool vgDrd_is_suppressed(Addr a1 , Addr a2 ) ;
extern Bool vgDrd_is_any_suppressed(Addr a1 , Addr a2 ) ;
extern void vgDrd_mark_hbvar(Addr a1 ) ;
extern Bool vgDrd_range_contains_suppression_or_hbvar(Addr a1 , Addr a2 ) ;
extern void vgDrd_start_tracing_address_range(Addr a1 , Addr a2 ) ;
extern void vgDrd_stop_tracing_address_range(Addr a1 , Addr a2 ) ;
extern Bool vgDrd_is_any_traced(Addr a1 , Addr a2 ) ;
extern void vgDrd_suppression_stop_using_mem(Addr a1 , Addr a2 ) ;
__inline static Bool vgDrd_any_address_is_traced(void) 
{ 

  {
  return (vgDrd_g_any_address_traced);
}
}
extern UInt ( /* format attribute */  vgPlain_sprintf)(Char *buf , HChar const   *format  , ...) ;
extern UInt ( /* format attribute */  vgPlain_vsprintf)(Char *buf , HChar const   *format , va_list vargs ) ;
extern UInt ( /* format attribute */  vgPlain_snprintf)(Char *buf , Int size , HChar const   *format  , ...) ;
extern UInt ( /* format attribute */  vgPlain_vsnprintf)(Char *buf , Int size , HChar const   *format , va_list vargs ) ;
extern void vgPlain_percentify(ULong n , ULong m , UInt d , Int n_buf , char *buf ) ;
extern UInt ( /* format attribute */  vgPlain_printf)(HChar const   *format  , ...) ;
extern UInt ( /* format attribute */  vgPlain_vprintf)(HChar const   *format , va_list vargs ) ;
extern UInt ( /* format attribute */  vgPlain_printf_xml)(HChar const   *format  , ...) ;
extern UInt ( /* format attribute */  vgPlain_vprintf_xml)(HChar const   *format , va_list vargs ) ;
extern UInt vgPlain_printf_xml_no_f_c(HChar const   *format  , ...) ;
extern void vgPlain_vcbprintf(void (*char_sink)(HChar  , void *opaque ) , void *opaque , HChar const   *format , va_list vargs ) ;
extern UInt vgPlain_message_no_f_c(VgMsgKind kind , HChar const   *format  , ...) ;
extern UInt ( /* format attribute */  vgPlain_message)(VgMsgKind kind , HChar const   *format  , ...) ;
extern UInt ( /* format attribute */  vgPlain_vmessage)(VgMsgKind kind , HChar const   *format , va_list vargs ) ;
extern UInt ( /* format attribute */  vgPlain_fmsg)(HChar const   *format  , ...) ;
extern  __attribute__((__noreturn__)) void ( /* format attribute */  vgPlain_fmsg_bad_option)(HChar *opt , HChar const   *format  , ...) ;
extern UInt ( /* format attribute */  vgPlain_umsg)(HChar const   *format  , ...) ;
extern UInt ( /* format attribute */  vgPlain_dmsg)(HChar const   *format  , ...) ;
extern void vgPlain_message_flush(void) ;
extern Addr vgPlain_get_IP(ThreadId tid ) ;
extern Addr vgPlain_get_SP(ThreadId tid ) ;
extern void vgPlain_get_shadow_regs_area(ThreadId tid , UChar *dst , Int shadowNo , PtrdiffT offset , SizeT size ) ;
extern void vgPlain_set_shadow_regs_area(ThreadId tid , Int shadowNo , PtrdiffT offset , SizeT size , UChar const   *src ) ;
extern void vgPlain_set_syscall_return_shadows(ThreadId tid , UWord s1res , UWord s2res , UWord s1err , UWord s2err ) ;
extern void vgPlain_apply_to_GP_regs(void (*f)(UWord val ) ) ;
extern void vgPlain_thread_stack_reset_iter(ThreadId *tid ) ;
extern Bool vgPlain_thread_stack_next(ThreadId *tid , Addr *stack_min , Addr *stack_max ) ;
extern Addr vgPlain_thread_get_stack_max(ThreadId tid ) ;
extern SizeT vgPlain_thread_get_stack_size(ThreadId tid ) ;
extern Addr vgPlain_thread_get_altstack_min(ThreadId tid ) ;
extern SizeT vgPlain_thread_get_altstack_size(ThreadId tid ) ;
extern void *vgPlain_fnptr_to_fnentry(void * ) ;
static Bool handle_client_request(ThreadId vg_tid , UWord *arg , UWord *ret ) ;
void vgDrd_clientreq_init(void) 
{ 

  {
  vgPlain_needs_client_requests(& handle_client_request);
  return;
}
}
static Bool handle_client_request(ThreadId vg_tid , UWord *arg , UWord *ret ) 
{ UWord result ;
  DrdThreadId drd_tid ;
  DrdThreadId tmp ;
  ThreadId tmp___0 ;
  DrdThreadId tmp___1 ;
  GenericErrInfo GEI ;
  DrdThreadId tmp___2 ;
  Addr tmp___3 ;
  Bool tmp___4 ;
  struct mutex_info *mutex_p ;
  struct mutex_info *tmp___5 ;
  struct mutex_info *mutex_p___0 ;
  struct mutex_info *tmp___6 ;
  struct mutex_info *mutex_p___1 ;
  struct mutex_info *tmp___7 ;
  struct mutex_info *mutex_p___2 ;
  struct mutex_info *tmp___8 ;
  DrdThreadId tmp___9 ;
  DrdThreadId tmp___10 ;
  DrdThreadId thread_to_join ;
  DrdThreadId tmp___11 ;
  InvalidThreadIdInfo ITI ;
  DrdThreadId tmp___12 ;
  Addr tmp___13 ;
  DrdThreadId thread_to_cancel ;
  DrdThreadId tmp___14 ;
  InvalidThreadIdInfo ITI___0 ;
  DrdThreadId tmp___15 ;
  Addr tmp___16 ;
  int tmp___17 ;
  int tmp___18 ;
  int tmp___19 ;
  int tmp___20 ;
  int tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;
  int tmp___24 ;
  Addr cond ;
  Addr mutex ;
  MutexT mutex_type ;
  int tmp___25 ;
  Addr cond___0 ;
  Addr mutex___0 ;
  Bool took_lock ;
  int tmp___26 ;
  int tmp___27 ;
  int tmp___28 ;
  int tmp___29 ;
  int tmp___30 ;
  int tmp___31 ;
  int tmp___32 ;
  int tmp___33 ;
  int tmp___34 ;
  int tmp___35 ;
  int tmp___36 ;
  int tmp___37 ;
  int tmp___38 ;
  int tmp___39 ;
  int tmp___40 ;
  int tmp___41 ;
  int tmp___42 ;
  int tmp___43 ;
  int tmp___44 ;
  int tmp___45 ;
  UnimpClReqInfo UICR ;
  DrdThreadId tmp___46 ;
  Addr tmp___47 ;
  UnimpClReqInfo UICR___0 ;
  DrdThreadId tmp___48 ;
  Addr tmp___49 ;

  {
  result = (UWord )0;
  tmp = vgDrd_thread_get_running_tid();
  drd_tid = tmp;
  tmp___0 = vgPlain_get_running_tid();
  if (vg_tid == tmp___0) {

  } else {
    vgPlain_assert_fail((unsigned char)0, (Char const   *)"vg_tid == VG_(get_running_tid())", (Char const   *)"drd_clientreq.c", 73, (Char const   *)"handle_client_request", "");
  }
  tmp___1 = vgDrd_VgThreadIdToDrdThreadId(vg_tid);
  if (tmp___1 == drd_tid) {

  } else {
    vgPlain_assert_fail((unsigned char)0, (Char const   *)"DRD_(VgThreadIdToDrdThreadId)(vg_tid) == drd_tid", (Char const   *)"drd_clientreq.c", 74, (Char const   *)"handle_client_request", "");
  }
  switch ((int )*(arg + 0)) {
  case 4865: 
  if (*(arg + 1)) {
    vgDrd_malloclike_block(vg_tid, *(arg + 1), *(arg + 2));
  } else {

  }
  break;
  case 4866: 
  if (*(arg + 1)) {
    tmp___4 = vgDrd_freelike_block(vg_tid, *(arg + 1));
    if (tmp___4) {

    } else {
      tmp___2 = vgDrd_thread_get_running_tid();
      GEI.tid = tmp___2;
      GEI.addr = (Addr )0;
      tmp___3 = vgPlain_get_IP(vg_tid);
      vgPlain_maybe_record_error(vg_tid, 11, tmp___3, (Char *)"Invalid VG_USERREQ__FREELIKE_BLOCK request", (void *)(& GEI));
    }
  } else {

  }
  break;
  case 1146224640: 
  result = (unsigned long )vg_tid;
  break;
  case 1146224641: 
  result = (unsigned long )drd_tid;
  break;
  case 1146224648: 
  vgDrd_thread_set_name(drd_tid, (char const   *)*(arg + 1));
  break;
  case 1146224642: 
  case ((unsigned int )((72 << 24) | (71 << 16)) + 256U) + 39U: 
  vgDrd_start_suppression(*(arg + 1), *(arg + 1) + *(arg + 2), "client");
  break;
  case 1146224643: 
  case ((unsigned int )((72 << 24) | (71 << 16)) + 256U) + 40U: 
  vgDrd_finish_suppression(*(arg + 1), *(arg + 1) + *(arg + 2));
  break;
  case 1212612897: 
  vgDrd_hb_happens_before(drd_tid, *(arg + 1));
  break;
  case 1212612898: 
  vgDrd_hb_happens_after(drd_tid, *(arg + 1));
  break;
  case 1212612878: 
  if (*(arg + 1)) {
    tmp___5 = vgDrd_mutex_get(*(arg + 1));
    mutex_p = tmp___5;
    if (mutex_p) {
      if ((int )mutex_p->mutex_type == 4) {
        break;
      } else {

      }
    } else {

    }
  } else {

  }
  vgDrd_rwlock_pre_init(*(arg + 1), (enum __anonenum_RwLockT_9 )2);
  break;
  case 1212612879: 
  if (*(arg + 1)) {
    tmp___6 = vgDrd_mutex_get(*(arg + 1));
    mutex_p___0 = tmp___6;
    if (mutex_p___0) {
      if ((int )mutex_p___0->mutex_type == 4) {
        break;
      } else {

      }
    } else {

    }
  } else {

  }
  vgDrd_rwlock_post_destroy(*(arg + 1), (enum __anonenum_RwLockT_9 )2);
  break;
  case 1212612881: 
  if (*(arg + 1)) {
    tmp___7 = vgDrd_mutex_get(*(arg + 1));
    mutex_p___1 = tmp___7;
    if (mutex_p___1) {
      if ((int )mutex_p___1->mutex_type == 4) {
        break;
      } else {

      }
    } else {

    }
  } else {

  }
  if (*(arg + 2) == (UWord )(! (! *(arg + 2)))) {

  } else {
    vgPlain_assert_fail((unsigned char)0, (Char const   *)"arg[2] == !! arg[2]", (Char const   *)"drd_clientreq.c", 157, (Char const   *)"handle_client_request", "");
  }
  if (*(arg + 2)) {
    vgDrd_rwlock_pre_wrlock(*(arg + 1), (enum __anonenum_RwLockT_9 )2);
    vgDrd_rwlock_post_wrlock(*(arg + 1), (enum __anonenum_RwLockT_9 )2, (unsigned char)1);
  } else {
    vgDrd_rwlock_pre_rdlock(*(arg + 1), (enum __anonenum_RwLockT_9 )2);
    vgDrd_rwlock_post_rdlock(*(arg + 1), (enum __anonenum_RwLockT_9 )2, (unsigned char)1);
  }
  break;
  case 1212612882: 
  if (*(arg + 1)) {
    tmp___8 = vgDrd_mutex_get(*(arg + 1));
    mutex_p___2 = tmp___8;
    if (mutex_p___2) {
      if ((int )mutex_p___2->mutex_type == 4) {
        break;
      } else {

      }
    } else {

    }
  } else {

  }
  if (*(arg + 2) == (UWord )(! (! *(arg + 2)))) {

  } else {
    vgPlain_assert_fail((unsigned char)0, (Char const   *)"arg[2] == !! arg[2]", (Char const   *)"drd_clientreq.c", 177, (Char const   *)"handle_client_request", "");
  }
  vgDrd_rwlock_pre_unlock(*(arg + 1), (enum __anonenum_RwLockT_9 )2);
  break;
  case 1148321792: 
  vgDrd_pthread_cond_initializer = *(arg + 1);
  vgDrd_pthread_cond_initializer_size = (int )*(arg + 2);
  break;
  case 1148321793: 
  tmp___9 = vgDrd_PtThreadIdToDrdThreadId(*(arg + 1));
  vgDrd_thread_new_segment(tmp___9);
  break;
  case 1146224644: 
  vgDrd_start_tracing_address_range(*(arg + 1), *(arg + 1) + *(arg + 2));
  break;
  case 1146224645: 
  vgDrd_stop_tracing_address_range(*(arg + 1), *(arg + 1) + *(arg + 2));
  break;
  case 1146224646: 
  vgDrd_thread_set_record_loads(drd_tid, (unsigned char )*(arg + 1));
  break;
  case 1146224647: 
  vgDrd_thread_set_record_stores(drd_tid, (unsigned char )*(arg + 1));
  break;
  case 1148321794: 
  if (*(arg + 1) != 0UL) {
    vgDrd_thread_set_pthreadid(drd_tid, *(arg + 1));
  } else {

  }
  break;
  case 1148321795: 
  tmp___10 = vgDrd_PtThreadIdToDrdThreadId(*(arg + 1));
  vgDrd_thread_set_joinable(tmp___10, (unsigned char )*(arg + 2));
  break;
  case 1148321796: 
  vgDrd_thread_entering_pthread_create(drd_tid);
  break;
  case 1148321797: 
  vgDrd_thread_left_pthread_create(drd_tid);
  break;
  case 1148321798: 
  tmp___11 = vgDrd_PtThreadIdToDrdThreadId(*(arg + 1));
  thread_to_join = tmp___11;
  if (thread_to_join == 0U) {
    tmp___12 = vgDrd_thread_get_running_tid();
    ITI.tid = tmp___12;
    ITI.ptid = (ULong )*(arg + 1);
    tmp___13 = vgPlain_get_IP(vg_tid);
    vgPlain_maybe_record_error(vg_tid, 12, tmp___13, (Char *)"pthread_join(): invalid thread ID", (void *)(& ITI));
  } else {
    vgDrd_thread_post_join(drd_tid, thread_to_join);
  }
  break;
  case 1148321799: 
  tmp___14 = vgDrd_PtThreadIdToDrdThreadId(*(arg + 1));
  thread_to_cancel = tmp___14;
  if (thread_to_cancel == 0U) {
    tmp___15 = vgDrd_thread_get_running_tid();
    ITI___0.tid = tmp___15;
    ITI___0.ptid = (ULong )*(arg + 1);
    tmp___16 = vgPlain_get_IP(vg_tid);
    vgPlain_maybe_record_error(vg_tid, 12, tmp___16, (Char *)"pthread_cancel(): invalid thread ID", (void *)(& ITI___0));
  } else {
    vgDrd_thread_pre_cancel(thread_to_cancel);
  }
  break;
  case 1148321800: 
  break;
  case 1148321801: 
  tmp___17 = vgDrd_thread_enter_synchr(drd_tid);
  if (tmp___17 == 0) {
    vgDrd_mutex_init(*(arg + 1), (enum __anonenum_MutexT_8 )*(arg + 2));
  } else {

  }
  break;
  case 1148321802: 
  vgDrd_thread_leave_synchr(drd_tid);
  break;
  case 1148321803: 
  vgDrd_thread_enter_synchr(drd_tid);
  break;
  case 1148321804: 
  tmp___18 = vgDrd_thread_leave_synchr(drd_tid);
  if (tmp___18 == 0) {
    vgDrd_mutex_post_destroy(*(arg + 1));
  } else {

  }
  break;
  case 1148321805: 
  tmp___19 = vgDrd_thread_enter_synchr(drd_tid);
  if (tmp___19 == 0) {
    vgDrd_mutex_pre_lock(*(arg + 1), (enum __anonenum_MutexT_8 )*(arg + 2), (unsigned char )*(arg + 3));
  } else {

  }
  break;
  case 1148321806: 
  tmp___20 = vgDrd_thread_leave_synchr(drd_tid);
  if (tmp___20 == 0) {
    vgDrd_mutex_post_lock(*(arg + 1), (unsigned char )*(arg + 2), (unsigned char)0);
  } else {

  }
  break;
  case 1148321807: 
  tmp___21 = vgDrd_thread_enter_synchr(drd_tid);
  if (tmp___21 == 0) {
    vgDrd_mutex_unlock(*(arg + 1), (enum __anonenum_MutexT_8 )*(arg + 2));
  } else {

  }
  break;
  case 1148321808: 
  vgDrd_thread_leave_synchr(drd_tid);
  break;
  case 1148321809: 
  tmp___22 = vgDrd_thread_enter_synchr(drd_tid);
  if (tmp___22 == 0) {
    vgDrd_spinlock_init_or_unlock(*(arg + 1));
  } else {

  }
  break;
  case 1148321810: 
  vgDrd_thread_leave_synchr(drd_tid);
  break;
  case 1148321811: 
  tmp___23 = vgDrd_thread_enter_synchr(drd_tid);
  if (tmp___23 == 0) {
    vgDrd_cond_pre_init(*(arg + 1));
  } else {

  }
  break;
  case 1148321812: 
  vgDrd_thread_leave_synchr(drd_tid);
  break;
  case 1148321813: 
  vgDrd_thread_enter_synchr(drd_tid);
  break;
  case 1148321814: 
  tmp___24 = vgDrd_thread_leave_synchr(drd_tid);
  if (tmp___24 == 0) {
    vgDrd_cond_post_destroy(*(arg + 1));
  } else {

  }
  break;
  case 1148321815: 
  tmp___25 = vgDrd_thread_enter_synchr(drd_tid);
  if (tmp___25 == 0) {
    cond = *(arg + 1);
    mutex = *(arg + 2);
    mutex_type = (MutexT )*(arg + 3);
    vgDrd_mutex_unlock(mutex, mutex_type);
    vgDrd_cond_pre_wait(cond, mutex);
  } else {

  }
  break;
  case 1148321816: 
  tmp___26 = vgDrd_thread_leave_synchr(drd_tid);
  if (tmp___26 == 0) {
    cond___0 = *(arg + 1);
    mutex___0 = *(arg + 2);
    took_lock = (Bool )*(arg + 3);
    vgDrd_cond_post_wait(cond___0);
    vgDrd_mutex_post_lock(mutex___0, took_lock, (unsigned char)1);
  } else {

  }
  break;
  case 1148321817: 
  tmp___27 = vgDrd_thread_enter_synchr(drd_tid);
  if (tmp___27 == 0) {
    vgDrd_cond_pre_signal(*(arg + 1));
  } else {

  }
  break;
  case 1148321818: 
  vgDrd_thread_leave_synchr(drd_tid);
  break;
  case 1148321819: 
  tmp___28 = vgDrd_thread_enter_synchr(drd_tid);
  if (tmp___28 == 0) {
    vgDrd_cond_pre_broadcast(*(arg + 1));
  } else {

  }
  break;
  case 1148321820: 
  vgDrd_thread_leave_synchr(drd_tid);
  break;
  case 1148321821: 
  tmp___29 = vgDrd_thread_enter_synchr(drd_tid);
  if (tmp___29 == 0) {
    vgDrd_semaphore_init(*(arg + 1), (long )*(arg + 2), (unsigned int )*(arg + 3));
  } else {

  }
  break;
  case 1148321822: 
  vgDrd_thread_leave_synchr(drd_tid);
  break;
  case 1148321823: 
  vgDrd_thread_enter_synchr(drd_tid);
  break;
  case 1148321824: 
  tmp___30 = vgDrd_thread_leave_synchr(drd_tid);
  if (tmp___30 == 0) {
    vgDrd_semaphore_destroy(*(arg + 1));
  } else {

  }
  break;
  case 1148321825: 
  vgDrd_thread_enter_synchr(drd_tid);
  break;
  case 1148321826: 
  tmp___31 = vgDrd_thread_leave_synchr(drd_tid);
  if (tmp___31 == 0) {
    vgDrd_semaphore_open(*(arg + 1), (Char const   *)((Char *)*(arg + 2)), (long )*(arg + 3), (long )*(arg + 4), (unsigned int )*(arg + 5));
  } else {

  }
  break;
  case 1148321827: 
  tmp___32 = vgDrd_thread_enter_synchr(drd_tid);
  if (tmp___32 == 0) {
    vgDrd_semaphore_close(*(arg + 1));
  } else {

  }
  break;
  case 1148321828: 
  vgDrd_thread_leave_synchr(drd_tid);
  break;
  case 1148321829: 
  tmp___33 = vgDrd_thread_enter_synchr(drd_tid);
  if (tmp___33 == 0) {
    vgDrd_semaphore_pre_wait(*(arg + 1));
  } else {

  }
  break;
  case 1148321830: 
  tmp___34 = vgDrd_thread_leave_synchr(drd_tid);
  if (tmp___34 == 0) {
    vgDrd_semaphore_post_wait(drd_tid, *(arg + 1), (unsigned char )*(arg + 2));
  } else {

  }
  break;
  case 1148321831: 
  tmp___35 = vgDrd_thread_enter_synchr(drd_tid);
  if (tmp___35 == 0) {
    vgDrd_semaphore_pre_post(drd_tid, *(arg + 1));
  } else {

  }
  break;
  case 1148321832: 
  tmp___36 = vgDrd_thread_leave_synchr(drd_tid);
  if (tmp___36 == 0) {
    vgDrd_semaphore_post_post(drd_tid, *(arg + 1), (unsigned char )*(arg + 2));
  } else {

  }
  break;
  case 1148321833: 
  tmp___37 = vgDrd_thread_enter_synchr(drd_tid);
  if (tmp___37 == 0) {
    vgDrd_barrier_init(*(arg + 1), (enum __anonenum_BarrierT_10 )*(arg + 2), (long )*(arg + 3), (unsigned char )*(arg + 4));
  } else {

  }
  break;
  case 1148321834: 
  vgDrd_thread_leave_synchr(drd_tid);
  break;
  case 1148321835: 
  vgDrd_thread_enter_synchr(drd_tid);
  break;
  case 1148321836: 
  tmp___38 = vgDrd_thread_leave_synchr(drd_tid);
  if (tmp___38 == 0) {
    vgDrd_barrier_destroy(*(arg + 1), (enum __anonenum_BarrierT_10 )*(arg + 2));
  } else {

  }
  break;
  case 1148321837: 
  tmp___39 = vgDrd_thread_enter_synchr(drd_tid);
  if (tmp___39 == 0) {
    vgDrd_barrier_pre_wait(drd_tid, *(arg + 1), (enum __anonenum_BarrierT_10 )*(arg + 2));
  } else {

  }
  break;
  case 1148321838: 
  tmp___40 = vgDrd_thread_leave_synchr(drd_tid);
  if (tmp___40 == 0) {
    vgDrd_barrier_post_wait(drd_tid, *(arg + 1), (enum __anonenum_BarrierT_10 )*(arg + 2), (unsigned char )*(arg + 3), (unsigned char )*(arg + 4));
  } else {

  }
  break;
  case 1148321839: 
  vgDrd_rwlock_pre_init(*(arg + 1), (enum __anonenum_RwLockT_9 )1);
  break;
  case 1148321840: 
  vgDrd_rwlock_post_destroy(*(arg + 1), (enum __anonenum_RwLockT_9 )1);
  break;
  case 1148321841: 
  tmp___41 = vgDrd_thread_enter_synchr(drd_tid);
  if (tmp___41 == 0) {
    vgDrd_rwlock_pre_rdlock(*(arg + 1), (enum __anonenum_RwLockT_9 )1);
  } else {

  }
  break;
  case 1148321842: 
  tmp___42 = vgDrd_thread_leave_synchr(drd_tid);
  if (tmp___42 == 0) {
    vgDrd_rwlock_post_rdlock(*(arg + 1), (enum __anonenum_RwLockT_9 )1, (unsigned char )*(arg + 2));
  } else {

  }
  break;
  case 1148321843: 
  tmp___43 = vgDrd_thread_enter_synchr(drd_tid);
  if (tmp___43 == 0) {
    vgDrd_rwlock_pre_wrlock(*(arg + 1), (enum __anonenum_RwLockT_9 )1);
  } else {

  }
  break;
  case 1148321844: 
  tmp___44 = vgDrd_thread_leave_synchr(drd_tid);
  if (tmp___44 == 0) {
    vgDrd_rwlock_post_wrlock(*(arg + 1), (enum __anonenum_RwLockT_9 )1, (unsigned char )*(arg + 2));
  } else {

  }
  break;
  case 1148321845: 
  tmp___45 = vgDrd_thread_enter_synchr(drd_tid);
  if (tmp___45 == 0) {
    vgDrd_rwlock_pre_unlock(*(arg + 1), (enum __anonenum_RwLockT_9 )1);
  } else {

  }
  break;
  case 1148321846: 
  vgDrd_thread_leave_synchr(drd_tid);
  break;
  case 1212612608: 
  if (*(arg + 2) > 0UL) {
    vgDrd_clean_memory(*(arg + 1), *(arg + 2));
  } else {

  }
  break;
  case 1212612896: 
  tmp___46 = vgDrd_thread_get_running_tid();
  UICR.tid = tmp___46;
  UICR.descr = (Char *)*(arg + 1);
  tmp___47 = vgPlain_get_IP(vg_tid);
  vgPlain_maybe_record_error(vg_tid, 13, tmp___47, (Char *)"", (void *)(& UICR));
  break;
  case 1146224649: 
  tmp___48 = vgDrd_thread_get_running_tid();
  UICR___0.tid = tmp___48;
  UICR___0.descr = (Char *)*(arg + 1);
  tmp___49 = vgPlain_get_IP(vg_tid);
  vgPlain_maybe_record_error(vg_tid, 14, tmp___49, (Char *)"", (void *)(& UICR___0));
  break;
  default: ;
  return ((unsigned char)0);
  }
  *ret = result;
  return ((unsigned char)1);
}
}
