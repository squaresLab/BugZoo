typedef unsigned char __u_char;
typedef unsigned short __u_short;
typedef unsigned int __u_int;
typedef unsigned long __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;
typedef long long __quad_t;
typedef unsigned long long __u_quad_t;
typedef __u_quad_t __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef __u_quad_t __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long __off_t;
typedef __quad_t __off64_t;
typedef int __pid_t;
struct __anonstruct___fsid_t_1 {
   int __val[2] ;
};
typedef struct __anonstruct___fsid_t_1 __fsid_t;
typedef long __clock_t;
typedef unsigned long __rlim_t;
typedef __u_quad_t __rlim64_t;
typedef unsigned int __id_t;
typedef long __time_t;
typedef unsigned int __useconds_t;
typedef long __suseconds_t;
typedef int __daddr_t;
typedef long __swblk_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void *__timer_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef __quad_t __blkcnt64_t;
typedef unsigned long __fsblkcnt_t;
typedef __u_quad_t __fsblkcnt64_t;
typedef unsigned long __fsfilcnt_t;
typedef __u_quad_t __fsfilcnt64_t;
typedef int __ssize_t;
typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;
typedef int __intptr_t;
typedef unsigned int __socklen_t;
typedef unsigned int size_t;
typedef __time_t time_t;
struct timespec {
   __time_t tv_sec ;
   long tv_nsec ;
};
typedef __pid_t pid_t;
struct sched_param {
   int __sched_priority ;
};
struct __sched_param {
   int __sched_priority ;
};
typedef unsigned long __cpu_mask;
struct __anonstruct_cpu_set_t_2 {
   __cpu_mask __bits[1024U / (8U * sizeof(__cpu_mask ))] ;
};
typedef struct __anonstruct_cpu_set_t_2 cpu_set_t;
typedef __clock_t clock_t;
typedef __clockid_t clockid_t;
typedef __timer_t timer_t;
struct tm {
   int tm_sec ;
   int tm_min ;
   int tm_hour ;
   int tm_mday ;
   int tm_mon ;
   int tm_year ;
   int tm_wday ;
   int tm_yday ;
   int tm_isdst ;
   long tm_gmtoff ;
   char const   *tm_zone ;
};
struct itimerspec {
   struct timespec it_interval ;
   struct timespec it_value ;
};
struct sigevent;
struct sigevent;
struct __locale_data;
struct __locale_struct {
   struct __locale_data *__locales[13] ;
   unsigned short const   *__ctype_b ;
   int const   *__ctype_tolower ;
   int const   *__ctype_toupper ;
   char const   *__names[13] ;
};
typedef struct __locale_struct *__locale_t;
typedef __locale_t locale_t;
typedef unsigned long pthread_t;
union __anonunion_pthread_attr_t_3 {
   char __size[36] ;
   long __align ;
};
typedef union __anonunion_pthread_attr_t_3 pthread_attr_t;
struct __pthread_internal_slist {
   struct __pthread_internal_slist *__next ;
};
typedef struct __pthread_internal_slist __pthread_slist_t;
union __anonunion____missing_field_name_5 {
   int __spins ;
   __pthread_slist_t __list ;
};
struct __pthread_mutex_s {
   int __lock ;
   unsigned int __count ;
   int __owner ;
   int __kind ;
   unsigned int __nusers ;
   union __anonunion____missing_field_name_5 __annonCompField1 ;
};
union __anonunion_pthread_mutex_t_4 {
   struct __pthread_mutex_s __data ;
   char __size[24] ;
   long __align ;
};
typedef union __anonunion_pthread_mutex_t_4 pthread_mutex_t;
union __anonunion_pthread_mutexattr_t_6 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_mutexattr_t_6 pthread_mutexattr_t;
struct __anonstruct___data_8 {
   int __lock ;
   unsigned int __futex ;
   unsigned long long __total_seq ;
   unsigned long long __wakeup_seq ;
   unsigned long long __woken_seq ;
   void *__mutex ;
   unsigned int __nwaiters ;
   unsigned int __broadcast_seq ;
};
union __anonunion_pthread_cond_t_7 {
   struct __anonstruct___data_8 __data ;
   char __size[48] ;
   long long __align ;
};
typedef union __anonunion_pthread_cond_t_7 pthread_cond_t;
union __anonunion_pthread_condattr_t_9 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_condattr_t_9 pthread_condattr_t;
typedef unsigned int pthread_key_t;
typedef int pthread_once_t;
struct __anonstruct___data_11 {
   int __lock ;
   unsigned int __nr_readers ;
   unsigned int __readers_wakeup ;
   unsigned int __writer_wakeup ;
   unsigned int __nr_readers_queued ;
   unsigned int __nr_writers_queued ;
   unsigned char __flags ;
   unsigned char __shared ;
   unsigned char __pad1 ;
   unsigned char __pad2 ;
   int __writer ;
};
union __anonunion_pthread_rwlock_t_10 {
   struct __anonstruct___data_11 __data ;
   char __size[32] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlock_t_10 pthread_rwlock_t;
union __anonunion_pthread_rwlockattr_t_12 {
   char __size[8] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlockattr_t_12 pthread_rwlockattr_t;
typedef int volatile   pthread_spinlock_t;
union __anonunion_pthread_barrier_t_13 {
   char __size[20] ;
   long __align ;
};
typedef union __anonunion_pthread_barrier_t_13 pthread_barrier_t;
union __anonunion_pthread_barrierattr_t_14 {
   char __size[4] ;
   int __align ;
};
typedef union __anonunion_pthread_barrierattr_t_14 pthread_barrierattr_t;
typedef int __jmp_buf[6];
enum __anonenum_15 {
    PTHREAD_CREATE_JOINABLE = 0,
    PTHREAD_CREATE_DETACHED = 1
} ;
enum __anonenum_16 {
    PTHREAD_MUTEX_TIMED_NP = 0,
    PTHREAD_MUTEX_RECURSIVE_NP = 1,
    PTHREAD_MUTEX_ERRORCHECK_NP = 2,
    PTHREAD_MUTEX_ADAPTIVE_NP = 3,
    PTHREAD_MUTEX_NORMAL = 0,
    PTHREAD_MUTEX_RECURSIVE = 1,
    PTHREAD_MUTEX_ERRORCHECK = 2,
    PTHREAD_MUTEX_DEFAULT = 0,
    PTHREAD_MUTEX_FAST_NP = 0
} ;
enum __anonenum_17 {
    PTHREAD_MUTEX_STALLED = 0,
    PTHREAD_MUTEX_STALLED_NP = 0,
    PTHREAD_MUTEX_ROBUST = 1,
    PTHREAD_MUTEX_ROBUST_NP = 1
} ;
enum __anonenum_18 {
    PTHREAD_PRIO_NONE = 0,
    PTHREAD_PRIO_INHERIT = 1,
    PTHREAD_PRIO_PROTECT = 2
} ;
enum __anonenum_19 {
    PTHREAD_RWLOCK_PREFER_READER_NP = 0,
    PTHREAD_RWLOCK_PREFER_WRITER_NP = 1,
    PTHREAD_RWLOCK_PREFER_WRITER_NONRECURSIVE_NP = 2,
    PTHREAD_RWLOCK_DEFAULT_NP = 0
} ;
enum __anonenum_20 {
    PTHREAD_INHERIT_SCHED = 0,
    PTHREAD_EXPLICIT_SCHED = 1
} ;
enum __anonenum_21 {
    PTHREAD_SCOPE_SYSTEM = 0,
    PTHREAD_SCOPE_PROCESS = 1
} ;
enum __anonenum_22 {
    PTHREAD_PROCESS_PRIVATE = 0,
    PTHREAD_PROCESS_SHARED = 1
} ;
struct _pthread_cleanup_buffer {
   void (*__routine)(void * ) ;
   void *__arg ;
   int __canceltype ;
   struct _pthread_cleanup_buffer *__prev ;
};
enum __anonenum_23 {
    PTHREAD_CANCEL_ENABLE = 0,
    PTHREAD_CANCEL_DISABLE = 1
} ;
enum __anonenum_24 {
    PTHREAD_CANCEL_DEFERRED = 0,
    PTHREAD_CANCEL_ASYNCHRONOUS = 1
} ;
struct __anonstruct___cancel_jmp_buf_26 {
   __jmp_buf __cancel_jmp_buf ;
   int __mask_was_saved ;
};
struct __anonstruct___pthread_unwind_buf_t_25 {
   struct __anonstruct___cancel_jmp_buf_26 __cancel_jmp_buf[1] ;
   void *__pad[4] ;
};
typedef struct __anonstruct___pthread_unwind_buf_t_25  __attribute__((__aligned__)) __pthread_unwind_buf_t;
struct __pthread_cleanup_frame {
   void (*__cancel_routine)(void * ) ;
   void *__cancel_arg ;
   int __do_it ;
   int __cancel_type ;
};
struct __jmp_buf_tag;
struct __jmp_buf_tag;
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;
typedef __loff_t loff_t;
typedef __ino_t ino_t;
typedef __ino64_t ino64_t;
typedef __dev_t dev_t;
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __nlink_t nlink_t;
typedef __uid_t uid_t;
typedef __off_t off_t;
typedef __off64_t off64_t;
typedef __id_t id_t;
typedef __ssize_t ssize_t;
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;
typedef __key_t key_t;
typedef __useconds_t useconds_t;
typedef __suseconds_t suseconds_t;
typedef unsigned long ulong;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char u_int8_t;
typedef unsigned short u_int16_t;
typedef unsigned int u_int32_t;
typedef unsigned long long u_int64_t;
typedef int register_t;
typedef int __sig_atomic_t;
struct __anonstruct___sigset_t_27 {
   unsigned long __val[1024U / (8U * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_27 __sigset_t;
typedef __sigset_t sigset_t;
struct timeval {
   __time_t tv_sec ;
   __suseconds_t tv_usec ;
};
typedef long __fd_mask;
struct __anonstruct_fd_set_28 {
   __fd_mask fds_bits[1024 / (8 * (int )sizeof(__fd_mask ))] ;
};
typedef struct __anonstruct_fd_set_28 fd_set;
typedef __fd_mask fd_mask;
typedef __blksize_t blksize_t;
typedef __blkcnt_t blkcnt_t;
typedef __fsblkcnt_t fsblkcnt_t;
typedef __fsfilcnt_t fsfilcnt_t;
typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;
union __anonunion_sem_t_29 {
   char __size[16] ;
   long __align ;
};
typedef union __anonunion_sem_t_29 sem_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef signed char int_least8_t;
typedef short int_least16_t;
typedef int int_least32_t;
typedef long long int_least64_t;
typedef unsigned char uint_least8_t;
typedef unsigned short uint_least16_t;
typedef unsigned int uint_least32_t;
typedef unsigned long long uint_least64_t;
typedef signed char int_fast8_t;
typedef int int_fast16_t;
typedef int int_fast32_t;
typedef long long int_fast64_t;
typedef unsigned char uint_fast8_t;
typedef unsigned int uint_fast16_t;
typedef unsigned int uint_fast32_t;
typedef unsigned long long uint_fast64_t;
typedef int intptr_t;
typedef unsigned int uintptr_t;
typedef long long intmax_t;
typedef unsigned long long uintmax_t;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_31 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_30 {
   int __count ;
   union __anonunion___value_31 __value ;
};
typedef struct __anonstruct___mbstate_t_30 __mbstate_t;
struct __anonstruct__G_fpos_t_32 {
   __off_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos_t_32 _G_fpos_t;
struct __anonstruct__G_fpos64_t_33 {
   __off64_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos64_t_33 _G_fpos64_t;
typedef short _G_int16_t;
typedef int _G_int32_t;
typedef unsigned short _G_uint16_t;
typedef unsigned int _G_uint32_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_jump_t;
struct _IO_jump_t;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
enum __codecvt_result {
    __codecvt_ok = 0,
    __codecvt_partial = 1,
    __codecvt_error = 2,
    __codecvt_noconv = 3
} ;
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15U * sizeof(int ) - 4U * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
struct _IO_FILE_plus;
struct _IO_FILE_plus;
typedef __ssize_t __io_read_fn(void *__cookie , char *__buf , size_t __nbytes );
typedef __ssize_t __io_write_fn(void *__cookie , char const   *__buf , size_t __n );
typedef int __io_seek_fn(void *__cookie , __off64_t *__pos , int __w );
typedef int __io_close_fn(void *__cookie );
typedef __io_read_fn cookie_read_function_t;
typedef __io_write_fn cookie_write_function_t;
typedef __io_seek_fn cookie_seek_function_t;
typedef __io_close_fn cookie_close_function_t;
struct __anonstruct__IO_cookie_io_functions_t_34 {
   __io_read_fn *read ;
   __io_write_fn *write ;
   __io_seek_fn *seek ;
   __io_close_fn *close ;
};
typedef struct __anonstruct__IO_cookie_io_functions_t_34 _IO_cookie_io_functions_t;
typedef _IO_cookie_io_functions_t cookie_io_functions_t;
struct _IO_cookie_file;
struct _IO_cookie_file;
typedef __gnuc_va_list va_list;
typedef _G_fpos_t fpos_t;
typedef _G_fpos64_t fpos64_t;
struct obstack;
struct obstack;
typedef long wchar_t;
struct __anonstruct___wait_terminated_35 {
   unsigned int __w_termsig : 7 ;
   unsigned int __w_coredump : 1 ;
   unsigned int __w_retcode : 8 ;
   unsigned int  : 16 ;
};
struct __anonstruct___wait_stopped_36 {
   unsigned int __w_stopval : 8 ;
   unsigned int __w_stopsig : 8 ;
   unsigned int  : 16 ;
};
union wait {
   int w_status ;
   struct __anonstruct___wait_terminated_35 __wait_terminated ;
   struct __anonstruct___wait_stopped_36 __wait_stopped ;
};
union __anonunion___WAIT_STATUS_37 {
   union wait *__uptr ;
   int *__iptr ;
};
typedef union __anonunion___WAIT_STATUS_37  __attribute__((__transparent_union__)) __WAIT_STATUS;
struct __anonstruct_div_t_38 {
   int quot ;
   int rem ;
};
typedef struct __anonstruct_div_t_38 div_t;
struct __anonstruct_ldiv_t_39 {
   long quot ;
   long rem ;
};
typedef struct __anonstruct_ldiv_t_39 ldiv_t;
struct __anonstruct_lldiv_t_40 {
   long long quot ;
   long long rem ;
};
typedef struct __anonstruct_lldiv_t_40 lldiv_t;
struct random_data {
   int32_t *fptr ;
   int32_t *rptr ;
   int32_t *state ;
   int rand_type ;
   int rand_deg ;
   int rand_sep ;
   int32_t *end_ptr ;
};
struct drand48_data {
   unsigned short __x[3] ;
   unsigned short __old_x[3] ;
   unsigned short __c ;
   unsigned short __init ;
   unsigned long long __a ;
};
typedef int (*__compar_fn_t)(void const   * , void const   * );
typedef int (*comparison_fn_t)(void const   * , void const   * );
typedef int (*__compar_d_fn_t)(void const   * , void const   * , void * );
typedef __socklen_t socklen_t;
enum __anonenum_41 {
    _PC_LINK_MAX = 0,
    _PC_MAX_CANON = 1,
    _PC_MAX_INPUT = 2,
    _PC_NAME_MAX = 3,
    _PC_PATH_MAX = 4,
    _PC_PIPE_BUF = 5,
    _PC_CHOWN_RESTRICTED = 6,
    _PC_NO_TRUNC = 7,
    _PC_VDISABLE = 8,
    _PC_SYNC_IO = 9,
    _PC_ASYNC_IO = 10,
    _PC_PRIO_IO = 11,
    _PC_SOCK_MAXBUF = 12,
    _PC_FILESIZEBITS = 13,
    _PC_REC_INCR_XFER_SIZE = 14,
    _PC_REC_MAX_XFER_SIZE = 15,
    _PC_REC_MIN_XFER_SIZE = 16,
    _PC_REC_XFER_ALIGN = 17,
    _PC_ALLOC_SIZE_MIN = 18,
    _PC_SYMLINK_MAX = 19,
    _PC_2_SYMLINKS = 20
} ;
enum __anonenum_42 {
    _SC_ARG_MAX = 0,
    _SC_CHILD_MAX = 1,
    _SC_CLK_TCK = 2,
    _SC_NGROUPS_MAX = 3,
    _SC_OPEN_MAX = 4,
    _SC_STREAM_MAX = 5,
    _SC_TZNAME_MAX = 6,
    _SC_JOB_CONTROL = 7,
    _SC_SAVED_IDS = 8,
    _SC_REALTIME_SIGNALS = 9,
    _SC_PRIORITY_SCHEDULING = 10,
    _SC_TIMERS = 11,
    _SC_ASYNCHRONOUS_IO = 12,
    _SC_PRIORITIZED_IO = 13,
    _SC_SYNCHRONIZED_IO = 14,
    _SC_FSYNC = 15,
    _SC_MAPPED_FILES = 16,
    _SC_MEMLOCK = 17,
    _SC_MEMLOCK_RANGE = 18,
    _SC_MEMORY_PROTECTION = 19,
    _SC_MESSAGE_PASSING = 20,
    _SC_SEMAPHORES = 21,
    _SC_SHARED_MEMORY_OBJECTS = 22,
    _SC_AIO_LISTIO_MAX = 23,
    _SC_AIO_MAX = 24,
    _SC_AIO_PRIO_DELTA_MAX = 25,
    _SC_DELAYTIMER_MAX = 26,
    _SC_MQ_OPEN_MAX = 27,
    _SC_MQ_PRIO_MAX = 28,
    _SC_VERSION = 29,
    _SC_PAGESIZE = 30,
    _SC_RTSIG_MAX = 31,
    _SC_SEM_NSEMS_MAX = 32,
    _SC_SEM_VALUE_MAX = 33,
    _SC_SIGQUEUE_MAX = 34,
    _SC_TIMER_MAX = 35,
    _SC_BC_BASE_MAX = 36,
    _SC_BC_DIM_MAX = 37,
    _SC_BC_SCALE_MAX = 38,
    _SC_BC_STRING_MAX = 39,
    _SC_COLL_WEIGHTS_MAX = 40,
    _SC_EQUIV_CLASS_MAX = 41,
    _SC_EXPR_NEST_MAX = 42,
    _SC_LINE_MAX = 43,
    _SC_RE_DUP_MAX = 44,
    _SC_CHARCLASS_NAME_MAX = 45,
    _SC_2_VERSION = 46,
    _SC_2_C_BIND = 47,
    _SC_2_C_DEV = 48,
    _SC_2_FORT_DEV = 49,
    _SC_2_FORT_RUN = 50,
    _SC_2_SW_DEV = 51,
    _SC_2_LOCALEDEF = 52,
    _SC_PII = 53,
    _SC_PII_XTI = 54,
    _SC_PII_SOCKET = 55,
    _SC_PII_INTERNET = 56,
    _SC_PII_OSI = 57,
    _SC_POLL = 58,
    _SC_SELECT = 59,
    _SC_UIO_MAXIOV = 60,
    _SC_IOV_MAX = 60,
    _SC_PII_INTERNET_STREAM = 61,
    _SC_PII_INTERNET_DGRAM = 62,
    _SC_PII_OSI_COTS = 63,
    _SC_PII_OSI_CLTS = 64,
    _SC_PII_OSI_M = 65,
    _SC_T_IOV_MAX = 66,
    _SC_THREADS = 67,
    _SC_THREAD_SAFE_FUNCTIONS = 68,
    _SC_GETGR_R_SIZE_MAX = 69,
    _SC_GETPW_R_SIZE_MAX = 70,
    _SC_LOGIN_NAME_MAX = 71,
    _SC_TTY_NAME_MAX = 72,
    _SC_THREAD_DESTRUCTOR_ITERATIONS = 73,
    _SC_THREAD_KEYS_MAX = 74,
    _SC_THREAD_STACK_MIN = 75,
    _SC_THREAD_THREADS_MAX = 76,
    _SC_THREAD_ATTR_STACKADDR = 77,
    _SC_THREAD_ATTR_STACKSIZE = 78,
    _SC_THREAD_PRIORITY_SCHEDULING = 79,
    _SC_THREAD_PRIO_INHERIT = 80,
    _SC_THREAD_PRIO_PROTECT = 81,
    _SC_THREAD_PROCESS_SHARED = 82,
    _SC_NPROCESSORS_CONF = 83,
    _SC_NPROCESSORS_ONLN = 84,
    _SC_PHYS_PAGES = 85,
    _SC_AVPHYS_PAGES = 86,
    _SC_ATEXIT_MAX = 87,
    _SC_PASS_MAX = 88,
    _SC_XOPEN_VERSION = 89,
    _SC_XOPEN_XCU_VERSION = 90,
    _SC_XOPEN_UNIX = 91,
    _SC_XOPEN_CRYPT = 92,
    _SC_XOPEN_ENH_I18N = 93,
    _SC_XOPEN_SHM = 94,
    _SC_2_CHAR_TERM = 95,
    _SC_2_C_VERSION = 96,
    _SC_2_UPE = 97,
    _SC_XOPEN_XPG2 = 98,
    _SC_XOPEN_XPG3 = 99,
    _SC_XOPEN_XPG4 = 100,
    _SC_CHAR_BIT = 101,
    _SC_CHAR_MAX = 102,
    _SC_CHAR_MIN = 103,
    _SC_INT_MAX = 104,
    _SC_INT_MIN = 105,
    _SC_LONG_BIT = 106,
    _SC_WORD_BIT = 107,
    _SC_MB_LEN_MAX = 108,
    _SC_NZERO = 109,
    _SC_SSIZE_MAX = 110,
    _SC_SCHAR_MAX = 111,
    _SC_SCHAR_MIN = 112,
    _SC_SHRT_MAX = 113,
    _SC_SHRT_MIN = 114,
    _SC_UCHAR_MAX = 115,
    _SC_UINT_MAX = 116,
    _SC_ULONG_MAX = 117,
    _SC_USHRT_MAX = 118,
    _SC_NL_ARGMAX = 119,
    _SC_NL_LANGMAX = 120,
    _SC_NL_MSGMAX = 121,
    _SC_NL_NMAX = 122,
    _SC_NL_SETMAX = 123,
    _SC_NL_TEXTMAX = 124,
    _SC_XBS5_ILP32_OFF32 = 125,
    _SC_XBS5_ILP32_OFFBIG = 126,
    _SC_XBS5_LP64_OFF64 = 127,
    _SC_XBS5_LPBIG_OFFBIG = 128,
    _SC_XOPEN_LEGACY = 129,
    _SC_XOPEN_REALTIME = 130,
    _SC_XOPEN_REALTIME_THREADS = 131,
    _SC_ADVISORY_INFO = 132,
    _SC_BARRIERS = 133,
    _SC_BASE = 134,
    _SC_C_LANG_SUPPORT = 135,
    _SC_C_LANG_SUPPORT_R = 136,
    _SC_CLOCK_SELECTION = 137,
    _SC_CPUTIME = 138,
    _SC_THREAD_CPUTIME = 139,
    _SC_DEVICE_IO = 140,
    _SC_DEVICE_SPECIFIC = 141,
    _SC_DEVICE_SPECIFIC_R = 142,
    _SC_FD_MGMT = 143,
    _SC_FIFO = 144,
    _SC_PIPE = 145,
    _SC_FILE_ATTRIBUTES = 146,
    _SC_FILE_LOCKING = 147,
    _SC_FILE_SYSTEM = 148,
    _SC_MONOTONIC_CLOCK = 149,
    _SC_MULTI_PROCESS = 150,
    _SC_SINGLE_PROCESS = 151,
    _SC_NETWORKING = 152,
    _SC_READER_WRITER_LOCKS = 153,
    _SC_SPIN_LOCKS = 154,
    _SC_REGEXP = 155,
    _SC_REGEX_VERSION = 156,
    _SC_SHELL = 157,
    _SC_SIGNALS = 158,
    _SC_SPAWN = 159,
    _SC_SPORADIC_SERVER = 160,
    _SC_THREAD_SPORADIC_SERVER = 161,
    _SC_SYSTEM_DATABASE = 162,
    _SC_SYSTEM_DATABASE_R = 163,
    _SC_TIMEOUTS = 164,
    _SC_TYPED_MEMORY_OBJECTS = 165,
    _SC_USER_GROUPS = 166,
    _SC_USER_GROUPS_R = 167,
    _SC_2_PBS = 168,
    _SC_2_PBS_ACCOUNTING = 169,
    _SC_2_PBS_LOCATE = 170,
    _SC_2_PBS_MESSAGE = 171,
    _SC_2_PBS_TRACK = 172,
    _SC_SYMLOOP_MAX = 173,
    _SC_STREAMS = 174,
    _SC_2_PBS_CHECKPOINT = 175,
    _SC_V6_ILP32_OFF32 = 176,
    _SC_V6_ILP32_OFFBIG = 177,
    _SC_V6_LP64_OFF64 = 178,
    _SC_V6_LPBIG_OFFBIG = 179,
    _SC_HOST_NAME_MAX = 180,
    _SC_TRACE = 181,
    _SC_TRACE_EVENT_FILTER = 182,
    _SC_TRACE_INHERIT = 183,
    _SC_TRACE_LOG = 184,
    _SC_LEVEL1_ICACHE_SIZE = 185,
    _SC_LEVEL1_ICACHE_ASSOC = 186,
    _SC_LEVEL1_ICACHE_LINESIZE = 187,
    _SC_LEVEL1_DCACHE_SIZE = 188,
    _SC_LEVEL1_DCACHE_ASSOC = 189,
    _SC_LEVEL1_DCACHE_LINESIZE = 190,
    _SC_LEVEL2_CACHE_SIZE = 191,
    _SC_LEVEL2_CACHE_ASSOC = 192,
    _SC_LEVEL2_CACHE_LINESIZE = 193,
    _SC_LEVEL3_CACHE_SIZE = 194,
    _SC_LEVEL3_CACHE_ASSOC = 195,
    _SC_LEVEL3_CACHE_LINESIZE = 196,
    _SC_LEVEL4_CACHE_SIZE = 197,
    _SC_LEVEL4_CACHE_ASSOC = 198,
    _SC_LEVEL4_CACHE_LINESIZE = 199,
    _SC_IPV6 = 235,
    _SC_RAW_SOCKETS = 236,
    _SC_V7_ILP32_OFF32 = 237,
    _SC_V7_ILP32_OFFBIG = 238,
    _SC_V7_LP64_OFF64 = 239,
    _SC_V7_LPBIG_OFFBIG = 240,
    _SC_SS_REPL_MAX = 241,
    _SC_TRACE_EVENT_NAME_MAX = 242,
    _SC_TRACE_NAME_MAX = 243,
    _SC_TRACE_SYS_MAX = 244,
    _SC_TRACE_USER_EVENT_MAX = 245,
    _SC_XOPEN_STREAMS = 246,
    _SC_THREAD_ROBUST_PRIO_INHERIT = 247,
    _SC_THREAD_ROBUST_PRIO_PROTECT = 248
} ;
enum __anonenum_43 {
    _CS_PATH = 0,
    _CS_V6_WIDTH_RESTRICTED_ENVS = 1,
    _CS_GNU_LIBC_VERSION = 2,
    _CS_GNU_LIBPTHREAD_VERSION = 3,
    _CS_V5_WIDTH_RESTRICTED_ENVS = 4,
    _CS_V7_WIDTH_RESTRICTED_ENVS = 5,
    _CS_LFS_CFLAGS = 1000,
    _CS_LFS_LDFLAGS = 1001,
    _CS_LFS_LIBS = 1002,
    _CS_LFS_LINTFLAGS = 1003,
    _CS_LFS64_CFLAGS = 1004,
    _CS_LFS64_LDFLAGS = 1005,
    _CS_LFS64_LIBS = 1006,
    _CS_LFS64_LINTFLAGS = 1007,
    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,
    _CS_XBS5_ILP32_OFF32_LDFLAGS = 1101,
    _CS_XBS5_ILP32_OFF32_LIBS = 1102,
    _CS_XBS5_ILP32_OFF32_LINTFLAGS = 1103,
    _CS_XBS5_ILP32_OFFBIG_CFLAGS = 1104,
    _CS_XBS5_ILP32_OFFBIG_LDFLAGS = 1105,
    _CS_XBS5_ILP32_OFFBIG_LIBS = 1106,
    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS = 1107,
    _CS_XBS5_LP64_OFF64_CFLAGS = 1108,
    _CS_XBS5_LP64_OFF64_LDFLAGS = 1109,
    _CS_XBS5_LP64_OFF64_LIBS = 1110,
    _CS_XBS5_LP64_OFF64_LINTFLAGS = 1111,
    _CS_XBS5_LPBIG_OFFBIG_CFLAGS = 1112,
    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS = 1113,
    _CS_XBS5_LPBIG_OFFBIG_LIBS = 1114,
    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS = 1115,
    _CS_POSIX_V6_ILP32_OFF32_CFLAGS = 1116,
    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS = 1117,
    _CS_POSIX_V6_ILP32_OFF32_LIBS = 1118,
    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS = 1119,
    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS = 1120,
    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS = 1121,
    _CS_POSIX_V6_ILP32_OFFBIG_LIBS = 1122,
    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS = 1123,
    _CS_POSIX_V6_LP64_OFF64_CFLAGS = 1124,
    _CS_POSIX_V6_LP64_OFF64_LDFLAGS = 1125,
    _CS_POSIX_V6_LP64_OFF64_LIBS = 1126,
    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS = 1127,
    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS = 1128,
    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS = 1129,
    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS = 1130,
    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS = 1131,
    _CS_POSIX_V7_ILP32_OFF32_CFLAGS = 1132,
    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS = 1133,
    _CS_POSIX_V7_ILP32_OFF32_LIBS = 1134,
    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS = 1135,
    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS = 1136,
    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS = 1137,
    _CS_POSIX_V7_ILP32_OFFBIG_LIBS = 1138,
    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS = 1139,
    _CS_POSIX_V7_LP64_OFF64_CFLAGS = 1140,
    _CS_POSIX_V7_LP64_OFF64_LDFLAGS = 1141,
    _CS_POSIX_V7_LP64_OFF64_LIBS = 1142,
    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS = 1143,
    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS = 1144,
    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS = 1145,
    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS = 1146,
    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS = 1147,
    _CS_V6_ENV = 1148,
    _CS_V7_ENV = 1149
} ;
typedef unsigned char UChar;
typedef signed char Char;
typedef char HChar;
typedef unsigned short UShort;
typedef short Short;
typedef unsigned int UInt;
typedef int Int;
typedef unsigned long long ULong;
typedef long long Long;
typedef UInt U128[4];
union __anonunion_V128_44 {
   UChar w8[16] ;
   UShort w16[8] ;
   UInt w32[4] ;
   ULong w64[2] ;
};
typedef union __anonunion_V128_44 V128;
typedef float Float;
typedef double Double;
typedef unsigned char Bool;
typedef UInt Addr32;
typedef ULong Addr64;
typedef unsigned long HWord;
typedef unsigned long UWord;
typedef long Word;
typedef UWord Addr;
typedef UWord AddrH;
typedef UWord SizeT;
typedef Word SSizeT;
typedef Word PtrdiffT;
typedef Word OffT;
typedef Long Off64T;
struct __anonstruct_UWordPair_45 {
   UWord uw1 ;
   UWord uw2 ;
};
typedef struct __anonstruct_UWordPair_45 UWordPair;
typedef UInt ThreadId;
struct __anonstruct_SysRes_46 {
   UWord _val ;
   Bool _isError ;
};
typedef struct __anonstruct_SysRes_46 SysRes;
typedef UInt DrdThreadId;
struct __anonstruct_OrigFn_47 {
   unsigned int nraddr ;
};
typedef struct __anonstruct_OrigFn_47 OrigFn;
enum __anonenum_Vg_ClientRequest_48 {
    VG_USERREQ__RUNNING_ON_VALGRIND = 4097,
    VG_USERREQ__DISCARD_TRANSLATIONS = 4098,
    VG_USERREQ__CLIENT_CALL0 = 4353,
    VG_USERREQ__CLIENT_CALL1 = 4354,
    VG_USERREQ__CLIENT_CALL2 = 4355,
    VG_USERREQ__CLIENT_CALL3 = 4356,
    VG_USERREQ__COUNT_ERRORS = 4609,
    VG_USERREQ__MALLOCLIKE_BLOCK = 4865,
    VG_USERREQ__FREELIKE_BLOCK = 4866,
    VG_USERREQ__CREATE_MEMPOOL = 4867,
    VG_USERREQ__DESTROY_MEMPOOL = 4868,
    VG_USERREQ__MEMPOOL_ALLOC = 4869,
    VG_USERREQ__MEMPOOL_FREE = 4870,
    VG_USERREQ__MEMPOOL_TRIM = 4871,
    VG_USERREQ__MOVE_MEMPOOL = 4872,
    VG_USERREQ__MEMPOOL_CHANGE = 4873,
    VG_USERREQ__MEMPOOL_EXISTS = 4874,
    VG_USERREQ__PRINTF = 5121,
    VG_USERREQ__PRINTF_BACKTRACE = 5122,
    VG_USERREQ__PRINTF_VALIST_BY_REF = 5123,
    VG_USERREQ__PRINTF_BACKTRACE_VALIST_BY_REF = 5124,
    VG_USERREQ__STACK_REGISTER = 5377,
    VG_USERREQ__STACK_DEREGISTER = 5378,
    VG_USERREQ__STACK_CHANGE = 5379,
    VG_USERREQ__LOAD_PDB_DEBUGINFO = 5633,
    VG_USERREQ__MAP_IP_TO_SRCLOC = 5889
} ;
typedef enum __anonenum_Vg_ClientRequest_48 Vg_ClientRequest;
enum __anonenum_49 {
    VG_USERREQ__DRD_CLEAN_MEMORY = 1212612608,
    VG_USERREQ__DRD_GET_VALGRIND_THREAD_ID = 1146224640,
    VG_USERREQ__DRD_GET_DRD_THREAD_ID = 1146224641,
    VG_USERREQ__DRD_START_SUPPRESSION = 1146224642,
    VG_USERREQ__DRD_FINISH_SUPPRESSION = 1146224643,
    VG_USERREQ__DRD_START_TRACE_ADDR = 1146224644,
    VG_USERREQ__DRD_STOP_TRACE_ADDR = 1146224645,
    VG_USERREQ__DRD_RECORD_LOADS = 1146224646,
    VG_USERREQ__DRD_RECORD_STORES = 1146224647,
    VG_USERREQ__DRD_SET_THREAD_NAME = 1146224648,
    VG_USERREQ__DRD_ANNOTATION_UNIMP = 1146224649,
    VG_USERREQ__DRD_ANNOTATE_RWLOCK_CREATE = 1212612878,
    VG_USERREQ__DRD_ANNOTATE_RWLOCK_DESTROY = 1212612879,
    VG_USERREQ__DRD_ANNOTATE_RWLOCK_ACQUIRED = 1212612881,
    VG_USERREQ__DRD_ANNOTATE_RWLOCK_RELEASED = 1212612882,
    VG_USERREQ__HELGRIND_ANNOTATION_UNIMP = 1212612896,
    VG_USERREQ__DRD_ANNOTATE_HAPPENS_BEFORE = 1212612897,
    VG_USERREQ__DRD_ANNOTATE_HAPPENS_AFTER = 1212612898
} ;
enum __anonenum_50 {
    VG_USERREQ__SET_PTHREAD_COND_INITIALIZER = 1148321792,
    VG_USERREQ__DRD_START_NEW_SEGMENT = 1148321793,
    VG_USERREQ__SET_PTHREADID = 1148321794,
    VG_USERREQ__SET_JOINABLE = 1148321795,
    VG_USERREQ__ENTERING_PTHREAD_CREATE = 1148321796,
    VG_USERREQ__LEFT_PTHREAD_CREATE = 1148321797,
    VG_USERREQ__POST_THREAD_JOIN = 1148321798,
    VG_USERREQ__PRE_THREAD_CANCEL = 1148321799,
    VG_USERREQ__POST_THREAD_CANCEL = 1148321800,
    VG_USERREQ__PRE_MUTEX_INIT = 1148321801,
    VG_USERREQ__POST_MUTEX_INIT = 1148321802,
    VG_USERREQ__PRE_MUTEX_DESTROY = 1148321803,
    VG_USERREQ__POST_MUTEX_DESTROY = 1148321804,
    VG_USERREQ__PRE_MUTEX_LOCK = 1148321805,
    VG_USERREQ__POST_MUTEX_LOCK = 1148321806,
    VG_USERREQ__PRE_MUTEX_UNLOCK = 1148321807,
    VG_USERREQ__POST_MUTEX_UNLOCK = 1148321808,
    VG_USERREQ__PRE_SPIN_INIT_OR_UNLOCK = 1148321809,
    VG_USERREQ__POST_SPIN_INIT_OR_UNLOCK = 1148321810,
    VG_USERREQ__PRE_COND_INIT = 1148321811,
    VG_USERREQ__POST_COND_INIT = 1148321812,
    VG_USERREQ__PRE_COND_DESTROY = 1148321813,
    VG_USERREQ__POST_COND_DESTROY = 1148321814,
    VG_USERREQ__PRE_COND_WAIT = 1148321815,
    VG_USERREQ__POST_COND_WAIT = 1148321816,
    VG_USERREQ__PRE_COND_SIGNAL = 1148321817,
    VG_USERREQ__POST_COND_SIGNAL = 1148321818,
    VG_USERREQ__PRE_COND_BROADCAST = 1148321819,
    VG_USERREQ__POST_COND_BROADCAST = 1148321820,
    VG_USERREQ__PRE_SEM_INIT = 1148321821,
    VG_USERREQ__POST_SEM_INIT = 1148321822,
    VG_USERREQ__PRE_SEM_DESTROY = 1148321823,
    VG_USERREQ__POST_SEM_DESTROY = 1148321824,
    VG_USERREQ__PRE_SEM_OPEN = 1148321825,
    VG_USERREQ__POST_SEM_OPEN = 1148321826,
    VG_USERREQ__PRE_SEM_CLOSE = 1148321827,
    VG_USERREQ__POST_SEM_CLOSE = 1148321828,
    VG_USERREQ__PRE_SEM_WAIT = 1148321829,
    VG_USERREQ__POST_SEM_WAIT = 1148321830,
    VG_USERREQ__PRE_SEM_POST = 1148321831,
    VG_USERREQ__POST_SEM_POST = 1148321832,
    VG_USERREQ__PRE_BARRIER_INIT = 1148321833,
    VG_USERREQ__POST_BARRIER_INIT = 1148321834,
    VG_USERREQ__PRE_BARRIER_DESTROY = 1148321835,
    VG_USERREQ__POST_BARRIER_DESTROY = 1148321836,
    VG_USERREQ__PRE_BARRIER_WAIT = 1148321837,
    VG_USERREQ__POST_BARRIER_WAIT = 1148321838,
    VG_USERREQ__PRE_RWLOCK_INIT = 1148321839,
    VG_USERREQ__POST_RWLOCK_DESTROY = 1148321840,
    VG_USERREQ__PRE_RWLOCK_RDLOCK = 1148321841,
    VG_USERREQ__POST_RWLOCK_RDLOCK = 1148321842,
    VG_USERREQ__PRE_RWLOCK_WRLOCK = 1148321843,
    VG_USERREQ__POST_RWLOCK_WRLOCK = 1148321844,
    VG_USERREQ__PRE_RWLOCK_UNLOCK = 1148321845,
    VG_USERREQ__POST_RWLOCK_UNLOCK = 1148321846
} ;
enum __anonenum_MutexT_51 {
    mutex_type_unknown = -1,
    mutex_type_invalid_mutex = 0,
    mutex_type_recursive_mutex = 1,
    mutex_type_errorcheck_mutex = 2,
    mutex_type_default_mutex = 3,
    mutex_type_spinlock = 4
} ;
typedef enum __anonenum_MutexT_51 MutexT;
enum __anonenum_RwLockT_52 {
    pthread_rwlock = 1,
    user_rwlock = 2
} ;
typedef enum __anonenum_RwLockT_52 RwLockT;
enum __anonenum_BarrierT_53 {
    pthread_barrier = 1,
    gomp_barrier = 2
} ;
typedef enum __anonenum_BarrierT_53 BarrierT;
struct __anonstruct_DrdPosixThreadArgs_54 {
   void *(*start)(void * ) ;
   void *arg ;
   int detachstate ;
   int wrapper_started ;
};
typedef struct __anonstruct_DrdPosixThreadArgs_54 DrdPosixThreadArgs;
extern  __attribute__((__nothrow__, __noreturn__)) void __assert_fail(char const   *__assertion , char const   *__file , unsigned int __line , char const   *__function ) ;
extern  __attribute__((__nothrow__, __noreturn__)) void __assert_perror_fail(int __errnum , char const   *__file , unsigned int __line , char const   *__function ) ;
extern  __attribute__((__nothrow__, __noreturn__)) void __assert(char const   *__assertion , char const   *__file , int __line ) ;
extern  __attribute__((__nothrow__)) int clone(int (*__fn)(void *__arg ) , void *__child_stack , int __flags , void *__arg  , ...) ;
extern  __attribute__((__nothrow__)) int unshare(int __flags ) ;
extern  __attribute__((__nothrow__)) int sched_getcpu(void) ;
extern  __attribute__((__nothrow__)) int __sched_cpucount(size_t __setsize , cpu_set_t const   *__setp ) ;
extern  __attribute__((__nothrow__)) cpu_set_t *__sched_cpualloc(size_t __count ) ;
extern  __attribute__((__nothrow__)) void __sched_cpufree(cpu_set_t *__set ) ;
extern  __attribute__((__nothrow__)) int sched_setparam(__pid_t __pid , struct sched_param  const  *__param ) ;
extern  __attribute__((__nothrow__)) int sched_getparam(__pid_t __pid , struct sched_param *__param ) ;
extern  __attribute__((__nothrow__)) int sched_setscheduler(__pid_t __pid , int __policy , struct sched_param  const  *__param ) ;
extern  __attribute__((__nothrow__)) int sched_getscheduler(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) int sched_yield(void) ;
extern  __attribute__((__nothrow__)) int sched_get_priority_max(int __algorithm ) ;
extern  __attribute__((__nothrow__)) int sched_get_priority_min(int __algorithm ) ;
extern  __attribute__((__nothrow__)) int sched_rr_get_interval(__pid_t __pid , struct timespec *__t ) ;
extern  __attribute__((__nothrow__)) int sched_setaffinity(__pid_t __pid , size_t __cpusetsize , cpu_set_t const   *__cpuset ) ;
extern  __attribute__((__nothrow__)) int sched_getaffinity(__pid_t __pid , size_t __cpusetsize , cpu_set_t *__cpuset ) ;
extern  __attribute__((__nothrow__)) clock_t clock(void) ;
extern  __attribute__((__nothrow__)) time_t time(time_t *__timer ) ;
extern  __attribute__((__nothrow__)) double difftime(time_t __time1 , time_t __time0 )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) time_t mktime(struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) size_t strftime(char * __restrict  __s , size_t __maxsize , char const   * __restrict  __format , struct tm  const  * __restrict  __tp ) ;
extern  __attribute__((__nothrow__)) char *strptime(char const   * __restrict  __s , char const   * __restrict  __fmt , struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) size_t strftime_l(char * __restrict  __s , size_t __maxsize , char const   * __restrict  __format , struct tm  const  * __restrict  __tp , __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) char *strptime_l(char const   * __restrict  __s , char const   * __restrict  __fmt , struct tm *__tp , __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) struct tm *gmtime(time_t const   *__timer ) ;
extern  __attribute__((__nothrow__)) struct tm *localtime(time_t const   *__timer ) ;
extern  __attribute__((__nothrow__)) struct tm *gmtime_r(time_t const   * __restrict  __timer , struct tm * __restrict  __tp ) ;
extern  __attribute__((__nothrow__)) struct tm *localtime_r(time_t const   * __restrict  __timer , struct tm * __restrict  __tp ) ;
extern  __attribute__((__nothrow__)) char *asctime(struct tm  const  *__tp ) ;
extern  __attribute__((__nothrow__)) char *ctime(time_t const   *__timer ) ;
extern  __attribute__((__nothrow__)) char *asctime_r(struct tm  const  * __restrict  __tp , char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) char *ctime_r(time_t const   * __restrict  __timer , char * __restrict  __buf ) ;
extern char *__tzname[2] ;
extern int __daylight ;
extern long __timezone ;
extern char *tzname[2] ;
extern  __attribute__((__nothrow__)) void tzset(void) ;
extern int daylight ;
extern long timezone ;
extern  __attribute__((__nothrow__)) int stime(time_t const   *__when ) ;
extern  __attribute__((__nothrow__)) time_t timegm(struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) time_t timelocal(struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) int dysize(int __year )  __attribute__((__const__)) ;
extern int nanosleep(struct timespec  const  *__requested_time , struct timespec *__remaining ) ;
extern  __attribute__((__nothrow__)) int clock_getres(clockid_t __clock_id , struct timespec *__res ) ;
extern  __attribute__((__nothrow__)) int clock_gettime(clockid_t __clock_id , struct timespec *__tp ) ;
extern  __attribute__((__nothrow__)) int clock_settime(clockid_t __clock_id , struct timespec  const  *__tp ) ;
extern int clock_nanosleep(clockid_t __clock_id , int __flags , struct timespec  const  *__req , struct timespec *__rem ) ;
extern  __attribute__((__nothrow__)) int clock_getcpuclockid(pid_t __pid , clockid_t *__clock_id ) ;
extern  __attribute__((__nothrow__)) int timer_create(clockid_t __clock_id , struct sigevent * __restrict  __evp , timer_t * __restrict  __timerid ) ;
extern  __attribute__((__nothrow__)) int timer_delete(timer_t __timerid ) ;
extern  __attribute__((__nothrow__)) int timer_settime(timer_t __timerid , int __flags , struct itimerspec  const  * __restrict  __value , struct itimerspec * __restrict  __ovalue ) ;
extern  __attribute__((__nothrow__)) int timer_gettime(timer_t __timerid , struct itimerspec *__value ) ;
extern  __attribute__((__nothrow__)) int timer_getoverrun(timer_t __timerid ) ;
extern int getdate_err ;
extern struct tm *getdate(char const   *__string ) ;
extern int getdate_r(char const   * __restrict  __string , struct tm * __restrict  __resbufp ) ;
extern  __attribute__((__nothrow__)) int pthread_create(pthread_t * __restrict  __newthread , pthread_attr_t const   * __restrict  __attr , void *(*__start_routine)(void * ) , void * __restrict  __arg )  __attribute__((__nonnull__(1,3))) ;
extern  __attribute__((__noreturn__)) void pthread_exit(void *__retval ) ;
extern int pthread_join(pthread_t __th , void **__thread_return ) ;
extern  __attribute__((__nothrow__)) int pthread_tryjoin_np(pthread_t __th , void **__thread_return ) ;
extern int pthread_timedjoin_np(pthread_t __th , void **__thread_return , struct timespec  const  *__abstime ) ;
extern  __attribute__((__nothrow__)) int pthread_detach(pthread_t __th ) ;
extern  __attribute__((__nothrow__)) pthread_t pthread_self(void)  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int pthread_equal(pthread_t __thread1 , pthread_t __thread2 ) ;
extern  __attribute__((__nothrow__)) int pthread_attr_init(pthread_attr_t *__attr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_destroy(pthread_attr_t *__attr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_getdetachstate(pthread_attr_t const   *__attr , int *__detachstate )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_setdetachstate(pthread_attr_t *__attr , int __detachstate )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_getguardsize(pthread_attr_t const   *__attr , size_t *__guardsize )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_setguardsize(pthread_attr_t *__attr , size_t __guardsize )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_getschedparam(pthread_attr_t const   * __restrict  __attr , struct sched_param * __restrict  __param )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_setschedparam(pthread_attr_t * __restrict  __attr , struct sched_param  const  * __restrict  __param )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_getschedpolicy(pthread_attr_t const   * __restrict  __attr , int * __restrict  __policy )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_setschedpolicy(pthread_attr_t *__attr , int __policy )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_getinheritsched(pthread_attr_t const   * __restrict  __attr , int * __restrict  __inherit )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_setinheritsched(pthread_attr_t *__attr , int __inherit )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_getscope(pthread_attr_t const   * __restrict  __attr , int * __restrict  __scope )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_setscope(pthread_attr_t *__attr , int __scope )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_getstackaddr(pthread_attr_t const   * __restrict  __attr , void ** __restrict  __stackaddr )  __attribute__((__nonnull__(1,2), __deprecated__)) ;
extern  __attribute__((__nothrow__)) int pthread_attr_setstackaddr(pthread_attr_t *__attr , void *__stackaddr )  __attribute__((__nonnull__(1), __deprecated__)) ;
extern  __attribute__((__nothrow__)) int pthread_attr_getstacksize(pthread_attr_t const   * __restrict  __attr , size_t * __restrict  __stacksize )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_setstacksize(pthread_attr_t *__attr , size_t __stacksize )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_getstack(pthread_attr_t const   * __restrict  __attr , void ** __restrict  __stackaddr , size_t * __restrict  __stacksize )  __attribute__((__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_setstack(pthread_attr_t *__attr , void *__stackaddr , size_t __stacksize )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_setaffinity_np(pthread_attr_t *__attr , size_t __cpusetsize , cpu_set_t const   *__cpuset )  __attribute__((__nonnull__(1,3))) ;
extern  __attribute__((__nothrow__)) int pthread_attr_getaffinity_np(pthread_attr_t const   *__attr , size_t __cpusetsize , cpu_set_t *__cpuset )  __attribute__((__nonnull__(1,3))) ;
extern  __attribute__((__nothrow__)) int pthread_getattr_np(pthread_t __th , pthread_attr_t *__attr )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int pthread_setschedparam(pthread_t __target_thread , int __policy , struct sched_param  const  *__param )  __attribute__((__nonnull__(3))) ;
extern  __attribute__((__nothrow__)) int pthread_getschedparam(pthread_t __target_thread , int * __restrict  __policy , struct sched_param * __restrict  __param )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) int pthread_setschedprio(pthread_t __target_thread , int __prio ) ;
extern  __attribute__((__nothrow__)) int pthread_getname_np(pthread_t __target_thread , char *__buf , size_t __buflen )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int pthread_setname_np(pthread_t __target_thread , char const   *__name )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int pthread_getconcurrency(void) ;
extern  __attribute__((__nothrow__)) int pthread_setconcurrency(int __level ) ;
extern  __attribute__((__nothrow__)) int pthread_yield(void) ;
extern  __attribute__((__nothrow__)) int pthread_setaffinity_np(pthread_t __th , size_t __cpusetsize , cpu_set_t const   *__cpuset )  __attribute__((__nonnull__(3))) ;
extern  __attribute__((__nothrow__)) int pthread_getaffinity_np(pthread_t __th , size_t __cpusetsize , cpu_set_t *__cpuset )  __attribute__((__nonnull__(3))) ;
extern int pthread_once(pthread_once_t *__once_control , void (*__init_routine)(void) )  __attribute__((__nonnull__(1,2))) ;
extern int pthread_setcancelstate(int __state , int *__oldstate ) ;
extern int pthread_setcanceltype(int __type , int *__oldtype ) ;
extern int pthread_cancel(pthread_t __th ) ;
extern void pthread_testcancel(void) ;
extern void ( __attribute__((__regparm__(1))) __pthread_register_cancel)(__pthread_unwind_buf_t *__buf ) ;
extern void ( __attribute__((__regparm__(1))) __pthread_unregister_cancel)(__pthread_unwind_buf_t *__buf ) ;
extern void ( __attribute__((__regparm__(1))) __pthread_register_cancel_defer)(__pthread_unwind_buf_t *__buf ) ;
extern void ( __attribute__((__regparm__(1))) __pthread_unregister_cancel_restore)(__pthread_unwind_buf_t *__buf ) ;
extern  __attribute__((__noreturn__)) void ( __attribute__((__regparm__(1))) __pthread_unwind_next)(__pthread_unwind_buf_t *__buf )  __attribute__((__weak__)) ;
extern  __attribute__((__nothrow__)) int __sigsetjmp(struct __jmp_buf_tag *__env , int __savemask ) ;
extern  __attribute__((__nothrow__)) int pthread_mutex_init(pthread_mutex_t *__mutex , pthread_mutexattr_t const   *__mutexattr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_mutex_destroy(pthread_mutex_t *__mutex )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_mutex_trylock(pthread_mutex_t *__mutex )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_mutex_lock(pthread_mutex_t *__mutex )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_mutex_timedlock(pthread_mutex_t * __restrict  __mutex , struct timespec  const  * __restrict  __abstime )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_mutex_unlock(pthread_mutex_t *__mutex )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_mutex_getprioceiling(pthread_mutex_t const   * __restrict  __mutex , int * __restrict  __prioceiling )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_mutex_setprioceiling(pthread_mutex_t * __restrict  __mutex , int __prioceiling , int * __restrict  __old_ceiling )  __attribute__((__nonnull__(1,3))) ;
extern  __attribute__((__nothrow__)) int pthread_mutex_consistent(pthread_mutex_t *__mutex )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_mutex_consistent_np(pthread_mutex_t *__mutex )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_mutexattr_init(pthread_mutexattr_t *__attr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_mutexattr_destroy(pthread_mutexattr_t *__attr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_mutexattr_getpshared(pthread_mutexattr_t const   * __restrict  __attr , int * __restrict  __pshared )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_mutexattr_setpshared(pthread_mutexattr_t *__attr , int __pshared )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_mutexattr_gettype(pthread_mutexattr_t const   * __restrict  __attr , int * __restrict  __kind )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_mutexattr_settype(pthread_mutexattr_t *__attr , int __kind )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_mutexattr_getprotocol(pthread_mutexattr_t const   * __restrict  __attr , int * __restrict  __protocol )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_mutexattr_setprotocol(pthread_mutexattr_t *__attr , int __protocol )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_mutexattr_getprioceiling(pthread_mutexattr_t const   * __restrict  __attr , int * __restrict  __prioceiling )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_mutexattr_setprioceiling(pthread_mutexattr_t *__attr , int __prioceiling )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_mutexattr_getrobust(pthread_mutexattr_t const   *__attr , int *__robustness )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_mutexattr_getrobust_np(pthread_mutexattr_t const   *__attr , int *__robustness )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_mutexattr_setrobust(pthread_mutexattr_t *__attr , int __robustness )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_mutexattr_setrobust_np(pthread_mutexattr_t *__attr , int __robustness )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_rwlock_init(pthread_rwlock_t * __restrict  __rwlock , pthread_rwlockattr_t const   * __restrict  __attr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_rwlock_destroy(pthread_rwlock_t *__rwlock )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_rwlock_rdlock(pthread_rwlock_t *__rwlock )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_rwlock_tryrdlock(pthread_rwlock_t *__rwlock )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_rwlock_timedrdlock(pthread_rwlock_t * __restrict  __rwlock , struct timespec  const  * __restrict  __abstime )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_rwlock_wrlock(pthread_rwlock_t *__rwlock )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_rwlock_trywrlock(pthread_rwlock_t *__rwlock )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_rwlock_timedwrlock(pthread_rwlock_t * __restrict  __rwlock , struct timespec  const  * __restrict  __abstime )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_rwlock_unlock(pthread_rwlock_t *__rwlock )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_rwlockattr_init(pthread_rwlockattr_t *__attr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_rwlockattr_destroy(pthread_rwlockattr_t *__attr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_rwlockattr_getpshared(pthread_rwlockattr_t const   * __restrict  __attr , int * __restrict  __pshared )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_rwlockattr_setpshared(pthread_rwlockattr_t *__attr , int __pshared )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_rwlockattr_getkind_np(pthread_rwlockattr_t const   * __restrict  __attr , int * __restrict  __pref )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_rwlockattr_setkind_np(pthread_rwlockattr_t *__attr , int __pref )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_cond_init(pthread_cond_t * __restrict  __cond , pthread_condattr_t const   * __restrict  __cond_attr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_cond_destroy(pthread_cond_t *__cond )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_cond_signal(pthread_cond_t *__cond )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_cond_broadcast(pthread_cond_t *__cond )  __attribute__((__nonnull__(1))) ;
extern int pthread_cond_wait(pthread_cond_t * __restrict  __cond , pthread_mutex_t * __restrict  __mutex )  __attribute__((__nonnull__(1,2))) ;
extern int pthread_cond_timedwait(pthread_cond_t * __restrict  __cond , pthread_mutex_t * __restrict  __mutex , struct timespec  const  * __restrict  __abstime )  __attribute__((__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) int pthread_condattr_init(pthread_condattr_t *__attr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_condattr_destroy(pthread_condattr_t *__attr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_condattr_getpshared(pthread_condattr_t const   * __restrict  __attr , int * __restrict  __pshared )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_condattr_setpshared(pthread_condattr_t *__attr , int __pshared )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_condattr_getclock(pthread_condattr_t const   * __restrict  __attr , __clockid_t * __restrict  __clock_id )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_condattr_setclock(pthread_condattr_t *__attr , __clockid_t __clock_id )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_spin_init(pthread_spinlock_t *__lock , int __pshared )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_spin_destroy(pthread_spinlock_t *__lock )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_spin_lock(pthread_spinlock_t *__lock )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_spin_trylock(pthread_spinlock_t *__lock )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_spin_unlock(pthread_spinlock_t *__lock )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_barrier_init(pthread_barrier_t * __restrict  __barrier , pthread_barrierattr_t const   * __restrict  __attr , unsigned int __count )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_barrier_destroy(pthread_barrier_t *__barrier )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_barrier_wait(pthread_barrier_t *__barrier )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_barrierattr_init(pthread_barrierattr_t *__attr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_barrierattr_destroy(pthread_barrierattr_t *__attr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_barrierattr_getpshared(pthread_barrierattr_t const   * __restrict  __attr , int * __restrict  __pshared )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int pthread_barrierattr_setpshared(pthread_barrierattr_t *__attr , int __pshared )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_key_create(pthread_key_t *__key , void (*__destr_function)(void * ) )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int pthread_key_delete(pthread_key_t __key ) ;
extern  __attribute__((__nothrow__)) void *pthread_getspecific(pthread_key_t __key ) ;
extern  __attribute__((__nothrow__)) int pthread_setspecific(pthread_key_t __key , void const   *__pointer ) ;
extern  __attribute__((__nothrow__)) int pthread_getcpuclockid(pthread_t __thread_id , __clockid_t *__clock_id )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int pthread_atfork(void (*__prepare)(void) , void (*__parent)(void) , void (*__child)(void) ) ;
__inline extern  __attribute__((__nothrow__)) int pthread_equal(pthread_t __thread1 , pthread_t __thread2 ) ;
__inline extern int pthread_equal(pthread_t __thread1 , pthread_t __thread2 ) 
{ 

  {
  return (__thread1 == __thread2);
}
}
extern int select(int __nfds , fd_set * __restrict  __readfds , fd_set * __restrict  __writefds , fd_set * __restrict  __exceptfds , struct timeval * __restrict  __timeout ) ;
extern int pselect(int __nfds , fd_set * __restrict  __readfds , fd_set * __restrict  __writefds , fd_set * __restrict  __exceptfds , struct timespec  const  * __restrict  __timeout , __sigset_t const   * __restrict  __sigmask ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major , unsigned int __minor ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_major(unsigned long long __dev ) 
{ 

  {
  return ((unsigned int )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_minor(unsigned long long __dev ) 
{ 

  {
  return ((unsigned int )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major , unsigned int __minor ) ;
__inline extern unsigned long long gnu_dev_makedev(unsigned int __major , unsigned int __minor ) 
{ 

  {
  return (((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32));
}
}
extern  __attribute__((__nothrow__)) int sem_init(sem_t *__sem , int __pshared , unsigned int __value ) ;
extern  __attribute__((__nothrow__)) int sem_destroy(sem_t *__sem ) ;
extern  __attribute__((__nothrow__)) sem_t *sem_open(char const   *__name , int __oflag  , ...) ;
extern  __attribute__((__nothrow__)) int sem_close(sem_t *__sem ) ;
extern  __attribute__((__nothrow__)) int sem_unlink(char const   *__name ) ;
extern int sem_wait(sem_t *__sem ) ;
extern int sem_timedwait(sem_t * __restrict  __sem , struct timespec  const  * __restrict  __abstime ) ;
extern  __attribute__((__nothrow__)) int sem_trywait(sem_t *__sem ) ;
extern  __attribute__((__nothrow__)) int sem_post(sem_t *__sem ) ;
extern  __attribute__((__nothrow__)) int sem_getvalue(sem_t * __restrict  __sem , int * __restrict  __sval ) ;
extern struct _IO_FILE_plus _IO_2_1_stdin_ ;
extern struct _IO_FILE_plus _IO_2_1_stdout_ ;
extern struct _IO_FILE_plus _IO_2_1_stderr_ ;
extern void _IO_cookie_init(struct _IO_cookie_file *__cfile , int __read_write , void *__cookie , _IO_cookie_io_functions_t __fns ) ;
extern int __underflow(_IO_FILE * ) ;
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_feof(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_ferror(_IO_FILE *__fp ) ;
extern int _IO_peekc_locked(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) void _IO_flockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) void _IO_funlockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) int _IO_ftrylockfile(_IO_FILE * ) ;
extern int _IO_vfscanf(_IO_FILE * __restrict   , char const   * __restrict   , __gnuc_va_list  , int * __restrict   ) ;
extern int _IO_vfprintf(_IO_FILE * __restrict   , char const   * __restrict   , __gnuc_va_list  ) ;
extern __ssize_t _IO_padn(_IO_FILE * , int  , __ssize_t  ) ;
extern size_t _IO_sgetn(_IO_FILE * , void * , size_t  ) ;
extern __off64_t _IO_seekoff(_IO_FILE * , __off64_t  , int  , int  ) ;
extern __off64_t _IO_seekpos(_IO_FILE * , __off64_t  , int  ) ;
extern  __attribute__((__nothrow__)) void _IO_free_backup_area(_IO_FILE * ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
extern  __attribute__((__nothrow__)) int remove(char const   *__filename ) ;
extern  __attribute__((__nothrow__)) int rename(char const   *__old , char const   *__new ) ;
extern  __attribute__((__nothrow__)) int renameat(int __oldfd , char const   *__old , int __newfd , char const   *__new ) ;
extern FILE *tmpfile(void) ;
extern FILE *tmpfile64(void) ;
extern  __attribute__((__nothrow__)) char *tmpnam(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tmpnam_r(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tempnam(char const   *__dir , char const   *__pfx )  __attribute__((__malloc__)) ;
extern int fclose(FILE *__stream ) ;
extern int fflush(FILE *__stream ) ;
extern int fflush_unlocked(FILE *__stream ) ;
extern int fcloseall(void) ;
extern FILE *fopen(char const   * __restrict  __filename , char const   * __restrict  __modes ) ;
extern FILE *freopen(char const   * __restrict  __filename , char const   * __restrict  __modes , FILE * __restrict  __stream ) ;
extern FILE *fopen64(char const   * __restrict  __filename , char const   * __restrict  __modes ) ;
extern FILE *freopen64(char const   * __restrict  __filename , char const   * __restrict  __modes , FILE * __restrict  __stream ) ;
extern  __attribute__((__nothrow__)) FILE *fdopen(int __fd , char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *fopencookie(void * __restrict  __magic_cookie , char const   * __restrict  __modes , _IO_cookie_io_functions_t __io_funcs ) ;
extern  __attribute__((__nothrow__)) FILE *fmemopen(void *__s , size_t __len , char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *open_memstream(char **__bufloc , size_t *__sizeloc ) ;
extern  __attribute__((__nothrow__)) void setbuf(FILE * __restrict  __stream , char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) int setvbuf(FILE * __restrict  __stream , char * __restrict  __buf , int __modes , size_t __n ) ;
extern  __attribute__((__nothrow__)) void setbuffer(FILE * __restrict  __stream , char * __restrict  __buf , size_t __size ) ;
extern  __attribute__((__nothrow__)) void setlinebuf(FILE *__stream ) ;
extern int fprintf(FILE * __restrict  __stream , char const   * __restrict  __format  , ...) ;
extern int printf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sprintf(char * __restrict  __s , char const   * __restrict  __format  , ...) ;
extern int vfprintf(FILE * __restrict  __s , char const   * __restrict  __format , __gnuc_va_list __arg ) ;
__inline extern int vprintf(char const   * __restrict  __fmt , __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vsprintf(char * __restrict  __s , char const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  snprintf)(char * __restrict  __s , size_t __maxlen , char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsnprintf)(char * __restrict  __s , size_t __maxlen , char const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vasprintf)(char ** __restrict  __ptr , char const   * __restrict  __f , __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  __asprintf)(char ** __restrict  __ptr , char const   * __restrict  __fmt  , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  asprintf)(char ** __restrict  __ptr , char const   * __restrict  __fmt  , ...) ;
extern int ( /* format attribute */  vdprintf)(int __fd , char const   * __restrict  __fmt , __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  dprintf)(int __fd , char const   * __restrict  __fmt  , ...) ;
extern int fscanf(FILE * __restrict  __stream , char const   * __restrict  __format  , ...) ;
extern int scanf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sscanf(char const   * __restrict  __s , char const   * __restrict  __format  , ...) ;
extern int ( /* format attribute */  vfscanf)(FILE * __restrict  __s , char const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  vscanf)(char const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsscanf)(char const   * __restrict  __s , char const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern int fgetc(FILE *__stream ) ;
extern int getc(FILE *__stream ) ;
__inline extern int getchar(void) ;
__inline extern int getc_unlocked(FILE *__fp ) ;
__inline extern int getchar_unlocked(void) ;
__inline extern int fgetc_unlocked(FILE *__fp ) ;
extern int fputc(int __c , FILE *__stream ) ;
extern int putc(int __c , FILE *__stream ) ;
__inline extern int putchar(int __c ) ;
__inline extern int fputc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putchar_unlocked(int __c ) ;
extern int getw(FILE *__stream ) ;
extern int putw(int __w , FILE *__stream ) ;
extern char *fgets(char * __restrict  __s , int __n , FILE * __restrict  __stream ) ;
extern char *gets(char *__s ) ;
extern char *fgets_unlocked(char * __restrict  __s , int __n , FILE * __restrict  __stream ) ;
extern __ssize_t __getdelim(char ** __restrict  __lineptr , size_t * __restrict  __n , int __delimiter , FILE * __restrict  __stream ) ;
extern __ssize_t getdelim(char ** __restrict  __lineptr , size_t * __restrict  __n , int __delimiter , FILE * __restrict  __stream ) ;
__inline extern __ssize_t getline(char ** __restrict  __lineptr , size_t * __restrict  __n , FILE * __restrict  __stream ) ;
extern int fputs(char const   * __restrict  __s , FILE * __restrict  __stream ) ;
extern int puts(char const   *__s ) ;
extern int ungetc(int __c , FILE *__stream ) ;
extern size_t fread(void * __restrict  __ptr , size_t __size , size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite(void const   * __restrict  __ptr , size_t __size , size_t __n , FILE * __restrict  __s ) ;
extern int fputs_unlocked(char const   * __restrict  __s , FILE * __restrict  __stream ) ;
extern size_t fread_unlocked(void * __restrict  __ptr , size_t __size , size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite_unlocked(void const   * __restrict  __ptr , size_t __size , size_t __n , FILE * __restrict  __stream ) ;
extern int fseek(FILE *__stream , long __off , int __whence ) ;
extern long ftell(FILE *__stream ) ;
extern void rewind(FILE *__stream ) ;
extern int fseeko(FILE *__stream , __off_t __off , int __whence ) ;
extern __off_t ftello(FILE *__stream ) ;
extern int fgetpos(FILE * __restrict  __stream , fpos_t * __restrict  __pos ) ;
extern int fsetpos(FILE *__stream , fpos_t const   *__pos ) ;
extern int fseeko64(FILE *__stream , __off64_t __off , int __whence ) ;
extern __off64_t ftello64(FILE *__stream ) ;
extern int fgetpos64(FILE * __restrict  __stream , fpos64_t * __restrict  __pos ) ;
extern int fsetpos64(FILE *__stream , fpos64_t const   *__pos ) ;
extern  __attribute__((__nothrow__)) void clearerr(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int feof(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ferror(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void clearerr_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
extern void perror(char const   *__s ) ;
extern int sys_nerr ;
extern char const   * const  sys_errlist[] ;
extern int _sys_nerr ;
extern char const   * const  _sys_errlist[] ;
extern  __attribute__((__nothrow__)) int fileno(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int fileno_unlocked(FILE *__stream ) ;
extern FILE *popen(char const   *__command , char const   *__modes ) ;
extern int pclose(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) char *ctermid(char *__s ) ;
extern char *cuserid(char *__s ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  obstack_printf)(struct obstack * __restrict  __obstack , char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  obstack_vprintf)(struct obstack * __restrict  __obstack , char const   * __restrict  __format , __gnuc_va_list __args ) ;
extern  __attribute__((__nothrow__)) void flockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ftrylockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void funlockfile(FILE *__stream ) ;
__inline extern int vprintf(char const   * __restrict  __fmt , __gnuc_va_list __arg ) 
{ int tmp ;

  {
  tmp = vfprintf((FILE */* __restrict  */)stdout, __fmt, __arg);
  return (tmp);
}
}
__inline extern int getchar(void) 
{ int tmp ;

  {
  tmp = _IO_getc(stdin);
  return (tmp);
}
}
__inline extern int fgetc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end), 0L);
  if (tmp___3) {
    tmp___0 = __uflow(__fp);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = __fp->_IO_read_ptr;
    (__fp->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return (tmp___2);
}
}
__inline extern int getc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end), 0L);
  if (tmp___3) {
    tmp___0 = __uflow(__fp);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = __fp->_IO_read_ptr;
    (__fp->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return (tmp___2);
}
}
__inline extern int getchar_unlocked(void) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned int )stdin->_IO_read_ptr >= (unsigned int )stdin->_IO_read_end), 0L);
  if (tmp___3) {
    tmp___0 = __uflow(stdin);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = stdin->_IO_read_ptr;
    (stdin->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return (tmp___2);
}
}
__inline extern int putchar(int __c ) 
{ int tmp ;

  {
  tmp = _IO_putc(__c, stdout);
  return (tmp);
}
}
__inline extern int fputc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end), 0L);
  if (tmp___4) {
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = __stream->_IO_write_ptr;
    (__stream->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return (tmp___3);
}
}
__inline extern int putc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end), 0L);
  if (tmp___4) {
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = __stream->_IO_write_ptr;
    (__stream->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return (tmp___3);
}
}
__inline extern int putchar_unlocked(int __c ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned int )stdout->_IO_write_ptr >= (unsigned int )stdout->_IO_write_end), 0L);
  if (tmp___4) {
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = stdout->_IO_write_ptr;
    (stdout->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return (tmp___3);
}
}
__inline extern __ssize_t getline(char ** __restrict  __lineptr , size_t * __restrict  __n , FILE * __restrict  __stream ) 
{ __ssize_t tmp ;

  {
  tmp = __getdelim(__lineptr, __n, '\n', __stream);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern int feof_unlocked(FILE *__stream ) 
{ 

  {
  return ((__stream->_flags & 0x10) != 0);
}
}
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
__inline extern int ferror_unlocked(FILE *__stream ) 
{ 

  {
  return ((__stream->_flags & 0x20) != 0);
}
}
extern  __attribute__((__nothrow__)) size_t __ctype_get_mb_cur_max(void) ;
__inline extern  __attribute__((__nothrow__)) double atof(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) int atoi(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) long atol(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) long long atoll(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) double strtod(char const   * __restrict  __nptr , char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) float strtof(char const   * __restrict  __nptr , char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long double strtold(char const   * __restrict  __nptr , char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long strtol(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long strtoul(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long long strtoq(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long long strtouq(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long long strtoll(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long long strtoull(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long strtol_l(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base , __locale_t __loc )  __attribute__((__nonnull__(1,4))) ;
extern  __attribute__((__nothrow__)) unsigned long strtoul_l(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base , __locale_t __loc )  __attribute__((__nonnull__(1,4))) ;
extern  __attribute__((__nothrow__)) long long strtoll_l(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base , __locale_t __loc )  __attribute__((__nonnull__(1,4))) ;
extern  __attribute__((__nothrow__)) unsigned long long strtoull_l(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base , __locale_t __loc )  __attribute__((__nonnull__(1,4))) ;
extern  __attribute__((__nothrow__)) double strtod_l(char const   * __restrict  __nptr , char ** __restrict  __endptr , __locale_t __loc )  __attribute__((__nonnull__(1,3))) ;
extern  __attribute__((__nothrow__)) float strtof_l(char const   * __restrict  __nptr , char ** __restrict  __endptr , __locale_t __loc )  __attribute__((__nonnull__(1,3))) ;
extern  __attribute__((__nothrow__)) long double strtold_l(char const   * __restrict  __nptr , char ** __restrict  __endptr , __locale_t __loc )  __attribute__((__nonnull__(1,3))) ;
__inline extern  __attribute__((__nothrow__)) double atof(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern double atof(char const   *__nptr ) 
{ double tmp ;

  {
  tmp = strtod((char const   */* __restrict  */)__nptr, (char **/* __restrict  */)((char **)((void *)0)));
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int atoi(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern int atoi(char const   *__nptr ) 
{ long tmp ;

  {
  tmp = strtol((char const   */* __restrict  */)__nptr, (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((int )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long atol(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern long atol(char const   *__nptr ) 
{ long tmp ;

  {
  tmp = strtol((char const   */* __restrict  */)__nptr, (char **/* __restrict  */)((char **)((void *)0)), 10);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long long atoll(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern long long atoll(char const   *__nptr ) 
{ long long tmp ;

  {
  tmp = strtoll((char const   */* __restrict  */)__nptr, (char **/* __restrict  */)((char **)((void *)0)), 10);
  return (tmp);
}
}
extern  __attribute__((__nothrow__)) char *l64a(long __n ) ;
extern  __attribute__((__nothrow__)) long a64l(char const   *__s )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long random(void) ;
extern  __attribute__((__nothrow__)) void srandom(unsigned int __seed ) ;
extern  __attribute__((__nothrow__)) char *initstate(unsigned int __seed , char *__statebuf , size_t __statelen )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *setstate(char *__statebuf )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int random_r(struct random_data * __restrict  __buf , int32_t * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int srandom_r(unsigned int __seed , struct random_data *__buf )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int initstate_r(unsigned int __seed , char * __restrict  __statebuf , size_t __statelen , struct random_data * __restrict  __buf )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) int setstate_r(char * __restrict  __statebuf , struct random_data * __restrict  __buf )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int rand(void) ;
extern  __attribute__((__nothrow__)) void srand(unsigned int __seed ) ;
extern  __attribute__((__nothrow__)) int rand_r(unsigned int *__seed ) ;
extern  __attribute__((__nothrow__)) double drand48(void) ;
extern  __attribute__((__nothrow__)) double erand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long lrand48(void) ;
extern  __attribute__((__nothrow__)) long nrand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long mrand48(void) ;
extern  __attribute__((__nothrow__)) long jrand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void srand48(long __seedval ) ;
extern  __attribute__((__nothrow__)) unsigned short *seed48(unsigned short *__seed16v )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void lcong48(unsigned short *__param )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int drand48_r(struct drand48_data * __restrict  __buffer , double * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int erand48_r(unsigned short *__xsubi , struct drand48_data * __restrict  __buffer , double * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int lrand48_r(struct drand48_data * __restrict  __buffer , long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int nrand48_r(unsigned short *__xsubi , struct drand48_data * __restrict  __buffer , long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int mrand48_r(struct drand48_data * __restrict  __buffer , long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int jrand48_r(unsigned short *__xsubi , struct drand48_data * __restrict  __buffer , long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int srand48_r(long __seedval , struct drand48_data *__buffer )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int seed48_r(unsigned short *__seed16v , struct drand48_data *__buffer )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int lcong48_r(unsigned short *__param , struct drand48_data *__buffer )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *malloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *calloc(size_t __nmemb , size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *realloc(void *__ptr , size_t __size )  __attribute__((__warn_unused_result__)) ;
extern  __attribute__((__nothrow__)) void free(void *__ptr ) ;
extern  __attribute__((__nothrow__)) void cfree(void *__ptr ) ;
extern  __attribute__((__nothrow__)) void *alloca(size_t __size ) ;
extern  __attribute__((__nothrow__)) void *valloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) int posix_memalign(void **__memptr , size_t __alignment , size_t __size )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__, __noreturn__)) void abort(void) ;
extern  __attribute__((__nothrow__)) int atexit(void (*__func)(void) )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int at_quick_exit(void (*__func)(void) )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int on_exit(void (*__func)(int __status , void *__arg ) , void *__arg )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__, __noreturn__)) void exit(int __status ) ;
extern  __attribute__((__nothrow__, __noreturn__)) void quick_exit(int __status ) ;
extern  __attribute__((__nothrow__, __noreturn__)) void _Exit(int __status ) ;
extern  __attribute__((__nothrow__)) char *getenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *__secure_getenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int putenv(char *__string )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int setenv(char const   *__name , char const   *__value , int __replace )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int unsetenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int clearenv(void) ;
extern  __attribute__((__nothrow__)) char *mktemp(char *__template )  __attribute__((__nonnull__(1))) ;
extern int mkstemp(char *__template )  __attribute__((__nonnull__(1))) ;
extern int mkstemp64(char *__template )  __attribute__((__nonnull__(1))) ;
extern int mkstemps(char *__template , int __suffixlen )  __attribute__((__nonnull__(1))) ;
extern int mkstemps64(char *__template , int __suffixlen )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *mkdtemp(char *__template )  __attribute__((__nonnull__(1))) ;
extern int mkostemp(char *__template , int __flags )  __attribute__((__nonnull__(1))) ;
extern int mkostemp64(char *__template , int __flags )  __attribute__((__nonnull__(1))) ;
extern int mkostemps(char *__template , int __suffixlen , int __flags )  __attribute__((__nonnull__(1))) ;
extern int mkostemps64(char *__template , int __suffixlen , int __flags )  __attribute__((__nonnull__(1))) ;
extern int system(char const   *__command ) ;
extern  __attribute__((__nothrow__)) char *canonicalize_file_name(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *realpath(char const   * __restrict  __name , char * __restrict  __resolved ) ;
extern void *bsearch(void const   *__key , void const   *__base , size_t __nmemb , size_t __size , int (*__compar)(void const   * , void const   * ) )  __attribute__((__nonnull__(1,2,5))) ;
extern void qsort(void *__base , size_t __nmemb , size_t __size , int (*__compar)(void const   * , void const   * ) )  __attribute__((__nonnull__(1,4))) ;
extern void qsort_r(void *__base , size_t __nmemb , size_t __size , int (*__compar)(void const   * , void const   * , void * ) , void *__arg )  __attribute__((__nonnull__(1,4))) ;
extern  __attribute__((__nothrow__)) int abs(int __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long labs(long __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long long llabs(long long __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) div_t div(int __numer , int __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) ldiv_t ldiv(long __numer , long __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) lldiv_t lldiv(long long __numer , long long __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) char *ecvt(double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *fcvt(double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *gcvt(double __value , int __ndigit , char *__buf )  __attribute__((__nonnull__(3))) ;
extern  __attribute__((__nothrow__)) char *qecvt(long double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *qfcvt(long double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *qgcvt(long double __value , int __ndigit , char *__buf )  __attribute__((__nonnull__(3))) ;
extern  __attribute__((__nothrow__)) int ecvt_r(double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign , char * __restrict  __buf , size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int fcvt_r(double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign , char * __restrict  __buf , size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int qecvt_r(long double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign , char * __restrict  __buf , size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int qfcvt_r(long double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign , char * __restrict  __buf , size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int mblen(char const   *__s , size_t __n ) ;
extern  __attribute__((__nothrow__)) int mbtowc(wchar_t * __restrict  __pwc , char const   * __restrict  __s , size_t __n ) ;
extern  __attribute__((__nothrow__)) int wctomb(char *__s , wchar_t __wchar ) ;
extern  __attribute__((__nothrow__)) size_t mbstowcs(wchar_t * __restrict  __pwcs , char const   * __restrict  __s , size_t __n ) ;
extern  __attribute__((__nothrow__)) size_t wcstombs(char * __restrict  __s , wchar_t const   * __restrict  __pwcs , size_t __n ) ;
extern  __attribute__((__nothrow__)) int rpmatch(char const   *__response )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int getsubopt(char ** __restrict  __optionp , char * const  * __restrict  __tokens , char ** __restrict  __valuep )  __attribute__((__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) void setkey(char const   *__key )  __attribute__((__nonnull__(1))) ;
extern int posix_openpt(int __oflag ) ;
extern  __attribute__((__nothrow__)) int grantpt(int __fd ) ;
extern  __attribute__((__nothrow__)) int unlockpt(int __fd ) ;
extern  __attribute__((__nothrow__)) char *ptsname(int __fd ) ;
extern  __attribute__((__nothrow__)) int ptsname_r(int __fd , char *__buf , size_t __buflen )  __attribute__((__nonnull__(2))) ;
extern int getpt(void) ;
extern  __attribute__((__nothrow__)) int getloadavg(double *__loadavg , int __nelem )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int access(char const   *__name , int __type )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int euidaccess(char const   *__name , int __type )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int eaccess(char const   *__name , int __type )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int faccessat(int __fd , char const   *__file , int __type , int __flag )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) __off_t lseek(int __fd , __off_t __offset , int __whence ) ;
extern  __attribute__((__nothrow__)) __off64_t lseek64(int __fd , __off64_t __offset , int __whence ) ;
extern int close(int __fd ) ;
extern ssize_t read(int __fd , void *__buf , size_t __nbytes ) ;
extern ssize_t write(int __fd , void const   *__buf , size_t __n ) ;
extern ssize_t pread(int __fd , void *__buf , size_t __nbytes , __off_t __offset ) ;
extern ssize_t pwrite(int __fd , void const   *__buf , size_t __n , __off_t __offset ) ;
extern ssize_t pread64(int __fd , void *__buf , size_t __nbytes , __off64_t __offset ) ;
extern ssize_t pwrite64(int __fd , void const   *__buf , size_t __n , __off64_t __offset ) ;
extern  __attribute__((__nothrow__)) int pipe(int *__pipedes ) ;
extern  __attribute__((__nothrow__)) int pipe2(int *__pipedes , int __flags ) ;
extern  __attribute__((__nothrow__)) unsigned int alarm(unsigned int __seconds ) ;
extern unsigned int sleep(unsigned int __seconds ) ;
extern  __attribute__((__nothrow__)) __useconds_t ualarm(__useconds_t __value , __useconds_t __interval ) ;
extern int usleep(__useconds_t __useconds ) ;
extern int pause(void) ;
extern  __attribute__((__nothrow__)) int chown(char const   *__file , __uid_t __owner , __gid_t __group )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int fchown(int __fd , __uid_t __owner , __gid_t __group ) ;
extern  __attribute__((__nothrow__)) int lchown(char const   *__file , __uid_t __owner , __gid_t __group )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int fchownat(int __fd , char const   *__file , __uid_t __owner , __gid_t __group , int __flag )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int chdir(char const   *__path )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int fchdir(int __fd ) ;
extern  __attribute__((__nothrow__)) char *getcwd(char *__buf , size_t __size ) ;
extern  __attribute__((__nothrow__)) char *get_current_dir_name(void) ;
extern  __attribute__((__nothrow__)) char *getwd(char *__buf )  __attribute__((__nonnull__(1), __deprecated__)) ;
extern  __attribute__((__nothrow__)) int dup(int __fd ) ;
extern  __attribute__((__nothrow__)) int dup2(int __fd , int __fd2 ) ;
extern  __attribute__((__nothrow__)) int dup3(int __fd , int __fd2 , int __flags ) ;
extern char **__environ ;
extern char **environ ;
extern  __attribute__((__nothrow__)) int execve(char const   *__path , char * const  *__argv , char * const  *__envp )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int fexecve(int __fd , char * const  *__argv , char * const  *__envp )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int execv(char const   *__path , char * const  *__argv )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execle(char const   *__path , char const   *__arg  , ...)  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execl(char const   *__path , char const   *__arg  , ...)  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execvp(char const   *__file , char * const  *__argv )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execlp(char const   *__file , char const   *__arg  , ...)  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execvpe(char const   *__file , char * const  *__argv , char * const  *__envp )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int nice(int __inc ) ;
extern  __attribute__((__noreturn__)) void _exit(int __status ) ;
extern  __attribute__((__nothrow__)) long pathconf(char const   *__path , int __name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long fpathconf(int __fd , int __name ) ;
extern  __attribute__((__nothrow__)) long sysconf(int __name ) ;
extern  __attribute__((__nothrow__)) size_t confstr(int __name , char *__buf , size_t __len ) ;
extern  __attribute__((__nothrow__)) __pid_t getpid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getppid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getpgrp(void) ;
extern  __attribute__((__nothrow__)) __pid_t __getpgid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) __pid_t getpgid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) int setpgid(__pid_t __pid , __pid_t __pgid ) ;
extern  __attribute__((__nothrow__)) int setpgrp(void) ;
extern  __attribute__((__nothrow__)) __pid_t setsid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getsid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) __uid_t getuid(void) ;
extern  __attribute__((__nothrow__)) __uid_t geteuid(void) ;
extern  __attribute__((__nothrow__)) __gid_t getgid(void) ;
extern  __attribute__((__nothrow__)) __gid_t getegid(void) ;
extern  __attribute__((__nothrow__)) int getgroups(int __size , __gid_t *__list ) ;
extern  __attribute__((__nothrow__)) int group_member(__gid_t __gid ) ;
extern  __attribute__((__nothrow__)) int setuid(__uid_t __uid ) ;
extern  __attribute__((__nothrow__)) int setreuid(__uid_t __ruid , __uid_t __euid ) ;
extern  __attribute__((__nothrow__)) int seteuid(__uid_t __uid ) ;
extern  __attribute__((__nothrow__)) int setgid(__gid_t __gid ) ;
extern  __attribute__((__nothrow__)) int setregid(__gid_t __rgid , __gid_t __egid ) ;
extern  __attribute__((__nothrow__)) int setegid(__gid_t __gid ) ;
extern  __attribute__((__nothrow__)) int getresuid(__uid_t *__ruid , __uid_t *__euid , __uid_t *__suid ) ;
extern  __attribute__((__nothrow__)) int getresgid(__gid_t *__rgid , __gid_t *__egid , __gid_t *__sgid ) ;
extern  __attribute__((__nothrow__)) int setresuid(__uid_t __ruid , __uid_t __euid , __uid_t __suid ) ;
extern  __attribute__((__nothrow__)) int setresgid(__gid_t __rgid , __gid_t __egid , __gid_t __sgid ) ;
extern  __attribute__((__nothrow__)) __pid_t fork(void) ;
extern  __attribute__((__nothrow__)) __pid_t vfork(void) ;
extern  __attribute__((__nothrow__)) char *ttyname(int __fd ) ;
extern  __attribute__((__nothrow__)) int ttyname_r(int __fd , char *__buf , size_t __buflen )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int isatty(int __fd ) ;
extern  __attribute__((__nothrow__)) int ttyslot(void) ;
extern  __attribute__((__nothrow__)) int link(char const   *__from , char const   *__to )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int linkat(int __fromfd , char const   *__from , int __tofd , char const   *__to , int __flags )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) int symlink(char const   *__from , char const   *__to )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) ssize_t readlink(char const   * __restrict  __path , char * __restrict  __buf , size_t __len )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int symlinkat(char const   *__from , int __tofd , char const   *__to )  __attribute__((__nonnull__(1,3))) ;
extern  __attribute__((__nothrow__)) ssize_t readlinkat(int __fd , char const   * __restrict  __path , char * __restrict  __buf , size_t __len )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) int unlink(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int unlinkat(int __fd , char const   *__name , int __flag )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int rmdir(char const   *__path )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) __pid_t tcgetpgrp(int __fd ) ;
extern  __attribute__((__nothrow__)) int tcsetpgrp(int __fd , __pid_t __pgrp_id ) ;
extern char *getlogin(void) ;
extern int getlogin_r(char *__name , size_t __name_len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int setlogin(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern char *optarg ;
extern int optind ;
extern int opterr ;
extern int optopt ;
extern  __attribute__((__nothrow__)) int getopt(int ___argc , char * const  *___argv , char const   *__shortopts ) ;
extern  __attribute__((__nothrow__)) int gethostname(char *__name , size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int sethostname(char const   *__name , size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int sethostid(long __id ) ;
extern  __attribute__((__nothrow__)) int getdomainname(char *__name , size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int setdomainname(char const   *__name , size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int vhangup(void) ;
extern  __attribute__((__nothrow__)) int revoke(char const   *__file )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int profil(unsigned short *__sample_buffer , size_t __size , size_t __offset , unsigned int __scale )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int acct(char const   *__name ) ;
extern  __attribute__((__nothrow__)) char *getusershell(void) ;
extern  __attribute__((__nothrow__)) void endusershell(void) ;
extern  __attribute__((__nothrow__)) void setusershell(void) ;
extern  __attribute__((__nothrow__)) int daemon(int __nochdir , int __noclose ) ;
extern  __attribute__((__nothrow__)) int chroot(char const   *__path )  __attribute__((__nonnull__(1))) ;
extern char *getpass(char const   *__prompt )  __attribute__((__nonnull__(1))) ;
extern int fsync(int __fd ) ;
extern long gethostid(void) ;
extern  __attribute__((__nothrow__)) void sync(void) ;
extern  __attribute__((__nothrow__)) int getpagesize(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int getdtablesize(void) ;
extern  __attribute__((__nothrow__)) int truncate(char const   *__file , __off_t __length )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int truncate64(char const   *__file , __off64_t __length )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int ftruncate(int __fd , __off_t __length ) ;
extern  __attribute__((__nothrow__)) int ftruncate64(int __fd , __off64_t __length ) ;
extern  __attribute__((__nothrow__)) int brk(void *__addr ) ;
extern  __attribute__((__nothrow__)) void *sbrk(intptr_t __delta ) ;
extern  __attribute__((__nothrow__)) long syscall(long __sysno  , ...) ;
extern int lockf(int __fd , int __cmd , __off_t __len ) ;
extern int lockf64(int __fd , int __cmd , __off64_t __len ) ;
extern int fdatasync(int __fildes ) ;
extern  __attribute__((__nothrow__)) char *crypt(char const   *__key , char const   *__salt )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void encrypt(char *__block , int __edflag )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void swab(void const   * __restrict  __from , void * __restrict  __to , ssize_t __n )  __attribute__((__nonnull__(1,2))) ;
__inline static Bool toBool(Int x ) 
{ Int r ;
  int tmp ;

  {
  if (x == 0) {
    tmp = 0;
  } else {
    tmp = 1;
  }
  r = tmp;
  return ((unsigned char )r);
}
}
__inline static UChar toUChar(Int x ) 
{ 

  {
  x &= 0xFF;
  return ((unsigned char )x);
}
}
__inline static HChar toHChar(Int x ) 
{ 

  {
  x &= 0xFF;
  return ((char )x);
}
}
__inline static UShort toUShort(Int x ) 
{ 

  {
  x &= 0xFFFF;
  return ((unsigned short )x);
}
}
__inline static Short toShort(Int x ) 
{ 

  {
  x &= 0xFFFF;
  return ((short )x);
}
}
__inline static UInt toUInt(Long x ) 
{ 

  {
  x &= 0xFFFFFFFFLL;
  return ((unsigned int )x);
}
}
__inline static ULong Ptr_to_ULong(void *p ) 
{ UInt w ;

  {
  w = (unsigned int )p;
  return ((unsigned long long )w);
}
}
__inline static void *ULong_to_Ptr(ULong n ) 
{ UInt w ;

  {
  w = (unsigned int )n;
  return ((void *)w);
}
}
__inline static Bool sr_isError(SysRes sr ) 
{ 

  {
  return (sr._isError);
}
}
__inline static UWord sr_Res(SysRes sr ) 
{ UWord tmp ;

  {
  if (sr._isError) {
    tmp = 0UL;
  } else {
    tmp = sr._val;
  }
  return (tmp);
}
}
__inline static UWord sr_ResHI(SysRes sr ) 
{ 

  {
  return (0UL);
}
}
__inline static UWord sr_Err(SysRes sr ) 
{ UWord tmp ;

  {
  if (sr._isError) {
    tmp = sr._val;
  } else {
    tmp = 0UL;
  }
  return (tmp);
}
}
__inline static Bool sr_EQ(SysRes sr1 , SysRes sr2 ) 
{ int tmp ;

  {
  if (sr1._val == sr2._val) {
    if (sr1._isError) {
      if (sr2._isError) {
        tmp = 1;
      } else {
        goto _L;
      }
    } else {
      _L: /* CIL Label */ 
      if (! sr1._isError) {
        if (! sr2._isError) {
          tmp = 1;
        } else {
          tmp = 0;
        }
      } else {
        tmp = 0;
      }
    }
  } else {
    tmp = 0;
  }
  return ((unsigned char )tmp);
}
}
static int ( /* format attribute */  VALGRIND_PRINTF)(char const   *format  , ...)  __attribute__((__unused__)) ;
static int ( /* format attribute */  VALGRIND_PRINTF)(char const   *format  , ...)  __attribute__((__unused__)) ;
static int ( /* format attribute */  VALGRIND_PRINTF)(char const   *format  , ...) 
{ unsigned long _qzz_res ;
  va_list vargs ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;

  {
  __builtin_va_start(vargs, format);
  _zzq_args[0] = (unsigned int volatile   )5123U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )((unsigned long )format));
  _zzq_args[2] = (unsigned int volatile   )((unsigned int )((unsigned long )(& vargs)));
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (0): "cc", "memory");
  _qzz_res = (unsigned long )_zzq_result;
  __builtin_va_end(vargs);
  return ((int )_qzz_res);
}
}
static int ( /* format attribute */  VALGRIND_PRINTF_BACKTRACE)(char const   *format  , ...)  __attribute__((__unused__)) ;
static int ( /* format attribute */  VALGRIND_PRINTF_BACKTRACE)(char const   *format  , ...)  __attribute__((__unused__)) ;
static int ( /* format attribute */  VALGRIND_PRINTF_BACKTRACE)(char const   *format  , ...) 
{ unsigned long _qzz_res ;
  va_list vargs ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;

  {
  __builtin_va_start(vargs, format);
  _zzq_args[0] = (unsigned int volatile   )5124U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )((unsigned long )format));
  _zzq_args[2] = (unsigned int volatile   )((unsigned int )((unsigned long )(& vargs)));
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (0): "cc", "memory");
  _qzz_res = (unsigned long )_zzq_result;
  __builtin_va_end(vargs);
  return ((int )_qzz_res);
}
}
extern void vgDrd_clientreq_init(void) ;
static void vgDrd_init(void)  __attribute__((__constructor__)) ;
static void vgDrd_check_threading_library(void) ;
static void vgDrd_set_main_thread_state(void) ;
static void vgDrd_init(void)  __attribute__((__constructor__)) ;
static void vgDrd_init(void) 
{ 

  {
  vgDrd_check_threading_library();
  vgDrd_set_main_thread_state();
  return;
}
}
static MutexT vgDrd_pthread_to_drd_mutex_type(int kind ) 
{ 

  {
  if (kind == 1) {
    return ((enum __anonenum_MutexT_51 )1);
  } else {
    if (kind == 2) {
      return ((enum __anonenum_MutexT_51 )2);
    } else {
      if (kind == 0) {
        return ((enum __anonenum_MutexT_51 )3);
      } else {
        if (kind == 0) {
          return ((enum __anonenum_MutexT_51 )3);
        } else {
          if (kind == 3) {
            return ((enum __anonenum_MutexT_51 )3);
          } else {
            return ((enum __anonenum_MutexT_51 )0);
          }
        }
      }
    }
  }
}
}
__inline static MutexT ( __attribute__((__always_inline__)) vgDrd_mutex_type)(pthread_mutex_t *mutex ) 
{ int kind ;
  MutexT tmp ;

  {
  if (((unsigned int )(& mutex->__data.__kind) & (sizeof(mutex->__data.__kind) - 1U)) == 0U) {
    kind = mutex->__data.__kind & 3;
    tmp = vgDrd_pthread_to_drd_mutex_type(kind);
    return (tmp);
  } else {

  }
  return ((enum __anonenum_MutexT_51 )-1);
}
}
static void vgDrd_set_joinable(pthread_t tid , int joinable ) 
{ int res ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;

  {
  if (joinable == 0) {

  } else {
    if (joinable == 1) {

    } else {
      __assert_fail("joinable == 0 || joinable == 1", "drd_pthread_intercepts.c", 239U, "vgDrd_set_joinable");
    }
  }
  _zzq_args[0] = (unsigned int volatile   )1148321795U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )tid);
  _zzq_args[2] = (unsigned int volatile   )((unsigned int )joinable);
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (0): "cc", "memory");
  res = (int )_zzq_result;
  return;
}
}
__inline static void ( __attribute__((__always_inline__)) vgDrd_entering_pthread_create)(void) 
{ int res ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;

  {
  _zzq_args[0] = (unsigned int volatile   )1148321796U;
  _zzq_args[1] = (unsigned int volatile   )0U;
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (0): "cc", "memory");
  res = (int )_zzq_result;
  return;
}
}
__inline static void ( __attribute__((__always_inline__)) vgDrd_left_pthread_create)(void) 
{ int res ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;

  {
  _zzq_args[0] = (unsigned int volatile   )1148321797U;
  _zzq_args[1] = (unsigned int volatile   )0U;
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (0): "cc", "memory");
  res = (int )_zzq_result;
  return;
}
}
static void *vgDrd_thread_wrapper(void *arg ) 
{ int res ;
  DrdPosixThreadArgs *arg_ptr ;
  DrdPosixThreadArgs arg_copy ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  pthread_t tmp ;
  pthread_t tmp___0 ;
  void *tmp___1 ;

  {
  arg_ptr = (DrdPosixThreadArgs *)arg;
  arg_copy = *arg_ptr;
  _zzq_args[0] = (unsigned int volatile   )1148321794U;
  tmp = pthread_self();
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )tmp);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  tmp___0 = pthread_self();
  vgDrd_set_joinable(tmp___0, arg_copy.detachstate == 0);
  arg_ptr->wrapper_started = 1;
  tmp___1 = (*(arg_copy.start))(arg_copy.arg);
  return (tmp___1);
}
}
static int vgDrd_detected_linuxthreads(void) 
{ char buffer[256] ;
  unsigned int len ;
  int tmp ;

  {
  len = confstr(3, buffer, sizeof(buffer));
  if (len <= sizeof(buffer)) {

  } else {
    __assert_fail("len <= sizeof(buffer)", "drd_pthread_intercepts.c", 304U, "vgDrd_detected_linuxthreads");
  }
  if (len > 0U) {
    if ((int )buffer[0] == 108) {
      tmp = 1;
    } else {
      tmp = 0;
    }
  } else {
    tmp = 0;
  }
  return (tmp);
}
}
static void vgDrd_check_threading_library(void) 
{ char *tmp ;
  int tmp___0 ;

  {
  tmp___0 = vgDrd_detected_linuxthreads();
  if (tmp___0) {
    tmp = getenv("LD_ASSUME_KERNEL");
    if (tmp) {
      fprintf((FILE */* __restrict  */)stderr, (char const   */* __restrict  */)"Detected the LinuxThreads threading library. Sorry, but DRD only supports\nthe newer NPTL (Native POSIX Threads Library). Please try to rerun DRD\nafter having unset the environment variable LD_ASSUME_KERNEL. Giving up.\n");
    } else {
      fprintf((FILE */* __restrict  */)stderr, (char const   */* __restrict  */)"Detected the LinuxThreads threading library. Sorry, but DRD only supports\nthe newer NPTL (Native POSIX Threads Library). Please try to rerun DRD\nafter having upgraded to a newer version of your Linux distribution.\nGiving up.\n");
    }
    abort();
  } else {

  }
  return;
}
}
static void vgDrd_set_main_thread_state(void) 
{ int res ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  pthread_t tmp ;

  {
  _zzq_args[0] = (unsigned int volatile   )1148321794U;
  tmp = pthread_self();
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )tmp);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  return;
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_create_intercept)(pthread_t *thread , pthread_attr_t const   *attr , void *(*start)(void * ) , void *arg ) 
{ int res ;
  int ret ;
  OrigFn fn ;
  DrdPosixThreadArgs *thread_args_p ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  void *tmp ;
  unsigned int _zzq_rlval ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  int tmp___0 ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[5] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;
  pthread_t tmp___1 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  tmp = malloc(sizeof(*thread_args_p));
  thread_args_p = (DrdPosixThreadArgs *)tmp;
  if (thread_args_p) {

  } else {
    __assert_fail("thread_args_p", "drd_pthread_intercepts.c", 395U, "pthread_create_intercept");
  }
  thread_args_p->start = start;
  thread_args_p->arg = arg;
  _zzq_args[0] = (unsigned int volatile   )1146224642U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )(& thread_args_p->wrapper_started));
  _zzq_args[2] = (unsigned int volatile   )sizeof(thread_args_p->wrapper_started);
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (0): "cc", "memory");
  _zzq_rlval = (unsigned int )_zzq_result;
  thread_args_p->wrapper_started = 0;
  thread_args_p->detachstate = 0;
  if (attr) {
    tmp___0 = pthread_attr_getdetachstate(attr, & thread_args_p->detachstate);
    if (tmp___0 != 0) {
      __assert_fail("0", "drd_pthread_intercepts.c", 411U, "pthread_create_intercept");
    } else {

    }
  } else {

  }
  if (thread_args_p->detachstate == 0) {

  } else {
    if (thread_args_p->detachstate == 1) {

    } else {
      __assert_fail("thread_args_p->detachstate == PTHREAD_CREATE_JOINABLE || thread_args_p->detachstate == PTHREAD_CREATE_DETACHED", "drd_pthread_intercepts.c", 415U, "pthread_create_intercept");
    }
  }
  vgDrd_entering_pthread_create();
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )thread);
    _argvec[2] = (unsigned long volatile   )((unsigned long )attr);
    _argvec[3] = (unsigned long volatile   )((unsigned long )(& vgDrd_thread_wrapper));
    _argvec[4] = (unsigned long volatile   )((unsigned long )thread_args_p);
    __asm__  volatile   ("pushl 16(%%eax)\n\t"
                         "pushl 12(%%eax)\n\t"
                         "pushl 8(%%eax)\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  vgDrd_left_pthread_create();
  if (ret == 0) {
    while (! thread_args_p->wrapper_started) {
      sched_yield();
    }
  } else {

  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321793U;
  tmp___1 = pthread_self();
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )tmp___1);
  _zzq_args___0[2] = (unsigned int volatile   )0U;
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucreate(pthread_t *thread , pthread_attr_t const   *attr , void *(*start)(void * ) , void *arg ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucreate(pthread_t *thread , pthread_attr_t const   *attr , void *(*start)(void * ) , void *arg ) 
{ int tmp ;

  {
  tmp = pthread_create_intercept(thread, attr, start, arg);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucreateZAZa(pthread_t *thread , pthread_attr_t const   *attr , void *(*start)(void * ) , void *arg ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucreateZAZa(pthread_t *thread , pthread_attr_t const   *attr , void *(*start)(void * ) , void *arg ) 
{ int tmp ;

  {
  tmp = pthread_create_intercept(thread, attr, start, arg);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucreateZDZa(pthread_t *thread , pthread_attr_t const   *attr , void *(*start)(void * ) , void *arg ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucreateZDZa(pthread_t *thread , pthread_attr_t const   *attr , void *(*start)(void * ) , void *arg ) 
{ int tmp ;

  {
  tmp = pthread_create_intercept(thread, attr, start, arg);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_join_intercept)(pthread_t pt_joinee , void **thread_return ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[3] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )pt_joinee;
    _argvec[2] = (unsigned long volatile   )((unsigned long )thread_return);
    __asm__  volatile   ("subl $8, %%esp\n\t"
                         "pushl 8(%%eax)\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  if (ret == 0) {
    _zzq_args[0] = (unsigned int volatile   )1148321798U;
    _zzq_args[1] = (unsigned int volatile   )((unsigned int )pt_joinee);
    _zzq_args[2] = (unsigned int volatile   )0U;
    _zzq_args[3] = (unsigned int volatile   )0U;
    _zzq_args[4] = (unsigned int volatile   )0U;
    _zzq_args[5] = (unsigned int volatile   )0U;
    __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
    res = (int )_zzq_result;
  } else {

  }
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZujoin(pthread_t pt_joinee , void **thread_return ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZujoin(pthread_t pt_joinee , void **thread_return ) 
{ int tmp ;

  {
  tmp = pthread_join_intercept(pt_joinee, thread_return);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZujoinZAZa(pthread_t pt_joinee , void **thread_return ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZujoinZAZa(pthread_t pt_joinee , void **thread_return ) 
{ int tmp ;

  {
  tmp = pthread_join_intercept(pt_joinee, thread_return);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZujoinZDZa(pthread_t pt_joinee , void **thread_return ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZujoinZDZa(pthread_t pt_joinee , void **thread_return ) 
{ int tmp ;

  {
  tmp = pthread_join_intercept(pt_joinee, thread_return);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_detach_intercept)(pthread_t pt_thread ) 
{ int ret ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )pt_thread;
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  if (ret == 0) {
    vgDrd_set_joinable(pt_thread, 0);
  } else {

  }
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZudetach(pthread_t thread ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZudetach(pthread_t thread ) 
{ int tmp ;

  {
  tmp = pthread_detach_intercept(thread);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZudetachZAZa(pthread_t thread ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZudetachZAZa(pthread_t thread ) 
{ int tmp ;

  {
  tmp = pthread_detach_intercept(thread);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZudetachZDZa(pthread_t thread ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZudetachZDZa(pthread_t thread ) 
{ int tmp ;

  {
  tmp = pthread_detach_intercept(thread);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_cancel_intercept)(pthread_t pt_thread ) 
{ int res ;
  int ret ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321799U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )pt_thread);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )pt_thread;
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321800U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )pt_thread);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )(ret == 0));
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucancel(pthread_t thread ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucancel(pthread_t thread ) 
{ int tmp ;

  {
  tmp = pthread_cancel_intercept(thread);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucancelZAZa(pthread_t thread ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucancelZAZa(pthread_t thread ) 
{ int tmp ;

  {
  tmp = pthread_cancel_intercept(thread);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucancelZDZa(pthread_t thread ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucancelZDZa(pthread_t thread ) 
{ int tmp ;

  {
  tmp = pthread_cancel_intercept(thread);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_once_intercept)(pthread_once_t *once_control , void (*init_routine)(void) ) 
{ int ret ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int _zzq_rlval ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[3] ;
  unsigned long volatile   _res ;
  unsigned int _zzq_rlval___0 ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1146224642U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )once_control);
  _zzq_args[2] = (unsigned int volatile   )sizeof(*once_control);
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (0): "cc", "memory");
  _zzq_rlval = (unsigned int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )once_control);
    _argvec[2] = (unsigned long volatile   )((unsigned long )init_routine);
    __asm__  volatile   ("subl $8, %%esp\n\t"
                         "pushl 8(%%eax)\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1146224643U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )once_control);
  _zzq_args___0[2] = (unsigned int volatile   )sizeof(*once_control);
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (0): "cc", "memory");
  _zzq_rlval___0 = (unsigned int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZuonce(pthread_once_t *once_control , void (*init_routine)(void) ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZuonce(pthread_once_t *once_control , void (*init_routine)(void) ) 
{ int tmp ;

  {
  tmp = pthread_once_intercept(once_control, init_routine);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZuonceZAZa(pthread_once_t *once_control , void (*init_routine)(void) ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZuonceZAZa(pthread_once_t *once_control , void (*init_routine)(void) ) 
{ int tmp ;

  {
  tmp = pthread_once_intercept(once_control, init_routine);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZuonceZDZa(pthread_once_t *once_control , void (*init_routine)(void) ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZuonceZDZa(pthread_once_t *once_control , void (*init_routine)(void) ) 
{ int tmp ;

  {
  tmp = pthread_once_intercept(once_control, init_routine);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_mutex_init_intercept)(pthread_mutex_t *mutex , pthread_mutexattr_t const   *attr ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  int mt ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  MutexT tmp ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[3] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  mt = 0;
  if (attr) {
    pthread_mutexattr_gettype((pthread_mutexattr_t const   */* __restrict  */)attr, (int */* __restrict  */)(& mt));
  } else {

  }
  _zzq_args[0] = (unsigned int volatile   )1148321801U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )mutex);
  tmp = vgDrd_pthread_to_drd_mutex_type(mt);
  _zzq_args[2] = (unsigned int volatile   )((unsigned int )tmp);
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )mutex);
    _argvec[2] = (unsigned long volatile   )((unsigned long )attr);
    __asm__  volatile   ("subl $8, %%esp\n\t"
                         "pushl 8(%%eax)\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321802U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )mutex);
  _zzq_args___0[2] = (unsigned int volatile   )0U;
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZuinit(pthread_mutex_t *mutex , pthread_mutexattr_t const   *attr ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZuinit(pthread_mutex_t *mutex , pthread_mutexattr_t const   *attr ) 
{ int tmp ;

  {
  tmp = pthread_mutex_init_intercept(mutex, attr);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZuinitZAZa(pthread_mutex_t *mutex , pthread_mutexattr_t const   *attr ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZuinitZAZa(pthread_mutex_t *mutex , pthread_mutexattr_t const   *attr ) 
{ int tmp ;

  {
  tmp = pthread_mutex_init_intercept(mutex, attr);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZuinitZDZa(pthread_mutex_t *mutex , pthread_mutexattr_t const   *attr ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZuinitZDZa(pthread_mutex_t *mutex , pthread_mutexattr_t const   *attr ) 
{ int tmp ;

  {
  tmp = pthread_mutex_init_intercept(mutex, attr);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_mutex_destroy_intercept)(pthread_mutex_t *mutex ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;
  MutexT tmp ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321803U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )mutex);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )mutex);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321804U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )mutex);
  tmp = vgDrd_mutex_type(mutex);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )tmp);
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZudestroy(pthread_mutex_t *mutex ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZudestroy(pthread_mutex_t *mutex ) 
{ int tmp ;

  {
  tmp = pthread_mutex_destroy_intercept(mutex);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZudestroyZAZa(pthread_mutex_t *mutex ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZudestroyZAZa(pthread_mutex_t *mutex ) 
{ int tmp ;

  {
  tmp = pthread_mutex_destroy_intercept(mutex);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZudestroyZDZa(pthread_mutex_t *mutex ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZudestroyZDZa(pthread_mutex_t *mutex ) 
{ int tmp ;

  {
  tmp = pthread_mutex_destroy_intercept(mutex);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_mutex_lock_intercept)(pthread_mutex_t *mutex ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  MutexT tmp ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321805U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )mutex);
  tmp = vgDrd_mutex_type(mutex);
  _zzq_args[2] = (unsigned int volatile   )((unsigned int )tmp);
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (0): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )mutex);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321806U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )mutex);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )(ret == 0));
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (0): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZulock(pthread_mutex_t *mutex ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZulock(pthread_mutex_t *mutex ) 
{ int tmp ;

  {
  tmp = pthread_mutex_lock_intercept(mutex);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZulockZAZa(pthread_mutex_t *mutex ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZulockZAZa(pthread_mutex_t *mutex ) 
{ int tmp ;

  {
  tmp = pthread_mutex_lock_intercept(mutex);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZulockZDZa(pthread_mutex_t *mutex ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZulockZDZa(pthread_mutex_t *mutex ) 
{ int tmp ;

  {
  tmp = pthread_mutex_lock_intercept(mutex);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_mutex_trylock_intercept)(pthread_mutex_t *mutex ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  MutexT tmp ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321805U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )mutex);
  tmp = vgDrd_mutex_type(mutex);
  _zzq_args[2] = (unsigned int volatile   )((unsigned int )tmp);
  _zzq_args[3] = (unsigned int volatile   )1U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (0): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )mutex);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321806U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )mutex);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )(ret == 0));
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZutrylock(pthread_mutex_t *mutex ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZutrylock(pthread_mutex_t *mutex ) 
{ int tmp ;

  {
  tmp = pthread_mutex_trylock_intercept(mutex);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZutrylockZAZa(pthread_mutex_t *mutex ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZutrylockZAZa(pthread_mutex_t *mutex ) 
{ int tmp ;

  {
  tmp = pthread_mutex_trylock_intercept(mutex);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZutrylockZDZa(pthread_mutex_t *mutex ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZutrylockZDZa(pthread_mutex_t *mutex ) 
{ int tmp ;

  {
  tmp = pthread_mutex_trylock_intercept(mutex);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_mutex_timedlock_intercept)(pthread_mutex_t *mutex , struct timespec  const  *abs_timeout ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  MutexT tmp ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[3] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321805U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )mutex);
  tmp = vgDrd_mutex_type(mutex);
  _zzq_args[2] = (unsigned int volatile   )((unsigned int )tmp);
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (0): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )mutex);
    _argvec[2] = (unsigned long volatile   )((unsigned long )abs_timeout);
    __asm__  volatile   ("subl $8, %%esp\n\t"
                         "pushl 8(%%eax)\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321806U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )mutex);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )(ret == 0));
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZutimedlock(pthread_mutex_t *mutex , struct timespec  const  *abs_timeout ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZutimedlock(pthread_mutex_t *mutex , struct timespec  const  *abs_timeout ) 
{ int tmp ;

  {
  tmp = pthread_mutex_timedlock_intercept(mutex, abs_timeout);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZutimedlockZAZa(pthread_mutex_t *mutex , struct timespec  const  *abs_timeout ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZutimedlockZAZa(pthread_mutex_t *mutex , struct timespec  const  *abs_timeout ) 
{ int tmp ;

  {
  tmp = pthread_mutex_timedlock_intercept(mutex, abs_timeout);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZutimedlockZDZa(pthread_mutex_t *mutex , struct timespec  const  *abs_timeout ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZutimedlockZDZa(pthread_mutex_t *mutex , struct timespec  const  *abs_timeout ) 
{ int tmp ;

  {
  tmp = pthread_mutex_timedlock_intercept(mutex, abs_timeout);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_mutex_unlock_intercept)(pthread_mutex_t *mutex ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  MutexT tmp ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321807U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )mutex);
  tmp = vgDrd_mutex_type(mutex);
  _zzq_args[2] = (unsigned int volatile   )((unsigned int )tmp);
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )mutex);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321808U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )mutex);
  _zzq_args___0[2] = (unsigned int volatile   )0U;
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZuunlock(pthread_mutex_t *mutex ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZuunlock(pthread_mutex_t *mutex ) 
{ int tmp ;

  {
  tmp = pthread_mutex_unlock_intercept(mutex);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZuunlockZAZa(pthread_mutex_t *mutex ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZuunlockZAZa(pthread_mutex_t *mutex ) 
{ int tmp ;

  {
  tmp = pthread_mutex_unlock_intercept(mutex);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZuunlockZDZa(pthread_mutex_t *mutex ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZumutexZuunlockZDZa(pthread_mutex_t *mutex ) 
{ int tmp ;

  {
  tmp = pthread_mutex_unlock_intercept(mutex);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_cond_init_intercept)(pthread_cond_t *cond , pthread_condattr_t const   *attr ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[3] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321811U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )cond);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )cond);
    _argvec[2] = (unsigned long volatile   )((unsigned long )attr);
    __asm__  volatile   ("subl $8, %%esp\n\t"
                         "pushl 8(%%eax)\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321812U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )cond);
  _zzq_args___0[2] = (unsigned int volatile   )0U;
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZuinit(pthread_cond_t *cond , pthread_condattr_t const   *attr ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZuinit(pthread_cond_t *cond , pthread_condattr_t const   *attr ) 
{ int tmp ;

  {
  tmp = pthread_cond_init_intercept(cond, attr);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZuinitZAZa(pthread_cond_t *cond , pthread_condattr_t const   *attr ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZuinitZAZa(pthread_cond_t *cond , pthread_condattr_t const   *attr ) 
{ int tmp ;

  {
  tmp = pthread_cond_init_intercept(cond, attr);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZuinitZDZa(pthread_cond_t *cond , pthread_condattr_t const   *attr ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZuinitZDZa(pthread_cond_t *cond , pthread_condattr_t const   *attr ) 
{ int tmp ;

  {
  tmp = pthread_cond_init_intercept(cond, attr);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_cond_destroy_intercept)(pthread_cond_t *cond ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321813U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )cond);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )cond);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321814U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )cond);
  _zzq_args___0[2] = (unsigned int volatile   )0U;
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZudestroy(pthread_cond_t *cond ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZudestroy(pthread_cond_t *cond ) 
{ int tmp ;

  {
  tmp = pthread_cond_destroy_intercept(cond);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZudestroyZAZa(pthread_cond_t *cond ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZudestroyZAZa(pthread_cond_t *cond ) 
{ int tmp ;

  {
  tmp = pthread_cond_destroy_intercept(cond);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZudestroyZDZa(pthread_cond_t *cond ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZudestroyZDZa(pthread_cond_t *cond ) 
{ int tmp ;

  {
  tmp = pthread_cond_destroy_intercept(cond);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_cond_wait_intercept)(pthread_cond_t *cond , pthread_mutex_t *mutex ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  MutexT tmp ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[3] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321815U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )cond);
  _zzq_args[2] = (unsigned int volatile   )((unsigned int )mutex);
  tmp = vgDrd_mutex_type(mutex);
  _zzq_args[3] = (unsigned int volatile   )((unsigned int )tmp);
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )cond);
    _argvec[2] = (unsigned long volatile   )((unsigned long )mutex);
    __asm__  volatile   ("subl $8, %%esp\n\t"
                         "pushl 8(%%eax)\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321816U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )cond);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )mutex);
  _zzq_args___0[3] = (unsigned int volatile   )1U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZuwait(pthread_cond_t *cond , pthread_mutex_t *mutex ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZuwait(pthread_cond_t *cond , pthread_mutex_t *mutex ) 
{ int tmp ;

  {
  tmp = pthread_cond_wait_intercept(cond, mutex);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZuwaitZAZa(pthread_cond_t *cond , pthread_mutex_t *mutex ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZuwaitZAZa(pthread_cond_t *cond , pthread_mutex_t *mutex ) 
{ int tmp ;

  {
  tmp = pthread_cond_wait_intercept(cond, mutex);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZuwaitZDZa(pthread_cond_t *cond , pthread_mutex_t *mutex ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZuwaitZDZa(pthread_cond_t *cond , pthread_mutex_t *mutex ) 
{ int tmp ;

  {
  tmp = pthread_cond_wait_intercept(cond, mutex);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_cond_timedwait_intercept)(pthread_cond_t *cond , pthread_mutex_t *mutex , struct timespec  const  *abstime ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  MutexT tmp ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[4] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321815U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )cond);
  _zzq_args[2] = (unsigned int volatile   )((unsigned int )mutex);
  tmp = vgDrd_mutex_type(mutex);
  _zzq_args[3] = (unsigned int volatile   )((unsigned int )tmp);
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )cond);
    _argvec[2] = (unsigned long volatile   )((unsigned long )mutex);
    _argvec[3] = (unsigned long volatile   )((unsigned long )abstime);
    __asm__  volatile   ("subl $4, %%esp\n\t"
                         "pushl 12(%%eax)\n\t"
                         "pushl 8(%%eax)\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321816U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )cond);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )mutex);
  _zzq_args___0[3] = (unsigned int volatile   )1U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZutimedwait(pthread_cond_t *cond , pthread_mutex_t *mutex , struct timespec  const  *abstime ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZutimedwait(pthread_cond_t *cond , pthread_mutex_t *mutex , struct timespec  const  *abstime ) 
{ int tmp ;

  {
  tmp = pthread_cond_timedwait_intercept(cond, mutex, abstime);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZutimedwaitZAZa(pthread_cond_t *cond , pthread_mutex_t *mutex , struct timespec  const  *abstime ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZutimedwaitZAZa(pthread_cond_t *cond , pthread_mutex_t *mutex , struct timespec  const  *abstime ) 
{ int tmp ;

  {
  tmp = pthread_cond_timedwait_intercept(cond, mutex, abstime);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZutimedwaitZDZa(pthread_cond_t *cond , pthread_mutex_t *mutex , struct timespec  const  *abstime ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZutimedwaitZDZa(pthread_cond_t *cond , pthread_mutex_t *mutex , struct timespec  const  *abstime ) 
{ int tmp ;

  {
  tmp = pthread_cond_timedwait_intercept(cond, mutex, abstime);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_cond_signal_intercept)(pthread_cond_t *cond ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321817U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )cond);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )cond);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321818U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )cond);
  _zzq_args___0[2] = (unsigned int volatile   )0U;
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZusignal(pthread_cond_t *cond ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZusignal(pthread_cond_t *cond ) 
{ int tmp ;

  {
  tmp = pthread_cond_signal_intercept(cond);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZusignalZAZa(pthread_cond_t *cond ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZusignalZAZa(pthread_cond_t *cond ) 
{ int tmp ;

  {
  tmp = pthread_cond_signal_intercept(cond);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZusignalZDZa(pthread_cond_t *cond ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZusignalZDZa(pthread_cond_t *cond ) 
{ int tmp ;

  {
  tmp = pthread_cond_signal_intercept(cond);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_cond_broadcast_intercept)(pthread_cond_t *cond ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321819U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )cond);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )cond);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321820U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )cond);
  _zzq_args___0[2] = (unsigned int volatile   )0U;
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZubroadcast(pthread_cond_t *cond ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZubroadcast(pthread_cond_t *cond ) 
{ int tmp ;

  {
  tmp = pthread_cond_broadcast_intercept(cond);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZubroadcastZAZa(pthread_cond_t *cond ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZubroadcastZAZa(pthread_cond_t *cond ) 
{ int tmp ;

  {
  tmp = pthread_cond_broadcast_intercept(cond);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZubroadcastZDZa(pthread_cond_t *cond ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZucondZubroadcastZDZa(pthread_cond_t *cond ) 
{ int tmp ;

  {
  tmp = pthread_cond_broadcast_intercept(cond);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) sem_init_intercept)(sem_t *sem , int pshared , unsigned int value ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[4] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321821U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )sem);
  _zzq_args[2] = (unsigned int volatile   )((unsigned int )pshared);
  _zzq_args[3] = (unsigned int volatile   )value;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )sem);
    _argvec[2] = (unsigned long volatile   )((unsigned long )pshared);
    _argvec[3] = (unsigned long volatile   )((unsigned long )value);
    __asm__  volatile   ("subl $4, %%esp\n\t"
                         "pushl 12(%%eax)\n\t"
                         "pushl 8(%%eax)\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321822U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )sem);
  _zzq_args___0[2] = (unsigned int volatile   )0U;
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZuinit(sem_t *sem , int pshared , unsigned int value ) ;
int _vgwZZ_libpthreadZdsoZd0_semZuinit(sem_t *sem , int pshared , unsigned int value ) 
{ int tmp ;

  {
  tmp = sem_init_intercept(sem, pshared, value);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZuinitZAZa(sem_t *sem , int pshared , unsigned int value ) ;
int _vgwZZ_libpthreadZdsoZd0_semZuinitZAZa(sem_t *sem , int pshared , unsigned int value ) 
{ int tmp ;

  {
  tmp = sem_init_intercept(sem, pshared, value);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZuinitZDZa(sem_t *sem , int pshared , unsigned int value ) ;
int _vgwZZ_libpthreadZdsoZd0_semZuinitZDZa(sem_t *sem , int pshared , unsigned int value ) 
{ int tmp ;

  {
  tmp = sem_init_intercept(sem, pshared, value);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) sem_destroy_intercept)(sem_t *sem ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321823U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )sem);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )sem);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321824U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )sem);
  _zzq_args___0[2] = (unsigned int volatile   )0U;
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZudestroy(sem_t *sem ) ;
int _vgwZZ_libpthreadZdsoZd0_semZudestroy(sem_t *sem ) 
{ int tmp ;

  {
  tmp = sem_destroy_intercept(sem);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZudestroyZAZa(sem_t *sem ) ;
int _vgwZZ_libpthreadZdsoZd0_semZudestroyZAZa(sem_t *sem ) 
{ int tmp ;

  {
  tmp = sem_destroy_intercept(sem);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZudestroyZDZa(sem_t *sem ) ;
int _vgwZZ_libpthreadZdsoZd0_semZudestroyZDZa(sem_t *sem ) 
{ int tmp ;

  {
  tmp = sem_destroy_intercept(sem);
  return (tmp);
}
}
__inline static sem_t *( __attribute__((__always_inline__)) sem_open_intercept)(char const   *name , int oflag , mode_t mode , unsigned int value ) 
{ sem_t *ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[5] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;
  sem_t *tmp ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321825U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )name);
  _zzq_args[2] = (unsigned int volatile   )((unsigned int )oflag);
  _zzq_args[3] = (unsigned int volatile   )mode;
  _zzq_args[4] = (unsigned int volatile   )value;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )name);
    _argvec[2] = (unsigned long volatile   )((unsigned long )oflag);
    _argvec[3] = (unsigned long volatile   )((unsigned long )mode);
    _argvec[4] = (unsigned long volatile   )((unsigned long )value);
    __asm__  volatile   ("pushl 16(%%eax)\n\t"
                         "pushl 12(%%eax)\n\t"
                         "pushl 8(%%eax)\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (sem_t *)_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321826U;
  if ((unsigned int )ret != (unsigned int )((sem_t *)0)) {
    tmp = ret;
  } else {
    tmp = (sem_t *)0;
  }
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )tmp);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )name);
  _zzq_args___0[3] = (unsigned int volatile   )((unsigned int )oflag);
  _zzq_args___0[4] = (unsigned int volatile   )mode;
  _zzq_args___0[5] = (unsigned int volatile   )value;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
sem_t *_vgwZZ_libpthreadZdsoZd0_semZuopen(char const   *name , int oflag , mode_t mode , unsigned int value ) ;
sem_t *_vgwZZ_libpthreadZdsoZd0_semZuopen(char const   *name , int oflag , mode_t mode , unsigned int value ) 
{ sem_t *tmp ;

  {
  tmp = sem_open_intercept(name, oflag, mode, value);
  return (tmp);
}
}
sem_t *_vgwZZ_libpthreadZdsoZd0_semZuopenZAZa(char const   *name , int oflag , mode_t mode , unsigned int value ) ;
sem_t *_vgwZZ_libpthreadZdsoZd0_semZuopenZAZa(char const   *name , int oflag , mode_t mode , unsigned int value ) 
{ sem_t *tmp ;

  {
  tmp = sem_open_intercept(name, oflag, mode, value);
  return (tmp);
}
}
sem_t *_vgwZZ_libpthreadZdsoZd0_semZuopenZDZa(char const   *name , int oflag , mode_t mode , unsigned int value ) ;
sem_t *_vgwZZ_libpthreadZdsoZd0_semZuopenZDZa(char const   *name , int oflag , mode_t mode , unsigned int value ) 
{ sem_t *tmp ;

  {
  tmp = sem_open_intercept(name, oflag, mode, value);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) sem_close_intercept)(sem_t *sem ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321827U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )sem);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )sem);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321828U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )sem);
  _zzq_args___0[2] = (unsigned int volatile   )0U;
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZuclose(sem_t *sem ) ;
int _vgwZZ_libpthreadZdsoZd0_semZuclose(sem_t *sem ) 
{ int tmp ;

  {
  tmp = sem_close_intercept(sem);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZucloseZAZa(sem_t *sem ) ;
int _vgwZZ_libpthreadZdsoZd0_semZucloseZAZa(sem_t *sem ) 
{ int tmp ;

  {
  tmp = sem_close_intercept(sem);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZucloseZDZa(sem_t *sem ) ;
int _vgwZZ_libpthreadZdsoZd0_semZucloseZDZa(sem_t *sem ) 
{ int tmp ;

  {
  tmp = sem_close_intercept(sem);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) sem_wait_intercept)(sem_t *sem ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321829U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )sem);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )sem);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321830U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )sem);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )(ret == 0));
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZuwait(sem_t *sem ) ;
int _vgwZZ_libpthreadZdsoZd0_semZuwait(sem_t *sem ) 
{ int tmp ;

  {
  tmp = sem_wait_intercept(sem);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZuwaitZAZa(sem_t *sem ) ;
int _vgwZZ_libpthreadZdsoZd0_semZuwaitZAZa(sem_t *sem ) 
{ int tmp ;

  {
  tmp = sem_wait_intercept(sem);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZuwaitZDZa(sem_t *sem ) ;
int _vgwZZ_libpthreadZdsoZd0_semZuwaitZDZa(sem_t *sem ) 
{ int tmp ;

  {
  tmp = sem_wait_intercept(sem);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) sem_trywait_intercept)(sem_t *sem ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321829U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )sem);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )sem);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321830U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )sem);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )(ret == 0));
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZutrywait(sem_t *sem ) ;
int _vgwZZ_libpthreadZdsoZd0_semZutrywait(sem_t *sem ) 
{ int tmp ;

  {
  tmp = sem_trywait_intercept(sem);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZutrywaitZAZa(sem_t *sem ) ;
int _vgwZZ_libpthreadZdsoZd0_semZutrywaitZAZa(sem_t *sem ) 
{ int tmp ;

  {
  tmp = sem_trywait_intercept(sem);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZutrywaitZDZa(sem_t *sem ) ;
int _vgwZZ_libpthreadZdsoZd0_semZutrywaitZDZa(sem_t *sem ) 
{ int tmp ;

  {
  tmp = sem_trywait_intercept(sem);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) sem_timedwait_intercept)(sem_t *sem , struct timespec  const  *abs_timeout ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[3] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321829U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )sem);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )sem);
    _argvec[2] = (unsigned long volatile   )((unsigned long )abs_timeout);
    __asm__  volatile   ("subl $8, %%esp\n\t"
                         "pushl 8(%%eax)\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321830U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )sem);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )(ret == 0));
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZutimedwait(sem_t *sem , struct timespec  const  *abs_timeout ) ;
int _vgwZZ_libpthreadZdsoZd0_semZutimedwait(sem_t *sem , struct timespec  const  *abs_timeout ) 
{ int tmp ;

  {
  tmp = sem_timedwait_intercept(sem, abs_timeout);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZutimedwaitZAZa(sem_t *sem , struct timespec  const  *abs_timeout ) ;
int _vgwZZ_libpthreadZdsoZd0_semZutimedwaitZAZa(sem_t *sem , struct timespec  const  *abs_timeout ) 
{ int tmp ;

  {
  tmp = sem_timedwait_intercept(sem, abs_timeout);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZutimedwaitZDZa(sem_t *sem , struct timespec  const  *abs_timeout ) ;
int _vgwZZ_libpthreadZdsoZd0_semZutimedwaitZDZa(sem_t *sem , struct timespec  const  *abs_timeout ) 
{ int tmp ;

  {
  tmp = sem_timedwait_intercept(sem, abs_timeout);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) sem_post_intercept)(sem_t *sem ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321831U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )sem);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )sem);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321832U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )sem);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )(ret == 0));
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZupost(sem_t *sem ) ;
int _vgwZZ_libpthreadZdsoZd0_semZupost(sem_t *sem ) 
{ int tmp ;

  {
  tmp = sem_post_intercept(sem);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZupostZAZa(sem_t *sem ) ;
int _vgwZZ_libpthreadZdsoZd0_semZupostZAZa(sem_t *sem ) 
{ int tmp ;

  {
  tmp = sem_post_intercept(sem);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_semZupostZDZa(sem_t *sem ) ;
int _vgwZZ_libpthreadZdsoZd0_semZupostZDZa(sem_t *sem ) 
{ int tmp ;

  {
  tmp = sem_post_intercept(sem);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_rwlock_init_intercept)(pthread_rwlock_t *rwlock , pthread_rwlockattr_t const   *attr ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[3] ;
  unsigned long volatile   _res ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321839U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )rwlock);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )rwlock);
    _argvec[2] = (unsigned long volatile   )((unsigned long )attr);
    __asm__  volatile   ("subl $8, %%esp\n\t"
                         "pushl 8(%%eax)\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuinit(pthread_rwlock_t *rwlock , pthread_rwlockattr_t const   *attr ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuinit(pthread_rwlock_t *rwlock , pthread_rwlockattr_t const   *attr ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_init_intercept(rwlock, attr);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuinitZAZa(pthread_rwlock_t *rwlock , pthread_rwlockattr_t const   *attr ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuinitZAZa(pthread_rwlock_t *rwlock , pthread_rwlockattr_t const   *attr ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_init_intercept(rwlock, attr);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuinitZDZa(pthread_rwlock_t *rwlock , pthread_rwlockattr_t const   *attr ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuinitZDZa(pthread_rwlock_t *rwlock , pthread_rwlockattr_t const   *attr ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_init_intercept(rwlock, attr);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_rwlock_destroy_intercept)(pthread_rwlock_t *rwlock ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )rwlock);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args[0] = (unsigned int volatile   )1148321840U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )rwlock);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZudestroy(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZudestroy(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_destroy_intercept(rwlock);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZudestroyZAZa(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZudestroyZAZa(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_destroy_intercept(rwlock);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZudestroyZDZa(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZudestroyZDZa(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_destroy_intercept(rwlock);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_rwlock_rdlock_intercept)(pthread_rwlock_t *rwlock ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321841U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )rwlock);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )rwlock);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321842U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )rwlock);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )(ret == 0));
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZurdlock(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZurdlock(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_rdlock_intercept(rwlock);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZurdlockZAZa(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZurdlockZAZa(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_rdlock_intercept(rwlock);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZurdlockZDZa(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZurdlockZDZa(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_rdlock_intercept(rwlock);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_rwlock_wrlock_intercept)(pthread_rwlock_t *rwlock ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321843U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )rwlock);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )rwlock);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321844U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )rwlock);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )(ret == 0));
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuwrlock(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuwrlock(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_wrlock_intercept(rwlock);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuwrlockZAZa(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuwrlockZAZa(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_wrlock_intercept(rwlock);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuwrlockZDZa(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuwrlockZDZa(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_wrlock_intercept(rwlock);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_rwlock_timedrdlock_intercept)(pthread_rwlock_t *rwlock ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321841U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )rwlock);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )rwlock);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321842U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )rwlock);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )(ret == 0));
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutimedrdlock(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutimedrdlock(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_timedrdlock_intercept(rwlock);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutimedrdlockZAZa(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutimedrdlockZAZa(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_timedrdlock_intercept(rwlock);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutimedrdlockZDZa(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutimedrdlockZDZa(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_timedrdlock_intercept(rwlock);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_rwlock_timedwrlock_intercept)(pthread_rwlock_t *rwlock ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321843U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )rwlock);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )rwlock);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321844U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )rwlock);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )(ret == 0));
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutimedwrlock(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutimedwrlock(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_timedwrlock_intercept(rwlock);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutimedwrlockZAZa(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutimedwrlockZAZa(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_timedwrlock_intercept(rwlock);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutimedwrlockZDZa(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutimedwrlockZDZa(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_timedwrlock_intercept(rwlock);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_rwlock_tryrdlock_intercept)(pthread_rwlock_t *rwlock ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321841U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )rwlock);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )rwlock);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321842U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )rwlock);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )(ret == 0));
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutryrdlock(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutryrdlock(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_tryrdlock_intercept(rwlock);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutryrdlockZAZa(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutryrdlockZAZa(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_tryrdlock_intercept(rwlock);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutryrdlockZDZa(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutryrdlockZDZa(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_tryrdlock_intercept(rwlock);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_rwlock_trywrlock_intercept)(pthread_rwlock_t *rwlock ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321843U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )rwlock);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )rwlock);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321844U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )rwlock);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )(ret == 0));
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutrywrlock(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutrywrlock(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_trywrlock_intercept(rwlock);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutrywrlockZAZa(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutrywrlockZAZa(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_trywrlock_intercept(rwlock);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutrywrlockZDZa(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZutrywrlockZDZa(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_trywrlock_intercept(rwlock);
  return (tmp);
}
}
__inline static int ( __attribute__((__always_inline__)) pthread_rwlock_unlock_intercept)(pthread_rwlock_t *rwlock ) 
{ int ret ;
  int res ;
  OrigFn fn ;
  OrigFn volatile   *_zzq_orig ;
  unsigned int volatile   __addr ;
  unsigned int volatile   _zzq_args[6] ;
  unsigned int volatile   _zzq_result ;
  OrigFn volatile   _orig ;
  unsigned long volatile   _argvec[2] ;
  unsigned long volatile   _res ;
  unsigned int volatile   _zzq_args___0[6] ;
  unsigned int volatile   _zzq_result___0 ;

  {
  _zzq_orig = (OrigFn volatile   *)(& fn);
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ecx,%%ecx": "=a" (__addr): : "cc", "memory");
  _zzq_orig->nraddr = __addr;
  _zzq_args[0] = (unsigned int volatile   )1148321845U;
  _zzq_args[1] = (unsigned int volatile   )((unsigned int )rwlock);
  _zzq_args[2] = (unsigned int volatile   )0U;
  _zzq_args[3] = (unsigned int volatile   )0U;
  _zzq_args[4] = (unsigned int volatile   )0U;
  _zzq_args[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result): "a" (& _zzq_args[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result;
  while (1) {
    _orig = fn;
    _argvec[0] = (unsigned long volatile   )((unsigned long )_orig.nraddr);
    _argvec[1] = (unsigned long volatile   )((unsigned long )rwlock);
    __asm__  volatile   ("subl $12, %%esp\n\t"
                         "pushl 4(%%eax)\n\t"
                         "movl (%%eax), %%eax\n\t"
                         "roll $3,  %%edi ; roll $13, %%edi\n\t"
                         "roll $29, %%edi ; roll $19, %%edi\n\t"
                         "xchgl %%edx,%%edx\n\t"
                         "addl $16, %%esp\n": "=a" (_res): "a" (& _argvec[0]): "cc", "memory", "ecx", "edx");
    ret = (int )_res;
    break;
  }
  _zzq_args___0[0] = (unsigned int volatile   )1148321846U;
  _zzq_args___0[1] = (unsigned int volatile   )((unsigned int )rwlock);
  _zzq_args___0[2] = (unsigned int volatile   )((unsigned int )(ret == 0));
  _zzq_args___0[3] = (unsigned int volatile   )0U;
  _zzq_args___0[4] = (unsigned int volatile   )0U;
  _zzq_args___0[5] = (unsigned int volatile   )0U;
  __asm__  volatile   ("roll $3,  %%edi ; roll $13, %%edi\n\t"
                       "roll $29, %%edi ; roll $19, %%edi\n\t"
                       "xchgl %%ebx,%%ebx": "=d" (_zzq_result___0): "a" (& _zzq_args___0[0]), "0" (-1): "cc", "memory");
  res = (int )_zzq_result___0;
  return (ret);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuunlock(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuunlock(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_unlock_intercept(rwlock);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuunlockZAZa(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuunlockZAZa(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_unlock_intercept(rwlock);
  return (tmp);
}
}
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuunlockZDZa(pthread_rwlock_t *rwlock ) ;
int _vgwZZ_libpthreadZdsoZd0_pthreadZurwlockZuunlockZDZa(pthread_rwlock_t *rwlock ) 
{ int tmp ;

  {
  tmp = pthread_rwlock_unlock_intercept(rwlock);
  return (tmp);
}
}
