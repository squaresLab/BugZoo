#define anytostr inttostr
#define inttype int
#define inttype_is_signed 1
#include "anytostr.c"
