from importlib.test.__main__ import test_main


if __name__ == '__main__':
    test_main()
