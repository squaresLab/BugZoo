typedef unsigned int size_t;
typedef unsigned char __u_char;
typedef unsigned short __u_short;
typedef unsigned int __u_int;
typedef unsigned long __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;
typedef long long __quad_t;
typedef unsigned long long __u_quad_t;
typedef __u_quad_t __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef __u_quad_t __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long __off_t;
typedef __quad_t __off64_t;
typedef int __pid_t;
struct __anonstruct___fsid_t_1 {
   int __val[2] ;
};
typedef struct __anonstruct___fsid_t_1 __fsid_t;
typedef long __clock_t;
typedef unsigned long __rlim_t;
typedef __u_quad_t __rlim64_t;
typedef unsigned int __id_t;
typedef long __time_t;
typedef unsigned int __useconds_t;
typedef long __suseconds_t;
typedef int __daddr_t;
typedef long __swblk_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void *__timer_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef __quad_t __blkcnt64_t;
typedef unsigned long __fsblkcnt_t;
typedef __u_quad_t __fsblkcnt64_t;
typedef unsigned long __fsfilcnt_t;
typedef __u_quad_t __fsfilcnt64_t;
typedef int __ssize_t;
typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;
typedef int __intptr_t;
typedef unsigned int __socklen_t;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_3 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_2 {
   int __count ;
   union __anonunion___value_3 __value ;
};
typedef struct __anonstruct___mbstate_t_2 __mbstate_t;
struct __anonstruct__G_fpos_t_4 {
   __off_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos_t_4 _G_fpos_t;
struct __anonstruct__G_fpos64_t_5 {
   __off64_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos64_t_5 _G_fpos64_t;
typedef short _G_int16_t;
typedef int _G_int32_t;
typedef unsigned short _G_uint16_t;
typedef unsigned int _G_uint32_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_jump_t;
struct _IO_jump_t;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
enum __codecvt_result {
    __codecvt_ok = 0,
    __codecvt_partial = 1,
    __codecvt_error = 2,
    __codecvt_noconv = 3
} ;
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15U * sizeof(int ) - 4U * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
struct _IO_FILE_plus;
struct _IO_FILE_plus;
typedef __ssize_t __io_read_fn(void *__cookie , char *__buf , size_t __nbytes );
typedef __ssize_t __io_write_fn(void *__cookie , char const   *__buf , size_t __n );
typedef int __io_seek_fn(void *__cookie , __off64_t *__pos , int __w );
typedef int __io_close_fn(void *__cookie );
typedef __io_read_fn cookie_read_function_t;
typedef __io_write_fn cookie_write_function_t;
typedef __io_seek_fn cookie_seek_function_t;
typedef __io_close_fn cookie_close_function_t;
struct __anonstruct__IO_cookie_io_functions_t_6 {
   __io_read_fn *read ;
   __io_write_fn *write ;
   __io_seek_fn *seek ;
   __io_close_fn *close ;
};
typedef struct __anonstruct__IO_cookie_io_functions_t_6 _IO_cookie_io_functions_t;
typedef _IO_cookie_io_functions_t cookie_io_functions_t;
struct _IO_cookie_file;
struct _IO_cookie_file;
typedef __gnuc_va_list va_list;
typedef __off64_t off_t;
typedef __off64_t off64_t;
typedef __ssize_t ssize_t;
typedef _G_fpos64_t fpos_t;
typedef _G_fpos64_t fpos64_t;
struct obstack;
struct obstack;
struct __locale_data;
struct __locale_struct {
   struct __locale_data *__locales[13] ;
   unsigned short const   *__ctype_b ;
   int const   *__ctype_tolower ;
   int const   *__ctype_toupper ;
   char const   *__names[13] ;
};
typedef struct __locale_struct *__locale_t;
typedef __locale_t locale_t;
typedef int error_t;
typedef long wchar_t;
struct __anonstruct___wait_terminated_7 {
   unsigned int __w_termsig : 7 ;
   unsigned int __w_coredump : 1 ;
   unsigned int __w_retcode : 8 ;
   unsigned int  : 16 ;
};
struct __anonstruct___wait_stopped_8 {
   unsigned int __w_stopval : 8 ;
   unsigned int __w_stopsig : 8 ;
   unsigned int  : 16 ;
};
union wait {
   int w_status ;
   struct __anonstruct___wait_terminated_7 __wait_terminated ;
   struct __anonstruct___wait_stopped_8 __wait_stopped ;
};
union __anonunion___WAIT_STATUS_9 {
   union wait *__uptr ;
   int *__iptr ;
};
typedef union __anonunion___WAIT_STATUS_9  __attribute__((__transparent_union__)) __WAIT_STATUS;
struct __anonstruct_div_t_10 {
   int quot ;
   int rem ;
};
typedef struct __anonstruct_div_t_10 div_t;
struct __anonstruct_ldiv_t_11 {
   long quot ;
   long rem ;
};
typedef struct __anonstruct_ldiv_t_11 ldiv_t;
struct __anonstruct_lldiv_t_12 {
   long long quot ;
   long long rem ;
};
typedef struct __anonstruct_lldiv_t_12 lldiv_t;
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;
typedef __loff_t loff_t;
typedef __ino64_t ino_t;
typedef __ino64_t ino64_t;
typedef __dev_t dev_t;
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __nlink_t nlink_t;
typedef __uid_t uid_t;
typedef __pid_t pid_t;
typedef __id_t id_t;
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;
typedef __key_t key_t;
typedef __clock_t clock_t;
typedef __time_t time_t;
typedef __clockid_t clockid_t;
typedef __timer_t timer_t;
typedef __useconds_t useconds_t;
typedef __suseconds_t suseconds_t;
typedef unsigned long ulong;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char u_int8_t;
typedef unsigned short u_int16_t;
typedef unsigned int u_int32_t;
typedef unsigned long long u_int64_t;
typedef int register_t;
typedef int __sig_atomic_t;
struct __anonstruct___sigset_t_13 {
   unsigned long __val[1024U / (8U * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_13 __sigset_t;
typedef __sigset_t sigset_t;
struct timespec {
   __time_t tv_sec ;
   long tv_nsec ;
};
struct timeval {
   __time_t tv_sec ;
   __suseconds_t tv_usec ;
};
typedef long __fd_mask;
struct __anonstruct_fd_set_14 {
   __fd_mask fds_bits[1024 / (8 * (int )sizeof(__fd_mask ))] ;
};
typedef struct __anonstruct_fd_set_14 fd_set;
typedef __fd_mask fd_mask;
typedef __blksize_t blksize_t;
typedef __blkcnt64_t blkcnt_t;
typedef __fsblkcnt64_t fsblkcnt_t;
typedef __fsfilcnt64_t fsfilcnt_t;
typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;
typedef unsigned long pthread_t;
union __anonunion_pthread_attr_t_15 {
   char __size[36] ;
   long __align ;
};
typedef union __anonunion_pthread_attr_t_15 pthread_attr_t;
struct __pthread_internal_slist {
   struct __pthread_internal_slist *__next ;
};
typedef struct __pthread_internal_slist __pthread_slist_t;
union __anonunion____missing_field_name_17 {
   int __spins ;
   __pthread_slist_t __list ;
};
struct __pthread_mutex_s {
   int __lock ;
   unsigned int __count ;
   int __owner ;
   int __kind ;
   unsigned int __nusers ;
   union __anonunion____missing_field_name_17 __annonCompField1 ;
};
union __anonunion_pthread_mutex_t_16 {
   struct __pthread_mutex_s __data ;
   char __size[24] ;
   long __align ;
};
typedef union __anonunion_pthread_mutex_t_16 pthread_mutex_t;
union __anonunion_pthread_mutexattr_t_18 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_mutexattr_t_18 pthread_mutexattr_t;
struct __anonstruct___data_20 {
   int __lock ;
   unsigned int __futex ;
   unsigned long long __total_seq ;
   unsigned long long __wakeup_seq ;
   unsigned long long __woken_seq ;
   void *__mutex ;
   unsigned int __nwaiters ;
   unsigned int __broadcast_seq ;
};
union __anonunion_pthread_cond_t_19 {
   struct __anonstruct___data_20 __data ;
   char __size[48] ;
   long long __align ;
};
typedef union __anonunion_pthread_cond_t_19 pthread_cond_t;
union __anonunion_pthread_condattr_t_21 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_condattr_t_21 pthread_condattr_t;
typedef unsigned int pthread_key_t;
typedef int pthread_once_t;
struct __anonstruct___data_23 {
   int __lock ;
   unsigned int __nr_readers ;
   unsigned int __readers_wakeup ;
   unsigned int __writer_wakeup ;
   unsigned int __nr_readers_queued ;
   unsigned int __nr_writers_queued ;
   unsigned char __flags ;
   unsigned char __shared ;
   unsigned char __pad1 ;
   unsigned char __pad2 ;
   int __writer ;
};
union __anonunion_pthread_rwlock_t_22 {
   struct __anonstruct___data_23 __data ;
   char __size[32] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlock_t_22 pthread_rwlock_t;
union __anonunion_pthread_rwlockattr_t_24 {
   char __size[8] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlockattr_t_24 pthread_rwlockattr_t;
typedef int volatile   pthread_spinlock_t;
union __anonunion_pthread_barrier_t_25 {
   char __size[20] ;
   long __align ;
};
typedef union __anonunion_pthread_barrier_t_25 pthread_barrier_t;
union __anonunion_pthread_barrierattr_t_26 {
   char __size[4] ;
   int __align ;
};
typedef union __anonunion_pthread_barrierattr_t_26 pthread_barrierattr_t;
struct random_data {
   int32_t *fptr ;
   int32_t *rptr ;
   int32_t *state ;
   int rand_type ;
   int rand_deg ;
   int rand_sep ;
   int32_t *end_ptr ;
};
struct drand48_data {
   unsigned short __x[3] ;
   unsigned short __old_x[3] ;
   unsigned short __c ;
   unsigned short __init ;
   unsigned long long __a ;
};
typedef int (*__compar_fn_t)(void const   * , void const   * );
typedef int (*comparison_fn_t)(void const   * , void const   * );
typedef int (*__compar_d_fn_t)(void const   * , void const   * , void * );
typedef __intptr_t intptr_t;
typedef __socklen_t socklen_t;
enum __anonenum_27 {
    _PC_LINK_MAX = 0,
    _PC_MAX_CANON = 1,
    _PC_MAX_INPUT = 2,
    _PC_NAME_MAX = 3,
    _PC_PATH_MAX = 4,
    _PC_PIPE_BUF = 5,
    _PC_CHOWN_RESTRICTED = 6,
    _PC_NO_TRUNC = 7,
    _PC_VDISABLE = 8,
    _PC_SYNC_IO = 9,
    _PC_ASYNC_IO = 10,
    _PC_PRIO_IO = 11,
    _PC_SOCK_MAXBUF = 12,
    _PC_FILESIZEBITS = 13,
    _PC_REC_INCR_XFER_SIZE = 14,
    _PC_REC_MAX_XFER_SIZE = 15,
    _PC_REC_MIN_XFER_SIZE = 16,
    _PC_REC_XFER_ALIGN = 17,
    _PC_ALLOC_SIZE_MIN = 18,
    _PC_SYMLINK_MAX = 19,
    _PC_2_SYMLINKS = 20
} ;
enum __anonenum_28 {
    _SC_ARG_MAX = 0,
    _SC_CHILD_MAX = 1,
    _SC_CLK_TCK = 2,
    _SC_NGROUPS_MAX = 3,
    _SC_OPEN_MAX = 4,
    _SC_STREAM_MAX = 5,
    _SC_TZNAME_MAX = 6,
    _SC_JOB_CONTROL = 7,
    _SC_SAVED_IDS = 8,
    _SC_REALTIME_SIGNALS = 9,
    _SC_PRIORITY_SCHEDULING = 10,
    _SC_TIMERS = 11,
    _SC_ASYNCHRONOUS_IO = 12,
    _SC_PRIORITIZED_IO = 13,
    _SC_SYNCHRONIZED_IO = 14,
    _SC_FSYNC = 15,
    _SC_MAPPED_FILES = 16,
    _SC_MEMLOCK = 17,
    _SC_MEMLOCK_RANGE = 18,
    _SC_MEMORY_PROTECTION = 19,
    _SC_MESSAGE_PASSING = 20,
    _SC_SEMAPHORES = 21,
    _SC_SHARED_MEMORY_OBJECTS = 22,
    _SC_AIO_LISTIO_MAX = 23,
    _SC_AIO_MAX = 24,
    _SC_AIO_PRIO_DELTA_MAX = 25,
    _SC_DELAYTIMER_MAX = 26,
    _SC_MQ_OPEN_MAX = 27,
    _SC_MQ_PRIO_MAX = 28,
    _SC_VERSION = 29,
    _SC_PAGESIZE = 30,
    _SC_RTSIG_MAX = 31,
    _SC_SEM_NSEMS_MAX = 32,
    _SC_SEM_VALUE_MAX = 33,
    _SC_SIGQUEUE_MAX = 34,
    _SC_TIMER_MAX = 35,
    _SC_BC_BASE_MAX = 36,
    _SC_BC_DIM_MAX = 37,
    _SC_BC_SCALE_MAX = 38,
    _SC_BC_STRING_MAX = 39,
    _SC_COLL_WEIGHTS_MAX = 40,
    _SC_EQUIV_CLASS_MAX = 41,
    _SC_EXPR_NEST_MAX = 42,
    _SC_LINE_MAX = 43,
    _SC_RE_DUP_MAX = 44,
    _SC_CHARCLASS_NAME_MAX = 45,
    _SC_2_VERSION = 46,
    _SC_2_C_BIND = 47,
    _SC_2_C_DEV = 48,
    _SC_2_FORT_DEV = 49,
    _SC_2_FORT_RUN = 50,
    _SC_2_SW_DEV = 51,
    _SC_2_LOCALEDEF = 52,
    _SC_PII = 53,
    _SC_PII_XTI = 54,
    _SC_PII_SOCKET = 55,
    _SC_PII_INTERNET = 56,
    _SC_PII_OSI = 57,
    _SC_POLL = 58,
    _SC_SELECT = 59,
    _SC_UIO_MAXIOV = 60,
    _SC_IOV_MAX = 60,
    _SC_PII_INTERNET_STREAM = 61,
    _SC_PII_INTERNET_DGRAM = 62,
    _SC_PII_OSI_COTS = 63,
    _SC_PII_OSI_CLTS = 64,
    _SC_PII_OSI_M = 65,
    _SC_T_IOV_MAX = 66,
    _SC_THREADS = 67,
    _SC_THREAD_SAFE_FUNCTIONS = 68,
    _SC_GETGR_R_SIZE_MAX = 69,
    _SC_GETPW_R_SIZE_MAX = 70,
    _SC_LOGIN_NAME_MAX = 71,
    _SC_TTY_NAME_MAX = 72,
    _SC_THREAD_DESTRUCTOR_ITERATIONS = 73,
    _SC_THREAD_KEYS_MAX = 74,
    _SC_THREAD_STACK_MIN = 75,
    _SC_THREAD_THREADS_MAX = 76,
    _SC_THREAD_ATTR_STACKADDR = 77,
    _SC_THREAD_ATTR_STACKSIZE = 78,
    _SC_THREAD_PRIORITY_SCHEDULING = 79,
    _SC_THREAD_PRIO_INHERIT = 80,
    _SC_THREAD_PRIO_PROTECT = 81,
    _SC_THREAD_PROCESS_SHARED = 82,
    _SC_NPROCESSORS_CONF = 83,
    _SC_NPROCESSORS_ONLN = 84,
    _SC_PHYS_PAGES = 85,
    _SC_AVPHYS_PAGES = 86,
    _SC_ATEXIT_MAX = 87,
    _SC_PASS_MAX = 88,
    _SC_XOPEN_VERSION = 89,
    _SC_XOPEN_XCU_VERSION = 90,
    _SC_XOPEN_UNIX = 91,
    _SC_XOPEN_CRYPT = 92,
    _SC_XOPEN_ENH_I18N = 93,
    _SC_XOPEN_SHM = 94,
    _SC_2_CHAR_TERM = 95,
    _SC_2_C_VERSION = 96,
    _SC_2_UPE = 97,
    _SC_XOPEN_XPG2 = 98,
    _SC_XOPEN_XPG3 = 99,
    _SC_XOPEN_XPG4 = 100,
    _SC_CHAR_BIT = 101,
    _SC_CHAR_MAX = 102,
    _SC_CHAR_MIN = 103,
    _SC_INT_MAX = 104,
    _SC_INT_MIN = 105,
    _SC_LONG_BIT = 106,
    _SC_WORD_BIT = 107,
    _SC_MB_LEN_MAX = 108,
    _SC_NZERO = 109,
    _SC_SSIZE_MAX = 110,
    _SC_SCHAR_MAX = 111,
    _SC_SCHAR_MIN = 112,
    _SC_SHRT_MAX = 113,
    _SC_SHRT_MIN = 114,
    _SC_UCHAR_MAX = 115,
    _SC_UINT_MAX = 116,
    _SC_ULONG_MAX = 117,
    _SC_USHRT_MAX = 118,
    _SC_NL_ARGMAX = 119,
    _SC_NL_LANGMAX = 120,
    _SC_NL_MSGMAX = 121,
    _SC_NL_NMAX = 122,
    _SC_NL_SETMAX = 123,
    _SC_NL_TEXTMAX = 124,
    _SC_XBS5_ILP32_OFF32 = 125,
    _SC_XBS5_ILP32_OFFBIG = 126,
    _SC_XBS5_LP64_OFF64 = 127,
    _SC_XBS5_LPBIG_OFFBIG = 128,
    _SC_XOPEN_LEGACY = 129,
    _SC_XOPEN_REALTIME = 130,
    _SC_XOPEN_REALTIME_THREADS = 131,
    _SC_ADVISORY_INFO = 132,
    _SC_BARRIERS = 133,
    _SC_BASE = 134,
    _SC_C_LANG_SUPPORT = 135,
    _SC_C_LANG_SUPPORT_R = 136,
    _SC_CLOCK_SELECTION = 137,
    _SC_CPUTIME = 138,
    _SC_THREAD_CPUTIME = 139,
    _SC_DEVICE_IO = 140,
    _SC_DEVICE_SPECIFIC = 141,
    _SC_DEVICE_SPECIFIC_R = 142,
    _SC_FD_MGMT = 143,
    _SC_FIFO = 144,
    _SC_PIPE = 145,
    _SC_FILE_ATTRIBUTES = 146,
    _SC_FILE_LOCKING = 147,
    _SC_FILE_SYSTEM = 148,
    _SC_MONOTONIC_CLOCK = 149,
    _SC_MULTI_PROCESS = 150,
    _SC_SINGLE_PROCESS = 151,
    _SC_NETWORKING = 152,
    _SC_READER_WRITER_LOCKS = 153,
    _SC_SPIN_LOCKS = 154,
    _SC_REGEXP = 155,
    _SC_REGEX_VERSION = 156,
    _SC_SHELL = 157,
    _SC_SIGNALS = 158,
    _SC_SPAWN = 159,
    _SC_SPORADIC_SERVER = 160,
    _SC_THREAD_SPORADIC_SERVER = 161,
    _SC_SYSTEM_DATABASE = 162,
    _SC_SYSTEM_DATABASE_R = 163,
    _SC_TIMEOUTS = 164,
    _SC_TYPED_MEMORY_OBJECTS = 165,
    _SC_USER_GROUPS = 166,
    _SC_USER_GROUPS_R = 167,
    _SC_2_PBS = 168,
    _SC_2_PBS_ACCOUNTING = 169,
    _SC_2_PBS_LOCATE = 170,
    _SC_2_PBS_MESSAGE = 171,
    _SC_2_PBS_TRACK = 172,
    _SC_SYMLOOP_MAX = 173,
    _SC_STREAMS = 174,
    _SC_2_PBS_CHECKPOINT = 175,
    _SC_V6_ILP32_OFF32 = 176,
    _SC_V6_ILP32_OFFBIG = 177,
    _SC_V6_LP64_OFF64 = 178,
    _SC_V6_LPBIG_OFFBIG = 179,
    _SC_HOST_NAME_MAX = 180,
    _SC_TRACE = 181,
    _SC_TRACE_EVENT_FILTER = 182,
    _SC_TRACE_INHERIT = 183,
    _SC_TRACE_LOG = 184,
    _SC_LEVEL1_ICACHE_SIZE = 185,
    _SC_LEVEL1_ICACHE_ASSOC = 186,
    _SC_LEVEL1_ICACHE_LINESIZE = 187,
    _SC_LEVEL1_DCACHE_SIZE = 188,
    _SC_LEVEL1_DCACHE_ASSOC = 189,
    _SC_LEVEL1_DCACHE_LINESIZE = 190,
    _SC_LEVEL2_CACHE_SIZE = 191,
    _SC_LEVEL2_CACHE_ASSOC = 192,
    _SC_LEVEL2_CACHE_LINESIZE = 193,
    _SC_LEVEL3_CACHE_SIZE = 194,
    _SC_LEVEL3_CACHE_ASSOC = 195,
    _SC_LEVEL3_CACHE_LINESIZE = 196,
    _SC_LEVEL4_CACHE_SIZE = 197,
    _SC_LEVEL4_CACHE_ASSOC = 198,
    _SC_LEVEL4_CACHE_LINESIZE = 199,
    _SC_IPV6 = 235,
    _SC_RAW_SOCKETS = 236,
    _SC_V7_ILP32_OFF32 = 237,
    _SC_V7_ILP32_OFFBIG = 238,
    _SC_V7_LP64_OFF64 = 239,
    _SC_V7_LPBIG_OFFBIG = 240,
    _SC_SS_REPL_MAX = 241,
    _SC_TRACE_EVENT_NAME_MAX = 242,
    _SC_TRACE_NAME_MAX = 243,
    _SC_TRACE_SYS_MAX = 244,
    _SC_TRACE_USER_EVENT_MAX = 245,
    _SC_XOPEN_STREAMS = 246,
    _SC_THREAD_ROBUST_PRIO_INHERIT = 247,
    _SC_THREAD_ROBUST_PRIO_PROTECT = 248
} ;
enum __anonenum_29 {
    _CS_PATH = 0,
    _CS_V6_WIDTH_RESTRICTED_ENVS = 1,
    _CS_GNU_LIBC_VERSION = 2,
    _CS_GNU_LIBPTHREAD_VERSION = 3,
    _CS_V5_WIDTH_RESTRICTED_ENVS = 4,
    _CS_V7_WIDTH_RESTRICTED_ENVS = 5,
    _CS_LFS_CFLAGS = 1000,
    _CS_LFS_LDFLAGS = 1001,
    _CS_LFS_LIBS = 1002,
    _CS_LFS_LINTFLAGS = 1003,
    _CS_LFS64_CFLAGS = 1004,
    _CS_LFS64_LDFLAGS = 1005,
    _CS_LFS64_LIBS = 1006,
    _CS_LFS64_LINTFLAGS = 1007,
    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,
    _CS_XBS5_ILP32_OFF32_LDFLAGS = 1101,
    _CS_XBS5_ILP32_OFF32_LIBS = 1102,
    _CS_XBS5_ILP32_OFF32_LINTFLAGS = 1103,
    _CS_XBS5_ILP32_OFFBIG_CFLAGS = 1104,
    _CS_XBS5_ILP32_OFFBIG_LDFLAGS = 1105,
    _CS_XBS5_ILP32_OFFBIG_LIBS = 1106,
    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS = 1107,
    _CS_XBS5_LP64_OFF64_CFLAGS = 1108,
    _CS_XBS5_LP64_OFF64_LDFLAGS = 1109,
    _CS_XBS5_LP64_OFF64_LIBS = 1110,
    _CS_XBS5_LP64_OFF64_LINTFLAGS = 1111,
    _CS_XBS5_LPBIG_OFFBIG_CFLAGS = 1112,
    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS = 1113,
    _CS_XBS5_LPBIG_OFFBIG_LIBS = 1114,
    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS = 1115,
    _CS_POSIX_V6_ILP32_OFF32_CFLAGS = 1116,
    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS = 1117,
    _CS_POSIX_V6_ILP32_OFF32_LIBS = 1118,
    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS = 1119,
    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS = 1120,
    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS = 1121,
    _CS_POSIX_V6_ILP32_OFFBIG_LIBS = 1122,
    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS = 1123,
    _CS_POSIX_V6_LP64_OFF64_CFLAGS = 1124,
    _CS_POSIX_V6_LP64_OFF64_LDFLAGS = 1125,
    _CS_POSIX_V6_LP64_OFF64_LIBS = 1126,
    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS = 1127,
    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS = 1128,
    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS = 1129,
    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS = 1130,
    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS = 1131,
    _CS_POSIX_V7_ILP32_OFF32_CFLAGS = 1132,
    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS = 1133,
    _CS_POSIX_V7_ILP32_OFF32_LIBS = 1134,
    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS = 1135,
    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS = 1136,
    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS = 1137,
    _CS_POSIX_V7_ILP32_OFFBIG_LIBS = 1138,
    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS = 1139,
    _CS_POSIX_V7_LP64_OFF64_CFLAGS = 1140,
    _CS_POSIX_V7_LP64_OFF64_LDFLAGS = 1141,
    _CS_POSIX_V7_LP64_OFF64_LIBS = 1142,
    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS = 1143,
    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS = 1144,
    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS = 1145,
    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS = 1146,
    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS = 1147,
    _CS_V6_ENV = 1148,
    _CS_V7_ENV = 1149
} ;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef signed char int_least8_t;
typedef short int_least16_t;
typedef int int_least32_t;
typedef long long int_least64_t;
typedef unsigned char uint_least8_t;
typedef unsigned short uint_least16_t;
typedef unsigned int uint_least32_t;
typedef unsigned long long uint_least64_t;
typedef signed char int_fast8_t;
typedef int int_fast16_t;
typedef int int_fast32_t;
typedef long long int_fast64_t;
typedef unsigned char uint_fast8_t;
typedef unsigned int uint_fast16_t;
typedef unsigned int uint_fast32_t;
typedef unsigned long long uint_fast64_t;
typedef unsigned int uintptr_t;
typedef long long intmax_t;
typedef unsigned long long uintmax_t;
typedef long __gwchar_t;
struct __anonstruct_imaxdiv_t_30 {
   long long quot ;
   long long rem ;
};
typedef struct __anonstruct_imaxdiv_t_30 imaxdiv_t;
typedef uintptr_t Py_uintptr_t;
typedef intptr_t Py_intptr_t;
typedef ssize_t Py_ssize_t;
typedef Py_ssize_t Py_hash_t;
typedef size_t Py_uhash_t;
typedef long double float_t;
typedef long double double_t;
enum __anonenum_31 {
    FP_NAN = 0,
    FP_INFINITE = 1,
    FP_ZERO = 2,
    FP_SUBNORMAL = 3,
    FP_NORMAL = 4
} ;
enum __anonenum__LIB_VERSION_TYPE_32 {
    _IEEE_ = -1,
    _SVID_ = 0,
    _XOPEN_ = 1,
    _POSIX_ = 2,
    _ISOC_ = 3
} ;
typedef enum __anonenum__LIB_VERSION_TYPE_32 _LIB_VERSION_TYPE;
struct exception {
   int type ;
   char *name ;
   double arg1 ;
   double arg2 ;
   double retval ;
};
union __anonunion___u_33 {
   float __f ;
   int __i ;
};
union __anonunion___u_34 {
   double __d ;
   int __i[2] ;
};
union __anonunion___u_35 {
   long double __l ;
   int __i[3] ;
};
union __anonunion___n_36 {
   long double __xld ;
   unsigned int __xi[3] ;
};
union __anonunion_37 {
   double __d ;
   int __i[2] ;
};
struct timezone {
   int tz_minuteswest ;
   int tz_dsttime ;
};
typedef struct timezone * __restrict  __timezone_ptr_t;
enum __itimer_which {
    ITIMER_REAL = 0,
    ITIMER_VIRTUAL = 1,
    ITIMER_PROF = 2
} ;
struct itimerval {
   struct timeval it_interval ;
   struct timeval it_value ;
};
typedef enum __itimer_which __itimer_which_t;
struct tm {
   int tm_sec ;
   int tm_min ;
   int tm_hour ;
   int tm_mday ;
   int tm_mon ;
   int tm_year ;
   int tm_wday ;
   int tm_yday ;
   int tm_isdst ;
   long tm_gmtoff ;
   char const   *tm_zone ;
};
struct itimerspec {
   struct timespec it_interval ;
   struct timespec it_value ;
};
struct sigevent;
struct sigevent;
struct stat {
   __dev_t st_dev ;
   unsigned short __pad1 ;
   __ino_t __st_ino ;
   __mode_t st_mode ;
   __nlink_t st_nlink ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   __dev_t st_rdev ;
   unsigned short __pad2 ;
   __off64_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt64_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __ino64_t st_ino ;
};
struct stat64 {
   __dev_t st_dev ;
   unsigned int __pad1 ;
   __ino_t __st_ino ;
   __mode_t st_mode ;
   __nlink_t st_nlink ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   __dev_t st_rdev ;
   unsigned int __pad2 ;
   __off64_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt64_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __ino64_t st_ino ;
};
enum _Py_memory_order {
    _Py_memory_order_relaxed = 0,
    _Py_memory_order_acquire = 1,
    _Py_memory_order_release = 2,
    _Py_memory_order_acq_rel = 3,
    _Py_memory_order_seq_cst = 4
} ;
typedef enum _Py_memory_order _Py_memory_order;
struct _Py_atomic_address {
   void *_value ;
};
typedef struct _Py_atomic_address _Py_atomic_address;
struct _Py_atomic_int {
   int _value ;
};
typedef struct _Py_atomic_int _Py_atomic_int;
typedef struct timeval _PyTime_timeval;
struct _typeobject;
struct _object {
   Py_ssize_t ob_refcnt ;
   struct _typeobject *ob_type ;
};
typedef struct _object PyObject;
struct __anonstruct_PyVarObject_38 {
   PyObject ob_base ;
   Py_ssize_t ob_size ;
};
typedef struct __anonstruct_PyVarObject_38 PyVarObject;
typedef PyObject *(*unaryfunc)(PyObject * );
typedef PyObject *(*binaryfunc)(PyObject * , PyObject * );
typedef PyObject *(*ternaryfunc)(PyObject * , PyObject * , PyObject * );
typedef int (*inquiry)(PyObject * );
typedef Py_ssize_t (*lenfunc)(PyObject * );
typedef PyObject *(*ssizeargfunc)(PyObject * , Py_ssize_t  );
typedef PyObject *(*ssizessizeargfunc)(PyObject * , Py_ssize_t  , Py_ssize_t  );
typedef int (*ssizeobjargproc)(PyObject * , Py_ssize_t  , PyObject * );
typedef int (*ssizessizeobjargproc)(PyObject * , Py_ssize_t  , Py_ssize_t  , PyObject * );
typedef int (*objobjargproc)(PyObject * , PyObject * , PyObject * );
struct bufferinfo {
   void *buf ;
   PyObject *obj ;
   Py_ssize_t len ;
   Py_ssize_t itemsize ;
   int readonly ;
   int ndim ;
   char *format ;
   Py_ssize_t *shape ;
   Py_ssize_t *strides ;
   Py_ssize_t *suboffsets ;
   Py_ssize_t smalltable[2] ;
   void *internal ;
};
typedef struct bufferinfo Py_buffer;
typedef int (*getbufferproc)(PyObject * , Py_buffer * , int  );
typedef void (*releasebufferproc)(PyObject * , Py_buffer * );
typedef int (*objobjproc)(PyObject * , PyObject * );
typedef int (*visitproc)(PyObject * , void * );
typedef int (*traverseproc)(PyObject * , int (*)(PyObject * , void * ) , void * );
struct __anonstruct_PyNumberMethods_39 {
   PyObject *(*nb_add)(PyObject * , PyObject * ) ;
   PyObject *(*nb_subtract)(PyObject * , PyObject * ) ;
   PyObject *(*nb_multiply)(PyObject * , PyObject * ) ;
   PyObject *(*nb_remainder)(PyObject * , PyObject * ) ;
   PyObject *(*nb_divmod)(PyObject * , PyObject * ) ;
   PyObject *(*nb_power)(PyObject * , PyObject * , PyObject * ) ;
   PyObject *(*nb_negative)(PyObject * ) ;
   PyObject *(*nb_positive)(PyObject * ) ;
   PyObject *(*nb_absolute)(PyObject * ) ;
   int (*nb_bool)(PyObject * ) ;
   PyObject *(*nb_invert)(PyObject * ) ;
   PyObject *(*nb_lshift)(PyObject * , PyObject * ) ;
   PyObject *(*nb_rshift)(PyObject * , PyObject * ) ;
   PyObject *(*nb_and)(PyObject * , PyObject * ) ;
   PyObject *(*nb_xor)(PyObject * , PyObject * ) ;
   PyObject *(*nb_or)(PyObject * , PyObject * ) ;
   PyObject *(*nb_int)(PyObject * ) ;
   void *nb_reserved ;
   PyObject *(*nb_float)(PyObject * ) ;
   PyObject *(*nb_inplace_add)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_subtract)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_multiply)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_remainder)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_power)(PyObject * , PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_lshift)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_rshift)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_and)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_xor)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_or)(PyObject * , PyObject * ) ;
   PyObject *(*nb_floor_divide)(PyObject * , PyObject * ) ;
   PyObject *(*nb_true_divide)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_floor_divide)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_true_divide)(PyObject * , PyObject * ) ;
   PyObject *(*nb_index)(PyObject * ) ;
};
typedef struct __anonstruct_PyNumberMethods_39 PyNumberMethods;
struct __anonstruct_PySequenceMethods_40 {
   Py_ssize_t (*sq_length)(PyObject * ) ;
   PyObject *(*sq_concat)(PyObject * , PyObject * ) ;
   PyObject *(*sq_repeat)(PyObject * , Py_ssize_t  ) ;
   PyObject *(*sq_item)(PyObject * , Py_ssize_t  ) ;
   void *was_sq_slice ;
   int (*sq_ass_item)(PyObject * , Py_ssize_t  , PyObject * ) ;
   void *was_sq_ass_slice ;
   int (*sq_contains)(PyObject * , PyObject * ) ;
   PyObject *(*sq_inplace_concat)(PyObject * , PyObject * ) ;
   PyObject *(*sq_inplace_repeat)(PyObject * , Py_ssize_t  ) ;
};
typedef struct __anonstruct_PySequenceMethods_40 PySequenceMethods;
struct __anonstruct_PyMappingMethods_41 {
   Py_ssize_t (*mp_length)(PyObject * ) ;
   PyObject *(*mp_subscript)(PyObject * , PyObject * ) ;
   int (*mp_ass_subscript)(PyObject * , PyObject * , PyObject * ) ;
};
typedef struct __anonstruct_PyMappingMethods_41 PyMappingMethods;
struct __anonstruct_PyBufferProcs_42 {
   int (*bf_getbuffer)(PyObject * , Py_buffer * , int  ) ;
   void (*bf_releasebuffer)(PyObject * , Py_buffer * ) ;
};
typedef struct __anonstruct_PyBufferProcs_42 PyBufferProcs;
typedef void (*freefunc)(void * );
typedef void (*destructor)(PyObject * );
typedef int (*printfunc)(PyObject * , FILE * , int  );
typedef PyObject *(*getattrfunc)(PyObject * , char * );
typedef PyObject *(*getattrofunc)(PyObject * , PyObject * );
typedef int (*setattrfunc)(PyObject * , char * , PyObject * );
typedef int (*setattrofunc)(PyObject * , PyObject * , PyObject * );
typedef PyObject *(*reprfunc)(PyObject * );
typedef Py_hash_t (*hashfunc)(PyObject * );
typedef PyObject *(*richcmpfunc)(PyObject * , PyObject * , int  );
typedef PyObject *(*getiterfunc)(PyObject * );
typedef PyObject *(*iternextfunc)(PyObject * );
typedef PyObject *(*descrgetfunc)(PyObject * , PyObject * , PyObject * );
typedef int (*descrsetfunc)(PyObject * , PyObject * , PyObject * );
typedef int (*initproc)(PyObject * , PyObject * , PyObject * );
typedef PyObject *(*newfunc)(struct _typeobject * , PyObject * , PyObject * );
typedef PyObject *(*allocfunc)(struct _typeobject * , Py_ssize_t  );
struct PyMethodDef;
struct PyMemberDef;
struct PyGetSetDef;
struct _typeobject {
   PyVarObject ob_base ;
   char const   *tp_name ;
   Py_ssize_t tp_basicsize ;
   Py_ssize_t tp_itemsize ;
   void (*tp_dealloc)(PyObject * ) ;
   int (*tp_print)(PyObject * , FILE * , int  ) ;
   PyObject *(*tp_getattr)(PyObject * , char * ) ;
   int (*tp_setattr)(PyObject * , char * , PyObject * ) ;
   void *tp_reserved ;
   PyObject *(*tp_repr)(PyObject * ) ;
   PyNumberMethods *tp_as_number ;
   PySequenceMethods *tp_as_sequence ;
   PyMappingMethods *tp_as_mapping ;
   Py_hash_t (*tp_hash)(PyObject * ) ;
   PyObject *(*tp_call)(PyObject * , PyObject * , PyObject * ) ;
   PyObject *(*tp_str)(PyObject * ) ;
   PyObject *(*tp_getattro)(PyObject * , PyObject * ) ;
   int (*tp_setattro)(PyObject * , PyObject * , PyObject * ) ;
   PyBufferProcs *tp_as_buffer ;
   long tp_flags ;
   char const   *tp_doc ;
   int (*tp_traverse)(PyObject * , int (*)(PyObject * , void * ) , void * ) ;
   int (*tp_clear)(PyObject * ) ;
   PyObject *(*tp_richcompare)(PyObject * , PyObject * , int  ) ;
   Py_ssize_t tp_weaklistoffset ;
   PyObject *(*tp_iter)(PyObject * ) ;
   PyObject *(*tp_iternext)(PyObject * ) ;
   struct PyMethodDef *tp_methods ;
   struct PyMemberDef *tp_members ;
   struct PyGetSetDef *tp_getset ;
   struct _typeobject *tp_base ;
   PyObject *tp_dict ;
   PyObject *(*tp_descr_get)(PyObject * , PyObject * , PyObject * ) ;
   int (*tp_descr_set)(PyObject * , PyObject * , PyObject * ) ;
   Py_ssize_t tp_dictoffset ;
   int (*tp_init)(PyObject * , PyObject * , PyObject * ) ;
   PyObject *(*tp_alloc)(struct _typeobject * , Py_ssize_t  ) ;
   PyObject *(*tp_new)(struct _typeobject * , PyObject * , PyObject * ) ;
   void (*tp_free)(void * ) ;
   int (*tp_is_gc)(PyObject * ) ;
   PyObject *tp_bases ;
   PyObject *tp_mro ;
   PyObject *tp_cache ;
   PyObject *tp_subclasses ;
   PyObject *tp_weaklist ;
   void (*tp_del)(PyObject * ) ;
   unsigned int tp_version_tag ;
};
typedef struct _typeobject PyTypeObject;
struct __anonstruct_PyType_Slot_43 {
   int slot ;
   void *pfunc ;
};
typedef struct __anonstruct_PyType_Slot_43 PyType_Slot;
struct __anonstruct_PyType_Spec_44 {
   char const   *name ;
   int basicsize ;
   int itemsize ;
   int flags ;
   PyType_Slot *slots ;
};
typedef struct __anonstruct_PyType_Spec_44 PyType_Spec;
struct _heaptypeobject {
   PyTypeObject ht_type ;
   PyNumberMethods as_number ;
   PyMappingMethods as_mapping ;
   PySequenceMethods as_sequence ;
   PyBufferProcs as_buffer ;
   PyObject *ht_name ;
   PyObject *ht_slots ;
};
typedef struct _heaptypeobject PyHeapTypeObject;
struct __anonstruct_gc_45 {
   union _gc_head *gc_next ;
   union _gc_head *gc_prev ;
   Py_ssize_t gc_refs ;
};
union _gc_head {
   struct __anonstruct_gc_45 gc ;
   long double dummy ;
};
typedef union _gc_head PyGC_Head;
struct __anonstruct_PyByteArrayObject_46 {
   PyVarObject ob_base ;
   int ob_exports ;
   Py_ssize_t ob_alloc ;
   char *ob_bytes ;
};
typedef struct __anonstruct_PyByteArrayObject_46 PyByteArrayObject;
struct __anonstruct_PyBytesObject_47 {
   PyVarObject ob_base ;
   Py_hash_t ob_shash ;
   char ob_sval[1] ;
};
typedef struct __anonstruct_PyBytesObject_47 PyBytesObject;
enum __anonenum_48 {
    _ISupper = 256,
    _ISlower = 512,
    _ISalpha = 1024,
    _ISdigit = 2048,
    _ISxdigit = 4096,
    _ISspace = 8192,
    _ISprint = 16384,
    _ISgraph = 32768,
    _ISblank = 1,
    _IScntrl = 2,
    _ISpunct = 4,
    _ISalnum = 8
} ;
typedef unsigned int wint_t;
typedef __mbstate_t mbstate_t;
struct tm;
typedef unsigned int Py_UCS4;
typedef unsigned short Py_UNICODE;
struct __anonstruct_PyUnicodeObject_49 {
   PyObject ob_base ;
   Py_ssize_t length ;
   Py_UNICODE *str ;
   Py_hash_t hash ;
   int state ;
   PyObject *defenc ;
};
typedef struct __anonstruct_PyUnicodeObject_49 PyUnicodeObject;
struct _longobject;
typedef struct _longobject PyLongObject;
typedef unsigned short digit;
typedef short sdigit;
typedef unsigned long twodigits;
typedef long stwodigits;
struct _longobject {
   PyVarObject ob_base ;
   digit ob_digit[1] ;
};
struct __anonstruct_PyFloatObject_50 {
   PyObject ob_base ;
   double ob_fval ;
};
typedef struct __anonstruct_PyFloatObject_50 PyFloatObject;
struct __anonstruct_Py_complex_51 {
   double real ;
   double imag ;
};
typedef struct __anonstruct_Py_complex_51 Py_complex;
struct __anonstruct_PyComplexObject_52 {
   PyObject ob_base ;
   Py_complex cval ;
};
typedef struct __anonstruct_PyComplexObject_52 PyComplexObject;
struct __anonstruct_PyMemoryViewObject_53 {
   PyObject ob_base ;
   Py_buffer view ;
};
typedef struct __anonstruct_PyMemoryViewObject_53 PyMemoryViewObject;
struct __anonstruct_PyTupleObject_54 {
   PyVarObject ob_base ;
   PyObject *ob_item[1] ;
};
typedef struct __anonstruct_PyTupleObject_54 PyTupleObject;
struct __anonstruct_PyListObject_55 {
   PyVarObject ob_base ;
   PyObject **ob_item ;
   Py_ssize_t allocated ;
};
typedef struct __anonstruct_PyListObject_55 PyListObject;
struct __anonstruct_PyDictEntry_56 {
   Py_hash_t me_hash ;
   PyObject *me_key ;
   PyObject *me_value ;
};
typedef struct __anonstruct_PyDictEntry_56 PyDictEntry;
struct _dictobject;
typedef struct _dictobject PyDictObject;
struct _dictobject {
   PyObject ob_base ;
   Py_ssize_t ma_fill ;
   Py_ssize_t ma_used ;
   Py_ssize_t ma_mask ;
   PyDictEntry *ma_table ;
   PyDictEntry *(*ma_lookup)(PyDictObject *mp , PyObject *key , Py_hash_t hash ) ;
   PyDictEntry ma_smalltable[8] ;
};
struct __anonstruct_setentry_57 {
   Py_hash_t hash ;
   PyObject *key ;
};
typedef struct __anonstruct_setentry_57 setentry;
struct _setobject;
typedef struct _setobject PySetObject;
struct _setobject {
   PyObject ob_base ;
   Py_ssize_t fill ;
   Py_ssize_t used ;
   Py_ssize_t mask ;
   setentry *table ;
   setentry *(*lookup)(PySetObject *so , PyObject *key , Py_hash_t hash ) ;
   setentry smalltable[8] ;
   Py_hash_t hash ;
   PyObject *weakreflist ;
};
typedef PyObject *(*PyCFunction)(PyObject * , PyObject * );
typedef PyObject *(*PyCFunctionWithKeywords)(PyObject * , PyObject * , PyObject * );
typedef PyObject *(*PyNoArgsFunction)(PyObject * );
struct PyMethodDef {
   char const   *ml_name ;
   PyObject *(*ml_meth)(PyObject * , PyObject * ) ;
   int ml_flags ;
   char const   *ml_doc ;
};
typedef struct PyMethodDef PyMethodDef;
struct __anonstruct_PyCFunctionObject_58 {
   PyObject ob_base ;
   PyMethodDef *m_ml ;
   PyObject *m_self ;
   PyObject *m_module ;
};
typedef struct __anonstruct_PyCFunctionObject_58 PyCFunctionObject;
struct PyModuleDef;
struct PyModuleDef_Base {
   PyObject ob_base ;
   PyObject *(*m_init)(void) ;
   Py_ssize_t m_index ;
   PyObject *m_copy ;
};
typedef struct PyModuleDef_Base PyModuleDef_Base;
struct PyModuleDef {
   PyModuleDef_Base m_base ;
   char const   *m_name ;
   char const   *m_doc ;
   Py_ssize_t m_size ;
   PyMethodDef *m_methods ;
   int (*m_reload)(PyObject * ) ;
   int (*m_traverse)(PyObject * , int (*)(PyObject * , void * ) , void * ) ;
   int (*m_clear)(PyObject * ) ;
   void (*m_free)(void * ) ;
};
typedef struct PyModuleDef PyModuleDef;
struct __anonstruct_PyFunctionObject_59 {
   PyObject ob_base ;
   PyObject *func_code ;
   PyObject *func_globals ;
   PyObject *func_defaults ;
   PyObject *func_kwdefaults ;
   PyObject *func_closure ;
   PyObject *func_doc ;
   PyObject *func_name ;
   PyObject *func_dict ;
   PyObject *func_weakreflist ;
   PyObject *func_module ;
   PyObject *func_annotations ;
};
typedef struct __anonstruct_PyFunctionObject_59 PyFunctionObject;
struct __anonstruct_PyMethodObject_60 {
   PyObject ob_base ;
   PyObject *im_func ;
   PyObject *im_self ;
   PyObject *im_weakreflist ;
};
typedef struct __anonstruct_PyMethodObject_60 PyMethodObject;
struct __anonstruct_PyInstanceMethodObject_61 {
   PyObject ob_base ;
   PyObject *func ;
};
typedef struct __anonstruct_PyInstanceMethodObject_61 PyInstanceMethodObject;
typedef void (*PyCapsule_Destructor)(PyObject * );
struct _ts;
struct _ts;
struct _is;
struct _is;
struct _is {
   struct _is *next ;
   struct _ts *tstate_head ;
   PyObject *modules ;
   PyObject *modules_by_index ;
   PyObject *sysdict ;
   PyObject *builtins ;
   PyObject *modules_reloading ;
   PyObject *codec_search_path ;
   PyObject *codec_search_cache ;
   PyObject *codec_error_registry ;
   int codecs_initialized ;
   int fscodec_initialized ;
   int dlopenflags ;
};
typedef struct _is PyInterpreterState;
struct _frame;
struct _frame;
typedef int (*Py_tracefunc)(PyObject * , struct _frame * , int  , PyObject * );
struct _ts {
   struct _ts *next ;
   PyInterpreterState *interp ;
   struct _frame *frame ;
   int recursion_depth ;
   char overflowed ;
   char recursion_critical ;
   int tracing ;
   int use_tracing ;
   int (*c_profilefunc)(PyObject * , struct _frame * , int  , PyObject * ) ;
   int (*c_tracefunc)(PyObject * , struct _frame * , int  , PyObject * ) ;
   PyObject *c_profileobj ;
   PyObject *c_traceobj ;
   PyObject *curexc_type ;
   PyObject *curexc_value ;
   PyObject *curexc_traceback ;
   PyObject *exc_type ;
   PyObject *exc_value ;
   PyObject *exc_traceback ;
   PyObject *dict ;
   int tick_counter ;
   int gilstate_counter ;
   PyObject *async_exc ;
   long thread_id ;
};
typedef struct _ts PyThreadState;
enum __anonenum_PyGILState_STATE_62 {
    PyGILState_LOCKED = 0,
    PyGILState_UNLOCKED = 1
} ;
typedef enum __anonenum_PyGILState_STATE_62 PyGILState_STATE;
typedef struct _frame *(*PyThreadFrameGetter)(PyThreadState *self_ );
struct _frame;
struct _traceback {
   PyObject ob_base ;
   struct _traceback *tb_next ;
   struct _frame *tb_frame ;
   int tb_lasti ;
   int tb_lineno ;
};
typedef struct _traceback PyTracebackObject;
struct __anonstruct_PySliceObject_63 {
   PyObject ob_base ;
   PyObject *start ;
   PyObject *stop ;
   PyObject *step ;
};
typedef struct __anonstruct_PySliceObject_63 PySliceObject;
struct __anonstruct_PyCellObject_64 {
   PyObject ob_base ;
   PyObject *ob_ref ;
};
typedef struct __anonstruct_PyCellObject_64 PyCellObject;
struct _frame;
struct __anonstruct_PyGenObject_65 {
   PyObject ob_base ;
   struct _frame *gi_frame ;
   int gi_running ;
   PyObject *gi_code ;
   PyObject *gi_weakreflist ;
};
typedef struct __anonstruct_PyGenObject_65 PyGenObject;
typedef PyObject *(*getter)(PyObject * , void * );
typedef int (*setter)(PyObject * , PyObject * , void * );
struct PyGetSetDef {
   char *name ;
   PyObject *(*get)(PyObject * , void * ) ;
   int (*set)(PyObject * , PyObject * , void * ) ;
   char *doc ;
   void *closure ;
};
typedef struct PyGetSetDef PyGetSetDef;
typedef PyObject *(*wrapperfunc)(PyObject *self , PyObject *args , void *wrapped );
typedef PyObject *(*wrapperfunc_kwds)(PyObject *self , PyObject *args , void *wrapped , PyObject *kwds );
struct wrapperbase {
   char *name ;
   int offset ;
   void *function ;
   PyObject *(*wrapper)(PyObject *self , PyObject *args , void *wrapped ) ;
   char *doc ;
   int flags ;
   PyObject *name_strobj ;
};
struct __anonstruct_PyDescrObject_66 {
   PyObject ob_base ;
   PyTypeObject *d_type ;
   PyObject *d_name ;
};
typedef struct __anonstruct_PyDescrObject_66 PyDescrObject;
struct __anonstruct_PyMethodDescrObject_67 {
   PyDescrObject d_common ;
   PyMethodDef *d_method ;
};
typedef struct __anonstruct_PyMethodDescrObject_67 PyMethodDescrObject;
struct __anonstruct_PyMemberDescrObject_68 {
   PyDescrObject d_common ;
   struct PyMemberDef *d_member ;
};
typedef struct __anonstruct_PyMemberDescrObject_68 PyMemberDescrObject;
struct __anonstruct_PyGetSetDescrObject_69 {
   PyDescrObject d_common ;
   PyGetSetDef *d_getset ;
};
typedef struct __anonstruct_PyGetSetDescrObject_69 PyGetSetDescrObject;
struct __anonstruct_PyWrapperDescrObject_70 {
   PyDescrObject d_common ;
   struct wrapperbase *d_base ;
   void *d_wrapped ;
};
typedef struct __anonstruct_PyWrapperDescrObject_70 PyWrapperDescrObject;
struct PyMemberDef;
struct _PyWeakReference;
typedef struct _PyWeakReference PyWeakReference;
struct _PyWeakReference {
   PyObject ob_base ;
   PyObject *wr_object ;
   PyObject *wr_callback ;
   Py_hash_t hash ;
   PyWeakReference *wr_prev ;
   PyWeakReference *wr_next ;
};
struct PyStructSequence_Field {
   char *name ;
   char *doc ;
};
typedef struct PyStructSequence_Field PyStructSequence_Field;
struct PyStructSequence_Desc {
   char *name ;
   char *doc ;
   struct PyStructSequence_Field *fields ;
   int n_in_sequence ;
};
typedef struct PyStructSequence_Desc PyStructSequence_Desc;
typedef PyTupleObject PyStructSequence;
struct __anonstruct_PyBaseExceptionObject_71 {
   PyObject ob_base ;
   PyObject *dict ;
   PyObject *args ;
   PyObject *traceback ;
   PyObject *context ;
   PyObject *cause ;
};
typedef struct __anonstruct_PyBaseExceptionObject_71 PyBaseExceptionObject;
struct __anonstruct_PySyntaxErrorObject_72 {
   PyObject ob_base ;
   PyObject *dict ;
   PyObject *args ;
   PyObject *traceback ;
   PyObject *context ;
   PyObject *cause ;
   PyObject *msg ;
   PyObject *filename ;
   PyObject *lineno ;
   PyObject *offset ;
   PyObject *text ;
   PyObject *print_file_and_line ;
};
typedef struct __anonstruct_PySyntaxErrorObject_72 PySyntaxErrorObject;
struct __anonstruct_PyUnicodeErrorObject_73 {
   PyObject ob_base ;
   PyObject *dict ;
   PyObject *args ;
   PyObject *traceback ;
   PyObject *context ;
   PyObject *cause ;
   PyObject *encoding ;
   PyObject *object ;
   Py_ssize_t start ;
   Py_ssize_t end ;
   PyObject *reason ;
};
typedef struct __anonstruct_PyUnicodeErrorObject_73 PyUnicodeErrorObject;
struct __anonstruct_PySystemExitObject_74 {
   PyObject ob_base ;
   PyObject *dict ;
   PyObject *args ;
   PyObject *traceback ;
   PyObject *context ;
   PyObject *cause ;
   PyObject *code ;
};
typedef struct __anonstruct_PySystemExitObject_74 PySystemExitObject;
struct __anonstruct_PyEnvironmentErrorObject_75 {
   PyObject ob_base ;
   PyObject *dict ;
   PyObject *args ;
   PyObject *traceback ;
   PyObject *context ;
   PyObject *cause ;
   PyObject *myerrno ;
   PyObject *strerror ;
   PyObject *filename ;
};
typedef struct __anonstruct_PyEnvironmentErrorObject_75 PyEnvironmentErrorObject;
struct _arena;
typedef struct _arena PyArena;
struct __anonstruct_PyCompilerFlags_76 {
   int cf_flags ;
};
typedef struct __anonstruct_PyCompilerFlags_76 PyCompilerFlags;
struct _mod;
struct _node;
struct symtable;
typedef void (*PyOS_sighandler_t)(int  );
struct _frame;
struct _inittab {
   char *name ;
   PyObject *(*initfunc)(void) ;
};
struct _frozen {
   char *name ;
   unsigned char *code ;
   int size ;
};
struct __anonstruct_PyCodeObject_77 {
   PyObject ob_base ;
   int co_argcount ;
   int co_kwonlyargcount ;
   int co_nlocals ;
   int co_stacksize ;
   int co_flags ;
   PyObject *co_code ;
   PyObject *co_consts ;
   PyObject *co_names ;
   PyObject *co_varnames ;
   PyObject *co_freevars ;
   PyObject *co_cellvars ;
   PyObject *co_filename ;
   PyObject *co_name ;
   int co_firstlineno ;
   PyObject *co_lnotab ;
   void *co_zombieframe ;
   PyObject *co_weakreflist ;
};
typedef struct __anonstruct_PyCodeObject_77 PyCodeObject;
struct _addr_pair {
   int ap_lower ;
   int ap_upper ;
};
typedef struct _addr_pair PyAddrPair;
struct _node;
struct __anonstruct_PyFutureFeatures_78 {
   int ff_features ;
   int ff_lineno ;
};
typedef struct __anonstruct_PyFutureFeatures_78 PyFutureFeatures;
struct _mod;
typedef int ptrdiff_t;
struct PyMemberDef {
   char *name ;
   int type ;
   Py_ssize_t offset ;
   int flags ;
   char *doc ;
};
typedef struct PyMemberDef PyMemberDef;
typedef unsigned char Byte;
typedef unsigned int uInt;
typedef unsigned long uLong;
typedef Byte Bytef;
typedef char charf;
typedef int intf;
typedef uInt uIntf;
typedef uLong uLongf;
typedef void const   *voidpc;
typedef void *voidpf;
typedef void *voidp;
typedef voidpf (*alloc_func)(voidpf opaque , uInt items , uInt size );
typedef void (*free_func)(voidpf opaque , voidpf address );
struct internal_state;
struct internal_state;
struct z_stream_s {
   Bytef *next_in ;
   uInt avail_in ;
   uLong total_in ;
   Bytef *next_out ;
   uInt avail_out ;
   uLong total_out ;
   char *msg ;
   struct internal_state *state ;
   voidpf (*zalloc)(voidpf opaque , uInt items , uInt size ) ;
   void (*zfree)(voidpf opaque , voidpf address ) ;
   voidpf opaque ;
   int data_type ;
   uLong adler ;
   uLong reserved ;
};
typedef struct z_stream_s z_stream;
typedef z_stream *z_streamp;
struct gz_header_s {
   int text ;
   uLong time ;
   int xflags ;
   int os ;
   Bytef *extra ;
   uInt extra_len ;
   uInt extra_max ;
   Bytef *name ;
   uInt name_max ;
   Bytef *comment ;
   uInt comm_max ;
   int hcrc ;
   int done ;
};
typedef struct gz_header_s gz_header;
typedef gz_header *gz_headerp;
typedef unsigned int (*in_func)(void * , unsigned char ** );
typedef int (*out_func)(void * , unsigned char * , unsigned int  );
typedef voidp gzFile;
struct internal_state {
   int dummy ;
};
typedef void *PyThread_type_lock;
typedef void *PyThread_type_sema;
enum PyLockStatus {
    PY_LOCK_FAILURE = 0,
    PY_LOCK_ACQUIRED = 1,
    PY_LOCK_INTR = 2
} ;
typedef enum PyLockStatus PyLockStatus;
struct __anonstruct_compobject_79 {
   PyObject ob_base ;
   z_stream zst ;
   PyObject *unused_data ;
   PyObject *unconsumed_tail ;
   int is_initialised ;
   PyThread_type_lock lock ;
};
typedef struct __anonstruct_compobject_79 compobject;
extern struct _IO_FILE_plus _IO_2_1_stdin_ ;
extern struct _IO_FILE_plus _IO_2_1_stdout_ ;
extern struct _IO_FILE_plus _IO_2_1_stderr_ ;
extern void _IO_cookie_init(struct _IO_cookie_file *__cfile , int __read_write , void *__cookie , _IO_cookie_io_functions_t __fns ) ;
extern int __underflow(_IO_FILE * ) ;
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_feof(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_ferror(_IO_FILE *__fp ) ;
extern int _IO_peekc_locked(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) void _IO_flockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) void _IO_funlockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) int _IO_ftrylockfile(_IO_FILE * ) ;
extern int _IO_vfscanf(_IO_FILE * __restrict   , char const   * __restrict   , __gnuc_va_list  , int * __restrict   ) ;
extern int _IO_vfprintf(_IO_FILE * __restrict   , char const   * __restrict   , __gnuc_va_list  ) ;
extern __ssize_t _IO_padn(_IO_FILE * , int  , __ssize_t  ) ;
extern size_t _IO_sgetn(_IO_FILE * , void * , size_t  ) ;
extern __off64_t _IO_seekoff(_IO_FILE * , __off64_t  , int  , int  ) ;
extern __off64_t _IO_seekpos(_IO_FILE * , __off64_t  , int  ) ;
extern  __attribute__((__nothrow__)) void _IO_free_backup_area(_IO_FILE * ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
extern  __attribute__((__nothrow__)) int remove(char const   *__filename ) ;
extern  __attribute__((__nothrow__)) int rename(char const   *__old , char const   *__new ) ;
extern  __attribute__((__nothrow__)) int renameat(int __oldfd , char const   *__old , int __newfd , char const   *__new ) ;
extern FILE *tmpfile(void)  __asm__("tmpfile64")  ;
extern FILE *tmpfile64(void) ;
extern  __attribute__((__nothrow__)) char *tmpnam(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tmpnam_r(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tempnam(char const   *__dir , char const   *__pfx )  __attribute__((__malloc__)) ;
extern int fclose(FILE *__stream ) ;
extern int fflush(FILE *__stream ) ;
extern int fflush_unlocked(FILE *__stream ) ;
extern int fcloseall(void) ;
extern FILE *fopen(char const   * __restrict  __filename , char const   * __restrict  __modes )  __asm__("fopen64")  ;
extern FILE *freopen(char const   * __restrict  __filename , char const   * __restrict  __modes , FILE * __restrict  __stream )  __asm__("freopen64")  ;
extern FILE *fopen64(char const   * __restrict  __filename , char const   * __restrict  __modes ) ;
extern FILE *freopen64(char const   * __restrict  __filename , char const   * __restrict  __modes , FILE * __restrict  __stream ) ;
extern  __attribute__((__nothrow__)) FILE *fdopen(int __fd , char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *fopencookie(void * __restrict  __magic_cookie , char const   * __restrict  __modes , _IO_cookie_io_functions_t __io_funcs ) ;
extern  __attribute__((__nothrow__)) FILE *fmemopen(void *__s , size_t __len , char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *open_memstream(char **__bufloc , size_t *__sizeloc ) ;
extern  __attribute__((__nothrow__)) void setbuf(FILE * __restrict  __stream , char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) int setvbuf(FILE * __restrict  __stream , char * __restrict  __buf , int __modes , size_t __n ) ;
extern  __attribute__((__nothrow__)) void setbuffer(FILE * __restrict  __stream , char * __restrict  __buf , size_t __size ) ;
extern  __attribute__((__nothrow__)) void setlinebuf(FILE *__stream ) ;
extern int fprintf(FILE * __restrict  __stream , char const   * __restrict  __format  , ...) ;
extern int printf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sprintf(char * __restrict  __s , char const   * __restrict  __format  , ...) ;
extern int vfprintf(FILE * __restrict  __s , char const   * __restrict  __format , __gnuc_va_list __arg ) ;
__inline extern int vprintf(char const   * __restrict  __fmt , __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vsprintf(char * __restrict  __s , char const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  snprintf)(char * __restrict  __s , size_t __maxlen , char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsnprintf)(char * __restrict  __s , size_t __maxlen , char const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vasprintf)(char ** __restrict  __ptr , char const   * __restrict  __f , __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  __asprintf)(char ** __restrict  __ptr , char const   * __restrict  __fmt  , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  asprintf)(char ** __restrict  __ptr , char const   * __restrict  __fmt  , ...) ;
extern int ( /* format attribute */  vdprintf)(int __fd , char const   * __restrict  __fmt , __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  dprintf)(int __fd , char const   * __restrict  __fmt  , ...) ;
extern int fscanf(FILE * __restrict  __stream , char const   * __restrict  __format  , ...) ;
extern int scanf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sscanf(char const   * __restrict  __s , char const   * __restrict  __format  , ...) ;
extern int ( /* format attribute */  vfscanf)(FILE * __restrict  __s , char const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  vscanf)(char const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsscanf)(char const   * __restrict  __s , char const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern int fgetc(FILE *__stream ) ;
extern int getc(FILE *__stream ) ;
__inline extern int getchar(void) ;
__inline extern int getc_unlocked(FILE *__fp ) ;
__inline extern int getchar_unlocked(void) ;
__inline extern int fgetc_unlocked(FILE *__fp ) ;
extern int fputc(int __c , FILE *__stream ) ;
extern int putc(int __c , FILE *__stream ) ;
__inline extern int putchar(int __c ) ;
__inline extern int fputc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putchar_unlocked(int __c ) ;
extern int getw(FILE *__stream ) ;
extern int putw(int __w , FILE *__stream ) ;
extern char *fgets(char * __restrict  __s , int __n , FILE * __restrict  __stream ) ;
extern char *gets(char *__s ) ;
extern char *fgets_unlocked(char * __restrict  __s , int __n , FILE * __restrict  __stream ) ;
extern __ssize_t __getdelim(char ** __restrict  __lineptr , size_t * __restrict  __n , int __delimiter , FILE * __restrict  __stream ) ;
extern __ssize_t getdelim(char ** __restrict  __lineptr , size_t * __restrict  __n , int __delimiter , FILE * __restrict  __stream ) ;
__inline extern __ssize_t getline(char ** __restrict  __lineptr , size_t * __restrict  __n , FILE * __restrict  __stream ) ;
extern int fputs(char const   * __restrict  __s , FILE * __restrict  __stream ) ;
extern int puts(char const   *__s ) ;
extern int ungetc(int __c , FILE *__stream ) ;
extern size_t fread(void * __restrict  __ptr , size_t __size , size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite(void const   * __restrict  __ptr , size_t __size , size_t __n , FILE * __restrict  __s ) ;
extern int fputs_unlocked(char const   * __restrict  __s , FILE * __restrict  __stream ) ;
extern size_t fread_unlocked(void * __restrict  __ptr , size_t __size , size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite_unlocked(void const   * __restrict  __ptr , size_t __size , size_t __n , FILE * __restrict  __stream ) ;
extern int fseek(FILE *__stream , long __off , int __whence ) ;
extern long ftell(FILE *__stream ) ;
extern void rewind(FILE *__stream ) ;
extern int fseeko(FILE *__stream , __off64_t __off , int __whence )  __asm__("fseeko64")  ;
extern __off64_t ftello(FILE *__stream )  __asm__("ftello64")  ;
extern int fgetpos(FILE * __restrict  __stream , fpos_t * __restrict  __pos )  __asm__("fgetpos64")  ;
extern int fsetpos(FILE *__stream , fpos_t const   *__pos )  __asm__("fsetpos64")  ;
extern int fseeko64(FILE *__stream , __off64_t __off , int __whence ) ;
extern __off64_t ftello64(FILE *__stream ) ;
extern int fgetpos64(FILE * __restrict  __stream , fpos64_t * __restrict  __pos ) ;
extern int fsetpos64(FILE *__stream , fpos64_t const   *__pos ) ;
extern  __attribute__((__nothrow__)) void clearerr(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int feof(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ferror(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void clearerr_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
extern void perror(char const   *__s ) ;
extern int sys_nerr ;
extern char const   * const  sys_errlist[] ;
extern int _sys_nerr ;
extern char const   * const  _sys_errlist[] ;
extern  __attribute__((__nothrow__)) int fileno(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int fileno_unlocked(FILE *__stream ) ;
extern FILE *popen(char const   *__command , char const   *__modes ) ;
extern int pclose(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) char *ctermid(char *__s ) ;
extern char *cuserid(char *__s ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  obstack_printf)(struct obstack * __restrict  __obstack , char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  obstack_vprintf)(struct obstack * __restrict  __obstack , char const   * __restrict  __format , __gnuc_va_list __args ) ;
extern  __attribute__((__nothrow__)) void flockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ftrylockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void funlockfile(FILE *__stream ) ;
__inline extern int vprintf(char const   * __restrict  __fmt , __gnuc_va_list __arg ) 
{ int tmp ;

  {
  tmp = vfprintf((FILE */* __restrict  */)stdout, __fmt, __arg);
  return (tmp);
}
}
__inline extern int getchar(void) 
{ int tmp ;

  {
  tmp = _IO_getc(stdin);
  return (tmp);
}
}
__inline extern int fgetc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end), 0L);
  if (tmp___3) {
    tmp___0 = __uflow(__fp);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = __fp->_IO_read_ptr;
    (__fp->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return (tmp___2);
}
}
__inline extern int getc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end), 0L);
  if (tmp___3) {
    tmp___0 = __uflow(__fp);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = __fp->_IO_read_ptr;
    (__fp->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return (tmp___2);
}
}
__inline extern int getchar_unlocked(void) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned int )stdin->_IO_read_ptr >= (unsigned int )stdin->_IO_read_end), 0L);
  if (tmp___3) {
    tmp___0 = __uflow(stdin);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = stdin->_IO_read_ptr;
    (stdin->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return (tmp___2);
}
}
__inline extern int putchar(int __c ) 
{ int tmp ;

  {
  tmp = _IO_putc(__c, stdout);
  return (tmp);
}
}
__inline extern int fputc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end), 0L);
  if (tmp___4) {
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = __stream->_IO_write_ptr;
    (__stream->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return (tmp___3);
}
}
__inline extern int putc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end), 0L);
  if (tmp___4) {
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = __stream->_IO_write_ptr;
    (__stream->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return (tmp___3);
}
}
__inline extern int putchar_unlocked(int __c ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned int )stdout->_IO_write_ptr >= (unsigned int )stdout->_IO_write_end), 0L);
  if (tmp___4) {
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = stdout->_IO_write_ptr;
    (stdout->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return (tmp___3);
}
}
__inline extern __ssize_t getline(char ** __restrict  __lineptr , size_t * __restrict  __n , FILE * __restrict  __stream ) 
{ __ssize_t tmp ;

  {
  tmp = __getdelim(__lineptr, __n, '\n', __stream);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern int feof_unlocked(FILE *__stream ) 
{ 

  {
  return ((__stream->_flags & 0x10) != 0);
}
}
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
__inline extern int ferror_unlocked(FILE *__stream ) 
{ 

  {
  return ((__stream->_flags & 0x20) != 0);
}
}
extern  __attribute__((__nothrow__)) void *memcpy(void * __restrict  __dest , void const   * __restrict  __src , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memmove(void *__dest , void const   *__src , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memccpy(void * __restrict  __dest , void const   * __restrict  __src , int __c , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memset(void *__s , int __c , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int memcmp(void const   *__s1 , void const   *__s2 , size_t __n )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memchr(void const   *__s , int __c , size_t __n )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void *rawmemchr(void const   *__s , int __c )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void *memrchr(void const   *__s , int __c , size_t __n )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strcpy(char * __restrict  __dest , char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncpy(char * __restrict  __dest , char const   * __restrict  __src , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strcat(char * __restrict  __dest , char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncat(char * __restrict  __dest , char const   * __restrict  __src , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcmp(char const   *__s1 , char const   *__s2 )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncmp(char const   *__s1 , char const   *__s2 , size_t __n )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcoll(char const   *__s1 , char const   *__s2 )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm(char * __restrict  __dest , char const   * __restrict  __src , size_t __n )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int strcoll_l(char const   *__s1 , char const   *__s2 , __locale_t __l )  __attribute__((__pure__, __nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm_l(char *__dest , char const   *__src , size_t __n , __locale_t __l )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) char *strdup(char const   *__s )  __attribute__((__nonnull__(1), __malloc__)) ;
extern  __attribute__((__nothrow__)) char *strndup(char const   *__string , size_t __n )  __attribute__((__nonnull__(1), __malloc__)) ;
extern  __attribute__((__nothrow__)) char *strchr(char const   *__s , int __c )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strrchr(char const   *__s , int __c )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strchrnul(char const   *__s , int __c )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strcspn(char const   *__s , char const   *__reject )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strspn(char const   *__s , char const   *__accept )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strpbrk(char const   *__s , char const   *__accept )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strstr(char const   *__haystack , char const   *__needle )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strtok(char * __restrict  __s , char const   * __restrict  __delim )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *__strtok_r(char * __restrict  __s , char const   * __restrict  __delim , char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) char *strtok_r(char * __restrict  __s , char const   * __restrict  __delim , char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) char *strcasestr(char const   *__haystack , char const   *__needle )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memmem(void const   *__haystack , size_t __haystacklen , void const   *__needle , size_t __needlelen )  __attribute__((__pure__, __nonnull__(1,3))) ;
extern  __attribute__((__nothrow__)) void *__mempcpy(void * __restrict  __dest , void const   * __restrict  __src , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *mempcpy(void * __restrict  __dest , void const   * __restrict  __src , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strlen(char const   *__s )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strnlen(char const   *__string , size_t __maxlen )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strerror(int __errnum ) ;
extern  __attribute__((__nothrow__)) char *strerror_r(int __errnum , char *__buf , size_t __buflen )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *strerror_l(int __errnum , __locale_t __l ) ;
extern  __attribute__((__nothrow__)) void __bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void bcopy(void const   *__src , void *__dest , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int bcmp(void const   *__s1 , void const   *__s2 , size_t __n )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *index(char const   *__s , int __c )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *rindex(char const   *__s , int __c )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int ffs(int __i )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int ffsl(long __l )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int ffsll(long long __ll )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int strcasecmp(char const   *__s1 , char const   *__s2 )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncasecmp(char const   *__s1 , char const   *__s2 , size_t __n )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcasecmp_l(char const   *__s1 , char const   *__s2 , __locale_t __loc )  __attribute__((__pure__, __nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) int strncasecmp_l(char const   *__s1 , char const   *__s2 , size_t __n , __locale_t __loc )  __attribute__((__pure__, __nonnull__(1,2,4))) ;
extern  __attribute__((__nothrow__)) char *strsep(char ** __restrict  __stringp , char const   * __restrict  __delim )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsignal(int __sig ) ;
extern  __attribute__((__nothrow__)) char *__stpcpy(char * __restrict  __dest , char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpcpy(char * __restrict  __dest , char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *__stpncpy(char * __restrict  __dest , char const   * __restrict  __src , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpncpy(char * __restrict  __dest , char const   * __restrict  __src , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strverscmp(char const   *__s1 , char const   *__s2 )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strfry(char *__string )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void *memfrob(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *basename(char const   *__filename )  __attribute__((__nonnull__(1))) ;
extern void *__rawmemchr(void const   *__s , int __c ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) 
{ register size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if ((int const   )*(__s + __result) != (int const   )__reject) {

      } else {
        break;
      }
    } else {
      break;
    }
    __result ++;
  }
  return (__result);
}
}
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 , int __reject2 ) ;
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 , int __reject2 ) 
{ register size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        if ((int const   )*(__s + __result) != (int const   )__reject2) {

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __result ++;
  }
  return (__result);
}
}
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 , int __reject2 , int __reject3 ) ;
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 , int __reject2 , int __reject3 ) 
{ register size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          if ((int const   )*(__s + __result) != (int const   )__reject3) {

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __result ++;
  }
  return (__result);
}
}
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) ;
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) 
{ register size_t __result ;

  {
  __result = (size_t )0;
  while ((int const   )*(__s + __result) == (int const   )__accept) {
    __result ++;
  }
  return (__result);
}
}
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 , int __accept2 ) ;
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 , int __accept2 ) 
{ register size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) == (int const   )__accept1) {

    } else {
      if ((int const   )*(__s + __result) == (int const   )__accept2) {

      } else {
        break;
      }
    }
    __result ++;
  }
  return (__result);
}
}
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 , int __accept2 , int __accept3 ) ;
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 , int __accept2 , int __accept3 ) 
{ register size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) == (int const   )__accept1) {

    } else {
      if ((int const   )*(__s + __result) == (int const   )__accept2) {

      } else {
        if ((int const   )*(__s + __result) == (int const   )__accept3) {

        } else {
          break;
        }
      }
    }
    __result ++;
  }
  return (__result);
}
}
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 , int __accept2 ) ;
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 , int __accept2 ) 
{ char *tmp ;

  {
  while (1) {
    if ((int const   )*__s != 0) {
      if ((int const   )*__s != (int const   )__accept1) {
        if ((int const   )*__s != (int const   )__accept2) {

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __s ++;
  }
  if ((int const   )*__s == 0) {
    tmp = (char *)((void *)0);
  } else {
    tmp = (char *)((unsigned int )__s);
  }
  return (tmp);
}
}
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 , int __accept2 , int __accept3 ) ;
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 , int __accept2 , int __accept3 ) 
{ char *tmp ;

  {
  while (1) {
    if ((int const   )*__s != 0) {
      if ((int const   )*__s != (int const   )__accept1) {
        if ((int const   )*__s != (int const   )__accept2) {
          if ((int const   )*__s != (int const   )__accept3) {

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __s ++;
  }
  if ((int const   )*__s == 0) {
    tmp = (char *)((void *)0);
  } else {
    tmp = (char *)((unsigned int )__s);
  }
  return (tmp);
}
}
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) ;
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) 
{ char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  if ((unsigned int )__s == (unsigned int )((void *)0)) {
    __s = *__nextp;
  } else {

  }
  while ((int )*__s == (int )__sep) {
    __s ++;
  }
  __result = (char *)((void *)0);
  if ((int )*__s != 0) {
    tmp = __s;
    __s ++;
    __result = tmp;
    while ((int )*__s != 0) {
      tmp___0 = __s;
      __s ++;
      if ((int )*tmp___0 == (int )__sep) {
        *(__s + -1) = (char )'\000';
        break;
      } else {

      }
    }
  } else {

  }
  *__nextp = __s;
  return (__result);
}
}
extern char *__strsep_g(char **__stringp , char const   *__delim ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) 
{ register char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  void *tmp___1 ;
  char *tmp___2 ;

  {
  __retval = *__s;
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    tmp___0 = tmp___2;
    *__s = tmp___0;
    if ((unsigned int )tmp___0 != (unsigned int )((void *)0)) {
      tmp = *__s;
      (*__s) ++;
      *tmp = (char )'\000';
    } else {

    }
  } else {

  }
  return (__retval);
}
}
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) ;
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  __retval = *__s;
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    __cp = __retval;
    while (1) {
      if ((int )*__cp == 0) {
        __cp = (char *)((void *)0);
        break;
      } else {

      }
      if ((int )*__cp == (int )__reject1) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else {
        if ((int )*__cp == (int )__reject2) {
          tmp = __cp;
          __cp ++;
          *tmp = (char )'\000';
          break;
        } else {

        }
      }
      __cp ++;
    }
    *__s = __cp;
  } else {

  }
  return (__retval);
}
}
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 , char __reject3 ) ;
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 , char __reject3 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  __retval = *__s;
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    __cp = __retval;
    while (1) {
      if ((int )*__cp == 0) {
        __cp = (char *)((void *)0);
        break;
      } else {

      }
      if ((int )*__cp == (int )__reject1) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else {
        if ((int )*__cp == (int )__reject2) {
          tmp = __cp;
          __cp ++;
          *tmp = (char )'\000';
          break;
        } else {
          if ((int )*__cp == (int )__reject3) {
            tmp = __cp;
            __cp ++;
            *tmp = (char )'\000';
            break;
          } else {

          }
        }
      }
      __cp ++;
    }
    *__s = __cp;
  } else {

  }
  return (__retval);
}
}
extern  __attribute__((__nothrow__)) void *malloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *calloc(size_t __nmemb , size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strdup(char const   *__string )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strndup(char const   *__string , size_t __n )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) int *__errno_location(void)  __attribute__((__const__)) ;
extern char *program_invocation_name ;
extern char *program_invocation_short_name ;
extern  __attribute__((__nothrow__)) size_t __ctype_get_mb_cur_max(void) ;
__inline extern  __attribute__((__nothrow__)) double atof(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) int atoi(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) long atol(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) long long atoll(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) double strtod(char const   * __restrict  __nptr , char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) float strtof(char const   * __restrict  __nptr , char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long double strtold(char const   * __restrict  __nptr , char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long strtol(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long strtoul(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long long strtoq(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long long strtouq(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long long strtoll(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long long strtoull(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long strtol_l(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base , __locale_t __loc )  __attribute__((__nonnull__(1,4))) ;
extern  __attribute__((__nothrow__)) unsigned long strtoul_l(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base , __locale_t __loc )  __attribute__((__nonnull__(1,4))) ;
extern  __attribute__((__nothrow__)) long long strtoll_l(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base , __locale_t __loc )  __attribute__((__nonnull__(1,4))) ;
extern  __attribute__((__nothrow__)) unsigned long long strtoull_l(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base , __locale_t __loc )  __attribute__((__nonnull__(1,4))) ;
extern  __attribute__((__nothrow__)) double strtod_l(char const   * __restrict  __nptr , char ** __restrict  __endptr , __locale_t __loc )  __attribute__((__nonnull__(1,3))) ;
extern  __attribute__((__nothrow__)) float strtof_l(char const   * __restrict  __nptr , char ** __restrict  __endptr , __locale_t __loc )  __attribute__((__nonnull__(1,3))) ;
extern  __attribute__((__nothrow__)) long double strtold_l(char const   * __restrict  __nptr , char ** __restrict  __endptr , __locale_t __loc )  __attribute__((__nonnull__(1,3))) ;
__inline extern  __attribute__((__nothrow__)) double atof(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern double atof(char const   *__nptr ) 
{ double tmp ;

  {
  tmp = strtod((char const   */* __restrict  */)__nptr, (char **/* __restrict  */)((char **)((void *)0)));
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int atoi(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern int atoi(char const   *__nptr ) 
{ long tmp ;

  {
  tmp = strtol((char const   */* __restrict  */)__nptr, (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((int )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long atol(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern long atol(char const   *__nptr ) 
{ long tmp ;

  {
  tmp = strtol((char const   */* __restrict  */)__nptr, (char **/* __restrict  */)((char **)((void *)0)), 10);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long long atoll(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern long long atoll(char const   *__nptr ) 
{ long long tmp ;

  {
  tmp = strtoll((char const   */* __restrict  */)__nptr, (char **/* __restrict  */)((char **)((void *)0)), 10);
  return (tmp);
}
}
extern  __attribute__((__nothrow__)) char *l64a(long __n ) ;
extern  __attribute__((__nothrow__)) long a64l(char const   *__s )  __attribute__((__pure__, __nonnull__(1))) ;
extern int select(int __nfds , fd_set * __restrict  __readfds , fd_set * __restrict  __writefds , fd_set * __restrict  __exceptfds , struct timeval * __restrict  __timeout ) ;
extern int pselect(int __nfds , fd_set * __restrict  __readfds , fd_set * __restrict  __writefds , fd_set * __restrict  __exceptfds , struct timespec  const  * __restrict  __timeout , __sigset_t const   * __restrict  __sigmask ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major , unsigned int __minor ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_major(unsigned long long __dev ) 
{ 

  {
  return ((unsigned int )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_minor(unsigned long long __dev ) 
{ 

  {
  return ((unsigned int )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major , unsigned int __minor ) ;
__inline extern unsigned long long gnu_dev_makedev(unsigned int __major , unsigned int __minor ) 
{ 

  {
  return (((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32));
}
}
extern  __attribute__((__nothrow__)) long random(void) ;
extern  __attribute__((__nothrow__)) void srandom(unsigned int __seed ) ;
extern  __attribute__((__nothrow__)) char *initstate(unsigned int __seed , char *__statebuf , size_t __statelen )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *setstate(char *__statebuf )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int random_r(struct random_data * __restrict  __buf , int32_t * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int srandom_r(unsigned int __seed , struct random_data *__buf )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int initstate_r(unsigned int __seed , char * __restrict  __statebuf , size_t __statelen , struct random_data * __restrict  __buf )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) int setstate_r(char * __restrict  __statebuf , struct random_data * __restrict  __buf )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int rand(void) ;
extern  __attribute__((__nothrow__)) void srand(unsigned int __seed ) ;
extern  __attribute__((__nothrow__)) int rand_r(unsigned int *__seed ) ;
extern  __attribute__((__nothrow__)) double drand48(void) ;
extern  __attribute__((__nothrow__)) double erand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long lrand48(void) ;
extern  __attribute__((__nothrow__)) long nrand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long mrand48(void) ;
extern  __attribute__((__nothrow__)) long jrand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void srand48(long __seedval ) ;
extern  __attribute__((__nothrow__)) unsigned short *seed48(unsigned short *__seed16v )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void lcong48(unsigned short *__param )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int drand48_r(struct drand48_data * __restrict  __buffer , double * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int erand48_r(unsigned short *__xsubi , struct drand48_data * __restrict  __buffer , double * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int lrand48_r(struct drand48_data * __restrict  __buffer , long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int nrand48_r(unsigned short *__xsubi , struct drand48_data * __restrict  __buffer , long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int mrand48_r(struct drand48_data * __restrict  __buffer , long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int jrand48_r(unsigned short *__xsubi , struct drand48_data * __restrict  __buffer , long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int srand48_r(long __seedval , struct drand48_data *__buffer )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int seed48_r(unsigned short *__seed16v , struct drand48_data *__buffer )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int lcong48_r(unsigned short *__param , struct drand48_data *__buffer )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *realloc(void *__ptr , size_t __size )  __attribute__((__warn_unused_result__)) ;
extern  __attribute__((__nothrow__)) void free(void *__ptr ) ;
extern  __attribute__((__nothrow__)) void cfree(void *__ptr ) ;
extern  __attribute__((__nothrow__)) void *alloca(size_t __size ) ;
extern  __attribute__((__nothrow__)) void *valloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) int posix_memalign(void **__memptr , size_t __alignment , size_t __size )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__, __noreturn__)) void abort(void) ;
extern  __attribute__((__nothrow__)) int atexit(void (*__func)(void) )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int at_quick_exit(void (*__func)(void) )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int on_exit(void (*__func)(int __status , void *__arg ) , void *__arg )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__, __noreturn__)) void exit(int __status ) ;
extern  __attribute__((__nothrow__, __noreturn__)) void quick_exit(int __status ) ;
extern  __attribute__((__nothrow__, __noreturn__)) void _Exit(int __status ) ;
extern  __attribute__((__nothrow__)) char *getenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *__secure_getenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int putenv(char *__string )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int setenv(char const   *__name , char const   *__value , int __replace )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int unsetenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int clearenv(void) ;
extern  __attribute__((__nothrow__)) char *mktemp(char *__template )  __attribute__((__nonnull__(1))) ;
extern int mkstemp(char *__template )  __asm__("mkstemp64") __attribute__((__nonnull__(1))) ;
extern int mkstemp64(char *__template )  __attribute__((__nonnull__(1))) ;
extern int mkstemps(char *__template , int __suffixlen )  __asm__("mkstemps64") __attribute__((__nonnull__(1))) ;
extern int mkstemps64(char *__template , int __suffixlen )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *mkdtemp(char *__template )  __attribute__((__nonnull__(1))) ;
extern int mkostemp(char *__template , int __flags )  __asm__("mkostemp64") __attribute__((__nonnull__(1))) ;
extern int mkostemp64(char *__template , int __flags )  __attribute__((__nonnull__(1))) ;
extern int mkostemps(char *__template , int __suffixlen , int __flags )  __asm__("mkostemps64") __attribute__((__nonnull__(1))) ;
extern int mkostemps64(char *__template , int __suffixlen , int __flags )  __attribute__((__nonnull__(1))) ;
extern int system(char const   *__command ) ;
extern  __attribute__((__nothrow__)) char *canonicalize_file_name(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *realpath(char const   * __restrict  __name , char * __restrict  __resolved ) ;
extern void *bsearch(void const   *__key , void const   *__base , size_t __nmemb , size_t __size , int (*__compar)(void const   * , void const   * ) )  __attribute__((__nonnull__(1,2,5))) ;
extern void qsort(void *__base , size_t __nmemb , size_t __size , int (*__compar)(void const   * , void const   * ) )  __attribute__((__nonnull__(1,4))) ;
extern void qsort_r(void *__base , size_t __nmemb , size_t __size , int (*__compar)(void const   * , void const   * , void * ) , void *__arg )  __attribute__((__nonnull__(1,4))) ;
extern  __attribute__((__nothrow__)) int abs(int __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long labs(long __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long long llabs(long long __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) div_t div(int __numer , int __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) ldiv_t ldiv(long __numer , long __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) lldiv_t lldiv(long long __numer , long long __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) char *ecvt(double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *fcvt(double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *gcvt(double __value , int __ndigit , char *__buf )  __attribute__((__nonnull__(3))) ;
extern  __attribute__((__nothrow__)) char *qecvt(long double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *qfcvt(long double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *qgcvt(long double __value , int __ndigit , char *__buf )  __attribute__((__nonnull__(3))) ;
extern  __attribute__((__nothrow__)) int ecvt_r(double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign , char * __restrict  __buf , size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int fcvt_r(double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign , char * __restrict  __buf , size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int qecvt_r(long double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign , char * __restrict  __buf , size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int qfcvt_r(long double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign , char * __restrict  __buf , size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int mblen(char const   *__s , size_t __n ) ;
extern  __attribute__((__nothrow__)) int mbtowc(wchar_t * __restrict  __pwc , char const   * __restrict  __s , size_t __n ) ;
extern  __attribute__((__nothrow__)) int wctomb(char *__s , wchar_t __wchar ) ;
extern  __attribute__((__nothrow__)) size_t mbstowcs(wchar_t * __restrict  __pwcs , char const   * __restrict  __s , size_t __n ) ;
extern  __attribute__((__nothrow__)) size_t wcstombs(char * __restrict  __s , wchar_t const   * __restrict  __pwcs , size_t __n ) ;
extern  __attribute__((__nothrow__)) int rpmatch(char const   *__response )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int getsubopt(char ** __restrict  __optionp , char * const  * __restrict  __tokens , char ** __restrict  __valuep )  __attribute__((__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) void setkey(char const   *__key )  __attribute__((__nonnull__(1))) ;
extern int posix_openpt(int __oflag ) ;
extern  __attribute__((__nothrow__)) int grantpt(int __fd ) ;
extern  __attribute__((__nothrow__)) int unlockpt(int __fd ) ;
extern  __attribute__((__nothrow__)) char *ptsname(int __fd ) ;
extern  __attribute__((__nothrow__)) int ptsname_r(int __fd , char *__buf , size_t __buflen )  __attribute__((__nonnull__(2))) ;
extern int getpt(void) ;
extern  __attribute__((__nothrow__)) int getloadavg(double *__loadavg , int __nelem )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int access(char const   *__name , int __type )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int euidaccess(char const   *__name , int __type )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int eaccess(char const   *__name , int __type )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int faccessat(int __fd , char const   *__file , int __type , int __flag )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) __off64_t lseek(int __fd , __off64_t __offset , int __whence )  __asm__("lseek64")  ;
extern  __attribute__((__nothrow__)) __off64_t lseek64(int __fd , __off64_t __offset , int __whence ) ;
extern int close(int __fd ) ;
extern ssize_t read(int __fd , void *__buf , size_t __nbytes ) ;
extern ssize_t write(int __fd , void const   *__buf , size_t __n ) ;
extern ssize_t pread(int __fd , void *__buf , size_t __nbytes , __off64_t __offset )  __asm__("pread64")  ;
extern ssize_t pwrite(int __fd , void const   *__buf , size_t __nbytes , __off64_t __offset )  __asm__("pwrite64")  ;
extern ssize_t pread64(int __fd , void *__buf , size_t __nbytes , __off64_t __offset ) ;
extern ssize_t pwrite64(int __fd , void const   *__buf , size_t __n , __off64_t __offset ) ;
extern  __attribute__((__nothrow__)) int pipe(int *__pipedes ) ;
extern  __attribute__((__nothrow__)) int pipe2(int *__pipedes , int __flags ) ;
extern  __attribute__((__nothrow__)) unsigned int alarm(unsigned int __seconds ) ;
extern unsigned int sleep(unsigned int __seconds ) ;
extern  __attribute__((__nothrow__)) __useconds_t ualarm(__useconds_t __value , __useconds_t __interval ) ;
extern int usleep(__useconds_t __useconds ) ;
extern int pause(void) ;
extern  __attribute__((__nothrow__)) int chown(char const   *__file , __uid_t __owner , __gid_t __group )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int fchown(int __fd , __uid_t __owner , __gid_t __group ) ;
extern  __attribute__((__nothrow__)) int lchown(char const   *__file , __uid_t __owner , __gid_t __group )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int fchownat(int __fd , char const   *__file , __uid_t __owner , __gid_t __group , int __flag )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int chdir(char const   *__path )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int fchdir(int __fd ) ;
extern  __attribute__((__nothrow__)) char *getcwd(char *__buf , size_t __size ) ;
extern  __attribute__((__nothrow__)) char *get_current_dir_name(void) ;
extern  __attribute__((__nothrow__)) char *getwd(char *__buf )  __attribute__((__nonnull__(1), __deprecated__)) ;
extern  __attribute__((__nothrow__)) int dup(int __fd ) ;
extern  __attribute__((__nothrow__)) int dup2(int __fd , int __fd2 ) ;
extern  __attribute__((__nothrow__)) int dup3(int __fd , int __fd2 , int __flags ) ;
extern char **__environ ;
extern char **environ ;
extern  __attribute__((__nothrow__)) int execve(char const   *__path , char * const  *__argv , char * const  *__envp )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int fexecve(int __fd , char * const  *__argv , char * const  *__envp )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int execv(char const   *__path , char * const  *__argv )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execle(char const   *__path , char const   *__arg  , ...)  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execl(char const   *__path , char const   *__arg  , ...)  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execvp(char const   *__file , char * const  *__argv )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execlp(char const   *__file , char const   *__arg  , ...)  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execvpe(char const   *__file , char * const  *__argv , char * const  *__envp )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int nice(int __inc ) ;
extern  __attribute__((__noreturn__)) void _exit(int __status ) ;
extern  __attribute__((__nothrow__)) long pathconf(char const   *__path , int __name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long fpathconf(int __fd , int __name ) ;
extern  __attribute__((__nothrow__)) long sysconf(int __name ) ;
extern  __attribute__((__nothrow__)) size_t confstr(int __name , char *__buf , size_t __len ) ;
extern  __attribute__((__nothrow__)) __pid_t getpid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getppid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getpgrp(void) ;
extern  __attribute__((__nothrow__)) __pid_t __getpgid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) __pid_t getpgid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) int setpgid(__pid_t __pid , __pid_t __pgid ) ;
extern  __attribute__((__nothrow__)) int setpgrp(void) ;
extern  __attribute__((__nothrow__)) __pid_t setsid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getsid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) __uid_t getuid(void) ;
extern  __attribute__((__nothrow__)) __uid_t geteuid(void) ;
extern  __attribute__((__nothrow__)) __gid_t getgid(void) ;
extern  __attribute__((__nothrow__)) __gid_t getegid(void) ;
extern  __attribute__((__nothrow__)) int getgroups(int __size , __gid_t *__list ) ;
extern  __attribute__((__nothrow__)) int group_member(__gid_t __gid ) ;
extern  __attribute__((__nothrow__)) int setuid(__uid_t __uid ) ;
extern  __attribute__((__nothrow__)) int setreuid(__uid_t __ruid , __uid_t __euid ) ;
extern  __attribute__((__nothrow__)) int seteuid(__uid_t __uid ) ;
extern  __attribute__((__nothrow__)) int setgid(__gid_t __gid ) ;
extern  __attribute__((__nothrow__)) int setregid(__gid_t __rgid , __gid_t __egid ) ;
extern  __attribute__((__nothrow__)) int setegid(__gid_t __gid ) ;
extern  __attribute__((__nothrow__)) int getresuid(__uid_t *__ruid , __uid_t *__euid , __uid_t *__suid ) ;
extern  __attribute__((__nothrow__)) int getresgid(__gid_t *__rgid , __gid_t *__egid , __gid_t *__sgid ) ;
extern  __attribute__((__nothrow__)) int setresuid(__uid_t __ruid , __uid_t __euid , __uid_t __suid ) ;
extern  __attribute__((__nothrow__)) int setresgid(__gid_t __rgid , __gid_t __egid , __gid_t __sgid ) ;
extern  __attribute__((__nothrow__)) __pid_t fork(void) ;
extern  __attribute__((__nothrow__)) __pid_t vfork(void) ;
extern  __attribute__((__nothrow__)) char *ttyname(int __fd ) ;
extern  __attribute__((__nothrow__)) int ttyname_r(int __fd , char *__buf , size_t __buflen )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int isatty(int __fd ) ;
extern  __attribute__((__nothrow__)) int ttyslot(void) ;
extern  __attribute__((__nothrow__)) int link(char const   *__from , char const   *__to )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int linkat(int __fromfd , char const   *__from , int __tofd , char const   *__to , int __flags )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) int symlink(char const   *__from , char const   *__to )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) ssize_t readlink(char const   * __restrict  __path , char * __restrict  __buf , size_t __len )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int symlinkat(char const   *__from , int __tofd , char const   *__to )  __attribute__((__nonnull__(1,3))) ;
extern  __attribute__((__nothrow__)) ssize_t readlinkat(int __fd , char const   * __restrict  __path , char * __restrict  __buf , size_t __len )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) int unlink(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int unlinkat(int __fd , char const   *__name , int __flag )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int rmdir(char const   *__path )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) __pid_t tcgetpgrp(int __fd ) ;
extern  __attribute__((__nothrow__)) int tcsetpgrp(int __fd , __pid_t __pgrp_id ) ;
extern char *getlogin(void) ;
extern int getlogin_r(char *__name , size_t __name_len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int setlogin(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern char *optarg ;
extern int optind ;
extern int opterr ;
extern int optopt ;
extern  __attribute__((__nothrow__)) int getopt(int ___argc , char * const  *___argv , char const   *__shortopts ) ;
extern  __attribute__((__nothrow__)) int gethostname(char *__name , size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int sethostname(char const   *__name , size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int sethostid(long __id ) ;
extern  __attribute__((__nothrow__)) int getdomainname(char *__name , size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int setdomainname(char const   *__name , size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int vhangup(void) ;
extern  __attribute__((__nothrow__)) int revoke(char const   *__file )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int profil(unsigned short *__sample_buffer , size_t __size , size_t __offset , unsigned int __scale )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int acct(char const   *__name ) ;
extern  __attribute__((__nothrow__)) char *getusershell(void) ;
extern  __attribute__((__nothrow__)) void endusershell(void) ;
extern  __attribute__((__nothrow__)) void setusershell(void) ;
extern  __attribute__((__nothrow__)) int daemon(int __nochdir , int __noclose ) ;
extern  __attribute__((__nothrow__)) int chroot(char const   *__path )  __attribute__((__nonnull__(1))) ;
extern char *getpass(char const   *__prompt )  __attribute__((__nonnull__(1))) ;
extern int fsync(int __fd ) ;
extern long gethostid(void) ;
extern  __attribute__((__nothrow__)) void sync(void) ;
extern  __attribute__((__nothrow__)) int getpagesize(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int getdtablesize(void) ;
extern  __attribute__((__nothrow__)) int truncate(char const   *__file , __off64_t __length )  __asm__("truncate64") __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int truncate64(char const   *__file , __off64_t __length )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int ftruncate(int __fd , __off64_t __length )  __asm__("ftruncate64")  ;
extern  __attribute__((__nothrow__)) int ftruncate64(int __fd , __off64_t __length ) ;
extern  __attribute__((__nothrow__)) int brk(void *__addr ) ;
extern  __attribute__((__nothrow__)) void *sbrk(intptr_t __delta ) ;
extern  __attribute__((__nothrow__)) long syscall(long __sysno  , ...) ;
extern int lockf(int __fd , int __cmd , __off64_t __len )  __asm__("lockf64")  ;
extern int lockf64(int __fd , int __cmd , __off64_t __len ) ;
extern int fdatasync(int __fildes ) ;
extern  __attribute__((__nothrow__)) char *crypt(char const   *__key , char const   *__salt )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void encrypt(char *__block , int __edflag )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void swab(void const   * __restrict  __from , void * __restrict  __to , ssize_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) intmax_t imaxabs(intmax_t __n )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) imaxdiv_t imaxdiv(intmax_t __numer , intmax_t __denom )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) intmax_t strtoimax(char const   * __restrict  nptr , char ** __restrict  endptr , int base ) ;
__inline extern  __attribute__((__nothrow__)) uintmax_t strtoumax(char const   * __restrict  nptr , char ** __restrict  endptr , int base ) ;
__inline extern  __attribute__((__nothrow__)) intmax_t wcstoimax(__gwchar_t const   * __restrict  nptr , __gwchar_t ** __restrict  endptr , int base ) ;
__inline extern  __attribute__((__nothrow__)) uintmax_t wcstoumax(__gwchar_t const   * __restrict  nptr , __gwchar_t ** __restrict  endptr , int base ) ;
extern  __attribute__((__nothrow__)) long long __strtoll_internal(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base , int __group )  __attribute__((__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) intmax_t strtoimax(char const   * __restrict  nptr , char ** __restrict  endptr , int base ) ;
__inline extern intmax_t strtoimax(char const   * __restrict  nptr , char ** __restrict  endptr , int base ) 
{ long long tmp ;

  {
  tmp = __strtoll_internal(nptr, endptr, base, 0);
  return (tmp);
}
}
extern  __attribute__((__nothrow__)) unsigned long long __strtoull_internal(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base , int __group )  __attribute__((__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) uintmax_t strtoumax(char const   * __restrict  nptr , char ** __restrict  endptr , int base ) ;
__inline extern uintmax_t strtoumax(char const   * __restrict  nptr , char ** __restrict  endptr , int base ) 
{ unsigned long long tmp ;

  {
  tmp = __strtoull_internal(nptr, endptr, base, 0);
  return (tmp);
}
}
extern  __attribute__((__nothrow__)) long long __wcstoll_internal(__gwchar_t const   * __restrict  __nptr , __gwchar_t ** __restrict  __endptr , int __base , int __group )  __attribute__((__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) intmax_t wcstoimax(__gwchar_t const   * __restrict  nptr , __gwchar_t ** __restrict  endptr , int base ) ;
__inline extern intmax_t wcstoimax(__gwchar_t const   * __restrict  nptr , __gwchar_t ** __restrict  endptr , int base ) 
{ long long tmp ;

  {
  tmp = __wcstoll_internal(nptr, endptr, base, 0);
  return (tmp);
}
}
extern  __attribute__((__nothrow__)) unsigned long long __wcstoull_internal(__gwchar_t const   * __restrict  __nptr , __gwchar_t ** __restrict  __endptr , int __base , int __group )  __attribute__((__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) uintmax_t wcstoumax(__gwchar_t const   * __restrict  nptr , __gwchar_t ** __restrict  endptr , int base ) ;
__inline extern uintmax_t wcstoumax(__gwchar_t const   * __restrict  nptr , __gwchar_t ** __restrict  endptr , int base ) 
{ unsigned long long tmp ;

  {
  tmp = __wcstoull_internal(nptr, endptr, base, 0);
  return (tmp);
}
}
extern  __attribute__((__nothrow__)) double acos(double __x ) ;
extern  __attribute__((__nothrow__)) double __acos(double __x ) ;
extern  __attribute__((__nothrow__)) double asin(double __x ) ;
extern  __attribute__((__nothrow__)) double __asin(double __x ) ;
extern  __attribute__((__nothrow__)) double atan(double __x ) ;
extern  __attribute__((__nothrow__)) double __atan(double __x ) ;
extern  __attribute__((__nothrow__)) double atan2(double __y , double __x ) ;
extern  __attribute__((__nothrow__)) double __atan2(double __y , double __x ) ;
extern  __attribute__((__nothrow__)) double cos(double __x ) ;
extern  __attribute__((__nothrow__)) double __cos(double __x ) ;
extern  __attribute__((__nothrow__)) double sin(double __x ) ;
extern  __attribute__((__nothrow__)) double __sin(double __x ) ;
extern  __attribute__((__nothrow__)) double tan(double __x ) ;
extern  __attribute__((__nothrow__)) double __tan(double __x ) ;
extern  __attribute__((__nothrow__)) double cosh(double __x ) ;
extern  __attribute__((__nothrow__)) double __cosh(double __x ) ;
extern  __attribute__((__nothrow__)) double sinh(double __x ) ;
extern  __attribute__((__nothrow__)) double __sinh(double __x ) ;
extern  __attribute__((__nothrow__)) double tanh(double __x ) ;
extern  __attribute__((__nothrow__)) double __tanh(double __x ) ;
extern  __attribute__((__nothrow__)) void sincos(double __x , double *__sinx , double *__cosx ) ;
extern  __attribute__((__nothrow__)) void __sincos(double __x , double *__sinx , double *__cosx ) ;
extern  __attribute__((__nothrow__)) double acosh(double __x ) ;
extern  __attribute__((__nothrow__)) double __acosh(double __x ) ;
extern  __attribute__((__nothrow__)) double asinh(double __x ) ;
extern  __attribute__((__nothrow__)) double __asinh(double __x ) ;
extern  __attribute__((__nothrow__)) double atanh(double __x ) ;
extern  __attribute__((__nothrow__)) double __atanh(double __x ) ;
extern  __attribute__((__nothrow__)) double exp(double __x ) ;
extern  __attribute__((__nothrow__)) double __exp(double __x ) ;
extern  __attribute__((__nothrow__)) double frexp(double __x , int *__exponent ) ;
extern  __attribute__((__nothrow__)) double __frexp(double __x , int *__exponent ) ;
extern  __attribute__((__nothrow__)) double ldexp(double __x , int __exponent ) ;
extern  __attribute__((__nothrow__)) double __ldexp(double __x , int __exponent ) ;
extern  __attribute__((__nothrow__)) double log(double __x ) ;
extern  __attribute__((__nothrow__)) double __log(double __x ) ;
extern  __attribute__((__nothrow__)) double log10(double __x ) ;
extern  __attribute__((__nothrow__)) double __log10(double __x ) ;
extern  __attribute__((__nothrow__)) double modf(double __x , double *__iptr ) ;
extern  __attribute__((__nothrow__)) double __modf(double __x , double *__iptr ) ;
extern  __attribute__((__nothrow__)) double exp10(double __x ) ;
extern  __attribute__((__nothrow__)) double __exp10(double __x ) ;
extern  __attribute__((__nothrow__)) double pow10(double __x ) ;
extern  __attribute__((__nothrow__)) double __pow10(double __x ) ;
extern  __attribute__((__nothrow__)) double expm1(double __x ) ;
extern  __attribute__((__nothrow__)) double __expm1(double __x ) ;
extern  __attribute__((__nothrow__)) double log1p(double __x ) ;
extern  __attribute__((__nothrow__)) double __log1p(double __x ) ;
extern  __attribute__((__nothrow__)) double logb(double __x ) ;
extern  __attribute__((__nothrow__)) double __logb(double __x ) ;
extern  __attribute__((__nothrow__)) double exp2(double __x ) ;
extern  __attribute__((__nothrow__)) double __exp2(double __x ) ;
extern  __attribute__((__nothrow__)) double log2(double __x ) ;
extern  __attribute__((__nothrow__)) double __log2(double __x ) ;
extern  __attribute__((__nothrow__)) double pow(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double __pow(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double sqrt(double __x ) ;
extern  __attribute__((__nothrow__)) double __sqrt(double __x ) ;
extern  __attribute__((__nothrow__)) double hypot(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double __hypot(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double cbrt(double __x ) ;
extern  __attribute__((__nothrow__)) double __cbrt(double __x ) ;
__inline extern  __attribute__((__nothrow__)) double ceil(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __ceil(double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) double fabs(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __fabs(double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) double floor(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __floor(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double fmod(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double __fmod(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) int __isinf(double __value )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __finite(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int isinf(double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int finite(double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double drem(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double __drem(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double significand(double __x ) ;
extern  __attribute__((__nothrow__)) double __significand(double __x ) ;
extern  __attribute__((__nothrow__)) double copysign(double __x , double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __copysign(double __x , double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double nan(char const   *__tagb )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __nan(char const   *__tagb )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int __isnan(double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int isnan(double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double j0(double  ) ;
extern  __attribute__((__nothrow__)) double __j0(double  ) ;
extern  __attribute__((__nothrow__)) double j1(double  ) ;
extern  __attribute__((__nothrow__)) double __j1(double  ) ;
extern  __attribute__((__nothrow__)) double jn(int  , double  ) ;
extern  __attribute__((__nothrow__)) double __jn(int  , double  ) ;
extern  __attribute__((__nothrow__)) double y0(double  ) ;
extern  __attribute__((__nothrow__)) double __y0(double  ) ;
extern  __attribute__((__nothrow__)) double y1(double  ) ;
extern  __attribute__((__nothrow__)) double __y1(double  ) ;
extern  __attribute__((__nothrow__)) double yn(int  , double  ) ;
extern  __attribute__((__nothrow__)) double __yn(int  , double  ) ;
extern  __attribute__((__nothrow__)) double erf(double  ) ;
extern  __attribute__((__nothrow__)) double __erf(double  ) ;
extern  __attribute__((__nothrow__)) double erfc(double  ) ;
extern  __attribute__((__nothrow__)) double __erfc(double  ) ;
extern  __attribute__((__nothrow__)) double lgamma(double  ) ;
extern  __attribute__((__nothrow__)) double __lgamma(double  ) ;
extern  __attribute__((__nothrow__)) double tgamma(double  ) ;
extern  __attribute__((__nothrow__)) double __tgamma(double  ) ;
extern  __attribute__((__nothrow__)) double gamma(double  ) ;
extern  __attribute__((__nothrow__)) double __gamma(double  ) ;
extern  __attribute__((__nothrow__)) double lgamma_r(double  , int *__signgamp ) ;
extern  __attribute__((__nothrow__)) double __lgamma_r(double  , int *__signgamp ) ;
extern  __attribute__((__nothrow__)) double rint(double __x ) ;
extern  __attribute__((__nothrow__)) double __rint(double __x ) ;
extern  __attribute__((__nothrow__)) double nextafter(double __x , double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __nextafter(double __x , double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double nexttoward(double __x , long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __nexttoward(double __x , long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double remainder(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double __remainder(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double scalbn(double __x , int __n ) ;
extern  __attribute__((__nothrow__)) double __scalbn(double __x , int __n ) ;
extern  __attribute__((__nothrow__)) int ilogb(double __x ) ;
extern  __attribute__((__nothrow__)) int __ilogb(double __x ) ;
extern  __attribute__((__nothrow__)) double scalbln(double __x , long __n ) ;
extern  __attribute__((__nothrow__)) double __scalbln(double __x , long __n ) ;
extern  __attribute__((__nothrow__)) double nearbyint(double __x ) ;
extern  __attribute__((__nothrow__)) double __nearbyint(double __x ) ;
extern  __attribute__((__nothrow__)) double round(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __round(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double trunc(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __trunc(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double remquo(double __x , double __y , int *__quo ) ;
extern  __attribute__((__nothrow__)) double __remquo(double __x , double __y , int *__quo ) ;
__inline extern  __attribute__((__nothrow__)) long lrint(double __x ) ;
extern  __attribute__((__nothrow__)) long __lrint(double __x ) ;
__inline extern  __attribute__((__nothrow__)) long long llrint(double __x ) ;
extern  __attribute__((__nothrow__)) long long __llrint(double __x ) ;
extern  __attribute__((__nothrow__)) long lround(double __x ) ;
extern  __attribute__((__nothrow__)) long __lround(double __x ) ;
extern  __attribute__((__nothrow__)) long long llround(double __x ) ;
extern  __attribute__((__nothrow__)) long long __llround(double __x ) ;
extern  __attribute__((__nothrow__)) double fdim(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double __fdim(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double fmax(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double __fmax(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double fmin(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double __fmin(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) int __fpclassify(double __value )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __signbit(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double fma(double __x , double __y , double __z ) ;
extern  __attribute__((__nothrow__)) double __fma(double __x , double __y , double __z ) ;
extern  __attribute__((__nothrow__)) double scalb(double __x , double __n ) ;
extern  __attribute__((__nothrow__)) double __scalb(double __x , double __n ) ;
extern  __attribute__((__nothrow__)) float acosf(float __x ) ;
extern  __attribute__((__nothrow__)) float __acosf(float __x ) ;
extern  __attribute__((__nothrow__)) float asinf(float __x ) ;
extern  __attribute__((__nothrow__)) float __asinf(float __x ) ;
extern  __attribute__((__nothrow__)) float atanf(float __x ) ;
extern  __attribute__((__nothrow__)) float __atanf(float __x ) ;
extern  __attribute__((__nothrow__)) float atan2f(float __y , float __x ) ;
extern  __attribute__((__nothrow__)) float __atan2f(float __y , float __x ) ;
extern  __attribute__((__nothrow__)) float cosf(float __x ) ;
extern  __attribute__((__nothrow__)) float __cosf(float __x ) ;
extern  __attribute__((__nothrow__)) float sinf(float __x ) ;
extern  __attribute__((__nothrow__)) float __sinf(float __x ) ;
extern  __attribute__((__nothrow__)) float tanf(float __x ) ;
extern  __attribute__((__nothrow__)) float __tanf(float __x ) ;
extern  __attribute__((__nothrow__)) float coshf(float __x ) ;
extern  __attribute__((__nothrow__)) float __coshf(float __x ) ;
extern  __attribute__((__nothrow__)) float sinhf(float __x ) ;
extern  __attribute__((__nothrow__)) float __sinhf(float __x ) ;
extern  __attribute__((__nothrow__)) float tanhf(float __x ) ;
extern  __attribute__((__nothrow__)) float __tanhf(float __x ) ;
extern  __attribute__((__nothrow__)) void sincosf(float __x , float *__sinx , float *__cosx ) ;
extern  __attribute__((__nothrow__)) void __sincosf(float __x , float *__sinx , float *__cosx ) ;
extern  __attribute__((__nothrow__)) float acoshf(float __x ) ;
extern  __attribute__((__nothrow__)) float __acoshf(float __x ) ;
extern  __attribute__((__nothrow__)) float asinhf(float __x ) ;
extern  __attribute__((__nothrow__)) float __asinhf(float __x ) ;
extern  __attribute__((__nothrow__)) float atanhf(float __x ) ;
extern  __attribute__((__nothrow__)) float __atanhf(float __x ) ;
extern  __attribute__((__nothrow__)) float expf(float __x ) ;
extern  __attribute__((__nothrow__)) float __expf(float __x ) ;
extern  __attribute__((__nothrow__)) float frexpf(float __x , int *__exponent ) ;
extern  __attribute__((__nothrow__)) float __frexpf(float __x , int *__exponent ) ;
extern  __attribute__((__nothrow__)) float ldexpf(float __x , int __exponent ) ;
extern  __attribute__((__nothrow__)) float __ldexpf(float __x , int __exponent ) ;
extern  __attribute__((__nothrow__)) float logf(float __x ) ;
extern  __attribute__((__nothrow__)) float __logf(float __x ) ;
extern  __attribute__((__nothrow__)) float log10f(float __x ) ;
extern  __attribute__((__nothrow__)) float __log10f(float __x ) ;
extern  __attribute__((__nothrow__)) float modff(float __x , float *__iptr ) ;
extern  __attribute__((__nothrow__)) float __modff(float __x , float *__iptr ) ;
extern  __attribute__((__nothrow__)) float exp10f(float __x ) ;
extern  __attribute__((__nothrow__)) float __exp10f(float __x ) ;
extern  __attribute__((__nothrow__)) float pow10f(float __x ) ;
extern  __attribute__((__nothrow__)) float __pow10f(float __x ) ;
extern  __attribute__((__nothrow__)) float expm1f(float __x ) ;
extern  __attribute__((__nothrow__)) float __expm1f(float __x ) ;
extern  __attribute__((__nothrow__)) float log1pf(float __x ) ;
extern  __attribute__((__nothrow__)) float __log1pf(float __x ) ;
extern  __attribute__((__nothrow__)) float logbf(float __x ) ;
extern  __attribute__((__nothrow__)) float __logbf(float __x ) ;
extern  __attribute__((__nothrow__)) float exp2f(float __x ) ;
extern  __attribute__((__nothrow__)) float __exp2f(float __x ) ;
extern  __attribute__((__nothrow__)) float log2f(float __x ) ;
extern  __attribute__((__nothrow__)) float __log2f(float __x ) ;
extern  __attribute__((__nothrow__)) float powf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float __powf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float sqrtf(float __x ) ;
extern  __attribute__((__nothrow__)) float __sqrtf(float __x ) ;
extern  __attribute__((__nothrow__)) float hypotf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float __hypotf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float cbrtf(float __x ) ;
extern  __attribute__((__nothrow__)) float __cbrtf(float __x ) ;
__inline extern  __attribute__((__nothrow__)) float ceilf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __ceilf(float __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) float fabsf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __fabsf(float __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) float floorf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __floorf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float fmodf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float __fmodf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) int __isinff(float __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int __finitef(float __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int isinff(float __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int finitef(float __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float dremf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float __dremf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float significandf(float __x ) ;
extern  __attribute__((__nothrow__)) float __significandf(float __x ) ;
extern  __attribute__((__nothrow__)) float copysignf(float __x , float __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __copysignf(float __x , float __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float nanf(char const   *__tagb )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __nanf(char const   *__tagb )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int __isnanf(float __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int isnanf(float __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float j0f(float  ) ;
extern  __attribute__((__nothrow__)) float __j0f(float  ) ;
extern  __attribute__((__nothrow__)) float j1f(float  ) ;
extern  __attribute__((__nothrow__)) float __j1f(float  ) ;
extern  __attribute__((__nothrow__)) float jnf(int  , float  ) ;
extern  __attribute__((__nothrow__)) float __jnf(int  , float  ) ;
extern  __attribute__((__nothrow__)) float y0f(float  ) ;
extern  __attribute__((__nothrow__)) float __y0f(float  ) ;
extern  __attribute__((__nothrow__)) float y1f(float  ) ;
extern  __attribute__((__nothrow__)) float __y1f(float  ) ;
extern  __attribute__((__nothrow__)) float ynf(int  , float  ) ;
extern  __attribute__((__nothrow__)) float __ynf(int  , float  ) ;
extern  __attribute__((__nothrow__)) float erff(float  ) ;
extern  __attribute__((__nothrow__)) float __erff(float  ) ;
extern  __attribute__((__nothrow__)) float erfcf(float  ) ;
extern  __attribute__((__nothrow__)) float __erfcf(float  ) ;
extern  __attribute__((__nothrow__)) float lgammaf(float  ) ;
extern  __attribute__((__nothrow__)) float __lgammaf(float  ) ;
extern  __attribute__((__nothrow__)) float tgammaf(float  ) ;
extern  __attribute__((__nothrow__)) float __tgammaf(float  ) ;
extern  __attribute__((__nothrow__)) float gammaf(float  ) ;
extern  __attribute__((__nothrow__)) float __gammaf(float  ) ;
extern  __attribute__((__nothrow__)) float lgammaf_r(float  , int *__signgamp ) ;
extern  __attribute__((__nothrow__)) float __lgammaf_r(float  , int *__signgamp ) ;
extern  __attribute__((__nothrow__)) float rintf(float __x ) ;
extern  __attribute__((__nothrow__)) float __rintf(float __x ) ;
extern  __attribute__((__nothrow__)) float nextafterf(float __x , float __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __nextafterf(float __x , float __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float nexttowardf(float __x , long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __nexttowardf(float __x , long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float remainderf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float __remainderf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float scalbnf(float __x , int __n ) ;
extern  __attribute__((__nothrow__)) float __scalbnf(float __x , int __n ) ;
extern  __attribute__((__nothrow__)) int ilogbf(float __x ) ;
extern  __attribute__((__nothrow__)) int __ilogbf(float __x ) ;
extern  __attribute__((__nothrow__)) float scalblnf(float __x , long __n ) ;
extern  __attribute__((__nothrow__)) float __scalblnf(float __x , long __n ) ;
extern  __attribute__((__nothrow__)) float nearbyintf(float __x ) ;
extern  __attribute__((__nothrow__)) float __nearbyintf(float __x ) ;
extern  __attribute__((__nothrow__)) float roundf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __roundf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float truncf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __truncf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float remquof(float __x , float __y , int *__quo ) ;
extern  __attribute__((__nothrow__)) float __remquof(float __x , float __y , int *__quo ) ;
__inline extern  __attribute__((__nothrow__)) long lrintf(float __x ) ;
extern  __attribute__((__nothrow__)) long __lrintf(float __x ) ;
__inline extern  __attribute__((__nothrow__)) long long llrintf(float __x ) ;
extern  __attribute__((__nothrow__)) long long __llrintf(float __x ) ;
extern  __attribute__((__nothrow__)) long lroundf(float __x ) ;
extern  __attribute__((__nothrow__)) long __lroundf(float __x ) ;
extern  __attribute__((__nothrow__)) long long llroundf(float __x ) ;
extern  __attribute__((__nothrow__)) long long __llroundf(float __x ) ;
extern  __attribute__((__nothrow__)) float fdimf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float __fdimf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float fmaxf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float __fmaxf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float fminf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float __fminf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) int __fpclassifyf(float __value )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __signbitf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float fmaf(float __x , float __y , float __z ) ;
extern  __attribute__((__nothrow__)) float __fmaf(float __x , float __y , float __z ) ;
extern  __attribute__((__nothrow__)) float scalbf(float __x , float __n ) ;
extern  __attribute__((__nothrow__)) float __scalbf(float __x , float __n ) ;
extern  __attribute__((__nothrow__)) long double acosl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __acosl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double asinl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __asinl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double atanl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __atanl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double atan2l(long double __y , long double __x ) ;
__inline extern  __attribute__((__nothrow__)) long double __atan2l(long double __y , long double __x ) ;
extern  __attribute__((__nothrow__)) long double cosl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __cosl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double sinl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __sinl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double tanl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __tanl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double coshl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __coshl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double sinhl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __sinhl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double tanhl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __tanhl(long double __x ) ;
extern  __attribute__((__nothrow__)) void sincosl(long double __x , long double *__sinx , long double *__cosx ) ;
extern  __attribute__((__nothrow__)) void __sincosl(long double __x , long double *__sinx , long double *__cosx ) ;
extern  __attribute__((__nothrow__)) long double acoshl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __acoshl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double asinhl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __asinhl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double atanhl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __atanhl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double expl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __expl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double frexpl(long double __x , int *__exponent ) ;
extern  __attribute__((__nothrow__)) long double __frexpl(long double __x , int *__exponent ) ;
extern  __attribute__((__nothrow__)) long double ldexpl(long double __x , int __exponent ) ;
extern  __attribute__((__nothrow__)) long double __ldexpl(long double __x , int __exponent ) ;
extern  __attribute__((__nothrow__)) long double logl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __logl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double log10l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __log10l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double modfl(long double __x , long double *__iptr ) ;
extern  __attribute__((__nothrow__)) long double __modfl(long double __x , long double *__iptr ) ;
extern  __attribute__((__nothrow__)) long double exp10l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __exp10l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double pow10l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __pow10l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double expm1l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __expm1l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double log1pl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __log1pl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double logbl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __logbl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double exp2l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __exp2l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double log2l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __log2l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double powl(long double __x , long double __y ) ;
extern  __attribute__((__nothrow__)) long double __powl(long double __x , long double __y ) ;
extern  __attribute__((__nothrow__)) long double sqrtl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __sqrtl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double hypotl(long double __x , long double __y ) ;
extern  __attribute__((__nothrow__)) long double __hypotl(long double __x , long double __y ) ;
extern  __attribute__((__nothrow__)) long double cbrtl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __cbrtl(long double __x ) ;
__inline extern  __attribute__((__nothrow__)) long double ceill(long double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double __ceill(long double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) long double fabsl(long double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) long double __fabsl(long double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) long double floorl(long double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double __floorl(long double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double fmodl(long double __x , long double __y ) ;
extern  __attribute__((__nothrow__)) long double __fmodl(long double __x , long double __y ) ;
extern  __attribute__((__nothrow__)) int __isinfl(long double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int __finitel(long double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int isinfl(long double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int finitel(long double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double dreml(long double __x , long double __y ) ;
extern  __attribute__((__nothrow__)) long double __dreml(long double __x , long double __y ) ;
extern  __attribute__((__nothrow__)) long double significandl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __significandl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double copysignl(long double __x , long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double __copysignl(long double __x , long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double nanl(char const   *__tagb )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double __nanl(char const   *__tagb )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int __isnanl(long double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int isnanl(long double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double j0l(long double  ) ;
extern  __attribute__((__nothrow__)) long double __j0l(long double  ) ;
extern  __attribute__((__nothrow__)) long double j1l(long double  ) ;
extern  __attribute__((__nothrow__)) long double __j1l(long double  ) ;
extern  __attribute__((__nothrow__)) long double jnl(int  , long double  ) ;
extern  __attribute__((__nothrow__)) long double __jnl(int  , long double  ) ;
extern  __attribute__((__nothrow__)) long double y0l(long double  ) ;
extern  __attribute__((__nothrow__)) long double __y0l(long double  ) ;
extern  __attribute__((__nothrow__)) long double y1l(long double  ) ;
extern  __attribute__((__nothrow__)) long double __y1l(long double  ) ;
extern  __attribute__((__nothrow__)) long double ynl(int  , long double  ) ;
extern  __attribute__((__nothrow__)) long double __ynl(int  , long double  ) ;
extern  __attribute__((__nothrow__)) long double erfl(long double  ) ;
extern  __attribute__((__nothrow__)) long double __erfl(long double  ) ;
extern  __attribute__((__nothrow__)) long double erfcl(long double  ) ;
extern  __attribute__((__nothrow__)) long double __erfcl(long double  ) ;
extern  __attribute__((__nothrow__)) long double lgammal(long double  ) ;
extern  __attribute__((__nothrow__)) long double __lgammal(long double  ) ;
extern  __attribute__((__nothrow__)) long double tgammal(long double  ) ;
extern  __attribute__((__nothrow__)) long double __tgammal(long double  ) ;
extern  __attribute__((__nothrow__)) long double gammal(long double  ) ;
extern  __attribute__((__nothrow__)) long double __gammal(long double  ) ;
extern  __attribute__((__nothrow__)) long double lgammal_r(long double  , int *__signgamp ) ;
extern  __attribute__((__nothrow__)) long double __lgammal_r(long double  , int *__signgamp ) ;
extern  __attribute__((__nothrow__)) long double rintl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __rintl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double nextafterl(long double __x , long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double __nextafterl(long double __x , long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double nexttowardl(long double __x , long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double __nexttowardl(long double __x , long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double remainderl(long double __x , long double __y ) ;
extern  __attribute__((__nothrow__)) long double __remainderl(long double __x , long double __y ) ;
extern  __attribute__((__nothrow__)) long double scalbnl(long double __x , int __n ) ;
extern  __attribute__((__nothrow__)) long double __scalbnl(long double __x , int __n ) ;
extern  __attribute__((__nothrow__)) int ilogbl(long double __x ) ;
extern  __attribute__((__nothrow__)) int __ilogbl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double scalblnl(long double __x , long __n ) ;
extern  __attribute__((__nothrow__)) long double __scalblnl(long double __x , long __n ) ;
extern  __attribute__((__nothrow__)) long double nearbyintl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __nearbyintl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double roundl(long double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double __roundl(long double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double truncl(long double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double __truncl(long double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double remquol(long double __x , long double __y , int *__quo ) ;
extern  __attribute__((__nothrow__)) long double __remquol(long double __x , long double __y , int *__quo ) ;
__inline extern  __attribute__((__nothrow__)) long lrintl(long double __x ) ;
extern  __attribute__((__nothrow__)) long __lrintl(long double __x ) ;
__inline extern  __attribute__((__nothrow__)) long long llrintl(long double __x ) ;
extern  __attribute__((__nothrow__)) long long __llrintl(long double __x ) ;
extern  __attribute__((__nothrow__)) long lroundl(long double __x ) ;
extern  __attribute__((__nothrow__)) long __lroundl(long double __x ) ;
extern  __attribute__((__nothrow__)) long long llroundl(long double __x ) ;
extern  __attribute__((__nothrow__)) long long __llroundl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double fdiml(long double __x , long double __y ) ;
extern  __attribute__((__nothrow__)) long double __fdiml(long double __x , long double __y ) ;
extern  __attribute__((__nothrow__)) long double fmaxl(long double __x , long double __y ) ;
extern  __attribute__((__nothrow__)) long double __fmaxl(long double __x , long double __y ) ;
extern  __attribute__((__nothrow__)) long double fminl(long double __x , long double __y ) ;
extern  __attribute__((__nothrow__)) long double __fminl(long double __x , long double __y ) ;
extern  __attribute__((__nothrow__)) int __fpclassifyl(long double __value )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __signbitl(long double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double fmal(long double __x , long double __y , long double __z ) ;
extern  __attribute__((__nothrow__)) long double __fmal(long double __x , long double __y , long double __z ) ;
extern  __attribute__((__nothrow__)) long double scalbl(long double __x , long double __n ) ;
extern  __attribute__((__nothrow__)) long double __scalbl(long double __x , long double __n ) ;
extern int signgam ;
extern _LIB_VERSION_TYPE _LIB_VERSION ;
extern int matherr(struct exception *__exc ) ;
__inline extern  __attribute__((__nothrow__)) int __signbitf(float __x )  __attribute__((__const__)) ;
__inline extern int __signbitf(float __x ) 
{ union __anonunion___u_33 __u ;

  {
  __u.__f = __x;
  return (__u.__i < 0);
}
}
__inline extern  __attribute__((__nothrow__)) int __signbit(double __x )  __attribute__((__const__)) ;
__inline extern int __signbit(double __x ) 
{ union __anonunion___u_34 __u ;

  {
  __u.__d = __x;
  return (__u.__i[1] < 0);
}
}
__inline extern  __attribute__((__nothrow__)) int __signbitl(long double __x )  __attribute__((__const__)) ;
__inline extern int __signbitl(long double __x ) 
{ union __anonunion___u_35 __u ;

  {
  __u.__l = __x;
  return ((__u.__i[2] & 0x8000) != 0);
}
}
__inline extern  __attribute__((__nothrow__)) double __sgn(double __x ) ;
__inline extern  __attribute__((__nothrow__)) double __sgn(double __x ) ;
__inline extern double __sgn(double __x ) 
{ double tmp ;
  double tmp___0 ;

  {
  if (__x == 0.0) {
    tmp___0 = 0.0;
  } else {
    if (__x > 0.0) {
      tmp = 1.0;
    } else {
      tmp = - 1.0;
    }
    tmp___0 = tmp;
  }
  return (tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) float __sgnf(float __x ) ;
__inline extern  __attribute__((__nothrow__)) float __sgnf(float __x ) ;
__inline extern float __sgnf(float __x ) 
{ double tmp ;
  double tmp___0 ;

  {
  if ((double )__x == 0.0) {
    tmp___0 = 0.0;
  } else {
    if ((double )__x > 0.0) {
      tmp = 1.0;
    } else {
      tmp = - 1.0;
    }
    tmp___0 = tmp;
  }
  return ((float )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) long double __sgnl(long double __x ) ;
__inline extern  __attribute__((__nothrow__)) long double __sgnl(long double __x ) ;
__inline extern long double __sgnl(long double __x ) 
{ double tmp ;
  double tmp___0 ;

  {
  if (__x == (long double )0.0) {
    tmp___0 = 0.0;
  } else {
    if (__x > (long double )0.0) {
      tmp = 1.0;
    } else {
      tmp = - 1.0;
    }
    tmp___0 = tmp;
  }
  return ((long double )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) long double __atan2l(long double __y , long double __x ) ;
__inline extern long double __atan2l(long double __y , long double __x ) 
{ long double tmp ;

  {
  tmp = __builtin_atan2l(__y, __x);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) double fabs(double __x )  __attribute__((__const__)) ;
__inline extern double fabs(double __x ) 
{ double tmp ;

  {
  tmp = __builtin_fabs(__x);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) float fabsf(float __x )  __attribute__((__const__)) ;
__inline extern float fabsf(float __x ) 
{ float tmp ;

  {
  tmp = __builtin_fabsf(__x);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long double fabsl(long double __x )  __attribute__((__const__)) ;
__inline extern long double fabsl(long double __x ) 
{ long double tmp ;

  {
  tmp = __builtin_fabsl(__x);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long double __fabsl(long double __x )  __attribute__((__const__)) ;
__inline extern long double __fabsl(long double __x ) 
{ long double tmp ;

  {
  tmp = __builtin_fabsl(__x);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long double __sgn1l(long double __x ) ;
__inline extern  __attribute__((__nothrow__)) long double __sgn1l(long double __x ) ;
__inline extern long double __sgn1l(long double __x ) 
{ union __anonunion___n_36 __n ;

  {
  __n.__xld = __x;
  __n.__xi[2] = (__n.__xi[2] & 32768U) | 16383U;
  __n.__xi[1] = 0x80000000;
  __n.__xi[0] = 0U;
  return (__n.__xld);
}
}
__inline extern  __attribute__((__nothrow__)) double floor(double __x )  __attribute__((__const__)) ;
__inline extern double floor(double __x ) 
{ register long double __value ;
  register int __ignore ;
  unsigned short __cw ;
  unsigned short __cwtmp ;

  {
  __asm__  volatile   ("fnstcw %3\n\t"
                       "movzwl %3, %1\n\t"
                       "andl $0xf3ff, %1\n\t"
                       "orl $0x0400, %1\n\t"
                       "movw %w1, %2\n\t"
                       "fldcw %2\n\t"
                       "frndint\n\t"
                       "fldcw %3": "=t" (__value), "=&q" (__ignore), "=m" (__cwtmp), "=m" (__cw): "0" (__x));
  return ((double )__value);
}
}
__inline extern  __attribute__((__nothrow__)) float floorf(float __x )  __attribute__((__const__)) ;
__inline extern float floorf(float __x ) 
{ register long double __value ;
  register int __ignore ;
  unsigned short __cw ;
  unsigned short __cwtmp ;

  {
  __asm__  volatile   ("fnstcw %3\n\t"
                       "movzwl %3, %1\n\t"
                       "andl $0xf3ff, %1\n\t"
                       "orl $0x0400, %1\n\t"
                       "movw %w1, %2\n\t"
                       "fldcw %2\n\t"
                       "frndint\n\t"
                       "fldcw %3": "=t" (__value), "=&q" (__ignore), "=m" (__cwtmp), "=m" (__cw): "0" (__x));
  return ((float )__value);
}
}
__inline extern  __attribute__((__nothrow__)) long double floorl(long double __x )  __attribute__((__const__)) ;
__inline extern long double floorl(long double __x ) 
{ register long double __value ;
  register int __ignore ;
  unsigned short __cw ;
  unsigned short __cwtmp ;

  {
  __asm__  volatile   ("fnstcw %3\n\t"
                       "movzwl %3, %1\n\t"
                       "andl $0xf3ff, %1\n\t"
                       "orl $0x0400, %1\n\t"
                       "movw %w1, %2\n\t"
                       "fldcw %2\n\t"
                       "frndint\n\t"
                       "fldcw %3": "=t" (__value), "=&q" (__ignore), "=m" (__cwtmp), "=m" (__cw): "0" (__x));
  return (__value);
}
}
__inline extern  __attribute__((__nothrow__)) double ceil(double __x )  __attribute__((__const__)) ;
__inline extern double ceil(double __x ) 
{ register long double __value ;
  register int __ignore ;
  unsigned short __cw ;
  unsigned short __cwtmp ;

  {
  __asm__  volatile   ("fnstcw %3\n\t"
                       "movzwl %3, %1\n\t"
                       "andl $0xf3ff, %1\n\t"
                       "orl $0x0800, %1\n\t"
                       "movw %w1, %2\n\t"
                       "fldcw %2\n\t"
                       "frndint\n\t"
                       "fldcw %3": "=t" (__value), "=&q" (__ignore), "=m" (__cwtmp), "=m" (__cw): "0" (__x));
  return ((double )__value);
}
}
__inline extern  __attribute__((__nothrow__)) float ceilf(float __x )  __attribute__((__const__)) ;
__inline extern float ceilf(float __x ) 
{ register long double __value ;
  register int __ignore ;
  unsigned short __cw ;
  unsigned short __cwtmp ;

  {
  __asm__  volatile   ("fnstcw %3\n\t"
                       "movzwl %3, %1\n\t"
                       "andl $0xf3ff, %1\n\t"
                       "orl $0x0800, %1\n\t"
                       "movw %w1, %2\n\t"
                       "fldcw %2\n\t"
                       "frndint\n\t"
                       "fldcw %3": "=t" (__value), "=&q" (__ignore), "=m" (__cwtmp), "=m" (__cw): "0" (__x));
  return ((float )__value);
}
}
__inline extern  __attribute__((__nothrow__)) long double ceill(long double __x )  __attribute__((__const__)) ;
__inline extern long double ceill(long double __x ) 
{ register long double __value ;
  register int __ignore ;
  unsigned short __cw ;
  unsigned short __cwtmp ;

  {
  __asm__  volatile   ("fnstcw %3\n\t"
                       "movzwl %3, %1\n\t"
                       "andl $0xf3ff, %1\n\t"
                       "orl $0x0800, %1\n\t"
                       "movw %w1, %2\n\t"
                       "fldcw %2\n\t"
                       "frndint\n\t"
                       "fldcw %3": "=t" (__value), "=&q" (__ignore), "=m" (__cwtmp), "=m" (__cw): "0" (__x));
  return (__value);
}
}
__inline extern  __attribute__((__nothrow__)) long lrintf(float __x ) ;
__inline extern long lrintf(float __x ) 
{ long __lrintres ;

  {
  __asm__  volatile   ("fistpl %0": "=m" (__lrintres): "t" (__x): "st");
  return (__lrintres);
}
}
__inline extern  __attribute__((__nothrow__)) long lrint(double __x ) ;
__inline extern long lrint(double __x ) 
{ long __lrintres ;

  {
  __asm__  volatile   ("fistpl %0": "=m" (__lrintres): "t" (__x): "st");
  return (__lrintres);
}
}
__inline extern  __attribute__((__nothrow__)) long lrintl(long double __x ) ;
__inline extern long lrintl(long double __x ) 
{ long __lrintres ;

  {
  __asm__  volatile   ("fistpl %0": "=m" (__lrintres): "t" (__x): "st");
  return (__lrintres);
}
}
__inline extern  __attribute__((__nothrow__)) long long llrintf(float __x ) ;
__inline extern long long llrintf(float __x ) 
{ long long __llrintres ;

  {
  __asm__  volatile   ("fistpll %0": "=m" (__llrintres): "t" (__x): "st");
  return (__llrintres);
}
}
__inline extern  __attribute__((__nothrow__)) long long llrint(double __x ) ;
__inline extern long long llrint(double __x ) 
{ long long __llrintres ;

  {
  __asm__  volatile   ("fistpll %0": "=m" (__llrintres): "t" (__x): "st");
  return (__llrintres);
}
}
__inline extern  __attribute__((__nothrow__)) long long llrintl(long double __x ) ;
__inline extern long long llrintl(long double __x ) 
{ long long __llrintres ;

  {
  __asm__  volatile   ("fistpll %0": "=m" (__llrintres): "t" (__x): "st");
  return (__llrintres);
}
}
__inline extern  __attribute__((__nothrow__)) int __finite(double __x )  __attribute__((__const__)) ;
__inline extern int __finite(double __x ) 
{ union __anonunion_37 __constr_expr_0 ;

  {
  __constr_expr_0.__d = __x;
  return ((int )((((unsigned int )__constr_expr_0.__i[1] | 0x800fffffu) + 1U) >> 31));
}
}
extern  __attribute__((__nothrow__)) int gettimeofday(struct timeval * __restrict  __tv , __timezone_ptr_t __tz )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int settimeofday(struct timeval  const  *__tv , struct timezone  const  *__tz )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int adjtime(struct timeval  const  *__delta , struct timeval *__olddelta ) ;
extern  __attribute__((__nothrow__)) int getitimer(__itimer_which_t __which , struct itimerval *__value ) ;
extern  __attribute__((__nothrow__)) int setitimer(__itimer_which_t __which , struct itimerval  const  * __restrict  __new , struct itimerval * __restrict  __old ) ;
extern  __attribute__((__nothrow__)) int utimes(char const   *__file , struct timeval  const  *__tvp )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int lutimes(char const   *__file , struct timeval  const  *__tvp )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int futimes(int __fd , struct timeval  const  *__tvp ) ;
extern  __attribute__((__nothrow__)) int futimesat(int __fd , char const   *__file , struct timeval  const  *__tvp ) ;
extern  __attribute__((__nothrow__)) clock_t clock(void) ;
extern  __attribute__((__nothrow__)) time_t time(time_t *__timer ) ;
extern  __attribute__((__nothrow__)) double difftime(time_t __time1 , time_t __time0 )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) time_t mktime(struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) size_t strftime(char * __restrict  __s , size_t __maxsize , char const   * __restrict  __format , struct tm  const  * __restrict  __tp ) ;
extern  __attribute__((__nothrow__)) char *strptime(char const   * __restrict  __s , char const   * __restrict  __fmt , struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) size_t strftime_l(char * __restrict  __s , size_t __maxsize , char const   * __restrict  __format , struct tm  const  * __restrict  __tp , __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) char *strptime_l(char const   * __restrict  __s , char const   * __restrict  __fmt , struct tm *__tp , __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) struct tm *gmtime(time_t const   *__timer ) ;
extern  __attribute__((__nothrow__)) struct tm *localtime(time_t const   *__timer ) ;
extern  __attribute__((__nothrow__)) struct tm *gmtime_r(time_t const   * __restrict  __timer , struct tm * __restrict  __tp ) ;
extern  __attribute__((__nothrow__)) struct tm *localtime_r(time_t const   * __restrict  __timer , struct tm * __restrict  __tp ) ;
extern  __attribute__((__nothrow__)) char *asctime(struct tm  const  *__tp ) ;
extern  __attribute__((__nothrow__)) char *ctime(time_t const   *__timer ) ;
extern  __attribute__((__nothrow__)) char *asctime_r(struct tm  const  * __restrict  __tp , char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) char *ctime_r(time_t const   * __restrict  __timer , char * __restrict  __buf ) ;
extern char *__tzname[2] ;
extern int __daylight ;
extern long __timezone ;
extern char *tzname[2] ;
extern  __attribute__((__nothrow__)) void tzset(void) ;
extern int daylight ;
extern long timezone ;
extern  __attribute__((__nothrow__)) int stime(time_t const   *__when ) ;
extern  __attribute__((__nothrow__)) time_t timegm(struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) time_t timelocal(struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) int dysize(int __year )  __attribute__((__const__)) ;
extern int nanosleep(struct timespec  const  *__requested_time , struct timespec *__remaining ) ;
extern  __attribute__((__nothrow__)) int clock_getres(clockid_t __clock_id , struct timespec *__res ) ;
extern  __attribute__((__nothrow__)) int clock_gettime(clockid_t __clock_id , struct timespec *__tp ) ;
extern  __attribute__((__nothrow__)) int clock_settime(clockid_t __clock_id , struct timespec  const  *__tp ) ;
extern int clock_nanosleep(clockid_t __clock_id , int __flags , struct timespec  const  *__req , struct timespec *__rem ) ;
extern  __attribute__((__nothrow__)) int clock_getcpuclockid(pid_t __pid , clockid_t *__clock_id ) ;
extern  __attribute__((__nothrow__)) int timer_create(clockid_t __clock_id , struct sigevent * __restrict  __evp , timer_t * __restrict  __timerid ) ;
extern  __attribute__((__nothrow__)) int timer_delete(timer_t __timerid ) ;
extern  __attribute__((__nothrow__)) int timer_settime(timer_t __timerid , int __flags , struct itimerspec  const  * __restrict  __value , struct itimerspec * __restrict  __ovalue ) ;
extern  __attribute__((__nothrow__)) int timer_gettime(timer_t __timerid , struct itimerspec *__value ) ;
extern  __attribute__((__nothrow__)) int timer_getoverrun(timer_t __timerid ) ;
extern int getdate_err ;
extern struct tm *getdate(char const   *__string ) ;
extern int getdate_r(char const   * __restrict  __string , struct tm * __restrict  __resbufp ) ;
__inline extern  __attribute__((__nothrow__)) int stat(char const   * __restrict  __path , struct stat * __restrict  __statbuf )  __asm__("stat64") __attribute__((__nonnull__(1,2))) ;
__inline extern  __attribute__((__nothrow__)) int fstat(int __fd , struct stat *__statbuf )  __asm__("fstat64") __attribute__((__nonnull__(2))) ;
__inline extern  __attribute__((__nothrow__)) int stat64(char const   * __restrict  __path , struct stat64 * __restrict  __statbuf )  __attribute__((__nonnull__(1,2))) ;
__inline extern  __attribute__((__nothrow__)) int fstat64(int __fd , struct stat64 *__statbuf )  __attribute__((__nonnull__(2))) ;
__inline extern  __attribute__((__nothrow__)) int fstatat(int __fd , char const   * __restrict  __filename , struct stat * __restrict  __statbuf , int __flag )  __asm__("fstatat64") __attribute__((__nonnull__(2,3))) ;
__inline extern  __attribute__((__nothrow__)) int fstatat64(int __fd , char const   * __restrict  __filename , struct stat64 * __restrict  __statbuf , int __flag )  __attribute__((__nonnull__(2,3))) ;
__inline extern  __attribute__((__nothrow__)) int lstat(char const   * __restrict  __path , struct stat * __restrict  __statbuf )  __asm__("lstat64") __attribute__((__nonnull__(1,2))) ;
__inline extern  __attribute__((__nothrow__)) int lstat64(char const   * __restrict  __path , struct stat64 * __restrict  __statbuf )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int chmod(char const   *__file , __mode_t __mode )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int lchmod(char const   *__file , __mode_t __mode )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int fchmod(int __fd , __mode_t __mode ) ;
extern  __attribute__((__nothrow__)) int fchmodat(int __fd , char const   *__file , __mode_t __mode , int __flag )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) __mode_t umask(__mode_t __mask ) ;
extern  __attribute__((__nothrow__)) __mode_t getumask(void) ;
extern  __attribute__((__nothrow__)) int mkdir(char const   *__path , __mode_t __mode )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int mkdirat(int __fd , char const   *__path , __mode_t __mode )  __attribute__((__nonnull__(2))) ;
__inline extern  __attribute__((__nothrow__)) int mknod(char const   *__path , __mode_t __mode , __dev_t __dev )  __attribute__((__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) int mknodat(int __fd , char const   *__path , __mode_t __mode , __dev_t __dev )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int mkfifo(char const   *__path , __mode_t __mode )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int mkfifoat(int __fd , char const   *__path , __mode_t __mode )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int utimensat(int __fd , char const   *__path , struct timespec  const  *__times , int __flags )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int futimens(int __fd , struct timespec  const  *__times ) ;
extern  __attribute__((__nothrow__)) int __fxstat(int __ver , int __fildes , struct stat *__stat_buf )  __asm__("__fxstat64") __attribute__((__nonnull__(3))) ;
extern  __attribute__((__nothrow__)) int __xstat(int __ver , char const   *__filename , struct stat *__stat_buf )  __asm__("__xstat64") __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) int __lxstat(int __ver , char const   *__filename , struct stat *__stat_buf )  __asm__("__lxstat64") __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) int __fxstatat(int __ver , int __fildes , char const   *__filename , struct stat *__stat_buf , int __flag )  __asm__("__fxstatat64") __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) int __fxstat64(int __ver , int __fildes , struct stat64 *__stat_buf )  __attribute__((__nonnull__(3))) ;
extern  __attribute__((__nothrow__)) int __xstat64(int __ver , char const   *__filename , struct stat64 *__stat_buf )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) int __lxstat64(int __ver , char const   *__filename , struct stat64 *__stat_buf )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) int __fxstatat64(int __ver , int __fildes , char const   *__filename , struct stat64 *__stat_buf , int __flag )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) int __xmknod(int __ver , char const   *__path , __mode_t __mode , __dev_t *__dev )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) int __xmknodat(int __ver , int __fd , char const   *__path , __mode_t __mode , __dev_t *__dev )  __attribute__((__nonnull__(3,5))) ;
__inline extern  __attribute__((__nothrow__)) int stat(char const   * __restrict  __path , struct stat * __restrict  __statbuf )  __asm__("stat64") __attribute__((__nonnull__(1,2))) ;
__inline extern int stat(char const   * __restrict  __path , struct stat * __restrict  __statbuf ) 
{ int tmp ;

  {
  tmp = __xstat(3, (char const   *)__path, (struct stat *)__statbuf);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int lstat(char const   * __restrict  __path , struct stat * __restrict  __statbuf )  __asm__("lstat64") __attribute__((__nonnull__(1,2))) ;
__inline extern int lstat(char const   * __restrict  __path , struct stat * __restrict  __statbuf ) 
{ int tmp ;

  {
  tmp = __lxstat(3, (char const   *)__path, (struct stat *)__statbuf);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int fstat(int __fd , struct stat *__statbuf )  __asm__("fstat64") __attribute__((__nonnull__(2))) ;
__inline extern int fstat(int __fd , struct stat *__statbuf ) 
{ int tmp ;

  {
  tmp = __fxstat(3, __fd, __statbuf);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int fstatat(int __fd , char const   * __restrict  __filename , struct stat * __restrict  __statbuf , int __flag )  __asm__("fstatat64") __attribute__((__nonnull__(2,3))) ;
__inline extern int fstatat(int __fd , char const   * __restrict  __filename , struct stat * __restrict  __statbuf , int __flag ) 
{ int tmp ;

  {
  tmp = __fxstatat(3, __fd, (char const   *)__filename, (struct stat *)__statbuf, __flag);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int mknod(char const   *__path , __mode_t __mode , __dev_t __dev )  __attribute__((__nonnull__(1))) ;
__inline extern int mknod(char const   *__path , __mode_t __mode , __dev_t __dev ) 
{ int tmp ;

  {
  tmp = __xmknod(1, __path, __mode, & __dev);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int mknodat(int __fd , char const   *__path , __mode_t __mode , __dev_t __dev )  __attribute__((__nonnull__(2))) ;
__inline extern int mknodat(int __fd , char const   *__path , __mode_t __mode , __dev_t __dev ) 
{ int tmp ;

  {
  tmp = __xmknodat(1, __fd, __path, __mode, & __dev);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int stat64(char const   * __restrict  __path , struct stat64 * __restrict  __statbuf )  __attribute__((__nonnull__(1,2))) ;
__inline extern int stat64(char const   * __restrict  __path , struct stat64 * __restrict  __statbuf ) 
{ int tmp ;

  {
  tmp = __xstat64(3, (char const   *)__path, (struct stat64 *)__statbuf);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int lstat64(char const   * __restrict  __path , struct stat64 * __restrict  __statbuf )  __attribute__((__nonnull__(1,2))) ;
__inline extern int lstat64(char const   * __restrict  __path , struct stat64 * __restrict  __statbuf ) 
{ int tmp ;

  {
  tmp = __lxstat64(3, (char const   *)__path, (struct stat64 *)__statbuf);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int fstat64(int __fd , struct stat64 *__statbuf )  __attribute__((__nonnull__(2))) ;
__inline extern int fstat64(int __fd , struct stat64 *__statbuf ) 
{ int tmp ;

  {
  tmp = __fxstat64(3, __fd, __statbuf);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int fstatat64(int __fd , char const   * __restrict  __filename , struct stat64 * __restrict  __statbuf , int __flag )  __attribute__((__nonnull__(2,3))) ;
__inline extern int fstatat64(int __fd , char const   * __restrict  __filename , struct stat64 * __restrict  __statbuf , int __flag ) 
{ int tmp ;

  {
  tmp = __fxstatat64(3, __fd, (char const   *)__filename, (struct stat64 *)__statbuf, __flag);
  return (tmp);
}
}
extern void AnnotateRWLockCreate(char const   *file , int line , void const volatile   *lock ) ;
extern void AnnotateRWLockDestroy(char const   *file , int line , void const volatile   *lock ) ;
extern void AnnotateRWLockAcquired(char const   *file , int line , void const volatile   *lock , long is_w ) ;
extern void AnnotateRWLockReleased(char const   *file , int line , void const volatile   *lock , long is_w ) ;
extern void AnnotateBarrierInit(char const   *file , int line , void const volatile   *barrier , long count , long reinitialization_allowed ) ;
extern void AnnotateBarrierWaitBefore(char const   *file , int line , void const volatile   *barrier ) ;
extern void AnnotateBarrierWaitAfter(char const   *file , int line , void const volatile   *barrier ) ;
extern void AnnotateBarrierDestroy(char const   *file , int line , void const volatile   *barrier ) ;
extern void AnnotateCondVarWait(char const   *file , int line , void const volatile   *cv , void const volatile   *lock ) ;
extern void AnnotateCondVarSignal(char const   *file , int line , void const volatile   *cv ) ;
extern void AnnotateCondVarSignalAll(char const   *file , int line , void const volatile   *cv ) ;
extern void AnnotatePublishMemoryRange(char const   *file , int line , void const volatile   *address , long size ) ;
extern void AnnotateUnpublishMemoryRange(char const   *file , int line , void const volatile   *address , long size ) ;
extern void AnnotatePCQCreate(char const   *file , int line , void const volatile   *pcq ) ;
extern void AnnotatePCQDestroy(char const   *file , int line , void const volatile   *pcq ) ;
extern void AnnotatePCQPut(char const   *file , int line , void const volatile   *pcq ) ;
extern void AnnotatePCQGet(char const   *file , int line , void const volatile   *pcq ) ;
extern void AnnotateNewMemory(char const   *file , int line , void const volatile   *address , long size ) ;
extern void AnnotateExpectRace(char const   *file , int line , void const volatile   *address , char const   *description ) ;
extern void AnnotateBenignRace(char const   *file , int line , void const volatile   *address , char const   *description ) ;
extern void AnnotateBenignRaceSized(char const   *file , int line , void const volatile   *address , long size , char const   *description ) ;
extern void AnnotateMutexIsUsedAsCondVar(char const   *file , int line , void const volatile   *mu ) ;
extern void AnnotateTraceMemory(char const   *file , int line , void const volatile   *arg ) ;
extern void AnnotateThreadName(char const   *file , int line , char const   *name ) ;
extern void AnnotateIgnoreReadsBegin(char const   *file , int line ) ;
extern void AnnotateIgnoreReadsEnd(char const   *file , int line ) ;
extern void AnnotateIgnoreWritesBegin(char const   *file , int line ) ;
extern void AnnotateIgnoreWritesEnd(char const   *file , int line ) ;
extern void AnnotateEnableRaceDetection(char const   *file , int line , int enable ) ;
extern void AnnotateNoOp(char const   *file , int line , void const volatile   *arg ) ;
extern void AnnotateFlushState(char const   *file , int line ) ;
extern int RunningOnValgrind(void) ;
__inline static void _Py_atomic_signal_fence(_Py_memory_order order ) 
{ 

  {
  if ((unsigned int )order != 0U) {
    __asm__  volatile   ("": : : "memory");
  } else {

  }
  return;
}
}
__inline static void _Py_atomic_thread_fence(_Py_memory_order order ) 
{ 

  {
  if ((unsigned int )order != 0U) {
    __asm__  volatile   ("mfence": : : "memory");
  } else {

  }
  return;
}
}
__inline static void _Py_ANNOTATE_MEMORY_ORDER(void const volatile   *address , _Py_memory_order order ) 
{ 

  {
  switch ((int )order) {
  case 2: 
  case 3: 
  case 4: ;
  break;
  default: ;
  break;
  }
  switch ((int )order) {
  case 1: 
  case 3: 
  case 4: ;
  break;
  default: ;
  break;
  }
  return;
}
}
extern double _Py_force_double(double  ) ;
extern unsigned short _Py_get_387controlword(void) ;
extern void _Py_set_387controlword(unsigned short  ) ;
extern void _PyTime_gettimeofday(_PyTime_timeval *tp ) ;
extern void _PyTime_Init(void) ;
extern void *PyMem_Malloc(size_t  ) ;
extern void *PyMem_Realloc(void * , size_t  ) ;
extern void PyMem_Free(void * ) ;
extern PyObject *PyType_FromSpec(PyType_Spec * ) ;
extern int PyType_IsSubtype(PyTypeObject * , PyTypeObject * ) ;
extern PyTypeObject PyType_Type ;
extern PyTypeObject PyBaseObject_Type ;
extern PyTypeObject PySuper_Type ;
extern long PyType_GetFlags(PyTypeObject * ) ;
extern int PyType_Ready(PyTypeObject * ) ;
extern PyObject *PyType_GenericAlloc(PyTypeObject * , Py_ssize_t  ) ;
extern PyObject *PyType_GenericNew(PyTypeObject * , PyObject * , PyObject * ) ;
extern PyObject *_PyType_Lookup(PyTypeObject * , PyObject * ) ;
extern PyObject *_PyObject_LookupSpecial(PyObject * , char * , PyObject ** ) ;
extern unsigned int PyType_ClearCache(void) ;
extern void PyType_Modified(PyTypeObject * ) ;
extern int PyObject_Print(PyObject * , FILE * , int  ) ;
extern void _Py_BreakPoint(void) ;
extern void _PyObject_Dump(PyObject * ) ;
extern PyObject *PyObject_Repr(PyObject * ) ;
extern PyObject *PyObject_Str(PyObject * ) ;
extern PyObject *PyObject_ASCII(PyObject * ) ;
extern PyObject *PyObject_Bytes(PyObject * ) ;
extern PyObject *PyObject_RichCompare(PyObject * , PyObject * , int  ) ;
extern int PyObject_RichCompareBool(PyObject * , PyObject * , int  ) ;
extern PyObject *PyObject_GetAttrString(PyObject * , char const   * ) ;
extern int PyObject_SetAttrString(PyObject * , char const   * , PyObject * ) ;
extern int PyObject_HasAttrString(PyObject * , char const   * ) ;
extern PyObject *PyObject_GetAttr(PyObject * , PyObject * ) ;
extern int PyObject_SetAttr(PyObject * , PyObject * , PyObject * ) ;
extern int PyObject_HasAttr(PyObject * , PyObject * ) ;
extern PyObject **_PyObject_GetDictPtr(PyObject * ) ;
extern PyObject *PyObject_SelfIter(PyObject * ) ;
extern PyObject *_PyObject_NextNotImplemented(PyObject * ) ;
extern PyObject *PyObject_GenericGetAttr(PyObject * , PyObject * ) ;
extern int PyObject_GenericSetAttr(PyObject * , PyObject * , PyObject * ) ;
extern Py_hash_t PyObject_Hash(PyObject * ) ;
extern Py_hash_t PyObject_HashNotImplemented(PyObject * ) ;
extern int PyObject_IsTrue(PyObject * ) ;
extern int PyObject_Not(PyObject * ) ;
extern int PyCallable_Check(PyObject * ) ;
extern void PyObject_ClearWeakRefs(PyObject * ) ;
extern PyObject *_PyObject_GenericGetAttrWithDict(PyObject * , PyObject * , PyObject * ) ;
extern int _PyObject_GenericSetAttrWithDict(PyObject * , PyObject * , PyObject * , PyObject * ) ;
extern PyObject *PyObject_Dir(PyObject * ) ;
extern int Py_ReprEnter(PyObject * ) ;
extern void Py_ReprLeave(PyObject * ) ;
extern Py_hash_t _Py_HashDouble(double  ) ;
extern Py_hash_t _Py_HashPointer(void * ) ;
extern void Py_IncRef(PyObject * ) ;
extern void Py_DecRef(PyObject * ) ;
extern PyObject _Py_NoneStruct ;
extern PyObject _Py_NotImplementedStruct ;
extern int _Py_SwappedOp[] ;
extern void _PyTrash_deposit_object(PyObject * ) ;
extern void _PyTrash_destroy_chain(void) ;
extern int _PyTrash_delete_nesting ;
extern PyObject *_PyTrash_delete_later ;
extern void *PyObject_Malloc(size_t  ) ;
extern void *PyObject_Realloc(void * , size_t  ) ;
extern void PyObject_Free(void * ) ;
extern PyObject *PyObject_Init(PyObject * , PyTypeObject * ) ;
extern PyVarObject *PyObject_InitVar(PyVarObject * , PyTypeObject * , Py_ssize_t  ) ;
extern PyObject *_PyObject_New(PyTypeObject * ) ;
extern PyVarObject *_PyObject_NewVar(PyTypeObject * , Py_ssize_t  ) ;
extern Py_ssize_t PyGC_Collect(void) ;
extern PyVarObject *_PyObject_GC_Resize(PyVarObject * , Py_ssize_t  ) ;
extern PyGC_Head *_PyGC_generation0 ;
extern PyObject *_PyObject_GC_Malloc(size_t  ) ;
extern PyObject *_PyObject_GC_New(PyTypeObject * ) ;
extern PyVarObject *_PyObject_GC_NewVar(PyTypeObject * , Py_ssize_t  ) ;
extern void PyObject_GC_Track(void * ) ;
extern void PyObject_GC_UnTrack(void * ) ;
extern void PyObject_GC_Del(void * ) ;
extern int Py_DebugFlag ;
extern int Py_VerboseFlag ;
extern int Py_QuietFlag ;
extern int Py_InteractiveFlag ;
extern int Py_InspectFlag ;
extern int Py_OptimizeFlag ;
extern int Py_NoSiteFlag ;
extern int Py_BytesWarningFlag ;
extern int Py_UseClassExceptionsFlag ;
extern int Py_FrozenFlag ;
extern int Py_IgnoreEnvironmentFlag ;
extern int Py_DontWriteBytecodeFlag ;
extern int Py_NoUserSiteDirectory ;
extern int Py_UnbufferedStdioFlag ;
extern PyTypeObject PyByteArray_Type ;
extern PyTypeObject PyByteArrayIter_Type ;
extern PyObject *PyByteArray_FromObject(PyObject * ) ;
extern PyObject *PyByteArray_Concat(PyObject * , PyObject * ) ;
extern PyObject *PyByteArray_FromStringAndSize(char const   * , Py_ssize_t  ) ;
extern Py_ssize_t PyByteArray_Size(PyObject * ) ;
extern char *PyByteArray_AsString(PyObject * ) ;
extern int PyByteArray_Resize(PyObject * , Py_ssize_t  ) ;
extern char _PyByteArray_empty_string[] ;
extern PyTypeObject PyBytes_Type ;
extern PyTypeObject PyBytesIter_Type ;
extern PyObject *PyBytes_FromStringAndSize(char const   * , Py_ssize_t  ) ;
extern PyObject *PyBytes_FromString(char const   * ) ;
extern PyObject *PyBytes_FromObject(PyObject * ) ;
extern PyObject *( /* format attribute */  PyBytes_FromFormatV)(char const   * , va_list  ) ;
extern PyObject *( /* format attribute */  PyBytes_FromFormat)(char const   *  , ...) ;
extern Py_ssize_t PyBytes_Size(PyObject * ) ;
extern char *PyBytes_AsString(PyObject * ) ;
extern PyObject *PyBytes_Repr(PyObject * , int  ) ;
extern void PyBytes_Concat(PyObject ** , PyObject * ) ;
extern void PyBytes_ConcatAndDel(PyObject ** , PyObject * ) ;
extern int _PyBytes_Resize(PyObject ** , Py_ssize_t  ) ;
extern PyObject *_PyBytes_FormatLong(PyObject * , int  , int  , int  , char ** , int * ) ;
extern PyObject *PyBytes_DecodeEscape(char const   * , Py_ssize_t  , char const   * , Py_ssize_t  , char const   * ) ;
extern PyObject *_PyBytes_Join(PyObject *sep , PyObject *x ) ;
extern int PyBytes_AsStringAndSize(PyObject *obj , char **s , Py_ssize_t *len ) ;
extern Py_ssize_t _PyBytes_InsertThousandsGroupingLocale(char *buffer , Py_ssize_t n_buffer , char *digits , Py_ssize_t n_digits , Py_ssize_t min_width ) ;
extern Py_ssize_t _PyBytes_InsertThousandsGrouping(char *buffer , Py_ssize_t n_buffer , char *digits , Py_ssize_t n_digits , Py_ssize_t min_width , char const   *grouping , char const   *thousands_sep ) ;
extern  __attribute__((__nothrow__)) unsigned short const   **__ctype_b_loc(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) __int32_t const   **__ctype_tolower_loc(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) __int32_t const   **__ctype_toupper_loc(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int isalnum(int  ) ;
extern  __attribute__((__nothrow__)) int isalpha(int  ) ;
extern  __attribute__((__nothrow__)) int iscntrl(int  ) ;
extern  __attribute__((__nothrow__)) int isdigit(int  ) ;
extern  __attribute__((__nothrow__)) int islower(int  ) ;
extern  __attribute__((__nothrow__)) int isgraph(int  ) ;
extern  __attribute__((__nothrow__)) int isprint(int  ) ;
extern  __attribute__((__nothrow__)) int ispunct(int  ) ;
extern  __attribute__((__nothrow__)) int isspace(int  ) ;
extern  __attribute__((__nothrow__)) int isupper(int  ) ;
extern  __attribute__((__nothrow__)) int isxdigit(int  ) ;
__inline extern  __attribute__((__nothrow__)) int tolower(int __c ) ;
__inline extern  __attribute__((__nothrow__)) int toupper(int __c ) ;
extern  __attribute__((__nothrow__)) int isblank(int  ) ;
extern  __attribute__((__nothrow__)) int isctype(int __c , int __mask ) ;
extern  __attribute__((__nothrow__)) int isascii(int __c ) ;
extern  __attribute__((__nothrow__)) int toascii(int __c ) ;
extern  __attribute__((__nothrow__)) int _toupper(int  ) ;
extern  __attribute__((__nothrow__)) int _tolower(int  ) ;
__inline extern  __attribute__((__nothrow__)) int tolower(int __c ) ;
__inline extern int tolower(int __c ) 
{ __int32_t const   **tmp ;
  __int32_t tmp___0 ;

  {
  if (__c >= -128) {
    if (__c < 256) {
      tmp = __ctype_tolower_loc();
      tmp___0 = *(*tmp + __c);
    } else {
      tmp___0 = (int const   )__c;
    }
  } else {
    tmp___0 = (int const   )__c;
  }
  return ((int )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int toupper(int __c ) ;
__inline extern int toupper(int __c ) 
{ __int32_t const   **tmp ;
  __int32_t tmp___0 ;

  {
  if (__c >= -128) {
    if (__c < 256) {
      tmp = __ctype_toupper_loc();
      tmp___0 = *(*tmp + __c);
    } else {
      tmp___0 = (int const   )__c;
    }
  } else {
    tmp___0 = (int const   )__c;
  }
  return ((int )tmp___0);
}
}
extern  __attribute__((__nothrow__)) int isalnum_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isalpha_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int iscntrl_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isdigit_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int islower_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isgraph_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isprint_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int ispunct_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isspace_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isupper_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isxdigit_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isblank_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int __tolower_l(int __c , __locale_t __l ) ;
extern  __attribute__((__nothrow__)) int tolower_l(int __c , __locale_t __l ) ;
extern  __attribute__((__nothrow__)) int __toupper_l(int __c , __locale_t __l ) ;
extern  __attribute__((__nothrow__)) int toupper_l(int __c , __locale_t __l ) ;
extern  __attribute__((__nothrow__)) wchar_t *wcscpy(wchar_t * __restrict  __dest , wchar_t const   * __restrict  __src ) ;
extern  __attribute__((__nothrow__)) wchar_t *wcsncpy(wchar_t * __restrict  __dest , wchar_t const   * __restrict  __src , size_t __n ) ;
extern  __attribute__((__nothrow__)) wchar_t *wcscat(wchar_t * __restrict  __dest , wchar_t const   * __restrict  __src ) ;
extern  __attribute__((__nothrow__)) wchar_t *wcsncat(wchar_t * __restrict  __dest , wchar_t const   * __restrict  __src , size_t __n ) ;
extern  __attribute__((__nothrow__)) int wcscmp(wchar_t const   *__s1 , wchar_t const   *__s2 )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int wcsncmp(wchar_t const   *__s1 , wchar_t const   *__s2 , size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int wcscasecmp(wchar_t const   *__s1 , wchar_t const   *__s2 ) ;
extern  __attribute__((__nothrow__)) int wcsncasecmp(wchar_t const   *__s1 , wchar_t const   *__s2 , size_t __n ) ;
extern  __attribute__((__nothrow__)) int wcscasecmp_l(wchar_t const   *__s1 , wchar_t const   *__s2 , __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) int wcsncasecmp_l(wchar_t const   *__s1 , wchar_t const   *__s2 , size_t __n , __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) int wcscoll(wchar_t const   *__s1 , wchar_t const   *__s2 ) ;
extern  __attribute__((__nothrow__)) size_t wcsxfrm(wchar_t * __restrict  __s1 , wchar_t const   * __restrict  __s2 , size_t __n ) ;
extern  __attribute__((__nothrow__)) int wcscoll_l(wchar_t const   *__s1 , wchar_t const   *__s2 , __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) size_t wcsxfrm_l(wchar_t *__s1 , wchar_t const   *__s2 , size_t __n , __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) wchar_t *wcsdup(wchar_t const   *__s )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wcschr(wchar_t const   *__wcs , wchar_t __wc )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wcsrchr(wchar_t const   *__wcs , wchar_t __wc )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wcschrnul(wchar_t const   *__s , wchar_t __wc )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) size_t wcscspn(wchar_t const   *__wcs , wchar_t const   *__reject )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) size_t wcsspn(wchar_t const   *__wcs , wchar_t const   *__accept )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wcspbrk(wchar_t const   *__wcs , wchar_t const   *__accept )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wcsstr(wchar_t const   *__haystack , wchar_t const   *__needle )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wcstok(wchar_t * __restrict  __s , wchar_t const   * __restrict  __delim , wchar_t ** __restrict  __ptr ) ;
extern  __attribute__((__nothrow__)) size_t wcslen(wchar_t const   *__s )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wcswcs(wchar_t const   *__haystack , wchar_t const   *__needle )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) size_t wcsnlen(wchar_t const   *__s , size_t __maxlen )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wmemchr(wchar_t const   *__s , wchar_t __c , size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int wmemcmp(wchar_t const   * __restrict  __s1 , wchar_t const   * __restrict  __s2 , size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wmemcpy(wchar_t * __restrict  __s1 , wchar_t const   * __restrict  __s2 , size_t __n ) ;
extern  __attribute__((__nothrow__)) wchar_t *wmemmove(wchar_t *__s1 , wchar_t const   *__s2 , size_t __n ) ;
extern  __attribute__((__nothrow__)) wchar_t *wmemset(wchar_t *__s , wchar_t __c , size_t __n ) ;
extern  __attribute__((__nothrow__)) wchar_t *wmempcpy(wchar_t * __restrict  __s1 , wchar_t const   * __restrict  __s2 , size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wint_t btowc(int __c ) ;
__inline extern  __attribute__((__nothrow__)) int wctob(wint_t __wc ) ;
extern  __attribute__((__nothrow__)) int mbsinit(mbstate_t const   *__ps )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) size_t mbrtowc(wchar_t * __restrict  __pwc , char const   * __restrict  __s , size_t __n , mbstate_t *__p ) ;
extern  __attribute__((__nothrow__)) size_t wcrtomb(char * __restrict  __s , wchar_t __wc , mbstate_t * __restrict  __ps ) ;
extern  __attribute__((__nothrow__)) size_t __mbrlen(char const   * __restrict  __s , size_t __n , mbstate_t * __restrict  __ps ) ;
__inline extern  __attribute__((__nothrow__)) size_t mbrlen(char const   * __restrict  __s , size_t __n , mbstate_t * __restrict  __ps ) ;
extern wint_t __btowc_alias(int __c )  __asm__("btowc")  ;
__inline extern  __attribute__((__nothrow__)) wint_t btowc(int __c ) ;
__inline extern wint_t btowc(int __c ) 
{ wint_t tmp ;

  {
  tmp = __btowc_alias(__c);
  return (tmp);
}
}
extern int __wctob_alias(wint_t __c )  __asm__("wctob")  ;
__inline extern  __attribute__((__nothrow__)) int wctob(wint_t __wc ) ;
__inline extern int wctob(wint_t __wc ) 
{ int tmp ;

  {
  tmp = __wctob_alias(__wc);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) size_t mbrlen(char const   * __restrict  __s , size_t __n , mbstate_t * __restrict  __ps ) ;
__inline extern size_t mbrlen(char const   * __restrict  __s , size_t __n , mbstate_t * __restrict  __ps ) 
{ size_t tmp ;
  size_t tmp___0 ;
  size_t tmp___1 ;

  {
  if ((unsigned int )__ps != (unsigned int )((void *)0)) {
    tmp = mbrtowc((wchar_t */* __restrict  */)((void *)0), __s, __n, (mbstate_t *)__ps);
    tmp___1 = tmp;
  } else {
    tmp___0 = __mbrlen(__s, __n, (mbstate_t */* __restrict  */)((void *)0));
    tmp___1 = tmp___0;
  }
  return (tmp___1);
}
}
extern  __attribute__((__nothrow__)) size_t mbsrtowcs(wchar_t * __restrict  __dst , char const   ** __restrict  __src , size_t __len , mbstate_t * __restrict  __ps ) ;
extern  __attribute__((__nothrow__)) size_t wcsrtombs(char * __restrict  __dst , wchar_t const   ** __restrict  __src , size_t __len , mbstate_t * __restrict  __ps ) ;
extern  __attribute__((__nothrow__)) size_t mbsnrtowcs(wchar_t * __restrict  __dst , char const   ** __restrict  __src , size_t __nmc , size_t __len , mbstate_t * __restrict  __ps ) ;
extern  __attribute__((__nothrow__)) size_t wcsnrtombs(char * __restrict  __dst , wchar_t const   ** __restrict  __src , size_t __nwc , size_t __len , mbstate_t * __restrict  __ps ) ;
extern  __attribute__((__nothrow__)) int wcwidth(wchar_t __c ) ;
extern  __attribute__((__nothrow__)) int wcswidth(wchar_t const   *__s , size_t __n ) ;
extern  __attribute__((__nothrow__)) double wcstod(wchar_t const   * __restrict  __nptr , wchar_t ** __restrict  __endptr ) ;
extern  __attribute__((__nothrow__)) float wcstof(wchar_t const   * __restrict  __nptr , wchar_t ** __restrict  __endptr ) ;
extern  __attribute__((__nothrow__)) long double wcstold(wchar_t const   * __restrict  __nptr , wchar_t ** __restrict  __endptr ) ;
extern  __attribute__((__nothrow__)) long wcstol(wchar_t const   * __restrict  __nptr , wchar_t ** __restrict  __endptr , int __base ) ;
extern  __attribute__((__nothrow__)) unsigned long wcstoul(wchar_t const   * __restrict  __nptr , wchar_t ** __restrict  __endptr , int __base ) ;
extern  __attribute__((__nothrow__)) long long wcstoll(wchar_t const   * __restrict  __nptr , wchar_t ** __restrict  __endptr , int __base ) ;
extern  __attribute__((__nothrow__)) unsigned long long wcstoull(wchar_t const   * __restrict  __nptr , wchar_t ** __restrict  __endptr , int __base ) ;
extern  __attribute__((__nothrow__)) long long wcstoq(wchar_t const   * __restrict  __nptr , wchar_t ** __restrict  __endptr , int __base ) ;
extern  __attribute__((__nothrow__)) unsigned long long wcstouq(wchar_t const   * __restrict  __nptr , wchar_t ** __restrict  __endptr , int __base ) ;
extern  __attribute__((__nothrow__)) long wcstol_l(wchar_t const   * __restrict  __nptr , wchar_t ** __restrict  __endptr , int __base , __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) unsigned long wcstoul_l(wchar_t const   * __restrict  __nptr , wchar_t ** __restrict  __endptr , int __base , __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) long long wcstoll_l(wchar_t const   * __restrict  __nptr , wchar_t ** __restrict  __endptr , int __base , __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) unsigned long long wcstoull_l(wchar_t const   * __restrict  __nptr , wchar_t ** __restrict  __endptr , int __base , __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) double wcstod_l(wchar_t const   * __restrict  __nptr , wchar_t ** __restrict  __endptr , __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) float wcstof_l(wchar_t const   * __restrict  __nptr , wchar_t ** __restrict  __endptr , __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) long double wcstold_l(wchar_t const   * __restrict  __nptr , wchar_t ** __restrict  __endptr , __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) wchar_t *wcpcpy(wchar_t * __restrict  __dest , wchar_t const   * __restrict  __src ) ;
extern  __attribute__((__nothrow__)) wchar_t *wcpncpy(wchar_t * __restrict  __dest , wchar_t const   * __restrict  __src , size_t __n ) ;
extern  __attribute__((__nothrow__)) __FILE *open_wmemstream(wchar_t **__bufloc , size_t *__sizeloc ) ;
extern  __attribute__((__nothrow__)) int fwide(__FILE *__fp , int __mode ) ;
extern int fwprintf(__FILE * __restrict  __stream , wchar_t const   * __restrict  __format  , ...) ;
extern int wprintf(wchar_t const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int swprintf(wchar_t * __restrict  __s , size_t __n , wchar_t const   * __restrict  __format  , ...) ;
extern int vfwprintf(__FILE * __restrict  __s , wchar_t const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern int vwprintf(wchar_t const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vswprintf(wchar_t * __restrict  __s , size_t __n , wchar_t const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern int fwscanf(__FILE * __restrict  __stream , wchar_t const   * __restrict  __format  , ...) ;
extern int wscanf(wchar_t const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int swscanf(wchar_t const   * __restrict  __s , wchar_t const   * __restrict  __format  , ...) ;
extern int vfwscanf(__FILE * __restrict  __s , wchar_t const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern int vwscanf(wchar_t const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vswscanf(wchar_t const   * __restrict  __s , wchar_t const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern wint_t fgetwc(__FILE *__stream ) ;
extern wint_t getwc(__FILE *__stream ) ;
extern wint_t getwchar(void) ;
extern wint_t fputwc(wchar_t __wc , __FILE *__stream ) ;
extern wint_t putwc(wchar_t __wc , __FILE *__stream ) ;
extern wint_t putwchar(wchar_t __wc ) ;
extern wchar_t *fgetws(wchar_t * __restrict  __ws , int __n , __FILE * __restrict  __stream ) ;
extern int fputws(wchar_t const   * __restrict  __ws , __FILE * __restrict  __stream ) ;
extern wint_t ungetwc(wint_t __wc , __FILE *__stream ) ;
extern wint_t getwc_unlocked(__FILE *__stream ) ;
extern wint_t getwchar_unlocked(void) ;
extern wint_t fgetwc_unlocked(__FILE *__stream ) ;
extern wint_t fputwc_unlocked(wchar_t __wc , __FILE *__stream ) ;
extern wint_t putwc_unlocked(wchar_t __wc , __FILE *__stream ) ;
extern wint_t putwchar_unlocked(wchar_t __wc ) ;
extern wchar_t *fgetws_unlocked(wchar_t * __restrict  __ws , int __n , __FILE * __restrict  __stream ) ;
extern int fputws_unlocked(wchar_t const   * __restrict  __ws , __FILE * __restrict  __stream ) ;
extern  __attribute__((__nothrow__)) size_t wcsftime(wchar_t * __restrict  __s , size_t __maxsize , wchar_t const   * __restrict  __format , struct tm  const  * __restrict  __tp ) ;
extern  __attribute__((__nothrow__)) size_t wcsftime_l(wchar_t * __restrict  __s , size_t __maxsize , wchar_t const   * __restrict  __format , struct tm  const  * __restrict  __tp , __locale_t __loc ) ;
extern PyTypeObject PyUnicode_Type ;
extern PyTypeObject PyUnicodeIter_Type ;
extern PyObject *PyUnicodeUCS2_FromUnicode(Py_UNICODE const   *u , Py_ssize_t size ) ;
extern PyObject *PyUnicodeUCS2_FromStringAndSize(char const   *u , Py_ssize_t size ) ;
extern PyObject *PyUnicodeUCS2_FromString(char const   *u ) ;
extern Py_UNICODE *PyUnicodeUCS2_AsUnicode(PyObject *unicode ) ;
extern Py_ssize_t PyUnicodeUCS2_GetSize(PyObject *unicode ) ;
extern Py_UNICODE PyUnicodeUCS2_GetMax(void) ;
extern int PyUnicodeUCS2_Resize(PyObject **unicode , Py_ssize_t length ) ;
extern PyObject *PyUnicodeUCS2_FromEncodedObject(PyObject *obj , char const   *encoding , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_FromObject(PyObject *obj ) ;
extern PyObject *PyUnicodeUCS2_FromFormatV(char const   *format , va_list vargs ) ;
extern PyObject *PyUnicodeUCS2_FromFormat(char const   *format  , ...) ;
extern PyObject *_PyUnicode_FormatAdvanced(PyObject *obj , Py_UNICODE *format_spec , Py_ssize_t format_spec_len ) ;
extern void PyUnicode_InternInPlace(PyObject ** ) ;
extern void PyUnicode_InternImmortal(PyObject ** ) ;
extern PyObject *PyUnicode_InternFromString(char const   *u ) ;
extern void _Py_ReleaseInternedUnicodeStrings(void) ;
extern PyObject *PyUnicodeUCS2_FromWideChar(wchar_t const   *w , Py_ssize_t size ) ;
extern Py_ssize_t PyUnicodeUCS2_AsWideChar(PyObject *unicode , wchar_t *w , Py_ssize_t size ) ;
extern wchar_t *PyUnicodeUCS2_AsWideCharString(PyObject *unicode , Py_ssize_t *size ) ;
extern PyObject *PyUnicodeUCS2_FromOrdinal(int ordinal ) ;
extern int PyUnicodeUCS2_ClearFreelist(void) ;
extern PyObject *_PyUnicodeUCS2_AsDefaultEncodedString(PyObject *unicode ) ;
extern char *_PyUnicode_AsStringAndSize(PyObject *unicode , Py_ssize_t *size ) ;
extern char *_PyUnicode_AsString(PyObject *unicode ) ;
extern char const   *PyUnicodeUCS2_GetDefaultEncoding(void) ;
extern PyObject *PyUnicodeUCS2_Decode(char const   *s , Py_ssize_t size , char const   *encoding , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsDecodedObject(PyObject *unicode , char const   *encoding , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsDecodedUnicode(PyObject *unicode , char const   *encoding , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_Encode(Py_UNICODE const   *s , Py_ssize_t size , char const   *encoding , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsEncodedObject(PyObject *unicode , char const   *encoding , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsEncodedString(PyObject *unicode , char const   *encoding , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsEncodedUnicode(PyObject *unicode , char const   *encoding , char const   *errors ) ;
extern PyObject *PyUnicode_BuildEncodingMap(PyObject *string ) ;
extern PyObject *PyUnicode_DecodeUTF7(char const   *string , Py_ssize_t length , char const   *errors ) ;
extern PyObject *PyUnicode_DecodeUTF7Stateful(char const   *string , Py_ssize_t length , char const   *errors , Py_ssize_t *consumed ) ;
extern PyObject *PyUnicode_EncodeUTF7(Py_UNICODE const   *data , Py_ssize_t length , int base64SetO , int base64WhiteSpace , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_DecodeUTF8(char const   *string , Py_ssize_t length , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_DecodeUTF8Stateful(char const   *string , Py_ssize_t length , char const   *errors , Py_ssize_t *consumed ) ;
extern PyObject *PyUnicodeUCS2_AsUTF8String(PyObject *unicode ) ;
extern PyObject *PyUnicodeUCS2_EncodeUTF8(Py_UNICODE const   *data , Py_ssize_t length , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_DecodeUTF32(char const   *string , Py_ssize_t length , char const   *errors , int *byteorder ) ;
extern PyObject *PyUnicodeUCS2_DecodeUTF32Stateful(char const   *string , Py_ssize_t length , char const   *errors , int *byteorder , Py_ssize_t *consumed ) ;
extern PyObject *PyUnicodeUCS2_AsUTF32String(PyObject *unicode ) ;
extern PyObject *PyUnicodeUCS2_EncodeUTF32(Py_UNICODE const   *data , Py_ssize_t length , char const   *errors , int byteorder ) ;
extern PyObject *PyUnicodeUCS2_DecodeUTF16(char const   *string , Py_ssize_t length , char const   *errors , int *byteorder ) ;
extern PyObject *PyUnicodeUCS2_DecodeUTF16Stateful(char const   *string , Py_ssize_t length , char const   *errors , int *byteorder , Py_ssize_t *consumed ) ;
extern PyObject *PyUnicodeUCS2_AsUTF16String(PyObject *unicode ) ;
extern PyObject *PyUnicodeUCS2_EncodeUTF16(Py_UNICODE const   *data , Py_ssize_t length , char const   *errors , int byteorder ) ;
extern PyObject *PyUnicodeUCS2_DecodeUnicodeEscape(char const   *string , Py_ssize_t length , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsUnicodeEscapeString(PyObject *unicode ) ;
extern PyObject *PyUnicodeUCS2_EncodeUnicodeEscape(Py_UNICODE const   *data , Py_ssize_t length ) ;
extern PyObject *PyUnicodeUCS2_DecodeRawUnicodeEscape(char const   *string , Py_ssize_t length , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsRawUnicodeEscapeString(PyObject *unicode ) ;
extern PyObject *PyUnicodeUCS2_EncodeRawUnicodeEscape(Py_UNICODE const   *data , Py_ssize_t length ) ;
extern PyObject *_PyUnicode_DecodeUnicodeInternal(char const   *string , Py_ssize_t length , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_DecodeLatin1(char const   *string , Py_ssize_t length , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsLatin1String(PyObject *unicode ) ;
extern PyObject *PyUnicodeUCS2_EncodeLatin1(Py_UNICODE const   *data , Py_ssize_t length , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_DecodeASCII(char const   *string , Py_ssize_t length , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsASCIIString(PyObject *unicode ) ;
extern PyObject *PyUnicodeUCS2_EncodeASCII(Py_UNICODE const   *data , Py_ssize_t length , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_DecodeCharmap(char const   *string , Py_ssize_t length , PyObject *mapping , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsCharmapString(PyObject *unicode , PyObject *mapping ) ;
extern PyObject *PyUnicodeUCS2_EncodeCharmap(Py_UNICODE const   *data , Py_ssize_t length , PyObject *mapping , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_TranslateCharmap(Py_UNICODE const   *data , Py_ssize_t length , PyObject *table , char const   *errors ) ;
extern int PyUnicodeUCS2_EncodeDecimal(Py_UNICODE *s , Py_ssize_t length , char *output , char const   *errors ) ;
extern PyObject *PyUnicode_TransformDecimalToASCII(Py_UNICODE *s , Py_ssize_t length ) ;
extern int PyUnicodeUCS2_FSConverter(PyObject * , void * ) ;
extern int PyUnicodeUCS2_FSDecoder(PyObject * , void * ) ;
extern PyObject *PyUnicodeUCS2_DecodeFSDefault(char const   *s ) ;
extern PyObject *PyUnicodeUCS2_DecodeFSDefaultAndSize(char const   *s , Py_ssize_t size ) ;
extern PyObject *PyUnicode_EncodeFSDefault(PyObject *unicode ) ;
extern PyObject *PyUnicodeUCS2_Concat(PyObject *left , PyObject *right ) ;
extern void PyUnicodeUCS2_Append(PyObject **pleft , PyObject *right ) ;
extern void PyUnicodeUCS2_AppendAndDel(PyObject **pleft , PyObject *right ) ;
extern PyObject *PyUnicodeUCS2_Split(PyObject *s , PyObject *sep , Py_ssize_t maxsplit ) ;
extern PyObject *PyUnicodeUCS2_Splitlines(PyObject *s , int keepends ) ;
extern PyObject *PyUnicodeUCS2_Partition(PyObject *s , PyObject *sep ) ;
extern PyObject *PyUnicodeUCS2_RPartition(PyObject *s , PyObject *sep ) ;
extern PyObject *PyUnicodeUCS2_RSplit(PyObject *s , PyObject *sep , Py_ssize_t maxsplit ) ;
extern PyObject *PyUnicodeUCS2_Translate(PyObject *str , PyObject *table , char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_Join(PyObject *separator , PyObject *seq ) ;
extern Py_ssize_t PyUnicodeUCS2_Tailmatch(PyObject *str , PyObject *substr , Py_ssize_t start , Py_ssize_t end , int direction ) ;
extern Py_ssize_t PyUnicodeUCS2_Find(PyObject *str , PyObject *substr , Py_ssize_t start , Py_ssize_t end , int direction ) ;
extern Py_ssize_t PyUnicodeUCS2_Count(PyObject *str , PyObject *substr , Py_ssize_t start , Py_ssize_t end ) ;
extern PyObject *PyUnicodeUCS2_Replace(PyObject *str , PyObject *substr , PyObject *replstr , Py_ssize_t maxcount ) ;
extern int PyUnicodeUCS2_Compare(PyObject *left , PyObject *right ) ;
extern int PyUnicodeUCS2_CompareWithASCIIString(PyObject *left , char const   *right ) ;
extern PyObject *PyUnicodeUCS2_RichCompare(PyObject *left , PyObject *right , int op ) ;
extern PyObject *PyUnicodeUCS2_Format(PyObject *format , PyObject *args ) ;
extern int PyUnicodeUCS2_Contains(PyObject *container , PyObject *element ) ;
extern int PyUnicodeUCS2_IsIdentifier(PyObject *s ) ;
extern PyObject *_PyUnicode_XStrip(PyUnicodeObject *self , int striptype , PyObject *sepobj ) ;
extern Py_ssize_t _PyUnicode_InsertThousandsGroupingLocale(Py_UNICODE *buffer , Py_ssize_t n_buffer , Py_UNICODE *digits , Py_ssize_t n_digits , Py_ssize_t min_width ) ;
extern Py_ssize_t _PyUnicode_InsertThousandsGrouping(Py_UNICODE *buffer , Py_ssize_t n_buffer , Py_UNICODE *digits , Py_ssize_t n_digits , Py_ssize_t min_width , char const   *grouping , char const   *thousands_sep ) ;
extern unsigned char const   _Py_ascii_whitespace[] ;
extern int _PyUnicode_IsLowercase(Py_UCS4 ch ) ;
extern int _PyUnicode_IsUppercase(Py_UCS4 ch ) ;
extern int _PyUnicode_IsTitlecase(Py_UCS4 ch ) ;
extern int _PyUnicode_IsXidStart(Py_UCS4 ch ) ;
extern int _PyUnicode_IsXidContinue(Py_UCS4 ch ) ;
extern int _PyUnicode_IsWhitespace(Py_UCS4 ch ) ;
extern int _PyUnicode_IsLinebreak(Py_UCS4 ch ) ;
extern Py_UCS4 _PyUnicode_ToLowercase(Py_UCS4 ch ) ;
extern Py_UCS4 _PyUnicode_ToUppercase(Py_UCS4 ch ) ;
extern Py_UCS4 _PyUnicode_ToTitlecase(Py_UCS4 ch ) ;
extern int _PyUnicode_ToDecimalDigit(Py_UCS4 ch ) ;
extern int _PyUnicode_ToDigit(Py_UCS4 ch ) ;
extern double _PyUnicode_ToNumeric(Py_UCS4 ch ) ;
extern int _PyUnicode_IsDecimalDigit(Py_UCS4 ch ) ;
extern int _PyUnicode_IsDigit(Py_UCS4 ch ) ;
extern int _PyUnicode_IsNumeric(Py_UCS4 ch ) ;
extern int _PyUnicode_IsPrintable(Py_UCS4 ch ) ;
extern int _PyUnicode_IsAlpha(Py_UCS4 ch ) ;
extern size_t Py_UNICODE_strlen(Py_UNICODE const   *u ) ;
extern Py_UNICODE *Py_UNICODE_strcpy(Py_UNICODE *s1 , Py_UNICODE const   *s2 ) ;
extern Py_UNICODE *Py_UNICODE_strcat(Py_UNICODE *s1 , Py_UNICODE const   *s2 ) ;
extern Py_UNICODE *Py_UNICODE_strncpy(Py_UNICODE *s1 , Py_UNICODE const   *s2 , size_t n ) ;
extern int Py_UNICODE_strcmp(Py_UNICODE const   *s1 , Py_UNICODE const   *s2 ) ;
extern int Py_UNICODE_strncmp(Py_UNICODE const   *s1 , Py_UNICODE const   *s2 , size_t n ) ;
extern Py_UNICODE *Py_UNICODE_strchr(Py_UNICODE const   *s , Py_UNICODE c ) ;
extern Py_UNICODE *Py_UNICODE_strrchr(Py_UNICODE const   *s , Py_UNICODE c ) ;
extern Py_UNICODE *PyUnicode_AsUnicodeCopy(PyObject *unicode ) ;
extern PyTypeObject PyLong_Type ;
extern PyObject *PyLong_FromLong(long  ) ;
extern PyObject *PyLong_FromUnsignedLong(unsigned long  ) ;
extern PyObject *PyLong_FromSize_t(size_t  ) ;
extern PyObject *PyLong_FromSsize_t(Py_ssize_t  ) ;
extern PyObject *PyLong_FromDouble(double  ) ;
extern long PyLong_AsLong(PyObject * ) ;
extern long PyLong_AsLongAndOverflow(PyObject * , int * ) ;
extern Py_ssize_t PyLong_AsSsize_t(PyObject * ) ;
extern size_t PyLong_AsSize_t(PyObject * ) ;
extern unsigned long PyLong_AsUnsignedLong(PyObject * ) ;
extern unsigned long PyLong_AsUnsignedLongMask(PyObject * ) ;
extern PyObject *PyLong_GetInfo(void) ;
extern unsigned char _PyLong_DigitValue[256] ;
extern double _PyLong_Frexp(PyLongObject *a , Py_ssize_t *e ) ;
extern double PyLong_AsDouble(PyObject * ) ;
extern PyObject *PyLong_FromVoidPtr(void * ) ;
extern void *PyLong_AsVoidPtr(PyObject * ) ;
extern PyObject *PyLong_FromLongLong(long long  ) ;
extern PyObject *PyLong_FromUnsignedLongLong(unsigned long long  ) ;
extern long long PyLong_AsLongLong(PyObject * ) ;
extern unsigned long long PyLong_AsUnsignedLongLong(PyObject * ) ;
extern unsigned long long PyLong_AsUnsignedLongLongMask(PyObject * ) ;
extern long long PyLong_AsLongLongAndOverflow(PyObject * , int * ) ;
extern PyObject *PyLong_FromString(char * , char ** , int  ) ;
extern PyObject *PyLong_FromUnicode(Py_UNICODE * , Py_ssize_t  , int  ) ;
extern int _PyLong_Sign(PyObject *v ) ;
extern size_t _PyLong_NumBits(PyObject *v ) ;
extern PyObject *_PyLong_DivmodNear(PyObject * , PyObject * ) ;
extern PyObject *_PyLong_FromByteArray(unsigned char const   *bytes , size_t n , int little_endian , int is_signed ) ;
extern int _PyLong_AsByteArray(PyLongObject *v , unsigned char *bytes , size_t n , int little_endian , int is_signed ) ;
extern PyObject *_PyLong_Format(PyObject *aa , int base ) ;
extern PyObject *_PyLong_FormatAdvanced(PyObject *obj , Py_UNICODE *format_spec , Py_ssize_t format_spec_len ) ;
extern unsigned long PyOS_strtoul(char * , char ** , int  ) ;
extern long PyOS_strtol(char * , char ** , int  ) ;
extern PyLongObject *_PyLong_New(Py_ssize_t  ) ;
extern PyObject *_PyLong_Copy(PyLongObject *src ) ;
extern PyTypeObject PyBool_Type ;
extern struct _longobject _Py_FalseStruct ;
extern struct _longobject _Py_TrueStruct ;
extern PyObject *PyBool_FromLong(long  ) ;
extern PyTypeObject PyFloat_Type ;
extern double PyFloat_GetMax(void) ;
extern double PyFloat_GetMin(void) ;
extern PyObject *PyFloat_GetInfo(void) ;
extern PyObject *PyFloat_FromString(PyObject * ) ;
extern PyObject *PyFloat_FromDouble(double  ) ;
extern double PyFloat_AsDouble(PyObject * ) ;
extern int _PyFloat_Pack4(double x , unsigned char *p , int le ) ;
extern int _PyFloat_Pack8(double x , unsigned char *p , int le ) ;
extern int _PyFloat_Repr(double x , char *p , size_t len ) ;
extern int _PyFloat_Digits(char *buf , double v , int *signum ) ;
extern void _PyFloat_DigitsInit(void) ;
extern double _PyFloat_Unpack4(unsigned char const   *p , int le ) ;
extern double _PyFloat_Unpack8(unsigned char const   *p , int le ) ;
extern int PyFloat_ClearFreeList(void) ;
extern PyObject *_PyFloat_FormatAdvanced(PyObject *obj , Py_UNICODE *format_spec , Py_ssize_t format_spec_len ) ;
extern Py_complex _Py_c_sum(Py_complex  , Py_complex  ) ;
extern Py_complex _Py_c_diff(Py_complex  , Py_complex  ) ;
extern Py_complex _Py_c_neg(Py_complex  ) ;
extern Py_complex _Py_c_prod(Py_complex  , Py_complex  ) ;
extern Py_complex _Py_c_quot(Py_complex  , Py_complex  ) ;
extern Py_complex _Py_c_pow(Py_complex  , Py_complex  ) ;
extern double _Py_c_abs(Py_complex  ) ;
extern PyTypeObject PyComplex_Type ;
extern PyObject *PyComplex_FromCComplex(Py_complex  ) ;
extern PyObject *PyComplex_FromDoubles(double real , double imag ) ;
extern double PyComplex_RealAsDouble(PyObject *op ) ;
extern double PyComplex_ImagAsDouble(PyObject *op ) ;
extern Py_complex PyComplex_AsCComplex(PyObject *op ) ;
extern PyObject *_PyComplex_FormatAdvanced(PyObject *obj , Py_UNICODE *format_spec , Py_ssize_t format_spec_len ) ;
extern PyTypeObject PyRange_Type ;
extern PyTypeObject PyRangeIter_Type ;
extern PyTypeObject PyLongRangeIter_Type ;
extern PyTypeObject PyMemoryView_Type ;
extern PyObject *PyMemoryView_GetContiguous(PyObject *base , int buffertype , char fort ) ;
extern PyObject *PyMemoryView_FromObject(PyObject *base ) ;
extern PyObject *PyMemoryView_FromBuffer(Py_buffer *info ) ;
extern PyTypeObject PyTuple_Type ;
extern PyTypeObject PyTupleIter_Type ;
extern PyObject *PyTuple_New(Py_ssize_t size ) ;
extern Py_ssize_t PyTuple_Size(PyObject * ) ;
extern PyObject *PyTuple_GetItem(PyObject * , Py_ssize_t  ) ;
extern int PyTuple_SetItem(PyObject * , Py_ssize_t  , PyObject * ) ;
extern PyObject *PyTuple_GetSlice(PyObject * , Py_ssize_t  , Py_ssize_t  ) ;
extern int _PyTuple_Resize(PyObject ** , Py_ssize_t  ) ;
extern PyObject *PyTuple_Pack(Py_ssize_t   , ...) ;
extern void _PyTuple_MaybeUntrack(PyObject * ) ;
extern int PyTuple_ClearFreeList(void) ;
extern PyTypeObject PyList_Type ;
extern PyTypeObject PyListIter_Type ;
extern PyTypeObject PyListRevIter_Type ;
extern PyTypeObject PySortWrapper_Type ;
extern PyObject *PyList_New(Py_ssize_t size ) ;
extern Py_ssize_t PyList_Size(PyObject * ) ;
extern PyObject *PyList_GetItem(PyObject * , Py_ssize_t  ) ;
extern int PyList_SetItem(PyObject * , Py_ssize_t  , PyObject * ) ;
extern int PyList_Insert(PyObject * , Py_ssize_t  , PyObject * ) ;
extern int PyList_Append(PyObject * , PyObject * ) ;
extern PyObject *PyList_GetSlice(PyObject * , Py_ssize_t  , Py_ssize_t  ) ;
extern int PyList_SetSlice(PyObject * , Py_ssize_t  , Py_ssize_t  , PyObject * ) ;
extern int PyList_Sort(PyObject * ) ;
extern int PyList_Reverse(PyObject * ) ;
extern PyObject *PyList_AsTuple(PyObject * ) ;
extern PyObject *_PyList_Extend(PyListObject * , PyObject * ) ;
extern PyTypeObject PyDict_Type ;
extern PyTypeObject PyDictIterKey_Type ;
extern PyTypeObject PyDictIterValue_Type ;
extern PyTypeObject PyDictIterItem_Type ;
extern PyTypeObject PyDictKeys_Type ;
extern PyTypeObject PyDictItems_Type ;
extern PyTypeObject PyDictValues_Type ;
extern PyObject *PyDict_New(void) ;
extern PyObject *PyDict_GetItem(PyObject *mp , PyObject *key ) ;
extern PyObject *PyDict_GetItemWithError(PyObject *mp , PyObject *key ) ;
extern int PyDict_SetItem(PyObject *mp , PyObject *key , PyObject *item ) ;
extern int PyDict_DelItem(PyObject *mp , PyObject *key ) ;
extern void PyDict_Clear(PyObject *mp ) ;
extern int PyDict_Next(PyObject *mp , Py_ssize_t *pos , PyObject **key , PyObject **value ) ;
extern int _PyDict_Next(PyObject *mp , Py_ssize_t *pos , PyObject **key , PyObject **value , Py_hash_t *hash ) ;
extern PyObject *PyDict_Keys(PyObject *mp ) ;
extern PyObject *PyDict_Values(PyObject *mp ) ;
extern PyObject *PyDict_Items(PyObject *mp ) ;
extern Py_ssize_t PyDict_Size(PyObject *mp ) ;
extern PyObject *PyDict_Copy(PyObject *mp ) ;
extern int PyDict_Contains(PyObject *mp , PyObject *key ) ;
extern int _PyDict_Contains(PyObject *mp , PyObject *key , Py_hash_t hash ) ;
extern PyObject *_PyDict_NewPresized(Py_ssize_t minused ) ;
extern void _PyDict_MaybeUntrack(PyObject *mp ) ;
extern int _PyDict_HasOnlyStringKeys(PyObject *mp ) ;
extern int PyDict_Update(PyObject *mp , PyObject *other ) ;
extern int PyDict_Merge(PyObject *mp , PyObject *other , int override ) ;
extern int PyDict_MergeFromSeq2(PyObject *d , PyObject *seq2 , int override ) ;
extern PyObject *PyDict_GetItemString(PyObject *dp , char const   *key ) ;
extern int PyDict_SetItemString(PyObject *dp , char const   *key , PyObject *item ) ;
extern int PyDict_DelItemString(PyObject *dp , char const   *key ) ;
extern PyTypeObject PyEnum_Type ;
extern PyTypeObject PyReversed_Type ;
extern PyTypeObject PySet_Type ;
extern PyTypeObject PyFrozenSet_Type ;
extern PyTypeObject PySetIter_Type ;
extern PyObject *PySet_New(PyObject * ) ;
extern PyObject *PyFrozenSet_New(PyObject * ) ;
extern Py_ssize_t PySet_Size(PyObject *anyset ) ;
extern int PySet_Clear(PyObject *set ) ;
extern int PySet_Contains(PyObject *anyset , PyObject *key ) ;
extern int PySet_Discard(PyObject *set , PyObject *key ) ;
extern int PySet_Add(PyObject *set , PyObject *key ) ;
extern int _PySet_NextEntry(PyObject *set , Py_ssize_t *pos , PyObject **key , Py_hash_t *hash ) ;
extern PyObject *PySet_Pop(PyObject *set ) ;
extern int _PySet_Update(PyObject *set , PyObject *iterable ) ;
extern PyTypeObject PyCFunction_Type ;
extern PyCFunction PyCFunction_GetFunction(PyObject * ) ;
extern PyObject *PyCFunction_GetSelf(PyObject * ) ;
extern int PyCFunction_GetFlags(PyObject * ) ;
extern PyObject *PyCFunction_Call(PyObject * , PyObject * , PyObject * ) ;
extern PyObject *PyCFunction_NewEx(PyMethodDef * , PyObject * , PyObject * ) ;
extern int PyCFunction_ClearFreeList(void) ;
extern PyTypeObject PyModule_Type ;
extern PyObject *PyModule_NewObject(PyObject *name ) ;
extern PyObject *PyModule_New(char const   *name ) ;
extern PyObject *PyModule_GetDict(PyObject * ) ;
extern PyObject *PyModule_GetNameObject(PyObject * ) ;
extern char const   *PyModule_GetName(PyObject * ) ;
extern char const   *PyModule_GetFilename(PyObject * ) ;
extern PyObject *PyModule_GetFilenameObject(PyObject * ) ;
extern void _PyModule_Clear(PyObject * ) ;
extern struct PyModuleDef *PyModule_GetDef(PyObject * ) ;
extern void *PyModule_GetState(PyObject * ) ;
extern PyTypeObject PyFunction_Type ;
extern PyObject *PyFunction_New(PyObject * , PyObject * ) ;
extern PyObject *PyFunction_GetCode(PyObject * ) ;
extern PyObject *PyFunction_GetGlobals(PyObject * ) ;
extern PyObject *PyFunction_GetModule(PyObject * ) ;
extern PyObject *PyFunction_GetDefaults(PyObject * ) ;
extern int PyFunction_SetDefaults(PyObject * , PyObject * ) ;
extern PyObject *PyFunction_GetKwDefaults(PyObject * ) ;
extern int PyFunction_SetKwDefaults(PyObject * , PyObject * ) ;
extern PyObject *PyFunction_GetClosure(PyObject * ) ;
extern int PyFunction_SetClosure(PyObject * , PyObject * ) ;
extern PyObject *PyFunction_GetAnnotations(PyObject * ) ;
extern int PyFunction_SetAnnotations(PyObject * , PyObject * ) ;
extern PyTypeObject PyClassMethod_Type ;
extern PyTypeObject PyStaticMethod_Type ;
extern PyObject *PyClassMethod_New(PyObject * ) ;
extern PyObject *PyStaticMethod_New(PyObject * ) ;
extern PyTypeObject PyMethod_Type ;
extern PyObject *PyMethod_New(PyObject * , PyObject * ) ;
extern PyObject *PyMethod_Function(PyObject * ) ;
extern PyObject *PyMethod_Self(PyObject * ) ;
extern int PyMethod_ClearFreeList(void) ;
extern PyTypeObject PyInstanceMethod_Type ;
extern PyObject *PyInstanceMethod_New(PyObject * ) ;
extern PyObject *PyInstanceMethod_Function(PyObject * ) ;
extern PyObject *PyFile_FromFd(int  , char * , char * , int  , char * , char * , char * , int  ) ;
extern PyObject *PyFile_GetLine(PyObject * , int  ) ;
extern int PyFile_WriteObject(PyObject * , PyObject * , int  ) ;
extern int PyFile_WriteString(char const   * , PyObject * ) ;
extern int PyObject_AsFileDescriptor(PyObject * ) ;
extern char *Py_UniversalNewlineFgets(char * , int  , FILE * , PyObject * ) ;
extern char const   *Py_FileSystemDefaultEncoding ;
extern int Py_HasFileSystemDefaultEncoding ;
extern PyObject *PyFile_NewStdPrinter(int  ) ;
extern PyTypeObject PyStdPrinter_Type ;
extern PyTypeObject PyCapsule_Type ;
extern PyObject *PyCapsule_New(void *pointer , char const   *name , void (*destructor)(PyObject * ) ) ;
extern void *PyCapsule_GetPointer(PyObject *capsule , char const   *name ) ;
extern PyCapsule_Destructor PyCapsule_GetDestructor(PyObject *capsule ) ;
extern char const   *PyCapsule_GetName(PyObject *capsule ) ;
extern void *PyCapsule_GetContext(PyObject *capsule ) ;
extern int PyCapsule_IsValid(PyObject *capsule , char const   *name ) ;
extern int PyCapsule_SetPointer(PyObject *capsule , void *pointer ) ;
extern int PyCapsule_SetDestructor(PyObject *capsule , void (*destructor)(PyObject * ) ) ;
extern int PyCapsule_SetName(PyObject *capsule , char const   *name ) ;
extern int PyCapsule_SetContext(PyObject *capsule , void *context ) ;
extern void *PyCapsule_Import(char const   *name , int no_block ) ;
extern PyInterpreterState *PyInterpreterState_New(void) ;
extern void PyInterpreterState_Clear(PyInterpreterState * ) ;
extern void PyInterpreterState_Delete(PyInterpreterState * ) ;
extern int _PyState_AddModule(PyObject * , struct PyModuleDef * ) ;
extern PyObject *PyState_FindModule(struct PyModuleDef * ) ;
extern PyThreadState *PyThreadState_New(PyInterpreterState * ) ;
extern PyThreadState *_PyThreadState_Prealloc(PyInterpreterState * ) ;
extern void _PyThreadState_Init(PyThreadState * ) ;
extern void PyThreadState_Clear(PyThreadState * ) ;
extern void PyThreadState_Delete(PyThreadState * ) ;
extern void PyThreadState_DeleteCurrent(void) ;
extern void _PyGILState_Reinit(void) ;
extern PyThreadState *PyThreadState_Get(void) ;
extern PyThreadState *PyThreadState_Swap(PyThreadState * ) ;
extern PyObject *PyThreadState_GetDict(void) ;
extern int PyThreadState_SetAsyncExc(long  , PyObject * ) ;
extern _Py_atomic_address _PyThreadState_Current ;
extern PyGILState_STATE PyGILState_Ensure(void) ;
extern void PyGILState_Release(PyGILState_STATE  ) ;
extern PyThreadState *PyGILState_GetThisThreadState(void) ;
extern PyObject *_PyThread_CurrentFrames(void) ;
extern PyInterpreterState *PyInterpreterState_Head(void) ;
extern PyInterpreterState *PyInterpreterState_Next(PyInterpreterState * ) ;
extern PyThreadState *PyInterpreterState_ThreadHead(PyInterpreterState * ) ;
extern PyThreadState *PyThreadState_Next(PyThreadState * ) ;
extern struct _frame *(*_PyThreadState_GetFrame)(PyThreadState *self_ ) ;
extern int PyTraceBack_Here(struct _frame * ) ;
extern int PyTraceBack_Print(PyObject * , PyObject * ) ;
extern int _Py_DisplaySourceLine(PyObject * , PyObject * , int  , int  ) ;
extern PyTypeObject PyTraceBack_Type ;
extern void _Py_DumpTraceback(int fd , PyThreadState *tstate ) ;
extern char const   *_Py_DumpTracebackThreads(int fd , PyInterpreterState *interp , PyThreadState *current_thread ) ;
extern PyObject _Py_EllipsisObject ;
extern PyTypeObject PySlice_Type ;
extern PyTypeObject PyEllipsis_Type ;
extern PyObject *PySlice_New(PyObject *start , PyObject *stop , PyObject *step ) ;
extern PyObject *_PySlice_FromIndices(Py_ssize_t start , Py_ssize_t stop ) ;
extern int PySlice_GetIndices(PyObject *r , Py_ssize_t length , Py_ssize_t *start , Py_ssize_t *stop , Py_ssize_t *step ) ;
extern int PySlice_GetIndicesEx(PyObject *r , Py_ssize_t length , Py_ssize_t *start , Py_ssize_t *stop , Py_ssize_t *step , Py_ssize_t *slicelength ) ;
extern PyTypeObject PyCell_Type ;
extern PyObject *PyCell_New(PyObject * ) ;
extern PyObject *PyCell_Get(PyObject * ) ;
extern int PyCell_Set(PyObject * , PyObject * ) ;
extern PyTypeObject PySeqIter_Type ;
extern PyTypeObject PyCallIter_Type ;
extern PyTypeObject PyCmpWrapper_Type ;
extern PyObject *PySeqIter_New(PyObject * ) ;
extern PyObject *PyCallIter_New(PyObject * , PyObject * ) ;
extern PyTypeObject PyGen_Type ;
extern PyObject *PyGen_New(struct _frame * ) ;
extern int PyGen_NeedsFinalizing(PyGenObject * ) ;
extern PyTypeObject PyClassMethodDescr_Type ;
extern PyTypeObject PyGetSetDescr_Type ;
extern PyTypeObject PyMemberDescr_Type ;
extern PyTypeObject PyMethodDescr_Type ;
extern PyTypeObject PyWrapperDescr_Type ;
extern PyTypeObject PyDictProxy_Type ;
extern PyObject *PyDescr_NewMethod(PyTypeObject * , PyMethodDef * ) ;
extern PyObject *PyDescr_NewClassMethod(PyTypeObject * , PyMethodDef * ) ;
extern PyObject *PyDescr_NewMember(PyTypeObject * , struct PyMemberDef * ) ;
extern PyObject *PyDescr_NewGetSet(PyTypeObject * , struct PyGetSetDef * ) ;
extern PyObject *PyDescr_NewWrapper(PyTypeObject * , struct wrapperbase * , void * ) ;
extern PyObject *PyDictProxy_New(PyObject * ) ;
extern PyObject *PyWrapper_New(PyObject * , PyObject * ) ;
extern PyTypeObject PyProperty_Type ;
extern PyObject *_PyWarnings_Init(void) ;
extern int PyErr_WarnEx(PyObject *category , char const   *message , Py_ssize_t stack_level ) ;
extern int PyErr_WarnFormat(PyObject *category , Py_ssize_t stack_level , char const   *format  , ...) ;
extern int PyErr_WarnExplicit(PyObject *category , char const   *message , char const   *filename , int lineno , char const   *module , PyObject *registry ) ;
extern PyTypeObject _PyWeakref_RefType ;
extern PyTypeObject _PyWeakref_ProxyType ;
extern PyTypeObject _PyWeakref_CallableProxyType ;
extern PyObject *PyWeakref_NewRef(PyObject *ob , PyObject *callback ) ;
extern PyObject *PyWeakref_NewProxy(PyObject *ob , PyObject *callback ) ;
extern PyObject *PyWeakref_GetObject(PyObject *ref ) ;
extern Py_ssize_t _PyWeakref_GetWeakrefCount(PyWeakReference *head ) ;
extern void _PyWeakref_ClearRef(PyWeakReference *self ) ;
extern char *PyStructSequence_UnnamedField ;
extern void PyStructSequence_InitType(PyTypeObject *type , PyStructSequence_Desc *desc ) ;
extern PyTypeObject *PyStructSequence_NewType(PyStructSequence_Desc *desc ) ;
extern PyObject *PyStructSequence_New(PyTypeObject *type ) ;
extern void PyStructSequence_SetItem(PyObject * , Py_ssize_t  , PyObject * ) ;
extern PyObject *PyStructSequence_GetItem(PyObject * , Py_ssize_t  ) ;
extern int PyCodec_Register(PyObject *search_function ) ;
extern PyObject *_PyCodec_Lookup(char const   *encoding ) ;
extern int PyCodec_KnownEncoding(char const   *encoding ) ;
extern PyObject *PyCodec_Encode(PyObject *object , char const   *encoding , char const   *errors ) ;
extern PyObject *PyCodec_Decode(PyObject *object , char const   *encoding , char const   *errors ) ;
extern PyObject *PyCodec_Encoder(char const   *encoding ) ;
extern PyObject *PyCodec_Decoder(char const   *encoding ) ;
extern PyObject *PyCodec_IncrementalEncoder(char const   *encoding , char const   *errors ) ;
extern PyObject *PyCodec_IncrementalDecoder(char const   *encoding , char const   *errors ) ;
extern PyObject *PyCodec_StreamReader(char const   *encoding , PyObject *stream , char const   *errors ) ;
extern PyObject *PyCodec_StreamWriter(char const   *encoding , PyObject *stream , char const   *errors ) ;
extern int PyCodec_RegisterError(char const   *name , PyObject *error ) ;
extern PyObject *PyCodec_LookupError(char const   *name ) ;
extern PyObject *PyCodec_StrictErrors(PyObject *exc ) ;
extern PyObject *PyCodec_IgnoreErrors(PyObject *exc ) ;
extern PyObject *PyCodec_ReplaceErrors(PyObject *exc ) ;
extern PyObject *PyCodec_XMLCharRefReplaceErrors(PyObject *exc ) ;
extern PyObject *PyCodec_BackslashReplaceErrors(PyObject *exc ) ;
extern void PyErr_SetNone(PyObject * ) ;
extern void PyErr_SetObject(PyObject * , PyObject * ) ;
extern void PyErr_SetString(PyObject *exception , char const   *string ) ;
extern PyObject *PyErr_Occurred(void) ;
extern void PyErr_Clear(void) ;
extern void PyErr_Fetch(PyObject ** , PyObject ** , PyObject ** ) ;
extern void PyErr_Restore(PyObject * , PyObject * , PyObject * ) ;
extern void Py_FatalError(char const   *message ) ;
extern int PyErr_GivenExceptionMatches(PyObject * , PyObject * ) ;
extern int PyErr_ExceptionMatches(PyObject * ) ;
extern void PyErr_NormalizeException(PyObject ** , PyObject ** , PyObject ** ) ;
extern int PyException_SetTraceback(PyObject * , PyObject * ) ;
extern PyObject *PyException_GetTraceback(PyObject * ) ;
extern PyObject *PyException_GetCause(PyObject * ) ;
extern void PyException_SetCause(PyObject * , PyObject * ) ;
extern PyObject *PyException_GetContext(PyObject * ) ;
extern void PyException_SetContext(PyObject * , PyObject * ) ;
extern PyObject *PyExc_BaseException ;
extern PyObject *PyExc_Exception ;
extern PyObject *PyExc_StopIteration ;
extern PyObject *PyExc_GeneratorExit ;
extern PyObject *PyExc_ArithmeticError ;
extern PyObject *PyExc_LookupError ;
extern PyObject *PyExc_AssertionError ;
extern PyObject *PyExc_AttributeError ;
extern PyObject *PyExc_EOFError ;
extern PyObject *PyExc_FloatingPointError ;
extern PyObject *PyExc_EnvironmentError ;
extern PyObject *PyExc_IOError ;
extern PyObject *PyExc_OSError ;
extern PyObject *PyExc_ImportError ;
extern PyObject *PyExc_IndexError ;
extern PyObject *PyExc_KeyError ;
extern PyObject *PyExc_KeyboardInterrupt ;
extern PyObject *PyExc_MemoryError ;
extern PyObject *PyExc_NameError ;
extern PyObject *PyExc_OverflowError ;
extern PyObject *PyExc_RuntimeError ;
extern PyObject *PyExc_NotImplementedError ;
extern PyObject *PyExc_SyntaxError ;
extern PyObject *PyExc_IndentationError ;
extern PyObject *PyExc_TabError ;
extern PyObject *PyExc_ReferenceError ;
extern PyObject *PyExc_SystemError ;
extern PyObject *PyExc_SystemExit ;
extern PyObject *PyExc_TypeError ;
extern PyObject *PyExc_UnboundLocalError ;
extern PyObject *PyExc_UnicodeError ;
extern PyObject *PyExc_UnicodeEncodeError ;
extern PyObject *PyExc_UnicodeDecodeError ;
extern PyObject *PyExc_UnicodeTranslateError ;
extern PyObject *PyExc_ValueError ;
extern PyObject *PyExc_ZeroDivisionError ;
extern PyObject *PyExc_BufferError ;
extern PyObject *PyExc_RecursionErrorInst ;
extern PyObject *PyExc_Warning ;
extern PyObject *PyExc_UserWarning ;
extern PyObject *PyExc_DeprecationWarning ;
extern PyObject *PyExc_PendingDeprecationWarning ;
extern PyObject *PyExc_SyntaxWarning ;
extern PyObject *PyExc_RuntimeWarning ;
extern PyObject *PyExc_FutureWarning ;
extern PyObject *PyExc_ImportWarning ;
extern PyObject *PyExc_UnicodeWarning ;
extern PyObject *PyExc_BytesWarning ;
extern PyObject *PyExc_ResourceWarning ;
extern int PyErr_BadArgument(void) ;
extern PyObject *PyErr_NoMemory(void) ;
extern PyObject *PyErr_SetFromErrno(PyObject * ) ;
extern PyObject *PyErr_SetFromErrnoWithFilenameObject(PyObject * , PyObject * ) ;
extern PyObject *PyErr_SetFromErrnoWithFilename(PyObject *exc , char const   *filename ) ;
extern PyObject *PyErr_Format(PyObject *exception , char const   *format  , ...) ;
extern void PyErr_BadInternalCall(void) ;
extern void _PyErr_BadInternalCall(char const   *filename , int lineno ) ;
extern PyObject *PyErr_NewException(char const   *name , PyObject *base , PyObject *dict ) ;
extern PyObject *PyErr_NewExceptionWithDoc(char const   *name , char const   *doc , PyObject *base , PyObject *dict ) ;
extern void PyErr_WriteUnraisable(PyObject * ) ;
extern int PyErr_CheckSignals(void) ;
extern void PyErr_SetInterrupt(void) ;
extern int PySignal_SetWakeupFd(int fd ) ;
extern void PyErr_SyntaxLocation(char const   *filename , int lineno ) ;
extern void PyErr_SyntaxLocationEx(char const   *filename , int lineno , int col_offset ) ;
extern PyObject *PyErr_ProgramText(char const   *filename , int lineno ) ;
extern PyObject *PyUnicodeDecodeError_Create(char const   *encoding , char const   *object , Py_ssize_t length , Py_ssize_t start , Py_ssize_t end , char const   *reason ) ;
extern PyObject *PyUnicodeEncodeError_Create(char const   *encoding , Py_UNICODE const   *object , Py_ssize_t length , Py_ssize_t start , Py_ssize_t end , char const   *reason ) ;
extern PyObject *PyUnicodeTranslateError_Create(Py_UNICODE const   *object , Py_ssize_t length , Py_ssize_t start , Py_ssize_t end , char const   *reason ) ;
extern PyObject *PyUnicodeEncodeError_GetEncoding(PyObject * ) ;
extern PyObject *PyUnicodeDecodeError_GetEncoding(PyObject * ) ;
extern PyObject *PyUnicodeEncodeError_GetObject(PyObject * ) ;
extern PyObject *PyUnicodeDecodeError_GetObject(PyObject * ) ;
extern PyObject *PyUnicodeTranslateError_GetObject(PyObject * ) ;
extern int PyUnicodeEncodeError_GetStart(PyObject * , Py_ssize_t * ) ;
extern int PyUnicodeDecodeError_GetStart(PyObject * , Py_ssize_t * ) ;
extern int PyUnicodeTranslateError_GetStart(PyObject * , Py_ssize_t * ) ;
extern int PyUnicodeEncodeError_SetStart(PyObject * , Py_ssize_t  ) ;
extern int PyUnicodeDecodeError_SetStart(PyObject * , Py_ssize_t  ) ;
extern int PyUnicodeTranslateError_SetStart(PyObject * , Py_ssize_t  ) ;
extern int PyUnicodeEncodeError_GetEnd(PyObject * , Py_ssize_t * ) ;
extern int PyUnicodeDecodeError_GetEnd(PyObject * , Py_ssize_t * ) ;
extern int PyUnicodeTranslateError_GetEnd(PyObject * , Py_ssize_t * ) ;
extern int PyUnicodeEncodeError_SetEnd(PyObject * , Py_ssize_t  ) ;
extern int PyUnicodeDecodeError_SetEnd(PyObject * , Py_ssize_t  ) ;
extern int PyUnicodeTranslateError_SetEnd(PyObject * , Py_ssize_t  ) ;
extern PyObject *PyUnicodeEncodeError_GetReason(PyObject * ) ;
extern PyObject *PyUnicodeDecodeError_GetReason(PyObject * ) ;
extern PyObject *PyUnicodeTranslateError_GetReason(PyObject * ) ;
extern int PyUnicodeEncodeError_SetReason(PyObject *exc , char const   *reason ) ;
extern int PyUnicodeDecodeError_SetReason(PyObject *exc , char const   *reason ) ;
extern int PyUnicodeTranslateError_SetReason(PyObject *exc , char const   *reason ) ;
extern int ( /* format attribute */  PyOS_snprintf)(char *str , size_t size , char const   *format  , ...) ;
extern int ( /* format attribute */  PyOS_vsnprintf)(char *str , size_t size , char const   *format , va_list va ) ;
extern PyArena *PyArena_New(void) ;
extern void PyArena_Free(PyArena * ) ;
extern void *PyArena_Malloc(PyArena * , size_t size ) ;
extern int PyArena_AddPyObject(PyArena * , PyObject * ) ;
extern PyObject *_Py_VaBuildValue_SizeT(char const   * , va_list  ) ;
extern int PyArg_Parse(PyObject * , char const   *  , ...) ;
extern int PyArg_ParseTuple(PyObject * , char const   *  , ...) ;
extern int PyArg_ParseTupleAndKeywords(PyObject * , PyObject * , char const   * , char **  , ...) ;
extern int PyArg_ValidateKeywordArguments(PyObject * ) ;
extern int PyArg_UnpackTuple(PyObject * , char const   * , Py_ssize_t  , Py_ssize_t   , ...) ;
extern PyObject *Py_BuildValue(char const   *  , ...) ;
extern PyObject *_Py_BuildValue_SizeT(char const   *  , ...) ;
extern int _PyArg_NoKeywords(char const   *funcname , PyObject *kw ) ;
extern int PyArg_VaParse(PyObject * , char const   * , va_list  ) ;
extern int PyArg_VaParseTupleAndKeywords(PyObject * , PyObject * , char const   * , char ** , va_list  ) ;
extern PyObject *Py_VaBuildValue(char const   * , va_list  ) ;
extern int PyModule_AddObject(PyObject * , char const   * , PyObject * ) ;
extern int PyModule_AddIntConstant(PyObject * , char const   * , long  ) ;
extern int PyModule_AddStringConstant(PyObject * , char const   * , char const   * ) ;
extern PyObject *PyModule_Create2(struct PyModuleDef * , int apiver ) ;
extern char *_Py_PackageContext ;
extern void Py_SetProgramName(wchar_t * ) ;
extern wchar_t *Py_GetProgramName(void) ;
extern void Py_SetPythonHome(wchar_t * ) ;
extern wchar_t *Py_GetPythonHome(void) ;
extern void Py_Initialize(void) ;
extern void Py_InitializeEx(int  ) ;
extern void Py_Finalize(void) ;
extern int Py_IsInitialized(void) ;
extern PyThreadState *Py_NewInterpreter(void) ;
extern void Py_EndInterpreter(PyThreadState * ) ;
extern int PyRun_SimpleStringFlags(char const   * , PyCompilerFlags * ) ;
extern int PyRun_AnyFileFlags(FILE * , char const   * , PyCompilerFlags * ) ;
extern int PyRun_AnyFileExFlags(FILE *fp , char const   *filename , int closeit , PyCompilerFlags *flags ) ;
extern int PyRun_SimpleFileExFlags(FILE *fp , char const   *filename , int closeit , PyCompilerFlags *flags ) ;
extern int PyRun_InteractiveOneFlags(FILE *fp , char const   *filename , PyCompilerFlags *flags ) ;
extern int PyRun_InteractiveLoopFlags(FILE *fp , char const   *filename , PyCompilerFlags *flags ) ;
extern struct _mod *PyParser_ASTFromString(char const   *s , char const   *filename , int start , PyCompilerFlags *flags , PyArena *arena ) ;
extern struct _mod *PyParser_ASTFromFile(FILE *fp , char const   *filename , char const   *enc , int start , char *ps1 , char *ps2 , PyCompilerFlags *flags , int *errcode , PyArena *arena ) ;
extern struct _node *PyParser_SimpleParseStringFlags(char const   * , int  , int  ) ;
extern struct _node *PyParser_SimpleParseFileFlags(FILE * , char const   * , int  , int  ) ;
extern PyObject *PyRun_StringFlags(char const   * , int  , PyObject * , PyObject * , PyCompilerFlags * ) ;
extern PyObject *PyRun_FileExFlags(FILE *fp , char const   *filename , int start , PyObject *globals , PyObject *locals , int closeit , PyCompilerFlags *flags ) ;
extern PyObject *Py_CompileStringExFlags(char const   *str , char const   *filename , int start , PyCompilerFlags *flags , int optimize ) ;
extern struct symtable *Py_SymtableString(char const   *str , char const   *filename , int start ) ;
extern void PyErr_Print(void) ;
extern void PyErr_PrintEx(int  ) ;
extern void PyErr_Display(PyObject * , PyObject * , PyObject * ) ;
extern void _Py_PyAtExit(void (*func)(void) ) ;
extern int Py_AtExit(void (*func)(void) ) ;
extern void Py_Exit(int  ) ;
extern void _Py_RestoreSignals(void) ;
extern int Py_FdIsInteractive(FILE * , char const   * ) ;
extern int Py_Main(int argc , wchar_t **argv ) ;
extern wchar_t *Py_GetProgramFullPath(void) ;
extern wchar_t *Py_GetPrefix(void) ;
extern wchar_t *Py_GetExecPrefix(void) ;
extern wchar_t *Py_GetPath(void) ;
extern void Py_SetPath(wchar_t const   * ) ;
extern char const   *Py_GetVersion(void) ;
extern char const   *Py_GetPlatform(void) ;
extern char const   *Py_GetCopyright(void) ;
extern char const   *Py_GetCompiler(void) ;
extern char const   *Py_GetBuildInfo(void) ;
extern char const   *_Py_hgidentifier(void) ;
extern char const   *_Py_hgversion(void) ;
extern PyObject *_PyBuiltin_Init(void) ;
extern PyObject *_PySys_Init(void) ;
extern void _PyImport_Init(void) ;
extern void _PyExc_Init(void) ;
extern void _PyImportHooks_Init(void) ;
extern int _PyFrame_Init(void) ;
extern void _PyFloat_Init(void) ;
extern int PyByteArray_Init(void) ;
extern void _PyExc_Fini(void) ;
extern void _PyImport_Fini(void) ;
extern void PyMethod_Fini(void) ;
extern void PyFrame_Fini(void) ;
extern void PyCFunction_Fini(void) ;
extern void PyDict_Fini(void) ;
extern void PyTuple_Fini(void) ;
extern void PyList_Fini(void) ;
extern void PySet_Fini(void) ;
extern void PyBytes_Fini(void) ;
extern void PyByteArray_Fini(void) ;
extern void PyFloat_Fini(void) ;
extern void PyOS_FiniInterrupts(void) ;
extern void _PyGC_Fini(void) ;
extern PyThreadState *_Py_Finalizing ;
extern char *PyOS_Readline(FILE * , FILE * , char * ) ;
extern int (*PyOS_InputHook)(void) ;
extern char *(*PyOS_ReadlineFunctionPointer)(FILE * , FILE * , char * ) ;
extern PyThreadState *_PyOS_ReadlineTState ;
extern PyOS_sighandler_t PyOS_getsig(int  ) ;
extern PyOS_sighandler_t PyOS_setsig(int  , void (*)(int  ) ) ;
extern PyObject *PyEval_CallObjectWithKeywords(PyObject * , PyObject * , PyObject * ) ;
extern PyObject *PyEval_CallFunction(PyObject *obj , char const   *format  , ...) ;
extern PyObject *PyEval_CallMethod(PyObject *obj , char const   *methodname , char const   *format  , ...) ;
extern void PyEval_SetProfile(int (*)(PyObject * , struct _frame * , int  , PyObject * ) , PyObject * ) ;
extern void PyEval_SetTrace(int (*)(PyObject * , struct _frame * , int  , PyObject * ) , PyObject * ) ;
extern PyObject *PyEval_GetBuiltins(void) ;
extern PyObject *PyEval_GetGlobals(void) ;
extern PyObject *PyEval_GetLocals(void) ;
extern struct _frame *PyEval_GetFrame(void) ;
extern int PyEval_MergeCompilerFlags(PyCompilerFlags *cf ) ;
extern int Py_AddPendingCall(int (*func)(void * ) , void *arg ) ;
extern int Py_MakePendingCalls(void) ;
extern void Py_SetRecursionLimit(int  ) ;
extern int Py_GetRecursionLimit(void) ;
extern int _Py_CheckRecursiveCall(char *where ) ;
extern int _Py_CheckRecursionLimit ;
extern char const   *PyEval_GetFuncName(PyObject * ) ;
extern char const   *PyEval_GetFuncDesc(PyObject * ) ;
extern PyObject *PyEval_GetCallStats(PyObject * ) ;
extern PyObject *PyEval_EvalFrame(struct _frame * ) ;
extern PyObject *PyEval_EvalFrameEx(struct _frame *f , int exc ) ;
extern PyThreadState *PyEval_SaveThread(void) ;
extern void PyEval_RestoreThread(PyThreadState * ) ;
extern int PyEval_ThreadsInitialized(void) ;
extern void PyEval_InitThreads(void) ;
extern void _PyEval_FiniThreads(void) ;
extern void PyEval_AcquireLock(void) ;
extern void PyEval_ReleaseLock(void) ;
extern void PyEval_AcquireThread(PyThreadState *tstate ) ;
extern void PyEval_ReleaseThread(PyThreadState *tstate ) ;
extern void PyEval_ReInitThreads(void) ;
extern void _PyEval_SetSwitchInterval(unsigned long microseconds ) ;
extern unsigned long _PyEval_GetSwitchInterval(void) ;
extern int _PyEval_SliceIndex(PyObject * , Py_ssize_t * ) ;
extern void _PyEval_SignalAsyncExc(void) ;
extern PyObject *PySys_GetObject(char const   * ) ;
extern int PySys_SetObject(char const   * , PyObject * ) ;
extern void PySys_SetArgv(int  , wchar_t ** ) ;
extern void PySys_SetArgvEx(int  , wchar_t ** , int  ) ;
extern void PySys_SetPath(wchar_t const   * ) ;
extern void ( /* format attribute */  PySys_WriteStdout)(char const   *format  , ...) ;
extern void ( /* format attribute */  PySys_WriteStderr)(char const   *format  , ...) ;
extern void PySys_FormatStdout(char const   *format  , ...) ;
extern void PySys_FormatStderr(char const   *format  , ...) ;
extern PyObject *_PySys_TraceFunc ;
extern PyObject *_PySys_ProfileFunc ;
extern void PySys_ResetWarnOptions(void) ;
extern void PySys_AddWarnOption(wchar_t const   * ) ;
extern void PySys_AddWarnOptionUnicode(PyObject * ) ;
extern int PySys_HasWarnOptions(void) ;
extern void PySys_AddXOption(wchar_t const   * ) ;
extern PyObject *PySys_GetXOptions(void) ;
extern int PyOS_InterruptOccurred(void) ;
extern void PyOS_InitInterrupts(void) ;
extern void PyOS_AfterFork(void) ;
extern long PyImport_GetMagicNumber(void) ;
extern char const   *PyImport_GetMagicTag(void) ;
extern PyObject *PyImport_ExecCodeModule(char *name , PyObject *co ) ;
extern PyObject *PyImport_ExecCodeModuleEx(char *name , PyObject *co , char *pathname ) ;
extern PyObject *PyImport_ExecCodeModuleWithPathnames(char *name , PyObject *co , char *pathname , char *cpathname ) ;
extern PyObject *PyImport_ExecCodeModuleObject(PyObject *name , PyObject *co , PyObject *pathname , PyObject *cpathname ) ;
extern PyObject *PyImport_GetModuleDict(void) ;
extern PyObject *PyImport_AddModuleObject(PyObject *name ) ;
extern PyObject *PyImport_AddModule(char const   *name ) ;
extern PyObject *PyImport_ImportModule(char const   *name ) ;
extern PyObject *PyImport_ImportModuleNoBlock(char const   *name ) ;
extern PyObject *PyImport_ImportModuleLevel(char *name , PyObject *globals , PyObject *locals , PyObject *fromlist , int level ) ;
extern PyObject *PyImport_ImportModuleLevelObject(PyObject *name , PyObject *globals , PyObject *locals , PyObject *fromlist , int level ) ;
extern PyObject *PyImport_GetImporter(PyObject *path ) ;
extern PyObject *PyImport_Import(PyObject *name ) ;
extern PyObject *PyImport_ReloadModule(PyObject *m ) ;
extern void PyImport_Cleanup(void) ;
extern int PyImport_ImportFrozenModuleObject(PyObject *name ) ;
extern int PyImport_ImportFrozenModule(char *name ) ;
extern void _PyImport_AcquireLock(void) ;
extern int _PyImport_ReleaseLock(void) ;
extern void _PyImport_ReInitLock(void) ;
extern PyObject *_PyImport_FindBuiltin(char const   *name ) ;
extern PyObject *_PyImport_FindExtensionObject(PyObject * , PyObject * ) ;
extern int _PyImport_FixupBuiltin(PyObject *mod , char *name ) ;
extern int _PyImport_FixupExtensionObject(PyObject * , PyObject * , PyObject * ) ;
extern struct _inittab *PyImport_Inittab ;
extern int PyImport_ExtendInittab(struct _inittab *newtab ) ;
extern PyTypeObject PyNullImporter_Type ;
extern int PyImport_AppendInittab(char const   *name , PyObject *(*initfunc)(void) ) ;
extern struct _frozen *PyImport_FrozenModules ;
extern PyObject *PyObject_Call(PyObject *callable_object , PyObject *args , PyObject *kw ) ;
extern PyObject *PyObject_CallObject(PyObject *callable_object , PyObject *args ) ;
extern PyObject *PyObject_CallFunction(PyObject *callable_object , char *format  , ...) ;
extern PyObject *PyObject_CallMethod(PyObject *o , char *method , char *format  , ...) ;
extern PyObject *_PyObject_CallFunction_SizeT(PyObject *callable , char *format  , ...) ;
extern PyObject *_PyObject_CallMethod_SizeT(PyObject *o , char *name , char *format  , ...) ;
extern PyObject *PyObject_CallFunctionObjArgs(PyObject *callable  , ...) ;
extern PyObject *PyObject_CallMethodObjArgs(PyObject *o , PyObject *method  , ...) ;
extern PyObject *PyObject_Type(PyObject *o ) ;
extern Py_ssize_t PyObject_Size(PyObject *o ) ;
extern Py_ssize_t PyObject_Length(PyObject *o ) ;
extern Py_ssize_t _PyObject_LengthHint(PyObject *o , Py_ssize_t  ) ;
extern PyObject *PyObject_GetItem(PyObject *o , PyObject *key ) ;
extern int PyObject_SetItem(PyObject *o , PyObject *key , PyObject *v ) ;
extern int PyObject_DelItemString(PyObject *o , char *key ) ;
extern int PyObject_DelItem(PyObject *o , PyObject *key ) ;
extern int PyObject_AsCharBuffer(PyObject *obj , char const   **buffer , Py_ssize_t *buffer_len ) ;
extern int PyObject_CheckReadBuffer(PyObject *obj ) ;
extern int PyObject_AsReadBuffer(PyObject *obj , void const   **buffer , Py_ssize_t *buffer_len ) ;
extern int PyObject_AsWriteBuffer(PyObject *obj , void **buffer , Py_ssize_t *buffer_len ) ;
extern int PyObject_GetBuffer(PyObject *obj , Py_buffer *view , int flags ) ;
extern void *PyBuffer_GetPointer(Py_buffer *view , Py_ssize_t *indices ) ;
extern int PyBuffer_SizeFromFormat(char const   * ) ;
extern int PyBuffer_ToContiguous(void *buf , Py_buffer *view , Py_ssize_t len , char fort ) ;
extern int PyBuffer_FromContiguous(Py_buffer *view , void *buf , Py_ssize_t len , char fort ) ;
extern int PyObject_CopyData(PyObject *dest , PyObject *src ) ;
extern int PyBuffer_IsContiguous(Py_buffer *view , char fort ) ;
extern void PyBuffer_FillContiguousStrides(int ndims , Py_ssize_t *shape , Py_ssize_t *strides , int itemsize , char fort ) ;
extern int PyBuffer_FillInfo(Py_buffer *view , PyObject *o , void *buf , Py_ssize_t len , int readonly , int flags ) ;
extern void PyBuffer_Release(Py_buffer *view ) ;
extern PyObject *PyObject_Format(PyObject *obj , PyObject *format_spec ) ;
extern PyObject *PyObject_GetIter(PyObject * ) ;
extern PyObject *PyIter_Next(PyObject * ) ;
extern int PyNumber_Check(PyObject *o ) ;
extern PyObject *PyNumber_Add(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Subtract(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Multiply(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_FloorDivide(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_TrueDivide(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Remainder(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Divmod(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Power(PyObject *o1 , PyObject *o2 , PyObject *o3 ) ;
extern PyObject *PyNumber_Negative(PyObject *o ) ;
extern PyObject *PyNumber_Positive(PyObject *o ) ;
extern PyObject *PyNumber_Absolute(PyObject *o ) ;
extern PyObject *PyNumber_Invert(PyObject *o ) ;
extern PyObject *PyNumber_Lshift(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Rshift(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_And(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Xor(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Or(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Index(PyObject *o ) ;
extern Py_ssize_t PyNumber_AsSsize_t(PyObject *o , PyObject *exc ) ;
extern PyObject *_PyNumber_ConvertIntegralToInt(PyObject *integral , char const   *error_format ) ;
extern PyObject *PyNumber_Long(PyObject *o ) ;
extern PyObject *PyNumber_Float(PyObject *o ) ;
extern PyObject *PyNumber_InPlaceAdd(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceSubtract(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceMultiply(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceFloorDivide(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceTrueDivide(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceRemainder(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlacePower(PyObject *o1 , PyObject *o2 , PyObject *o3 ) ;
extern PyObject *PyNumber_InPlaceLshift(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceRshift(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceAnd(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceXor(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceOr(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_ToBase(PyObject *n , int base ) ;
extern int PySequence_Check(PyObject *o ) ;
extern Py_ssize_t PySequence_Size(PyObject *o ) ;
extern Py_ssize_t PySequence_Length(PyObject *o ) ;
extern PyObject *PySequence_Concat(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PySequence_Repeat(PyObject *o , Py_ssize_t count ) ;
extern PyObject *PySequence_GetItem(PyObject *o , Py_ssize_t i ) ;
extern PyObject *PySequence_GetSlice(PyObject *o , Py_ssize_t i1 , Py_ssize_t i2 ) ;
extern int PySequence_SetItem(PyObject *o , Py_ssize_t i , PyObject *v ) ;
extern int PySequence_DelItem(PyObject *o , Py_ssize_t i ) ;
extern int PySequence_SetSlice(PyObject *o , Py_ssize_t i1 , Py_ssize_t i2 , PyObject *v ) ;
extern int PySequence_DelSlice(PyObject *o , Py_ssize_t i1 , Py_ssize_t i2 ) ;
extern PyObject *PySequence_Tuple(PyObject *o ) ;
extern PyObject *PySequence_List(PyObject *o ) ;
extern PyObject *PySequence_Fast(PyObject *o , char const   *m ) ;
extern Py_ssize_t PySequence_Count(PyObject *o , PyObject *value ) ;
extern int PySequence_Contains(PyObject *seq , PyObject *ob ) ;
extern Py_ssize_t _PySequence_IterSearch(PyObject *seq , PyObject *obj , int operation ) ;
extern int PySequence_In(PyObject *o , PyObject *value ) ;
extern Py_ssize_t PySequence_Index(PyObject *o , PyObject *value ) ;
extern PyObject *PySequence_InPlaceConcat(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PySequence_InPlaceRepeat(PyObject *o , Py_ssize_t count ) ;
extern int PyMapping_Check(PyObject *o ) ;
extern Py_ssize_t PyMapping_Size(PyObject *o ) ;
extern Py_ssize_t PyMapping_Length(PyObject *o ) ;
extern int PyMapping_HasKeyString(PyObject *o , char *key ) ;
extern int PyMapping_HasKey(PyObject *o , PyObject *key ) ;
extern PyObject *PyMapping_Keys(PyObject *o ) ;
extern PyObject *PyMapping_Values(PyObject *o ) ;
extern PyObject *PyMapping_Items(PyObject *o ) ;
extern PyObject *PyMapping_GetItemString(PyObject *o , char *key ) ;
extern int PyMapping_SetItemString(PyObject *o , char *key , PyObject *value ) ;
extern int PyObject_IsInstance(PyObject *object , PyObject *typeorclass ) ;
extern int PyObject_IsSubclass(PyObject *object , PyObject *typeorclass ) ;
extern int _PyObject_RealIsInstance(PyObject *inst , PyObject *cls ) ;
extern int _PyObject_RealIsSubclass(PyObject *derived , PyObject *cls ) ;
extern char * const  *_PySequence_BytesToCharpArray(PyObject *self ) ;
extern void _Py_FreeCharPArray(char * const  *array ) ;
extern void _Py_add_one_to_index_F(int nd , Py_ssize_t *index , Py_ssize_t const   *shape ) ;
extern void _Py_add_one_to_index_C(int nd , Py_ssize_t *index , Py_ssize_t const   *shape ) ;
extern PyTypeObject PyFilter_Type ;
extern PyTypeObject PyMap_Type ;
extern PyTypeObject PyZip_Type ;
extern PyTypeObject PyCode_Type ;
extern PyCodeObject *PyCode_New(int  , int  , int  , int  , int  , PyObject * , PyObject * , PyObject * , PyObject * , PyObject * , PyObject * , PyObject * , PyObject * , int  , PyObject * ) ;
extern PyCodeObject *PyCode_NewEmpty(char const   *filename , char const   *funcname , int firstlineno ) ;
extern int PyCode_Addr2Line(PyCodeObject * , int  ) ;
extern int _PyCode_CheckLineNumber(PyCodeObject *co , int lasti , PyAddrPair *bounds ) ;
extern PyObject *PyCode_Optimize(PyObject *code , PyObject *consts , PyObject *names , PyObject *lineno_obj ) ;
extern PyCodeObject *PyNode_Compile(struct _node * , char const   * ) ;
extern PyCodeObject *PyAST_CompileEx(struct _mod *mod , char const   *filename , PyCompilerFlags *flags , int optimize , PyArena *arena ) ;
extern PyFutureFeatures *PyFuture_FromAST(struct _mod * , char const   * ) ;
extern PyObject *PyEval_EvalCode(PyObject * , PyObject * , PyObject * ) ;
extern PyObject *PyEval_EvalCodeEx(PyObject *co , PyObject *globals , PyObject *locals , PyObject **args , int argc , PyObject **kwds , int kwdc , PyObject **defs , int defc , PyObject *kwdefs , PyObject *closure ) ;
extern PyObject *_PyEval_CallTracing(PyObject *func , PyObject *args ) ;
extern unsigned int const   _Py_ctype_table[256] ;
extern unsigned char const   _Py_ctype_tolower[256] ;
extern unsigned char const   _Py_ctype_toupper[256] ;
extern double PyOS_string_to_double(char const   *str , char **endptr , PyObject *overflow_exception ) ;
extern char *PyOS_double_to_string(double val , char format_code , int precision , int flags , int *type ) ;
extern double _Py_parse_inf_or_nan(char const   *p , char **endptr ) ;
extern int PyOS_mystrnicmp(char const   * , char const   * , Py_ssize_t  ) ;
extern int PyOS_mystricmp(char const   * , char const   * ) ;
extern double _Py_dg_strtod(char const   *str , char **ptr ) ;
extern char *_Py_dg_dtoa(double d , int mode , int ndigits , int *decpt , int *sign , char **rve ) ;
extern void _Py_dg_freedtoa(char *s ) ;
extern wchar_t *_Py_char2wchar(char const   *arg , size_t *size ) ;
extern char *_Py_wchar2char(wchar_t const   *text , size_t *error_pos ) ;
extern int _Py_wstat(wchar_t const   *path , struct stat *buf ) ;
extern int _Py_stat(PyObject *path , struct stat *statbuf ) ;
extern FILE *_Py_wfopen(wchar_t const   *path , wchar_t const   *mode ) ;
extern FILE *_Py_fopen(PyObject *path , char const   *mode ) ;
extern int _Py_wreadlink(wchar_t const   *path , wchar_t *buf , size_t bufsiz ) ;
extern wchar_t *_Py_wrealpath(wchar_t const   *path , wchar_t *resolved_path , size_t resolved_path_size ) ;
extern wchar_t *_Py_wgetcwd(wchar_t *buf , size_t size ) ;
extern PyObject *_Py_Mangle(PyObject *p , PyObject *name ) ;
extern PyObject *PyMember_GetOne(char const   * , struct PyMemberDef * ) ;
extern int PyMember_SetOne(char * , struct PyMemberDef * , PyObject * ) ;
extern char const   *zlibVersion(void) ;
extern int deflate(z_streamp strm , int flush ) ;
extern int deflateEnd(z_streamp strm ) ;
extern int inflate(z_streamp strm , int flush ) ;
extern int inflateEnd(z_streamp strm ) ;
extern int deflateSetDictionary(z_streamp strm , Bytef const   *dictionary , uInt dictLength ) ;
extern int deflateCopy(z_streamp dest , z_streamp source ) ;
extern int deflateReset(z_streamp strm ) ;
extern int deflateParams(z_streamp strm , int level , int strategy ) ;
extern int deflateTune(z_streamp strm , int good_length , int max_lazy , int nice_length , int max_chain ) ;
extern uLong deflateBound(z_streamp strm , uLong sourceLen ) ;
extern int deflatePrime(z_streamp strm , int bits , int value ) ;
extern int deflateSetHeader(z_streamp strm , gz_headerp head ) ;
extern int inflateSetDictionary(z_streamp strm , Bytef const   *dictionary , uInt dictLength ) ;
extern int inflateSync(z_streamp strm ) ;
extern int inflateCopy(z_streamp dest , z_streamp source ) ;
extern int inflateReset(z_streamp strm ) ;
extern int inflatePrime(z_streamp strm , int bits , int value ) ;
extern int inflateGetHeader(z_streamp strm , gz_headerp head ) ;
extern int inflateBack(z_streamp strm , unsigned int (*in)(void * , unsigned char ** ) , void *in_desc , int (*out)(void * , unsigned char * , unsigned int  ) , void *out_desc ) ;
extern int inflateBackEnd(z_streamp strm ) ;
extern uLong zlibCompileFlags(void) ;
extern int compress(Bytef *dest , uLongf *destLen , Bytef const   *source , uLong sourceLen ) ;
extern int compress2(Bytef *dest , uLongf *destLen , Bytef const   *source , uLong sourceLen , int level ) ;
extern uLong compressBound(uLong sourceLen ) ;
extern int uncompress(Bytef *dest , uLongf *destLen , Bytef const   *source , uLong sourceLen ) ;
extern gzFile gzopen(char const   *path , char const   *mode ) ;
extern gzFile gzdopen(int fd , char const   *mode ) ;
extern int gzsetparams(gzFile file , int level , int strategy ) ;
extern int gzread(gzFile file , voidp buf , unsigned int len ) ;
extern int gzwrite(gzFile file , voidpc buf , unsigned int len ) ;
extern int gzprintf(gzFile file , char const   *format  , ...) ;
extern int gzputs(gzFile file , char const   *s ) ;
extern char *gzgets(gzFile file , char *buf , int len ) ;
extern int gzputc(gzFile file , int c ) ;
extern int gzgetc(gzFile file ) ;
extern int gzungetc(int c , gzFile file ) ;
extern int gzflush(gzFile file , int flush ) ;
extern off_t gzseek(gzFile file , off_t offset , int whence ) ;
extern int gzrewind(gzFile file ) ;
extern off_t gztell(gzFile file ) ;
extern int gzeof(gzFile file ) ;
extern int gzdirect(gzFile file ) ;
extern int gzclose(gzFile file ) ;
extern char const   *gzerror(gzFile file , int *errnum ) ;
extern void gzclearerr(gzFile file ) ;
extern uLong adler32(uLong adler , Bytef const   *buf , uInt len ) ;
extern uLong adler32_combine(uLong adler1 , uLong adler2 , off_t len2 ) ;
extern uLong crc32(uLong crc , Bytef const   *buf , uInt len ) ;
extern uLong crc32_combine(uLong crc1 , uLong crc2 , off_t len2 ) ;
extern int deflateInit_(z_streamp strm , int level , char const   *version , int stream_size ) ;
extern int inflateInit_(z_streamp strm , char const   *version , int stream_size ) ;
extern int deflateInit2_(z_streamp strm , int level , int method , int windowBits , int memLevel , int strategy , char const   *version , int stream_size ) ;
extern int inflateInit2_(z_streamp strm , int windowBits , char const   *version , int stream_size ) ;
extern int inflateBackInit_(z_streamp strm , int windowBits , unsigned char *window , char const   *version , int stream_size ) ;
extern char const   *zError(int  ) ;
extern int inflateSyncPoint(z_streamp z ) ;
extern uLongf const   *get_crc_table(void) ;
extern void PyThread_init_thread(void) ;
extern long PyThread_start_new_thread(void (*)(void * ) , void * ) ;
extern void PyThread_exit_thread(void) ;
extern long PyThread_get_thread_ident(void) ;
extern PyThread_type_lock PyThread_allocate_lock(void) ;
extern void PyThread_free_lock(PyThread_type_lock  ) ;
extern int PyThread_acquire_lock(PyThread_type_lock  , int  ) ;
extern PyLockStatus PyThread_acquire_lock_timed(PyThread_type_lock  , long long microseconds , int intr_flag ) ;
extern void PyThread_release_lock(PyThread_type_lock  ) ;
extern size_t PyThread_get_stacksize(void) ;
extern int PyThread_set_stacksize(size_t  ) ;
extern PyObject *PyThread_GetInfo(void) ;
extern int PyThread_create_key(void) ;
extern void PyThread_delete_key(int  ) ;
extern int PyThread_set_key_value(int  , void * ) ;
extern void *PyThread_get_key_value(int  ) ;
extern void PyThread_delete_key_value(int key ) ;
extern void PyThread_ReInitTLS(void) ;
static PyTypeObject Comptype ;
static PyTypeObject Decomptype ;
static PyObject *ZlibError  ;
static void zlib_error(z_stream zst , int err , char *msg ) 
{ char const   *zmsg ;

  {
  zmsg = (char const   *)zst.msg;
  if ((unsigned int )zmsg == (unsigned int )((char const   *)0)) {
    switch (err) {
    case -5: 
    zmsg = "incomplete or truncated stream";
    break;
    case -2: 
    zmsg = "inconsistent stream state";
    break;
    case -3: 
    zmsg = "invalid input data";
    break;
    }
  } else {

  }
  if ((unsigned int )zmsg == (unsigned int )((char const   *)0)) {
    PyErr_Format(ZlibError, "Error %d %s", err, msg);
  } else {
    PyErr_Format(ZlibError, "Error %d %s: %.200s", err, msg, zmsg);
  }
  return;
}
}
static char compressobj__doc__[106]  = 
  {      (char )'c',      (char )'o',      (char )'m',      (char )'p', 
        (char )'r',      (char )'e',      (char )'s',      (char )'s', 
        (char )'o',      (char )'b',      (char )'j',      (char )'(', 
        (char )'[',      (char )'l',      (char )'e',      (char )'v', 
        (char )'e',      (char )'l',      (char )']',      (char )')', 
        (char )' ',      (char )'-',      (char )'-',      (char )' ', 
        (char )'R',      (char )'e',      (char )'t',      (char )'u', 
        (char )'r',      (char )'n',      (char )' ',      (char )'a', 
        (char )' ',      (char )'c',      (char )'o',      (char )'m', 
        (char )'p',      (char )'r',      (char )'e',      (char )'s', 
        (char )'s',      (char )'o',      (char )'r',      (char )' ', 
        (char )'o',      (char )'b',      (char )'j',      (char )'e', 
        (char )'c',      (char )'t',      (char )'.',      (char )'\n', 
        (char )'\n',      (char )'O',      (char )'p',      (char )'t', 
        (char )'i',      (char )'o',      (char )'n',      (char )'a', 
        (char )'l',      (char )' ',      (char )'a',      (char )'r', 
        (char )'g',      (char )' ',      (char )'l',      (char )'e', 
        (char )'v',      (char )'e',      (char )'l',      (char )' ', 
        (char )'i',      (char )'s',      (char )' ',      (char )'t', 
        (char )'h',      (char )'e',      (char )' ',      (char )'c', 
        (char )'o',      (char )'m',      (char )'p',      (char )'r', 
        (char )'e',      (char )'s',      (char )'s',      (char )'i', 
        (char )'o',      (char )'n',      (char )' ',      (char )'l', 
        (char )'e',      (char )'v',      (char )'e',      (char )'l', 
        (char )',',      (char )' ',      (char )'i',      (char )'n', 
        (char )' ',      (char )'1',      (char )'-',      (char )'9', 
        (char )'.',      (char )'\000'};
static char decompressobj__doc__[103]  = 
  {      (char )'d',      (char )'e',      (char )'c',      (char )'o', 
        (char )'m',      (char )'p',      (char )'r',      (char )'e', 
        (char )'s',      (char )'s',      (char )'o',      (char )'b', 
        (char )'j',      (char )'(',      (char )'[',      (char )'w', 
        (char )'b',      (char )'i',      (char )'t',      (char )'s', 
        (char )']',      (char )')',      (char )' ',      (char )'-', 
        (char )'-',      (char )' ',      (char )'R',      (char )'e', 
        (char )'t',      (char )'u',      (char )'r',      (char )'n', 
        (char )' ',      (char )'a',      (char )' ',      (char )'d', 
        (char )'e',      (char )'c',      (char )'o',      (char )'m', 
        (char )'p',      (char )'r',      (char )'e',      (char )'s', 
        (char )'s',      (char )'o',      (char )'r',      (char )' ', 
        (char )'o',      (char )'b',      (char )'j',      (char )'e', 
        (char )'c',      (char )'t',      (char )'.',      (char )'\n', 
        (char )'\n',      (char )'O',      (char )'p',      (char )'t', 
        (char )'i',      (char )'o',      (char )'n',      (char )'a', 
        (char )'l',      (char )' ',      (char )'a',      (char )'r', 
        (char )'g',      (char )' ',      (char )'w',      (char )'b', 
        (char )'i',      (char )'t',      (char )'s',      (char )' ', 
        (char )'i',      (char )'s',      (char )' ',      (char )'t', 
        (char )'h',      (char )'e',      (char )' ',      (char )'w', 
        (char )'i',      (char )'n',      (char )'d',      (char )'o', 
        (char )'w',      (char )' ',      (char )'b',      (char )'u', 
        (char )'f',      (char )'f',      (char )'e',      (char )'r', 
        (char )' ',      (char )'s',      (char )'i',      (char )'z', 
        (char )'e',      (char )'.',      (char )'\000'};
static compobject *newcompobject(PyTypeObject *type ) 
{ compobject *self ;
  PyObject *tmp ;

  {
  tmp = _PyObject_New(type);
  self = (compobject *)tmp;
  if ((unsigned int )self == (unsigned int )((void *)0)) {
    return ((compobject *)((void *)0));
  } else {

  }
  self->is_initialised = 0;
  self->unused_data = PyBytes_FromStringAndSize("", 0);
  if ((unsigned int )self->unused_data == (unsigned int )((void *)0)) {
    while (1) {
      (((PyObject *)self)->ob_refcnt) --;
      if (((PyObject *)self)->ob_refcnt != 0) {

      } else {
        (*((((PyObject *)self)->ob_type)->tp_dealloc))((PyObject *)self);
      }
      break;
    }
    return ((compobject *)((void *)0));
  } else {

  }
  self->unconsumed_tail = PyBytes_FromStringAndSize("", 0);
  if ((unsigned int )self->unconsumed_tail == (unsigned int )((void *)0)) {
    while (1) {
      (((PyObject *)self)->ob_refcnt) --;
      if (((PyObject *)self)->ob_refcnt != 0) {

      } else {
        (*((((PyObject *)self)->ob_type)->tp_dealloc))((PyObject *)self);
      }
      break;
    }
    return ((compobject *)((void *)0));
  } else {

  }
  self->lock = PyThread_allocate_lock();
  return (self);
}
}
static char compress__doc__[111]  = 
  {      (char )'c',      (char )'o',      (char )'m',      (char )'p', 
        (char )'r',      (char )'e',      (char )'s',      (char )'s', 
        (char )'(',      (char )'s',      (char )'t',      (char )'r', 
        (char )'i',      (char )'n',      (char )'g',      (char )'[', 
        (char )',',      (char )' ',      (char )'l',      (char )'e', 
        (char )'v',      (char )'e',      (char )'l',      (char )']', 
        (char )')',      (char )' ',      (char )'-',      (char )'-', 
        (char )' ',      (char )'R',      (char )'e',      (char )'t', 
        (char )'u',      (char )'r',      (char )'n',      (char )'e', 
        (char )'d',      (char )' ',      (char )'c',      (char )'o', 
        (char )'m',      (char )'p',      (char )'r',      (char )'e', 
        (char )'s',      (char )'s',      (char )'e',      (char )'d', 
        (char )' ',      (char )'s',      (char )'t',      (char )'r', 
        (char )'i',      (char )'n',      (char )'g',      (char )'.', 
        (char )'\n',      (char )'\n',      (char )'O',      (char )'p', 
        (char )'t',      (char )'i',      (char )'o',      (char )'n', 
        (char )'a',      (char )'l',      (char )' ',      (char )'a', 
        (char )'r',      (char )'g',      (char )' ',      (char )'l', 
        (char )'e',      (char )'v',      (char )'e',      (char )'l', 
        (char )' ',      (char )'i',      (char )'s',      (char )' ', 
        (char )'t',      (char )'h',      (char )'e',      (char )' ', 
        (char )'c',      (char )'o',      (char )'m',      (char )'p', 
        (char )'r',      (char )'e',      (char )'s',      (char )'s', 
        (char )'i',      (char )'o',      (char )'n',      (char )' ', 
        (char )'l',      (char )'e',      (char )'v',      (char )'e', 
        (char )'l',      (char )',',      (char )' ',      (char )'i', 
        (char )'n',      (char )' ',      (char )'1',      (char )'-', 
        (char )'9',      (char )'.',      (char )'\000'};
static PyObject *PyZlib_compress(PyObject *self , PyObject *args ) 
{ PyObject *ReturnVal ;
  Py_buffer pinput ;
  Byte *input ;
  Byte *output ;
  unsigned int length ;
  int level ;
  int err ;
  z_stream zst ;
  int tmp ;
  void *tmp___0 ;
  PyThreadState *_save ;

  {
  ReturnVal = (PyObject *)((void *)0);
  level = -1;
  tmp = PyArg_ParseTuple(args, "y*|i:compress", & pinput, & level);
  if (tmp) {

  } else {
    return ((PyObject *)((void *)0));
  }
  if ((unsigned int )pinput.len > 4294967295U) {
    PyErr_SetString(PyExc_OverflowError, "size does not fit in an unsigned int");
    return ((PyObject *)((void *)0));
  } else {

  }
  length = (unsigned int )pinput.len;
  input = (Byte *)pinput.buf;
  zst.avail_out = ((length + length / 1000U) + 12U) + 1U;
  tmp___0 = malloc(zst.avail_out);
  output = (Byte *)tmp___0;
  if ((unsigned int )output == (unsigned int )((void *)0)) {
    PyBuffer_Release(& pinput);
    PyErr_SetString(PyExc_MemoryError, "Can\'t allocate memory to compress data");
    return ((PyObject *)((void *)0));
  } else {

  }
  zst.zalloc = (voidpf (*)(voidpf opaque , uInt items , uInt size ))((void *)0);
  zst.zfree = (void (*)(voidpf opaque , voidpf address ))0;
  zst.next_out = output;
  zst.next_in = input;
  zst.avail_in = length;
  err = deflateInit_(& zst, level, "1.2.3", (int )sizeof(z_stream ));
  switch (err) {
  case 0: 
  break;
  case -4: 
  PyErr_SetString(PyExc_MemoryError, "Out of memory while compressing data");
  goto error;
  case -2: 
  PyErr_SetString(ZlibError, "Bad compression level");
  goto error;
  default: 
  deflateEnd(& zst);
  zlib_error(zst, err, (char *)"while compressing data");
  goto error;
  }
  _save = PyEval_SaveThread();
  err = deflate(& zst, 4);
  PyEval_RestoreThread(_save);
  if (err != 1) {
    zlib_error(zst, err, (char *)"while compressing data");
    deflateEnd(& zst);
    goto error;
  } else {

  }
  err = deflateEnd(& zst);
  if (err == 0) {
    ReturnVal = PyBytes_FromStringAndSize((char const   *)((char *)output), (int )zst.total_out);
  } else {
    zlib_error(zst, err, (char *)"while finishing compression");
  }
  error: 
  PyBuffer_Release(& pinput);
  free((void *)output);
  return (ReturnVal);
}
}
static char decompress__doc__[174]  = 
  {      (char )'d',      (char )'e',      (char )'c',      (char )'o', 
        (char )'m',      (char )'p',      (char )'r',      (char )'e', 
        (char )'s',      (char )'s',      (char )'(',      (char )'s', 
        (char )'t',      (char )'r',      (char )'i',      (char )'n', 
        (char )'g',      (char )'[',      (char )',',      (char )' ', 
        (char )'w',      (char )'b',      (char )'i',      (char )'t', 
        (char )'s',      (char )'[',      (char )',',      (char )' ', 
        (char )'b',      (char )'u',      (char )'f',      (char )'s', 
        (char )'i',      (char )'z',      (char )'e',      (char )']', 
        (char )']',      (char )')',      (char )' ',      (char )'-', 
        (char )'-',      (char )' ',      (char )'R',      (char )'e', 
        (char )'t',      (char )'u',      (char )'r',      (char )'n', 
        (char )' ',      (char )'d',      (char )'e',      (char )'c', 
        (char )'o',      (char )'m',      (char )'p',      (char )'r', 
        (char )'e',      (char )'s',      (char )'s',      (char )'e', 
        (char )'d',      (char )' ',      (char )'s',      (char )'t', 
        (char )'r',      (char )'i',      (char )'n',      (char )'g', 
        (char )'.',      (char )'\n',      (char )'\n',      (char )'O', 
        (char )'p',      (char )'t',      (char )'i',      (char )'o', 
        (char )'n',      (char )'a',      (char )'l',      (char )' ', 
        (char )'a',      (char )'r',      (char )'g',      (char )' ', 
        (char )'w',      (char )'b',      (char )'i',      (char )'t', 
        (char )'s',      (char )' ',      (char )'i',      (char )'s', 
        (char )' ',      (char )'t',      (char )'h',      (char )'e', 
        (char )' ',      (char )'w',      (char )'i',      (char )'n', 
        (char )'d',      (char )'o',      (char )'w',      (char )' ', 
        (char )'b',      (char )'u',      (char )'f',      (char )'f', 
        (char )'e',      (char )'r',      (char )' ',      (char )'s', 
        (char )'i',      (char )'z',      (char )'e',      (char )'.', 
        (char )' ',      (char )' ',      (char )'O',      (char )'p', 
        (char )'t',      (char )'i',      (char )'o',      (char )'n', 
        (char )'a',      (char )'l',      (char )' ',      (char )'a', 
        (char )'r',      (char )'g',      (char )' ',      (char )'b', 
        (char )'u',      (char )'f',      (char )'s',      (char )'i', 
        (char )'z',      (char )'e',      (char )' ',      (char )'i', 
        (char )'s',      (char )'\n',      (char )'t',      (char )'h', 
        (char )'e',      (char )' ',      (char )'i',      (char )'n', 
        (char )'i',      (char )'t',      (char )'i',      (char )'a', 
        (char )'l',      (char )' ',      (char )'o',      (char )'u', 
        (char )'t',      (char )'p',      (char )'u',      (char )'t', 
        (char )' ',      (char )'b',      (char )'u',      (char )'f', 
        (char )'f',      (char )'e',      (char )'r',      (char )' ', 
        (char )'s',      (char )'i',      (char )'z',      (char )'e', 
        (char )'.',      (char )'\000'};
static PyObject *PyZlib_decompress(PyObject *self , PyObject *args ) 
{ PyObject *result_str ;
  Py_buffer pinput ;
  Byte *input ;
  unsigned int length ;
  int err ;
  int wsize ;
  Py_ssize_t r_strlen ;
  z_stream zst ;
  int tmp ;
  PyThreadState *_save ;
  int tmp___0 ;
  int tmp___1 ;

  {
  wsize = 15;
  r_strlen = 16384;
  tmp = PyArg_ParseTuple(args, "y*|in:decompress", & pinput, & wsize, & r_strlen);
  if (tmp) {

  } else {
    return ((PyObject *)((void *)0));
  }
  if ((unsigned int )pinput.len > 4294967295U) {
    PyErr_SetString(PyExc_OverflowError, "size does not fit in an unsigned int");
    return ((PyObject *)((void *)0));
  } else {

  }
  length = (unsigned int )pinput.len;
  input = (Byte *)pinput.buf;
  if (r_strlen <= 0) {
    r_strlen = 1;
  } else {

  }
  zst.avail_in = length;
  zst.avail_out = (unsigned int )r_strlen;
  result_str = PyBytes_FromStringAndSize((char const   *)((void *)0), r_strlen);
  if (result_str) {

  } else {
    PyBuffer_Release(& pinput);
    return ((PyObject *)((void *)0));
  }
  zst.zalloc = (voidpf (*)(voidpf opaque , uInt items , uInt size ))((void *)0);
  zst.zfree = (void (*)(voidpf opaque , voidpf address ))0;
  zst.next_out = (Byte *)(((PyBytesObject *)result_str)->ob_sval);
  zst.next_in = input;
  err = inflateInit2_(& zst, wsize, "1.2.3", (int )sizeof(z_stream ));
  switch (err) {
  case 0: 
  break;
  case -4: 
  PyErr_SetString(PyExc_MemoryError, "Out of memory while decompressing data");
  goto error;
  default: 
  inflateEnd(& zst);
  zlib_error(zst, err, (char *)"while preparing to decompress data");
  goto error;
  }
  while (1) {
    _save = PyEval_SaveThread();
    err = inflate(& zst, 4);
    PyEval_RestoreThread(_save);
    switch (err) {
    case 1: 
    break;
    case -5: 
    if (zst.avail_out > 0U) {
      zlib_error(zst, err, (char *)"while decompressing data");
      inflateEnd(& zst);
      goto error;
    } else {

    }
    case 0: 
    tmp___0 = _PyBytes_Resize(& result_str, r_strlen << 1);
    if (tmp___0 < 0) {
      inflateEnd(& zst);
      goto error;
    } else {

    }
    zst.next_out = (unsigned char *)(((PyBytesObject *)result_str)->ob_sval) + r_strlen;
    zst.avail_out = (unsigned int )r_strlen;
    r_strlen <<= 1;
    break;
    default: 
    inflateEnd(& zst);
    zlib_error(zst, err, (char *)"while decompressing data");
    goto error;
    }
    if (err != 1) {

    } else {
      break;
    }
  }
  err = inflateEnd(& zst);
  if (err != 0) {
    zlib_error(zst, err, (char *)"while finishing data decompression");
    goto error;
  } else {

  }
  tmp___1 = _PyBytes_Resize(& result_str, (int )zst.total_out);
  if (tmp___1 < 0) {
    goto error;
  } else {

  }
  PyBuffer_Release(& pinput);
  return (result_str);
  error: 
  PyBuffer_Release(& pinput);
  while (1) {
    if ((unsigned int )result_str == (unsigned int )((void *)0)) {

    } else {
      while (1) {
        (result_str->ob_refcnt) --;
        if (result_str->ob_refcnt != 0) {

        } else {
          (*((result_str->ob_type)->tp_dealloc))(result_str);
        }
        break;
      }
    }
    break;
  }
  return ((PyObject *)((void *)0));
}
}
static PyObject *PyZlib_compressobj(PyObject *selfptr , PyObject *args ) 
{ compobject *self ;
  int level ;
  int method ;
  int wbits ;
  int memLevel ;
  int strategy ;
  int err ;
  int tmp ;

  {
  level = -1;
  method = 8;
  wbits = 15;
  memLevel = 8;
  strategy = 0;
  tmp = PyArg_ParseTuple(args, "|iiiii:compressobj", & level, & method, & wbits, & memLevel, & strategy);
  if (tmp) {

  } else {
    return ((PyObject *)((void *)0));
  }
  self = newcompobject(& Comptype);
  if ((unsigned int )self == (unsigned int )((void *)0)) {
    return ((PyObject *)((void *)0));
  } else {

  }
  self->zst.zalloc = (voidpf (*)(voidpf opaque , uInt items , uInt size ))((void *)0);
  self->zst.zfree = (void (*)(voidpf opaque , voidpf address ))0;
  self->zst.next_in = (Bytef *)((void *)0);
  self->zst.avail_in = 0U;
  err = deflateInit2_(& self->zst, level, method, wbits, memLevel, strategy, "1.2.3", (int )sizeof(z_stream ));
  switch (err) {
  case 0: 
  self->is_initialised = 1;
  return ((PyObject *)self);
  case -4: 
  while (1) {
    (((PyObject *)self)->ob_refcnt) --;
    if (((PyObject *)self)->ob_refcnt != 0) {

    } else {
      (*((((PyObject *)self)->ob_type)->tp_dealloc))((PyObject *)self);
    }
    break;
  }
  PyErr_SetString(PyExc_MemoryError, "Can\'t allocate memory for compression object");
  return ((PyObject *)((void *)0));
  case -2: 
  while (1) {
    (((PyObject *)self)->ob_refcnt) --;
    if (((PyObject *)self)->ob_refcnt != 0) {

    } else {
      (*((((PyObject *)self)->ob_type)->tp_dealloc))((PyObject *)self);
    }
    break;
  }
  PyErr_SetString(PyExc_ValueError, "Invalid initialization option");
  return ((PyObject *)((void *)0));
  default: 
  zlib_error(self->zst, err, (char *)"while creating compression object");
  while (1) {
    (((PyObject *)self)->ob_refcnt) --;
    if (((PyObject *)self)->ob_refcnt != 0) {

    } else {
      (*((((PyObject *)self)->ob_type)->tp_dealloc))((PyObject *)self);
    }
    break;
  }
  return ((PyObject *)((void *)0));
  }
}
}
static PyObject *PyZlib_decompressobj(PyObject *selfptr , PyObject *args ) 
{ int wbits ;
  int err ;
  compobject *self ;
  int tmp ;

  {
  wbits = 15;
  tmp = PyArg_ParseTuple(args, "|i:decompressobj", & wbits);
  if (tmp) {

  } else {
    return ((PyObject *)((void *)0));
  }
  self = newcompobject(& Decomptype);
  if ((unsigned int )self == (unsigned int )((void *)0)) {
    return ((PyObject *)((void *)0));
  } else {

  }
  self->zst.zalloc = (voidpf (*)(voidpf opaque , uInt items , uInt size ))((void *)0);
  self->zst.zfree = (void (*)(voidpf opaque , voidpf address ))0;
  self->zst.next_in = (Bytef *)((void *)0);
  self->zst.avail_in = 0U;
  err = inflateInit2_(& self->zst, wbits, "1.2.3", (int )sizeof(z_stream ));
  switch (err) {
  case 0: 
  self->is_initialised = 1;
  return ((PyObject *)self);
  case -2: 
  while (1) {
    (((PyObject *)self)->ob_refcnt) --;
    if (((PyObject *)self)->ob_refcnt != 0) {

    } else {
      (*((((PyObject *)self)->ob_type)->tp_dealloc))((PyObject *)self);
    }
    break;
  }
  PyErr_SetString(PyExc_ValueError, "Invalid initialization option");
  return ((PyObject *)((void *)0));
  case -4: 
  while (1) {
    (((PyObject *)self)->ob_refcnt) --;
    if (((PyObject *)self)->ob_refcnt != 0) {

    } else {
      (*((((PyObject *)self)->ob_type)->tp_dealloc))((PyObject *)self);
    }
    break;
  }
  PyErr_SetString(PyExc_MemoryError, "Can\'t allocate memory for decompression object");
  return ((PyObject *)((void *)0));
  default: 
  zlib_error(self->zst, err, (char *)"while creating decompression object");
  while (1) {
    (((PyObject *)self)->ob_refcnt) --;
    if (((PyObject *)self)->ob_refcnt != 0) {

    } else {
      (*((((PyObject *)self)->ob_type)->tp_dealloc))((PyObject *)self);
    }
    break;
  }
  return ((PyObject *)((void *)0));
  }
}
}
static void Dealloc(compobject *self ) 
{ 

  {
  PyThread_free_lock(self->lock);
  while (1) {
    if ((unsigned int )self->unused_data == (unsigned int )((void *)0)) {

    } else {
      while (1) {
        ((self->unused_data)->ob_refcnt) --;
        if ((self->unused_data)->ob_refcnt != 0) {

        } else {
          (*(((self->unused_data)->ob_type)->tp_dealloc))(self->unused_data);
        }
        break;
      }
    }
    break;
  }
  while (1) {
    if ((unsigned int )self->unconsumed_tail == (unsigned int )((void *)0)) {

    } else {
      while (1) {
        ((self->unconsumed_tail)->ob_refcnt) --;
        if ((self->unconsumed_tail)->ob_refcnt != 0) {

        } else {
          (*(((self->unconsumed_tail)->ob_type)->tp_dealloc))(self->unconsumed_tail);
        }
        break;
      }
    }
    break;
  }
  PyObject_Free((void *)self);
  return;
}
}
static void Comp_dealloc(compobject *self ) 
{ 

  {
  if (self->is_initialised) {
    deflateEnd(& self->zst);
  } else {

  }
  Dealloc(self);
  return;
}
}
static void Decomp_dealloc(compobject *self ) 
{ 

  {
  if (self->is_initialised) {
    inflateEnd(& self->zst);
  } else {

  }
  Dealloc(self);
  return;
}
}
static char comp_compress__doc__[225]  = 
  {      (char )'c',      (char )'o',      (char )'m',      (char )'p', 
        (char )'r',      (char )'e',      (char )'s',      (char )'s', 
        (char )'(',      (char )'d',      (char )'a',      (char )'t', 
        (char )'a',      (char )')',      (char )' ',      (char )'-', 
        (char )'-',      (char )' ',      (char )'R',      (char )'e', 
        (char )'t',      (char )'u',      (char )'r',      (char )'n', 
        (char )' ',      (char )'a',      (char )' ',      (char )'s', 
        (char )'t',      (char )'r',      (char )'i',      (char )'n', 
        (char )'g',      (char )' ',      (char )'c',      (char )'o', 
        (char )'n',      (char )'t',      (char )'a',      (char )'i', 
        (char )'n',      (char )'i',      (char )'n',      (char )'g', 
        (char )' ',      (char )'d',      (char )'a',      (char )'t', 
        (char )'a',      (char )' ',      (char )'c',      (char )'o', 
        (char )'m',      (char )'p',      (char )'r',      (char )'e', 
        (char )'s',      (char )'s',      (char )'e',      (char )'d', 
        (char )'.',      (char )'\n',      (char )'\n',      (char )'A', 
        (char )'f',      (char )'t',      (char )'e',      (char )'r', 
        (char )' ',      (char )'c',      (char )'a',      (char )'l', 
        (char )'l',      (char )'i',      (char )'n',      (char )'g', 
        (char )' ',      (char )'t',      (char )'h',      (char )'i', 
        (char )'s',      (char )' ',      (char )'f',      (char )'u', 
        (char )'n',      (char )'c',      (char )'t',      (char )'i', 
        (char )'o',      (char )'n',      (char )',',      (char )' ', 
        (char )'s',      (char )'o',      (char )'m',      (char )'e', 
        (char )' ',      (char )'o',      (char )'f',      (char )' ', 
        (char )'t',      (char )'h',      (char )'e',      (char )' ', 
        (char )'i',      (char )'n',      (char )'p',      (char )'u', 
        (char )'t',      (char )' ',      (char )'d',      (char )'a', 
        (char )'t',      (char )'a',      (char )' ',      (char )'m', 
        (char )'a',      (char )'y',      (char )' ',      (char )'s', 
        (char )'t',      (char )'i',      (char )'l',      (char )'l', 
        (char )'\n',      (char )'b',      (char )'e',      (char )' ', 
        (char )'s',      (char )'t',      (char )'o',      (char )'r', 
        (char )'e',      (char )'d',      (char )' ',      (char )'i', 
        (char )'n',      (char )' ',      (char )'i',      (char )'n', 
        (char )'t',      (char )'e',      (char )'r',      (char )'n', 
        (char )'a',      (char )'l',      (char )' ',      (char )'b', 
        (char )'u',      (char )'f',      (char )'f',      (char )'e', 
        (char )'r',      (char )'s',      (char )' ',      (char )'f', 
        (char )'o',      (char )'r',      (char )' ',      (char )'l', 
        (char )'a',      (char )'t',      (char )'e',      (char )'r', 
        (char )' ',      (char )'p',      (char )'r',      (char )'o', 
        (char )'c',      (char )'e',      (char )'s',      (char )'s', 
        (char )'i',      (char )'n',      (char )'g',      (char )'.', 
        (char )'\n',      (char )'C',      (char )'a',      (char )'l', 
        (char )'l',      (char )' ',      (char )'t',      (char )'h', 
        (char )'e',      (char )' ',      (char )'f',      (char )'l', 
        (char )'u',      (char )'s',      (char )'h',      (char )'(', 
        (char )')',      (char )' ',      (char )'m',      (char )'e', 
        (char )'t',      (char )'h',      (char )'o',      (char )'d', 
        (char )' ',      (char )'t',      (char )'o',      (char )' ', 
        (char )'c',      (char )'l',      (char )'e',      (char )'a', 
        (char )'r',      (char )' ',      (char )'t',      (char )'h', 
        (char )'e',      (char )'s',      (char )'e',      (char )' ', 
        (char )'b',      (char )'u',      (char )'f',      (char )'f', 
        (char )'e',      (char )'r',      (char )'s',      (char )'.', 
        (char )'\000'};
static PyObject *PyZlib_objcompress(compobject *self , PyObject *args ) 
{ int err ;
  int inplen ;
  Py_ssize_t length ;
  PyObject *RetVal ;
  Py_buffer pinput ;
  Byte *input ;
  unsigned long start_total_out ;
  int tmp ;
  PyThreadState *_save ;
  PyThreadState *_save___0 ;
  int tmp___0 ;
  PyThreadState *_save___1 ;
  int tmp___1 ;

  {
  length = 16384;
  tmp = PyArg_ParseTuple(args, "y*:compress", & pinput);
  if (tmp) {

  } else {
    return ((PyObject *)((void *)0));
  }
  input = (Byte *)pinput.buf;
  inplen = pinput.len;
  RetVal = PyBytes_FromStringAndSize((char const   *)((void *)0), length);
  if (RetVal) {

  } else {
    PyBuffer_Release(& pinput);
    return ((PyObject *)((void *)0));
  }
  _save = PyEval_SaveThread();
  PyThread_acquire_lock(self->lock, 1);
  PyEval_RestoreThread(_save);
  start_total_out = self->zst.total_out;
  self->zst.avail_in = (unsigned int )inplen;
  self->zst.next_in = input;
  self->zst.avail_out = (unsigned int )length;
  self->zst.next_out = (unsigned char *)(((PyBytesObject *)RetVal)->ob_sval);
  _save___0 = PyEval_SaveThread();
  err = deflate(& self->zst, 0);
  PyEval_RestoreThread(_save___0);
  while (1) {
    if (err == 0) {
      if (self->zst.avail_out == 0U) {

      } else {
        break;
      }
    } else {
      break;
    }
    tmp___0 = _PyBytes_Resize(& RetVal, length << 1);
    if (tmp___0 < 0) {
      while (1) {
        (RetVal->ob_refcnt) --;
        if (RetVal->ob_refcnt != 0) {

        } else {
          (*((RetVal->ob_type)->tp_dealloc))(RetVal);
        }
        break;
      }
      RetVal = (PyObject *)((void *)0);
      goto error;
    } else {

    }
    self->zst.next_out = (unsigned char *)(((PyBytesObject *)RetVal)->ob_sval) + length;
    self->zst.avail_out = (unsigned int )length;
    length <<= 1;
    _save___1 = PyEval_SaveThread();
    err = deflate(& self->zst, 0);
    PyEval_RestoreThread(_save___1);
  }
  if (err != 0) {
    if (err != -5) {
      zlib_error(self->zst, err, (char *)"while compressing");
      while (1) {
        (RetVal->ob_refcnt) --;
        if (RetVal->ob_refcnt != 0) {

        } else {
          (*((RetVal->ob_type)->tp_dealloc))(RetVal);
        }
        break;
      }
      RetVal = (PyObject *)((void *)0);
      goto error;
    } else {

    }
  } else {

  }
  tmp___1 = _PyBytes_Resize(& RetVal, (int )(self->zst.total_out - start_total_out));
  if (tmp___1 < 0) {
    while (1) {
      (RetVal->ob_refcnt) --;
      if (RetVal->ob_refcnt != 0) {

      } else {
        (*((RetVal->ob_type)->tp_dealloc))(RetVal);
      }
      break;
    }
    RetVal = (PyObject *)((void *)0);
  } else {

  }
  error: 
  PyThread_release_lock(self->lock);
  PyBuffer_Release(& pinput);
  return (RetVal);
}
}
static char decomp_decompress__doc__[430]  = 
  {      (char )'d',      (char )'e',      (char )'c',      (char )'o', 
        (char )'m',      (char )'p',      (char )'r',      (char )'e', 
        (char )'s',      (char )'s',      (char )'(',      (char )'d', 
        (char )'a',      (char )'t',      (char )'a',      (char )',', 
        (char )' ',      (char )'m',      (char )'a',      (char )'x', 
        (char )'_',      (char )'l',      (char )'e',      (char )'n', 
        (char )'g',      (char )'t',      (char )'h',      (char )')', 
        (char )' ',      (char )'-',      (char )'-',      (char )' ', 
        (char )'R',      (char )'e',      (char )'t',      (char )'u', 
        (char )'r',      (char )'n',      (char )' ',      (char )'a', 
        (char )' ',      (char )'s',      (char )'t',      (char )'r', 
        (char )'i',      (char )'n',      (char )'g',      (char )' ', 
        (char )'c',      (char )'o',      (char )'n',      (char )'t', 
        (char )'a',      (char )'i',      (char )'n',      (char )'i', 
        (char )'n',      (char )'g',      (char )' ',      (char )'t', 
        (char )'h',      (char )'e',      (char )' ',      (char )'d', 
        (char )'e',      (char )'c',      (char )'o',      (char )'m', 
        (char )'p',      (char )'r',      (char )'e',      (char )'s', 
        (char )'s',      (char )'e',      (char )'d',      (char )'\n', 
        (char )'v',      (char )'e',      (char )'r',      (char )'s', 
        (char )'i',      (char )'o',      (char )'n',      (char )' ', 
        (char )'o',      (char )'f',      (char )' ',      (char )'t', 
        (char )'h',      (char )'e',      (char )' ',      (char )'d', 
        (char )'a',      (char )'t',      (char )'a',      (char )'.', 
        (char )'\n',      (char )'\n',      (char )'A',      (char )'f', 
        (char )'t',      (char )'e',      (char )'r',      (char )' ', 
        (char )'c',      (char )'a',      (char )'l',      (char )'l', 
        (char )'i',      (char )'n',      (char )'g',      (char )' ', 
        (char )'t',      (char )'h',      (char )'i',      (char )'s', 
        (char )' ',      (char )'f',      (char )'u',      (char )'n', 
        (char )'c',      (char )'t',      (char )'i',      (char )'o', 
        (char )'n',      (char )',',      (char )' ',      (char )'s', 
        (char )'o',      (char )'m',      (char )'e',      (char )' ', 
        (char )'o',      (char )'f',      (char )' ',      (char )'t', 
        (char )'h',      (char )'e',      (char )' ',      (char )'i', 
        (char )'n',      (char )'p',      (char )'u',      (char )'t', 
        (char )' ',      (char )'d',      (char )'a',      (char )'t', 
        (char )'a',      (char )' ',      (char )'m',      (char )'a', 
        (char )'y',      (char )' ',      (char )'s',      (char )'t', 
        (char )'i',      (char )'l',      (char )'l',      (char )' ', 
        (char )'b',      (char )'e',      (char )' ',      (char )'s', 
        (char )'t',      (char )'o',      (char )'r',      (char )'e', 
        (char )'d',      (char )' ',      (char )'i',      (char )'n', 
        (char )'\n',      (char )'i',      (char )'n',      (char )'t', 
        (char )'e',      (char )'r',      (char )'n',      (char )'a', 
        (char )'l',      (char )' ',      (char )'b',      (char )'u', 
        (char )'f',      (char )'f',      (char )'e',      (char )'r', 
        (char )'s',      (char )' ',      (char )'f',      (char )'o', 
        (char )'r',      (char )' ',      (char )'l',      (char )'a', 
        (char )'t',      (char )'e',      (char )'r',      (char )' ', 
        (char )'p',      (char )'r',      (char )'o',      (char )'c', 
        (char )'e',      (char )'s',      (char )'s',      (char )'i', 
        (char )'n',      (char )'g',      (char )'.',      (char )'\n', 
        (char )'C',      (char )'a',      (char )'l',      (char )'l', 
        (char )' ',      (char )'t',      (char )'h',      (char )'e', 
        (char )' ',      (char )'f',      (char )'l',      (char )'u', 
        (char )'s',      (char )'h',      (char )'(',      (char )')', 
        (char )' ',      (char )'m',      (char )'e',      (char )'t', 
        (char )'h',      (char )'o',      (char )'d',      (char )' ', 
        (char )'t',      (char )'o',      (char )' ',      (char )'c', 
        (char )'l',      (char )'e',      (char )'a',      (char )'r', 
        (char )' ',      (char )'t',      (char )'h',      (char )'e', 
        (char )'s',      (char )'e',      (char )' ',      (char )'b', 
        (char )'u',      (char )'f',      (char )'f',      (char )'e', 
        (char )'r',      (char )'s',      (char )'.',      (char )'\n', 
        (char )'I',      (char )'f',      (char )' ',      (char )'t', 
        (char )'h',      (char )'e',      (char )' ',      (char )'m', 
        (char )'a',      (char )'x',      (char )'_',      (char )'l', 
        (char )'e',      (char )'n',      (char )'g',      (char )'t', 
        (char )'h',      (char )' ',      (char )'p',      (char )'a', 
        (char )'r',      (char )'a',      (char )'m',      (char )'e', 
        (char )'t',      (char )'e',      (char )'r',      (char )' ', 
        (char )'i',      (char )'s',      (char )' ',      (char )'s', 
        (char )'p',      (char )'e',      (char )'c',      (char )'i', 
        (char )'f',      (char )'i',      (char )'e',      (char )'d', 
        (char )' ',      (char )'t',      (char )'h',      (char )'e', 
        (char )'n',      (char )' ',      (char )'t',      (char )'h', 
        (char )'e',      (char )' ',      (char )'r',      (char )'e', 
        (char )'t',      (char )'u',      (char )'r',      (char )'n', 
        (char )' ',      (char )'v',      (char )'a',      (char )'l', 
        (char )'u',      (char )'e',      (char )' ',      (char )'w', 
        (char )'i',      (char )'l',      (char )'l',      (char )' ', 
        (char )'b',      (char )'e',      (char )'\n',      (char )'n', 
        (char )'o',      (char )' ',      (char )'l',      (char )'o', 
        (char )'n',      (char )'g',      (char )'e',      (char )'r', 
        (char )' ',      (char )'t',      (char )'h',      (char )'a', 
        (char )'n',      (char )' ',      (char )'m',      (char )'a', 
        (char )'x',      (char )'_',      (char )'l',      (char )'e', 
        (char )'n',      (char )'g',      (char )'t',      (char )'h', 
        (char )'.',      (char )' ',      (char )' ',      (char )'U', 
        (char )'n',      (char )'c',      (char )'o',      (char )'n', 
        (char )'s',      (char )'u',      (char )'m',      (char )'e', 
        (char )'d',      (char )' ',      (char )'i',      (char )'n', 
        (char )'p',      (char )'u',      (char )'t',      (char )' ', 
        (char )'d',      (char )'a',      (char )'t',      (char )'a', 
        (char )' ',      (char )'w',      (char )'i',      (char )'l', 
        (char )'l',      (char )' ',      (char )'b',      (char )'e', 
        (char )' ',      (char )'s',      (char )'t',      (char )'o', 
        (char )'r',      (char )'e',      (char )'d',      (char )' ', 
        (char )'i',      (char )'n',      (char )'\n',      (char )'t', 
        (char )'h',      (char )'e',      (char )' ',      (char )'u', 
        (char )'n',      (char )'c',      (char )'o',      (char )'n', 
        (char )'s',      (char )'u',      (char )'m',      (char )'e', 
        (char )'d',      (char )'_',      (char )'t',      (char )'a', 
        (char )'i',      (char )'l',      (char )' ',      (char )'a', 
        (char )'t',      (char )'t',      (char )'r',      (char )'i', 
        (char )'b',      (char )'u',      (char )'t',      (char )'e', 
        (char )'.',      (char )'\000'};
static PyObject *PyZlib_objdecompress(compobject *self , PyObject *args ) 
{ int err ;
  int inplen ;
  int max_length ;
  Py_ssize_t old_length ;
  Py_ssize_t length ;
  PyObject *RetVal ;
  Py_buffer pinput ;
  Byte *input ;
  unsigned long start_total_out ;
  int tmp ;
  PyThreadState *_save ;
  PyThreadState *_save___0 ;
  int tmp___0 ;
  PyThreadState *_save___1 ;
  int tmp___1 ;

  {
  max_length = 0;
  length = 16384;
  tmp = PyArg_ParseTuple(args, "y*|i:decompress", & pinput, & max_length);
  if (tmp) {

  } else {
    return ((PyObject *)((void *)0));
  }
  input = (Byte *)pinput.buf;
  inplen = pinput.len;
  if (max_length < 0) {
    PyBuffer_Release(& pinput);
    PyErr_SetString(PyExc_ValueError, "max_length must be greater than zero");
    return ((PyObject *)((void *)0));
  } else {

  }
  if (max_length) {
    if (length > max_length) {
      length = max_length;
    } else {

    }
  } else {

  }
  RetVal = PyBytes_FromStringAndSize((char const   *)((void *)0), length);
  if (RetVal) {

  } else {
    PyBuffer_Release(& pinput);
    return ((PyObject *)((void *)0));
  }
  _save = PyEval_SaveThread();
  PyThread_acquire_lock(self->lock, 1);
  PyEval_RestoreThread(_save);
  start_total_out = self->zst.total_out;
  self->zst.avail_in = (unsigned int )inplen;
  self->zst.next_in = input;
  self->zst.avail_out = (unsigned int )length;
  self->zst.next_out = (unsigned char *)(((PyBytesObject *)RetVal)->ob_sval);
  _save___0 = PyEval_SaveThread();
  err = inflate(& self->zst, 2);
  PyEval_RestoreThread(_save___0);
  while (1) {
    if (err == 0) {
      if (self->zst.avail_out == 0U) {

      } else {
        break;
      }
    } else {
      break;
    }
    if (max_length) {
      if (length >= max_length) {
        break;
      } else {

      }
    } else {

    }
    old_length = length;
    length <<= 1;
    if (max_length) {
      if (length > max_length) {
        length = max_length;
      } else {

      }
    } else {

    }
    tmp___0 = _PyBytes_Resize(& RetVal, length);
    if (tmp___0 < 0) {
      while (1) {
        (RetVal->ob_refcnt) --;
        if (RetVal->ob_refcnt != 0) {

        } else {
          (*((RetVal->ob_type)->tp_dealloc))(RetVal);
        }
        break;
      }
      RetVal = (PyObject *)((void *)0);
      goto error;
    } else {

    }
    self->zst.next_out = (unsigned char *)(((PyBytesObject *)RetVal)->ob_sval) + old_length;
    self->zst.avail_out = (unsigned int )(length - old_length);
    _save___1 = PyEval_SaveThread();
    err = inflate(& self->zst, 2);
    PyEval_RestoreThread(_save___1);
  }
  if (max_length) {
    while (1) {
      ((self->unconsumed_tail)->ob_refcnt) --;
      if ((self->unconsumed_tail)->ob_refcnt != 0) {

      } else {
        (*(((self->unconsumed_tail)->ob_type)->tp_dealloc))(self->unconsumed_tail);
      }
      break;
    }
    self->unconsumed_tail = PyBytes_FromStringAndSize((char const   *)((char *)self->zst.next_in), (int )self->zst.avail_in);
    if (! self->unconsumed_tail) {
      while (1) {
        (RetVal->ob_refcnt) --;
        if (RetVal->ob_refcnt != 0) {

        } else {
          (*((RetVal->ob_type)->tp_dealloc))(RetVal);
        }
        break;
      }
      RetVal = (PyObject *)((void *)0);
      goto error;
    } else {

    }
  } else {

  }
  if (err == 1) {
    while (1) {
      if ((unsigned int )self->unused_data == (unsigned int )((void *)0)) {

      } else {
        while (1) {
          ((self->unused_data)->ob_refcnt) --;
          if ((self->unused_data)->ob_refcnt != 0) {

          } else {
            (*(((self->unused_data)->ob_type)->tp_dealloc))(self->unused_data);
          }
          break;
        }
      }
      break;
    }
    self->unused_data = PyBytes_FromStringAndSize((char const   *)((char *)self->zst.next_in), (int )self->zst.avail_in);
    if ((unsigned int )self->unused_data == (unsigned int )((void *)0)) {
      while (1) {
        (RetVal->ob_refcnt) --;
        if (RetVal->ob_refcnt != 0) {

        } else {
          (*((RetVal->ob_type)->tp_dealloc))(RetVal);
        }
        break;
      }
      goto error;
    } else {

    }
  } else {
    if (err != 0) {
      if (err != -5) {
        zlib_error(self->zst, err, (char *)"while decompressing");
        while (1) {
          (RetVal->ob_refcnt) --;
          if (RetVal->ob_refcnt != 0) {

          } else {
            (*((RetVal->ob_type)->tp_dealloc))(RetVal);
          }
          break;
        }
        RetVal = (PyObject *)((void *)0);
        goto error;
      } else {

      }
    } else {

    }
  }
  tmp___1 = _PyBytes_Resize(& RetVal, (int )(self->zst.total_out - start_total_out));
  if (tmp___1 < 0) {
    while (1) {
      (RetVal->ob_refcnt) --;
      if (RetVal->ob_refcnt != 0) {

      } else {
        (*((RetVal->ob_type)->tp_dealloc))(RetVal);
      }
      break;
    }
    RetVal = (PyObject *)((void *)0);
  } else {

  }
  error: 
  PyThread_release_lock(self->lock);
  PyBuffer_Release(& pinput);
  return (RetVal);
}
}
static char comp_flush__doc__[358]  = 
  {      (char )'f',      (char )'l',      (char )'u',      (char )'s', 
        (char )'h',      (char )'(',      (char )' ',      (char )'[', 
        (char )'m',      (char )'o',      (char )'d',      (char )'e', 
        (char )']',      (char )' ',      (char )')',      (char )' ', 
        (char )'-',      (char )'-',      (char )' ',      (char )'R', 
        (char )'e',      (char )'t',      (char )'u',      (char )'r', 
        (char )'n',      (char )' ',      (char )'a',      (char )' ', 
        (char )'s',      (char )'t',      (char )'r',      (char )'i', 
        (char )'n',      (char )'g',      (char )' ',      (char )'c', 
        (char )'o',      (char )'n',      (char )'t',      (char )'a', 
        (char )'i',      (char )'n',      (char )'i',      (char )'n', 
        (char )'g',      (char )' ',      (char )'a',      (char )'n', 
        (char )'y',      (char )' ',      (char )'r',      (char )'e', 
        (char )'m',      (char )'a',      (char )'i',      (char )'n', 
        (char )'i',      (char )'n',      (char )'g',      (char )' ', 
        (char )'c',      (char )'o',      (char )'m',      (char )'p', 
        (char )'r',      (char )'e',      (char )'s',      (char )'s', 
        (char )'e',      (char )'d',      (char )' ',      (char )'d', 
        (char )'a',      (char )'t',      (char )'a',      (char )'.', 
        (char )'\n',      (char )'\n',      (char )'m',      (char )'o', 
        (char )'d',      (char )'e',      (char )' ',      (char )'c', 
        (char )'a',      (char )'n',      (char )' ',      (char )'b', 
        (char )'e',      (char )' ',      (char )'o',      (char )'n', 
        (char )'e',      (char )' ',      (char )'o',      (char )'f', 
        (char )' ',      (char )'t',      (char )'h',      (char )'e', 
        (char )' ',      (char )'c',      (char )'o',      (char )'n', 
        (char )'s',      (char )'t',      (char )'a',      (char )'n', 
        (char )'t',      (char )'s',      (char )' ',      (char )'Z', 
        (char )'_',      (char )'S',      (char )'Y',      (char )'N', 
        (char )'C',      (char )'_',      (char )'F',      (char )'L', 
        (char )'U',      (char )'S',      (char )'H',      (char )',', 
        (char )' ',      (char )'Z',      (char )'_',      (char )'F', 
        (char )'U',      (char )'L',      (char )'L',      (char )'_', 
        (char )'F',      (char )'L',      (char )'U',      (char )'S', 
        (char )'H',      (char )',',      (char )' ',      (char )'Z', 
        (char )'_',      (char )'F',      (char )'I',      (char )'N', 
        (char )'I',      (char )'S',      (char )'H',      (char )';', 
        (char )' ',      (char )'t',      (char )'h',      (char )'e', 
        (char )'\n',      (char )'d',      (char )'e',      (char )'f', 
        (char )'a',      (char )'u',      (char )'l',      (char )'t', 
        (char )' ',      (char )'v',      (char )'a',      (char )'l', 
        (char )'u',      (char )'e',      (char )' ',      (char )'u', 
        (char )'s',      (char )'e',      (char )'d',      (char )' ', 
        (char )'w',      (char )'h',      (char )'e',      (char )'n', 
        (char )' ',      (char )'m',      (char )'o',      (char )'d', 
        (char )'e',      (char )' ',      (char )'i',      (char )'s', 
        (char )' ',      (char )'n',      (char )'o',      (char )'t', 
        (char )' ',      (char )'s',      (char )'p',      (char )'e', 
        (char )'c',      (char )'i',      (char )'f',      (char )'i', 
        (char )'e',      (char )'d',      (char )' ',      (char )'i', 
        (char )'s',      (char )' ',      (char )'Z',      (char )'_', 
        (char )'F',      (char )'I',      (char )'N',      (char )'I', 
        (char )'S',      (char )'H',      (char )'.',      (char )'\n', 
        (char )'I',      (char )'f',      (char )' ',      (char )'m', 
        (char )'o',      (char )'d',      (char )'e',      (char )' ', 
        (char )'=',      (char )'=',      (char )' ',      (char )'Z', 
        (char )'_',      (char )'F',      (char )'I',      (char )'N', 
        (char )'I',      (char )'S',      (char )'H',      (char )',', 
        (char )' ',      (char )'t',      (char )'h',      (char )'e', 
        (char )' ',      (char )'c',      (char )'o',      (char )'m', 
        (char )'p',      (char )'r',      (char )'e',      (char )'s', 
        (char )'s',      (char )'o',      (char )'r',      (char )' ', 
        (char )'o',      (char )'b',      (char )'j',      (char )'e', 
        (char )'c',      (char )'t',      (char )' ',      (char )'c', 
        (char )'a',      (char )'n',      (char )' ',      (char )'n', 
        (char )'o',      (char )' ',      (char )'l',      (char )'o', 
        (char )'n',      (char )'g',      (char )'e',      (char )'r', 
        (char )' ',      (char )'b',      (char )'e',      (char )' ', 
        (char )'u',      (char )'s',      (char )'e',      (char )'d', 
        (char )' ',      (char )'a',      (char )'f',      (char )'t', 
        (char )'e',      (char )'r',      (char )'\n',      (char )'c', 
        (char )'a',      (char )'l',      (char )'l',      (char )'i', 
        (char )'n',      (char )'g',      (char )' ',      (char )'t', 
        (char )'h',      (char )'e',      (char )' ',      (char )'f', 
        (char )'l',      (char )'u',      (char )'s',      (char )'h', 
        (char )'(',      (char )')',      (char )' ',      (char )'m', 
        (char )'e',      (char )'t',      (char )'h',      (char )'o', 
        (char )'d',      (char )'.',      (char )' ',      (char )' ', 
        (char )'O',      (char )'t',      (char )'h',      (char )'e', 
        (char )'r',      (char )'w',      (char )'i',      (char )'s', 
        (char )'e',      (char )',',      (char )' ',      (char )'m', 
        (char )'o',      (char )'r',      (char )'e',      (char )' ', 
        (char )'d',      (char )'a',      (char )'t',      (char )'a', 
        (char )' ',      (char )'c',      (char )'a',      (char )'n', 
        (char )' ',      (char )'s',      (char )'t',      (char )'i', 
        (char )'l',      (char )'l',      (char )' ',      (char )'b', 
        (char )'e',      (char )' ',      (char )'c',      (char )'o', 
        (char )'m',      (char )'p',      (char )'r',      (char )'e', 
        (char )'s',      (char )'s',      (char )'e',      (char )'d', 
        (char )'.',      (char )'\000'};
static PyObject *PyZlib_flush(compobject *self , PyObject *args ) 
{ int err ;
  int length ;
  PyObject *RetVal ;
  int flushmode ;
  unsigned long start_total_out ;
  int tmp ;
  PyObject *tmp___0 ;
  PyThreadState *_save ;
  PyThreadState *_save___0 ;
  int tmp___1 ;
  PyThreadState *_save___1 ;
  int tmp___2 ;

  {
  length = 16384;
  flushmode = 4;
  tmp = PyArg_ParseTuple(args, "|i:flush", & flushmode);
  if (tmp) {

  } else {
    return ((PyObject *)((void *)0));
  }
  if (flushmode == 0) {
    tmp___0 = PyBytes_FromStringAndSize((char const   *)((void *)0), 0);
    return (tmp___0);
  } else {

  }
  RetVal = PyBytes_FromStringAndSize((char const   *)((void *)0), length);
  if (RetVal) {

  } else {
    return ((PyObject *)((void *)0));
  }
  _save = PyEval_SaveThread();
  PyThread_acquire_lock(self->lock, 1);
  PyEval_RestoreThread(_save);
  start_total_out = self->zst.total_out;
  self->zst.avail_in = 0U;
  self->zst.avail_out = (unsigned int )length;
  self->zst.next_out = (unsigned char *)(((PyBytesObject *)RetVal)->ob_sval);
  _save___0 = PyEval_SaveThread();
  err = deflate(& self->zst, flushmode);
  PyEval_RestoreThread(_save___0);
  while (1) {
    if (err == 0) {
      if (self->zst.avail_out == 0U) {

      } else {
        break;
      }
    } else {
      break;
    }
    tmp___1 = _PyBytes_Resize(& RetVal, length << 1);
    if (tmp___1 < 0) {
      while (1) {
        (RetVal->ob_refcnt) --;
        if (RetVal->ob_refcnt != 0) {

        } else {
          (*((RetVal->ob_type)->tp_dealloc))(RetVal);
        }
        break;
      }
      RetVal = (PyObject *)((void *)0);
      goto error;
    } else {

    }
    self->zst.next_out = (unsigned char *)(((PyBytesObject *)RetVal)->ob_sval) + length;
    self->zst.avail_out = (unsigned int )length;
    length <<= 1;
    _save___1 = PyEval_SaveThread();
    err = deflate(& self->zst, flushmode);
    PyEval_RestoreThread(_save___1);
  }
  if (err == 1) {
    if (flushmode == 4) {
      err = deflateEnd(& self->zst);
      if (err != 0) {
        zlib_error(self->zst, err, (char *)"from deflateEnd()");
        while (1) {
          (RetVal->ob_refcnt) --;
          if (RetVal->ob_refcnt != 0) {

          } else {
            (*((RetVal->ob_type)->tp_dealloc))(RetVal);
          }
          break;
        }
        RetVal = (PyObject *)((void *)0);
        goto error;
      } else {
        self->is_initialised = 0;
      }
    } else {
      goto _L;
    }
  } else {
    _L: /* CIL Label */ 
    if (err != 0) {
      if (err != -5) {
        zlib_error(self->zst, err, (char *)"while flushing");
        while (1) {
          (RetVal->ob_refcnt) --;
          if (RetVal->ob_refcnt != 0) {

          } else {
            (*((RetVal->ob_type)->tp_dealloc))(RetVal);
          }
          break;
        }
        RetVal = (PyObject *)((void *)0);
        goto error;
      } else {

      }
    } else {

    }
  }
  tmp___2 = _PyBytes_Resize(& RetVal, (int )(self->zst.total_out - start_total_out));
  if (tmp___2 < 0) {
    while (1) {
      (RetVal->ob_refcnt) --;
      if (RetVal->ob_refcnt != 0) {

      } else {
        (*((RetVal->ob_type)->tp_dealloc))(RetVal);
      }
      break;
    }
    RetVal = (PyObject *)((void *)0);
  } else {

  }
  error: 
  PyThread_release_lock(self->lock);
  return (RetVal);
}
}
static char comp_copy__doc__[51]  = 
  {      (char )'c',      (char )'o',      (char )'p',      (char )'y', 
        (char )'(',      (char )')',      (char )' ',      (char )'-', 
        (char )'-',      (char )' ',      (char )'R',      (char )'e', 
        (char )'t',      (char )'u',      (char )'r',      (char )'n', 
        (char )' ',      (char )'a',      (char )' ',      (char )'c', 
        (char )'o',      (char )'p',      (char )'y',      (char )' ', 
        (char )'o',      (char )'f',      (char )' ',      (char )'t', 
        (char )'h',      (char )'e',      (char )' ',      (char )'c', 
        (char )'o',      (char )'m',      (char )'p',      (char )'r', 
        (char )'e',      (char )'s',      (char )'s',      (char )'i', 
        (char )'o',      (char )'n',      (char )' ',      (char )'o', 
        (char )'b',      (char )'j',      (char )'e',      (char )'c', 
        (char )'t',      (char )'.',      (char )'\000'};
static PyObject *PyZlib_copy(compobject *self ) 
{ compobject *retval ;
  int err ;
  PyThreadState *_save ;

  {
  retval = (compobject *)((void *)0);
  retval = newcompobject(& Comptype);
  if (! retval) {
    return ((PyObject *)((void *)0));
  } else {

  }
  _save = PyEval_SaveThread();
  PyThread_acquire_lock(self->lock, 1);
  PyEval_RestoreThread(_save);
  err = deflateCopy(& retval->zst, & self->zst);
  switch (err) {
  case 0: 
  break;
  case -2: 
  PyErr_SetString(PyExc_ValueError, "Inconsistent stream state");
  goto error;
  case -4: 
  PyErr_SetString(PyExc_MemoryError, "Can\'t allocate memory for compression object");
  goto error;
  default: 
  zlib_error(self->zst, err, (char *)"while copying compression object");
  goto error;
  }
  ((self->unused_data)->ob_refcnt) ++;
  ((self->unconsumed_tail)->ob_refcnt) ++;
  while (1) {
    if ((unsigned int )retval->unused_data == (unsigned int )((void *)0)) {

    } else {
      while (1) {
        ((retval->unused_data)->ob_refcnt) --;
        if ((retval->unused_data)->ob_refcnt != 0) {

        } else {
          (*(((retval->unused_data)->ob_type)->tp_dealloc))(retval->unused_data);
        }
        break;
      }
    }
    break;
  }
  while (1) {
    if ((unsigned int )retval->unconsumed_tail == (unsigned int )((void *)0)) {

    } else {
      while (1) {
        ((retval->unconsumed_tail)->ob_refcnt) --;
        if ((retval->unconsumed_tail)->ob_refcnt != 0) {

        } else {
          (*(((retval->unconsumed_tail)->ob_type)->tp_dealloc))(retval->unconsumed_tail);
        }
        break;
      }
    }
    break;
  }
  retval->unused_data = self->unused_data;
  retval->unconsumed_tail = self->unconsumed_tail;
  retval->is_initialised = 1;
  PyThread_release_lock(self->lock);
  return ((PyObject *)retval);
  error: 
  PyThread_release_lock(self->lock);
  while (1) {
    if ((unsigned int )retval == (unsigned int )((void *)0)) {

    } else {
      while (1) {
        (((PyObject *)retval)->ob_refcnt) --;
        if (((PyObject *)retval)->ob_refcnt != 0) {

        } else {
          (*((((PyObject *)retval)->ob_type)->tp_dealloc))((PyObject *)retval);
        }
        break;
      }
    }
    break;
  }
  return ((PyObject *)((void *)0));
}
}
static char decomp_copy__doc__[53]  = 
  {      (char )'c',      (char )'o',      (char )'p',      (char )'y', 
        (char )'(',      (char )')',      (char )' ',      (char )'-', 
        (char )'-',      (char )' ',      (char )'R',      (char )'e', 
        (char )'t',      (char )'u',      (char )'r',      (char )'n', 
        (char )' ',      (char )'a',      (char )' ',      (char )'c', 
        (char )'o',      (char )'p',      (char )'y',      (char )' ', 
        (char )'o',      (char )'f',      (char )' ',      (char )'t', 
        (char )'h',      (char )'e',      (char )' ',      (char )'d', 
        (char )'e',      (char )'c',      (char )'o',      (char )'m', 
        (char )'p',      (char )'r',      (char )'e',      (char )'s', 
        (char )'s',      (char )'i',      (char )'o',      (char )'n', 
        (char )' ',      (char )'o',      (char )'b',      (char )'j', 
        (char )'e',      (char )'c',      (char )'t',      (char )'.', 
        (char )'\000'};
static PyObject *PyZlib_uncopy(compobject *self ) 
{ compobject *retval ;
  int err ;
  PyThreadState *_save ;

  {
  retval = (compobject *)((void *)0);
  retval = newcompobject(& Decomptype);
  if (! retval) {
    return ((PyObject *)((void *)0));
  } else {

  }
  _save = PyEval_SaveThread();
  PyThread_acquire_lock(self->lock, 1);
  PyEval_RestoreThread(_save);
  err = inflateCopy(& retval->zst, & self->zst);
  switch (err) {
  case 0: 
  break;
  case -2: 
  PyErr_SetString(PyExc_ValueError, "Inconsistent stream state");
  goto error;
  case -4: 
  PyErr_SetString(PyExc_MemoryError, "Can\'t allocate memory for decompression object");
  goto error;
  default: 
  zlib_error(self->zst, err, (char *)"while copying decompression object");
  goto error;
  }
  ((self->unused_data)->ob_refcnt) ++;
  ((self->unconsumed_tail)->ob_refcnt) ++;
  while (1) {
    if ((unsigned int )retval->unused_data == (unsigned int )((void *)0)) {

    } else {
      while (1) {
        ((retval->unused_data)->ob_refcnt) --;
        if ((retval->unused_data)->ob_refcnt != 0) {

        } else {
          (*(((retval->unused_data)->ob_type)->tp_dealloc))(retval->unused_data);
        }
        break;
      }
    }
    break;
  }
  while (1) {
    if ((unsigned int )retval->unconsumed_tail == (unsigned int )((void *)0)) {

    } else {
      while (1) {
        ((retval->unconsumed_tail)->ob_refcnt) --;
        if ((retval->unconsumed_tail)->ob_refcnt != 0) {

        } else {
          (*(((retval->unconsumed_tail)->ob_type)->tp_dealloc))(retval->unconsumed_tail);
        }
        break;
      }
    }
    break;
  }
  retval->unused_data = self->unused_data;
  retval->unconsumed_tail = self->unconsumed_tail;
  retval->is_initialised = 1;
  PyThread_release_lock(self->lock);
  return ((PyObject *)retval);
  error: 
  PyThread_release_lock(self->lock);
  while (1) {
    if ((unsigned int )retval == (unsigned int )((void *)0)) {

    } else {
      while (1) {
        (((PyObject *)retval)->ob_refcnt) --;
        if (((PyObject *)retval)->ob_refcnt != 0) {

        } else {
          (*((((PyObject *)retval)->ob_type)->tp_dealloc))((PyObject *)retval);
        }
        break;
      }
    }
    break;
  }
  return ((PyObject *)((void *)0));
}
}
static char decomp_flush__doc__[205]  = 
  {      (char )'f',      (char )'l',      (char )'u',      (char )'s', 
        (char )'h',      (char )'(',      (char )' ',      (char )'[', 
        (char )'l',      (char )'e',      (char )'n',      (char )'g', 
        (char )'t',      (char )'h',      (char )']',      (char )' ', 
        (char )')',      (char )' ',      (char )'-',      (char )'-', 
        (char )' ',      (char )'R',      (char )'e',      (char )'t', 
        (char )'u',      (char )'r',      (char )'n',      (char )' ', 
        (char )'a',      (char )' ',      (char )'s',      (char )'t', 
        (char )'r',      (char )'i',      (char )'n',      (char )'g', 
        (char )' ',      (char )'c',      (char )'o',      (char )'n', 
        (char )'t',      (char )'a',      (char )'i',      (char )'n', 
        (char )'i',      (char )'n',      (char )'g',      (char )' ', 
        (char )'a',      (char )'n',      (char )'y',      (char )' ', 
        (char )'r',      (char )'e',      (char )'m',      (char )'a', 
        (char )'i',      (char )'n',      (char )'i',      (char )'n', 
        (char )'g',      (char )'\n',      (char )'d',      (char )'e', 
        (char )'c',      (char )'o',      (char )'m',      (char )'p', 
        (char )'r',      (char )'e',      (char )'s',      (char )'s', 
        (char )'e',      (char )'d',      (char )' ',      (char )'d', 
        (char )'a',      (char )'t',      (char )'a',      (char )'.', 
        (char )' ',      (char )'l',      (char )'e',      (char )'n', 
        (char )'g',      (char )'t',      (char )'h',      (char )',', 
        (char )' ',      (char )'i',      (char )'f',      (char )' ', 
        (char )'g',      (char )'i',      (char )'v',      (char )'e', 
        (char )'n',      (char )',',      (char )' ',      (char )'i', 
        (char )'s',      (char )' ',      (char )'t',      (char )'h', 
        (char )'e',      (char )' ',      (char )'i',      (char )'n', 
        (char )'i',      (char )'t',      (char )'i',      (char )'a', 
        (char )'l',      (char )' ',      (char )'s',      (char )'i', 
        (char )'z',      (char )'e',      (char )' ',      (char )'o', 
        (char )'f',      (char )' ',      (char )'t',      (char )'h', 
        (char )'e',      (char )'\n',      (char )'o',      (char )'u', 
        (char )'t',      (char )'p',      (char )'u',      (char )'t', 
        (char )' ',      (char )'b',      (char )'u',      (char )'f', 
        (char )'f',      (char )'e',      (char )'r',      (char )'.', 
        (char )'\n',      (char )'\n',      (char )'T',      (char )'h', 
        (char )'e',      (char )' ',      (char )'d',      (char )'e', 
        (char )'c',      (char )'o',      (char )'m',      (char )'p', 
        (char )'r',      (char )'e',      (char )'s',      (char )'s', 
        (char )'o',      (char )'r',      (char )' ',      (char )'o', 
        (char )'b',      (char )'j',      (char )'e',      (char )'c', 
        (char )'t',      (char )' ',      (char )'c',      (char )'a', 
        (char )'n',      (char )' ',      (char )'n',      (char )'o', 
        (char )' ',      (char )'l',      (char )'o',      (char )'n', 
        (char )'g',      (char )'e',      (char )'r',      (char )' ', 
        (char )'b',      (char )'e',      (char )' ',      (char )'u', 
        (char )'s',      (char )'e',      (char )'d',      (char )' ', 
        (char )'a',      (char )'f',      (char )'t',      (char )'e', 
        (char )'r',      (char )' ',      (char )'t',      (char )'h', 
        (char )'i',      (char )'s',      (char )' ',      (char )'c', 
        (char )'a',      (char )'l',      (char )'l',      (char )'.', 
        (char )'\000'};
static PyObject *PyZlib_unflush(compobject *self , PyObject *args ) 
{ int err ;
  int length ;
  PyObject *retval ;
  unsigned long start_total_out ;
  int tmp ;
  PyThreadState *_save ;
  PyThreadState *_save___0 ;
  int tmp___0 ;
  PyThreadState *_save___1 ;
  int tmp___1 ;

  {
  length = 16384;
  retval = (PyObject *)((void *)0);
  tmp = PyArg_ParseTuple(args, "|i:flush", & length);
  if (tmp) {

  } else {
    return ((PyObject *)((void *)0));
  }
  if (length <= 0) {
    PyErr_SetString(PyExc_ValueError, "length must be greater than zero");
    return ((PyObject *)((void *)0));
  } else {

  }
  retval = PyBytes_FromStringAndSize((char const   *)((void *)0), length);
  if (retval) {

  } else {
    return ((PyObject *)((void *)0));
  }
  _save = PyEval_SaveThread();
  PyThread_acquire_lock(self->lock, 1);
  PyEval_RestoreThread(_save);
  start_total_out = self->zst.total_out;
  self->zst.avail_out = (unsigned int )length;
  self->zst.next_out = (Byte *)(((PyBytesObject *)retval)->ob_sval);
  _save___0 = PyEval_SaveThread();
  err = inflate(& self->zst, 4);
  PyEval_RestoreThread(_save___0);
  while (1) {
    if (err == 0) {
      goto _L;
    } else {
      if (err == -5) {
        _L: /* CIL Label */ 
        if (self->zst.avail_out == 0U) {

        } else {
          break;
        }
      } else {
        break;
      }
    }
    tmp___0 = _PyBytes_Resize(& retval, length << 1);
    if (tmp___0 < 0) {
      while (1) {
        (retval->ob_refcnt) --;
        if (retval->ob_refcnt != 0) {

        } else {
          (*((retval->ob_type)->tp_dealloc))(retval);
        }
        break;
      }
      retval = (PyObject *)((void *)0);
      goto error;
    } else {

    }
    self->zst.next_out = (Byte *)(((PyBytesObject *)retval)->ob_sval) + length;
    self->zst.avail_out = (unsigned int )length;
    length <<= 1;
    _save___1 = PyEval_SaveThread();
    err = inflate(& self->zst, 4);
    PyEval_RestoreThread(_save___1);
  }
  if (err == 1) {
    err = inflateEnd(& self->zst);
    self->is_initialised = 0;
    if (err != 0) {
      zlib_error(self->zst, err, (char *)"from inflateEnd()");
      while (1) {
        (retval->ob_refcnt) --;
        if (retval->ob_refcnt != 0) {

        } else {
          (*((retval->ob_type)->tp_dealloc))(retval);
        }
        break;
      }
      retval = (PyObject *)((void *)0);
      goto error;
    } else {

    }
  } else {

  }
  tmp___1 = _PyBytes_Resize(& retval, (int )(self->zst.total_out - start_total_out));
  if (tmp___1 < 0) {
    while (1) {
      (retval->ob_refcnt) --;
      if (retval->ob_refcnt != 0) {

      } else {
        (*((retval->ob_type)->tp_dealloc))(retval);
      }
      break;
    }
    retval = (PyObject *)((void *)0);
  } else {

  }
  error: 
  PyThread_release_lock(self->lock);
  return (retval);
}
}
static PyMethodDef comp_methods[4]  = {      {"compress", (PyObject *(*)(PyObject * , PyObject * ))(& PyZlib_objcompress), 0x0001, (char const   *)(comp_compress__doc__)}, 
        {"flush", (PyObject *(*)(PyObject * , PyObject * ))(& PyZlib_flush), 0x0001, (char const   *)(comp_flush__doc__)}, 
        {"copy", (PyObject *(*)(PyObject * , PyObject * ))(& PyZlib_copy), 0x0004, (char const   *)(comp_copy__doc__)}, 
        {(char const   *)((void *)0), (PyObject *(*)(PyObject * , PyObject * ))((void *)0), 0, (char const   *)0}};
static PyMethodDef Decomp_methods[4]  = {      {"decompress", (PyObject *(*)(PyObject * , PyObject * ))(& PyZlib_objdecompress), 0x0001, (char const   *)(decomp_decompress__doc__)}, 
        {"flush", (PyObject *(*)(PyObject * , PyObject * ))(& PyZlib_unflush), 0x0001, (char const   *)(decomp_flush__doc__)}, 
        {"copy", (PyObject *(*)(PyObject * , PyObject * ))(& PyZlib_uncopy), 0x0004, (char const   *)(decomp_copy__doc__)}, 
        {(char const   *)((void *)0), (PyObject *(*)(PyObject * , PyObject * ))((void *)0), 0, (char const   *)0}};
static PyMemberDef Decomp_members[3]  = {      {(char *)"unused_data", 6, (Py_ssize_t )((unsigned int )(& ((compobject *)0)->unused_data)), 1, (char *)0}, 
        {(char *)"unconsumed_tail", 6, (Py_ssize_t )((unsigned int )(& ((compobject *)0)->unconsumed_tail)), 1, (char *)0}, 
        {(char *)((void *)0), 0, 0, 0, (char *)0}};
static char adler32__doc__[152]  = 
  {      (char )'a',      (char )'d',      (char )'l',      (char )'e', 
        (char )'r',      (char )'3',      (char )'2',      (char )'(', 
        (char )'s',      (char )'t',      (char )'r',      (char )'i', 
        (char )'n',      (char )'g',      (char )'[',      (char )',', 
        (char )' ',      (char )'s',      (char )'t',      (char )'a', 
        (char )'r',      (char )'t',      (char )']',      (char )')', 
        (char )' ',      (char )'-',      (char )'-',      (char )' ', 
        (char )'C',      (char )'o',      (char )'m',      (char )'p', 
        (char )'u',      (char )'t',      (char )'e',      (char )' ', 
        (char )'a',      (char )'n',      (char )' ',      (char )'A', 
        (char )'d',      (char )'l',      (char )'e',      (char )'r', 
        (char )'-',      (char )'3',      (char )'2',      (char )' ', 
        (char )'c',      (char )'h',      (char )'e',      (char )'c', 
        (char )'k',      (char )'s',      (char )'u',      (char )'m', 
        (char )' ',      (char )'o',      (char )'f',      (char )' ', 
        (char )'s',      (char )'t',      (char )'r',      (char )'i', 
        (char )'n',      (char )'g',      (char )'.',      (char )'\n', 
        (char )'\n',      (char )'A',      (char )'n',      (char )' ', 
        (char )'o',      (char )'p',      (char )'t',      (char )'i', 
        (char )'o',      (char )'n',      (char )'a',      (char )'l', 
        (char )' ',      (char )'s',      (char )'t',      (char )'a', 
        (char )'r',      (char )'t',      (char )'i',      (char )'n', 
        (char )'g',      (char )' ',      (char )'v',      (char )'a', 
        (char )'l',      (char )'u',      (char )'e',      (char )' ', 
        (char )'c',      (char )'a',      (char )'n',      (char )' ', 
        (char )'b',      (char )'e',      (char )' ',      (char )'s', 
        (char )'p',      (char )'e',      (char )'c',      (char )'i', 
        (char )'f',      (char )'i',      (char )'e',      (char )'d', 
        (char )'.',      (char )' ',      (char )' ',      (char )'T', 
        (char )'h',      (char )'e',      (char )' ',      (char )'r', 
        (char )'e',      (char )'t',      (char )'u',      (char )'r', 
        (char )'n',      (char )'e',      (char )'d',      (char )' ', 
        (char )'c',      (char )'h',      (char )'e',      (char )'c', 
        (char )'k',      (char )'s',      (char )'u',      (char )'m', 
        (char )' ',      (char )'i',      (char )'s',      (char )'\n', 
        (char )'a',      (char )'n',      (char )' ',      (char )'i', 
        (char )'n',      (char )'t',      (char )'e',      (char )'g', 
        (char )'e',      (char )'r',      (char )'.',      (char )'\000'};
static PyObject *PyZlib_adler32(PyObject *self , PyObject *args ) 
{ unsigned int adler32val ;
  Py_buffer pbuf ;
  int tmp ;
  unsigned char *buf ;
  Py_ssize_t len ;
  PyThreadState *_save ;
  uLong tmp___0 ;
  uLong tmp___1 ;
  uLong tmp___2 ;
  PyObject *tmp___3 ;

  {
  adler32val = 1U;
  tmp = PyArg_ParseTuple(args, "y*|I:adler32", & pbuf, & adler32val);
  if (tmp) {

  } else {
    return ((PyObject *)((void *)0));
  }
  if (pbuf.len > 5120) {
    buf = (unsigned char *)pbuf.buf;
    len = pbuf.len;
    _save = PyEval_SaveThread();
    while ((unsigned int )len > 4294967295U) {
      tmp___0 = adler32((unsigned long )adler32val, (Bytef const   *)buf, 4294967295U);
      adler32val = (unsigned int )tmp___0;
      buf += 4294967295U;
      len = (int )((unsigned int )len - 4294967295U);
    }
    tmp___1 = adler32((unsigned long )adler32val, (Bytef const   *)buf, (unsigned int )len);
    adler32val = (unsigned int )tmp___1;
    PyEval_RestoreThread(_save);
  } else {
    tmp___2 = adler32((unsigned long )adler32val, (Bytef const   *)pbuf.buf, (unsigned int )pbuf.len);
    adler32val = (unsigned int )tmp___2;
  }
  PyBuffer_Release(& pbuf);
  tmp___3 = PyLong_FromUnsignedLong((unsigned long )(adler32val & 0xffffffffU));
  return (tmp___3);
}
}
static char crc32__doc__[147]  = 
  {      (char )'c',      (char )'r',      (char )'c',      (char )'3', 
        (char )'2',      (char )'(',      (char )'s',      (char )'t', 
        (char )'r',      (char )'i',      (char )'n',      (char )'g', 
        (char )'[',      (char )',',      (char )' ',      (char )'s', 
        (char )'t',      (char )'a',      (char )'r',      (char )'t', 
        (char )']',      (char )')',      (char )' ',      (char )'-', 
        (char )'-',      (char )' ',      (char )'C',      (char )'o', 
        (char )'m',      (char )'p',      (char )'u',      (char )'t', 
        (char )'e',      (char )' ',      (char )'a',      (char )' ', 
        (char )'C',      (char )'R',      (char )'C',      (char )'-', 
        (char )'3',      (char )'2',      (char )' ',      (char )'c', 
        (char )'h',      (char )'e',      (char )'c',      (char )'k', 
        (char )'s',      (char )'u',      (char )'m',      (char )' ', 
        (char )'o',      (char )'f',      (char )' ',      (char )'s', 
        (char )'t',      (char )'r',      (char )'i',      (char )'n', 
        (char )'g',      (char )'.',      (char )'\n',      (char )'\n', 
        (char )'A',      (char )'n',      (char )' ',      (char )'o', 
        (char )'p',      (char )'t',      (char )'i',      (char )'o', 
        (char )'n',      (char )'a',      (char )'l',      (char )' ', 
        (char )'s',      (char )'t',      (char )'a',      (char )'r', 
        (char )'t',      (char )'i',      (char )'n',      (char )'g', 
        (char )' ',      (char )'v',      (char )'a',      (char )'l', 
        (char )'u',      (char )'e',      (char )' ',      (char )'c', 
        (char )'a',      (char )'n',      (char )' ',      (char )'b', 
        (char )'e',      (char )' ',      (char )'s',      (char )'p', 
        (char )'e',      (char )'c',      (char )'i',      (char )'f', 
        (char )'i',      (char )'e',      (char )'d',      (char )'.', 
        (char )' ',      (char )' ',      (char )'T',      (char )'h', 
        (char )'e',      (char )' ',      (char )'r',      (char )'e', 
        (char )'t',      (char )'u',      (char )'r',      (char )'n', 
        (char )'e',      (char )'d',      (char )' ',      (char )'c', 
        (char )'h',      (char )'e',      (char )'c',      (char )'k', 
        (char )'s',      (char )'u',      (char )'m',      (char )' ', 
        (char )'i',      (char )'s',      (char )'\n',      (char )'a', 
        (char )'n',      (char )' ',      (char )'i',      (char )'n', 
        (char )'t',      (char )'e',      (char )'g',      (char )'e', 
        (char )'r',      (char )'.',      (char )'\000'};
static PyObject *PyZlib_crc32(PyObject *self , PyObject *args ) 
{ unsigned int crc32val ;
  Py_buffer pbuf ;
  int signed_val ;
  int tmp ;
  unsigned char *buf ;
  Py_ssize_t len ;
  PyThreadState *_save ;
  uLong tmp___0 ;
  uLong tmp___1 ;
  uLong tmp___2 ;
  PyObject *tmp___3 ;

  {
  crc32val = 0U;
  tmp = PyArg_ParseTuple(args, "y*|I:crc32", & pbuf, & crc32val);
  if (tmp) {

  } else {
    return ((PyObject *)((void *)0));
  }
  if (pbuf.len > 5120) {
    buf = (unsigned char *)pbuf.buf;
    len = pbuf.len;
    _save = PyEval_SaveThread();
    while ((unsigned int )len > 4294967295U) {
      tmp___0 = crc32((unsigned long )crc32val, (Bytef const   *)buf, 4294967295U);
      crc32val = (unsigned int )tmp___0;
      buf += 4294967295U;
      len = (int )((unsigned int )len - 4294967295U);
    }
    tmp___1 = crc32((unsigned long )crc32val, (Bytef const   *)buf, (unsigned int )len);
    signed_val = (int )tmp___1;
    PyEval_RestoreThread(_save);
  } else {
    tmp___2 = crc32((unsigned long )crc32val, (Bytef const   *)pbuf.buf, (unsigned int )pbuf.len);
    signed_val = (int )tmp___2;
  }
  PyBuffer_Release(& pbuf);
  tmp___3 = PyLong_FromUnsignedLong((unsigned long )((unsigned int )signed_val & 0xffffffffU));
  return (tmp___3);
}
}
static PyMethodDef zlib_methods[7]  = {      {"adler32", & PyZlib_adler32, 0x0001, (char const   *)(adler32__doc__)}, 
        {"compress", & PyZlib_compress, 0x0001, (char const   *)(compress__doc__)}, 
        {"compressobj", & PyZlib_compressobj, 0x0001, (char const   *)(compressobj__doc__)}, 
        {"crc32", & PyZlib_crc32, 0x0001, (char const   *)(crc32__doc__)}, 
        {"decompress", & PyZlib_decompress, 0x0001, (char const   *)(decompress__doc__)}, 
        {"decompressobj", & PyZlib_decompressobj, 0x0001, (char const   *)(decompressobj__doc__)}, 
        {(char const   *)((void *)0), (PyObject *(*)(PyObject * , PyObject * ))((void *)0), 0, (char const   *)0}};
static PyTypeObject Comptype  = 
     {{{1, (struct _typeobject *)0}, 0}, "zlib.Compress", (Py_ssize_t )sizeof(compobject ), 0, (void (*)(PyObject * ))(& Comp_dealloc), (int (*)(PyObject * , FILE * , int  ))0, (PyObject *(*)(PyObject * , char * ))0, (int (*)(PyObject * , char * , PyObject * ))0, (void *)0, (PyObject *(*)(PyObject * ))0, (PyNumberMethods *)0, (PySequenceMethods *)0, (PyMappingMethods *)0, (Py_hash_t (*)(PyObject * ))0, (PyObject *(*)(PyObject * , PyObject * , PyObject * ))0, (PyObject *(*)(PyObject * ))0, (PyObject *(*)(PyObject * , PyObject * ))0, (int (*)(PyObject * , PyObject * , PyObject * ))0, (PyBufferProcs *)0, 1L << 18, (char const   *)0, (int (*)(PyObject * , int (*)(PyObject * , void * ) , void * ))0, (int (*)(PyObject * ))0, (PyObject *(*)(PyObject * , PyObject * , int  ))0, 0, (PyObject *(*)(PyObject * ))0, (PyObject *(*)(PyObject * ))0, comp_methods, (struct PyMemberDef *)0, (struct PyGetSetDef *)0, (struct _typeobject *)0, (PyObject *)0, (PyObject *(*)(PyObject * , PyObject * , PyObject * ))0, (int (*)(PyObject * , PyObject * , PyObject * ))0, 0, (int (*)(PyObject * , PyObject * , PyObject * ))0, (PyObject *(*)(struct _typeobject * , Py_ssize_t  ))0, (PyObject *(*)(struct _typeobject * , PyObject * , PyObject * ))0, (void (*)(void * ))0, (int (*)(PyObject * ))0, (PyObject *)0, (PyObject *)0, (PyObject *)0, (PyObject *)0, (PyObject *)0, (void (*)(PyObject * ))0, 0U};
static PyTypeObject Decomptype  = 
     {{{1, (struct _typeobject *)0}, 0}, "zlib.Decompress", (Py_ssize_t )sizeof(compobject ), 0, (void (*)(PyObject * ))(& Decomp_dealloc), (int (*)(PyObject * , FILE * , int  ))0, (PyObject *(*)(PyObject * , char * ))0, (int (*)(PyObject * , char * , PyObject * ))0, (void *)0, (PyObject *(*)(PyObject * ))0, (PyNumberMethods *)0, (PySequenceMethods *)0, (PyMappingMethods *)0, (Py_hash_t (*)(PyObject * ))0, (PyObject *(*)(PyObject * , PyObject * , PyObject * ))0, (PyObject *(*)(PyObject * ))0, (PyObject *(*)(PyObject * , PyObject * ))0, (int (*)(PyObject * , PyObject * , PyObject * ))0, (PyBufferProcs *)0, 1L << 18, (char const   *)0, (int (*)(PyObject * , int (*)(PyObject * , void * ) , void * ))0, (int (*)(PyObject * ))0, (PyObject *(*)(PyObject * , PyObject * , int  ))0, 0, (PyObject *(*)(PyObject * ))0, (PyObject *(*)(PyObject * ))0, Decomp_methods, Decomp_members, (struct PyGetSetDef *)0, (struct _typeobject *)0, (PyObject *)0, (PyObject *(*)(PyObject * , PyObject * , PyObject * ))0, (int (*)(PyObject * , PyObject * , PyObject * ))0, 0, (int (*)(PyObject * , PyObject * , PyObject * ))0, (PyObject *(*)(struct _typeobject * , Py_ssize_t  ))0, (PyObject *(*)(struct _typeobject * , PyObject * , PyObject * ))0, (void (*)(void * ))0, (int (*)(PyObject * ))0, (PyObject *)0, (PyObject *)0, (PyObject *)0, (PyObject *)0, (PyObject *)0, (void (*)(PyObject * ))0, 0U};
static char zlib_module_documentation[633]  = 
  {      (char )'T',      (char )'h',      (char )'e',      (char )' ', 
        (char )'f',      (char )'u',      (char )'n',      (char )'c', 
        (char )'t',      (char )'i',      (char )'o',      (char )'n', 
        (char )'s',      (char )' ',      (char )'i',      (char )'n', 
        (char )' ',      (char )'t',      (char )'h',      (char )'i', 
        (char )'s',      (char )' ',      (char )'m',      (char )'o', 
        (char )'d',      (char )'u',      (char )'l',      (char )'e', 
        (char )' ',      (char )'a',      (char )'l',      (char )'l', 
        (char )'o',      (char )'w',      (char )' ',      (char )'c', 
        (char )'o',      (char )'m',      (char )'p',      (char )'r', 
        (char )'e',      (char )'s',      (char )'s',      (char )'i', 
        (char )'o',      (char )'n',      (char )' ',      (char )'a', 
        (char )'n',      (char )'d',      (char )' ',      (char )'d', 
        (char )'e',      (char )'c',      (char )'o',      (char )'m', 
        (char )'p',      (char )'r',      (char )'e',      (char )'s', 
        (char )'s',      (char )'i',      (char )'o',      (char )'n', 
        (char )' ',      (char )'u',      (char )'s',      (char )'i', 
        (char )'n',      (char )'g',      (char )' ',      (char )'t', 
        (char )'h',      (char )'e',      (char )'\n',      (char )'z', 
        (char )'l',      (char )'i',      (char )'b',      (char )' ', 
        (char )'l',      (char )'i',      (char )'b',      (char )'r', 
        (char )'a',      (char )'r',      (char )'y',      (char )',', 
        (char )' ',      (char )'w',      (char )'h',      (char )'i', 
        (char )'c',      (char )'h',      (char )' ',      (char )'i', 
        (char )'s',      (char )' ',      (char )'b',      (char )'a', 
        (char )'s',      (char )'e',      (char )'d',      (char )' ', 
        (char )'o',      (char )'n',      (char )' ',      (char )'G', 
        (char )'N',      (char )'U',      (char )' ',      (char )'z', 
        (char )'i',      (char )'p',      (char )'.',      (char )'\n', 
        (char )'\n',      (char )'a',      (char )'d',      (char )'l', 
        (char )'e',      (char )'r',      (char )'3',      (char )'2', 
        (char )'(',      (char )'s',      (char )'t',      (char )'r', 
        (char )'i',      (char )'n',      (char )'g',      (char )'[', 
        (char )',',      (char )' ',      (char )'s',      (char )'t', 
        (char )'a',      (char )'r',      (char )'t',      (char )']', 
        (char )')',      (char )' ',      (char )'-',      (char )'-', 
        (char )' ',      (char )'C',      (char )'o',      (char )'m', 
        (char )'p',      (char )'u',      (char )'t',      (char )'e', 
        (char )' ',      (char )'a',      (char )'n',      (char )' ', 
        (char )'A',      (char )'d',      (char )'l',      (char )'e', 
        (char )'r',      (char )'-',      (char )'3',      (char )'2', 
        (char )' ',      (char )'c',      (char )'h',      (char )'e', 
        (char )'c',      (char )'k',      (char )'s',      (char )'u', 
        (char )'m',      (char )'.',      (char )'\n',      (char )'c', 
        (char )'o',      (char )'m',      (char )'p',      (char )'r', 
        (char )'e',      (char )'s',      (char )'s',      (char )'(', 
        (char )'s',      (char )'t',      (char )'r',      (char )'i', 
        (char )'n',      (char )'g',      (char )'[',      (char )',', 
        (char )' ',      (char )'l',      (char )'e',      (char )'v', 
        (char )'e',      (char )'l',      (char )']',      (char )')', 
        (char )' ',      (char )'-',      (char )'-',      (char )' ', 
        (char )'C',      (char )'o',      (char )'m',      (char )'p', 
        (char )'r',      (char )'e',      (char )'s',      (char )'s', 
        (char )' ',      (char )'s',      (char )'t',      (char )'r', 
        (char )'i',      (char )'n',      (char )'g',      (char )',', 
        (char )' ',      (char )'w',      (char )'i',      (char )'t', 
        (char )'h',      (char )' ',      (char )'c',      (char )'o', 
        (char )'m',      (char )'p',      (char )'r',      (char )'e', 
        (char )'s',      (char )'s',      (char )'i',      (char )'o', 
        (char )'n',      (char )' ',      (char )'l',      (char )'e', 
        (char )'v',      (char )'e',      (char )'l',      (char )' ', 
        (char )'i',      (char )'n',      (char )' ',      (char )'1', 
        (char )'-',      (char )'9',      (char )'.',      (char )'\n', 
        (char )'c',      (char )'o',      (char )'m',      (char )'p', 
        (char )'r',      (char )'e',      (char )'s',      (char )'s', 
        (char )'o',      (char )'b',      (char )'j',      (char )'(', 
        (char )'[',      (char )'l',      (char )'e',      (char )'v', 
        (char )'e',      (char )'l',      (char )']',      (char )')', 
        (char )' ',      (char )'-',      (char )'-',      (char )' ', 
        (char )'R',      (char )'e',      (char )'t',      (char )'u', 
        (char )'r',      (char )'n',      (char )' ',      (char )'a', 
        (char )' ',      (char )'c',      (char )'o',      (char )'m', 
        (char )'p',      (char )'r',      (char )'e',      (char )'s', 
        (char )'s',      (char )'o',      (char )'r',      (char )' ', 
        (char )'o',      (char )'b',      (char )'j',      (char )'e', 
        (char )'c',      (char )'t',      (char )'.',      (char )'\n', 
        (char )'c',      (char )'r',      (char )'c',      (char )'3', 
        (char )'2',      (char )'(',      (char )'s',      (char )'t', 
        (char )'r',      (char )'i',      (char )'n',      (char )'g', 
        (char )'[',      (char )',',      (char )' ',      (char )'s', 
        (char )'t',      (char )'a',      (char )'r',      (char )'t', 
        (char )']',      (char )')',      (char )' ',      (char )'-', 
        (char )'-',      (char )' ',      (char )'C',      (char )'o', 
        (char )'m',      (char )'p',      (char )'u',      (char )'t', 
        (char )'e',      (char )' ',      (char )'a',      (char )' ', 
        (char )'C',      (char )'R',      (char )'C',      (char )'-', 
        (char )'3',      (char )'2',      (char )' ',      (char )'c', 
        (char )'h',      (char )'e',      (char )'c',      (char )'k', 
        (char )'s',      (char )'u',      (char )'m',      (char )'.', 
        (char )'\n',      (char )'d',      (char )'e',      (char )'c', 
        (char )'o',      (char )'m',      (char )'p',      (char )'r', 
        (char )'e',      (char )'s',      (char )'s',      (char )'(', 
        (char )'s',      (char )'t',      (char )'r',      (char )'i', 
        (char )'n',      (char )'g',      (char )',',      (char )'[', 
        (char )'w',      (char )'b',      (char )'i',      (char )'t', 
        (char )'s',      (char )']',      (char )',',      (char )'[', 
        (char )'b',      (char )'u',      (char )'f',      (char )'s', 
        (char )'i',      (char )'z',      (char )'e',      (char )']', 
        (char )')',      (char )' ',      (char )'-',      (char )'-', 
        (char )' ',      (char )'D',      (char )'e',      (char )'c', 
        (char )'o',      (char )'m',      (char )'p',      (char )'r', 
        (char )'e',      (char )'s',      (char )'s',      (char )'e', 
        (char )'s',      (char )' ',      (char )'a',      (char )' ', 
        (char )'c',      (char )'o',      (char )'m',      (char )'p', 
        (char )'r',      (char )'e',      (char )'s',      (char )'s', 
        (char )'e',      (char )'d',      (char )' ',      (char )'s', 
        (char )'t',      (char )'r',      (char )'i',      (char )'n', 
        (char )'g',      (char )'.',      (char )'\n',      (char )'d', 
        (char )'e',      (char )'c',      (char )'o',      (char )'m', 
        (char )'p',      (char )'r',      (char )'e',      (char )'s', 
        (char )'s',      (char )'o',      (char )'b',      (char )'j', 
        (char )'(',      (char )'[',      (char )'w',      (char )'b', 
        (char )'i',      (char )'t',      (char )'s',      (char )']', 
        (char )')',      (char )' ',      (char )'-',      (char )'-', 
        (char )' ',      (char )'R',      (char )'e',      (char )'t', 
        (char )'u',      (char )'r',      (char )'n',      (char )' ', 
        (char )'a',      (char )' ',      (char )'d',      (char )'e', 
        (char )'c',      (char )'o',      (char )'m',      (char )'p', 
        (char )'r',      (char )'e',      (char )'s',      (char )'s', 
        (char )'o',      (char )'r',      (char )' ',      (char )'o', 
        (char )'b',      (char )'j',      (char )'e',      (char )'c', 
        (char )'t',      (char )'.',      (char )'\n',      (char )'\n', 
        (char )'\'',      (char )'w',      (char )'b',      (char )'i', 
        (char )'t',      (char )'s',      (char )'\'',      (char )' ', 
        (char )'i',      (char )'s',      (char )' ',      (char )'w', 
        (char )'i',      (char )'n',      (char )'d',      (char )'o', 
        (char )'w',      (char )' ',      (char )'b',      (char )'u', 
        (char )'f',      (char )'f',      (char )'e',      (char )'r', 
        (char )' ',      (char )'s',      (char )'i',      (char )'z', 
        (char )'e',      (char )'.',      (char )'\n',      (char )'C', 
        (char )'o',      (char )'m',      (char )'p',      (char )'r', 
        (char )'e',      (char )'s',      (char )'s',      (char )'o', 
        (char )'r',      (char )' ',      (char )'o',      (char )'b', 
        (char )'j',      (char )'e',      (char )'c',      (char )'t', 
        (char )'s',      (char )' ',      (char )'s',      (char )'u', 
        (char )'p',      (char )'p',      (char )'o',      (char )'r', 
        (char )'t',      (char )' ',      (char )'c',      (char )'o', 
        (char )'m',      (char )'p',      (char )'r',      (char )'e', 
        (char )'s',      (char )'s',      (char )'(',      (char )')', 
        (char )' ',      (char )'a',      (char )'n',      (char )'d', 
        (char )' ',      (char )'f',      (char )'l',      (char )'u', 
        (char )'s',      (char )'h',      (char )'(',      (char )')', 
        (char )' ',      (char )'m',      (char )'e',      (char )'t', 
        (char )'h',      (char )'o',      (char )'d',      (char )'s', 
        (char )';',      (char )' ',      (char )'d',      (char )'e', 
        (char )'c',      (char )'o',      (char )'m',      (char )'p', 
        (char )'r',      (char )'e',      (char )'s',      (char )'s', 
        (char )'o',      (char )'r',      (char )'\n',      (char )'o', 
        (char )'b',      (char )'j',      (char )'e',      (char )'c', 
        (char )'t',      (char )'s',      (char )' ',      (char )'s', 
        (char )'u',      (char )'p',      (char )'p',      (char )'o', 
        (char )'r',      (char )'t',      (char )' ',      (char )'d', 
        (char )'e',      (char )'c',      (char )'o',      (char )'m', 
        (char )'p',      (char )'r',      (char )'e',      (char )'s', 
        (char )'s',      (char )'(',      (char )')',      (char )' ', 
        (char )'a',      (char )'n',      (char )'d',      (char )' ', 
        (char )'f',      (char )'l',      (char )'u',      (char )'s', 
        (char )'h',      (char )'(',      (char )')',      (char )'.', 
        (char )'\000'};
static struct PyModuleDef zlibmodule  = 
     {{{1, (struct _typeobject *)((void *)0)}, (PyObject *(*)(void))((void *)0), 0, (PyObject *)((void *)0)}, "zlib", (char const   *)(zlib_module_documentation), -1, zlib_methods, (int (*)(PyObject * ))((void *)0), (int (*)(PyObject * , int (*)(PyObject * , void * ) , void * ))((void *)0), (int (*)(PyObject * ))((void *)0), (void (*)(void * ))((void *)0)};
PyObject *PyInit_zlib(void) 
{ PyObject *m ;
  PyObject *ver ;
  int tmp ;
  int tmp___0 ;

  {
  tmp = PyType_Ready(& Comptype);
  if (tmp < 0) {
    return ((PyObject *)((void *)0));
  } else {

  }
  tmp___0 = PyType_Ready(& Decomptype);
  if (tmp___0 < 0) {
    return ((PyObject *)((void *)0));
  } else {

  }
  m = PyModule_Create2(& zlibmodule, 1013);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    return ((PyObject *)((void *)0));
  } else {

  }
  ZlibError = PyErr_NewException("zlib.error", (PyObject *)((void *)0), (PyObject *)((void *)0));
  if ((unsigned int )ZlibError != (unsigned int )((void *)0)) {
    (ZlibError->ob_refcnt) ++;
    PyModule_AddObject(m, "error", ZlibError);
  } else {

  }
  PyModule_AddIntConstant(m, "MAX_WBITS", 15L);
  PyModule_AddIntConstant(m, "DEFLATED", 8L);
  PyModule_AddIntConstant(m, "DEF_MEM_LEVEL", 8L);
  PyModule_AddIntConstant(m, "Z_BEST_SPEED", 1L);
  PyModule_AddIntConstant(m, "Z_BEST_COMPRESSION", 9L);
  PyModule_AddIntConstant(m, "Z_DEFAULT_COMPRESSION", -1L);
  PyModule_AddIntConstant(m, "Z_FILTERED", 1L);
  PyModule_AddIntConstant(m, "Z_HUFFMAN_ONLY", 2L);
  PyModule_AddIntConstant(m, "Z_DEFAULT_STRATEGY", 0L);
  PyModule_AddIntConstant(m, "Z_FINISH", 4L);
  PyModule_AddIntConstant(m, "Z_NO_FLUSH", 0L);
  PyModule_AddIntConstant(m, "Z_SYNC_FLUSH", 2L);
  PyModule_AddIntConstant(m, "Z_FULL_FLUSH", 3L);
  ver = PyUnicodeUCS2_FromString("1.2.3");
  if ((unsigned int )ver != (unsigned int )((void *)0)) {
    PyModule_AddObject(m, "ZLIB_VERSION", ver);
  } else {

  }
  PyModule_AddStringConstant(m, "__version__", "1.0");
  return (m);
}
}
