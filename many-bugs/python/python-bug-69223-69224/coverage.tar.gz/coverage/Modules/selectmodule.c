struct _IO_FILE;
struct _IO_FILE *_coverage_fout  ;
char ___coverage_array[1157] ;
int ___coverage_array_already_memset ;
int ___coverage_array_already_memset  =    0;
typedef unsigned int size_t;
typedef unsigned char __u_char;
typedef unsigned short __u_short;
typedef unsigned int __u_int;
typedef unsigned long __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;
typedef long long __quad_t;
typedef unsigned long long __u_quad_t;
typedef __u_quad_t __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef __u_quad_t __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long __off_t;
typedef __quad_t __off64_t;
typedef int __pid_t;
struct __anonstruct___fsid_t_1 {
   int __val[2] ;
};
typedef struct __anonstruct___fsid_t_1 __fsid_t;
typedef long __clock_t;
typedef unsigned long __rlim_t;
typedef __u_quad_t __rlim64_t;
typedef unsigned int __id_t;
typedef long __time_t;
typedef unsigned int __useconds_t;
typedef long __suseconds_t;
typedef int __daddr_t;
typedef long __swblk_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void *__timer_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef __quad_t __blkcnt64_t;
typedef unsigned long __fsblkcnt_t;
typedef __u_quad_t __fsblkcnt64_t;
typedef unsigned long __fsfilcnt_t;
typedef __u_quad_t __fsfilcnt64_t;
typedef int __ssize_t;
typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;
typedef int __intptr_t;
typedef unsigned int __socklen_t;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_3 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_2 {
   int __count ;
   union __anonunion___value_3 __value ;
};
typedef struct __anonstruct___mbstate_t_2 __mbstate_t;
struct __anonstruct__G_fpos_t_4 {
   __off_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos_t_4 _G_fpos_t;
struct __anonstruct__G_fpos64_t_5 {
   __off64_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos64_t_5 _G_fpos64_t;
typedef short _G_int16_t;
typedef int _G_int32_t;
typedef unsigned short _G_uint16_t;
typedef unsigned int _G_uint32_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_jump_t;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
enum __codecvt_result {
    __codecvt_ok = 0,
    __codecvt_partial = 1,
    __codecvt_error = 2,
    __codecvt_noconv = 3
} ;
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15UL * sizeof(int ) - 4UL * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
struct _IO_FILE_plus;
typedef __ssize_t __io_read_fn(void *__cookie , char *__buf , size_t __nbytes );
typedef __ssize_t __io_write_fn(void *__cookie , char const   *__buf ,
                                size_t __n );
typedef int __io_seek_fn(void *__cookie , __off64_t *__pos , int __w );
typedef int __io_close_fn(void *__cookie );
typedef __io_read_fn cookie_read_function_t;
typedef __io_write_fn cookie_write_function_t;
typedef __io_seek_fn cookie_seek_function_t;
typedef __io_close_fn cookie_close_function_t;
struct __anonstruct__IO_cookie_io_functions_t_6 {
   __io_read_fn *read ;
   __io_write_fn *write ;
   __io_seek_fn *seek ;
   __io_close_fn *close ;
};
typedef struct __anonstruct__IO_cookie_io_functions_t_6 _IO_cookie_io_functions_t;
typedef _IO_cookie_io_functions_t cookie_io_functions_t;
struct _IO_cookie_file;
typedef __gnuc_va_list va_list;
typedef __off64_t off_t;
typedef __off64_t off64_t;
typedef __ssize_t ssize_t;
typedef _G_fpos64_t fpos_t;
typedef _G_fpos64_t fpos64_t;
struct obstack;
struct __locale_data;
struct __locale_struct {
   struct __locale_data *__locales[13] ;
   unsigned short const   *__ctype_b ;
   int const   *__ctype_tolower ;
   int const   *__ctype_toupper ;
   char const   *__names[13] ;
};
typedef struct __locale_struct *__locale_t;
typedef __locale_t locale_t;
typedef int error_t;
typedef long wchar_t;
struct __anonstruct___wait_terminated_7 {
   unsigned int __w_termsig : 7 ;
   unsigned int __w_coredump : 1 ;
   unsigned int __w_retcode : 8 ;
   unsigned int  : 16 ;
};
struct __anonstruct___wait_stopped_8 {
   unsigned int __w_stopval : 8 ;
   unsigned int __w_stopsig : 8 ;
   unsigned int  : 16 ;
};
union wait {
   int w_status ;
   struct __anonstruct___wait_terminated_7 __wait_terminated ;
   struct __anonstruct___wait_stopped_8 __wait_stopped ;
};
union __anonunion___WAIT_STATUS_9 {
   union wait *__uptr ;
   int *__iptr ;
};
typedef union __anonunion___WAIT_STATUS_9  __attribute__((__transparent_union__)) __WAIT_STATUS;
struct __anonstruct_div_t_10 {
   int quot ;
   int rem ;
};
typedef struct __anonstruct_div_t_10 div_t;
struct __anonstruct_ldiv_t_11 {
   long quot ;
   long rem ;
};
typedef struct __anonstruct_ldiv_t_11 ldiv_t;
struct __anonstruct_lldiv_t_12 {
   long long quot ;
   long long rem ;
};
typedef struct __anonstruct_lldiv_t_12 lldiv_t;
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;
typedef __loff_t loff_t;
typedef __ino64_t ino_t;
typedef __ino64_t ino64_t;
typedef __dev_t dev_t;
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __nlink_t nlink_t;
typedef __uid_t uid_t;
typedef __pid_t pid_t;
typedef __id_t id_t;
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;
typedef __key_t key_t;
typedef __clock_t clock_t;
typedef __time_t time_t;
typedef __clockid_t clockid_t;
typedef __timer_t timer_t;
typedef __useconds_t useconds_t;
typedef __suseconds_t suseconds_t;
typedef unsigned long ulong;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long int64_t;
typedef unsigned char u_int8_t;
typedef unsigned short u_int16_t;
typedef unsigned int u_int32_t;
typedef unsigned long u_int64_t;
typedef int register_t;
typedef int __sig_atomic_t;
struct __anonstruct___sigset_t_13 {
   unsigned long __val[1024UL / (8UL * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_13 __sigset_t;
typedef __sigset_t sigset_t;
struct timespec {
   __time_t tv_sec ;
   long tv_nsec ;
};
struct timeval {
   __time_t tv_sec ;
   __suseconds_t tv_usec ;
};
typedef long __fd_mask;
struct __anonstruct_fd_set_14 {
   __fd_mask fds_bits[1024 / (8 * (int )sizeof(__fd_mask ))] ;
};
typedef struct __anonstruct_fd_set_14 fd_set;
typedef __fd_mask fd_mask;
typedef __blksize_t blksize_t;
typedef __blkcnt64_t blkcnt_t;
typedef __fsblkcnt64_t fsblkcnt_t;
typedef __fsfilcnt64_t fsfilcnt_t;
typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;
typedef unsigned long pthread_t;
union __anonunion_pthread_attr_t_15 {
   char __size[36] ;
   long __align ;
};
typedef union __anonunion_pthread_attr_t_15 pthread_attr_t;
struct __pthread_internal_slist {
   struct __pthread_internal_slist *__next ;
};
typedef struct __pthread_internal_slist __pthread_slist_t;
union __anonunion____missing_field_name_17 {
   int __spins ;
   __pthread_slist_t __list ;
};
struct __pthread_mutex_s {
   int __lock ;
   unsigned int __count ;
   int __owner ;
   int __kind ;
   unsigned int __nusers ;
   union __anonunion____missing_field_name_17 __annonCompField1 ;
};
union __anonunion_pthread_mutex_t_16 {
   struct __pthread_mutex_s __data ;
   char __size[24] ;
   long __align ;
};
typedef union __anonunion_pthread_mutex_t_16 pthread_mutex_t;
union __anonunion_pthread_mutexattr_t_18 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_mutexattr_t_18 pthread_mutexattr_t;
struct __anonstruct___data_20 {
   int __lock ;
   unsigned int __futex ;
   unsigned long long __total_seq ;
   unsigned long long __wakeup_seq ;
   unsigned long long __woken_seq ;
   void *__mutex ;
   unsigned int __nwaiters ;
   unsigned int __broadcast_seq ;
};
union __anonunion_pthread_cond_t_19 {
   struct __anonstruct___data_20 __data ;
   char __size[48] ;
   long long __align ;
};
typedef union __anonunion_pthread_cond_t_19 pthread_cond_t;
union __anonunion_pthread_condattr_t_21 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_condattr_t_21 pthread_condattr_t;
typedef unsigned int pthread_key_t;
typedef int pthread_once_t;
struct __anonstruct___data_23 {
   int __lock ;
   unsigned int __nr_readers ;
   unsigned int __readers_wakeup ;
   unsigned int __writer_wakeup ;
   unsigned int __nr_readers_queued ;
   unsigned int __nr_writers_queued ;
   unsigned char __flags ;
   unsigned char __shared ;
   unsigned char __pad1 ;
   unsigned char __pad2 ;
   int __writer ;
};
union __anonunion_pthread_rwlock_t_22 {
   struct __anonstruct___data_23 __data ;
   char __size[32] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlock_t_22 pthread_rwlock_t;
union __anonunion_pthread_rwlockattr_t_24 {
   char __size[8] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlockattr_t_24 pthread_rwlockattr_t;
typedef int volatile   pthread_spinlock_t;
union __anonunion_pthread_barrier_t_25 {
   char __size[20] ;
   long __align ;
};
typedef union __anonunion_pthread_barrier_t_25 pthread_barrier_t;
union __anonunion_pthread_barrierattr_t_26 {
   char __size[4] ;
   int __align ;
};
typedef union __anonunion_pthread_barrierattr_t_26 pthread_barrierattr_t;
struct random_data {
   int32_t *fptr ;
   int32_t *rptr ;
   int32_t *state ;
   int rand_type ;
   int rand_deg ;
   int rand_sep ;
   int32_t *end_ptr ;
};
struct drand48_data {
   unsigned short __x[3] ;
   unsigned short __old_x[3] ;
   unsigned short __c ;
   unsigned short __init ;
   unsigned long long __a ;
};
typedef int (*__compar_fn_t)(void const   * , void const   * );
typedef int (*comparison_fn_t)(void const   * , void const   * );
typedef int (*__compar_d_fn_t)(void const   * , void const   * , void * );
typedef __intptr_t intptr_t;
typedef __socklen_t socklen_t;
enum __anonenum_27 {
    _PC_LINK_MAX = 0,
    _PC_MAX_CANON = 1,
    _PC_MAX_INPUT = 2,
    _PC_NAME_MAX = 3,
    _PC_PATH_MAX = 4,
    _PC_PIPE_BUF = 5,
    _PC_CHOWN_RESTRICTED = 6,
    _PC_NO_TRUNC = 7,
    _PC_VDISABLE = 8,
    _PC_SYNC_IO = 9,
    _PC_ASYNC_IO = 10,
    _PC_PRIO_IO = 11,
    _PC_SOCK_MAXBUF = 12,
    _PC_FILESIZEBITS = 13,
    _PC_REC_INCR_XFER_SIZE = 14,
    _PC_REC_MAX_XFER_SIZE = 15,
    _PC_REC_MIN_XFER_SIZE = 16,
    _PC_REC_XFER_ALIGN = 17,
    _PC_ALLOC_SIZE_MIN = 18,
    _PC_SYMLINK_MAX = 19,
    _PC_2_SYMLINKS = 20
} ;
enum __anonenum_28 {
    _SC_ARG_MAX = 0,
    _SC_CHILD_MAX = 1,
    _SC_CLK_TCK = 2,
    _SC_NGROUPS_MAX = 3,
    _SC_OPEN_MAX = 4,
    _SC_STREAM_MAX = 5,
    _SC_TZNAME_MAX = 6,
    _SC_JOB_CONTROL = 7,
    _SC_SAVED_IDS = 8,
    _SC_REALTIME_SIGNALS = 9,
    _SC_PRIORITY_SCHEDULING = 10,
    _SC_TIMERS = 11,
    _SC_ASYNCHRONOUS_IO = 12,
    _SC_PRIORITIZED_IO = 13,
    _SC_SYNCHRONIZED_IO = 14,
    _SC_FSYNC = 15,
    _SC_MAPPED_FILES = 16,
    _SC_MEMLOCK = 17,
    _SC_MEMLOCK_RANGE = 18,
    _SC_MEMORY_PROTECTION = 19,
    _SC_MESSAGE_PASSING = 20,
    _SC_SEMAPHORES = 21,
    _SC_SHARED_MEMORY_OBJECTS = 22,
    _SC_AIO_LISTIO_MAX = 23,
    _SC_AIO_MAX = 24,
    _SC_AIO_PRIO_DELTA_MAX = 25,
    _SC_DELAYTIMER_MAX = 26,
    _SC_MQ_OPEN_MAX = 27,
    _SC_MQ_PRIO_MAX = 28,
    _SC_VERSION = 29,
    _SC_PAGESIZE = 30,
    _SC_RTSIG_MAX = 31,
    _SC_SEM_NSEMS_MAX = 32,
    _SC_SEM_VALUE_MAX = 33,
    _SC_SIGQUEUE_MAX = 34,
    _SC_TIMER_MAX = 35,
    _SC_BC_BASE_MAX = 36,
    _SC_BC_DIM_MAX = 37,
    _SC_BC_SCALE_MAX = 38,
    _SC_BC_STRING_MAX = 39,
    _SC_COLL_WEIGHTS_MAX = 40,
    _SC_EQUIV_CLASS_MAX = 41,
    _SC_EXPR_NEST_MAX = 42,
    _SC_LINE_MAX = 43,
    _SC_RE_DUP_MAX = 44,
    _SC_CHARCLASS_NAME_MAX = 45,
    _SC_2_VERSION = 46,
    _SC_2_C_BIND = 47,
    _SC_2_C_DEV = 48,
    _SC_2_FORT_DEV = 49,
    _SC_2_FORT_RUN = 50,
    _SC_2_SW_DEV = 51,
    _SC_2_LOCALEDEF = 52,
    _SC_PII = 53,
    _SC_PII_XTI = 54,
    _SC_PII_SOCKET = 55,
    _SC_PII_INTERNET = 56,
    _SC_PII_OSI = 57,
    _SC_POLL = 58,
    _SC_SELECT = 59,
    _SC_UIO_MAXIOV = 60,
    _SC_IOV_MAX = 60,
    _SC_PII_INTERNET_STREAM = 61,
    _SC_PII_INTERNET_DGRAM = 62,
    _SC_PII_OSI_COTS = 63,
    _SC_PII_OSI_CLTS = 64,
    _SC_PII_OSI_M = 65,
    _SC_T_IOV_MAX = 66,
    _SC_THREADS = 67,
    _SC_THREAD_SAFE_FUNCTIONS = 68,
    _SC_GETGR_R_SIZE_MAX = 69,
    _SC_GETPW_R_SIZE_MAX = 70,
    _SC_LOGIN_NAME_MAX = 71,
    _SC_TTY_NAME_MAX = 72,
    _SC_THREAD_DESTRUCTOR_ITERATIONS = 73,
    _SC_THREAD_KEYS_MAX = 74,
    _SC_THREAD_STACK_MIN = 75,
    _SC_THREAD_THREADS_MAX = 76,
    _SC_THREAD_ATTR_STACKADDR = 77,
    _SC_THREAD_ATTR_STACKSIZE = 78,
    _SC_THREAD_PRIORITY_SCHEDULING = 79,
    _SC_THREAD_PRIO_INHERIT = 80,
    _SC_THREAD_PRIO_PROTECT = 81,
    _SC_THREAD_PROCESS_SHARED = 82,
    _SC_NPROCESSORS_CONF = 83,
    _SC_NPROCESSORS_ONLN = 84,
    _SC_PHYS_PAGES = 85,
    _SC_AVPHYS_PAGES = 86,
    _SC_ATEXIT_MAX = 87,
    _SC_PASS_MAX = 88,
    _SC_XOPEN_VERSION = 89,
    _SC_XOPEN_XCU_VERSION = 90,
    _SC_XOPEN_UNIX = 91,
    _SC_XOPEN_CRYPT = 92,
    _SC_XOPEN_ENH_I18N = 93,
    _SC_XOPEN_SHM = 94,
    _SC_2_CHAR_TERM = 95,
    _SC_2_C_VERSION = 96,
    _SC_2_UPE = 97,
    _SC_XOPEN_XPG2 = 98,
    _SC_XOPEN_XPG3 = 99,
    _SC_XOPEN_XPG4 = 100,
    _SC_CHAR_BIT = 101,
    _SC_CHAR_MAX = 102,
    _SC_CHAR_MIN = 103,
    _SC_INT_MAX = 104,
    _SC_INT_MIN = 105,
    _SC_LONG_BIT = 106,
    _SC_WORD_BIT = 107,
    _SC_MB_LEN_MAX = 108,
    _SC_NZERO = 109,
    _SC_SSIZE_MAX = 110,
    _SC_SCHAR_MAX = 111,
    _SC_SCHAR_MIN = 112,
    _SC_SHRT_MAX = 113,
    _SC_SHRT_MIN = 114,
    _SC_UCHAR_MAX = 115,
    _SC_UINT_MAX = 116,
    _SC_ULONG_MAX = 117,
    _SC_USHRT_MAX = 118,
    _SC_NL_ARGMAX = 119,
    _SC_NL_LANGMAX = 120,
    _SC_NL_MSGMAX = 121,
    _SC_NL_NMAX = 122,
    _SC_NL_SETMAX = 123,
    _SC_NL_TEXTMAX = 124,
    _SC_XBS5_ILP32_OFF32 = 125,
    _SC_XBS5_ILP32_OFFBIG = 126,
    _SC_XBS5_LP64_OFF64 = 127,
    _SC_XBS5_LPBIG_OFFBIG = 128,
    _SC_XOPEN_LEGACY = 129,
    _SC_XOPEN_REALTIME = 130,
    _SC_XOPEN_REALTIME_THREADS = 131,
    _SC_ADVISORY_INFO = 132,
    _SC_BARRIERS = 133,
    _SC_BASE = 134,
    _SC_C_LANG_SUPPORT = 135,
    _SC_C_LANG_SUPPORT_R = 136,
    _SC_CLOCK_SELECTION = 137,
    _SC_CPUTIME = 138,
    _SC_THREAD_CPUTIME = 139,
    _SC_DEVICE_IO = 140,
    _SC_DEVICE_SPECIFIC = 141,
    _SC_DEVICE_SPECIFIC_R = 142,
    _SC_FD_MGMT = 143,
    _SC_FIFO = 144,
    _SC_PIPE = 145,
    _SC_FILE_ATTRIBUTES = 146,
    _SC_FILE_LOCKING = 147,
    _SC_FILE_SYSTEM = 148,
    _SC_MONOTONIC_CLOCK = 149,
    _SC_MULTI_PROCESS = 150,
    _SC_SINGLE_PROCESS = 151,
    _SC_NETWORKING = 152,
    _SC_READER_WRITER_LOCKS = 153,
    _SC_SPIN_LOCKS = 154,
    _SC_REGEXP = 155,
    _SC_REGEX_VERSION = 156,
    _SC_SHELL = 157,
    _SC_SIGNALS = 158,
    _SC_SPAWN = 159,
    _SC_SPORADIC_SERVER = 160,
    _SC_THREAD_SPORADIC_SERVER = 161,
    _SC_SYSTEM_DATABASE = 162,
    _SC_SYSTEM_DATABASE_R = 163,
    _SC_TIMEOUTS = 164,
    _SC_TYPED_MEMORY_OBJECTS = 165,
    _SC_USER_GROUPS = 166,
    _SC_USER_GROUPS_R = 167,
    _SC_2_PBS = 168,
    _SC_2_PBS_ACCOUNTING = 169,
    _SC_2_PBS_LOCATE = 170,
    _SC_2_PBS_MESSAGE = 171,
    _SC_2_PBS_TRACK = 172,
    _SC_SYMLOOP_MAX = 173,
    _SC_STREAMS = 174,
    _SC_2_PBS_CHECKPOINT = 175,
    _SC_V6_ILP32_OFF32 = 176,
    _SC_V6_ILP32_OFFBIG = 177,
    _SC_V6_LP64_OFF64 = 178,
    _SC_V6_LPBIG_OFFBIG = 179,
    _SC_HOST_NAME_MAX = 180,
    _SC_TRACE = 181,
    _SC_TRACE_EVENT_FILTER = 182,
    _SC_TRACE_INHERIT = 183,
    _SC_TRACE_LOG = 184,
    _SC_LEVEL1_ICACHE_SIZE = 185,
    _SC_LEVEL1_ICACHE_ASSOC = 186,
    _SC_LEVEL1_ICACHE_LINESIZE = 187,
    _SC_LEVEL1_DCACHE_SIZE = 188,
    _SC_LEVEL1_DCACHE_ASSOC = 189,
    _SC_LEVEL1_DCACHE_LINESIZE = 190,
    _SC_LEVEL2_CACHE_SIZE = 191,
    _SC_LEVEL2_CACHE_ASSOC = 192,
    _SC_LEVEL2_CACHE_LINESIZE = 193,
    _SC_LEVEL3_CACHE_SIZE = 194,
    _SC_LEVEL3_CACHE_ASSOC = 195,
    _SC_LEVEL3_CACHE_LINESIZE = 196,
    _SC_LEVEL4_CACHE_SIZE = 197,
    _SC_LEVEL4_CACHE_ASSOC = 198,
    _SC_LEVEL4_CACHE_LINESIZE = 199,
    _SC_IPV6 = 235,
    _SC_RAW_SOCKETS = 236,
    _SC_V7_ILP32_OFF32 = 237,
    _SC_V7_ILP32_OFFBIG = 238,
    _SC_V7_LP64_OFF64 = 239,
    _SC_V7_LPBIG_OFFBIG = 240,
    _SC_SS_REPL_MAX = 241,
    _SC_TRACE_EVENT_NAME_MAX = 242,
    _SC_TRACE_NAME_MAX = 243,
    _SC_TRACE_SYS_MAX = 244,
    _SC_TRACE_USER_EVENT_MAX = 245,
    _SC_XOPEN_STREAMS = 246,
    _SC_THREAD_ROBUST_PRIO_INHERIT = 247,
    _SC_THREAD_ROBUST_PRIO_PROTECT = 248
} ;
enum __anonenum_29 {
    _CS_PATH = 0,
    _CS_V6_WIDTH_RESTRICTED_ENVS = 1,
    _CS_GNU_LIBC_VERSION = 2,
    _CS_GNU_LIBPTHREAD_VERSION = 3,
    _CS_V5_WIDTH_RESTRICTED_ENVS = 4,
    _CS_V7_WIDTH_RESTRICTED_ENVS = 5,
    _CS_LFS_CFLAGS = 1000,
    _CS_LFS_LDFLAGS = 1001,
    _CS_LFS_LIBS = 1002,
    _CS_LFS_LINTFLAGS = 1003,
    _CS_LFS64_CFLAGS = 1004,
    _CS_LFS64_LDFLAGS = 1005,
    _CS_LFS64_LIBS = 1006,
    _CS_LFS64_LINTFLAGS = 1007,
    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,
    _CS_XBS5_ILP32_OFF32_LDFLAGS = 1101,
    _CS_XBS5_ILP32_OFF32_LIBS = 1102,
    _CS_XBS5_ILP32_OFF32_LINTFLAGS = 1103,
    _CS_XBS5_ILP32_OFFBIG_CFLAGS = 1104,
    _CS_XBS5_ILP32_OFFBIG_LDFLAGS = 1105,
    _CS_XBS5_ILP32_OFFBIG_LIBS = 1106,
    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS = 1107,
    _CS_XBS5_LP64_OFF64_CFLAGS = 1108,
    _CS_XBS5_LP64_OFF64_LDFLAGS = 1109,
    _CS_XBS5_LP64_OFF64_LIBS = 1110,
    _CS_XBS5_LP64_OFF64_LINTFLAGS = 1111,
    _CS_XBS5_LPBIG_OFFBIG_CFLAGS = 1112,
    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS = 1113,
    _CS_XBS5_LPBIG_OFFBIG_LIBS = 1114,
    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS = 1115,
    _CS_POSIX_V6_ILP32_OFF32_CFLAGS = 1116,
    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS = 1117,
    _CS_POSIX_V6_ILP32_OFF32_LIBS = 1118,
    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS = 1119,
    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS = 1120,
    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS = 1121,
    _CS_POSIX_V6_ILP32_OFFBIG_LIBS = 1122,
    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS = 1123,
    _CS_POSIX_V6_LP64_OFF64_CFLAGS = 1124,
    _CS_POSIX_V6_LP64_OFF64_LDFLAGS = 1125,
    _CS_POSIX_V6_LP64_OFF64_LIBS = 1126,
    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS = 1127,
    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS = 1128,
    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS = 1129,
    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS = 1130,
    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS = 1131,
    _CS_POSIX_V7_ILP32_OFF32_CFLAGS = 1132,
    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS = 1133,
    _CS_POSIX_V7_ILP32_OFF32_LIBS = 1134,
    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS = 1135,
    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS = 1136,
    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS = 1137,
    _CS_POSIX_V7_ILP32_OFFBIG_LIBS = 1138,
    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS = 1139,
    _CS_POSIX_V7_LP64_OFF64_CFLAGS = 1140,
    _CS_POSIX_V7_LP64_OFF64_LDFLAGS = 1141,
    _CS_POSIX_V7_LP64_OFF64_LIBS = 1142,
    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS = 1143,
    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS = 1144,
    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS = 1145,
    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS = 1146,
    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS = 1147,
    _CS_V6_ENV = 1148,
    _CS_V7_ENV = 1149
} ;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef signed char int_least8_t;
typedef short int_least16_t;
typedef int int_least32_t;
typedef long long int_least64_t;
typedef unsigned char uint_least8_t;
typedef unsigned short uint_least16_t;
typedef unsigned int uint_least32_t;
typedef unsigned long long uint_least64_t;
typedef signed char int_fast8_t;
typedef int int_fast16_t;
typedef int int_fast32_t;
typedef long long int_fast64_t;
typedef unsigned char uint_fast8_t;
typedef unsigned int uint_fast16_t;
typedef unsigned int uint_fast32_t;
typedef unsigned long long uint_fast64_t;
typedef unsigned int uintptr_t;
typedef long long intmax_t;
typedef unsigned long long uintmax_t;
typedef long __gwchar_t;
struct __anonstruct_imaxdiv_t_30 {
   long long quot ;
   long long rem ;
};
typedef struct __anonstruct_imaxdiv_t_30 imaxdiv_t;
typedef uintptr_t Py_uintptr_t;
typedef intptr_t Py_intptr_t;
typedef ssize_t Py_ssize_t;
typedef Py_ssize_t Py_hash_t;
typedef size_t Py_uhash_t;
typedef long double float_t;
typedef long double double_t;
enum __anonenum_31 {
    FP_NAN = 0,
    FP_INFINITE = 1,
    FP_ZERO = 2,
    FP_SUBNORMAL = 3,
    FP_NORMAL = 4
} ;
enum __anonenum__LIB_VERSION_TYPE_32 {
    _IEEE_ = -1,
    _SVID_ = 0,
    _XOPEN_ = 1,
    _POSIX_ = 2,
    _ISOC_ = 3
} ;
typedef enum __anonenum__LIB_VERSION_TYPE_32 _LIB_VERSION_TYPE;
struct exception {
   int type ;
   char *name ;
   double arg1 ;
   double arg2 ;
   double retval ;
};
union __anonunion___u_33 {
   float __f ;
   int __i ;
};
union __anonunion___u_34 {
   double __d ;
   int __i[2] ;
};
union __anonunion___u_35 {
   long double __l ;
   int __i[3] ;
};
union __anonunion___n_36 {
   long double __xld ;
   unsigned int __xi[3] ;
};
union __anonunion_37 {
   double __d ;
   int __i[2] ;
};
struct timezone {
   int tz_minuteswest ;
   int tz_dsttime ;
};
typedef struct timezone * __restrict  __timezone_ptr_t;
enum __itimer_which {
    ITIMER_REAL = 0,
    ITIMER_VIRTUAL = 1,
    ITIMER_PROF = 2
} ;
struct itimerval {
   struct timeval it_interval ;
   struct timeval it_value ;
};
typedef enum __itimer_which __itimer_which_t;
struct tm {
   int tm_sec ;
   int tm_min ;
   int tm_hour ;
   int tm_mday ;
   int tm_mon ;
   int tm_year ;
   int tm_wday ;
   int tm_yday ;
   int tm_isdst ;
   long tm_gmtoff ;
   char const   *tm_zone ;
};
struct itimerspec {
   struct timespec it_interval ;
   struct timespec it_value ;
};
struct sigevent;
struct stat {
   __dev_t st_dev ;
   unsigned short __pad1 ;
   __ino_t __st_ino ;
   __mode_t st_mode ;
   __nlink_t st_nlink ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   __dev_t st_rdev ;
   unsigned short __pad2 ;
   __off64_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt64_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __ino64_t st_ino ;
};
struct stat64 {
   __dev_t st_dev ;
   unsigned int __pad1 ;
   __ino_t __st_ino ;
   __mode_t st_mode ;
   __nlink_t st_nlink ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   __dev_t st_rdev ;
   unsigned int __pad2 ;
   __off64_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt64_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __ino64_t st_ino ;
};
enum _Py_memory_order {
    _Py_memory_order_relaxed = 0,
    _Py_memory_order_acquire = 1,
    _Py_memory_order_release = 2,
    _Py_memory_order_acq_rel = 3,
    _Py_memory_order_seq_cst = 4
} ;
typedef enum _Py_memory_order _Py_memory_order;
struct _Py_atomic_address {
   void *_value ;
};
typedef struct _Py_atomic_address _Py_atomic_address;
struct _Py_atomic_int {
   int _value ;
};
typedef struct _Py_atomic_int _Py_atomic_int;
typedef struct timeval _PyTime_timeval;
struct _typeobject;
struct _object {
   Py_ssize_t ob_refcnt ;
   struct _typeobject *ob_type ;
};
typedef struct _object PyObject;
struct __anonstruct_PyVarObject_38 {
   PyObject ob_base ;
   Py_ssize_t ob_size ;
};
typedef struct __anonstruct_PyVarObject_38 PyVarObject;
typedef PyObject *(*unaryfunc)(PyObject * );
typedef PyObject *(*binaryfunc)(PyObject * , PyObject * );
typedef PyObject *(*ternaryfunc)(PyObject * , PyObject * , PyObject * );
typedef int (*inquiry)(PyObject * );
typedef Py_ssize_t (*lenfunc)(PyObject * );
typedef PyObject *(*ssizeargfunc)(PyObject * , Py_ssize_t  );
typedef PyObject *(*ssizessizeargfunc)(PyObject * , Py_ssize_t  , Py_ssize_t  );
typedef int (*ssizeobjargproc)(PyObject * , Py_ssize_t  , PyObject * );
typedef int (*ssizessizeobjargproc)(PyObject * , Py_ssize_t  , Py_ssize_t  ,
                                    PyObject * );
typedef int (*objobjargproc)(PyObject * , PyObject * , PyObject * );
struct bufferinfo {
   void *buf ;
   PyObject *obj ;
   Py_ssize_t len ;
   Py_ssize_t itemsize ;
   int readonly ;
   int ndim ;
   char *format ;
   Py_ssize_t *shape ;
   Py_ssize_t *strides ;
   Py_ssize_t *suboffsets ;
   Py_ssize_t smalltable[2] ;
   void *internal ;
};
typedef struct bufferinfo Py_buffer;
typedef int (*getbufferproc)(PyObject * , Py_buffer * , int  );
typedef void (*releasebufferproc)(PyObject * , Py_buffer * );
typedef int (*objobjproc)(PyObject * , PyObject * );
typedef int (*visitproc)(PyObject * , void * );
typedef int (*traverseproc)(PyObject * , int (*)(PyObject * , void * ) , void * );
struct __anonstruct_PyNumberMethods_39 {
   PyObject *(*nb_add)(PyObject * , PyObject * ) ;
   PyObject *(*nb_subtract)(PyObject * , PyObject * ) ;
   PyObject *(*nb_multiply)(PyObject * , PyObject * ) ;
   PyObject *(*nb_remainder)(PyObject * , PyObject * ) ;
   PyObject *(*nb_divmod)(PyObject * , PyObject * ) ;
   PyObject *(*nb_power)(PyObject * , PyObject * , PyObject * ) ;
   PyObject *(*nb_negative)(PyObject * ) ;
   PyObject *(*nb_positive)(PyObject * ) ;
   PyObject *(*nb_absolute)(PyObject * ) ;
   int (*nb_bool)(PyObject * ) ;
   PyObject *(*nb_invert)(PyObject * ) ;
   PyObject *(*nb_lshift)(PyObject * , PyObject * ) ;
   PyObject *(*nb_rshift)(PyObject * , PyObject * ) ;
   PyObject *(*nb_and)(PyObject * , PyObject * ) ;
   PyObject *(*nb_xor)(PyObject * , PyObject * ) ;
   PyObject *(*nb_or)(PyObject * , PyObject * ) ;
   PyObject *(*nb_int)(PyObject * ) ;
   void *nb_reserved ;
   PyObject *(*nb_float)(PyObject * ) ;
   PyObject *(*nb_inplace_add)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_subtract)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_multiply)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_remainder)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_power)(PyObject * , PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_lshift)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_rshift)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_and)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_xor)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_or)(PyObject * , PyObject * ) ;
   PyObject *(*nb_floor_divide)(PyObject * , PyObject * ) ;
   PyObject *(*nb_true_divide)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_floor_divide)(PyObject * , PyObject * ) ;
   PyObject *(*nb_inplace_true_divide)(PyObject * , PyObject * ) ;
   PyObject *(*nb_index)(PyObject * ) ;
};
typedef struct __anonstruct_PyNumberMethods_39 PyNumberMethods;
struct __anonstruct_PySequenceMethods_40 {
   Py_ssize_t (*sq_length)(PyObject * ) ;
   PyObject *(*sq_concat)(PyObject * , PyObject * ) ;
   PyObject *(*sq_repeat)(PyObject * , Py_ssize_t  ) ;
   PyObject *(*sq_item)(PyObject * , Py_ssize_t  ) ;
   void *was_sq_slice ;
   int (*sq_ass_item)(PyObject * , Py_ssize_t  , PyObject * ) ;
   void *was_sq_ass_slice ;
   int (*sq_contains)(PyObject * , PyObject * ) ;
   PyObject *(*sq_inplace_concat)(PyObject * , PyObject * ) ;
   PyObject *(*sq_inplace_repeat)(PyObject * , Py_ssize_t  ) ;
};
typedef struct __anonstruct_PySequenceMethods_40 PySequenceMethods;
struct __anonstruct_PyMappingMethods_41 {
   Py_ssize_t (*mp_length)(PyObject * ) ;
   PyObject *(*mp_subscript)(PyObject * , PyObject * ) ;
   int (*mp_ass_subscript)(PyObject * , PyObject * , PyObject * ) ;
};
typedef struct __anonstruct_PyMappingMethods_41 PyMappingMethods;
struct __anonstruct_PyBufferProcs_42 {
   int (*bf_getbuffer)(PyObject * , Py_buffer * , int  ) ;
   void (*bf_releasebuffer)(PyObject * , Py_buffer * ) ;
};
typedef struct __anonstruct_PyBufferProcs_42 PyBufferProcs;
typedef void (*freefunc)(void * );
typedef void (*destructor)(PyObject * );
typedef int (*printfunc)(PyObject * , FILE * , int  );
typedef PyObject *(*getattrfunc)(PyObject * , char * );
typedef PyObject *(*getattrofunc)(PyObject * , PyObject * );
typedef int (*setattrfunc)(PyObject * , char * , PyObject * );
typedef int (*setattrofunc)(PyObject * , PyObject * , PyObject * );
typedef PyObject *(*reprfunc)(PyObject * );
typedef Py_hash_t (*hashfunc)(PyObject * );
typedef PyObject *(*richcmpfunc)(PyObject * , PyObject * , int  );
typedef PyObject *(*getiterfunc)(PyObject * );
typedef PyObject *(*iternextfunc)(PyObject * );
typedef PyObject *(*descrgetfunc)(PyObject * , PyObject * , PyObject * );
typedef int (*descrsetfunc)(PyObject * , PyObject * , PyObject * );
typedef int (*initproc)(PyObject * , PyObject * , PyObject * );
typedef PyObject *(*newfunc)(struct _typeobject * , PyObject * , PyObject * );
typedef PyObject *(*allocfunc)(struct _typeobject * , Py_ssize_t  );
struct PyMethodDef;
struct PyMemberDef;
struct PyGetSetDef;
struct _typeobject {
   PyVarObject ob_base ;
   char const   *tp_name ;
   Py_ssize_t tp_basicsize ;
   Py_ssize_t tp_itemsize ;
   void (*tp_dealloc)(PyObject * ) ;
   int (*tp_print)(PyObject * , FILE * , int  ) ;
   PyObject *(*tp_getattr)(PyObject * , char * ) ;
   int (*tp_setattr)(PyObject * , char * , PyObject * ) ;
   void *tp_reserved ;
   PyObject *(*tp_repr)(PyObject * ) ;
   PyNumberMethods *tp_as_number ;
   PySequenceMethods *tp_as_sequence ;
   PyMappingMethods *tp_as_mapping ;
   Py_hash_t (*tp_hash)(PyObject * ) ;
   PyObject *(*tp_call)(PyObject * , PyObject * , PyObject * ) ;
   PyObject *(*tp_str)(PyObject * ) ;
   PyObject *(*tp_getattro)(PyObject * , PyObject * ) ;
   int (*tp_setattro)(PyObject * , PyObject * , PyObject * ) ;
   PyBufferProcs *tp_as_buffer ;
   long tp_flags ;
   char const   *tp_doc ;
   int (*tp_traverse)(PyObject * , int (*)(PyObject * , void * ) , void * ) ;
   int (*tp_clear)(PyObject * ) ;
   PyObject *(*tp_richcompare)(PyObject * , PyObject * , int  ) ;
   Py_ssize_t tp_weaklistoffset ;
   PyObject *(*tp_iter)(PyObject * ) ;
   PyObject *(*tp_iternext)(PyObject * ) ;
   struct PyMethodDef *tp_methods ;
   struct PyMemberDef *tp_members ;
   struct PyGetSetDef *tp_getset ;
   struct _typeobject *tp_base ;
   PyObject *tp_dict ;
   PyObject *(*tp_descr_get)(PyObject * , PyObject * , PyObject * ) ;
   int (*tp_descr_set)(PyObject * , PyObject * , PyObject * ) ;
   Py_ssize_t tp_dictoffset ;
   int (*tp_init)(PyObject * , PyObject * , PyObject * ) ;
   PyObject *(*tp_alloc)(struct _typeobject * , Py_ssize_t  ) ;
   PyObject *(*tp_new)(struct _typeobject * , PyObject * , PyObject * ) ;
   void (*tp_free)(void * ) ;
   int (*tp_is_gc)(PyObject * ) ;
   PyObject *tp_bases ;
   PyObject *tp_mro ;
   PyObject *tp_cache ;
   PyObject *tp_subclasses ;
   PyObject *tp_weaklist ;
   void (*tp_del)(PyObject * ) ;
   unsigned int tp_version_tag ;
};
typedef struct _typeobject PyTypeObject;
struct __anonstruct_PyType_Slot_43 {
   int slot ;
   void *pfunc ;
};
typedef struct __anonstruct_PyType_Slot_43 PyType_Slot;
struct __anonstruct_PyType_Spec_44 {
   char const   *name ;
   int basicsize ;
   int itemsize ;
   int flags ;
   PyType_Slot *slots ;
};
typedef struct __anonstruct_PyType_Spec_44 PyType_Spec;
struct _heaptypeobject {
   PyTypeObject ht_type ;
   PyNumberMethods as_number ;
   PyMappingMethods as_mapping ;
   PySequenceMethods as_sequence ;
   PyBufferProcs as_buffer ;
   PyObject *ht_name ;
   PyObject *ht_slots ;
};
typedef struct _heaptypeobject PyHeapTypeObject;
union _gc_head;
struct __anonstruct_gc_45 {
   union _gc_head *gc_next ;
   union _gc_head *gc_prev ;
   Py_ssize_t gc_refs ;
};
union _gc_head {
   struct __anonstruct_gc_45 gc ;
   long double dummy ;
};
typedef union _gc_head PyGC_Head;
struct __anonstruct_PyByteArrayObject_46 {
   PyVarObject ob_base ;
   int ob_exports ;
   Py_ssize_t ob_alloc ;
   char *ob_bytes ;
};
typedef struct __anonstruct_PyByteArrayObject_46 PyByteArrayObject;
struct __anonstruct_PyBytesObject_47 {
   PyVarObject ob_base ;
   Py_hash_t ob_shash ;
   char ob_sval[1] ;
};
typedef struct __anonstruct_PyBytesObject_47 PyBytesObject;
enum __anonenum_48 {
    _ISupper = 256,
    _ISlower = 512,
    _ISalpha = 1024,
    _ISdigit = 2048,
    _ISxdigit = 4096,
    _ISspace = 8192,
    _ISprint = 16384,
    _ISgraph = 32768,
    _ISblank = 1,
    _IScntrl = 2,
    _ISpunct = 4,
    _ISalnum = 8
} ;
typedef unsigned int wint_t;
typedef __mbstate_t mbstate_t;
typedef unsigned int Py_UCS4;
typedef unsigned short Py_UNICODE;
struct __anonstruct_PyUnicodeObject_49 {
   PyObject ob_base ;
   Py_ssize_t length ;
   Py_UNICODE *str ;
   Py_hash_t hash ;
   int state ;
   PyObject *defenc ;
};
typedef struct __anonstruct_PyUnicodeObject_49 PyUnicodeObject;
struct _longobject;
typedef struct _longobject PyLongObject;
typedef unsigned short digit;
typedef short sdigit;
typedef unsigned long twodigits;
typedef long stwodigits;
struct _longobject {
   PyVarObject ob_base ;
   digit ob_digit[1] ;
};
struct __anonstruct_PyFloatObject_50 {
   PyObject ob_base ;
   double ob_fval ;
};
typedef struct __anonstruct_PyFloatObject_50 PyFloatObject;
struct __anonstruct_Py_complex_51 {
   double real ;
   double imag ;
};
typedef struct __anonstruct_Py_complex_51 Py_complex;
struct __anonstruct_PyComplexObject_52 {
   PyObject ob_base ;
   Py_complex cval ;
};
typedef struct __anonstruct_PyComplexObject_52 PyComplexObject;
struct __anonstruct_PyMemoryViewObject_53 {
   PyObject ob_base ;
   Py_buffer view ;
};
typedef struct __anonstruct_PyMemoryViewObject_53 PyMemoryViewObject;
struct __anonstruct_PyTupleObject_54 {
   PyVarObject ob_base ;
   PyObject *ob_item[1] ;
};
typedef struct __anonstruct_PyTupleObject_54 PyTupleObject;
struct __anonstruct_PyListObject_55 {
   PyVarObject ob_base ;
   PyObject **ob_item ;
   Py_ssize_t allocated ;
};
typedef struct __anonstruct_PyListObject_55 PyListObject;
struct __anonstruct_PyDictEntry_56 {
   Py_hash_t me_hash ;
   PyObject *me_key ;
   PyObject *me_value ;
};
typedef struct __anonstruct_PyDictEntry_56 PyDictEntry;
struct _dictobject;
typedef struct _dictobject PyDictObject;
struct _dictobject {
   PyObject ob_base ;
   Py_ssize_t ma_fill ;
   Py_ssize_t ma_used ;
   Py_ssize_t ma_mask ;
   PyDictEntry *ma_table ;
   PyDictEntry *(*ma_lookup)(PyDictObject *mp , PyObject *key , Py_hash_t hash ) ;
   PyDictEntry ma_smalltable[8] ;
};
struct __anonstruct_setentry_57 {
   Py_hash_t hash ;
   PyObject *key ;
};
typedef struct __anonstruct_setentry_57 setentry;
struct _setobject;
typedef struct _setobject PySetObject;
struct _setobject {
   PyObject ob_base ;
   Py_ssize_t fill ;
   Py_ssize_t used ;
   Py_ssize_t mask ;
   setentry *table ;
   setentry *(*lookup)(PySetObject *so , PyObject *key , Py_hash_t hash ) ;
   setentry smalltable[8] ;
   Py_hash_t hash ;
   PyObject *weakreflist ;
};
typedef PyObject *(*PyCFunction)(PyObject * , PyObject * );
typedef PyObject *(*PyCFunctionWithKeywords)(PyObject * , PyObject * ,
                                             PyObject * );
typedef PyObject *(*PyNoArgsFunction)(PyObject * );
struct PyMethodDef {
   char const   *ml_name ;
   PyObject *(*ml_meth)(PyObject * , PyObject * ) ;
   int ml_flags ;
   char const   *ml_doc ;
};
typedef struct PyMethodDef PyMethodDef;
struct __anonstruct_PyCFunctionObject_58 {
   PyObject ob_base ;
   PyMethodDef *m_ml ;
   PyObject *m_self ;
   PyObject *m_module ;
};
typedef struct __anonstruct_PyCFunctionObject_58 PyCFunctionObject;
struct PyModuleDef;
struct PyModuleDef_Base {
   PyObject ob_base ;
   PyObject *(*m_init)(void) ;
   Py_ssize_t m_index ;
   PyObject *m_copy ;
};
typedef struct PyModuleDef_Base PyModuleDef_Base;
struct PyModuleDef {
   PyModuleDef_Base m_base ;
   char const   *m_name ;
   char const   *m_doc ;
   Py_ssize_t m_size ;
   PyMethodDef *m_methods ;
   int (*m_reload)(PyObject * ) ;
   int (*m_traverse)(PyObject * , int (*)(PyObject * , void * ) , void * ) ;
   int (*m_clear)(PyObject * ) ;
   void (*m_free)(void * ) ;
};
typedef struct PyModuleDef PyModuleDef;
struct __anonstruct_PyFunctionObject_59 {
   PyObject ob_base ;
   PyObject *func_code ;
   PyObject *func_globals ;
   PyObject *func_defaults ;
   PyObject *func_kwdefaults ;
   PyObject *func_closure ;
   PyObject *func_doc ;
   PyObject *func_name ;
   PyObject *func_dict ;
   PyObject *func_weakreflist ;
   PyObject *func_module ;
   PyObject *func_annotations ;
};
typedef struct __anonstruct_PyFunctionObject_59 PyFunctionObject;
struct __anonstruct_PyMethodObject_60 {
   PyObject ob_base ;
   PyObject *im_func ;
   PyObject *im_self ;
   PyObject *im_weakreflist ;
};
typedef struct __anonstruct_PyMethodObject_60 PyMethodObject;
struct __anonstruct_PyInstanceMethodObject_61 {
   PyObject ob_base ;
   PyObject *func ;
};
typedef struct __anonstruct_PyInstanceMethodObject_61 PyInstanceMethodObject;
typedef void (*PyCapsule_Destructor)(PyObject * );
struct _ts;
struct _is;
struct _is {
   struct _is *next ;
   struct _ts *tstate_head ;
   PyObject *modules ;
   PyObject *modules_by_index ;
   PyObject *sysdict ;
   PyObject *builtins ;
   PyObject *modules_reloading ;
   PyObject *codec_search_path ;
   PyObject *codec_search_cache ;
   PyObject *codec_error_registry ;
   int codecs_initialized ;
   int dlopenflags ;
};
typedef struct _is PyInterpreterState;
struct _frame;
typedef int (*Py_tracefunc)(PyObject * , struct _frame * , int  , PyObject * );
struct _ts {
   struct _ts *next ;
   PyInterpreterState *interp ;
   struct _frame *frame ;
   int recursion_depth ;
   char overflowed ;
   char recursion_critical ;
   int tracing ;
   int use_tracing ;
   int (*c_profilefunc)(PyObject * , struct _frame * , int  , PyObject * ) ;
   int (*c_tracefunc)(PyObject * , struct _frame * , int  , PyObject * ) ;
   PyObject *c_profileobj ;
   PyObject *c_traceobj ;
   PyObject *curexc_type ;
   PyObject *curexc_value ;
   PyObject *curexc_traceback ;
   PyObject *exc_type ;
   PyObject *exc_value ;
   PyObject *exc_traceback ;
   PyObject *dict ;
   int tick_counter ;
   int gilstate_counter ;
   PyObject *async_exc ;
   long thread_id ;
};
typedef struct _ts PyThreadState;
enum __anonenum_PyGILState_STATE_62 {
    PyGILState_LOCKED = 0,
    PyGILState_UNLOCKED = 1
} ;
typedef enum __anonenum_PyGILState_STATE_62 PyGILState_STATE;
typedef struct _frame *(*PyThreadFrameGetter)(PyThreadState *self_ );
struct _traceback {
   PyObject ob_base ;
   struct _traceback *tb_next ;
   struct _frame *tb_frame ;
   int tb_lasti ;
   int tb_lineno ;
};
typedef struct _traceback PyTracebackObject;
struct __anonstruct_PySliceObject_63 {
   PyObject ob_base ;
   PyObject *start ;
   PyObject *stop ;
   PyObject *step ;
};
typedef struct __anonstruct_PySliceObject_63 PySliceObject;
struct __anonstruct_PyCellObject_64 {
   PyObject ob_base ;
   PyObject *ob_ref ;
};
typedef struct __anonstruct_PyCellObject_64 PyCellObject;
struct __anonstruct_PyGenObject_65 {
   PyObject ob_base ;
   struct _frame *gi_frame ;
   int gi_running ;
   PyObject *gi_code ;
   PyObject *gi_weakreflist ;
};
typedef struct __anonstruct_PyGenObject_65 PyGenObject;
typedef PyObject *(*getter)(PyObject * , void * );
typedef int (*setter)(PyObject * , PyObject * , void * );
struct PyGetSetDef {
   char *name ;
   PyObject *(*get)(PyObject * , void * ) ;
   int (*set)(PyObject * , PyObject * , void * ) ;
   char *doc ;
   void *closure ;
};
typedef struct PyGetSetDef PyGetSetDef;
typedef PyObject *(*wrapperfunc)(PyObject *self , PyObject *args ,
                                 void *wrapped );
typedef PyObject *(*wrapperfunc_kwds)(PyObject *self , PyObject *args ,
                                      void *wrapped , PyObject *kwds );
struct wrapperbase {
   char *name ;
   int offset ;
   void *function ;
   PyObject *(*wrapper)(PyObject *self , PyObject *args , void *wrapped ) ;
   char *doc ;
   int flags ;
   PyObject *name_strobj ;
};
struct __anonstruct_PyDescrObject_66 {
   PyObject ob_base ;
   PyTypeObject *d_type ;
   PyObject *d_name ;
};
typedef struct __anonstruct_PyDescrObject_66 PyDescrObject;
struct __anonstruct_PyMethodDescrObject_67 {
   PyDescrObject d_common ;
   PyMethodDef *d_method ;
};
typedef struct __anonstruct_PyMethodDescrObject_67 PyMethodDescrObject;
struct __anonstruct_PyMemberDescrObject_68 {
   PyDescrObject d_common ;
   struct PyMemberDef *d_member ;
};
typedef struct __anonstruct_PyMemberDescrObject_68 PyMemberDescrObject;
struct __anonstruct_PyGetSetDescrObject_69 {
   PyDescrObject d_common ;
   PyGetSetDef *d_getset ;
};
typedef struct __anonstruct_PyGetSetDescrObject_69 PyGetSetDescrObject;
struct __anonstruct_PyWrapperDescrObject_70 {
   PyDescrObject d_common ;
   struct wrapperbase *d_base ;
   void *d_wrapped ;
};
typedef struct __anonstruct_PyWrapperDescrObject_70 PyWrapperDescrObject;
struct _PyWeakReference;
typedef struct _PyWeakReference PyWeakReference;
struct _PyWeakReference {
   PyObject ob_base ;
   PyObject *wr_object ;
   PyObject *wr_callback ;
   Py_hash_t hash ;
   PyWeakReference *wr_prev ;
   PyWeakReference *wr_next ;
};
struct PyStructSequence_Field {
   char *name ;
   char *doc ;
};
typedef struct PyStructSequence_Field PyStructSequence_Field;
struct PyStructSequence_Desc {
   char *name ;
   char *doc ;
   struct PyStructSequence_Field *fields ;
   int n_in_sequence ;
};
typedef struct PyStructSequence_Desc PyStructSequence_Desc;
typedef PyTupleObject PyStructSequence;
struct __anonstruct_PyBaseExceptionObject_71 {
   PyObject ob_base ;
   PyObject *dict ;
   PyObject *args ;
   PyObject *traceback ;
   PyObject *context ;
   PyObject *cause ;
};
typedef struct __anonstruct_PyBaseExceptionObject_71 PyBaseExceptionObject;
struct __anonstruct_PySyntaxErrorObject_72 {
   PyObject ob_base ;
   PyObject *dict ;
   PyObject *args ;
   PyObject *traceback ;
   PyObject *context ;
   PyObject *cause ;
   PyObject *msg ;
   PyObject *filename ;
   PyObject *lineno ;
   PyObject *offset ;
   PyObject *text ;
   PyObject *print_file_and_line ;
};
typedef struct __anonstruct_PySyntaxErrorObject_72 PySyntaxErrorObject;
struct __anonstruct_PyUnicodeErrorObject_73 {
   PyObject ob_base ;
   PyObject *dict ;
   PyObject *args ;
   PyObject *traceback ;
   PyObject *context ;
   PyObject *cause ;
   PyObject *encoding ;
   PyObject *object ;
   Py_ssize_t start ;
   Py_ssize_t end ;
   PyObject *reason ;
};
typedef struct __anonstruct_PyUnicodeErrorObject_73 PyUnicodeErrorObject;
struct __anonstruct_PySystemExitObject_74 {
   PyObject ob_base ;
   PyObject *dict ;
   PyObject *args ;
   PyObject *traceback ;
   PyObject *context ;
   PyObject *cause ;
   PyObject *code ;
};
typedef struct __anonstruct_PySystemExitObject_74 PySystemExitObject;
struct __anonstruct_PyEnvironmentErrorObject_75 {
   PyObject ob_base ;
   PyObject *dict ;
   PyObject *args ;
   PyObject *traceback ;
   PyObject *context ;
   PyObject *cause ;
   PyObject *myerrno ;
   PyObject *strerror ;
   PyObject *filename ;
};
typedef struct __anonstruct_PyEnvironmentErrorObject_75 PyEnvironmentErrorObject;
struct _arena;
typedef struct _arena PyArena;
struct __anonstruct_PyCompilerFlags_76 {
   int cf_flags ;
};
typedef struct __anonstruct_PyCompilerFlags_76 PyCompilerFlags;
struct _mod;
struct _node;
struct symtable;
typedef void (*PyOS_sighandler_t)(int  );
struct _inittab {
   char *name ;
   PyObject *(*initfunc)(void) ;
};
struct _frozen {
   char *name ;
   unsigned char *code ;
   int size ;
};
struct __anonstruct_PyCodeObject_77 {
   PyObject ob_base ;
   int co_argcount ;
   int co_kwonlyargcount ;
   int co_nlocals ;
   int co_stacksize ;
   int co_flags ;
   PyObject *co_code ;
   PyObject *co_consts ;
   PyObject *co_names ;
   PyObject *co_varnames ;
   PyObject *co_freevars ;
   PyObject *co_cellvars ;
   PyObject *co_filename ;
   PyObject *co_name ;
   int co_firstlineno ;
   PyObject *co_lnotab ;
   void *co_zombieframe ;
   PyObject *co_weakreflist ;
};
typedef struct __anonstruct_PyCodeObject_77 PyCodeObject;
struct _addr_pair {
   int ap_lower ;
   int ap_upper ;
};
typedef struct _addr_pair PyAddrPair;
struct __anonstruct_PyFutureFeatures_78 {
   int ff_features ;
   int ff_lineno ;
};
typedef struct __anonstruct_PyFutureFeatures_78 PyFutureFeatures;
typedef int ptrdiff_t;
struct PyMemberDef {
   char *name ;
   int type ;
   Py_ssize_t offset ;
   int flags ;
   char *doc ;
};
typedef struct PyMemberDef PyMemberDef;
typedef unsigned long nfds_t;
struct pollfd {
   int fd ;
   short events ;
   short revents ;
};
struct __anonstruct_pylist_79 {
   PyObject *obj ;
   int fd ;
   int sentinel ;
};
typedef struct __anonstruct_pylist_79 pylist;
struct __anonstruct_pollObject_80 {
   PyObject ob_base ;
   PyObject *dict ;
   int ufd_uptodate ;
   int ufd_len ;
   struct pollfd *ufds ;
};
typedef struct __anonstruct_pollObject_80 pollObject;
enum __anonenum_81 {
    EPOLL_CLOEXEC = 524288,
    EPOLL_NONBLOCK = 2048
} ;
enum EPOLL_EVENTS {
    EPOLLIN = 1,
    EPOLLPRI = 2,
    EPOLLOUT = 4,
    EPOLLRDNORM = 64,
    EPOLLRDBAND = 128,
    EPOLLWRNORM = 256,
    EPOLLWRBAND = 512,
    EPOLLMSG = 1024,
    EPOLLERR = 8,
    EPOLLHUP = 16,
    EPOLLRDHUP = 8192,
    EPOLLONESHOT = 1073741824,
    EPOLLET = (-0x7FFFFFFF-1)
} ;
union epoll_data {
   void *ptr ;
   int fd ;
   uint32_t u32 ;
   uint64_t u64 ;
};
typedef union epoll_data epoll_data_t;
struct epoll_event {
   uint32_t events ;
   epoll_data_t data ;
};
struct __anonstruct_pyEpoll_Object_82 {
   PyObject ob_base ;
   int epfd ;
};
typedef struct __anonstruct_pyEpoll_Object_82 pyEpoll_Object;
extern struct _IO_FILE_plus _IO_2_1_stdin_ ;
extern struct _IO_FILE_plus _IO_2_1_stdout_ ;
extern struct _IO_FILE_plus _IO_2_1_stderr_ ;
extern void _IO_cookie_init(struct _IO_cookie_file *__cfile , int __read_write ,
                            void *__cookie , _IO_cookie_io_functions_t __fns ) ;
extern int __underflow(_IO_FILE * ) ;
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_feof(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_ferror(_IO_FILE *__fp ) ;
extern int _IO_peekc_locked(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) void _IO_flockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) void _IO_funlockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) int _IO_ftrylockfile(_IO_FILE * ) ;
extern int _IO_vfscanf(_IO_FILE * __restrict   , char const   * __restrict   ,
                       __gnuc_va_list  , int * __restrict   ) ;
extern int _IO_vfprintf(_IO_FILE * __restrict   , char const   * __restrict   ,
                        __gnuc_va_list  ) ;
extern __ssize_t _IO_padn(_IO_FILE * , int  , __ssize_t  ) ;
extern size_t _IO_sgetn(_IO_FILE * , void * , size_t  ) ;
extern __off64_t _IO_seekoff(_IO_FILE * , __off64_t  , int  , int  ) ;
extern __off64_t _IO_seekpos(_IO_FILE * , __off64_t  , int  ) ;
extern  __attribute__((__nothrow__)) void _IO_free_backup_area(_IO_FILE * ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
extern  __attribute__((__nothrow__)) int remove(char const   *__filename ) ;
extern  __attribute__((__nothrow__)) int rename(char const   *__old ,
                                                char const   *__new ) ;
extern  __attribute__((__nothrow__)) int renameat(int __oldfd ,
                                                  char const   *__old ,
                                                  int __newfd ,
                                                  char const   *__new ) ;
extern FILE *tmpfile(void)  __asm__("tmpfile64")  ;
extern FILE *tmpfile64(void) ;
extern  __attribute__((__nothrow__)) char *tmpnam(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tmpnam_r(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tempnam(char const   *__dir ,
                                                   char const   *__pfx )  __attribute__((__malloc__)) ;
extern int fclose(FILE *__stream ) ;
extern int fflush(FILE *__stream ) ;
extern int fflush_unlocked(FILE *__stream ) ;
extern int fcloseall(void) ;
extern FILE *fopen(char const   * __restrict  __filename ,
                   char const   * __restrict  __modes )  __asm__("fopen64")  ;
extern FILE *freopen(char const   * __restrict  __filename ,
                     char const   * __restrict  __modes ,
                     FILE * __restrict  __stream )  __asm__("freopen64")  ;
extern FILE *fopen64(char const   * __restrict  __filename ,
                     char const   * __restrict  __modes ) ;
extern FILE *freopen64(char const   * __restrict  __filename ,
                       char const   * __restrict  __modes ,
                       FILE * __restrict  __stream ) ;
extern  __attribute__((__nothrow__)) FILE *fdopen(int __fd ,
                                                  char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *fopencookie(void * __restrict  __magic_cookie ,
                                                       char const   * __restrict  __modes ,
                                                       _IO_cookie_io_functions_t __io_funcs ) ;
extern  __attribute__((__nothrow__)) FILE *fmemopen(void *__s , size_t __len ,
                                                    char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *open_memstream(char **__bufloc ,
                                                          size_t *__sizeloc ) ;
extern  __attribute__((__nothrow__)) void setbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) int setvbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ,
                                                 int __modes , size_t __n ) ;
extern  __attribute__((__nothrow__)) void setbuffer(FILE * __restrict  __stream ,
                                                    char * __restrict  __buf ,
                                                    size_t __size ) ;
extern  __attribute__((__nothrow__)) void setlinebuf(FILE *__stream ) ;
extern int fprintf(FILE * __restrict  __stream ,
                   char const   * __restrict  __format  , ...) ;
extern int printf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sprintf(char * __restrict  __s ,
                                                 char const   * __restrict  __format 
                                                 , ...) ;
extern int vfprintf(FILE * __restrict  __s ,
                    char const   * __restrict  __format , __gnuc_va_list __arg ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vsprintf(char * __restrict  __s ,
                                                  char const   * __restrict  __format ,
                                                  __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  snprintf)(char * __restrict  __s ,
                                                                             size_t __maxlen ,
                                                                             char const   * __restrict  __format 
                                                                             , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsnprintf)(char * __restrict  __s ,
                                                                              size_t __maxlen ,
                                                                              char const   * __restrict  __format ,
                                                                              __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vasprintf)(char ** __restrict  __ptr ,
                                                                              char const   * __restrict  __f ,
                                                                              __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  __asprintf)(char ** __restrict  __ptr ,
                                                                               char const   * __restrict  __fmt 
                                                                               , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  asprintf)(char ** __restrict  __ptr ,
                                                                             char const   * __restrict  __fmt 
                                                                             , ...) ;
extern int ( /* format attribute */  vdprintf)(int __fd ,
                                               char const   * __restrict  __fmt ,
                                               __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  dprintf)(int __fd ,
                                              char const   * __restrict  __fmt 
                                              , ...) ;
extern int fscanf(FILE * __restrict  __stream ,
                  char const   * __restrict  __format  , ...) ;
extern int scanf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sscanf(char const   * __restrict  __s ,
                                                char const   * __restrict  __format 
                                                , ...) ;
extern int ( /* format attribute */  vfscanf)(FILE * __restrict  __s ,
                                              char const   * __restrict  __format ,
                                              __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  vscanf)(char const   * __restrict  __format ,
                                             __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsscanf)(char const   * __restrict  __s ,
                                                                            char const   * __restrict  __format ,
                                                                            __gnuc_va_list __arg ) ;
extern int fgetc(FILE *__stream ) ;
extern int getc(FILE *__stream ) ;
__inline extern int getchar(void) ;
__inline extern int getc_unlocked(FILE *__fp ) ;
__inline extern int getchar_unlocked(void) ;
__inline extern int fgetc_unlocked(FILE *__fp ) ;
extern int fputc(int __c , FILE *__stream ) ;
extern int putc(int __c , FILE *__stream ) ;
__inline extern int putchar(int __c ) ;
__inline extern int fputc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putchar_unlocked(int __c ) ;
extern int getw(FILE *__stream ) ;
extern int putw(int __w , FILE *__stream ) ;
extern char *fgets(char * __restrict  __s , int __n ,
                   FILE * __restrict  __stream ) ;
extern char *gets(char *__s ) ;
extern char *fgets_unlocked(char * __restrict  __s , int __n ,
                            FILE * __restrict  __stream ) ;
extern __ssize_t __getdelim(char ** __restrict  __lineptr ,
                            size_t * __restrict  __n , int __delimiter ,
                            FILE * __restrict  __stream ) ;
extern __ssize_t getdelim(char ** __restrict  __lineptr ,
                          size_t * __restrict  __n , int __delimiter ,
                          FILE * __restrict  __stream ) ;
__inline extern __ssize_t getline(char ** __restrict  __lineptr ,
                                  size_t * __restrict  __n ,
                                  FILE * __restrict  __stream ) ;
extern int fputs(char const   * __restrict  __s , FILE * __restrict  __stream ) ;
extern int puts(char const   *__s ) ;
extern int ungetc(int __c , FILE *__stream ) ;
extern size_t fread(void * __restrict  __ptr , size_t __size , size_t __n ,
                    FILE * __restrict  __stream ) ;
extern size_t fwrite(void const   * __restrict  __ptr , size_t __size ,
                     size_t __n , FILE * __restrict  __s ) ;
extern int fputs_unlocked(char const   * __restrict  __s ,
                          FILE * __restrict  __stream ) ;
extern size_t fread_unlocked(void * __restrict  __ptr , size_t __size ,
                             size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite_unlocked(void const   * __restrict  __ptr , size_t __size ,
                              size_t __n , FILE * __restrict  __stream ) ;
extern int fseek(FILE *__stream , long __off , int __whence ) ;
extern long ftell(FILE *__stream ) ;
extern void rewind(FILE *__stream ) ;
extern int fseeko(FILE *__stream , __off64_t __off , int __whence )  __asm__("fseeko64")  ;
extern __off64_t ftello(FILE *__stream )  __asm__("ftello64")  ;
extern int fgetpos(FILE * __restrict  __stream , fpos_t * __restrict  __pos )  __asm__("fgetpos64")  ;
extern int fsetpos(FILE *__stream , fpos_t const   *__pos )  __asm__("fsetpos64")  ;
extern int fseeko64(FILE *__stream , __off64_t __off , int __whence ) ;
extern __off64_t ftello64(FILE *__stream ) ;
extern int fgetpos64(FILE * __restrict  __stream , fpos64_t * __restrict  __pos ) ;
extern int fsetpos64(FILE *__stream , fpos64_t const   *__pos ) ;
extern  __attribute__((__nothrow__)) void clearerr(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int feof(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ferror(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void clearerr_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
extern void perror(char const   *__s ) ;
extern int sys_nerr ;
extern char const   * const  sys_errlist[] ;
extern int _sys_nerr ;
extern char const   * const  _sys_errlist[] ;
extern  __attribute__((__nothrow__)) int fileno(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int fileno_unlocked(FILE *__stream ) ;
extern FILE *popen(char const   *__command , char const   *__modes ) ;
extern int pclose(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) char *ctermid(char *__s ) ;
extern char *cuserid(char *__s ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  obstack_printf)(struct obstack * __restrict  __obstack ,
                                                                                   char const   * __restrict  __format 
                                                                                   , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  obstack_vprintf)(struct obstack * __restrict  __obstack ,
                                                                                    char const   * __restrict  __format ,
                                                                                    __gnuc_va_list __args ) ;
extern  __attribute__((__nothrow__)) void flockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ftrylockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void funlockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1))) memset)(void *__s ,
                                                                                     int __c ,
                                                                                     size_t __n ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) 
{ 
  int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[1] == 0) {
    {
    fprintf(_coverage_fout, "1\n");
    fflush(_coverage_fout);
    ___coverage_array[1] = 1;
    }
  }
  }
  tmp = vfprintf((FILE */* __restrict  */)stdout, __fmt, __arg);
  {
  if (___coverage_array[2] == 0) {
    {
    fprintf(_coverage_fout, "2\n");
    fflush(_coverage_fout);
    ___coverage_array[2] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern int getchar(void) 
{ 
  int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[3] == 0) {
    {
    fprintf(_coverage_fout, "3\n");
    fflush(_coverage_fout);
    ___coverage_array[3] = 1;
    }
  }
  }
  tmp = _IO_getc(stdin);
  {
  if (___coverage_array[4] == 0) {
    {
    fprintf(_coverage_fout, "4\n");
    fflush(_coverage_fout);
    ___coverage_array[4] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern int fgetc_unlocked(FILE *__fp ) 
{ 
  long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[5] == 0) {
    {
    fprintf(_coverage_fout, "5\n");
    fflush(_coverage_fout);
    ___coverage_array[5] = 1;
    }
  }
  }
  tmp___3 = __builtin_expect((long )((unsigned long )__fp->_IO_read_ptr >= (unsigned long )__fp->_IO_read_end),
                             0L);
  {
  if (___coverage_array[6] == 0) {
    {
    fprintf(_coverage_fout, "6\n");
    fflush(_coverage_fout);
    ___coverage_array[6] = 1;
    }
  }
  }
  if (tmp___3) {
    {
    if (___coverage_array[7] == 0) {
      {
      fprintf(_coverage_fout, "7\n");
      fflush(_coverage_fout);
      ___coverage_array[7] = 1;
      }
    }
    }
    tmp___0 = __uflow(__fp);
    {
    if (___coverage_array[8] == 0) {
      {
      fprintf(_coverage_fout, "8\n");
      fflush(_coverage_fout);
      ___coverage_array[8] = 1;
      }
    }
    }
    tmp___2 = tmp___0;
  } else {
    {
    if (___coverage_array[9] == 0) {
      {
      fprintf(_coverage_fout, "9\n");
      fflush(_coverage_fout);
      ___coverage_array[9] = 1;
      }
    }
    }
    tmp___1 = __fp->_IO_read_ptr;
    {
    if (___coverage_array[10] == 0) {
      {
      fprintf(_coverage_fout, "10\n");
      fflush(_coverage_fout);
      ___coverage_array[10] = 1;
      }
    }
    }
    (__fp->_IO_read_ptr) ++;
    {
    if (___coverage_array[11] == 0) {
      {
      fprintf(_coverage_fout, "11\n");
      fflush(_coverage_fout);
      ___coverage_array[11] = 1;
      }
    }
    }
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  {
  if (___coverage_array[12] == 0) {
    {
    fprintf(_coverage_fout, "12\n");
    fflush(_coverage_fout);
    ___coverage_array[12] = 1;
    }
  }
  }
  return (tmp___2);
}
}
__inline extern int getc_unlocked(FILE *__fp ) 
{ 
  long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[13] == 0) {
    {
    fprintf(_coverage_fout, "13\n");
    fflush(_coverage_fout);
    ___coverage_array[13] = 1;
    }
  }
  }
  tmp___3 = __builtin_expect((long )((unsigned long )__fp->_IO_read_ptr >= (unsigned long )__fp->_IO_read_end),
                             0L);
  {
  if (___coverage_array[14] == 0) {
    {
    fprintf(_coverage_fout, "14\n");
    fflush(_coverage_fout);
    ___coverage_array[14] = 1;
    }
  }
  }
  if (tmp___3) {
    {
    if (___coverage_array[15] == 0) {
      {
      fprintf(_coverage_fout, "15\n");
      fflush(_coverage_fout);
      ___coverage_array[15] = 1;
      }
    }
    }
    tmp___0 = __uflow(__fp);
    {
    if (___coverage_array[16] == 0) {
      {
      fprintf(_coverage_fout, "16\n");
      fflush(_coverage_fout);
      ___coverage_array[16] = 1;
      }
    }
    }
    tmp___2 = tmp___0;
  } else {
    {
    if (___coverage_array[17] == 0) {
      {
      fprintf(_coverage_fout, "17\n");
      fflush(_coverage_fout);
      ___coverage_array[17] = 1;
      }
    }
    }
    tmp___1 = __fp->_IO_read_ptr;
    {
    if (___coverage_array[18] == 0) {
      {
      fprintf(_coverage_fout, "18\n");
      fflush(_coverage_fout);
      ___coverage_array[18] = 1;
      }
    }
    }
    (__fp->_IO_read_ptr) ++;
    {
    if (___coverage_array[19] == 0) {
      {
      fprintf(_coverage_fout, "19\n");
      fflush(_coverage_fout);
      ___coverage_array[19] = 1;
      }
    }
    }
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  {
  if (___coverage_array[20] == 0) {
    {
    fprintf(_coverage_fout, "20\n");
    fflush(_coverage_fout);
    ___coverage_array[20] = 1;
    }
  }
  }
  return (tmp___2);
}
}
__inline extern int getchar_unlocked(void) 
{ 
  long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[21] == 0) {
    {
    fprintf(_coverage_fout, "21\n");
    fflush(_coverage_fout);
    ___coverage_array[21] = 1;
    }
  }
  }
  tmp___3 = __builtin_expect((long )((unsigned long )stdin->_IO_read_ptr >= (unsigned long )stdin->_IO_read_end),
                             0L);
  {
  if (___coverage_array[22] == 0) {
    {
    fprintf(_coverage_fout, "22\n");
    fflush(_coverage_fout);
    ___coverage_array[22] = 1;
    }
  }
  }
  if (tmp___3) {
    {
    if (___coverage_array[23] == 0) {
      {
      fprintf(_coverage_fout, "23\n");
      fflush(_coverage_fout);
      ___coverage_array[23] = 1;
      }
    }
    }
    tmp___0 = __uflow(stdin);
    {
    if (___coverage_array[24] == 0) {
      {
      fprintf(_coverage_fout, "24\n");
      fflush(_coverage_fout);
      ___coverage_array[24] = 1;
      }
    }
    }
    tmp___2 = tmp___0;
  } else {
    {
    if (___coverage_array[25] == 0) {
      {
      fprintf(_coverage_fout, "25\n");
      fflush(_coverage_fout);
      ___coverage_array[25] = 1;
      }
    }
    }
    tmp___1 = stdin->_IO_read_ptr;
    {
    if (___coverage_array[26] == 0) {
      {
      fprintf(_coverage_fout, "26\n");
      fflush(_coverage_fout);
      ___coverage_array[26] = 1;
      }
    }
    }
    (stdin->_IO_read_ptr) ++;
    {
    if (___coverage_array[27] == 0) {
      {
      fprintf(_coverage_fout, "27\n");
      fflush(_coverage_fout);
      ___coverage_array[27] = 1;
      }
    }
    }
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  {
  if (___coverage_array[28] == 0) {
    {
    fprintf(_coverage_fout, "28\n");
    fflush(_coverage_fout);
    ___coverage_array[28] = 1;
    }
  }
  }
  return (tmp___2);
}
}
__inline extern int putchar(int __c ) 
{ 
  int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[29] == 0) {
    {
    fprintf(_coverage_fout, "29\n");
    fflush(_coverage_fout);
    ___coverage_array[29] = 1;
    }
  }
  }
  tmp = _IO_putc(__c, stdout);
  {
  if (___coverage_array[30] == 0) {
    {
    fprintf(_coverage_fout, "30\n");
    fflush(_coverage_fout);
    ___coverage_array[30] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern int fputc_unlocked(int __c , FILE *__stream ) 
{ 
  long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[31] == 0) {
    {
    fprintf(_coverage_fout, "31\n");
    fflush(_coverage_fout);
    ___coverage_array[31] = 1;
    }
  }
  }
  tmp___4 = __builtin_expect((long )((unsigned long )__stream->_IO_write_ptr >= (unsigned long )__stream->_IO_write_end),
                             0L);
  {
  if (___coverage_array[32] == 0) {
    {
    fprintf(_coverage_fout, "32\n");
    fflush(_coverage_fout);
    ___coverage_array[32] = 1;
    }
  }
  }
  if (tmp___4) {
    {
    if (___coverage_array[33] == 0) {
      {
      fprintf(_coverage_fout, "33\n");
      fflush(_coverage_fout);
      ___coverage_array[33] = 1;
      }
    }
    }
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    {
    if (___coverage_array[34] == 0) {
      {
      fprintf(_coverage_fout, "34\n");
      fflush(_coverage_fout);
      ___coverage_array[34] = 1;
      }
    }
    }
    tmp___3 = tmp___0;
  } else {
    {
    if (___coverage_array[35] == 0) {
      {
      fprintf(_coverage_fout, "35\n");
      fflush(_coverage_fout);
      ___coverage_array[35] = 1;
      }
    }
    }
    tmp___1 = __stream->_IO_write_ptr;
    {
    if (___coverage_array[36] == 0) {
      {
      fprintf(_coverage_fout, "36\n");
      fflush(_coverage_fout);
      ___coverage_array[36] = 1;
      }
    }
    }
    (__stream->_IO_write_ptr) ++;
    {
    if (___coverage_array[37] == 0) {
      {
      fprintf(_coverage_fout, "37\n");
      fflush(_coverage_fout);
      ___coverage_array[37] = 1;
      }
    }
    }
    tmp___2 = (char )__c;
    {
    if (___coverage_array[38] == 0) {
      {
      fprintf(_coverage_fout, "38\n");
      fflush(_coverage_fout);
      ___coverage_array[38] = 1;
      }
    }
    }
    *tmp___1 = tmp___2;
    {
    if (___coverage_array[39] == 0) {
      {
      fprintf(_coverage_fout, "39\n");
      fflush(_coverage_fout);
      ___coverage_array[39] = 1;
      }
    }
    }
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  {
  if (___coverage_array[40] == 0) {
    {
    fprintf(_coverage_fout, "40\n");
    fflush(_coverage_fout);
    ___coverage_array[40] = 1;
    }
  }
  }
  return (tmp___3);
}
}
__inline extern int putc_unlocked(int __c , FILE *__stream ) 
{ 
  long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[41] == 0) {
    {
    fprintf(_coverage_fout, "41\n");
    fflush(_coverage_fout);
    ___coverage_array[41] = 1;
    }
  }
  }
  tmp___4 = __builtin_expect((long )((unsigned long )__stream->_IO_write_ptr >= (unsigned long )__stream->_IO_write_end),
                             0L);
  {
  if (___coverage_array[42] == 0) {
    {
    fprintf(_coverage_fout, "42\n");
    fflush(_coverage_fout);
    ___coverage_array[42] = 1;
    }
  }
  }
  if (tmp___4) {
    {
    if (___coverage_array[43] == 0) {
      {
      fprintf(_coverage_fout, "43\n");
      fflush(_coverage_fout);
      ___coverage_array[43] = 1;
      }
    }
    }
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    {
    if (___coverage_array[44] == 0) {
      {
      fprintf(_coverage_fout, "44\n");
      fflush(_coverage_fout);
      ___coverage_array[44] = 1;
      }
    }
    }
    tmp___3 = tmp___0;
  } else {
    {
    if (___coverage_array[45] == 0) {
      {
      fprintf(_coverage_fout, "45\n");
      fflush(_coverage_fout);
      ___coverage_array[45] = 1;
      }
    }
    }
    tmp___1 = __stream->_IO_write_ptr;
    {
    if (___coverage_array[46] == 0) {
      {
      fprintf(_coverage_fout, "46\n");
      fflush(_coverage_fout);
      ___coverage_array[46] = 1;
      }
    }
    }
    (__stream->_IO_write_ptr) ++;
    {
    if (___coverage_array[47] == 0) {
      {
      fprintf(_coverage_fout, "47\n");
      fflush(_coverage_fout);
      ___coverage_array[47] = 1;
      }
    }
    }
    tmp___2 = (char )__c;
    {
    if (___coverage_array[48] == 0) {
      {
      fprintf(_coverage_fout, "48\n");
      fflush(_coverage_fout);
      ___coverage_array[48] = 1;
      }
    }
    }
    *tmp___1 = tmp___2;
    {
    if (___coverage_array[49] == 0) {
      {
      fprintf(_coverage_fout, "49\n");
      fflush(_coverage_fout);
      ___coverage_array[49] = 1;
      }
    }
    }
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  {
  if (___coverage_array[50] == 0) {
    {
    fprintf(_coverage_fout, "50\n");
    fflush(_coverage_fout);
    ___coverage_array[50] = 1;
    }
  }
  }
  return (tmp___3);
}
}
__inline extern int putchar_unlocked(int __c ) 
{ 
  long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[51] == 0) {
    {
    fprintf(_coverage_fout, "51\n");
    fflush(_coverage_fout);
    ___coverage_array[51] = 1;
    }
  }
  }
  tmp___4 = __builtin_expect((long )((unsigned long )stdout->_IO_write_ptr >= (unsigned long )stdout->_IO_write_end),
                             0L);
  {
  if (___coverage_array[52] == 0) {
    {
    fprintf(_coverage_fout, "52\n");
    fflush(_coverage_fout);
    ___coverage_array[52] = 1;
    }
  }
  }
  if (tmp___4) {
    {
    if (___coverage_array[53] == 0) {
      {
      fprintf(_coverage_fout, "53\n");
      fflush(_coverage_fout);
      ___coverage_array[53] = 1;
      }
    }
    }
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    {
    if (___coverage_array[54] == 0) {
      {
      fprintf(_coverage_fout, "54\n");
      fflush(_coverage_fout);
      ___coverage_array[54] = 1;
      }
    }
    }
    tmp___3 = tmp___0;
  } else {
    {
    if (___coverage_array[55] == 0) {
      {
      fprintf(_coverage_fout, "55\n");
      fflush(_coverage_fout);
      ___coverage_array[55] = 1;
      }
    }
    }
    tmp___1 = stdout->_IO_write_ptr;
    {
    if (___coverage_array[56] == 0) {
      {
      fprintf(_coverage_fout, "56\n");
      fflush(_coverage_fout);
      ___coverage_array[56] = 1;
      }
    }
    }
    (stdout->_IO_write_ptr) ++;
    {
    if (___coverage_array[57] == 0) {
      {
      fprintf(_coverage_fout, "57\n");
      fflush(_coverage_fout);
      ___coverage_array[57] = 1;
      }
    }
    }
    tmp___2 = (char )__c;
    {
    if (___coverage_array[58] == 0) {
      {
      fprintf(_coverage_fout, "58\n");
      fflush(_coverage_fout);
      ___coverage_array[58] = 1;
      }
    }
    }
    *tmp___1 = tmp___2;
    {
    if (___coverage_array[59] == 0) {
      {
      fprintf(_coverage_fout, "59\n");
      fflush(_coverage_fout);
      ___coverage_array[59] = 1;
      }
    }
    }
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  {
  if (___coverage_array[60] == 0) {
    {
    fprintf(_coverage_fout, "60\n");
    fflush(_coverage_fout);
    ___coverage_array[60] = 1;
    }
  }
  }
  return (tmp___3);
}
}
__inline extern __ssize_t getline(char ** __restrict  __lineptr ,
                                  size_t * __restrict  __n ,
                                  FILE * __restrict  __stream ) 
{ 
  __ssize_t tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[61] == 0) {
    {
    fprintf(_coverage_fout, "61\n");
    fflush(_coverage_fout);
    ___coverage_array[61] = 1;
    }
  }
  }
  tmp = __getdelim(__lineptr, __n, '\n', __stream);
  {
  if (___coverage_array[62] == 0) {
    {
    fprintf(_coverage_fout, "62\n");
    fflush(_coverage_fout);
    ___coverage_array[62] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern int feof_unlocked(FILE *__stream ) 
{ 


  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[63] == 0) {
    {
    fprintf(_coverage_fout, "63\n");
    fflush(_coverage_fout);
    ___coverage_array[63] = 1;
    }
  }
  }
  return ((__stream->_flags & 16) != 0);
}
}
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
__inline extern int ferror_unlocked(FILE *__stream ) 
{ 


  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[64] == 0) {
    {
    fprintf(_coverage_fout, "64\n");
    fflush(_coverage_fout);
    ___coverage_array[64] = 1;
    }
  }
  }
  return ((__stream->_flags & 32) != 0);
}
}
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2))) memcpy)(void * __restrict  __dest ,
                                                                                       void const   * __restrict  __src ,
                                                                                       size_t __n ) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2))) memmove)(void *__dest ,
                                                                                        void const   *__src ,
                                                                                        size_t __n ) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2))) memccpy)(void * __restrict  __dest ,
                                                                                        void const   * __restrict  __src ,
                                                                                        int __c ,
                                                                                        size_t __n ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) memcmp)(void const   *__s1 ,
                                                                                     void const   *__s2 ,
                                                                                     size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1))) memchr)(void const   *__s ,
                                                                                     int __c ,
                                                                                     size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1))) rawmemchr)(void const   *__s ,
                                                                                        int __c )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1))) memrchr)(void const   *__s ,
                                                                                      int __c ,
                                                                                      size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2))) strcpy)(char * __restrict  __dest ,
                                                                                       char const   * __restrict  __src ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2))) strncpy)(char * __restrict  __dest ,
                                                                                        char const   * __restrict  __src ,
                                                                                        size_t __n ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2))) strcat)(char * __restrict  __dest ,
                                                                                       char const   * __restrict  __src ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2))) strncat)(char * __restrict  __dest ,
                                                                                        char const   * __restrict  __src ,
                                                                                        size_t __n ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) strcmp)(char const   *__s1 ,
                                                                                     char const   *__s2 )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) strncmp)(char const   *__s1 ,
                                                                                      char const   *__s2 ,
                                                                                      size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) strcoll)(char const   *__s1 ,
                                                                                      char const   *__s2 )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(2))) strxfrm)(char * __restrict  __dest ,
                                                                                       char const   * __restrict  __src ,
                                                                                       size_t __n ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2,3))) strcoll_l)(char const   *__s1 ,
                                                                                          char const   *__s2 ,
                                                                                          __locale_t __l )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(2,4))) strxfrm_l)(char *__dest ,
                                                                                           char const   *__src ,
                                                                                           size_t __n ,
                                                                                           __locale_t __l ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1))) strdup)(char const   *__s )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1))) strndup)(char const   *__string ,
                                                                                      size_t __n )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1))) strchr)(char const   *__s ,
                                                                                     int __c )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1))) strrchr)(char const   *__s ,
                                                                                      int __c )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1))) strchrnul)(char const   *__s ,
                                                                                        int __c )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(1,2))) strcspn)(char const   *__s ,
                                                                                         char const   *__reject )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(1,2))) strspn)(char const   *__s ,
                                                                                        char const   *__accept )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2))) strpbrk)(char const   *__s ,
                                                                                        char const   *__accept )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2))) strstr)(char const   *__haystack ,
                                                                                       char const   *__needle )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(2))) strtok)(char * __restrict  __s ,
                                                                                     char const   * __restrict  __delim ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(2,3))) __strtok_r)(char * __restrict  __s ,
                                                                                           char const   * __restrict  __delim ,
                                                                                           char ** __restrict  __save_ptr ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(2,3))) strtok_r)(char * __restrict  __s ,
                                                                                         char const   * __restrict  __delim ,
                                                                                         char ** __restrict  __save_ptr ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2))) strcasestr)(char const   *__haystack ,
                                                                                           char const   *__needle )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,3))) memmem)(void const   *__haystack ,
                                                                                       size_t __haystacklen ,
                                                                                       void const   *__needle ,
                                                                                       size_t __needlelen )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2))) __mempcpy)(void * __restrict  __dest ,
                                                                                          void const   * __restrict  __src ,
                                                                                          size_t __n ) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1,2))) mempcpy)(void * __restrict  __dest ,
                                                                                        void const   * __restrict  __src ,
                                                                                        size_t __n ) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(1))) strlen)(char const   *__s )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) size_t ( __attribute__((__nonnull__(1))) strnlen)(char const   *__string ,
                                                                                       size_t __maxlen )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *strerror(int __errnum ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(2))) strerror_r)(int __errnum ,
                                                                                         char *__buf ,
                                                                                         size_t __buflen ) ;
extern  __attribute__((__nothrow__)) char *strerror_l(int __errnum ,
                                                      __locale_t __l ) ;
extern  __attribute__((__nothrow__)) void ( __attribute__((__nonnull__(1))) __bzero)(void *__s ,
                                                                                     size_t __n ) ;
extern  __attribute__((__nothrow__)) void ( __attribute__((__nonnull__(1,2))) bcopy)(void const   *__src ,
                                                                                     void *__dest ,
                                                                                     size_t __n ) ;
extern  __attribute__((__nothrow__)) void ( __attribute__((__nonnull__(1))) bzero)(void *__s ,
                                                                                   size_t __n ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) bcmp)(void const   *__s1 ,
                                                                                   void const   *__s2 ,
                                                                                   size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1))) index)(char const   *__s ,
                                                                                    int __c )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1))) rindex)(char const   *__s ,
                                                                                     int __c )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int ffs(int __i )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int ffsl(long __l )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int ffsll(long long __ll )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) strcasecmp)(char const   *__s1 ,
                                                                                         char const   *__s2 )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) strncasecmp)(char const   *__s1 ,
                                                                                          char const   *__s2 ,
                                                                                          size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2,3))) strcasecmp_l)(char const   *__s1 ,
                                                                                             char const   *__s2 ,
                                                                                             __locale_t __loc )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2,4))) strncasecmp_l)(char const   *__s1 ,
                                                                                              char const   *__s2 ,
                                                                                              size_t __n ,
                                                                                              __locale_t __loc )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2))) strsep)(char ** __restrict  __stringp ,
                                                                                       char const   * __restrict  __delim ) ;
extern  __attribute__((__nothrow__)) char *strsignal(int __sig ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2))) __stpcpy)(char * __restrict  __dest ,
                                                                                         char const   * __restrict  __src ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2))) stpcpy)(char * __restrict  __dest ,
                                                                                       char const   * __restrict  __src ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2))) __stpncpy)(char * __restrict  __dest ,
                                                                                          char const   * __restrict  __src ,
                                                                                          size_t __n ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2))) stpncpy)(char * __restrict  __dest ,
                                                                                        char const   * __restrict  __src ,
                                                                                        size_t __n ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) strverscmp)(char const   *__s1 ,
                                                                                         char const   *__s2 )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1))) strfry)(char *__string ) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__nonnull__(1))) memfrob)(void *__s ,
                                                                                      size_t __n ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1))) basename)(char const   *__filename ) ;
extern void *__rawmemchr(void const   *__s , int __c ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) 
{ 
  register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[65] == 0) {
    {
    fprintf(_coverage_fout, "65\n");
    fflush(_coverage_fout);
    ___coverage_array[65] = 1;
    }
  }
  }
  __result = (size_t )0;
  {
  if (___coverage_array[66] == 0) {
    {
    fprintf(_coverage_fout, "66\n");
    fflush(_coverage_fout);
    ___coverage_array[66] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[67] == 0) {
      {
      fprintf(_coverage_fout, "67\n");
      fflush(_coverage_fout);
      ___coverage_array[67] = 1;
      }
    }
    }
    if ((int const   )*(__s + __result) != 0) {
      {
      if (___coverage_array[68] == 0) {
        {
        fprintf(_coverage_fout, "68\n");
        fflush(_coverage_fout);
        ___coverage_array[68] = 1;
        }
      }
      }
      if ((int const   )*(__s + __result) != (int const   )__reject) {
        {
        if (___coverage_array[69] == 0) {
          {
          fprintf(_coverage_fout, "69\n");
          fflush(_coverage_fout);
          ___coverage_array[69] = 1;
          }
        }
        }

      } else {
        {
        if (___coverage_array[70] == 0) {
          {
          fprintf(_coverage_fout, "70\n");
          fflush(_coverage_fout);
          ___coverage_array[70] = 1;
          }
        }
        }
        break;
      }
    } else {
      {
      if (___coverage_array[71] == 0) {
        {
        fprintf(_coverage_fout, "71\n");
        fflush(_coverage_fout);
        ___coverage_array[71] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[72] == 0) {
      {
      fprintf(_coverage_fout, "72\n");
      fflush(_coverage_fout);
      ___coverage_array[72] = 1;
      }
    }
    }
    __result ++;
  }
  {
  if (___coverage_array[73] == 0) {
    {
    fprintf(_coverage_fout, "73\n");
    fflush(_coverage_fout);
    ___coverage_array[73] = 1;
    }
  }
  }
  return (__result);
}
}
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) ;
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) 
{ 
  register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[74] == 0) {
    {
    fprintf(_coverage_fout, "74\n");
    fflush(_coverage_fout);
    ___coverage_array[74] = 1;
    }
  }
  }
  __result = (size_t )0;
  {
  if (___coverage_array[75] == 0) {
    {
    fprintf(_coverage_fout, "75\n");
    fflush(_coverage_fout);
    ___coverage_array[75] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[76] == 0) {
      {
      fprintf(_coverage_fout, "76\n");
      fflush(_coverage_fout);
      ___coverage_array[76] = 1;
      }
    }
    }
    if ((int const   )*(__s + __result) != 0) {
      {
      if (___coverage_array[77] == 0) {
        {
        fprintf(_coverage_fout, "77\n");
        fflush(_coverage_fout);
        ___coverage_array[77] = 1;
        }
      }
      }
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        {
        if (___coverage_array[78] == 0) {
          {
          fprintf(_coverage_fout, "78\n");
          fflush(_coverage_fout);
          ___coverage_array[78] = 1;
          }
        }
        }
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          {
          if (___coverage_array[79] == 0) {
            {
            fprintf(_coverage_fout, "79\n");
            fflush(_coverage_fout);
            ___coverage_array[79] = 1;
            }
          }
          }

        } else {
          {
          if (___coverage_array[80] == 0) {
            {
            fprintf(_coverage_fout, "80\n");
            fflush(_coverage_fout);
            ___coverage_array[80] = 1;
            }
          }
          }
          break;
        }
      } else {
        {
        if (___coverage_array[81] == 0) {
          {
          fprintf(_coverage_fout, "81\n");
          fflush(_coverage_fout);
          ___coverage_array[81] = 1;
          }
        }
        }
        break;
      }
    } else {
      {
      if (___coverage_array[82] == 0) {
        {
        fprintf(_coverage_fout, "82\n");
        fflush(_coverage_fout);
        ___coverage_array[82] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[83] == 0) {
      {
      fprintf(_coverage_fout, "83\n");
      fflush(_coverage_fout);
      ___coverage_array[83] = 1;
      }
    }
    }
    __result ++;
  }
  {
  if (___coverage_array[84] == 0) {
    {
    fprintf(_coverage_fout, "84\n");
    fflush(_coverage_fout);
    ___coverage_array[84] = 1;
    }
  }
  }
  return (__result);
}
}
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) ;
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) 
{ 
  register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[85] == 0) {
    {
    fprintf(_coverage_fout, "85\n");
    fflush(_coverage_fout);
    ___coverage_array[85] = 1;
    }
  }
  }
  __result = (size_t )0;
  {
  if (___coverage_array[86] == 0) {
    {
    fprintf(_coverage_fout, "86\n");
    fflush(_coverage_fout);
    ___coverage_array[86] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[87] == 0) {
      {
      fprintf(_coverage_fout, "87\n");
      fflush(_coverage_fout);
      ___coverage_array[87] = 1;
      }
    }
    }
    if ((int const   )*(__s + __result) != 0) {
      {
      if (___coverage_array[88] == 0) {
        {
        fprintf(_coverage_fout, "88\n");
        fflush(_coverage_fout);
        ___coverage_array[88] = 1;
        }
      }
      }
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        {
        if (___coverage_array[89] == 0) {
          {
          fprintf(_coverage_fout, "89\n");
          fflush(_coverage_fout);
          ___coverage_array[89] = 1;
          }
        }
        }
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          {
          if (___coverage_array[90] == 0) {
            {
            fprintf(_coverage_fout, "90\n");
            fflush(_coverage_fout);
            ___coverage_array[90] = 1;
            }
          }
          }
          if ((int const   )*(__s + __result) != (int const   )__reject3) {
            {
            if (___coverage_array[91] == 0) {
              {
              fprintf(_coverage_fout, "91\n");
              fflush(_coverage_fout);
              ___coverage_array[91] = 1;
              }
            }
            }

          } else {
            {
            if (___coverage_array[92] == 0) {
              {
              fprintf(_coverage_fout, "92\n");
              fflush(_coverage_fout);
              ___coverage_array[92] = 1;
              }
            }
            }
            break;
          }
        } else {
          {
          if (___coverage_array[93] == 0) {
            {
            fprintf(_coverage_fout, "93\n");
            fflush(_coverage_fout);
            ___coverage_array[93] = 1;
            }
          }
          }
          break;
        }
      } else {
        {
        if (___coverage_array[94] == 0) {
          {
          fprintf(_coverage_fout, "94\n");
          fflush(_coverage_fout);
          ___coverage_array[94] = 1;
          }
        }
        }
        break;
      }
    } else {
      {
      if (___coverage_array[95] == 0) {
        {
        fprintf(_coverage_fout, "95\n");
        fflush(_coverage_fout);
        ___coverage_array[95] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[96] == 0) {
      {
      fprintf(_coverage_fout, "96\n");
      fflush(_coverage_fout);
      ___coverage_array[96] = 1;
      }
    }
    }
    __result ++;
  }
  {
  if (___coverage_array[97] == 0) {
    {
    fprintf(_coverage_fout, "97\n");
    fflush(_coverage_fout);
    ___coverage_array[97] = 1;
    }
  }
  }
  return (__result);
}
}
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) ;
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) 
{ 
  register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[98] == 0) {
    {
    fprintf(_coverage_fout, "98\n");
    fflush(_coverage_fout);
    ___coverage_array[98] = 1;
    }
  }
  }
  __result = (size_t )0;
  {
  if (___coverage_array[99] == 0) {
    {
    fprintf(_coverage_fout, "99\n");
    fflush(_coverage_fout);
    ___coverage_array[99] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[100] == 0) {
      {
      fprintf(_coverage_fout, "100\n");
      fflush(_coverage_fout);
      ___coverage_array[100] = 1;
      }
    }
    }
    if ((int const   )*(__s + __result) == (int const   )__accept) {
      {
      if (___coverage_array[101] == 0) {
        {
        fprintf(_coverage_fout, "101\n");
        fflush(_coverage_fout);
        ___coverage_array[101] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[102] == 0) {
        {
        fprintf(_coverage_fout, "102\n");
        fflush(_coverage_fout);
        ___coverage_array[102] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[103] == 0) {
      {
      fprintf(_coverage_fout, "103\n");
      fflush(_coverage_fout);
      ___coverage_array[103] = 1;
      }
    }
    }
    __result ++;
  }
  {
  if (___coverage_array[104] == 0) {
    {
    fprintf(_coverage_fout, "104\n");
    fflush(_coverage_fout);
    ___coverage_array[104] = 1;
    }
  }
  }
  return (__result);
}
}
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ 
  register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[105] == 0) {
    {
    fprintf(_coverage_fout, "105\n");
    fflush(_coverage_fout);
    ___coverage_array[105] = 1;
    }
  }
  }
  __result = (size_t )0;
  {
  if (___coverage_array[106] == 0) {
    {
    fprintf(_coverage_fout, "106\n");
    fflush(_coverage_fout);
    ___coverage_array[106] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[107] == 0) {
      {
      fprintf(_coverage_fout, "107\n");
      fflush(_coverage_fout);
      ___coverage_array[107] = 1;
      }
    }
    }
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      {
      if (___coverage_array[108] == 0) {
        {
        fprintf(_coverage_fout, "108\n");
        fflush(_coverage_fout);
        ___coverage_array[108] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[109] == 0) {
        {
        fprintf(_coverage_fout, "109\n");
        fflush(_coverage_fout);
        ___coverage_array[109] = 1;
        }
      }
      }
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        {
        if (___coverage_array[110] == 0) {
          {
          fprintf(_coverage_fout, "110\n");
          fflush(_coverage_fout);
          ___coverage_array[110] = 1;
          }
        }
        }

      } else {
        {
        if (___coverage_array[111] == 0) {
          {
          fprintf(_coverage_fout, "111\n");
          fflush(_coverage_fout);
          ___coverage_array[111] = 1;
          }
        }
        }
        break;
      }
    }
    {
    if (___coverage_array[112] == 0) {
      {
      fprintf(_coverage_fout, "112\n");
      fflush(_coverage_fout);
      ___coverage_array[112] = 1;
      }
    }
    }
    __result ++;
  }
  {
  if (___coverage_array[113] == 0) {
    {
    fprintf(_coverage_fout, "113\n");
    fflush(_coverage_fout);
    ___coverage_array[113] = 1;
    }
  }
  }
  return (__result);
}
}
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ 
  register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[114] == 0) {
    {
    fprintf(_coverage_fout, "114\n");
    fflush(_coverage_fout);
    ___coverage_array[114] = 1;
    }
  }
  }
  __result = (size_t )0;
  {
  if (___coverage_array[115] == 0) {
    {
    fprintf(_coverage_fout, "115\n");
    fflush(_coverage_fout);
    ___coverage_array[115] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[116] == 0) {
      {
      fprintf(_coverage_fout, "116\n");
      fflush(_coverage_fout);
      ___coverage_array[116] = 1;
      }
    }
    }
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      {
      if (___coverage_array[117] == 0) {
        {
        fprintf(_coverage_fout, "117\n");
        fflush(_coverage_fout);
        ___coverage_array[117] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[118] == 0) {
        {
        fprintf(_coverage_fout, "118\n");
        fflush(_coverage_fout);
        ___coverage_array[118] = 1;
        }
      }
      }
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        {
        if (___coverage_array[119] == 0) {
          {
          fprintf(_coverage_fout, "119\n");
          fflush(_coverage_fout);
          ___coverage_array[119] = 1;
          }
        }
        }

      } else {
        {
        if (___coverage_array[120] == 0) {
          {
          fprintf(_coverage_fout, "120\n");
          fflush(_coverage_fout);
          ___coverage_array[120] = 1;
          }
        }
        }
        if ((int const   )*(__s + __result) == (int const   )__accept3) {
          {
          if (___coverage_array[121] == 0) {
            {
            fprintf(_coverage_fout, "121\n");
            fflush(_coverage_fout);
            ___coverage_array[121] = 1;
            }
          }
          }

        } else {
          {
          if (___coverage_array[122] == 0) {
            {
            fprintf(_coverage_fout, "122\n");
            fflush(_coverage_fout);
            ___coverage_array[122] = 1;
            }
          }
          }
          break;
        }
      }
    }
    {
    if (___coverage_array[123] == 0) {
      {
      fprintf(_coverage_fout, "123\n");
      fflush(_coverage_fout);
      ___coverage_array[123] = 1;
      }
    }
    }
    __result ++;
  }
  {
  if (___coverage_array[124] == 0) {
    {
    fprintf(_coverage_fout, "124\n");
    fflush(_coverage_fout);
    ___coverage_array[124] = 1;
    }
  }
  }
  return (__result);
}
}
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ 
  char *tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[125] == 0) {
    {
    fprintf(_coverage_fout, "125\n");
    fflush(_coverage_fout);
    ___coverage_array[125] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[126] == 0) {
      {
      fprintf(_coverage_fout, "126\n");
      fflush(_coverage_fout);
      ___coverage_array[126] = 1;
      }
    }
    }
    if ((int const   )*__s != 0) {
      {
      if (___coverage_array[127] == 0) {
        {
        fprintf(_coverage_fout, "127\n");
        fflush(_coverage_fout);
        ___coverage_array[127] = 1;
        }
      }
      }
      if ((int const   )*__s != (int const   )__accept1) {
        {
        if (___coverage_array[128] == 0) {
          {
          fprintf(_coverage_fout, "128\n");
          fflush(_coverage_fout);
          ___coverage_array[128] = 1;
          }
        }
        }
        if ((int const   )*__s != (int const   )__accept2) {
          {
          if (___coverage_array[129] == 0) {
            {
            fprintf(_coverage_fout, "129\n");
            fflush(_coverage_fout);
            ___coverage_array[129] = 1;
            }
          }
          }

        } else {
          {
          if (___coverage_array[130] == 0) {
            {
            fprintf(_coverage_fout, "130\n");
            fflush(_coverage_fout);
            ___coverage_array[130] = 1;
            }
          }
          }
          break;
        }
      } else {
        {
        if (___coverage_array[131] == 0) {
          {
          fprintf(_coverage_fout, "131\n");
          fflush(_coverage_fout);
          ___coverage_array[131] = 1;
          }
        }
        }
        break;
      }
    } else {
      {
      if (___coverage_array[132] == 0) {
        {
        fprintf(_coverage_fout, "132\n");
        fflush(_coverage_fout);
        ___coverage_array[132] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[133] == 0) {
      {
      fprintf(_coverage_fout, "133\n");
      fflush(_coverage_fout);
      ___coverage_array[133] = 1;
      }
    }
    }
    __s ++;
  }
  {
  if (___coverage_array[134] == 0) {
    {
    fprintf(_coverage_fout, "134\n");
    fflush(_coverage_fout);
    ___coverage_array[134] = 1;
    }
  }
  }
  if ((int const   )*__s == 0) {
    {
    if (___coverage_array[135] == 0) {
      {
      fprintf(_coverage_fout, "135\n");
      fflush(_coverage_fout);
      ___coverage_array[135] = 1;
      }
    }
    }
    tmp = (char *)((void *)0);
  } else {
    {
    if (___coverage_array[136] == 0) {
      {
      fprintf(_coverage_fout, "136\n");
      fflush(_coverage_fout);
      ___coverage_array[136] = 1;
      }
    }
    }
    tmp = (char *)((size_t )__s);
  }
  {
  if (___coverage_array[137] == 0) {
    {
    fprintf(_coverage_fout, "137\n");
    fflush(_coverage_fout);
    ___coverage_array[137] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ 
  char *tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[138] == 0) {
    {
    fprintf(_coverage_fout, "138\n");
    fflush(_coverage_fout);
    ___coverage_array[138] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[139] == 0) {
      {
      fprintf(_coverage_fout, "139\n");
      fflush(_coverage_fout);
      ___coverage_array[139] = 1;
      }
    }
    }
    if ((int const   )*__s != 0) {
      {
      if (___coverage_array[140] == 0) {
        {
        fprintf(_coverage_fout, "140\n");
        fflush(_coverage_fout);
        ___coverage_array[140] = 1;
        }
      }
      }
      if ((int const   )*__s != (int const   )__accept1) {
        {
        if (___coverage_array[141] == 0) {
          {
          fprintf(_coverage_fout, "141\n");
          fflush(_coverage_fout);
          ___coverage_array[141] = 1;
          }
        }
        }
        if ((int const   )*__s != (int const   )__accept2) {
          {
          if (___coverage_array[142] == 0) {
            {
            fprintf(_coverage_fout, "142\n");
            fflush(_coverage_fout);
            ___coverage_array[142] = 1;
            }
          }
          }
          if ((int const   )*__s != (int const   )__accept3) {
            {
            if (___coverage_array[143] == 0) {
              {
              fprintf(_coverage_fout, "143\n");
              fflush(_coverage_fout);
              ___coverage_array[143] = 1;
              }
            }
            }

          } else {
            {
            if (___coverage_array[144] == 0) {
              {
              fprintf(_coverage_fout, "144\n");
              fflush(_coverage_fout);
              ___coverage_array[144] = 1;
              }
            }
            }
            break;
          }
        } else {
          {
          if (___coverage_array[145] == 0) {
            {
            fprintf(_coverage_fout, "145\n");
            fflush(_coverage_fout);
            ___coverage_array[145] = 1;
            }
          }
          }
          break;
        }
      } else {
        {
        if (___coverage_array[146] == 0) {
          {
          fprintf(_coverage_fout, "146\n");
          fflush(_coverage_fout);
          ___coverage_array[146] = 1;
          }
        }
        }
        break;
      }
    } else {
      {
      if (___coverage_array[147] == 0) {
        {
        fprintf(_coverage_fout, "147\n");
        fflush(_coverage_fout);
        ___coverage_array[147] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[148] == 0) {
      {
      fprintf(_coverage_fout, "148\n");
      fflush(_coverage_fout);
      ___coverage_array[148] = 1;
      }
    }
    }
    __s ++;
  }
  {
  if (___coverage_array[149] == 0) {
    {
    fprintf(_coverage_fout, "149\n");
    fflush(_coverage_fout);
    ___coverage_array[149] = 1;
    }
  }
  }
  if ((int const   )*__s == 0) {
    {
    if (___coverage_array[150] == 0) {
      {
      fprintf(_coverage_fout, "150\n");
      fflush(_coverage_fout);
      ___coverage_array[150] = 1;
      }
    }
    }
    tmp = (char *)((void *)0);
  } else {
    {
    if (___coverage_array[151] == 0) {
      {
      fprintf(_coverage_fout, "151\n");
      fflush(_coverage_fout);
      ___coverage_array[151] = 1;
      }
    }
    }
    tmp = (char *)((size_t )__s);
  }
  {
  if (___coverage_array[152] == 0) {
    {
    fprintf(_coverage_fout, "152\n");
    fflush(_coverage_fout);
    ___coverage_array[152] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) ;
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) 
{ 
  char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[153] == 0) {
    {
    fprintf(_coverage_fout, "153\n");
    fflush(_coverage_fout);
    ___coverage_array[153] = 1;
    }
  }
  }
  if ((unsigned long )__s == (unsigned long )((void *)0)) {
    {
    if (___coverage_array[154] == 0) {
      {
      fprintf(_coverage_fout, "154\n");
      fflush(_coverage_fout);
      ___coverage_array[154] = 1;
      }
    }
    }
    __s = *__nextp;
  } else {
    {
    if (___coverage_array[155] == 0) {
      {
      fprintf(_coverage_fout, "155\n");
      fflush(_coverage_fout);
      ___coverage_array[155] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[156] == 0) {
    {
    fprintf(_coverage_fout, "156\n");
    fflush(_coverage_fout);
    ___coverage_array[156] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[157] == 0) {
      {
      fprintf(_coverage_fout, "157\n");
      fflush(_coverage_fout);
      ___coverage_array[157] = 1;
      }
    }
    }
    if ((int )*__s == (int )__sep) {
      {
      if (___coverage_array[158] == 0) {
        {
        fprintf(_coverage_fout, "158\n");
        fflush(_coverage_fout);
        ___coverage_array[158] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[159] == 0) {
        {
        fprintf(_coverage_fout, "159\n");
        fflush(_coverage_fout);
        ___coverage_array[159] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[160] == 0) {
      {
      fprintf(_coverage_fout, "160\n");
      fflush(_coverage_fout);
      ___coverage_array[160] = 1;
      }
    }
    }
    __s ++;
  }
  {
  if (___coverage_array[161] == 0) {
    {
    fprintf(_coverage_fout, "161\n");
    fflush(_coverage_fout);
    ___coverage_array[161] = 1;
    }
  }
  }
  __result = (char *)((void *)0);
  {
  if (___coverage_array[162] == 0) {
    {
    fprintf(_coverage_fout, "162\n");
    fflush(_coverage_fout);
    ___coverage_array[162] = 1;
    }
  }
  }
  if ((int )*__s != 0) {
    {
    if (___coverage_array[163] == 0) {
      {
      fprintf(_coverage_fout, "163\n");
      fflush(_coverage_fout);
      ___coverage_array[163] = 1;
      }
    }
    }
    tmp = __s;
    {
    if (___coverage_array[164] == 0) {
      {
      fprintf(_coverage_fout, "164\n");
      fflush(_coverage_fout);
      ___coverage_array[164] = 1;
      }
    }
    }
    __s ++;
    {
    if (___coverage_array[165] == 0) {
      {
      fprintf(_coverage_fout, "165\n");
      fflush(_coverage_fout);
      ___coverage_array[165] = 1;
      }
    }
    }
    __result = tmp;
    {
    if (___coverage_array[166] == 0) {
      {
      fprintf(_coverage_fout, "166\n");
      fflush(_coverage_fout);
      ___coverage_array[166] = 1;
      }
    }
    }
    while (1) {
      {
      if (___coverage_array[167] == 0) {
        {
        fprintf(_coverage_fout, "167\n");
        fflush(_coverage_fout);
        ___coverage_array[167] = 1;
        }
      }
      }
      if ((int )*__s != 0) {
        {
        if (___coverage_array[168] == 0) {
          {
          fprintf(_coverage_fout, "168\n");
          fflush(_coverage_fout);
          ___coverage_array[168] = 1;
          }
        }
        }

      } else {
        {
        if (___coverage_array[169] == 0) {
          {
          fprintf(_coverage_fout, "169\n");
          fflush(_coverage_fout);
          ___coverage_array[169] = 1;
          }
        }
        }
        break;
      }
      {
      if (___coverage_array[170] == 0) {
        {
        fprintf(_coverage_fout, "170\n");
        fflush(_coverage_fout);
        ___coverage_array[170] = 1;
        }
      }
      }
      tmp___0 = __s;
      {
      if (___coverage_array[171] == 0) {
        {
        fprintf(_coverage_fout, "171\n");
        fflush(_coverage_fout);
        ___coverage_array[171] = 1;
        }
      }
      }
      __s ++;
      {
      if (___coverage_array[172] == 0) {
        {
        fprintf(_coverage_fout, "172\n");
        fflush(_coverage_fout);
        ___coverage_array[172] = 1;
        }
      }
      }
      if ((int )*tmp___0 == (int )__sep) {
        {
        if (___coverage_array[173] == 0) {
          {
          fprintf(_coverage_fout, "173\n");
          fflush(_coverage_fout);
          ___coverage_array[173] = 1;
          }
        }
        }
        *(__s + -1) = (char )'\000';
        {
        if (___coverage_array[174] == 0) {
          {
          fprintf(_coverage_fout, "174\n");
          fflush(_coverage_fout);
          ___coverage_array[174] = 1;
          }
        }
        }
        break;
      } else {
        {
        if (___coverage_array[175] == 0) {
          {
          fprintf(_coverage_fout, "175\n");
          fflush(_coverage_fout);
          ___coverage_array[175] = 1;
          }
        }
        }

      }
    }
  } else {
    {
    if (___coverage_array[176] == 0) {
      {
      fprintf(_coverage_fout, "176\n");
      fflush(_coverage_fout);
      ___coverage_array[176] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[177] == 0) {
    {
    fprintf(_coverage_fout, "177\n");
    fflush(_coverage_fout);
    ___coverage_array[177] = 1;
    }
  }
  }
  *__nextp = __s;
  {
  if (___coverage_array[178] == 0) {
    {
    fprintf(_coverage_fout, "178\n");
    fflush(_coverage_fout);
    ___coverage_array[178] = 1;
    }
  }
  }
  return (__result);
}
}
extern char *__strsep_g(char **__stringp , char const   *__delim ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) 
{ 
  register char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  void *tmp___1 ;
  char *tmp___2 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[179] == 0) {
    {
    fprintf(_coverage_fout, "179\n");
    fflush(_coverage_fout);
    ___coverage_array[179] = 1;
    }
  }
  }
  __retval = *__s;
  {
  if (___coverage_array[180] == 0) {
    {
    fprintf(_coverage_fout, "180\n");
    fflush(_coverage_fout);
    ___coverage_array[180] = 1;
    }
  }
  }
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    {
    if (___coverage_array[181] == 0) {
      {
      fprintf(_coverage_fout, "181\n");
      fflush(_coverage_fout);
      ___coverage_array[181] = 1;
      }
    }
    }
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    {
    if (___coverage_array[182] == 0) {
      {
      fprintf(_coverage_fout, "182\n");
      fflush(_coverage_fout);
      ___coverage_array[182] = 1;
      }
    }
    }
    tmp___0 = tmp___2;
    {
    if (___coverage_array[183] == 0) {
      {
      fprintf(_coverage_fout, "183\n");
      fflush(_coverage_fout);
      ___coverage_array[183] = 1;
      }
    }
    }
    *__s = tmp___0;
    {
    if (___coverage_array[184] == 0) {
      {
      fprintf(_coverage_fout, "184\n");
      fflush(_coverage_fout);
      ___coverage_array[184] = 1;
      }
    }
    }
    if ((unsigned long )tmp___0 != (unsigned long )((void *)0)) {
      {
      if (___coverage_array[185] == 0) {
        {
        fprintf(_coverage_fout, "185\n");
        fflush(_coverage_fout);
        ___coverage_array[185] = 1;
        }
      }
      }
      tmp = *__s;
      {
      if (___coverage_array[186] == 0) {
        {
        fprintf(_coverage_fout, "186\n");
        fflush(_coverage_fout);
        ___coverage_array[186] = 1;
        }
      }
      }
      (*__s) ++;
      {
      if (___coverage_array[187] == 0) {
        {
        fprintf(_coverage_fout, "187\n");
        fflush(_coverage_fout);
        ___coverage_array[187] = 1;
        }
      }
      }
      *tmp = (char )'\000';
    } else {
      {
      if (___coverage_array[188] == 0) {
        {
        fprintf(_coverage_fout, "188\n");
        fflush(_coverage_fout);
        ___coverage_array[188] = 1;
        }
      }
      }

    }
  } else {
    {
    if (___coverage_array[189] == 0) {
      {
      fprintf(_coverage_fout, "189\n");
      fflush(_coverage_fout);
      ___coverage_array[189] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[190] == 0) {
    {
    fprintf(_coverage_fout, "190\n");
    fflush(_coverage_fout);
    ___coverage_array[190] = 1;
    }
  }
  }
  return (__retval);
}
}
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) ;
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) 
{ 
  register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[191] == 0) {
    {
    fprintf(_coverage_fout, "191\n");
    fflush(_coverage_fout);
    ___coverage_array[191] = 1;
    }
  }
  }
  __retval = *__s;
  {
  if (___coverage_array[192] == 0) {
    {
    fprintf(_coverage_fout, "192\n");
    fflush(_coverage_fout);
    ___coverage_array[192] = 1;
    }
  }
  }
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    {
    if (___coverage_array[193] == 0) {
      {
      fprintf(_coverage_fout, "193\n");
      fflush(_coverage_fout);
      ___coverage_array[193] = 1;
      }
    }
    }
    __cp = __retval;
    {
    if (___coverage_array[194] == 0) {
      {
      fprintf(_coverage_fout, "194\n");
      fflush(_coverage_fout);
      ___coverage_array[194] = 1;
      }
    }
    }
    while (1) {
      {
      if (___coverage_array[195] == 0) {
        {
        fprintf(_coverage_fout, "195\n");
        fflush(_coverage_fout);
        ___coverage_array[195] = 1;
        }
      }
      }
      if ((int )*__cp == 0) {
        {
        if (___coverage_array[196] == 0) {
          {
          fprintf(_coverage_fout, "196\n");
          fflush(_coverage_fout);
          ___coverage_array[196] = 1;
          }
        }
        }
        __cp = (char *)((void *)0);
        {
        if (___coverage_array[197] == 0) {
          {
          fprintf(_coverage_fout, "197\n");
          fflush(_coverage_fout);
          ___coverage_array[197] = 1;
          }
        }
        }
        break;
      } else {
        {
        if (___coverage_array[198] == 0) {
          {
          fprintf(_coverage_fout, "198\n");
          fflush(_coverage_fout);
          ___coverage_array[198] = 1;
          }
        }
        }

      }
      {
      if (___coverage_array[199] == 0) {
        {
        fprintf(_coverage_fout, "199\n");
        fflush(_coverage_fout);
        ___coverage_array[199] = 1;
        }
      }
      }
      if ((int )*__cp == (int )__reject1) {
        {
        if (___coverage_array[200] == 0) {
          {
          fprintf(_coverage_fout, "200\n");
          fflush(_coverage_fout);
          ___coverage_array[200] = 1;
          }
        }
        }
        tmp = __cp;
        {
        if (___coverage_array[201] == 0) {
          {
          fprintf(_coverage_fout, "201\n");
          fflush(_coverage_fout);
          ___coverage_array[201] = 1;
          }
        }
        }
        __cp ++;
        {
        if (___coverage_array[202] == 0) {
          {
          fprintf(_coverage_fout, "202\n");
          fflush(_coverage_fout);
          ___coverage_array[202] = 1;
          }
        }
        }
        *tmp = (char )'\000';
        {
        if (___coverage_array[203] == 0) {
          {
          fprintf(_coverage_fout, "203\n");
          fflush(_coverage_fout);
          ___coverage_array[203] = 1;
          }
        }
        }
        break;
      } else {
        {
        if (___coverage_array[204] == 0) {
          {
          fprintf(_coverage_fout, "204\n");
          fflush(_coverage_fout);
          ___coverage_array[204] = 1;
          }
        }
        }
        if ((int )*__cp == (int )__reject2) {
          {
          if (___coverage_array[205] == 0) {
            {
            fprintf(_coverage_fout, "205\n");
            fflush(_coverage_fout);
            ___coverage_array[205] = 1;
            }
          }
          }
          tmp = __cp;
          {
          if (___coverage_array[206] == 0) {
            {
            fprintf(_coverage_fout, "206\n");
            fflush(_coverage_fout);
            ___coverage_array[206] = 1;
            }
          }
          }
          __cp ++;
          {
          if (___coverage_array[207] == 0) {
            {
            fprintf(_coverage_fout, "207\n");
            fflush(_coverage_fout);
            ___coverage_array[207] = 1;
            }
          }
          }
          *tmp = (char )'\000';
          {
          if (___coverage_array[208] == 0) {
            {
            fprintf(_coverage_fout, "208\n");
            fflush(_coverage_fout);
            ___coverage_array[208] = 1;
            }
          }
          }
          break;
        } else {
          {
          if (___coverage_array[209] == 0) {
            {
            fprintf(_coverage_fout, "209\n");
            fflush(_coverage_fout);
            ___coverage_array[209] = 1;
            }
          }
          }

        }
      }
      {
      if (___coverage_array[210] == 0) {
        {
        fprintf(_coverage_fout, "210\n");
        fflush(_coverage_fout);
        ___coverage_array[210] = 1;
        }
      }
      }
      __cp ++;
    }
    {
    if (___coverage_array[211] == 0) {
      {
      fprintf(_coverage_fout, "211\n");
      fflush(_coverage_fout);
      ___coverage_array[211] = 1;
      }
    }
    }
    *__s = __cp;
  } else {
    {
    if (___coverage_array[212] == 0) {
      {
      fprintf(_coverage_fout, "212\n");
      fflush(_coverage_fout);
      ___coverage_array[212] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[213] == 0) {
    {
    fprintf(_coverage_fout, "213\n");
    fflush(_coverage_fout);
    ___coverage_array[213] = 1;
    }
  }
  }
  return (__retval);
}
}
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) ;
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) 
{ 
  register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[214] == 0) {
    {
    fprintf(_coverage_fout, "214\n");
    fflush(_coverage_fout);
    ___coverage_array[214] = 1;
    }
  }
  }
  __retval = *__s;
  {
  if (___coverage_array[215] == 0) {
    {
    fprintf(_coverage_fout, "215\n");
    fflush(_coverage_fout);
    ___coverage_array[215] = 1;
    }
  }
  }
  if ((unsigned long )__retval != (unsigned long )((void *)0)) {
    {
    if (___coverage_array[216] == 0) {
      {
      fprintf(_coverage_fout, "216\n");
      fflush(_coverage_fout);
      ___coverage_array[216] = 1;
      }
    }
    }
    __cp = __retval;
    {
    if (___coverage_array[217] == 0) {
      {
      fprintf(_coverage_fout, "217\n");
      fflush(_coverage_fout);
      ___coverage_array[217] = 1;
      }
    }
    }
    while (1) {
      {
      if (___coverage_array[218] == 0) {
        {
        fprintf(_coverage_fout, "218\n");
        fflush(_coverage_fout);
        ___coverage_array[218] = 1;
        }
      }
      }
      if ((int )*__cp == 0) {
        {
        if (___coverage_array[219] == 0) {
          {
          fprintf(_coverage_fout, "219\n");
          fflush(_coverage_fout);
          ___coverage_array[219] = 1;
          }
        }
        }
        __cp = (char *)((void *)0);
        {
        if (___coverage_array[220] == 0) {
          {
          fprintf(_coverage_fout, "220\n");
          fflush(_coverage_fout);
          ___coverage_array[220] = 1;
          }
        }
        }
        break;
      } else {
        {
        if (___coverage_array[221] == 0) {
          {
          fprintf(_coverage_fout, "221\n");
          fflush(_coverage_fout);
          ___coverage_array[221] = 1;
          }
        }
        }

      }
      {
      if (___coverage_array[222] == 0) {
        {
        fprintf(_coverage_fout, "222\n");
        fflush(_coverage_fout);
        ___coverage_array[222] = 1;
        }
      }
      }
      if ((int )*__cp == (int )__reject1) {
        {
        if (___coverage_array[223] == 0) {
          {
          fprintf(_coverage_fout, "223\n");
          fflush(_coverage_fout);
          ___coverage_array[223] = 1;
          }
        }
        }
        tmp = __cp;
        {
        if (___coverage_array[224] == 0) {
          {
          fprintf(_coverage_fout, "224\n");
          fflush(_coverage_fout);
          ___coverage_array[224] = 1;
          }
        }
        }
        __cp ++;
        {
        if (___coverage_array[225] == 0) {
          {
          fprintf(_coverage_fout, "225\n");
          fflush(_coverage_fout);
          ___coverage_array[225] = 1;
          }
        }
        }
        *tmp = (char )'\000';
        {
        if (___coverage_array[226] == 0) {
          {
          fprintf(_coverage_fout, "226\n");
          fflush(_coverage_fout);
          ___coverage_array[226] = 1;
          }
        }
        }
        break;
      } else {
        {
        if (___coverage_array[227] == 0) {
          {
          fprintf(_coverage_fout, "227\n");
          fflush(_coverage_fout);
          ___coverage_array[227] = 1;
          }
        }
        }
        if ((int )*__cp == (int )__reject2) {
          {
          if (___coverage_array[228] == 0) {
            {
            fprintf(_coverage_fout, "228\n");
            fflush(_coverage_fout);
            ___coverage_array[228] = 1;
            }
          }
          }
          tmp = __cp;
          {
          if (___coverage_array[229] == 0) {
            {
            fprintf(_coverage_fout, "229\n");
            fflush(_coverage_fout);
            ___coverage_array[229] = 1;
            }
          }
          }
          __cp ++;
          {
          if (___coverage_array[230] == 0) {
            {
            fprintf(_coverage_fout, "230\n");
            fflush(_coverage_fout);
            ___coverage_array[230] = 1;
            }
          }
          }
          *tmp = (char )'\000';
          {
          if (___coverage_array[231] == 0) {
            {
            fprintf(_coverage_fout, "231\n");
            fflush(_coverage_fout);
            ___coverage_array[231] = 1;
            }
          }
          }
          break;
        } else {
          {
          if (___coverage_array[232] == 0) {
            {
            fprintf(_coverage_fout, "232\n");
            fflush(_coverage_fout);
            ___coverage_array[232] = 1;
            }
          }
          }
          if ((int )*__cp == (int )__reject3) {
            {
            if (___coverage_array[233] == 0) {
              {
              fprintf(_coverage_fout, "233\n");
              fflush(_coverage_fout);
              ___coverage_array[233] = 1;
              }
            }
            }
            tmp = __cp;
            {
            if (___coverage_array[234] == 0) {
              {
              fprintf(_coverage_fout, "234\n");
              fflush(_coverage_fout);
              ___coverage_array[234] = 1;
              }
            }
            }
            __cp ++;
            {
            if (___coverage_array[235] == 0) {
              {
              fprintf(_coverage_fout, "235\n");
              fflush(_coverage_fout);
              ___coverage_array[235] = 1;
              }
            }
            }
            *tmp = (char )'\000';
            {
            if (___coverage_array[236] == 0) {
              {
              fprintf(_coverage_fout, "236\n");
              fflush(_coverage_fout);
              ___coverage_array[236] = 1;
              }
            }
            }
            break;
          } else {
            {
            if (___coverage_array[237] == 0) {
              {
              fprintf(_coverage_fout, "237\n");
              fflush(_coverage_fout);
              ___coverage_array[237] = 1;
              }
            }
            }

          }
        }
      }
      {
      if (___coverage_array[238] == 0) {
        {
        fprintf(_coverage_fout, "238\n");
        fflush(_coverage_fout);
        ___coverage_array[238] = 1;
        }
      }
      }
      __cp ++;
    }
    {
    if (___coverage_array[239] == 0) {
      {
      fprintf(_coverage_fout, "239\n");
      fflush(_coverage_fout);
      ___coverage_array[239] = 1;
      }
    }
    }
    *__s = __cp;
  } else {
    {
    if (___coverage_array[240] == 0) {
      {
      fprintf(_coverage_fout, "240\n");
      fflush(_coverage_fout);
      ___coverage_array[240] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[241] == 0) {
    {
    fprintf(_coverage_fout, "241\n");
    fflush(_coverage_fout);
    ___coverage_array[241] = 1;
    }
  }
  }
  return (__retval);
}
}
extern  __attribute__((__nothrow__)) void *malloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *calloc(size_t __nmemb ,
                                                  size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strdup(char const   *__string )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strndup(char const   *__string ,
                                                     size_t __n )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) int *__errno_location(void)  __attribute__((__const__)) ;
extern char *program_invocation_name ;
extern char *program_invocation_short_name ;
extern  __attribute__((__nothrow__)) size_t __ctype_get_mb_cur_max(void) ;
__inline extern  __attribute__((__nothrow__)) double ( __attribute__((__nonnull__(1))) atof)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) atoi)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) long ( __attribute__((__nonnull__(1))) atol)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern  __attribute__((__nothrow__)) long long ( __attribute__((__nonnull__(1))) atoll)(char const   *__nptr )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) double ( __attribute__((__nonnull__(1))) strtod)(char const   * __restrict  __nptr ,
                                                                                      char ** __restrict  __endptr ) ;
extern  __attribute__((__nothrow__)) float ( __attribute__((__nonnull__(1))) strtof)(char const   * __restrict  __nptr ,
                                                                                     char ** __restrict  __endptr ) ;
extern  __attribute__((__nothrow__)) long double ( __attribute__((__nonnull__(1))) strtold)(char const   * __restrict  __nptr ,
                                                                                            char ** __restrict  __endptr ) ;
extern  __attribute__((__nothrow__)) long ( __attribute__((__nonnull__(1))) strtol)(char const   * __restrict  __nptr ,
                                                                                    char ** __restrict  __endptr ,
                                                                                    int __base ) ;
extern  __attribute__((__nothrow__)) unsigned long ( __attribute__((__nonnull__(1))) strtoul)(char const   * __restrict  __nptr ,
                                                                                              char ** __restrict  __endptr ,
                                                                                              int __base ) ;
extern  __attribute__((__nothrow__)) long long ( __attribute__((__nonnull__(1))) strtoq)(char const   * __restrict  __nptr ,
                                                                                         char ** __restrict  __endptr ,
                                                                                         int __base ) ;
extern  __attribute__((__nothrow__)) unsigned long long ( __attribute__((__nonnull__(1))) strtouq)(char const   * __restrict  __nptr ,
                                                                                                   char ** __restrict  __endptr ,
                                                                                                   int __base ) ;
extern  __attribute__((__nothrow__)) long long ( __attribute__((__nonnull__(1))) strtoll)(char const   * __restrict  __nptr ,
                                                                                          char ** __restrict  __endptr ,
                                                                                          int __base ) ;
extern  __attribute__((__nothrow__)) unsigned long long ( __attribute__((__nonnull__(1))) strtoull)(char const   * __restrict  __nptr ,
                                                                                                    char ** __restrict  __endptr ,
                                                                                                    int __base ) ;
extern  __attribute__((__nothrow__)) long ( __attribute__((__nonnull__(1,4))) strtol_l)(char const   * __restrict  __nptr ,
                                                                                        char ** __restrict  __endptr ,
                                                                                        int __base ,
                                                                                        __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) unsigned long ( __attribute__((__nonnull__(1,4))) strtoul_l)(char const   * __restrict  __nptr ,
                                                                                                  char ** __restrict  __endptr ,
                                                                                                  int __base ,
                                                                                                  __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) long long ( __attribute__((__nonnull__(1,4))) strtoll_l)(char const   * __restrict  __nptr ,
                                                                                              char ** __restrict  __endptr ,
                                                                                              int __base ,
                                                                                              __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) unsigned long long ( __attribute__((__nonnull__(1,4))) strtoull_l)(char const   * __restrict  __nptr ,
                                                                                                        char ** __restrict  __endptr ,
                                                                                                        int __base ,
                                                                                                        __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) double ( __attribute__((__nonnull__(1,3))) strtod_l)(char const   * __restrict  __nptr ,
                                                                                          char ** __restrict  __endptr ,
                                                                                          __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) float ( __attribute__((__nonnull__(1,3))) strtof_l)(char const   * __restrict  __nptr ,
                                                                                         char ** __restrict  __endptr ,
                                                                                         __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) long double ( __attribute__((__nonnull__(1,3))) strtold_l)(char const   * __restrict  __nptr ,
                                                                                                char ** __restrict  __endptr ,
                                                                                                __locale_t __loc ) ;
__inline extern  __attribute__((__nothrow__)) double ( __attribute__((__nonnull__(1))) atof)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern double ( __attribute__((__nonnull__(1))) atof)(char const   *__nptr ) 
{ 
  double tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[242] == 0) {
    {
    fprintf(_coverage_fout, "242\n");
    fflush(_coverage_fout);
    ___coverage_array[242] = 1;
    }
  }
  }
  tmp = strtod((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)));
  {
  if (___coverage_array[243] == 0) {
    {
    fprintf(_coverage_fout, "243\n");
    fflush(_coverage_fout);
    ___coverage_array[243] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) atoi)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern int ( __attribute__((__nonnull__(1))) atoi)(char const   *__nptr ) 
{ 
  long tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[244] == 0) {
    {
    fprintf(_coverage_fout, "244\n");
    fflush(_coverage_fout);
    ___coverage_array[244] = 1;
    }
  }
  }
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  {
  if (___coverage_array[245] == 0) {
    {
    fprintf(_coverage_fout, "245\n");
    fflush(_coverage_fout);
    ___coverage_array[245] = 1;
    }
  }
  }
  return ((int )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long ( __attribute__((__nonnull__(1))) atol)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern long ( __attribute__((__nonnull__(1))) atol)(char const   *__nptr ) 
{ 
  long tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[246] == 0) {
    {
    fprintf(_coverage_fout, "246\n");
    fflush(_coverage_fout);
    ___coverage_array[246] = 1;
    }
  }
  }
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  {
  if (___coverage_array[247] == 0) {
    {
    fprintf(_coverage_fout, "247\n");
    fflush(_coverage_fout);
    ___coverage_array[247] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long long ( __attribute__((__nonnull__(1))) atoll)(char const   *__nptr )  __attribute__((__pure__)) ;
__inline extern long long ( __attribute__((__nonnull__(1))) atoll)(char const   *__nptr ) 
{ 
  long long tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[248] == 0) {
    {
    fprintf(_coverage_fout, "248\n");
    fflush(_coverage_fout);
    ___coverage_array[248] = 1;
    }
  }
  }
  tmp = strtoll((char const   */* __restrict  */)__nptr,
                (char **/* __restrict  */)((char **)((void *)0)), 10);
  {
  if (___coverage_array[249] == 0) {
    {
    fprintf(_coverage_fout, "249\n");
    fflush(_coverage_fout);
    ___coverage_array[249] = 1;
    }
  }
  }
  return (tmp);
}
}
extern  __attribute__((__nothrow__)) char *l64a(long __n ) ;
extern  __attribute__((__nothrow__)) long ( __attribute__((__nonnull__(1))) a64l)(char const   *__s )  __attribute__((__pure__)) ;
extern int select(int __nfds , fd_set * __restrict  __readfds ,
                  fd_set * __restrict  __writefds ,
                  fd_set * __restrict  __exceptfds ,
                  struct timeval * __restrict  __timeout ) ;
extern int pselect(int __nfds , fd_set * __restrict  __readfds ,
                   fd_set * __restrict  __writefds ,
                   fd_set * __restrict  __exceptfds ,
                   struct timespec  const  * __restrict  __timeout ,
                   __sigset_t const   * __restrict  __sigmask ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_major(unsigned long long __dev ) 
{ 


  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[250] == 0) {
    {
    fprintf(_coverage_fout, "250\n");
    fflush(_coverage_fout);
    ___coverage_array[250] = 1;
    }
  }
  }
  return ((unsigned int )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_minor(unsigned long long __dev ) 
{ 


  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[251] == 0) {
    {
    fprintf(_coverage_fout, "251\n");
    fflush(_coverage_fout);
    ___coverage_array[251] = 1;
    }
  }
  }
  return ((unsigned int )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                   unsigned int __minor ) 
{ 


  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[252] == 0) {
    {
    fprintf(_coverage_fout, "252\n");
    fflush(_coverage_fout);
    ___coverage_array[252] = 1;
    }
  }
  }
  return (((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32));
}
}
extern  __attribute__((__nothrow__)) long random(void) ;
extern  __attribute__((__nothrow__)) void srandom(unsigned int __seed ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(2))) initstate)(unsigned int __seed ,
                                                                                        char *__statebuf ,
                                                                                        size_t __statelen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1))) setstate)(char *__statebuf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) random_r)(struct random_data * __restrict  __buf ,
                                                                                       int32_t * __restrict  __result ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) srandom_r)(unsigned int __seed ,
                                                                                      struct random_data *__buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,4))) initstate_r)(unsigned int __seed ,
                                                                                          char * __restrict  __statebuf ,
                                                                                          size_t __statelen ,
                                                                                          struct random_data * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) setstate_r)(char * __restrict  __statebuf ,
                                                                                         struct random_data * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) int rand(void) ;
extern  __attribute__((__nothrow__)) void srand(unsigned int __seed ) ;
extern  __attribute__((__nothrow__)) int rand_r(unsigned int *__seed ) ;
extern  __attribute__((__nothrow__)) double drand48(void) ;
extern  __attribute__((__nothrow__)) double ( __attribute__((__nonnull__(1))) erand48)(unsigned short *__xsubi ) ;
extern  __attribute__((__nothrow__)) long lrand48(void) ;
extern  __attribute__((__nothrow__)) long ( __attribute__((__nonnull__(1))) nrand48)(unsigned short *__xsubi ) ;
extern  __attribute__((__nothrow__)) long mrand48(void) ;
extern  __attribute__((__nothrow__)) long ( __attribute__((__nonnull__(1))) jrand48)(unsigned short *__xsubi ) ;
extern  __attribute__((__nothrow__)) void srand48(long __seedval ) ;
extern  __attribute__((__nothrow__)) unsigned short *( __attribute__((__nonnull__(1))) seed48)(unsigned short *__seed16v ) ;
extern  __attribute__((__nothrow__)) void ( __attribute__((__nonnull__(1))) lcong48)(unsigned short *__param ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) drand48_r)(struct drand48_data * __restrict  __buffer ,
                                                                                        double * __restrict  __result ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) erand48_r)(unsigned short *__xsubi ,
                                                                                        struct drand48_data * __restrict  __buffer ,
                                                                                        double * __restrict  __result ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) lrand48_r)(struct drand48_data * __restrict  __buffer ,
                                                                                        long * __restrict  __result ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) nrand48_r)(unsigned short *__xsubi ,
                                                                                        struct drand48_data * __restrict  __buffer ,
                                                                                        long * __restrict  __result ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) mrand48_r)(struct drand48_data * __restrict  __buffer ,
                                                                                        long * __restrict  __result ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) jrand48_r)(unsigned short *__xsubi ,
                                                                                        struct drand48_data * __restrict  __buffer ,
                                                                                        long * __restrict  __result ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) srand48_r)(long __seedval ,
                                                                                      struct drand48_data *__buffer ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) seed48_r)(unsigned short *__seed16v ,
                                                                                       struct drand48_data *__buffer ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) lcong48_r)(unsigned short *__param ,
                                                                                        struct drand48_data *__buffer ) ;
extern  __attribute__((__nothrow__)) void *( __attribute__((__warn_unused_result__)) realloc)(void *__ptr ,
                                                                                              size_t __size ) ;
extern  __attribute__((__nothrow__)) void free(void *__ptr ) ;
extern  __attribute__((__nothrow__)) void cfree(void *__ptr ) ;
extern  __attribute__((__nothrow__)) void *alloca(size_t __size ) ;
extern  __attribute__((__nothrow__)) void *valloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) posix_memalign)(void **__memptr ,
                                                                                           size_t __alignment ,
                                                                                           size_t __size ) ;
extern  __attribute__((__nothrow__, __noreturn__)) void abort(void) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) atexit)(void (*__func)(void) ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) at_quick_exit)(void (*__func)(void) ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) on_exit)(void (*__func)(int __status ,
                                                                                                   void *__arg ) ,
                                                                                    void *__arg ) ;
extern  __attribute__((__nothrow__, __noreturn__)) void exit(int __status ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void quick_exit(int __status ) ;
extern  __attribute__((__nothrow__, __noreturn__)) void _Exit(int __status ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1))) getenv)(char const   *__name ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1))) __secure_getenv)(char const   *__name ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) putenv)(char *__string ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) setenv)(char const   *__name ,
                                                                                   char const   *__value ,
                                                                                   int __replace ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) unsetenv)(char const   *__name ) ;
extern  __attribute__((__nothrow__)) int clearenv(void) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1))) mktemp)(char *__template ) ;
extern int ( __attribute__((__nonnull__(1))) mkstemp)(char *__template )  __asm__("mkstemp64")  ;
extern int ( __attribute__((__nonnull__(1))) mkstemp64)(char *__template ) ;
extern int ( __attribute__((__nonnull__(1))) mkstemps)(char *__template ,
                                                       int __suffixlen )  __asm__("mkstemps64")  ;
extern int ( __attribute__((__nonnull__(1))) mkstemps64)(char *__template ,
                                                         int __suffixlen ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1))) mkdtemp)(char *__template ) ;
extern int ( __attribute__((__nonnull__(1))) mkostemp)(char *__template ,
                                                       int __flags )  __asm__("mkostemp64")  ;
extern int ( __attribute__((__nonnull__(1))) mkostemp64)(char *__template ,
                                                         int __flags ) ;
extern int ( __attribute__((__nonnull__(1))) mkostemps)(char *__template ,
                                                        int __suffixlen ,
                                                        int __flags )  __asm__("mkostemps64")  ;
extern int ( __attribute__((__nonnull__(1))) mkostemps64)(char *__template ,
                                                          int __suffixlen ,
                                                          int __flags ) ;
extern int system(char const   *__command ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1))) canonicalize_file_name)(char const   *__name ) ;
extern  __attribute__((__nothrow__)) char *realpath(char const   * __restrict  __name ,
                                                    char * __restrict  __resolved ) ;
extern void *( __attribute__((__nonnull__(1,2,5))) bsearch)(void const   *__key ,
                                                            void const   *__base ,
                                                            size_t __nmemb ,
                                                            size_t __size ,
                                                            int (*__compar)(void const   * ,
                                                                            void const   * ) ) ;
extern void ( __attribute__((__nonnull__(1,4))) qsort)(void *__base ,
                                                       size_t __nmemb ,
                                                       size_t __size ,
                                                       int (*__compar)(void const   * ,
                                                                       void const   * ) ) ;
extern void ( __attribute__((__nonnull__(1,4))) qsort_r)(void *__base ,
                                                         size_t __nmemb ,
                                                         size_t __size ,
                                                         int (*__compar)(void const   * ,
                                                                         void const   * ,
                                                                         void * ) ,
                                                         void *__arg ) ;
extern  __attribute__((__nothrow__)) int abs(int __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long labs(long __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long long llabs(long long __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) div_t div(int __numer , int __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) ldiv_t ldiv(long __numer , long __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) lldiv_t lldiv(long long __numer ,
                                                   long long __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(3,4))) ecvt)(double __value ,
                                                                                     int __ndigit ,
                                                                                     int * __restrict  __decpt ,
                                                                                     int * __restrict  __sign ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(3,4))) fcvt)(double __value ,
                                                                                     int __ndigit ,
                                                                                     int * __restrict  __decpt ,
                                                                                     int * __restrict  __sign ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(3))) gcvt)(double __value ,
                                                                                   int __ndigit ,
                                                                                   char *__buf ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(3,4))) qecvt)(long double __value ,
                                                                                      int __ndigit ,
                                                                                      int * __restrict  __decpt ,
                                                                                      int * __restrict  __sign ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(3,4))) qfcvt)(long double __value ,
                                                                                      int __ndigit ,
                                                                                      int * __restrict  __decpt ,
                                                                                      int * __restrict  __sign ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(3))) qgcvt)(long double __value ,
                                                                                    int __ndigit ,
                                                                                    char *__buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,4,5))) ecvt_r)(double __value ,
                                                                                       int __ndigit ,
                                                                                       int * __restrict  __decpt ,
                                                                                       int * __restrict  __sign ,
                                                                                       char * __restrict  __buf ,
                                                                                       size_t __len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,4,5))) fcvt_r)(double __value ,
                                                                                       int __ndigit ,
                                                                                       int * __restrict  __decpt ,
                                                                                       int * __restrict  __sign ,
                                                                                       char * __restrict  __buf ,
                                                                                       size_t __len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,4,5))) qecvt_r)(long double __value ,
                                                                                        int __ndigit ,
                                                                                        int * __restrict  __decpt ,
                                                                                        int * __restrict  __sign ,
                                                                                        char * __restrict  __buf ,
                                                                                        size_t __len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,4,5))) qfcvt_r)(long double __value ,
                                                                                        int __ndigit ,
                                                                                        int * __restrict  __decpt ,
                                                                                        int * __restrict  __sign ,
                                                                                        char * __restrict  __buf ,
                                                                                        size_t __len ) ;
extern  __attribute__((__nothrow__)) int mblen(char const   *__s , size_t __n ) ;
extern  __attribute__((__nothrow__)) int mbtowc(wchar_t * __restrict  __pwc ,
                                                char const   * __restrict  __s ,
                                                size_t __n ) ;
extern  __attribute__((__nothrow__)) int wctomb(char *__s , wchar_t __wchar ) ;
extern  __attribute__((__nothrow__)) size_t mbstowcs(wchar_t * __restrict  __pwcs ,
                                                     char const   * __restrict  __s ,
                                                     size_t __n ) ;
extern  __attribute__((__nothrow__)) size_t wcstombs(char * __restrict  __s ,
                                                     wchar_t const   * __restrict  __pwcs ,
                                                     size_t __n ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) rpmatch)(char const   *__response ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2,3))) getsubopt)(char ** __restrict  __optionp ,
                                                                                          char * const  * __restrict  __tokens ,
                                                                                          char ** __restrict  __valuep ) ;
extern  __attribute__((__nothrow__)) void ( __attribute__((__nonnull__(1))) setkey)(char const   *__key ) ;
extern int posix_openpt(int __oflag ) ;
extern  __attribute__((__nothrow__)) int grantpt(int __fd ) ;
extern  __attribute__((__nothrow__)) int unlockpt(int __fd ) ;
extern  __attribute__((__nothrow__)) char *ptsname(int __fd ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) ptsname_r)(int __fd ,
                                                                                      char *__buf ,
                                                                                      size_t __buflen ) ;
extern int getpt(void) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) getloadavg)(double *__loadavg ,
                                                                                       int __nelem ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) access)(char const   *__name ,
                                                                                   int __type ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) euidaccess)(char const   *__name ,
                                                                                       int __type ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) eaccess)(char const   *__name ,
                                                                                    int __type ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) faccessat)(int __fd ,
                                                                                      char const   *__file ,
                                                                                      int __type ,
                                                                                      int __flag ) ;
extern  __attribute__((__nothrow__)) __off64_t lseek(int __fd ,
                                                     __off64_t __offset ,
                                                     int __whence )  __asm__("lseek64")  ;
extern  __attribute__((__nothrow__)) __off64_t lseek64(int __fd ,
                                                       __off64_t __offset ,
                                                       int __whence ) ;
extern int close(int __fd ) ;
extern ssize_t read(int __fd , void *__buf , size_t __nbytes ) ;
extern ssize_t write(int __fd , void const   *__buf , size_t __n ) ;
extern ssize_t pread(int __fd , void *__buf , size_t __nbytes ,
                     __off64_t __offset )  __asm__("pread64")  ;
extern ssize_t pwrite(int __fd , void const   *__buf , size_t __nbytes ,
                      __off64_t __offset )  __asm__("pwrite64")  ;
extern ssize_t pread64(int __fd , void *__buf , size_t __nbytes ,
                       __off64_t __offset ) ;
extern ssize_t pwrite64(int __fd , void const   *__buf , size_t __n ,
                        __off64_t __offset ) ;
extern  __attribute__((__nothrow__)) int pipe(int *__pipedes ) ;
extern  __attribute__((__nothrow__)) int pipe2(int *__pipedes , int __flags ) ;
extern  __attribute__((__nothrow__)) unsigned int alarm(unsigned int __seconds ) ;
extern unsigned int sleep(unsigned int __seconds ) ;
extern  __attribute__((__nothrow__)) __useconds_t ualarm(__useconds_t __value ,
                                                         __useconds_t __interval ) ;
extern int usleep(__useconds_t __useconds ) ;
extern int pause(void) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) chown)(char const   *__file ,
                                                                                  __uid_t __owner ,
                                                                                  __gid_t __group ) ;
extern  __attribute__((__nothrow__)) int fchown(int __fd , __uid_t __owner ,
                                                __gid_t __group ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) lchown)(char const   *__file ,
                                                                                   __uid_t __owner ,
                                                                                   __gid_t __group ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) fchownat)(int __fd ,
                                                                                     char const   *__file ,
                                                                                     __uid_t __owner ,
                                                                                     __gid_t __group ,
                                                                                     int __flag ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) chdir)(char const   *__path ) ;
extern  __attribute__((__nothrow__)) int fchdir(int __fd ) ;
extern  __attribute__((__nothrow__)) char *getcwd(char *__buf , size_t __size ) ;
extern  __attribute__((__nothrow__)) char *get_current_dir_name(void) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1))) getwd)(char *__buf )  __attribute__((__deprecated__)) ;
extern  __attribute__((__nothrow__)) int dup(int __fd ) ;
extern  __attribute__((__nothrow__)) int dup2(int __fd , int __fd2 ) ;
extern  __attribute__((__nothrow__)) int dup3(int __fd , int __fd2 ,
                                              int __flags ) ;
extern char **__environ ;
extern char **environ ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) execve)(char const   *__path ,
                                                                                     char * const  *__argv ,
                                                                                     char * const  *__envp ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) fexecve)(int __fd ,
                                                                                    char * const  *__argv ,
                                                                                    char * const  *__envp ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) execv)(char const   *__path ,
                                                                                    char * const  *__argv ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) execle)(char const   *__path ,
                                                                                     char const   *__arg 
                                                                                     , ...) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) execl)(char const   *__path ,
                                                                                    char const   *__arg 
                                                                                    , ...) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) execvp)(char const   *__file ,
                                                                                     char * const  *__argv ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) execlp)(char const   *__file ,
                                                                                     char const   *__arg 
                                                                                     , ...) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) execvpe)(char const   *__file ,
                                                                                      char * const  *__argv ,
                                                                                      char * const  *__envp ) ;
extern  __attribute__((__nothrow__)) int nice(int __inc ) ;
extern  __attribute__((__noreturn__)) void _exit(int __status ) ;
extern  __attribute__((__nothrow__)) long ( __attribute__((__nonnull__(1))) pathconf)(char const   *__path ,
                                                                                      int __name ) ;
extern  __attribute__((__nothrow__)) long fpathconf(int __fd , int __name ) ;
extern  __attribute__((__nothrow__)) long sysconf(int __name ) ;
extern  __attribute__((__nothrow__)) size_t confstr(int __name , char *__buf ,
                                                    size_t __len ) ;
extern  __attribute__((__nothrow__)) __pid_t getpid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getppid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getpgrp(void) ;
extern  __attribute__((__nothrow__)) __pid_t __getpgid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) __pid_t getpgid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) int setpgid(__pid_t __pid , __pid_t __pgid ) ;
extern  __attribute__((__nothrow__)) int setpgrp(void) ;
extern  __attribute__((__nothrow__)) __pid_t setsid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getsid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) __uid_t getuid(void) ;
extern  __attribute__((__nothrow__)) __uid_t geteuid(void) ;
extern  __attribute__((__nothrow__)) __gid_t getgid(void) ;
extern  __attribute__((__nothrow__)) __gid_t getegid(void) ;
extern  __attribute__((__nothrow__)) int getgroups(int __size , __gid_t *__list ) ;
extern  __attribute__((__nothrow__)) int group_member(__gid_t __gid ) ;
extern  __attribute__((__nothrow__)) int setuid(__uid_t __uid ) ;
extern  __attribute__((__nothrow__)) int setreuid(__uid_t __ruid ,
                                                  __uid_t __euid ) ;
extern  __attribute__((__nothrow__)) int seteuid(__uid_t __uid ) ;
extern  __attribute__((__nothrow__)) int setgid(__gid_t __gid ) ;
extern  __attribute__((__nothrow__)) int setregid(__gid_t __rgid ,
                                                  __gid_t __egid ) ;
extern  __attribute__((__nothrow__)) int setegid(__gid_t __gid ) ;
extern  __attribute__((__nothrow__)) int getresuid(__uid_t *__ruid ,
                                                   __uid_t *__euid ,
                                                   __uid_t *__suid ) ;
extern  __attribute__((__nothrow__)) int getresgid(__gid_t *__rgid ,
                                                   __gid_t *__egid ,
                                                   __gid_t *__sgid ) ;
extern  __attribute__((__nothrow__)) int setresuid(__uid_t __ruid ,
                                                   __uid_t __euid ,
                                                   __uid_t __suid ) ;
extern  __attribute__((__nothrow__)) int setresgid(__gid_t __rgid ,
                                                   __gid_t __egid ,
                                                   __gid_t __sgid ) ;
extern  __attribute__((__nothrow__)) __pid_t fork(void) ;
extern  __attribute__((__nothrow__)) __pid_t vfork(void) ;
extern  __attribute__((__nothrow__)) char *ttyname(int __fd ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) ttyname_r)(int __fd ,
                                                                                      char *__buf ,
                                                                                      size_t __buflen ) ;
extern  __attribute__((__nothrow__)) int isatty(int __fd ) ;
extern  __attribute__((__nothrow__)) int ttyslot(void) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) link)(char const   *__from ,
                                                                                   char const   *__to ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,4))) linkat)(int __fromfd ,
                                                                                     char const   *__from ,
                                                                                     int __tofd ,
                                                                                     char const   *__to ,
                                                                                     int __flags ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) symlink)(char const   *__from ,
                                                                                      char const   *__to ) ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__nonnull__(1,2))) readlink)(char const   * __restrict  __path ,
                                                                                           char * __restrict  __buf ,
                                                                                           size_t __len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,3))) symlinkat)(char const   *__from ,
                                                                                        int __tofd ,
                                                                                        char const   *__to ) ;
extern  __attribute__((__nothrow__)) ssize_t ( __attribute__((__nonnull__(2,3))) readlinkat)(int __fd ,
                                                                                             char const   * __restrict  __path ,
                                                                                             char * __restrict  __buf ,
                                                                                             size_t __len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) unlink)(char const   *__name ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) unlinkat)(int __fd ,
                                                                                     char const   *__name ,
                                                                                     int __flag ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) rmdir)(char const   *__path ) ;
extern  __attribute__((__nothrow__)) __pid_t tcgetpgrp(int __fd ) ;
extern  __attribute__((__nothrow__)) int tcsetpgrp(int __fd , __pid_t __pgrp_id ) ;
extern char *getlogin(void) ;
extern int ( __attribute__((__nonnull__(1))) getlogin_r)(char *__name ,
                                                         size_t __name_len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) setlogin)(char const   *__name ) ;
extern char *optarg ;
extern int optind ;
extern int opterr ;
extern int optopt ;
extern  __attribute__((__nothrow__)) int getopt(int ___argc ,
                                                char * const  *___argv ,
                                                char const   *__shortopts ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) gethostname)(char *__name ,
                                                                                        size_t __len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) sethostname)(char const   *__name ,
                                                                                        size_t __len ) ;
extern  __attribute__((__nothrow__)) int sethostid(long __id ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) getdomainname)(char *__name ,
                                                                                          size_t __len ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) setdomainname)(char const   *__name ,
                                                                                          size_t __len ) ;
extern  __attribute__((__nothrow__)) int vhangup(void) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) revoke)(char const   *__file ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) profil)(unsigned short *__sample_buffer ,
                                                                                   size_t __size ,
                                                                                   size_t __offset ,
                                                                                   unsigned int __scale ) ;
extern  __attribute__((__nothrow__)) int acct(char const   *__name ) ;
extern  __attribute__((__nothrow__)) char *getusershell(void) ;
extern  __attribute__((__nothrow__)) void endusershell(void) ;
extern  __attribute__((__nothrow__)) void setusershell(void) ;
extern  __attribute__((__nothrow__)) int daemon(int __nochdir , int __noclose ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) chroot)(char const   *__path ) ;
extern char *( __attribute__((__nonnull__(1))) getpass)(char const   *__prompt ) ;
extern int fsync(int __fd ) ;
extern long gethostid(void) ;
extern  __attribute__((__nothrow__)) void sync(void) ;
extern  __attribute__((__nothrow__)) int getpagesize(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int getdtablesize(void) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) truncate)(char const   *__file ,
                                                                                     __off64_t __length )  __asm__("truncate64")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) truncate64)(char const   *__file ,
                                                                                       __off64_t __length ) ;
extern  __attribute__((__nothrow__)) int ftruncate(int __fd ,
                                                   __off64_t __length )  __asm__("ftruncate64")  ;
extern  __attribute__((__nothrow__)) int ftruncate64(int __fd ,
                                                     __off64_t __length ) ;
extern  __attribute__((__nothrow__)) int brk(void *__addr ) ;
extern  __attribute__((__nothrow__)) void *sbrk(intptr_t __delta ) ;
extern  __attribute__((__nothrow__)) long syscall(long __sysno  , ...) ;
extern int lockf(int __fd , int __cmd , __off64_t __len )  __asm__("lockf64")  ;
extern int lockf64(int __fd , int __cmd , __off64_t __len ) ;
extern int fdatasync(int __fildes ) ;
extern  __attribute__((__nothrow__)) char *( __attribute__((__nonnull__(1,2))) crypt)(char const   *__key ,
                                                                                      char const   *__salt ) ;
extern  __attribute__((__nothrow__)) void ( __attribute__((__nonnull__(1))) encrypt)(char *__block ,
                                                                                     int __edflag ) ;
extern  __attribute__((__nothrow__)) void ( __attribute__((__nonnull__(1,2))) swab)(void const   * __restrict  __from ,
                                                                                    void * __restrict  __to ,
                                                                                    ssize_t __n ) ;
extern  __attribute__((__nothrow__)) intmax_t imaxabs(intmax_t __n )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) imaxdiv_t imaxdiv(intmax_t __numer ,
                                                       intmax_t __denom )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) intmax_t strtoimax(char const   * __restrict  nptr ,
                                                                 char ** __restrict  endptr ,
                                                                 int base ) ;
__inline extern  __attribute__((__nothrow__)) uintmax_t strtoumax(char const   * __restrict  nptr ,
                                                                  char ** __restrict  endptr ,
                                                                  int base ) ;
__inline extern  __attribute__((__nothrow__)) intmax_t wcstoimax(__gwchar_t const   * __restrict  nptr ,
                                                                 __gwchar_t ** __restrict  endptr ,
                                                                 int base ) ;
__inline extern  __attribute__((__nothrow__)) uintmax_t wcstoumax(__gwchar_t const   * __restrict  nptr ,
                                                                  __gwchar_t ** __restrict  endptr ,
                                                                  int base ) ;
extern  __attribute__((__nothrow__)) long long ( __attribute__((__nonnull__(1))) __strtoll_internal)(char const   * __restrict  __nptr ,
                                                                                                     char ** __restrict  __endptr ,
                                                                                                     int __base ,
                                                                                                     int __group ) ;
__inline extern  __attribute__((__nothrow__)) intmax_t strtoimax(char const   * __restrict  nptr ,
                                                                 char ** __restrict  endptr ,
                                                                 int base ) ;
__inline extern intmax_t strtoimax(char const   * __restrict  nptr ,
                                   char ** __restrict  endptr , int base ) 
{ 
  long long tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[253] == 0) {
    {
    fprintf(_coverage_fout, "253\n");
    fflush(_coverage_fout);
    ___coverage_array[253] = 1;
    }
  }
  }
  tmp = __strtoll_internal(nptr, endptr, base, 0);
  {
  if (___coverage_array[254] == 0) {
    {
    fprintf(_coverage_fout, "254\n");
    fflush(_coverage_fout);
    ___coverage_array[254] = 1;
    }
  }
  }
  return (tmp);
}
}
extern  __attribute__((__nothrow__)) unsigned long long ( __attribute__((__nonnull__(1))) __strtoull_internal)(char const   * __restrict  __nptr ,
                                                                                                               char ** __restrict  __endptr ,
                                                                                                               int __base ,
                                                                                                               int __group ) ;
__inline extern  __attribute__((__nothrow__)) uintmax_t strtoumax(char const   * __restrict  nptr ,
                                                                  char ** __restrict  endptr ,
                                                                  int base ) ;
__inline extern uintmax_t strtoumax(char const   * __restrict  nptr ,
                                    char ** __restrict  endptr , int base ) 
{ 
  unsigned long long tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[255] == 0) {
    {
    fprintf(_coverage_fout, "255\n");
    fflush(_coverage_fout);
    ___coverage_array[255] = 1;
    }
  }
  }
  tmp = __strtoull_internal(nptr, endptr, base, 0);
  {
  if (___coverage_array[256] == 0) {
    {
    fprintf(_coverage_fout, "256\n");
    fflush(_coverage_fout);
    ___coverage_array[256] = 1;
    }
  }
  }
  return (tmp);
}
}
extern  __attribute__((__nothrow__)) long long ( __attribute__((__nonnull__(1))) __wcstoll_internal)(__gwchar_t const   * __restrict  __nptr ,
                                                                                                     __gwchar_t ** __restrict  __endptr ,
                                                                                                     int __base ,
                                                                                                     int __group ) ;
__inline extern  __attribute__((__nothrow__)) intmax_t wcstoimax(__gwchar_t const   * __restrict  nptr ,
                                                                 __gwchar_t ** __restrict  endptr ,
                                                                 int base ) ;
__inline extern intmax_t wcstoimax(__gwchar_t const   * __restrict  nptr ,
                                   __gwchar_t ** __restrict  endptr , int base ) 
{ 
  long long tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[257] == 0) {
    {
    fprintf(_coverage_fout, "257\n");
    fflush(_coverage_fout);
    ___coverage_array[257] = 1;
    }
  }
  }
  tmp = __wcstoll_internal(nptr, endptr, base, 0);
  {
  if (___coverage_array[258] == 0) {
    {
    fprintf(_coverage_fout, "258\n");
    fflush(_coverage_fout);
    ___coverage_array[258] = 1;
    }
  }
  }
  return (tmp);
}
}
extern  __attribute__((__nothrow__)) unsigned long long ( __attribute__((__nonnull__(1))) __wcstoull_internal)(__gwchar_t const   * __restrict  __nptr ,
                                                                                                               __gwchar_t ** __restrict  __endptr ,
                                                                                                               int __base ,
                                                                                                               int __group ) ;
__inline extern  __attribute__((__nothrow__)) uintmax_t wcstoumax(__gwchar_t const   * __restrict  nptr ,
                                                                  __gwchar_t ** __restrict  endptr ,
                                                                  int base ) ;
__inline extern uintmax_t wcstoumax(__gwchar_t const   * __restrict  nptr ,
                                    __gwchar_t ** __restrict  endptr , int base ) 
{ 
  unsigned long long tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[259] == 0) {
    {
    fprintf(_coverage_fout, "259\n");
    fflush(_coverage_fout);
    ___coverage_array[259] = 1;
    }
  }
  }
  tmp = __wcstoull_internal(nptr, endptr, base, 0);
  {
  if (___coverage_array[260] == 0) {
    {
    fprintf(_coverage_fout, "260\n");
    fflush(_coverage_fout);
    ___coverage_array[260] = 1;
    }
  }
  }
  return (tmp);
}
}
extern  __attribute__((__nothrow__)) double acos(double __x ) ;
extern  __attribute__((__nothrow__)) double __acos(double __x ) ;
extern  __attribute__((__nothrow__)) double asin(double __x ) ;
extern  __attribute__((__nothrow__)) double __asin(double __x ) ;
extern  __attribute__((__nothrow__)) double atan(double __x ) ;
extern  __attribute__((__nothrow__)) double __atan(double __x ) ;
extern  __attribute__((__nothrow__)) double atan2(double __y , double __x ) ;
extern  __attribute__((__nothrow__)) double __atan2(double __y , double __x ) ;
extern  __attribute__((__nothrow__)) double cos(double __x ) ;
extern  __attribute__((__nothrow__)) double __cos(double __x ) ;
extern  __attribute__((__nothrow__)) double sin(double __x ) ;
extern  __attribute__((__nothrow__)) double __sin(double __x ) ;
extern  __attribute__((__nothrow__)) double tan(double __x ) ;
extern  __attribute__((__nothrow__)) double __tan(double __x ) ;
extern  __attribute__((__nothrow__)) double cosh(double __x ) ;
extern  __attribute__((__nothrow__)) double __cosh(double __x ) ;
extern  __attribute__((__nothrow__)) double sinh(double __x ) ;
extern  __attribute__((__nothrow__)) double __sinh(double __x ) ;
extern  __attribute__((__nothrow__)) double tanh(double __x ) ;
extern  __attribute__((__nothrow__)) double __tanh(double __x ) ;
extern  __attribute__((__nothrow__)) void sincos(double __x , double *__sinx ,
                                                 double *__cosx ) ;
extern  __attribute__((__nothrow__)) void __sincos(double __x , double *__sinx ,
                                                   double *__cosx ) ;
extern  __attribute__((__nothrow__)) double acosh(double __x ) ;
extern  __attribute__((__nothrow__)) double __acosh(double __x ) ;
extern  __attribute__((__nothrow__)) double asinh(double __x ) ;
extern  __attribute__((__nothrow__)) double __asinh(double __x ) ;
extern  __attribute__((__nothrow__)) double atanh(double __x ) ;
extern  __attribute__((__nothrow__)) double __atanh(double __x ) ;
extern  __attribute__((__nothrow__)) double exp(double __x ) ;
extern  __attribute__((__nothrow__)) double __exp(double __x ) ;
extern  __attribute__((__nothrow__)) double frexp(double __x , int *__exponent ) ;
extern  __attribute__((__nothrow__)) double __frexp(double __x ,
                                                    int *__exponent ) ;
extern  __attribute__((__nothrow__)) double ldexp(double __x , int __exponent ) ;
extern  __attribute__((__nothrow__)) double __ldexp(double __x , int __exponent ) ;
extern  __attribute__((__nothrow__)) double log(double __x ) ;
extern  __attribute__((__nothrow__)) double __log(double __x ) ;
extern  __attribute__((__nothrow__)) double log10(double __x ) ;
extern  __attribute__((__nothrow__)) double __log10(double __x ) ;
extern  __attribute__((__nothrow__)) double modf(double __x , double *__iptr ) ;
extern  __attribute__((__nothrow__)) double __modf(double __x , double *__iptr ) ;
extern  __attribute__((__nothrow__)) double exp10(double __x ) ;
extern  __attribute__((__nothrow__)) double __exp10(double __x ) ;
extern  __attribute__((__nothrow__)) double pow10(double __x ) ;
extern  __attribute__((__nothrow__)) double __pow10(double __x ) ;
extern  __attribute__((__nothrow__)) double expm1(double __x ) ;
extern  __attribute__((__nothrow__)) double __expm1(double __x ) ;
extern  __attribute__((__nothrow__)) double log1p(double __x ) ;
extern  __attribute__((__nothrow__)) double __log1p(double __x ) ;
extern  __attribute__((__nothrow__)) double logb(double __x ) ;
extern  __attribute__((__nothrow__)) double __logb(double __x ) ;
extern  __attribute__((__nothrow__)) double exp2(double __x ) ;
extern  __attribute__((__nothrow__)) double __exp2(double __x ) ;
extern  __attribute__((__nothrow__)) double log2(double __x ) ;
extern  __attribute__((__nothrow__)) double __log2(double __x ) ;
extern  __attribute__((__nothrow__)) double pow(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double __pow(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double sqrt(double __x ) ;
extern  __attribute__((__nothrow__)) double __sqrt(double __x ) ;
extern  __attribute__((__nothrow__)) double hypot(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double __hypot(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double cbrt(double __x ) ;
extern  __attribute__((__nothrow__)) double __cbrt(double __x ) ;
__inline extern  __attribute__((__nothrow__)) double ceil(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __ceil(double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) double fabs(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __fabs(double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) double floor(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __floor(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double fmod(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double __fmod(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) int __isinf(double __value )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __finite(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int isinf(double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int finite(double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double drem(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double __drem(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double significand(double __x ) ;
extern  __attribute__((__nothrow__)) double __significand(double __x ) ;
extern  __attribute__((__nothrow__)) double copysign(double __x , double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __copysign(double __x , double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double nan(char const   *__tagb )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __nan(char const   *__tagb )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int __isnan(double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int isnan(double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double j0(double  ) ;
extern  __attribute__((__nothrow__)) double __j0(double  ) ;
extern  __attribute__((__nothrow__)) double j1(double  ) ;
extern  __attribute__((__nothrow__)) double __j1(double  ) ;
extern  __attribute__((__nothrow__)) double jn(int  , double  ) ;
extern  __attribute__((__nothrow__)) double __jn(int  , double  ) ;
extern  __attribute__((__nothrow__)) double y0(double  ) ;
extern  __attribute__((__nothrow__)) double __y0(double  ) ;
extern  __attribute__((__nothrow__)) double y1(double  ) ;
extern  __attribute__((__nothrow__)) double __y1(double  ) ;
extern  __attribute__((__nothrow__)) double yn(int  , double  ) ;
extern  __attribute__((__nothrow__)) double __yn(int  , double  ) ;
extern  __attribute__((__nothrow__)) double erf(double  ) ;
extern  __attribute__((__nothrow__)) double __erf(double  ) ;
extern  __attribute__((__nothrow__)) double erfc(double  ) ;
extern  __attribute__((__nothrow__)) double __erfc(double  ) ;
extern  __attribute__((__nothrow__)) double lgamma(double  ) ;
extern  __attribute__((__nothrow__)) double __lgamma(double  ) ;
extern  __attribute__((__nothrow__)) double tgamma(double  ) ;
extern  __attribute__((__nothrow__)) double __tgamma(double  ) ;
extern  __attribute__((__nothrow__)) double gamma(double  ) ;
extern  __attribute__((__nothrow__)) double __gamma(double  ) ;
extern  __attribute__((__nothrow__)) double lgamma_r(double  , int *__signgamp ) ;
extern  __attribute__((__nothrow__)) double __lgamma_r(double  ,
                                                       int *__signgamp ) ;
extern  __attribute__((__nothrow__)) double rint(double __x ) ;
extern  __attribute__((__nothrow__)) double __rint(double __x ) ;
extern  __attribute__((__nothrow__)) double nextafter(double __x , double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __nextafter(double __x , double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double nexttoward(double __x ,
                                                       long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __nexttoward(double __x ,
                                                         long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double remainder(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double __remainder(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double scalbn(double __x , int __n ) ;
extern  __attribute__((__nothrow__)) double __scalbn(double __x , int __n ) ;
extern  __attribute__((__nothrow__)) int ilogb(double __x ) ;
extern  __attribute__((__nothrow__)) int __ilogb(double __x ) ;
extern  __attribute__((__nothrow__)) double scalbln(double __x , long __n ) ;
extern  __attribute__((__nothrow__)) double __scalbln(double __x , long __n ) ;
extern  __attribute__((__nothrow__)) double nearbyint(double __x ) ;
extern  __attribute__((__nothrow__)) double __nearbyint(double __x ) ;
extern  __attribute__((__nothrow__)) double round(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __round(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double trunc(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double __trunc(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double remquo(double __x , double __y ,
                                                   int *__quo ) ;
extern  __attribute__((__nothrow__)) double __remquo(double __x , double __y ,
                                                     int *__quo ) ;
__inline extern  __attribute__((__nothrow__)) long lrint(double __x ) ;
extern  __attribute__((__nothrow__)) long __lrint(double __x ) ;
__inline extern  __attribute__((__nothrow__)) long long llrint(double __x ) ;
extern  __attribute__((__nothrow__)) long long __llrint(double __x ) ;
extern  __attribute__((__nothrow__)) long lround(double __x ) ;
extern  __attribute__((__nothrow__)) long __lround(double __x ) ;
extern  __attribute__((__nothrow__)) long long llround(double __x ) ;
extern  __attribute__((__nothrow__)) long long __llround(double __x ) ;
extern  __attribute__((__nothrow__)) double fdim(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double __fdim(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double fmax(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double __fmax(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double fmin(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) double __fmin(double __x , double __y ) ;
extern  __attribute__((__nothrow__)) int __fpclassify(double __value )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __signbit(double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) double fma(double __x , double __y ,
                                                double __z ) ;
extern  __attribute__((__nothrow__)) double __fma(double __x , double __y ,
                                                  double __z ) ;
extern  __attribute__((__nothrow__)) double scalb(double __x , double __n ) ;
extern  __attribute__((__nothrow__)) double __scalb(double __x , double __n ) ;
extern  __attribute__((__nothrow__)) float acosf(float __x ) ;
extern  __attribute__((__nothrow__)) float __acosf(float __x ) ;
extern  __attribute__((__nothrow__)) float asinf(float __x ) ;
extern  __attribute__((__nothrow__)) float __asinf(float __x ) ;
extern  __attribute__((__nothrow__)) float atanf(float __x ) ;
extern  __attribute__((__nothrow__)) float __atanf(float __x ) ;
extern  __attribute__((__nothrow__)) float atan2f(float __y , float __x ) ;
extern  __attribute__((__nothrow__)) float __atan2f(float __y , float __x ) ;
extern  __attribute__((__nothrow__)) float cosf(float __x ) ;
extern  __attribute__((__nothrow__)) float __cosf(float __x ) ;
extern  __attribute__((__nothrow__)) float sinf(float __x ) ;
extern  __attribute__((__nothrow__)) float __sinf(float __x ) ;
extern  __attribute__((__nothrow__)) float tanf(float __x ) ;
extern  __attribute__((__nothrow__)) float __tanf(float __x ) ;
extern  __attribute__((__nothrow__)) float coshf(float __x ) ;
extern  __attribute__((__nothrow__)) float __coshf(float __x ) ;
extern  __attribute__((__nothrow__)) float sinhf(float __x ) ;
extern  __attribute__((__nothrow__)) float __sinhf(float __x ) ;
extern  __attribute__((__nothrow__)) float tanhf(float __x ) ;
extern  __attribute__((__nothrow__)) float __tanhf(float __x ) ;
extern  __attribute__((__nothrow__)) void sincosf(float __x , float *__sinx ,
                                                  float *__cosx ) ;
extern  __attribute__((__nothrow__)) void __sincosf(float __x , float *__sinx ,
                                                    float *__cosx ) ;
extern  __attribute__((__nothrow__)) float acoshf(float __x ) ;
extern  __attribute__((__nothrow__)) float __acoshf(float __x ) ;
extern  __attribute__((__nothrow__)) float asinhf(float __x ) ;
extern  __attribute__((__nothrow__)) float __asinhf(float __x ) ;
extern  __attribute__((__nothrow__)) float atanhf(float __x ) ;
extern  __attribute__((__nothrow__)) float __atanhf(float __x ) ;
extern  __attribute__((__nothrow__)) float expf(float __x ) ;
extern  __attribute__((__nothrow__)) float __expf(float __x ) ;
extern  __attribute__((__nothrow__)) float frexpf(float __x , int *__exponent ) ;
extern  __attribute__((__nothrow__)) float __frexpf(float __x , int *__exponent ) ;
extern  __attribute__((__nothrow__)) float ldexpf(float __x , int __exponent ) ;
extern  __attribute__((__nothrow__)) float __ldexpf(float __x , int __exponent ) ;
extern  __attribute__((__nothrow__)) float logf(float __x ) ;
extern  __attribute__((__nothrow__)) float __logf(float __x ) ;
extern  __attribute__((__nothrow__)) float log10f(float __x ) ;
extern  __attribute__((__nothrow__)) float __log10f(float __x ) ;
extern  __attribute__((__nothrow__)) float modff(float __x , float *__iptr ) ;
extern  __attribute__((__nothrow__)) float __modff(float __x , float *__iptr ) ;
extern  __attribute__((__nothrow__)) float exp10f(float __x ) ;
extern  __attribute__((__nothrow__)) float __exp10f(float __x ) ;
extern  __attribute__((__nothrow__)) float pow10f(float __x ) ;
extern  __attribute__((__nothrow__)) float __pow10f(float __x ) ;
extern  __attribute__((__nothrow__)) float expm1f(float __x ) ;
extern  __attribute__((__nothrow__)) float __expm1f(float __x ) ;
extern  __attribute__((__nothrow__)) float log1pf(float __x ) ;
extern  __attribute__((__nothrow__)) float __log1pf(float __x ) ;
extern  __attribute__((__nothrow__)) float logbf(float __x ) ;
extern  __attribute__((__nothrow__)) float __logbf(float __x ) ;
extern  __attribute__((__nothrow__)) float exp2f(float __x ) ;
extern  __attribute__((__nothrow__)) float __exp2f(float __x ) ;
extern  __attribute__((__nothrow__)) float log2f(float __x ) ;
extern  __attribute__((__nothrow__)) float __log2f(float __x ) ;
extern  __attribute__((__nothrow__)) float powf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float __powf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float sqrtf(float __x ) ;
extern  __attribute__((__nothrow__)) float __sqrtf(float __x ) ;
extern  __attribute__((__nothrow__)) float hypotf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float __hypotf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float cbrtf(float __x ) ;
extern  __attribute__((__nothrow__)) float __cbrtf(float __x ) ;
__inline extern  __attribute__((__nothrow__)) float ceilf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __ceilf(float __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) float fabsf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __fabsf(float __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) float floorf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __floorf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float fmodf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float __fmodf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) int __isinff(float __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int __finitef(float __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int isinff(float __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int finitef(float __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float dremf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float __dremf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float significandf(float __x ) ;
extern  __attribute__((__nothrow__)) float __significandf(float __x ) ;
extern  __attribute__((__nothrow__)) float copysignf(float __x , float __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __copysignf(float __x , float __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float nanf(char const   *__tagb )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __nanf(char const   *__tagb )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int __isnanf(float __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int isnanf(float __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float j0f(float  ) ;
extern  __attribute__((__nothrow__)) float __j0f(float  ) ;
extern  __attribute__((__nothrow__)) float j1f(float  ) ;
extern  __attribute__((__nothrow__)) float __j1f(float  ) ;
extern  __attribute__((__nothrow__)) float jnf(int  , float  ) ;
extern  __attribute__((__nothrow__)) float __jnf(int  , float  ) ;
extern  __attribute__((__nothrow__)) float y0f(float  ) ;
extern  __attribute__((__nothrow__)) float __y0f(float  ) ;
extern  __attribute__((__nothrow__)) float y1f(float  ) ;
extern  __attribute__((__nothrow__)) float __y1f(float  ) ;
extern  __attribute__((__nothrow__)) float ynf(int  , float  ) ;
extern  __attribute__((__nothrow__)) float __ynf(int  , float  ) ;
extern  __attribute__((__nothrow__)) float erff(float  ) ;
extern  __attribute__((__nothrow__)) float __erff(float  ) ;
extern  __attribute__((__nothrow__)) float erfcf(float  ) ;
extern  __attribute__((__nothrow__)) float __erfcf(float  ) ;
extern  __attribute__((__nothrow__)) float lgammaf(float  ) ;
extern  __attribute__((__nothrow__)) float __lgammaf(float  ) ;
extern  __attribute__((__nothrow__)) float tgammaf(float  ) ;
extern  __attribute__((__nothrow__)) float __tgammaf(float  ) ;
extern  __attribute__((__nothrow__)) float gammaf(float  ) ;
extern  __attribute__((__nothrow__)) float __gammaf(float  ) ;
extern  __attribute__((__nothrow__)) float lgammaf_r(float  , int *__signgamp ) ;
extern  __attribute__((__nothrow__)) float __lgammaf_r(float  , int *__signgamp ) ;
extern  __attribute__((__nothrow__)) float rintf(float __x ) ;
extern  __attribute__((__nothrow__)) float __rintf(float __x ) ;
extern  __attribute__((__nothrow__)) float nextafterf(float __x , float __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __nextafterf(float __x , float __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float nexttowardf(float __x ,
                                                       long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __nexttowardf(float __x ,
                                                         long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float remainderf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float __remainderf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float scalbnf(float __x , int __n ) ;
extern  __attribute__((__nothrow__)) float __scalbnf(float __x , int __n ) ;
extern  __attribute__((__nothrow__)) int ilogbf(float __x ) ;
extern  __attribute__((__nothrow__)) int __ilogbf(float __x ) ;
extern  __attribute__((__nothrow__)) float scalblnf(float __x , long __n ) ;
extern  __attribute__((__nothrow__)) float __scalblnf(float __x , long __n ) ;
extern  __attribute__((__nothrow__)) float nearbyintf(float __x ) ;
extern  __attribute__((__nothrow__)) float __nearbyintf(float __x ) ;
extern  __attribute__((__nothrow__)) float roundf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __roundf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float truncf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float __truncf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float remquof(float __x , float __y ,
                                                   int *__quo ) ;
extern  __attribute__((__nothrow__)) float __remquof(float __x , float __y ,
                                                     int *__quo ) ;
__inline extern  __attribute__((__nothrow__)) long lrintf(float __x ) ;
extern  __attribute__((__nothrow__)) long __lrintf(float __x ) ;
__inline extern  __attribute__((__nothrow__)) long long llrintf(float __x ) ;
extern  __attribute__((__nothrow__)) long long __llrintf(float __x ) ;
extern  __attribute__((__nothrow__)) long lroundf(float __x ) ;
extern  __attribute__((__nothrow__)) long __lroundf(float __x ) ;
extern  __attribute__((__nothrow__)) long long llroundf(float __x ) ;
extern  __attribute__((__nothrow__)) long long __llroundf(float __x ) ;
extern  __attribute__((__nothrow__)) float fdimf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float __fdimf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float fmaxf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float __fmaxf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float fminf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) float __fminf(float __x , float __y ) ;
extern  __attribute__((__nothrow__)) int __fpclassifyf(float __value )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __signbitf(float __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) float fmaf(float __x , float __y ,
                                                float __z ) ;
extern  __attribute__((__nothrow__)) float __fmaf(float __x , float __y ,
                                                  float __z ) ;
extern  __attribute__((__nothrow__)) float scalbf(float __x , float __n ) ;
extern  __attribute__((__nothrow__)) float __scalbf(float __x , float __n ) ;
extern  __attribute__((__nothrow__)) long double acosl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __acosl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double asinl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __asinl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double atanl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __atanl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double atan2l(long double __y ,
                                                        long double __x ) ;
__inline extern  __attribute__((__nothrow__)) long double __atan2l(long double __y ,
                                                                   long double __x ) ;
extern  __attribute__((__nothrow__)) long double cosl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __cosl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double sinl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __sinl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double tanl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __tanl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double coshl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __coshl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double sinhl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __sinhl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double tanhl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __tanhl(long double __x ) ;
extern  __attribute__((__nothrow__)) void sincosl(long double __x ,
                                                  long double *__sinx ,
                                                  long double *__cosx ) ;
extern  __attribute__((__nothrow__)) void __sincosl(long double __x ,
                                                    long double *__sinx ,
                                                    long double *__cosx ) ;
extern  __attribute__((__nothrow__)) long double acoshl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __acoshl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double asinhl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __asinhl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double atanhl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __atanhl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double expl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __expl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double frexpl(long double __x ,
                                                        int *__exponent ) ;
extern  __attribute__((__nothrow__)) long double __frexpl(long double __x ,
                                                          int *__exponent ) ;
extern  __attribute__((__nothrow__)) long double ldexpl(long double __x ,
                                                        int __exponent ) ;
extern  __attribute__((__nothrow__)) long double __ldexpl(long double __x ,
                                                          int __exponent ) ;
extern  __attribute__((__nothrow__)) long double logl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __logl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double log10l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __log10l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double modfl(long double __x ,
                                                       long double *__iptr ) ;
extern  __attribute__((__nothrow__)) long double __modfl(long double __x ,
                                                         long double *__iptr ) ;
extern  __attribute__((__nothrow__)) long double exp10l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __exp10l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double pow10l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __pow10l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double expm1l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __expm1l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double log1pl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __log1pl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double logbl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __logbl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double exp2l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __exp2l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double log2l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __log2l(long double __x ) ;
extern  __attribute__((__nothrow__)) long double powl(long double __x ,
                                                      long double __y ) ;
extern  __attribute__((__nothrow__)) long double __powl(long double __x ,
                                                        long double __y ) ;
extern  __attribute__((__nothrow__)) long double sqrtl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __sqrtl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double hypotl(long double __x ,
                                                        long double __y ) ;
extern  __attribute__((__nothrow__)) long double __hypotl(long double __x ,
                                                          long double __y ) ;
extern  __attribute__((__nothrow__)) long double cbrtl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __cbrtl(long double __x ) ;
__inline extern  __attribute__((__nothrow__)) long double ceill(long double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double __ceill(long double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) long double fabsl(long double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) long double __fabsl(long double __x )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) long double floorl(long double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double __floorl(long double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double fmodl(long double __x ,
                                                       long double __y ) ;
extern  __attribute__((__nothrow__)) long double __fmodl(long double __x ,
                                                         long double __y ) ;
extern  __attribute__((__nothrow__)) int __isinfl(long double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int __finitel(long double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int isinfl(long double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int finitel(long double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double dreml(long double __x ,
                                                       long double __y ) ;
extern  __attribute__((__nothrow__)) long double __dreml(long double __x ,
                                                         long double __y ) ;
extern  __attribute__((__nothrow__)) long double significandl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __significandl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double copysignl(long double __x ,
                                                           long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double __copysignl(long double __x ,
                                                             long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double nanl(char const   *__tagb )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double __nanl(char const   *__tagb )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int __isnanl(long double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int isnanl(long double __value )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double j0l(long double  ) ;
extern  __attribute__((__nothrow__)) long double __j0l(long double  ) ;
extern  __attribute__((__nothrow__)) long double j1l(long double  ) ;
extern  __attribute__((__nothrow__)) long double __j1l(long double  ) ;
extern  __attribute__((__nothrow__)) long double jnl(int  , long double  ) ;
extern  __attribute__((__nothrow__)) long double __jnl(int  , long double  ) ;
extern  __attribute__((__nothrow__)) long double y0l(long double  ) ;
extern  __attribute__((__nothrow__)) long double __y0l(long double  ) ;
extern  __attribute__((__nothrow__)) long double y1l(long double  ) ;
extern  __attribute__((__nothrow__)) long double __y1l(long double  ) ;
extern  __attribute__((__nothrow__)) long double ynl(int  , long double  ) ;
extern  __attribute__((__nothrow__)) long double __ynl(int  , long double  ) ;
extern  __attribute__((__nothrow__)) long double erfl(long double  ) ;
extern  __attribute__((__nothrow__)) long double __erfl(long double  ) ;
extern  __attribute__((__nothrow__)) long double erfcl(long double  ) ;
extern  __attribute__((__nothrow__)) long double __erfcl(long double  ) ;
extern  __attribute__((__nothrow__)) long double lgammal(long double  ) ;
extern  __attribute__((__nothrow__)) long double __lgammal(long double  ) ;
extern  __attribute__((__nothrow__)) long double tgammal(long double  ) ;
extern  __attribute__((__nothrow__)) long double __tgammal(long double  ) ;
extern  __attribute__((__nothrow__)) long double gammal(long double  ) ;
extern  __attribute__((__nothrow__)) long double __gammal(long double  ) ;
extern  __attribute__((__nothrow__)) long double lgammal_r(long double  ,
                                                           int *__signgamp ) ;
extern  __attribute__((__nothrow__)) long double __lgammal_r(long double  ,
                                                             int *__signgamp ) ;
extern  __attribute__((__nothrow__)) long double rintl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __rintl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double nextafterl(long double __x ,
                                                            long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double __nextafterl(long double __x ,
                                                              long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double nexttowardl(long double __x ,
                                                             long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double __nexttowardl(long double __x ,
                                                               long double __y )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double remainderl(long double __x ,
                                                            long double __y ) ;
extern  __attribute__((__nothrow__)) long double __remainderl(long double __x ,
                                                              long double __y ) ;
extern  __attribute__((__nothrow__)) long double scalbnl(long double __x ,
                                                         int __n ) ;
extern  __attribute__((__nothrow__)) long double __scalbnl(long double __x ,
                                                           int __n ) ;
extern  __attribute__((__nothrow__)) int ilogbl(long double __x ) ;
extern  __attribute__((__nothrow__)) int __ilogbl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double scalblnl(long double __x ,
                                                          long __n ) ;
extern  __attribute__((__nothrow__)) long double __scalblnl(long double __x ,
                                                            long __n ) ;
extern  __attribute__((__nothrow__)) long double nearbyintl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double __nearbyintl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double roundl(long double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double __roundl(long double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double truncl(long double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double __truncl(long double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double remquol(long double __x ,
                                                         long double __y ,
                                                         int *__quo ) ;
extern  __attribute__((__nothrow__)) long double __remquol(long double __x ,
                                                           long double __y ,
                                                           int *__quo ) ;
__inline extern  __attribute__((__nothrow__)) long lrintl(long double __x ) ;
extern  __attribute__((__nothrow__)) long __lrintl(long double __x ) ;
__inline extern  __attribute__((__nothrow__)) long long llrintl(long double __x ) ;
extern  __attribute__((__nothrow__)) long long __llrintl(long double __x ) ;
extern  __attribute__((__nothrow__)) long lroundl(long double __x ) ;
extern  __attribute__((__nothrow__)) long __lroundl(long double __x ) ;
extern  __attribute__((__nothrow__)) long long llroundl(long double __x ) ;
extern  __attribute__((__nothrow__)) long long __llroundl(long double __x ) ;
extern  __attribute__((__nothrow__)) long double fdiml(long double __x ,
                                                       long double __y ) ;
extern  __attribute__((__nothrow__)) long double __fdiml(long double __x ,
                                                         long double __y ) ;
extern  __attribute__((__nothrow__)) long double fmaxl(long double __x ,
                                                       long double __y ) ;
extern  __attribute__((__nothrow__)) long double __fmaxl(long double __x ,
                                                         long double __y ) ;
extern  __attribute__((__nothrow__)) long double fminl(long double __x ,
                                                       long double __y ) ;
extern  __attribute__((__nothrow__)) long double __fminl(long double __x ,
                                                         long double __y ) ;
extern  __attribute__((__nothrow__)) int __fpclassifyl(long double __value )  __attribute__((__const__)) ;
__inline extern  __attribute__((__nothrow__)) int __signbitl(long double __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long double fmal(long double __x ,
                                                      long double __y ,
                                                      long double __z ) ;
extern  __attribute__((__nothrow__)) long double __fmal(long double __x ,
                                                        long double __y ,
                                                        long double __z ) ;
extern  __attribute__((__nothrow__)) long double scalbl(long double __x ,
                                                        long double __n ) ;
extern  __attribute__((__nothrow__)) long double __scalbl(long double __x ,
                                                          long double __n ) ;
extern int signgam ;
extern _LIB_VERSION_TYPE _LIB_VERSION ;
extern int matherr(struct exception *__exc ) ;
__inline extern  __attribute__((__nothrow__)) int __signbitf(float __x )  __attribute__((__const__)) ;
__inline extern int __signbitf(float __x ) 
{ 
  union __anonunion___u_33 __u ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[261] == 0) {
    {
    fprintf(_coverage_fout, "261\n");
    fflush(_coverage_fout);
    ___coverage_array[261] = 1;
    }
  }
  }
  __u.__f = __x;
  {
  if (___coverage_array[262] == 0) {
    {
    fprintf(_coverage_fout, "262\n");
    fflush(_coverage_fout);
    ___coverage_array[262] = 1;
    }
  }
  }
  return (__u.__i < 0);
}
}
__inline extern  __attribute__((__nothrow__)) int __signbit(double __x )  __attribute__((__const__)) ;
__inline extern int __signbit(double __x ) 
{ 
  union __anonunion___u_34 __u ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[263] == 0) {
    {
    fprintf(_coverage_fout, "263\n");
    fflush(_coverage_fout);
    ___coverage_array[263] = 1;
    }
  }
  }
  __u.__d = __x;
  {
  if (___coverage_array[264] == 0) {
    {
    fprintf(_coverage_fout, "264\n");
    fflush(_coverage_fout);
    ___coverage_array[264] = 1;
    }
  }
  }
  return (__u.__i[1] < 0);
}
}
__inline extern  __attribute__((__nothrow__)) int __signbitl(long double __x )  __attribute__((__const__)) ;
__inline extern int __signbitl(long double __x ) 
{ 
  union __anonunion___u_35 __u ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[265] == 0) {
    {
    fprintf(_coverage_fout, "265\n");
    fflush(_coverage_fout);
    ___coverage_array[265] = 1;
    }
  }
  }
  __u.__l = __x;
  {
  if (___coverage_array[266] == 0) {
    {
    fprintf(_coverage_fout, "266\n");
    fflush(_coverage_fout);
    ___coverage_array[266] = 1;
    }
  }
  }
  return ((__u.__i[2] & 32768) != 0);
}
}
__inline extern  __attribute__((__nothrow__)) double __sgn(double __x ) ;
__inline extern  __attribute__((__nothrow__)) double __sgn(double __x ) ;
__inline extern double __sgn(double __x ) 
{ 
  double tmp ;
  double tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[267] == 0) {
    {
    fprintf(_coverage_fout, "267\n");
    fflush(_coverage_fout);
    ___coverage_array[267] = 1;
    }
  }
  }
  if (__x == 0.0) {
    {
    if (___coverage_array[268] == 0) {
      {
      fprintf(_coverage_fout, "268\n");
      fflush(_coverage_fout);
      ___coverage_array[268] = 1;
      }
    }
    }
    tmp___0 = 0.0;
  } else {
    {
    if (___coverage_array[269] == 0) {
      {
      fprintf(_coverage_fout, "269\n");
      fflush(_coverage_fout);
      ___coverage_array[269] = 1;
      }
    }
    }
    if (__x > 0.0) {
      {
      if (___coverage_array[270] == 0) {
        {
        fprintf(_coverage_fout, "270\n");
        fflush(_coverage_fout);
        ___coverage_array[270] = 1;
        }
      }
      }
      tmp = 1.0;
    } else {
      {
      if (___coverage_array[271] == 0) {
        {
        fprintf(_coverage_fout, "271\n");
        fflush(_coverage_fout);
        ___coverage_array[271] = 1;
        }
      }
      }
      tmp = - 1.0;
    }
    {
    if (___coverage_array[272] == 0) {
      {
      fprintf(_coverage_fout, "272\n");
      fflush(_coverage_fout);
      ___coverage_array[272] = 1;
      }
    }
    }
    tmp___0 = tmp;
  }
  {
  if (___coverage_array[273] == 0) {
    {
    fprintf(_coverage_fout, "273\n");
    fflush(_coverage_fout);
    ___coverage_array[273] = 1;
    }
  }
  }
  return (tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) float __sgnf(float __x ) ;
__inline extern  __attribute__((__nothrow__)) float __sgnf(float __x ) ;
__inline extern float __sgnf(float __x ) 
{ 
  double tmp ;
  double tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[274] == 0) {
    {
    fprintf(_coverage_fout, "274\n");
    fflush(_coverage_fout);
    ___coverage_array[274] = 1;
    }
  }
  }
  if ((double )__x == 0.0) {
    {
    if (___coverage_array[275] == 0) {
      {
      fprintf(_coverage_fout, "275\n");
      fflush(_coverage_fout);
      ___coverage_array[275] = 1;
      }
    }
    }
    tmp___0 = 0.0;
  } else {
    {
    if (___coverage_array[276] == 0) {
      {
      fprintf(_coverage_fout, "276\n");
      fflush(_coverage_fout);
      ___coverage_array[276] = 1;
      }
    }
    }
    if ((double )__x > 0.0) {
      {
      if (___coverage_array[277] == 0) {
        {
        fprintf(_coverage_fout, "277\n");
        fflush(_coverage_fout);
        ___coverage_array[277] = 1;
        }
      }
      }
      tmp = 1.0;
    } else {
      {
      if (___coverage_array[278] == 0) {
        {
        fprintf(_coverage_fout, "278\n");
        fflush(_coverage_fout);
        ___coverage_array[278] = 1;
        }
      }
      }
      tmp = - 1.0;
    }
    {
    if (___coverage_array[279] == 0) {
      {
      fprintf(_coverage_fout, "279\n");
      fflush(_coverage_fout);
      ___coverage_array[279] = 1;
      }
    }
    }
    tmp___0 = tmp;
  }
  {
  if (___coverage_array[280] == 0) {
    {
    fprintf(_coverage_fout, "280\n");
    fflush(_coverage_fout);
    ___coverage_array[280] = 1;
    }
  }
  }
  return ((float )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) long double __sgnl(long double __x ) ;
__inline extern  __attribute__((__nothrow__)) long double __sgnl(long double __x ) ;
__inline extern long double __sgnl(long double __x ) 
{ 
  double tmp ;
  double tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[281] == 0) {
    {
    fprintf(_coverage_fout, "281\n");
    fflush(_coverage_fout);
    ___coverage_array[281] = 1;
    }
  }
  }
  if (__x == (long double )0.0) {
    {
    if (___coverage_array[282] == 0) {
      {
      fprintf(_coverage_fout, "282\n");
      fflush(_coverage_fout);
      ___coverage_array[282] = 1;
      }
    }
    }
    tmp___0 = 0.0;
  } else {
    {
    if (___coverage_array[283] == 0) {
      {
      fprintf(_coverage_fout, "283\n");
      fflush(_coverage_fout);
      ___coverage_array[283] = 1;
      }
    }
    }
    if (__x > (long double )0.0) {
      {
      if (___coverage_array[284] == 0) {
        {
        fprintf(_coverage_fout, "284\n");
        fflush(_coverage_fout);
        ___coverage_array[284] = 1;
        }
      }
      }
      tmp = 1.0;
    } else {
      {
      if (___coverage_array[285] == 0) {
        {
        fprintf(_coverage_fout, "285\n");
        fflush(_coverage_fout);
        ___coverage_array[285] = 1;
        }
      }
      }
      tmp = - 1.0;
    }
    {
    if (___coverage_array[286] == 0) {
      {
      fprintf(_coverage_fout, "286\n");
      fflush(_coverage_fout);
      ___coverage_array[286] = 1;
      }
    }
    }
    tmp___0 = tmp;
  }
  {
  if (___coverage_array[287] == 0) {
    {
    fprintf(_coverage_fout, "287\n");
    fflush(_coverage_fout);
    ___coverage_array[287] = 1;
    }
  }
  }
  return ((long double )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) long double __atan2l(long double __y ,
                                                                   long double __x ) ;
__inline extern long double __atan2l(long double __y , long double __x ) 
{ 
  long double tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[288] == 0) {
    {
    fprintf(_coverage_fout, "288\n");
    fflush(_coverage_fout);
    ___coverage_array[288] = 1;
    }
  }
  }
  tmp = __builtin_atan2l(__y, __x);
  {
  if (___coverage_array[289] == 0) {
    {
    fprintf(_coverage_fout, "289\n");
    fflush(_coverage_fout);
    ___coverage_array[289] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) double fabs(double __x )  __attribute__((__const__)) ;
__inline extern double fabs(double __x ) 
{ 
  double tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[290] == 0) {
    {
    fprintf(_coverage_fout, "290\n");
    fflush(_coverage_fout);
    ___coverage_array[290] = 1;
    }
  }
  }
  tmp = __builtin_fabs(__x);
  {
  if (___coverage_array[291] == 0) {
    {
    fprintf(_coverage_fout, "291\n");
    fflush(_coverage_fout);
    ___coverage_array[291] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) float fabsf(float __x )  __attribute__((__const__)) ;
__inline extern float fabsf(float __x ) 
{ 
  float tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[292] == 0) {
    {
    fprintf(_coverage_fout, "292\n");
    fflush(_coverage_fout);
    ___coverage_array[292] = 1;
    }
  }
  }
  tmp = __builtin_fabsf(__x);
  {
  if (___coverage_array[293] == 0) {
    {
    fprintf(_coverage_fout, "293\n");
    fflush(_coverage_fout);
    ___coverage_array[293] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long double fabsl(long double __x )  __attribute__((__const__)) ;
__inline extern long double fabsl(long double __x ) 
{ 
  long double tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[294] == 0) {
    {
    fprintf(_coverage_fout, "294\n");
    fflush(_coverage_fout);
    ___coverage_array[294] = 1;
    }
  }
  }
  tmp = __builtin_fabsl(__x);
  {
  if (___coverage_array[295] == 0) {
    {
    fprintf(_coverage_fout, "295\n");
    fflush(_coverage_fout);
    ___coverage_array[295] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long double __fabsl(long double __x )  __attribute__((__const__)) ;
__inline extern long double __fabsl(long double __x ) 
{ 
  long double tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[296] == 0) {
    {
    fprintf(_coverage_fout, "296\n");
    fflush(_coverage_fout);
    ___coverage_array[296] = 1;
    }
  }
  }
  tmp = __builtin_fabsl(__x);
  {
  if (___coverage_array[297] == 0) {
    {
    fprintf(_coverage_fout, "297\n");
    fflush(_coverage_fout);
    ___coverage_array[297] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long double __sgn1l(long double __x ) ;
__inline extern  __attribute__((__nothrow__)) long double __sgn1l(long double __x ) ;
__inline extern long double __sgn1l(long double __x ) 
{ 
  union __anonunion___n_36 __n ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[298] == 0) {
    {
    fprintf(_coverage_fout, "298\n");
    fflush(_coverage_fout);
    ___coverage_array[298] = 1;
    }
  }
  }
  __n.__xld = __x;
  {
  if (___coverage_array[299] == 0) {
    {
    fprintf(_coverage_fout, "299\n");
    fflush(_coverage_fout);
    ___coverage_array[299] = 1;
    }
  }
  }
  __n.__xi[2] = (__n.__xi[2] & 32768U) | 16383U;
  {
  if (___coverage_array[300] == 0) {
    {
    fprintf(_coverage_fout, "300\n");
    fflush(_coverage_fout);
    ___coverage_array[300] = 1;
    }
  }
  }
  __n.__xi[1] = 2147483648U;
  {
  if (___coverage_array[301] == 0) {
    {
    fprintf(_coverage_fout, "301\n");
    fflush(_coverage_fout);
    ___coverage_array[301] = 1;
    }
  }
  }
  __n.__xi[0] = 0U;
  {
  if (___coverage_array[302] == 0) {
    {
    fprintf(_coverage_fout, "302\n");
    fflush(_coverage_fout);
    ___coverage_array[302] = 1;
    }
  }
  }
  return (__n.__xld);
}
}
__inline extern  __attribute__((__nothrow__)) double floor(double __x )  __attribute__((__const__)) ;
__inline extern double floor(double __x ) 
{ 
  register long double __value ;
  register int __ignore ;
  unsigned short __cw ;
  unsigned short __cwtmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[303] == 0) {
    {
    fprintf(_coverage_fout, "303\n");
    fflush(_coverage_fout);
    ___coverage_array[303] = 1;
    }
  }
  }
  __asm__  volatile   ("fnstcw %3\n\t"
                       "movzwl %3, %1\n\t"
                       "andl $0xf3ff, %1\n\t"
                       "orl $0x0400, %1\n\t"
                       "movw %w1, %2\n\t"
                       "fldcw %2\n\t"
                       "frndint\n\t"
                       "fldcw %3": "=t" (__value), "=&q" (__ignore),
                       "=m" (__cwtmp), "=m" (__cw): "0" (__x));
  {
  if (___coverage_array[304] == 0) {
    {
    fprintf(_coverage_fout, "304\n");
    fflush(_coverage_fout);
    ___coverage_array[304] = 1;
    }
  }
  }
  return ((double )__value);
}
}
__inline extern  __attribute__((__nothrow__)) float floorf(float __x )  __attribute__((__const__)) ;
__inline extern float floorf(float __x ) 
{ 
  register long double __value ;
  register int __ignore ;
  unsigned short __cw ;
  unsigned short __cwtmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[305] == 0) {
    {
    fprintf(_coverage_fout, "305\n");
    fflush(_coverage_fout);
    ___coverage_array[305] = 1;
    }
  }
  }
  __asm__  volatile   ("fnstcw %3\n\t"
                       "movzwl %3, %1\n\t"
                       "andl $0xf3ff, %1\n\t"
                       "orl $0x0400, %1\n\t"
                       "movw %w1, %2\n\t"
                       "fldcw %2\n\t"
                       "frndint\n\t"
                       "fldcw %3": "=t" (__value), "=&q" (__ignore),
                       "=m" (__cwtmp), "=m" (__cw): "0" (__x));
  {
  if (___coverage_array[306] == 0) {
    {
    fprintf(_coverage_fout, "306\n");
    fflush(_coverage_fout);
    ___coverage_array[306] = 1;
    }
  }
  }
  return ((float )__value);
}
}
__inline extern  __attribute__((__nothrow__)) long double floorl(long double __x )  __attribute__((__const__)) ;
__inline extern long double floorl(long double __x ) 
{ 
  register long double __value ;
  register int __ignore ;
  unsigned short __cw ;
  unsigned short __cwtmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[307] == 0) {
    {
    fprintf(_coverage_fout, "307\n");
    fflush(_coverage_fout);
    ___coverage_array[307] = 1;
    }
  }
  }
  __asm__  volatile   ("fnstcw %3\n\t"
                       "movzwl %3, %1\n\t"
                       "andl $0xf3ff, %1\n\t"
                       "orl $0x0400, %1\n\t"
                       "movw %w1, %2\n\t"
                       "fldcw %2\n\t"
                       "frndint\n\t"
                       "fldcw %3": "=t" (__value), "=&q" (__ignore),
                       "=m" (__cwtmp), "=m" (__cw): "0" (__x));
  {
  if (___coverage_array[308] == 0) {
    {
    fprintf(_coverage_fout, "308\n");
    fflush(_coverage_fout);
    ___coverage_array[308] = 1;
    }
  }
  }
  return (__value);
}
}
__inline extern  __attribute__((__nothrow__)) double ceil(double __x )  __attribute__((__const__)) ;
__inline extern double ceil(double __x ) 
{ 
  register long double __value ;
  register int __ignore ;
  unsigned short __cw ;
  unsigned short __cwtmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[309] == 0) {
    {
    fprintf(_coverage_fout, "309\n");
    fflush(_coverage_fout);
    ___coverage_array[309] = 1;
    }
  }
  }
  __asm__  volatile   ("fnstcw %3\n\t"
                       "movzwl %3, %1\n\t"
                       "andl $0xf3ff, %1\n\t"
                       "orl $0x0800, %1\n\t"
                       "movw %w1, %2\n\t"
                       "fldcw %2\n\t"
                       "frndint\n\t"
                       "fldcw %3": "=t" (__value), "=&q" (__ignore),
                       "=m" (__cwtmp), "=m" (__cw): "0" (__x));
  {
  if (___coverage_array[310] == 0) {
    {
    fprintf(_coverage_fout, "310\n");
    fflush(_coverage_fout);
    ___coverage_array[310] = 1;
    }
  }
  }
  return ((double )__value);
}
}
__inline extern  __attribute__((__nothrow__)) float ceilf(float __x )  __attribute__((__const__)) ;
__inline extern float ceilf(float __x ) 
{ 
  register long double __value ;
  register int __ignore ;
  unsigned short __cw ;
  unsigned short __cwtmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[311] == 0) {
    {
    fprintf(_coverage_fout, "311\n");
    fflush(_coverage_fout);
    ___coverage_array[311] = 1;
    }
  }
  }
  __asm__  volatile   ("fnstcw %3\n\t"
                       "movzwl %3, %1\n\t"
                       "andl $0xf3ff, %1\n\t"
                       "orl $0x0800, %1\n\t"
                       "movw %w1, %2\n\t"
                       "fldcw %2\n\t"
                       "frndint\n\t"
                       "fldcw %3": "=t" (__value), "=&q" (__ignore),
                       "=m" (__cwtmp), "=m" (__cw): "0" (__x));
  {
  if (___coverage_array[312] == 0) {
    {
    fprintf(_coverage_fout, "312\n");
    fflush(_coverage_fout);
    ___coverage_array[312] = 1;
    }
  }
  }
  return ((float )__value);
}
}
__inline extern  __attribute__((__nothrow__)) long double ceill(long double __x )  __attribute__((__const__)) ;
__inline extern long double ceill(long double __x ) 
{ 
  register long double __value ;
  register int __ignore ;
  unsigned short __cw ;
  unsigned short __cwtmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[313] == 0) {
    {
    fprintf(_coverage_fout, "313\n");
    fflush(_coverage_fout);
    ___coverage_array[313] = 1;
    }
  }
  }
  __asm__  volatile   ("fnstcw %3\n\t"
                       "movzwl %3, %1\n\t"
                       "andl $0xf3ff, %1\n\t"
                       "orl $0x0800, %1\n\t"
                       "movw %w1, %2\n\t"
                       "fldcw %2\n\t"
                       "frndint\n\t"
                       "fldcw %3": "=t" (__value), "=&q" (__ignore),
                       "=m" (__cwtmp), "=m" (__cw): "0" (__x));
  {
  if (___coverage_array[314] == 0) {
    {
    fprintf(_coverage_fout, "314\n");
    fflush(_coverage_fout);
    ___coverage_array[314] = 1;
    }
  }
  }
  return (__value);
}
}
__inline extern  __attribute__((__nothrow__)) long lrintf(float __x ) ;
__inline extern long lrintf(float __x ) 
{ 
  long __lrintres ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[315] == 0) {
    {
    fprintf(_coverage_fout, "315\n");
    fflush(_coverage_fout);
    ___coverage_array[315] = 1;
    }
  }
  }
  __asm__  volatile   ("fistpl %0": "=m" (__lrintres): "t" (__x): "st");
  {
  if (___coverage_array[316] == 0) {
    {
    fprintf(_coverage_fout, "316\n");
    fflush(_coverage_fout);
    ___coverage_array[316] = 1;
    }
  }
  }
  return (__lrintres);
}
}
__inline extern  __attribute__((__nothrow__)) long lrint(double __x ) ;
__inline extern long lrint(double __x ) 
{ 
  long __lrintres ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[317] == 0) {
    {
    fprintf(_coverage_fout, "317\n");
    fflush(_coverage_fout);
    ___coverage_array[317] = 1;
    }
  }
  }
  __asm__  volatile   ("fistpl %0": "=m" (__lrintres): "t" (__x): "st");
  {
  if (___coverage_array[318] == 0) {
    {
    fprintf(_coverage_fout, "318\n");
    fflush(_coverage_fout);
    ___coverage_array[318] = 1;
    }
  }
  }
  return (__lrintres);
}
}
__inline extern  __attribute__((__nothrow__)) long lrintl(long double __x ) ;
__inline extern long lrintl(long double __x ) 
{ 
  long __lrintres ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[319] == 0) {
    {
    fprintf(_coverage_fout, "319\n");
    fflush(_coverage_fout);
    ___coverage_array[319] = 1;
    }
  }
  }
  __asm__  volatile   ("fistpl %0": "=m" (__lrintres): "t" (__x): "st");
  {
  if (___coverage_array[320] == 0) {
    {
    fprintf(_coverage_fout, "320\n");
    fflush(_coverage_fout);
    ___coverage_array[320] = 1;
    }
  }
  }
  return (__lrintres);
}
}
__inline extern  __attribute__((__nothrow__)) long long llrintf(float __x ) ;
__inline extern long long llrintf(float __x ) 
{ 
  long long __llrintres ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[321] == 0) {
    {
    fprintf(_coverage_fout, "321\n");
    fflush(_coverage_fout);
    ___coverage_array[321] = 1;
    }
  }
  }
  __asm__  volatile   ("fistpll %0": "=m" (__llrintres): "t" (__x): "st");
  {
  if (___coverage_array[322] == 0) {
    {
    fprintf(_coverage_fout, "322\n");
    fflush(_coverage_fout);
    ___coverage_array[322] = 1;
    }
  }
  }
  return (__llrintres);
}
}
__inline extern  __attribute__((__nothrow__)) long long llrint(double __x ) ;
__inline extern long long llrint(double __x ) 
{ 
  long long __llrintres ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[323] == 0) {
    {
    fprintf(_coverage_fout, "323\n");
    fflush(_coverage_fout);
    ___coverage_array[323] = 1;
    }
  }
  }
  __asm__  volatile   ("fistpll %0": "=m" (__llrintres): "t" (__x): "st");
  {
  if (___coverage_array[324] == 0) {
    {
    fprintf(_coverage_fout, "324\n");
    fflush(_coverage_fout);
    ___coverage_array[324] = 1;
    }
  }
  }
  return (__llrintres);
}
}
__inline extern  __attribute__((__nothrow__)) long long llrintl(long double __x ) ;
__inline extern long long llrintl(long double __x ) 
{ 
  long long __llrintres ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[325] == 0) {
    {
    fprintf(_coverage_fout, "325\n");
    fflush(_coverage_fout);
    ___coverage_array[325] = 1;
    }
  }
  }
  __asm__  volatile   ("fistpll %0": "=m" (__llrintres): "t" (__x): "st");
  {
  if (___coverage_array[326] == 0) {
    {
    fprintf(_coverage_fout, "326\n");
    fflush(_coverage_fout);
    ___coverage_array[326] = 1;
    }
  }
  }
  return (__llrintres);
}
}
__inline extern  __attribute__((__nothrow__)) int __finite(double __x )  __attribute__((__const__)) ;
__inline extern int __finite(double __x ) 
{ 
  union __anonunion_37 __constr_expr_0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[327] == 0) {
    {
    fprintf(_coverage_fout, "327\n");
    fflush(_coverage_fout);
    ___coverage_array[327] = 1;
    }
  }
  }
  __constr_expr_0.__d = __x;
  {
  if (___coverage_array[328] == 0) {
    {
    fprintf(_coverage_fout, "328\n");
    fflush(_coverage_fout);
    ___coverage_array[328] = 1;
    }
  }
  }
  return ((int )((((unsigned int )__constr_expr_0.__i[1] | 2148532223U) + 1U) >> 31));
}
}
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) gettimeofday)(struct timeval * __restrict  __tv ,
                                                                                         __timezone_ptr_t __tz ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) settimeofday)(struct timeval  const  *__tv ,
                                                                                         struct timezone  const  *__tz ) ;
extern  __attribute__((__nothrow__)) int adjtime(struct timeval  const  *__delta ,
                                                 struct timeval *__olddelta ) ;
extern  __attribute__((__nothrow__)) int getitimer(__itimer_which_t __which ,
                                                   struct itimerval *__value ) ;
extern  __attribute__((__nothrow__)) int setitimer(__itimer_which_t __which ,
                                                   struct itimerval  const  * __restrict  __new ,
                                                   struct itimerval * __restrict  __old ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) utimes)(char const   *__file ,
                                                                                   struct timeval  const  *__tvp ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) lutimes)(char const   *__file ,
                                                                                    struct timeval  const  *__tvp ) ;
extern  __attribute__((__nothrow__)) int futimes(int __fd ,
                                                 struct timeval  const  *__tvp ) ;
extern  __attribute__((__nothrow__)) int futimesat(int __fd ,
                                                   char const   *__file ,
                                                   struct timeval  const  *__tvp ) ;
extern  __attribute__((__nothrow__)) clock_t clock(void) ;
extern  __attribute__((__nothrow__)) time_t time(time_t *__timer ) ;
extern  __attribute__((__nothrow__)) double difftime(time_t __time1 ,
                                                     time_t __time0 )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) time_t mktime(struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) size_t strftime(char * __restrict  __s ,
                                                     size_t __maxsize ,
                                                     char const   * __restrict  __format ,
                                                     struct tm  const  * __restrict  __tp ) ;
extern  __attribute__((__nothrow__)) char *strptime(char const   * __restrict  __s ,
                                                    char const   * __restrict  __fmt ,
                                                    struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) size_t strftime_l(char * __restrict  __s ,
                                                       size_t __maxsize ,
                                                       char const   * __restrict  __format ,
                                                       struct tm  const  * __restrict  __tp ,
                                                       __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) char *strptime_l(char const   * __restrict  __s ,
                                                      char const   * __restrict  __fmt ,
                                                      struct tm *__tp ,
                                                      __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) struct tm *gmtime(time_t const   *__timer ) ;
extern  __attribute__((__nothrow__)) struct tm *localtime(time_t const   *__timer ) ;
extern  __attribute__((__nothrow__)) struct tm *gmtime_r(time_t const   * __restrict  __timer ,
                                                         struct tm * __restrict  __tp ) ;
extern  __attribute__((__nothrow__)) struct tm *localtime_r(time_t const   * __restrict  __timer ,
                                                            struct tm * __restrict  __tp ) ;
extern  __attribute__((__nothrow__)) char *asctime(struct tm  const  *__tp ) ;
extern  __attribute__((__nothrow__)) char *ctime(time_t const   *__timer ) ;
extern  __attribute__((__nothrow__)) char *asctime_r(struct tm  const  * __restrict  __tp ,
                                                     char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) char *ctime_r(time_t const   * __restrict  __timer ,
                                                   char * __restrict  __buf ) ;
extern char *__tzname[2] ;
extern int __daylight ;
extern long __timezone ;
extern char *tzname[2] ;
extern  __attribute__((__nothrow__)) void tzset(void) ;
extern int daylight ;
extern long timezone ;
extern  __attribute__((__nothrow__)) int stime(time_t const   *__when ) ;
extern  __attribute__((__nothrow__)) time_t timegm(struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) time_t timelocal(struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) int dysize(int __year )  __attribute__((__const__)) ;
extern int nanosleep(struct timespec  const  *__requested_time ,
                     struct timespec *__remaining ) ;
extern  __attribute__((__nothrow__)) int clock_getres(clockid_t __clock_id ,
                                                      struct timespec *__res ) ;
extern  __attribute__((__nothrow__)) int clock_gettime(clockid_t __clock_id ,
                                                       struct timespec *__tp ) ;
extern  __attribute__((__nothrow__)) int clock_settime(clockid_t __clock_id ,
                                                       struct timespec  const  *__tp ) ;
extern int clock_nanosleep(clockid_t __clock_id , int __flags ,
                           struct timespec  const  *__req ,
                           struct timespec *__rem ) ;
extern  __attribute__((__nothrow__)) int clock_getcpuclockid(pid_t __pid ,
                                                             clockid_t *__clock_id ) ;
extern  __attribute__((__nothrow__)) int timer_create(clockid_t __clock_id ,
                                                      struct sigevent * __restrict  __evp ,
                                                      timer_t * __restrict  __timerid ) ;
extern  __attribute__((__nothrow__)) int timer_delete(timer_t __timerid ) ;
extern  __attribute__((__nothrow__)) int timer_settime(timer_t __timerid ,
                                                       int __flags ,
                                                       struct itimerspec  const  * __restrict  __value ,
                                                       struct itimerspec * __restrict  __ovalue ) ;
extern  __attribute__((__nothrow__)) int timer_gettime(timer_t __timerid ,
                                                       struct itimerspec *__value ) ;
extern  __attribute__((__nothrow__)) int timer_getoverrun(timer_t __timerid ) ;
extern int getdate_err ;
extern struct tm *getdate(char const   *__string ) ;
extern int getdate_r(char const   * __restrict  __string ,
                     struct tm * __restrict  __resbufp ) ;
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) stat)(char const   * __restrict  __path ,
                                                                                            struct stat * __restrict  __statbuf )  __asm__("stat64")  ;
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) fstat)(int __fd ,
                                                                                           struct stat *__statbuf )  __asm__("fstat64")  ;
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) stat64)(char const   * __restrict  __path ,
                                                                                              struct stat64 * __restrict  __statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) fstat64)(int __fd ,
                                                                                             struct stat64 *__statbuf ) ;
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3))) fstatat)(int __fd ,
                                                                                               char const   * __restrict  __filename ,
                                                                                               struct stat * __restrict  __statbuf ,
                                                                                               int __flag )  __asm__("fstatat64")  ;
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3))) fstatat64)(int __fd ,
                                                                                                 char const   * __restrict  __filename ,
                                                                                                 struct stat64 * __restrict  __statbuf ,
                                                                                                 int __flag ) ;
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) lstat)(char const   * __restrict  __path ,
                                                                                             struct stat * __restrict  __statbuf )  __asm__("lstat64")  ;
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) lstat64)(char const   * __restrict  __path ,
                                                                                               struct stat64 * __restrict  __statbuf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) chmod)(char const   *__file ,
                                                                                  __mode_t __mode ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) lchmod)(char const   *__file ,
                                                                                   __mode_t __mode ) ;
extern  __attribute__((__nothrow__)) int fchmod(int __fd , __mode_t __mode ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) fchmodat)(int __fd ,
                                                                                     char const   *__file ,
                                                                                     __mode_t __mode ,
                                                                                     int __flag ) ;
extern  __attribute__((__nothrow__)) __mode_t umask(__mode_t __mask ) ;
extern  __attribute__((__nothrow__)) __mode_t getumask(void) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) mkdir)(char const   *__path ,
                                                                                  __mode_t __mode ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) mkdirat)(int __fd ,
                                                                                    char const   *__path ,
                                                                                    __mode_t __mode ) ;
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) mknod)(char const   *__path ,
                                                                                           __mode_t __mode ,
                                                                                           __dev_t __dev ) ;
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) mknodat)(int __fd ,
                                                                                             char const   *__path ,
                                                                                             __mode_t __mode ,
                                                                                             __dev_t __dev ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) mkfifo)(char const   *__path ,
                                                                                   __mode_t __mode ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) mkfifoat)(int __fd ,
                                                                                     char const   *__path ,
                                                                                     __mode_t __mode ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) utimensat)(int __fd ,
                                                                                      char const   *__path ,
                                                                                      struct timespec  const  *__times ,
                                                                                      int __flags ) ;
extern  __attribute__((__nothrow__)) int futimens(int __fd ,
                                                  struct timespec  const  *__times ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3))) __fxstat)(int __ver ,
                                                                                     int __fildes ,
                                                                                     struct stat *__stat_buf )  __asm__("__fxstat64")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3))) __xstat)(int __ver ,
                                                                                      char const   *__filename ,
                                                                                      struct stat *__stat_buf )  __asm__("__xstat64")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3))) __lxstat)(int __ver ,
                                                                                       char const   *__filename ,
                                                                                       struct stat *__stat_buf )  __asm__("__lxstat64")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,4))) __fxstatat)(int __ver ,
                                                                                         int __fildes ,
                                                                                         char const   *__filename ,
                                                                                         struct stat *__stat_buf ,
                                                                                         int __flag )  __asm__("__fxstatat64")  ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3))) __fxstat64)(int __ver ,
                                                                                       int __fildes ,
                                                                                       struct stat64 *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3))) __xstat64)(int __ver ,
                                                                                        char const   *__filename ,
                                                                                        struct stat64 *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3))) __lxstat64)(int __ver ,
                                                                                         char const   *__filename ,
                                                                                         struct stat64 *__stat_buf ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,4))) __fxstatat64)(int __ver ,
                                                                                           int __fildes ,
                                                                                           char const   *__filename ,
                                                                                           struct stat64 *__stat_buf ,
                                                                                           int __flag ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,4))) __xmknod)(int __ver ,
                                                                                       char const   *__path ,
                                                                                       __mode_t __mode ,
                                                                                       __dev_t *__dev ) ;
extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(3,5))) __xmknodat)(int __ver ,
                                                                                         int __fd ,
                                                                                         char const   *__path ,
                                                                                         __mode_t __mode ,
                                                                                         __dev_t *__dev ) ;
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) stat)(char const   * __restrict  __path ,
                                                                                            struct stat * __restrict  __statbuf )  __asm__("stat64")  ;
__inline extern int ( __attribute__((__nonnull__(1,2))) stat)(char const   * __restrict  __path ,
                                                              struct stat * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[329] == 0) {
    {
    fprintf(_coverage_fout, "329\n");
    fflush(_coverage_fout);
    ___coverage_array[329] = 1;
    }
  }
  }
  tmp = __xstat(3, (char const   *)__path, (struct stat *)__statbuf);
  {
  if (___coverage_array[330] == 0) {
    {
    fprintf(_coverage_fout, "330\n");
    fflush(_coverage_fout);
    ___coverage_array[330] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) lstat)(char const   * __restrict  __path ,
                                                                                             struct stat * __restrict  __statbuf )  __asm__("lstat64")  ;
__inline extern int ( __attribute__((__nonnull__(1,2))) lstat)(char const   * __restrict  __path ,
                                                               struct stat * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[331] == 0) {
    {
    fprintf(_coverage_fout, "331\n");
    fflush(_coverage_fout);
    ___coverage_array[331] = 1;
    }
  }
  }
  tmp = __lxstat(3, (char const   *)__path, (struct stat *)__statbuf);
  {
  if (___coverage_array[332] == 0) {
    {
    fprintf(_coverage_fout, "332\n");
    fflush(_coverage_fout);
    ___coverage_array[332] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) fstat)(int __fd ,
                                                                                           struct stat *__statbuf )  __asm__("fstat64")  ;
__inline extern int ( __attribute__((__nonnull__(2))) fstat)(int __fd ,
                                                             struct stat *__statbuf ) 
{ 
  int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[333] == 0) {
    {
    fprintf(_coverage_fout, "333\n");
    fflush(_coverage_fout);
    ___coverage_array[333] = 1;
    }
  }
  }
  tmp = __fxstat(3, __fd, __statbuf);
  {
  if (___coverage_array[334] == 0) {
    {
    fprintf(_coverage_fout, "334\n");
    fflush(_coverage_fout);
    ___coverage_array[334] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3))) fstatat)(int __fd ,
                                                                                               char const   * __restrict  __filename ,
                                                                                               struct stat * __restrict  __statbuf ,
                                                                                               int __flag )  __asm__("fstatat64")  ;
__inline extern int ( __attribute__((__nonnull__(2,3))) fstatat)(int __fd ,
                                                                 char const   * __restrict  __filename ,
                                                                 struct stat * __restrict  __statbuf ,
                                                                 int __flag ) 
{ 
  int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[335] == 0) {
    {
    fprintf(_coverage_fout, "335\n");
    fflush(_coverage_fout);
    ___coverage_array[335] = 1;
    }
  }
  }
  tmp = __fxstatat(3, __fd, (char const   *)__filename,
                   (struct stat *)__statbuf, __flag);
  {
  if (___coverage_array[336] == 0) {
    {
    fprintf(_coverage_fout, "336\n");
    fflush(_coverage_fout);
    ___coverage_array[336] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1))) mknod)(char const   *__path ,
                                                                                           __mode_t __mode ,
                                                                                           __dev_t __dev ) ;
__inline extern int ( __attribute__((__nonnull__(1))) mknod)(char const   *__path ,
                                                             __mode_t __mode ,
                                                             __dev_t __dev ) 
{ 
  int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[337] == 0) {
    {
    fprintf(_coverage_fout, "337\n");
    fflush(_coverage_fout);
    ___coverage_array[337] = 1;
    }
  }
  }
  tmp = __xmknod(1, __path, __mode, & __dev);
  {
  if (___coverage_array[338] == 0) {
    {
    fprintf(_coverage_fout, "338\n");
    fflush(_coverage_fout);
    ___coverage_array[338] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) mknodat)(int __fd ,
                                                                                             char const   *__path ,
                                                                                             __mode_t __mode ,
                                                                                             __dev_t __dev ) ;
__inline extern int ( __attribute__((__nonnull__(2))) mknodat)(int __fd ,
                                                               char const   *__path ,
                                                               __mode_t __mode ,
                                                               __dev_t __dev ) 
{ 
  int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[339] == 0) {
    {
    fprintf(_coverage_fout, "339\n");
    fflush(_coverage_fout);
    ___coverage_array[339] = 1;
    }
  }
  }
  tmp = __xmknodat(1, __fd, __path, __mode, & __dev);
  {
  if (___coverage_array[340] == 0) {
    {
    fprintf(_coverage_fout, "340\n");
    fflush(_coverage_fout);
    ___coverage_array[340] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) stat64)(char const   * __restrict  __path ,
                                                                                              struct stat64 * __restrict  __statbuf ) ;
__inline extern int ( __attribute__((__nonnull__(1,2))) stat64)(char const   * __restrict  __path ,
                                                                struct stat64 * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[341] == 0) {
    {
    fprintf(_coverage_fout, "341\n");
    fflush(_coverage_fout);
    ___coverage_array[341] = 1;
    }
  }
  }
  tmp = __xstat64(3, (char const   *)__path, (struct stat64 *)__statbuf);
  {
  if (___coverage_array[342] == 0) {
    {
    fprintf(_coverage_fout, "342\n");
    fflush(_coverage_fout);
    ___coverage_array[342] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(1,2))) lstat64)(char const   * __restrict  __path ,
                                                                                               struct stat64 * __restrict  __statbuf ) ;
__inline extern int ( __attribute__((__nonnull__(1,2))) lstat64)(char const   * __restrict  __path ,
                                                                 struct stat64 * __restrict  __statbuf ) 
{ 
  int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[343] == 0) {
    {
    fprintf(_coverage_fout, "343\n");
    fflush(_coverage_fout);
    ___coverage_array[343] = 1;
    }
  }
  }
  tmp = __lxstat64(3, (char const   *)__path, (struct stat64 *)__statbuf);
  {
  if (___coverage_array[344] == 0) {
    {
    fprintf(_coverage_fout, "344\n");
    fflush(_coverage_fout);
    ___coverage_array[344] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2))) fstat64)(int __fd ,
                                                                                             struct stat64 *__statbuf ) ;
__inline extern int ( __attribute__((__nonnull__(2))) fstat64)(int __fd ,
                                                               struct stat64 *__statbuf ) 
{ 
  int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[345] == 0) {
    {
    fprintf(_coverage_fout, "345\n");
    fflush(_coverage_fout);
    ___coverage_array[345] = 1;
    }
  }
  }
  tmp = __fxstat64(3, __fd, __statbuf);
  {
  if (___coverage_array[346] == 0) {
    {
    fprintf(_coverage_fout, "346\n");
    fflush(_coverage_fout);
    ___coverage_array[346] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int ( __attribute__((__nonnull__(2,3))) fstatat64)(int __fd ,
                                                                                                 char const   * __restrict  __filename ,
                                                                                                 struct stat64 * __restrict  __statbuf ,
                                                                                                 int __flag ) ;
__inline extern int ( __attribute__((__nonnull__(2,3))) fstatat64)(int __fd ,
                                                                   char const   * __restrict  __filename ,
                                                                   struct stat64 * __restrict  __statbuf ,
                                                                   int __flag ) 
{ 
  int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[347] == 0) {
    {
    fprintf(_coverage_fout, "347\n");
    fflush(_coverage_fout);
    ___coverage_array[347] = 1;
    }
  }
  }
  tmp = __fxstatat64(3, __fd, (char const   *)__filename,
                     (struct stat64 *)__statbuf, __flag);
  {
  if (___coverage_array[348] == 0) {
    {
    fprintf(_coverage_fout, "348\n");
    fflush(_coverage_fout);
    ___coverage_array[348] = 1;
    }
  }
  }
  return (tmp);
}
}
extern void AnnotateRWLockCreate(char const   *file , int line ,
                                 void const volatile   *lock ) ;
extern void AnnotateRWLockDestroy(char const   *file , int line ,
                                  void const volatile   *lock ) ;
extern void AnnotateRWLockAcquired(char const   *file , int line ,
                                   void const volatile   *lock , long is_w ) ;
extern void AnnotateRWLockReleased(char const   *file , int line ,
                                   void const volatile   *lock , long is_w ) ;
extern void AnnotateBarrierInit(char const   *file , int line ,
                                void const volatile   *barrier , long count ,
                                long reinitialization_allowed ) ;
extern void AnnotateBarrierWaitBefore(char const   *file , int line ,
                                      void const volatile   *barrier ) ;
extern void AnnotateBarrierWaitAfter(char const   *file , int line ,
                                     void const volatile   *barrier ) ;
extern void AnnotateBarrierDestroy(char const   *file , int line ,
                                   void const volatile   *barrier ) ;
extern void AnnotateCondVarWait(char const   *file , int line ,
                                void const volatile   *cv ,
                                void const volatile   *lock ) ;
extern void AnnotateCondVarSignal(char const   *file , int line ,
                                  void const volatile   *cv ) ;
extern void AnnotateCondVarSignalAll(char const   *file , int line ,
                                     void const volatile   *cv ) ;
extern void AnnotatePublishMemoryRange(char const   *file , int line ,
                                       void const volatile   *address ,
                                       long size ) ;
extern void AnnotateUnpublishMemoryRange(char const   *file , int line ,
                                         void const volatile   *address ,
                                         long size ) ;
extern void AnnotatePCQCreate(char const   *file , int line ,
                              void const volatile   *pcq ) ;
extern void AnnotatePCQDestroy(char const   *file , int line ,
                               void const volatile   *pcq ) ;
extern void AnnotatePCQPut(char const   *file , int line ,
                           void const volatile   *pcq ) ;
extern void AnnotatePCQGet(char const   *file , int line ,
                           void const volatile   *pcq ) ;
extern void AnnotateNewMemory(char const   *file , int line ,
                              void const volatile   *address , long size ) ;
extern void AnnotateExpectRace(char const   *file , int line ,
                               void const volatile   *address ,
                               char const   *description ) ;
extern void AnnotateBenignRace(char const   *file , int line ,
                               void const volatile   *address ,
                               char const   *description ) ;
extern void AnnotateBenignRaceSized(char const   *file , int line ,
                                    void const volatile   *address , long size ,
                                    char const   *description ) ;
extern void AnnotateMutexIsUsedAsCondVar(char const   *file , int line ,
                                         void const volatile   *mu ) ;
extern void AnnotateTraceMemory(char const   *file , int line ,
                                void const volatile   *arg ) ;
extern void AnnotateThreadName(char const   *file , int line ,
                               char const   *name ) ;
extern void AnnotateIgnoreReadsBegin(char const   *file , int line ) ;
extern void AnnotateIgnoreReadsEnd(char const   *file , int line ) ;
extern void AnnotateIgnoreWritesBegin(char const   *file , int line ) ;
extern void AnnotateIgnoreWritesEnd(char const   *file , int line ) ;
extern void AnnotateEnableRaceDetection(char const   *file , int line ,
                                        int enable ) ;
extern void AnnotateNoOp(char const   *file , int line ,
                         void const volatile   *arg ) ;
extern void AnnotateFlushState(char const   *file , int line ) ;
extern int RunningOnValgrind(void) ;
__inline static void _Py_atomic_signal_fence(_Py_memory_order order ) 
{ 


  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[349] == 0) {
    {
    fprintf(_coverage_fout, "349\n");
    fflush(_coverage_fout);
    ___coverage_array[349] = 1;
    }
  }
  }
  if ((unsigned int )order != 0U) {
    {
    if (___coverage_array[350] == 0) {
      {
      fprintf(_coverage_fout, "350\n");
      fflush(_coverage_fout);
      ___coverage_array[350] = 1;
      }
    }
    }
    __asm__  volatile   ("": : : "memory");
  } else {
    {
    if (___coverage_array[351] == 0) {
      {
      fprintf(_coverage_fout, "351\n");
      fflush(_coverage_fout);
      ___coverage_array[351] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[352] == 0) {
    {
    fprintf(_coverage_fout, "352\n");
    fflush(_coverage_fout);
    ___coverage_array[352] = 1;
    }
  }
  }
  return;
}
}
__inline static void _Py_atomic_thread_fence(_Py_memory_order order ) 
{ 


  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[353] == 0) {
    {
    fprintf(_coverage_fout, "353\n");
    fflush(_coverage_fout);
    ___coverage_array[353] = 1;
    }
  }
  }
  if ((unsigned int )order != 0U) {
    {
    if (___coverage_array[354] == 0) {
      {
      fprintf(_coverage_fout, "354\n");
      fflush(_coverage_fout);
      ___coverage_array[354] = 1;
      }
    }
    }
    __asm__  volatile   ("mfence": : : "memory");
  } else {
    {
    if (___coverage_array[355] == 0) {
      {
      fprintf(_coverage_fout, "355\n");
      fflush(_coverage_fout);
      ___coverage_array[355] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[356] == 0) {
    {
    fprintf(_coverage_fout, "356\n");
    fflush(_coverage_fout);
    ___coverage_array[356] = 1;
    }
  }
  }
  return;
}
}
__inline static void _Py_ANNOTATE_MEMORY_ORDER(void const volatile   *address ,
                                               _Py_memory_order order ) 
{ 


  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[357] == 0) {
    {
    fprintf(_coverage_fout, "357\n");
    fflush(_coverage_fout);
    ___coverage_array[357] = 1;
    }
  }
  }
  switch ((unsigned int )order) {
  {
  if (___coverage_array[358] == 0) {
    {
    fprintf(_coverage_fout, "358\n");
    fflush(_coverage_fout);
    ___coverage_array[358] = 1;
    }
  }
  }
  case 4U: 
  case 3U: 
  case 2U: ;
  {
  if (___coverage_array[359] == 0) {
    {
    fprintf(_coverage_fout, "359\n");
    fflush(_coverage_fout);
    ___coverage_array[359] = 1;
    }
  }
  }
  break;
  {
  if (___coverage_array[360] == 0) {
    {
    fprintf(_coverage_fout, "360\n");
    fflush(_coverage_fout);
    ___coverage_array[360] = 1;
    }
  }
  }
  default: 
  break;
  }
  {
  if (___coverage_array[361] == 0) {
    {
    fprintf(_coverage_fout, "361\n");
    fflush(_coverage_fout);
    ___coverage_array[361] = 1;
    }
  }
  }
  switch ((unsigned int )order) {
  {
  if (___coverage_array[362] == 0) {
    {
    fprintf(_coverage_fout, "362\n");
    fflush(_coverage_fout);
    ___coverage_array[362] = 1;
    }
  }
  }
  case 4U: 
  case 3U: 
  case 1U: ;
  {
  if (___coverage_array[363] == 0) {
    {
    fprintf(_coverage_fout, "363\n");
    fflush(_coverage_fout);
    ___coverage_array[363] = 1;
    }
  }
  }
  break;
  {
  if (___coverage_array[364] == 0) {
    {
    fprintf(_coverage_fout, "364\n");
    fflush(_coverage_fout);
    ___coverage_array[364] = 1;
    }
  }
  }
  default: 
  break;
  }
  {
  if (___coverage_array[365] == 0) {
    {
    fprintf(_coverage_fout, "365\n");
    fflush(_coverage_fout);
    ___coverage_array[365] = 1;
    }
  }
  }
  return;
}
}
extern double _Py_force_double(double  ) ;
extern unsigned short _Py_get_387controlword(void) ;
extern void _Py_set_387controlword(unsigned short  ) ;
extern void _PyTime_gettimeofday(_PyTime_timeval *tp ) ;
extern void _PyTime_Init(void) ;
extern void *PyMem_Malloc(size_t  ) ;
extern void *PyMem_Realloc(void * , size_t  ) ;
extern void PyMem_Free(void * ) ;
extern PyObject *PyType_FromSpec(PyType_Spec * ) ;
extern int PyType_IsSubtype(PyTypeObject * , PyTypeObject * ) ;
extern PyTypeObject PyType_Type ;
extern PyTypeObject PyBaseObject_Type ;
extern PyTypeObject PySuper_Type ;
extern long PyType_GetFlags(PyTypeObject * ) ;
extern int PyType_Ready(PyTypeObject * ) ;
extern PyObject *PyType_GenericAlloc(PyTypeObject * , Py_ssize_t  ) ;
extern PyObject *PyType_GenericNew(PyTypeObject * , PyObject * , PyObject * ) ;
extern PyObject *_PyType_Lookup(PyTypeObject * , PyObject * ) ;
extern PyObject *_PyObject_LookupSpecial(PyObject * , char * , PyObject ** ) ;
extern unsigned int PyType_ClearCache(void) ;
extern void PyType_Modified(PyTypeObject * ) ;
extern int PyObject_Print(PyObject * , FILE * , int  ) ;
extern void _Py_BreakPoint(void) ;
extern void _PyObject_Dump(PyObject * ) ;
extern PyObject *PyObject_Repr(PyObject * ) ;
extern PyObject *PyObject_Str(PyObject * ) ;
extern PyObject *PyObject_ASCII(PyObject * ) ;
extern PyObject *PyObject_Bytes(PyObject * ) ;
extern PyObject *PyObject_RichCompare(PyObject * , PyObject * , int  ) ;
extern int PyObject_RichCompareBool(PyObject * , PyObject * , int  ) ;
extern PyObject *PyObject_GetAttrString(PyObject * , char const   * ) ;
extern int PyObject_SetAttrString(PyObject * , char const   * , PyObject * ) ;
extern int PyObject_HasAttrString(PyObject * , char const   * ) ;
extern PyObject *PyObject_GetAttr(PyObject * , PyObject * ) ;
extern int PyObject_SetAttr(PyObject * , PyObject * , PyObject * ) ;
extern int PyObject_HasAttr(PyObject * , PyObject * ) ;
extern PyObject **_PyObject_GetDictPtr(PyObject * ) ;
extern PyObject *PyObject_SelfIter(PyObject * ) ;
extern PyObject *_PyObject_NextNotImplemented(PyObject * ) ;
extern PyObject *PyObject_GenericGetAttr(PyObject * , PyObject * ) ;
extern int PyObject_GenericSetAttr(PyObject * , PyObject * , PyObject * ) ;
extern Py_hash_t PyObject_Hash(PyObject * ) ;
extern Py_hash_t PyObject_HashNotImplemented(PyObject * ) ;
extern int PyObject_IsTrue(PyObject * ) ;
extern int PyObject_Not(PyObject * ) ;
extern int PyCallable_Check(PyObject * ) ;
extern void PyObject_ClearWeakRefs(PyObject * ) ;
extern PyObject *_PyObject_GenericGetAttrWithDict(PyObject * , PyObject * ,
                                                  PyObject * ) ;
extern int _PyObject_GenericSetAttrWithDict(PyObject * , PyObject * ,
                                            PyObject * , PyObject * ) ;
extern PyObject *PyObject_Dir(PyObject * ) ;
extern int Py_ReprEnter(PyObject * ) ;
extern void Py_ReprLeave(PyObject * ) ;
extern Py_hash_t _Py_HashDouble(double  ) ;
extern Py_hash_t _Py_HashPointer(void * ) ;
extern void Py_IncRef(PyObject * ) ;
extern void Py_DecRef(PyObject * ) ;
extern PyObject _Py_NoneStruct ;
extern PyObject _Py_NotImplementedStruct ;
extern int _Py_SwappedOp[] ;
extern void _PyTrash_deposit_object(PyObject * ) ;
extern void _PyTrash_destroy_chain(void) ;
extern int _PyTrash_delete_nesting ;
extern PyObject *_PyTrash_delete_later ;
extern void *PyObject_Malloc(size_t  ) ;
extern void *PyObject_Realloc(void * , size_t  ) ;
extern void PyObject_Free(void * ) ;
extern PyObject *PyObject_Init(PyObject * , PyTypeObject * ) ;
extern PyVarObject *PyObject_InitVar(PyVarObject * , PyTypeObject * ,
                                     Py_ssize_t  ) ;
extern PyObject *_PyObject_New(PyTypeObject * ) ;
extern PyVarObject *_PyObject_NewVar(PyTypeObject * , Py_ssize_t  ) ;
extern Py_ssize_t PyGC_Collect(void) ;
extern PyVarObject *_PyObject_GC_Resize(PyVarObject * , Py_ssize_t  ) ;
extern PyGC_Head *_PyGC_generation0 ;
extern PyObject *_PyObject_GC_Malloc(size_t  ) ;
extern PyObject *_PyObject_GC_New(PyTypeObject * ) ;
extern PyVarObject *_PyObject_GC_NewVar(PyTypeObject * , Py_ssize_t  ) ;
extern void PyObject_GC_Track(void * ) ;
extern void PyObject_GC_UnTrack(void * ) ;
extern void PyObject_GC_Del(void * ) ;
extern int Py_DebugFlag ;
extern int Py_VerboseFlag ;
extern int Py_QuietFlag ;
extern int Py_InteractiveFlag ;
extern int Py_InspectFlag ;
extern int Py_OptimizeFlag ;
extern int Py_NoSiteFlag ;
extern int Py_BytesWarningFlag ;
extern int Py_UseClassExceptionsFlag ;
extern int Py_FrozenFlag ;
extern int Py_IgnoreEnvironmentFlag ;
extern int Py_DontWriteBytecodeFlag ;
extern int Py_NoUserSiteDirectory ;
extern int Py_UnbufferedStdioFlag ;
extern PyTypeObject PyByteArray_Type ;
extern PyTypeObject PyByteArrayIter_Type ;
extern PyObject *PyByteArray_FromObject(PyObject * ) ;
extern PyObject *PyByteArray_Concat(PyObject * , PyObject * ) ;
extern PyObject *PyByteArray_FromStringAndSize(char const   * , Py_ssize_t  ) ;
extern Py_ssize_t PyByteArray_Size(PyObject * ) ;
extern char *PyByteArray_AsString(PyObject * ) ;
extern int PyByteArray_Resize(PyObject * , Py_ssize_t  ) ;
extern char _PyByteArray_empty_string[] ;
extern PyTypeObject PyBytes_Type ;
extern PyTypeObject PyBytesIter_Type ;
extern PyObject *PyBytes_FromStringAndSize(char const   * , Py_ssize_t  ) ;
extern PyObject *PyBytes_FromString(char const   * ) ;
extern PyObject *PyBytes_FromObject(PyObject * ) ;
extern PyObject *( /* format attribute */  PyBytes_FromFormatV)(char const   * ,
                                                                va_list  ) ;
extern PyObject *( /* format attribute */  PyBytes_FromFormat)(char const   * 
                                                               , ...) ;
extern Py_ssize_t PyBytes_Size(PyObject * ) ;
extern char *PyBytes_AsString(PyObject * ) ;
extern PyObject *PyBytes_Repr(PyObject * , int  ) ;
extern void PyBytes_Concat(PyObject ** , PyObject * ) ;
extern void PyBytes_ConcatAndDel(PyObject ** , PyObject * ) ;
extern int _PyBytes_Resize(PyObject ** , Py_ssize_t  ) ;
extern PyObject *_PyBytes_FormatLong(PyObject * , int  , int  , int  , char ** ,
                                     int * ) ;
extern PyObject *PyBytes_DecodeEscape(char const   * , Py_ssize_t  ,
                                      char const   * , Py_ssize_t  ,
                                      char const   * ) ;
extern PyObject *_PyBytes_Join(PyObject *sep , PyObject *x ) ;
extern int PyBytes_AsStringAndSize(PyObject *obj , char **s , Py_ssize_t *len ) ;
extern Py_ssize_t _PyBytes_InsertThousandsGroupingLocale(char *buffer ,
                                                         Py_ssize_t n_buffer ,
                                                         char *digits ,
                                                         Py_ssize_t n_digits ,
                                                         Py_ssize_t min_width ) ;
extern Py_ssize_t _PyBytes_InsertThousandsGrouping(char *buffer ,
                                                   Py_ssize_t n_buffer ,
                                                   char *digits ,
                                                   Py_ssize_t n_digits ,
                                                   Py_ssize_t min_width ,
                                                   char const   *grouping ,
                                                   char const   *thousands_sep ) ;
extern  __attribute__((__nothrow__)) unsigned short const   **__ctype_b_loc(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) __int32_t const   **__ctype_tolower_loc(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) __int32_t const   **__ctype_toupper_loc(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int isalnum(int  ) ;
extern  __attribute__((__nothrow__)) int isalpha(int  ) ;
extern  __attribute__((__nothrow__)) int iscntrl(int  ) ;
extern  __attribute__((__nothrow__)) int isdigit(int  ) ;
extern  __attribute__((__nothrow__)) int islower(int  ) ;
extern  __attribute__((__nothrow__)) int isgraph(int  ) ;
extern  __attribute__((__nothrow__)) int isprint(int  ) ;
extern  __attribute__((__nothrow__)) int ispunct(int  ) ;
extern  __attribute__((__nothrow__)) int isspace(int  ) ;
extern  __attribute__((__nothrow__)) int isupper(int  ) ;
extern  __attribute__((__nothrow__)) int isxdigit(int  ) ;
__inline extern  __attribute__((__nothrow__)) int tolower(int __c ) ;
__inline extern  __attribute__((__nothrow__)) int toupper(int __c ) ;
extern  __attribute__((__nothrow__)) int isblank(int  ) ;
extern  __attribute__((__nothrow__)) int isctype(int __c , int __mask ) ;
extern  __attribute__((__nothrow__)) int isascii(int __c ) ;
extern  __attribute__((__nothrow__)) int toascii(int __c ) ;
extern  __attribute__((__nothrow__)) int _toupper(int  ) ;
extern  __attribute__((__nothrow__)) int _tolower(int  ) ;
__inline extern  __attribute__((__nothrow__)) int tolower(int __c ) ;
__inline extern int tolower(int __c ) 
{ 
  __int32_t const   **tmp ;
  __int32_t tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[366] == 0) {
    {
    fprintf(_coverage_fout, "366\n");
    fflush(_coverage_fout);
    ___coverage_array[366] = 1;
    }
  }
  }
  if (__c >= -128) {
    {
    if (___coverage_array[367] == 0) {
      {
      fprintf(_coverage_fout, "367\n");
      fflush(_coverage_fout);
      ___coverage_array[367] = 1;
      }
    }
    }
    if (__c < 256) {
      {
      if (___coverage_array[368] == 0) {
        {
        fprintf(_coverage_fout, "368\n");
        fflush(_coverage_fout);
        ___coverage_array[368] = 1;
        }
      }
      }
      tmp = __ctype_tolower_loc();
      {
      if (___coverage_array[369] == 0) {
        {
        fprintf(_coverage_fout, "369\n");
        fflush(_coverage_fout);
        ___coverage_array[369] = 1;
        }
      }
      }
      tmp___0 = *(*tmp + __c);
    } else {
      {
      if (___coverage_array[370] == 0) {
        {
        fprintf(_coverage_fout, "370\n");
        fflush(_coverage_fout);
        ___coverage_array[370] = 1;
        }
      }
      }
      tmp___0 = (__int32_t const   )__c;
    }
  } else {
    {
    if (___coverage_array[371] == 0) {
      {
      fprintf(_coverage_fout, "371\n");
      fflush(_coverage_fout);
      ___coverage_array[371] = 1;
      }
    }
    }
    tmp___0 = (__int32_t const   )__c;
  }
  {
  if (___coverage_array[372] == 0) {
    {
    fprintf(_coverage_fout, "372\n");
    fflush(_coverage_fout);
    ___coverage_array[372] = 1;
    }
  }
  }
  return ((int )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int toupper(int __c ) ;
__inline extern int toupper(int __c ) 
{ 
  __int32_t const   **tmp ;
  __int32_t tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[373] == 0) {
    {
    fprintf(_coverage_fout, "373\n");
    fflush(_coverage_fout);
    ___coverage_array[373] = 1;
    }
  }
  }
  if (__c >= -128) {
    {
    if (___coverage_array[374] == 0) {
      {
      fprintf(_coverage_fout, "374\n");
      fflush(_coverage_fout);
      ___coverage_array[374] = 1;
      }
    }
    }
    if (__c < 256) {
      {
      if (___coverage_array[375] == 0) {
        {
        fprintf(_coverage_fout, "375\n");
        fflush(_coverage_fout);
        ___coverage_array[375] = 1;
        }
      }
      }
      tmp = __ctype_toupper_loc();
      {
      if (___coverage_array[376] == 0) {
        {
        fprintf(_coverage_fout, "376\n");
        fflush(_coverage_fout);
        ___coverage_array[376] = 1;
        }
      }
      }
      tmp___0 = *(*tmp + __c);
    } else {
      {
      if (___coverage_array[377] == 0) {
        {
        fprintf(_coverage_fout, "377\n");
        fflush(_coverage_fout);
        ___coverage_array[377] = 1;
        }
      }
      }
      tmp___0 = (__int32_t const   )__c;
    }
  } else {
    {
    if (___coverage_array[378] == 0) {
      {
      fprintf(_coverage_fout, "378\n");
      fflush(_coverage_fout);
      ___coverage_array[378] = 1;
      }
    }
    }
    tmp___0 = (__int32_t const   )__c;
  }
  {
  if (___coverage_array[379] == 0) {
    {
    fprintf(_coverage_fout, "379\n");
    fflush(_coverage_fout);
    ___coverage_array[379] = 1;
    }
  }
  }
  return ((int )tmp___0);
}
}
extern  __attribute__((__nothrow__)) int isalnum_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isalpha_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int iscntrl_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isdigit_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int islower_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isgraph_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isprint_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int ispunct_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isspace_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isupper_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isxdigit_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isblank_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int __tolower_l(int __c , __locale_t __l ) ;
extern  __attribute__((__nothrow__)) int tolower_l(int __c , __locale_t __l ) ;
extern  __attribute__((__nothrow__)) int __toupper_l(int __c , __locale_t __l ) ;
extern  __attribute__((__nothrow__)) int toupper_l(int __c , __locale_t __l ) ;
extern  __attribute__((__nothrow__)) wchar_t *wcscpy(wchar_t * __restrict  __dest ,
                                                     wchar_t const   * __restrict  __src ) ;
extern  __attribute__((__nothrow__)) wchar_t *wcsncpy(wchar_t * __restrict  __dest ,
                                                      wchar_t const   * __restrict  __src ,
                                                      size_t __n ) ;
extern  __attribute__((__nothrow__)) wchar_t *wcscat(wchar_t * __restrict  __dest ,
                                                     wchar_t const   * __restrict  __src ) ;
extern  __attribute__((__nothrow__)) wchar_t *wcsncat(wchar_t * __restrict  __dest ,
                                                      wchar_t const   * __restrict  __src ,
                                                      size_t __n ) ;
extern  __attribute__((__nothrow__)) int wcscmp(wchar_t const   *__s1 ,
                                                wchar_t const   *__s2 )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int wcsncmp(wchar_t const   *__s1 ,
                                                 wchar_t const   *__s2 ,
                                                 size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int wcscasecmp(wchar_t const   *__s1 ,
                                                    wchar_t const   *__s2 ) ;
extern  __attribute__((__nothrow__)) int wcsncasecmp(wchar_t const   *__s1 ,
                                                     wchar_t const   *__s2 ,
                                                     size_t __n ) ;
extern  __attribute__((__nothrow__)) int wcscasecmp_l(wchar_t const   *__s1 ,
                                                      wchar_t const   *__s2 ,
                                                      __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) int wcsncasecmp_l(wchar_t const   *__s1 ,
                                                       wchar_t const   *__s2 ,
                                                       size_t __n ,
                                                       __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) int wcscoll(wchar_t const   *__s1 ,
                                                 wchar_t const   *__s2 ) ;
extern  __attribute__((__nothrow__)) size_t wcsxfrm(wchar_t * __restrict  __s1 ,
                                                    wchar_t const   * __restrict  __s2 ,
                                                    size_t __n ) ;
extern  __attribute__((__nothrow__)) int wcscoll_l(wchar_t const   *__s1 ,
                                                   wchar_t const   *__s2 ,
                                                   __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) size_t wcsxfrm_l(wchar_t *__s1 ,
                                                      wchar_t const   *__s2 ,
                                                      size_t __n ,
                                                      __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) wchar_t *wcsdup(wchar_t const   *__s )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wcschr(wchar_t const   *__wcs ,
                                                     wchar_t __wc )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wcsrchr(wchar_t const   *__wcs ,
                                                      wchar_t __wc )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wcschrnul(wchar_t const   *__s ,
                                                        wchar_t __wc )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) size_t wcscspn(wchar_t const   *__wcs ,
                                                    wchar_t const   *__reject )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) size_t wcsspn(wchar_t const   *__wcs ,
                                                   wchar_t const   *__accept )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wcspbrk(wchar_t const   *__wcs ,
                                                      wchar_t const   *__accept )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wcsstr(wchar_t const   *__haystack ,
                                                     wchar_t const   *__needle )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wcstok(wchar_t * __restrict  __s ,
                                                     wchar_t const   * __restrict  __delim ,
                                                     wchar_t ** __restrict  __ptr ) ;
extern  __attribute__((__nothrow__)) size_t wcslen(wchar_t const   *__s )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wcswcs(wchar_t const   *__haystack ,
                                                     wchar_t const   *__needle )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) size_t wcsnlen(wchar_t const   *__s ,
                                                    size_t __maxlen )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wmemchr(wchar_t const   *__s ,
                                                      wchar_t __c , size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) int wmemcmp(wchar_t const   * __restrict  __s1 ,
                                                 wchar_t const   * __restrict  __s2 ,
                                                 size_t __n )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) wchar_t *wmemcpy(wchar_t * __restrict  __s1 ,
                                                      wchar_t const   * __restrict  __s2 ,
                                                      size_t __n ) ;
extern  __attribute__((__nothrow__)) wchar_t *wmemmove(wchar_t *__s1 ,
                                                       wchar_t const   *__s2 ,
                                                       size_t __n ) ;
extern  __attribute__((__nothrow__)) wchar_t *wmemset(wchar_t *__s ,
                                                      wchar_t __c , size_t __n ) ;
extern  __attribute__((__nothrow__)) wchar_t *wmempcpy(wchar_t * __restrict  __s1 ,
                                                       wchar_t const   * __restrict  __s2 ,
                                                       size_t __n ) ;
__inline extern  __attribute__((__nothrow__)) wint_t btowc(int __c ) ;
__inline extern  __attribute__((__nothrow__)) int wctob(wint_t __wc ) ;
extern  __attribute__((__nothrow__)) int mbsinit(mbstate_t const   *__ps )  __attribute__((__pure__)) ;
extern  __attribute__((__nothrow__)) size_t mbrtowc(wchar_t * __restrict  __pwc ,
                                                    char const   * __restrict  __s ,
                                                    size_t __n , mbstate_t *__p ) ;
extern  __attribute__((__nothrow__)) size_t wcrtomb(char * __restrict  __s ,
                                                    wchar_t __wc ,
                                                    mbstate_t * __restrict  __ps ) ;
extern  __attribute__((__nothrow__)) size_t __mbrlen(char const   * __restrict  __s ,
                                                     size_t __n ,
                                                     mbstate_t * __restrict  __ps ) ;
__inline extern  __attribute__((__nothrow__)) size_t mbrlen(char const   * __restrict  __s ,
                                                            size_t __n ,
                                                            mbstate_t * __restrict  __ps ) ;
extern wint_t __btowc_alias(int __c )  __asm__("btowc")  ;
__inline extern  __attribute__((__nothrow__)) wint_t btowc(int __c ) ;
__inline extern wint_t btowc(int __c ) 
{ 
  wint_t tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[380] == 0) {
    {
    fprintf(_coverage_fout, "380\n");
    fflush(_coverage_fout);
    ___coverage_array[380] = 1;
    }
  }
  }
  tmp = __btowc_alias(__c);
  {
  if (___coverage_array[381] == 0) {
    {
    fprintf(_coverage_fout, "381\n");
    fflush(_coverage_fout);
    ___coverage_array[381] = 1;
    }
  }
  }
  return (tmp);
}
}
extern int __wctob_alias(wint_t __c )  __asm__("wctob")  ;
__inline extern  __attribute__((__nothrow__)) int wctob(wint_t __wc ) ;
__inline extern int wctob(wint_t __wc ) 
{ 
  int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[382] == 0) {
    {
    fprintf(_coverage_fout, "382\n");
    fflush(_coverage_fout);
    ___coverage_array[382] = 1;
    }
  }
  }
  tmp = __wctob_alias(__wc);
  {
  if (___coverage_array[383] == 0) {
    {
    fprintf(_coverage_fout, "383\n");
    fflush(_coverage_fout);
    ___coverage_array[383] = 1;
    }
  }
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) size_t mbrlen(char const   * __restrict  __s ,
                                                            size_t __n ,
                                                            mbstate_t * __restrict  __ps ) ;
__inline extern size_t mbrlen(char const   * __restrict  __s , size_t __n ,
                              mbstate_t * __restrict  __ps ) 
{ 
  size_t tmp ;
  size_t tmp___0 ;
  size_t tmp___1 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[384] == 0) {
    {
    fprintf(_coverage_fout, "384\n");
    fflush(_coverage_fout);
    ___coverage_array[384] = 1;
    }
  }
  }
  if ((unsigned long )__ps != (unsigned long )((void *)0)) {
    {
    if (___coverage_array[385] == 0) {
      {
      fprintf(_coverage_fout, "385\n");
      fflush(_coverage_fout);
      ___coverage_array[385] = 1;
      }
    }
    }
    tmp = mbrtowc((wchar_t */* __restrict  */)((void *)0), __s, __n,
                  (mbstate_t *)__ps);
    {
    if (___coverage_array[386] == 0) {
      {
      fprintf(_coverage_fout, "386\n");
      fflush(_coverage_fout);
      ___coverage_array[386] = 1;
      }
    }
    }
    tmp___1 = tmp;
  } else {
    {
    if (___coverage_array[387] == 0) {
      {
      fprintf(_coverage_fout, "387\n");
      fflush(_coverage_fout);
      ___coverage_array[387] = 1;
      }
    }
    }
    tmp___0 = __mbrlen(__s, __n, (mbstate_t */* __restrict  */)((void *)0));
    {
    if (___coverage_array[388] == 0) {
      {
      fprintf(_coverage_fout, "388\n");
      fflush(_coverage_fout);
      ___coverage_array[388] = 1;
      }
    }
    }
    tmp___1 = tmp___0;
  }
  {
  if (___coverage_array[389] == 0) {
    {
    fprintf(_coverage_fout, "389\n");
    fflush(_coverage_fout);
    ___coverage_array[389] = 1;
    }
  }
  }
  return (tmp___1);
}
}
extern  __attribute__((__nothrow__)) size_t mbsrtowcs(wchar_t * __restrict  __dst ,
                                                      char const   ** __restrict  __src ,
                                                      size_t __len ,
                                                      mbstate_t * __restrict  __ps ) ;
extern  __attribute__((__nothrow__)) size_t wcsrtombs(char * __restrict  __dst ,
                                                      wchar_t const   ** __restrict  __src ,
                                                      size_t __len ,
                                                      mbstate_t * __restrict  __ps ) ;
extern  __attribute__((__nothrow__)) size_t mbsnrtowcs(wchar_t * __restrict  __dst ,
                                                       char const   ** __restrict  __src ,
                                                       size_t __nmc ,
                                                       size_t __len ,
                                                       mbstate_t * __restrict  __ps ) ;
extern  __attribute__((__nothrow__)) size_t wcsnrtombs(char * __restrict  __dst ,
                                                       wchar_t const   ** __restrict  __src ,
                                                       size_t __nwc ,
                                                       size_t __len ,
                                                       mbstate_t * __restrict  __ps ) ;
extern  __attribute__((__nothrow__)) int wcwidth(wchar_t __c ) ;
extern  __attribute__((__nothrow__)) int wcswidth(wchar_t const   *__s ,
                                                  size_t __n ) ;
extern  __attribute__((__nothrow__)) double wcstod(wchar_t const   * __restrict  __nptr ,
                                                   wchar_t ** __restrict  __endptr ) ;
extern  __attribute__((__nothrow__)) float wcstof(wchar_t const   * __restrict  __nptr ,
                                                  wchar_t ** __restrict  __endptr ) ;
extern  __attribute__((__nothrow__)) long double wcstold(wchar_t const   * __restrict  __nptr ,
                                                         wchar_t ** __restrict  __endptr ) ;
extern  __attribute__((__nothrow__)) long wcstol(wchar_t const   * __restrict  __nptr ,
                                                 wchar_t ** __restrict  __endptr ,
                                                 int __base ) ;
extern  __attribute__((__nothrow__)) unsigned long wcstoul(wchar_t const   * __restrict  __nptr ,
                                                           wchar_t ** __restrict  __endptr ,
                                                           int __base ) ;
extern  __attribute__((__nothrow__)) long long wcstoll(wchar_t const   * __restrict  __nptr ,
                                                       wchar_t ** __restrict  __endptr ,
                                                       int __base ) ;
extern  __attribute__((__nothrow__)) unsigned long long wcstoull(wchar_t const   * __restrict  __nptr ,
                                                                 wchar_t ** __restrict  __endptr ,
                                                                 int __base ) ;
extern  __attribute__((__nothrow__)) long long wcstoq(wchar_t const   * __restrict  __nptr ,
                                                      wchar_t ** __restrict  __endptr ,
                                                      int __base ) ;
extern  __attribute__((__nothrow__)) unsigned long long wcstouq(wchar_t const   * __restrict  __nptr ,
                                                                wchar_t ** __restrict  __endptr ,
                                                                int __base ) ;
extern  __attribute__((__nothrow__)) long wcstol_l(wchar_t const   * __restrict  __nptr ,
                                                   wchar_t ** __restrict  __endptr ,
                                                   int __base ,
                                                   __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) unsigned long wcstoul_l(wchar_t const   * __restrict  __nptr ,
                                                             wchar_t ** __restrict  __endptr ,
                                                             int __base ,
                                                             __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) long long wcstoll_l(wchar_t const   * __restrict  __nptr ,
                                                         wchar_t ** __restrict  __endptr ,
                                                         int __base ,
                                                         __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) unsigned long long wcstoull_l(wchar_t const   * __restrict  __nptr ,
                                                                   wchar_t ** __restrict  __endptr ,
                                                                   int __base ,
                                                                   __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) double wcstod_l(wchar_t const   * __restrict  __nptr ,
                                                     wchar_t ** __restrict  __endptr ,
                                                     __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) float wcstof_l(wchar_t const   * __restrict  __nptr ,
                                                    wchar_t ** __restrict  __endptr ,
                                                    __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) long double wcstold_l(wchar_t const   * __restrict  __nptr ,
                                                           wchar_t ** __restrict  __endptr ,
                                                           __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) wchar_t *wcpcpy(wchar_t * __restrict  __dest ,
                                                     wchar_t const   * __restrict  __src ) ;
extern  __attribute__((__nothrow__)) wchar_t *wcpncpy(wchar_t * __restrict  __dest ,
                                                      wchar_t const   * __restrict  __src ,
                                                      size_t __n ) ;
extern  __attribute__((__nothrow__)) __FILE *open_wmemstream(wchar_t **__bufloc ,
                                                             size_t *__sizeloc ) ;
extern  __attribute__((__nothrow__)) int fwide(__FILE *__fp , int __mode ) ;
extern int fwprintf(__FILE * __restrict  __stream ,
                    wchar_t const   * __restrict  __format  , ...) ;
extern int wprintf(wchar_t const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int swprintf(wchar_t * __restrict  __s ,
                                                  size_t __n ,
                                                  wchar_t const   * __restrict  __format 
                                                  , ...) ;
extern int vfwprintf(__FILE * __restrict  __s ,
                     wchar_t const   * __restrict  __format ,
                     __gnuc_va_list __arg ) ;
extern int vwprintf(wchar_t const   * __restrict  __format ,
                    __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vswprintf(wchar_t * __restrict  __s ,
                                                   size_t __n ,
                                                   wchar_t const   * __restrict  __format ,
                                                   __gnuc_va_list __arg ) ;
extern int fwscanf(__FILE * __restrict  __stream ,
                   wchar_t const   * __restrict  __format  , ...) ;
extern int wscanf(wchar_t const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int swscanf(wchar_t const   * __restrict  __s ,
                                                 wchar_t const   * __restrict  __format 
                                                 , ...) ;
extern int vfwscanf(__FILE * __restrict  __s ,
                    wchar_t const   * __restrict  __format ,
                    __gnuc_va_list __arg ) ;
extern int vwscanf(wchar_t const   * __restrict  __format ,
                   __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vswscanf(wchar_t const   * __restrict  __s ,
                                                  wchar_t const   * __restrict  __format ,
                                                  __gnuc_va_list __arg ) ;
extern wint_t fgetwc(__FILE *__stream ) ;
extern wint_t getwc(__FILE *__stream ) ;
extern wint_t getwchar(void) ;
extern wint_t fputwc(wchar_t __wc , __FILE *__stream ) ;
extern wint_t putwc(wchar_t __wc , __FILE *__stream ) ;
extern wint_t putwchar(wchar_t __wc ) ;
extern wchar_t *fgetws(wchar_t * __restrict  __ws , int __n ,
                       __FILE * __restrict  __stream ) ;
extern int fputws(wchar_t const   * __restrict  __ws ,
                  __FILE * __restrict  __stream ) ;
extern wint_t ungetwc(wint_t __wc , __FILE *__stream ) ;
extern wint_t getwc_unlocked(__FILE *__stream ) ;
extern wint_t getwchar_unlocked(void) ;
extern wint_t fgetwc_unlocked(__FILE *__stream ) ;
extern wint_t fputwc_unlocked(wchar_t __wc , __FILE *__stream ) ;
extern wint_t putwc_unlocked(wchar_t __wc , __FILE *__stream ) ;
extern wint_t putwchar_unlocked(wchar_t __wc ) ;
extern wchar_t *fgetws_unlocked(wchar_t * __restrict  __ws , int __n ,
                                __FILE * __restrict  __stream ) ;
extern int fputws_unlocked(wchar_t const   * __restrict  __ws ,
                           __FILE * __restrict  __stream ) ;
extern  __attribute__((__nothrow__)) size_t wcsftime(wchar_t * __restrict  __s ,
                                                     size_t __maxsize ,
                                                     wchar_t const   * __restrict  __format ,
                                                     struct tm  const  * __restrict  __tp ) ;
extern  __attribute__((__nothrow__)) size_t wcsftime_l(wchar_t * __restrict  __s ,
                                                       size_t __maxsize ,
                                                       wchar_t const   * __restrict  __format ,
                                                       struct tm  const  * __restrict  __tp ,
                                                       __locale_t __loc ) ;
extern PyTypeObject PyUnicode_Type ;
extern PyTypeObject PyUnicodeIter_Type ;
extern PyObject *PyUnicodeUCS2_FromUnicode(Py_UNICODE const   *u ,
                                           Py_ssize_t size ) ;
extern PyObject *PyUnicodeUCS2_FromStringAndSize(char const   *u ,
                                                 Py_ssize_t size ) ;
extern PyObject *PyUnicodeUCS2_FromString(char const   *u ) ;
extern Py_UNICODE *PyUnicodeUCS2_AsUnicode(PyObject *unicode ) ;
extern Py_ssize_t PyUnicodeUCS2_GetSize(PyObject *unicode ) ;
extern Py_UNICODE PyUnicodeUCS2_GetMax(void) ;
extern int PyUnicodeUCS2_Resize(PyObject **unicode , Py_ssize_t length ) ;
extern PyObject *PyUnicodeUCS2_FromEncodedObject(PyObject *obj ,
                                                 char const   *encoding ,
                                                 char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_FromObject(PyObject *obj ) ;
extern PyObject *PyUnicodeUCS2_FromFormatV(char const   *format , va_list vargs ) ;
extern PyObject *PyUnicodeUCS2_FromFormat(char const   *format  , ...) ;
extern PyObject *_PyUnicode_FormatAdvanced(PyObject *obj ,
                                           Py_UNICODE *format_spec ,
                                           Py_ssize_t format_spec_len ) ;
extern void PyUnicode_InternInPlace(PyObject ** ) ;
extern void PyUnicode_InternImmortal(PyObject ** ) ;
extern PyObject *PyUnicode_InternFromString(char const   *u ) ;
extern void _Py_ReleaseInternedUnicodeStrings(void) ;
extern PyObject *PyUnicodeUCS2_FromWideChar(wchar_t const   *w ,
                                            Py_ssize_t size ) ;
extern Py_ssize_t PyUnicodeUCS2_AsWideChar(PyObject *unicode , wchar_t *w ,
                                           Py_ssize_t size ) ;
extern wchar_t *PyUnicodeUCS2_AsWideCharString(PyObject *unicode ,
                                               Py_ssize_t *size ) ;
extern PyObject *PyUnicodeUCS2_FromOrdinal(int ordinal ) ;
extern int PyUnicodeUCS2_ClearFreelist(void) ;
extern PyObject *_PyUnicodeUCS2_AsDefaultEncodedString(PyObject *unicode ) ;
extern char *_PyUnicode_AsStringAndSize(PyObject *unicode , Py_ssize_t *size ) ;
extern char *_PyUnicode_AsString(PyObject *unicode ) ;
extern char const   *PyUnicodeUCS2_GetDefaultEncoding(void) ;
extern PyObject *PyUnicodeUCS2_Decode(char const   *s , Py_ssize_t size ,
                                      char const   *encoding ,
                                      char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsDecodedObject(PyObject *unicode ,
                                               char const   *encoding ,
                                               char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsDecodedUnicode(PyObject *unicode ,
                                                char const   *encoding ,
                                                char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_Encode(Py_UNICODE const   *s , Py_ssize_t size ,
                                      char const   *encoding ,
                                      char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsEncodedObject(PyObject *unicode ,
                                               char const   *encoding ,
                                               char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsEncodedString(PyObject *unicode ,
                                               char const   *encoding ,
                                               char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsEncodedUnicode(PyObject *unicode ,
                                                char const   *encoding ,
                                                char const   *errors ) ;
extern PyObject *PyUnicode_BuildEncodingMap(PyObject *string ) ;
extern PyObject *PyUnicode_DecodeUTF7(char const   *string , Py_ssize_t length ,
                                      char const   *errors ) ;
extern PyObject *PyUnicode_DecodeUTF7Stateful(char const   *string ,
                                              Py_ssize_t length ,
                                              char const   *errors ,
                                              Py_ssize_t *consumed ) ;
extern PyObject *PyUnicode_EncodeUTF7(Py_UNICODE const   *data ,
                                      Py_ssize_t length , int base64SetO ,
                                      int base64WhiteSpace ,
                                      char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_DecodeUTF8(char const   *string ,
                                          Py_ssize_t length ,
                                          char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_DecodeUTF8Stateful(char const   *string ,
                                                  Py_ssize_t length ,
                                                  char const   *errors ,
                                                  Py_ssize_t *consumed ) ;
extern PyObject *PyUnicodeUCS2_AsUTF8String(PyObject *unicode ) ;
extern PyObject *PyUnicodeUCS2_EncodeUTF8(Py_UNICODE const   *data ,
                                          Py_ssize_t length ,
                                          char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_DecodeUTF32(char const   *string ,
                                           Py_ssize_t length ,
                                           char const   *errors ,
                                           int *byteorder ) ;
extern PyObject *PyUnicodeUCS2_DecodeUTF32Stateful(char const   *string ,
                                                   Py_ssize_t length ,
                                                   char const   *errors ,
                                                   int *byteorder ,
                                                   Py_ssize_t *consumed ) ;
extern PyObject *PyUnicodeUCS2_AsUTF32String(PyObject *unicode ) ;
extern PyObject *PyUnicodeUCS2_EncodeUTF32(Py_UNICODE const   *data ,
                                           Py_ssize_t length ,
                                           char const   *errors , int byteorder ) ;
extern PyObject *PyUnicodeUCS2_DecodeUTF16(char const   *string ,
                                           Py_ssize_t length ,
                                           char const   *errors ,
                                           int *byteorder ) ;
extern PyObject *PyUnicodeUCS2_DecodeUTF16Stateful(char const   *string ,
                                                   Py_ssize_t length ,
                                                   char const   *errors ,
                                                   int *byteorder ,
                                                   Py_ssize_t *consumed ) ;
extern PyObject *PyUnicodeUCS2_AsUTF16String(PyObject *unicode ) ;
extern PyObject *PyUnicodeUCS2_EncodeUTF16(Py_UNICODE const   *data ,
                                           Py_ssize_t length ,
                                           char const   *errors , int byteorder ) ;
extern PyObject *PyUnicodeUCS2_DecodeUnicodeEscape(char const   *string ,
                                                   Py_ssize_t length ,
                                                   char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsUnicodeEscapeString(PyObject *unicode ) ;
extern PyObject *PyUnicodeUCS2_EncodeUnicodeEscape(Py_UNICODE const   *data ,
                                                   Py_ssize_t length ) ;
extern PyObject *PyUnicodeUCS2_DecodeRawUnicodeEscape(char const   *string ,
                                                      Py_ssize_t length ,
                                                      char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsRawUnicodeEscapeString(PyObject *unicode ) ;
extern PyObject *PyUnicodeUCS2_EncodeRawUnicodeEscape(Py_UNICODE const   *data ,
                                                      Py_ssize_t length ) ;
extern PyObject *_PyUnicode_DecodeUnicodeInternal(char const   *string ,
                                                  Py_ssize_t length ,
                                                  char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_DecodeLatin1(char const   *string ,
                                            Py_ssize_t length ,
                                            char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsLatin1String(PyObject *unicode ) ;
extern PyObject *PyUnicodeUCS2_EncodeLatin1(Py_UNICODE const   *data ,
                                            Py_ssize_t length ,
                                            char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_DecodeASCII(char const   *string ,
                                           Py_ssize_t length ,
                                           char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsASCIIString(PyObject *unicode ) ;
extern PyObject *PyUnicodeUCS2_EncodeASCII(Py_UNICODE const   *data ,
                                           Py_ssize_t length ,
                                           char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_DecodeCharmap(char const   *string ,
                                             Py_ssize_t length ,
                                             PyObject *mapping ,
                                             char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_AsCharmapString(PyObject *unicode ,
                                               PyObject *mapping ) ;
extern PyObject *PyUnicodeUCS2_EncodeCharmap(Py_UNICODE const   *data ,
                                             Py_ssize_t length ,
                                             PyObject *mapping ,
                                             char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_TranslateCharmap(Py_UNICODE const   *data ,
                                                Py_ssize_t length ,
                                                PyObject *table ,
                                                char const   *errors ) ;
extern int PyUnicodeUCS2_EncodeDecimal(Py_UNICODE *s , Py_ssize_t length ,
                                       char *output , char const   *errors ) ;
extern PyObject *PyUnicode_TransformDecimalToASCII(Py_UNICODE *s ,
                                                   Py_ssize_t length ) ;
extern int PyUnicodeUCS2_FSConverter(PyObject * , void * ) ;
extern int PyUnicodeUCS2_FSDecoder(PyObject * , void * ) ;
extern PyObject *PyUnicodeUCS2_DecodeFSDefault(char const   *s ) ;
extern PyObject *PyUnicodeUCS2_DecodeFSDefaultAndSize(char const   *s ,
                                                      Py_ssize_t size ) ;
extern PyObject *PyUnicode_EncodeFSDefault(PyObject *unicode ) ;
extern PyObject *PyUnicodeUCS2_Concat(PyObject *left , PyObject *right ) ;
extern void PyUnicodeUCS2_Append(PyObject **pleft , PyObject *right ) ;
extern void PyUnicodeUCS2_AppendAndDel(PyObject **pleft , PyObject *right ) ;
extern PyObject *PyUnicodeUCS2_Split(PyObject *s , PyObject *sep ,
                                     Py_ssize_t maxsplit ) ;
extern PyObject *PyUnicodeUCS2_Splitlines(PyObject *s , int keepends ) ;
extern PyObject *PyUnicodeUCS2_Partition(PyObject *s , PyObject *sep ) ;
extern PyObject *PyUnicodeUCS2_RPartition(PyObject *s , PyObject *sep ) ;
extern PyObject *PyUnicodeUCS2_RSplit(PyObject *s , PyObject *sep ,
                                      Py_ssize_t maxsplit ) ;
extern PyObject *PyUnicodeUCS2_Translate(PyObject *str , PyObject *table ,
                                         char const   *errors ) ;
extern PyObject *PyUnicodeUCS2_Join(PyObject *separator , PyObject *seq ) ;
extern Py_ssize_t PyUnicodeUCS2_Tailmatch(PyObject *str , PyObject *substr ,
                                          Py_ssize_t start , Py_ssize_t end ,
                                          int direction ) ;
extern Py_ssize_t PyUnicodeUCS2_Find(PyObject *str , PyObject *substr ,
                                     Py_ssize_t start , Py_ssize_t end ,
                                     int direction ) ;
extern Py_ssize_t PyUnicodeUCS2_Count(PyObject *str , PyObject *substr ,
                                      Py_ssize_t start , Py_ssize_t end ) ;
extern PyObject *PyUnicodeUCS2_Replace(PyObject *str , PyObject *substr ,
                                       PyObject *replstr , Py_ssize_t maxcount ) ;
extern int PyUnicodeUCS2_Compare(PyObject *left , PyObject *right ) ;
extern int PyUnicodeUCS2_CompareWithASCIIString(PyObject *left ,
                                                char const   *right ) ;
extern PyObject *PyUnicodeUCS2_RichCompare(PyObject *left , PyObject *right ,
                                           int op ) ;
extern PyObject *PyUnicodeUCS2_Format(PyObject *format , PyObject *args ) ;
extern int PyUnicodeUCS2_Contains(PyObject *container , PyObject *element ) ;
extern int PyUnicodeUCS2_IsIdentifier(PyObject *s ) ;
extern PyObject *_PyUnicode_XStrip(PyUnicodeObject *self , int striptype ,
                                   PyObject *sepobj ) ;
extern Py_ssize_t _PyUnicode_InsertThousandsGroupingLocale(Py_UNICODE *buffer ,
                                                           Py_ssize_t n_buffer ,
                                                           Py_UNICODE *digits ,
                                                           Py_ssize_t n_digits ,
                                                           Py_ssize_t min_width ) ;
extern Py_ssize_t _PyUnicode_InsertThousandsGrouping(Py_UNICODE *buffer ,
                                                     Py_ssize_t n_buffer ,
                                                     Py_UNICODE *digits ,
                                                     Py_ssize_t n_digits ,
                                                     Py_ssize_t min_width ,
                                                     char const   *grouping ,
                                                     char const   *thousands_sep ) ;
extern unsigned char const   _Py_ascii_whitespace[] ;
extern int _PyUnicode_IsLowercase(Py_UCS4 ch ) ;
extern int _PyUnicode_IsUppercase(Py_UCS4 ch ) ;
extern int _PyUnicode_IsTitlecase(Py_UCS4 ch ) ;
extern int _PyUnicode_IsXidStart(Py_UCS4 ch ) ;
extern int _PyUnicode_IsXidContinue(Py_UCS4 ch ) ;
extern int _PyUnicode_IsWhitespace(Py_UCS4 const   ch ) ;
extern int _PyUnicode_IsLinebreak(Py_UCS4 const   ch ) ;
extern Py_UCS4 _PyUnicode_ToLowercase(Py_UCS4 ch ) ;
extern Py_UCS4 _PyUnicode_ToUppercase(Py_UCS4 ch ) ;
extern Py_UCS4 _PyUnicode_ToTitlecase(Py_UCS4 ch ) ;
extern int _PyUnicode_ToDecimalDigit(Py_UCS4 ch ) ;
extern int _PyUnicode_ToDigit(Py_UCS4 ch ) ;
extern double _PyUnicode_ToNumeric(Py_UCS4 ch ) ;
extern int _PyUnicode_IsDecimalDigit(Py_UCS4 ch ) ;
extern int _PyUnicode_IsDigit(Py_UCS4 ch ) ;
extern int _PyUnicode_IsNumeric(Py_UCS4 ch ) ;
extern int _PyUnicode_IsPrintable(Py_UCS4 ch ) ;
extern int _PyUnicode_IsAlpha(Py_UCS4 ch ) ;
extern size_t Py_UNICODE_strlen(Py_UNICODE const   *u ) ;
extern Py_UNICODE *Py_UNICODE_strcpy(Py_UNICODE *s1 , Py_UNICODE const   *s2 ) ;
extern Py_UNICODE *Py_UNICODE_strcat(Py_UNICODE *s1 , Py_UNICODE const   *s2 ) ;
extern Py_UNICODE *Py_UNICODE_strncpy(Py_UNICODE *s1 , Py_UNICODE const   *s2 ,
                                      size_t n ) ;
extern int Py_UNICODE_strcmp(Py_UNICODE const   *s1 , Py_UNICODE const   *s2 ) ;
extern int Py_UNICODE_strncmp(Py_UNICODE const   *s1 , Py_UNICODE const   *s2 ,
                              size_t n ) ;
extern Py_UNICODE *Py_UNICODE_strchr(Py_UNICODE const   *s , Py_UNICODE c ) ;
extern Py_UNICODE *Py_UNICODE_strrchr(Py_UNICODE const   *s , Py_UNICODE c ) ;
extern Py_UNICODE *PyUnicode_AsUnicodeCopy(PyObject *unicode ) ;
extern PyTypeObject PyLong_Type ;
extern PyObject *PyLong_FromLong(long  ) ;
extern PyObject *PyLong_FromUnsignedLong(unsigned long  ) ;
extern PyObject *PyLong_FromSize_t(size_t  ) ;
extern PyObject *PyLong_FromSsize_t(Py_ssize_t  ) ;
extern PyObject *PyLong_FromDouble(double  ) ;
extern long PyLong_AsLong(PyObject * ) ;
extern long PyLong_AsLongAndOverflow(PyObject * , int * ) ;
extern Py_ssize_t PyLong_AsSsize_t(PyObject * ) ;
extern size_t PyLong_AsSize_t(PyObject * ) ;
extern unsigned long PyLong_AsUnsignedLong(PyObject * ) ;
extern unsigned long PyLong_AsUnsignedLongMask(PyObject * ) ;
extern PyObject *PyLong_GetInfo(void) ;
extern unsigned char _PyLong_DigitValue[256] ;
extern double _PyLong_Frexp(PyLongObject *a , Py_ssize_t *e ) ;
extern double PyLong_AsDouble(PyObject * ) ;
extern PyObject *PyLong_FromVoidPtr(void * ) ;
extern void *PyLong_AsVoidPtr(PyObject * ) ;
extern PyObject *PyLong_FromLongLong(long long  ) ;
extern PyObject *PyLong_FromUnsignedLongLong(unsigned long long  ) ;
extern long long PyLong_AsLongLong(PyObject * ) ;
extern unsigned long long PyLong_AsUnsignedLongLong(PyObject * ) ;
extern unsigned long long PyLong_AsUnsignedLongLongMask(PyObject * ) ;
extern long long PyLong_AsLongLongAndOverflow(PyObject * , int * ) ;
extern PyObject *PyLong_FromString(char * , char ** , int  ) ;
extern PyObject *PyLong_FromUnicode(Py_UNICODE * , Py_ssize_t  , int  ) ;
extern int _PyLong_Sign(PyObject *v ) ;
extern size_t _PyLong_NumBits(PyObject *v ) ;
extern PyObject *_PyLong_DivmodNear(PyObject * , PyObject * ) ;
extern PyObject *_PyLong_FromByteArray(unsigned char const   *bytes , size_t n ,
                                       int little_endian , int is_signed ) ;
extern int _PyLong_AsByteArray(PyLongObject *v , unsigned char *bytes ,
                               size_t n , int little_endian , int is_signed ) ;
extern PyObject *_PyLong_Format(PyObject *aa , int base ) ;
extern PyObject *_PyLong_FormatAdvanced(PyObject *obj ,
                                        Py_UNICODE *format_spec ,
                                        Py_ssize_t format_spec_len ) ;
extern unsigned long PyOS_strtoul(char * , char ** , int  ) ;
extern long PyOS_strtol(char * , char ** , int  ) ;
extern PyLongObject *_PyLong_New(Py_ssize_t  ) ;
extern PyObject *_PyLong_Copy(PyLongObject *src ) ;
extern PyTypeObject PyBool_Type ;
extern struct _longobject _Py_FalseStruct ;
extern struct _longobject _Py_TrueStruct ;
extern PyObject *PyBool_FromLong(long  ) ;
extern PyTypeObject PyFloat_Type ;
extern double PyFloat_GetMax(void) ;
extern double PyFloat_GetMin(void) ;
extern PyObject *PyFloat_GetInfo(void) ;
extern PyObject *PyFloat_FromString(PyObject * ) ;
extern PyObject *PyFloat_FromDouble(double  ) ;
extern double PyFloat_AsDouble(PyObject * ) ;
extern int _PyFloat_Pack4(double x , unsigned char *p , int le ) ;
extern int _PyFloat_Pack8(double x , unsigned char *p , int le ) ;
extern int _PyFloat_Repr(double x , char *p , size_t len ) ;
extern int _PyFloat_Digits(char *buf , double v , int *signum ) ;
extern void _PyFloat_DigitsInit(void) ;
extern double _PyFloat_Unpack4(unsigned char const   *p , int le ) ;
extern double _PyFloat_Unpack8(unsigned char const   *p , int le ) ;
extern int PyFloat_ClearFreeList(void) ;
extern PyObject *_PyFloat_FormatAdvanced(PyObject *obj ,
                                         Py_UNICODE *format_spec ,
                                         Py_ssize_t format_spec_len ) ;
extern Py_complex _Py_c_sum(Py_complex  , Py_complex  ) ;
extern Py_complex _Py_c_diff(Py_complex  , Py_complex  ) ;
extern Py_complex _Py_c_neg(Py_complex  ) ;
extern Py_complex _Py_c_prod(Py_complex  , Py_complex  ) ;
extern Py_complex _Py_c_quot(Py_complex  , Py_complex  ) ;
extern Py_complex _Py_c_pow(Py_complex  , Py_complex  ) ;
extern double _Py_c_abs(Py_complex  ) ;
extern PyTypeObject PyComplex_Type ;
extern PyObject *PyComplex_FromCComplex(Py_complex  ) ;
extern PyObject *PyComplex_FromDoubles(double real , double imag ) ;
extern double PyComplex_RealAsDouble(PyObject *op ) ;
extern double PyComplex_ImagAsDouble(PyObject *op ) ;
extern Py_complex PyComplex_AsCComplex(PyObject *op ) ;
extern PyObject *_PyComplex_FormatAdvanced(PyObject *obj ,
                                           Py_UNICODE *format_spec ,
                                           Py_ssize_t format_spec_len ) ;
extern PyTypeObject PyRange_Type ;
extern PyTypeObject PyRangeIter_Type ;
extern PyTypeObject PyLongRangeIter_Type ;
extern PyTypeObject PyMemoryView_Type ;
extern PyObject *PyMemoryView_GetContiguous(PyObject *base , int buffertype ,
                                            char fort ) ;
extern PyObject *PyMemoryView_FromObject(PyObject *base ) ;
extern PyObject *PyMemoryView_FromBuffer(Py_buffer *info ) ;
extern PyTypeObject PyTuple_Type ;
extern PyTypeObject PyTupleIter_Type ;
extern PyObject *PyTuple_New(Py_ssize_t size ) ;
extern Py_ssize_t PyTuple_Size(PyObject * ) ;
extern PyObject *PyTuple_GetItem(PyObject * , Py_ssize_t  ) ;
extern int PyTuple_SetItem(PyObject * , Py_ssize_t  , PyObject * ) ;
extern PyObject *PyTuple_GetSlice(PyObject * , Py_ssize_t  , Py_ssize_t  ) ;
extern int _PyTuple_Resize(PyObject ** , Py_ssize_t  ) ;
extern PyObject *PyTuple_Pack(Py_ssize_t   , ...) ;
extern void _PyTuple_MaybeUntrack(PyObject * ) ;
extern int PyTuple_ClearFreeList(void) ;
extern PyTypeObject PyList_Type ;
extern PyTypeObject PyListIter_Type ;
extern PyTypeObject PyListRevIter_Type ;
extern PyTypeObject PySortWrapper_Type ;
extern PyObject *PyList_New(Py_ssize_t size ) ;
extern Py_ssize_t PyList_Size(PyObject * ) ;
extern PyObject *PyList_GetItem(PyObject * , Py_ssize_t  ) ;
extern int PyList_SetItem(PyObject * , Py_ssize_t  , PyObject * ) ;
extern int PyList_Insert(PyObject * , Py_ssize_t  , PyObject * ) ;
extern int PyList_Append(PyObject * , PyObject * ) ;
extern PyObject *PyList_GetSlice(PyObject * , Py_ssize_t  , Py_ssize_t  ) ;
extern int PyList_SetSlice(PyObject * , Py_ssize_t  , Py_ssize_t  , PyObject * ) ;
extern int PyList_Sort(PyObject * ) ;
extern int PyList_Reverse(PyObject * ) ;
extern PyObject *PyList_AsTuple(PyObject * ) ;
extern PyObject *_PyList_Extend(PyListObject * , PyObject * ) ;
extern PyTypeObject PyDict_Type ;
extern PyTypeObject PyDictIterKey_Type ;
extern PyTypeObject PyDictIterValue_Type ;
extern PyTypeObject PyDictIterItem_Type ;
extern PyTypeObject PyDictKeys_Type ;
extern PyTypeObject PyDictItems_Type ;
extern PyTypeObject PyDictValues_Type ;
extern PyObject *PyDict_New(void) ;
extern PyObject *PyDict_GetItem(PyObject *mp , PyObject *key ) ;
extern PyObject *PyDict_GetItemWithError(PyObject *mp , PyObject *key ) ;
extern int PyDict_SetItem(PyObject *mp , PyObject *key , PyObject *item ) ;
extern int PyDict_DelItem(PyObject *mp , PyObject *key ) ;
extern void PyDict_Clear(PyObject *mp ) ;
extern int PyDict_Next(PyObject *mp , Py_ssize_t *pos , PyObject **key ,
                       PyObject **value ) ;
extern int _PyDict_Next(PyObject *mp , Py_ssize_t *pos , PyObject **key ,
                        PyObject **value , Py_hash_t *hash ) ;
extern PyObject *PyDict_Keys(PyObject *mp ) ;
extern PyObject *PyDict_Values(PyObject *mp ) ;
extern PyObject *PyDict_Items(PyObject *mp ) ;
extern Py_ssize_t PyDict_Size(PyObject *mp ) ;
extern PyObject *PyDict_Copy(PyObject *mp ) ;
extern int PyDict_Contains(PyObject *mp , PyObject *key ) ;
extern int _PyDict_Contains(PyObject *mp , PyObject *key , Py_hash_t hash ) ;
extern PyObject *_PyDict_NewPresized(Py_ssize_t minused ) ;
extern void _PyDict_MaybeUntrack(PyObject *mp ) ;
extern int _PyDict_HasOnlyStringKeys(PyObject *mp ) ;
extern int PyDict_Update(PyObject *mp , PyObject *other ) ;
extern int PyDict_Merge(PyObject *mp , PyObject *other , int override ) ;
extern int PyDict_MergeFromSeq2(PyObject *d , PyObject *seq2 , int override ) ;
extern PyObject *PyDict_GetItemString(PyObject *dp , char const   *key ) ;
extern int PyDict_SetItemString(PyObject *dp , char const   *key ,
                                PyObject *item ) ;
extern int PyDict_DelItemString(PyObject *dp , char const   *key ) ;
extern PyTypeObject PyEnum_Type ;
extern PyTypeObject PyReversed_Type ;
extern PyTypeObject PySet_Type ;
extern PyTypeObject PyFrozenSet_Type ;
extern PyTypeObject PySetIter_Type ;
extern PyObject *PySet_New(PyObject * ) ;
extern PyObject *PyFrozenSet_New(PyObject * ) ;
extern Py_ssize_t PySet_Size(PyObject *anyset ) ;
extern int PySet_Clear(PyObject *set ) ;
extern int PySet_Contains(PyObject *anyset , PyObject *key ) ;
extern int PySet_Discard(PyObject *set , PyObject *key ) ;
extern int PySet_Add(PyObject *set , PyObject *key ) ;
extern int _PySet_NextEntry(PyObject *set , Py_ssize_t *pos , PyObject **key ,
                            Py_hash_t *hash ) ;
extern PyObject *PySet_Pop(PyObject *set ) ;
extern int _PySet_Update(PyObject *set , PyObject *iterable ) ;
extern PyTypeObject PyCFunction_Type ;
extern PyCFunction PyCFunction_GetFunction(PyObject * ) ;
extern PyObject *PyCFunction_GetSelf(PyObject * ) ;
extern int PyCFunction_GetFlags(PyObject * ) ;
extern PyObject *PyCFunction_Call(PyObject * , PyObject * , PyObject * ) ;
extern PyObject *PyCFunction_NewEx(PyMethodDef * , PyObject * , PyObject * ) ;
extern int PyCFunction_ClearFreeList(void) ;
extern PyTypeObject PyModule_Type ;
extern PyObject *PyModule_NewObject(PyObject *name ) ;
extern PyObject *PyModule_New(char const   *name ) ;
extern PyObject *PyModule_GetDict(PyObject * ) ;
extern PyObject *PyModule_GetNameObject(PyObject * ) ;
extern char const   *PyModule_GetName(PyObject * ) ;
extern char const   *PyModule_GetFilename(PyObject * ) ;
extern PyObject *PyModule_GetFilenameObject(PyObject * ) ;
extern void _PyModule_Clear(PyObject * ) ;
extern struct PyModuleDef *PyModule_GetDef(PyObject * ) ;
extern void *PyModule_GetState(PyObject * ) ;
extern PyTypeObject PyFunction_Type ;
extern PyObject *PyFunction_New(PyObject * , PyObject * ) ;
extern PyObject *PyFunction_GetCode(PyObject * ) ;
extern PyObject *PyFunction_GetGlobals(PyObject * ) ;
extern PyObject *PyFunction_GetModule(PyObject * ) ;
extern PyObject *PyFunction_GetDefaults(PyObject * ) ;
extern int PyFunction_SetDefaults(PyObject * , PyObject * ) ;
extern PyObject *PyFunction_GetKwDefaults(PyObject * ) ;
extern int PyFunction_SetKwDefaults(PyObject * , PyObject * ) ;
extern PyObject *PyFunction_GetClosure(PyObject * ) ;
extern int PyFunction_SetClosure(PyObject * , PyObject * ) ;
extern PyObject *PyFunction_GetAnnotations(PyObject * ) ;
extern int PyFunction_SetAnnotations(PyObject * , PyObject * ) ;
extern PyTypeObject PyClassMethod_Type ;
extern PyTypeObject PyStaticMethod_Type ;
extern PyObject *PyClassMethod_New(PyObject * ) ;
extern PyObject *PyStaticMethod_New(PyObject * ) ;
extern PyTypeObject PyMethod_Type ;
extern PyObject *PyMethod_New(PyObject * , PyObject * ) ;
extern PyObject *PyMethod_Function(PyObject * ) ;
extern PyObject *PyMethod_Self(PyObject * ) ;
extern int PyMethod_ClearFreeList(void) ;
extern PyTypeObject PyInstanceMethod_Type ;
extern PyObject *PyInstanceMethod_New(PyObject * ) ;
extern PyObject *PyInstanceMethod_Function(PyObject * ) ;
extern PyObject *PyFile_FromFd(int  , char * , char * , int  , char * , char * ,
                               char * , int  ) ;
extern PyObject *PyFile_GetLine(PyObject * , int  ) ;
extern int PyFile_WriteObject(PyObject * , PyObject * , int  ) ;
extern int PyFile_WriteString(char const   * , PyObject * ) ;
extern int PyObject_AsFileDescriptor(PyObject * ) ;
extern char *Py_UniversalNewlineFgets(char * , int  , FILE * , PyObject * ) ;
extern char const   *Py_FileSystemDefaultEncoding ;
extern int Py_HasFileSystemDefaultEncoding ;
extern PyObject *PyFile_NewStdPrinter(int  ) ;
extern PyTypeObject PyStdPrinter_Type ;
extern PyTypeObject PyCapsule_Type ;
extern PyObject *PyCapsule_New(void *pointer , char const   *name ,
                               void (*destructor)(PyObject * ) ) ;
extern void *PyCapsule_GetPointer(PyObject *capsule , char const   *name ) ;
extern PyCapsule_Destructor PyCapsule_GetDestructor(PyObject *capsule ) ;
extern char const   *PyCapsule_GetName(PyObject *capsule ) ;
extern void *PyCapsule_GetContext(PyObject *capsule ) ;
extern int PyCapsule_IsValid(PyObject *capsule , char const   *name ) ;
extern int PyCapsule_SetPointer(PyObject *capsule , void *pointer ) ;
extern int PyCapsule_SetDestructor(PyObject *capsule ,
                                   void (*destructor)(PyObject * ) ) ;
extern int PyCapsule_SetName(PyObject *capsule , char const   *name ) ;
extern int PyCapsule_SetContext(PyObject *capsule , void *context ) ;
extern void *PyCapsule_Import(char const   *name , int no_block ) ;
extern PyInterpreterState *PyInterpreterState_New(void) ;
extern void PyInterpreterState_Clear(PyInterpreterState * ) ;
extern void PyInterpreterState_Delete(PyInterpreterState * ) ;
extern int _PyState_AddModule(PyObject * , struct PyModuleDef * ) ;
extern PyObject *PyState_FindModule(struct PyModuleDef * ) ;
extern PyThreadState *PyThreadState_New(PyInterpreterState * ) ;
extern PyThreadState *_PyThreadState_Prealloc(PyInterpreterState * ) ;
extern void _PyThreadState_Init(PyThreadState * ) ;
extern void PyThreadState_Clear(PyThreadState * ) ;
extern void PyThreadState_Delete(PyThreadState * ) ;
extern void PyThreadState_DeleteCurrent(void) ;
extern PyThreadState *PyThreadState_Get(void) ;
extern PyThreadState *PyThreadState_Swap(PyThreadState * ) ;
extern PyObject *PyThreadState_GetDict(void) ;
extern int PyThreadState_SetAsyncExc(long  , PyObject * ) ;
extern _Py_atomic_address _PyThreadState_Current ;
extern PyGILState_STATE PyGILState_Ensure(void) ;
extern void PyGILState_Release(PyGILState_STATE  ) ;
extern PyThreadState *PyGILState_GetThisThreadState(void) ;
extern PyObject *_PyThread_CurrentFrames(void) ;
extern PyInterpreterState *PyInterpreterState_Head(void) ;
extern PyInterpreterState *PyInterpreterState_Next(PyInterpreterState * ) ;
extern PyThreadState *PyInterpreterState_ThreadHead(PyInterpreterState * ) ;
extern PyThreadState *PyThreadState_Next(PyThreadState * ) ;
extern struct _frame *(*_PyThreadState_GetFrame)(PyThreadState *self_ ) ;
extern int PyTraceBack_Here(struct _frame * ) ;
extern int PyTraceBack_Print(PyObject * , PyObject * ) ;
extern int _Py_DisplaySourceLine(PyObject * , PyObject * , int  , int  ) ;
extern PyTypeObject PyTraceBack_Type ;
extern void _Py_DumpTraceback(int fd , PyThreadState *tstate ) ;
extern char const   *_Py_DumpTracebackThreads(int fd ,
                                              PyInterpreterState *interp ,
                                              PyThreadState *current_thread ) ;
extern PyObject _Py_EllipsisObject ;
extern PyTypeObject PySlice_Type ;
extern PyTypeObject PyEllipsis_Type ;
extern PyObject *PySlice_New(PyObject *start , PyObject *stop , PyObject *step ) ;
extern PyObject *_PySlice_FromIndices(Py_ssize_t start , Py_ssize_t stop ) ;
extern int PySlice_GetIndices(PyObject *r , Py_ssize_t length ,
                              Py_ssize_t *start , Py_ssize_t *stop ,
                              Py_ssize_t *step ) ;
extern int PySlice_GetIndicesEx(PyObject *r , Py_ssize_t length ,
                                Py_ssize_t *start , Py_ssize_t *stop ,
                                Py_ssize_t *step , Py_ssize_t *slicelength ) ;
extern PyTypeObject PyCell_Type ;
extern PyObject *PyCell_New(PyObject * ) ;
extern PyObject *PyCell_Get(PyObject * ) ;
extern int PyCell_Set(PyObject * , PyObject * ) ;
extern PyTypeObject PySeqIter_Type ;
extern PyTypeObject PyCallIter_Type ;
extern PyTypeObject PyCmpWrapper_Type ;
extern PyObject *PySeqIter_New(PyObject * ) ;
extern PyObject *PyCallIter_New(PyObject * , PyObject * ) ;
extern PyTypeObject PyGen_Type ;
extern PyObject *PyGen_New(struct _frame * ) ;
extern int PyGen_NeedsFinalizing(PyGenObject * ) ;
extern PyTypeObject PyClassMethodDescr_Type ;
extern PyTypeObject PyGetSetDescr_Type ;
extern PyTypeObject PyMemberDescr_Type ;
extern PyTypeObject PyMethodDescr_Type ;
extern PyTypeObject PyWrapperDescr_Type ;
extern PyTypeObject PyDictProxy_Type ;
extern PyObject *PyDescr_NewMethod(PyTypeObject * , PyMethodDef * ) ;
extern PyObject *PyDescr_NewClassMethod(PyTypeObject * , PyMethodDef * ) ;
extern PyObject *PyDescr_NewMember(PyTypeObject * , struct PyMemberDef * ) ;
extern PyObject *PyDescr_NewGetSet(PyTypeObject * , struct PyGetSetDef * ) ;
extern PyObject *PyDescr_NewWrapper(PyTypeObject * , struct wrapperbase * ,
                                    void * ) ;
extern PyObject *PyDictProxy_New(PyObject * ) ;
extern PyObject *PyWrapper_New(PyObject * , PyObject * ) ;
extern PyTypeObject PyProperty_Type ;
extern PyObject *_PyWarnings_Init(void) ;
extern int PyErr_WarnEx(PyObject *category , char const   *message ,
                        Py_ssize_t stack_level ) ;
extern int PyErr_WarnFormat(PyObject *category , Py_ssize_t stack_level ,
                            char const   *format  , ...) ;
extern int PyErr_WarnExplicit(PyObject *category , char const   *message ,
                              char const   *filename , int lineno ,
                              char const   *module , PyObject *registry ) ;
extern PyTypeObject _PyWeakref_RefType ;
extern PyTypeObject _PyWeakref_ProxyType ;
extern PyTypeObject _PyWeakref_CallableProxyType ;
extern PyObject *PyWeakref_NewRef(PyObject *ob , PyObject *callback ) ;
extern PyObject *PyWeakref_NewProxy(PyObject *ob , PyObject *callback ) ;
extern PyObject *PyWeakref_GetObject(PyObject *ref ) ;
extern Py_ssize_t _PyWeakref_GetWeakrefCount(PyWeakReference *head ) ;
extern void _PyWeakref_ClearRef(PyWeakReference *self ) ;
extern char *PyStructSequence_UnnamedField ;
extern void PyStructSequence_InitType(PyTypeObject *type ,
                                      PyStructSequence_Desc *desc ) ;
extern PyTypeObject *PyStructSequence_NewType(PyStructSequence_Desc *desc ) ;
extern PyObject *PyStructSequence_New(PyTypeObject *type ) ;
extern void PyStructSequence_SetItem(PyObject * , Py_ssize_t  , PyObject * ) ;
extern PyObject *PyStructSequence_GetItem(PyObject * , Py_ssize_t  ) ;
extern int PyCodec_Register(PyObject *search_function ) ;
extern PyObject *_PyCodec_Lookup(char const   *encoding ) ;
extern int PyCodec_KnownEncoding(char const   *encoding ) ;
extern PyObject *PyCodec_Encode(PyObject *object , char const   *encoding ,
                                char const   *errors ) ;
extern PyObject *PyCodec_Decode(PyObject *object , char const   *encoding ,
                                char const   *errors ) ;
extern PyObject *PyCodec_Encoder(char const   *encoding ) ;
extern PyObject *PyCodec_Decoder(char const   *encoding ) ;
extern PyObject *PyCodec_IncrementalEncoder(char const   *encoding ,
                                            char const   *errors ) ;
extern PyObject *PyCodec_IncrementalDecoder(char const   *encoding ,
                                            char const   *errors ) ;
extern PyObject *PyCodec_StreamReader(char const   *encoding ,
                                      PyObject *stream , char const   *errors ) ;
extern PyObject *PyCodec_StreamWriter(char const   *encoding ,
                                      PyObject *stream , char const   *errors ) ;
extern int PyCodec_RegisterError(char const   *name , PyObject *error ) ;
extern PyObject *PyCodec_LookupError(char const   *name ) ;
extern PyObject *PyCodec_StrictErrors(PyObject *exc ) ;
extern PyObject *PyCodec_IgnoreErrors(PyObject *exc ) ;
extern PyObject *PyCodec_ReplaceErrors(PyObject *exc ) ;
extern PyObject *PyCodec_XMLCharRefReplaceErrors(PyObject *exc ) ;
extern PyObject *PyCodec_BackslashReplaceErrors(PyObject *exc ) ;
extern void PyErr_SetNone(PyObject * ) ;
extern void PyErr_SetObject(PyObject * , PyObject * ) ;
extern void PyErr_SetString(PyObject *exception , char const   *string ) ;
extern PyObject *PyErr_Occurred(void) ;
extern void PyErr_Clear(void) ;
extern void PyErr_Fetch(PyObject ** , PyObject ** , PyObject ** ) ;
extern void PyErr_Restore(PyObject * , PyObject * , PyObject * ) ;
extern void Py_FatalError(char const   *message ) ;
extern int PyErr_GivenExceptionMatches(PyObject * , PyObject * ) ;
extern int PyErr_ExceptionMatches(PyObject * ) ;
extern void PyErr_NormalizeException(PyObject ** , PyObject ** , PyObject ** ) ;
extern int PyException_SetTraceback(PyObject * , PyObject * ) ;
extern PyObject *PyException_GetTraceback(PyObject * ) ;
extern PyObject *PyException_GetCause(PyObject * ) ;
extern void PyException_SetCause(PyObject * , PyObject * ) ;
extern PyObject *PyException_GetContext(PyObject * ) ;
extern void PyException_SetContext(PyObject * , PyObject * ) ;
extern PyObject *PyExc_BaseException ;
extern PyObject *PyExc_Exception ;
extern PyObject *PyExc_StopIteration ;
extern PyObject *PyExc_GeneratorExit ;
extern PyObject *PyExc_ArithmeticError ;
extern PyObject *PyExc_LookupError ;
extern PyObject *PyExc_AssertionError ;
extern PyObject *PyExc_AttributeError ;
extern PyObject *PyExc_EOFError ;
extern PyObject *PyExc_FloatingPointError ;
extern PyObject *PyExc_EnvironmentError ;
extern PyObject *PyExc_IOError ;
extern PyObject *PyExc_OSError ;
extern PyObject *PyExc_ImportError ;
extern PyObject *PyExc_IndexError ;
extern PyObject *PyExc_KeyError ;
extern PyObject *PyExc_KeyboardInterrupt ;
extern PyObject *PyExc_MemoryError ;
extern PyObject *PyExc_NameError ;
extern PyObject *PyExc_OverflowError ;
extern PyObject *PyExc_RuntimeError ;
extern PyObject *PyExc_NotImplementedError ;
extern PyObject *PyExc_SyntaxError ;
extern PyObject *PyExc_IndentationError ;
extern PyObject *PyExc_TabError ;
extern PyObject *PyExc_ReferenceError ;
extern PyObject *PyExc_SystemError ;
extern PyObject *PyExc_SystemExit ;
extern PyObject *PyExc_TypeError ;
extern PyObject *PyExc_UnboundLocalError ;
extern PyObject *PyExc_UnicodeError ;
extern PyObject *PyExc_UnicodeEncodeError ;
extern PyObject *PyExc_UnicodeDecodeError ;
extern PyObject *PyExc_UnicodeTranslateError ;
extern PyObject *PyExc_ValueError ;
extern PyObject *PyExc_ZeroDivisionError ;
extern PyObject *PyExc_BufferError ;
extern PyObject *PyExc_RecursionErrorInst ;
extern PyObject *PyExc_Warning ;
extern PyObject *PyExc_UserWarning ;
extern PyObject *PyExc_DeprecationWarning ;
extern PyObject *PyExc_PendingDeprecationWarning ;
extern PyObject *PyExc_SyntaxWarning ;
extern PyObject *PyExc_RuntimeWarning ;
extern PyObject *PyExc_FutureWarning ;
extern PyObject *PyExc_ImportWarning ;
extern PyObject *PyExc_UnicodeWarning ;
extern PyObject *PyExc_BytesWarning ;
extern PyObject *PyExc_ResourceWarning ;
extern int PyErr_BadArgument(void) ;
extern PyObject *PyErr_NoMemory(void) ;
extern PyObject *PyErr_SetFromErrno(PyObject * ) ;
extern PyObject *PyErr_SetFromErrnoWithFilenameObject(PyObject * , PyObject * ) ;
extern PyObject *PyErr_SetFromErrnoWithFilename(PyObject *exc ,
                                                char const   *filename ) ;
extern PyObject *PyErr_Format(PyObject *exception , char const   *format  , ...) ;
extern void PyErr_BadInternalCall(void) ;
extern void _PyErr_BadInternalCall(char const   *filename , int lineno ) ;
extern PyObject *PyErr_NewException(char const   *name , PyObject *base ,
                                    PyObject *dict ) ;
extern PyObject *PyErr_NewExceptionWithDoc(char const   *name ,
                                           char const   *doc , PyObject *base ,
                                           PyObject *dict ) ;
extern void PyErr_WriteUnraisable(PyObject * ) ;
extern int PyErr_CheckSignals(void) ;
extern void PyErr_SetInterrupt(void) ;
extern int PySignal_SetWakeupFd(int fd ) ;
extern void PyErr_SyntaxLocation(char const   *filename , int lineno ) ;
extern void PyErr_SyntaxLocationEx(char const   *filename , int lineno ,
                                   int col_offset ) ;
extern PyObject *PyErr_ProgramText(char const   *filename , int lineno ) ;
extern PyObject *PyUnicodeDecodeError_Create(char const   *encoding ,
                                             char const   *object ,
                                             Py_ssize_t length ,
                                             Py_ssize_t start , Py_ssize_t end ,
                                             char const   *reason ) ;
extern PyObject *PyUnicodeEncodeError_Create(char const   *encoding ,
                                             Py_UNICODE const   *object ,
                                             Py_ssize_t length ,
                                             Py_ssize_t start , Py_ssize_t end ,
                                             char const   *reason ) ;
extern PyObject *PyUnicodeTranslateError_Create(Py_UNICODE const   *object ,
                                                Py_ssize_t length ,
                                                Py_ssize_t start ,
                                                Py_ssize_t end ,
                                                char const   *reason ) ;
extern PyObject *PyUnicodeEncodeError_GetEncoding(PyObject * ) ;
extern PyObject *PyUnicodeDecodeError_GetEncoding(PyObject * ) ;
extern PyObject *PyUnicodeEncodeError_GetObject(PyObject * ) ;
extern PyObject *PyUnicodeDecodeError_GetObject(PyObject * ) ;
extern PyObject *PyUnicodeTranslateError_GetObject(PyObject * ) ;
extern int PyUnicodeEncodeError_GetStart(PyObject * , Py_ssize_t * ) ;
extern int PyUnicodeDecodeError_GetStart(PyObject * , Py_ssize_t * ) ;
extern int PyUnicodeTranslateError_GetStart(PyObject * , Py_ssize_t * ) ;
extern int PyUnicodeEncodeError_SetStart(PyObject * , Py_ssize_t  ) ;
extern int PyUnicodeDecodeError_SetStart(PyObject * , Py_ssize_t  ) ;
extern int PyUnicodeTranslateError_SetStart(PyObject * , Py_ssize_t  ) ;
extern int PyUnicodeEncodeError_GetEnd(PyObject * , Py_ssize_t * ) ;
extern int PyUnicodeDecodeError_GetEnd(PyObject * , Py_ssize_t * ) ;
extern int PyUnicodeTranslateError_GetEnd(PyObject * , Py_ssize_t * ) ;
extern int PyUnicodeEncodeError_SetEnd(PyObject * , Py_ssize_t  ) ;
extern int PyUnicodeDecodeError_SetEnd(PyObject * , Py_ssize_t  ) ;
extern int PyUnicodeTranslateError_SetEnd(PyObject * , Py_ssize_t  ) ;
extern PyObject *PyUnicodeEncodeError_GetReason(PyObject * ) ;
extern PyObject *PyUnicodeDecodeError_GetReason(PyObject * ) ;
extern PyObject *PyUnicodeTranslateError_GetReason(PyObject * ) ;
extern int PyUnicodeEncodeError_SetReason(PyObject *exc , char const   *reason ) ;
extern int PyUnicodeDecodeError_SetReason(PyObject *exc , char const   *reason ) ;
extern int PyUnicodeTranslateError_SetReason(PyObject *exc ,
                                             char const   *reason ) ;
extern int ( /* format attribute */  PyOS_snprintf)(char *str , size_t size ,
                                                    char const   *format  , ...) ;
extern int ( /* format attribute */  PyOS_vsnprintf)(char *str , size_t size ,
                                                     char const   *format ,
                                                     va_list va ) ;
extern PyArena *PyArena_New(void) ;
extern void PyArena_Free(PyArena * ) ;
extern void *PyArena_Malloc(PyArena * , size_t size ) ;
extern int PyArena_AddPyObject(PyArena * , PyObject * ) ;
extern PyObject *_Py_VaBuildValue_SizeT(char const   * , va_list  ) ;
extern int PyArg_Parse(PyObject * , char const   *  , ...) ;
extern int PyArg_ParseTuple(PyObject * , char const   *  , ...) ;
extern int PyArg_ParseTupleAndKeywords(PyObject * , PyObject * ,
                                       char const   * , char **  , ...) ;
extern int PyArg_ValidateKeywordArguments(PyObject * ) ;
extern int PyArg_UnpackTuple(PyObject * , char const   * , Py_ssize_t  ,
                             Py_ssize_t   , ...) ;
extern PyObject *Py_BuildValue(char const   *  , ...) ;
extern PyObject *_Py_BuildValue_SizeT(char const   *  , ...) ;
extern int _PyArg_NoKeywords(char const   *funcname , PyObject *kw ) ;
extern int PyArg_VaParse(PyObject * , char const   * , va_list  ) ;
extern int PyArg_VaParseTupleAndKeywords(PyObject * , PyObject * ,
                                         char const   * , char ** , va_list  ) ;
extern PyObject *Py_VaBuildValue(char const   * , va_list  ) ;
extern int PyModule_AddObject(PyObject * , char const   * , PyObject * ) ;
extern int PyModule_AddIntConstant(PyObject * , char const   * , long  ) ;
extern int PyModule_AddStringConstant(PyObject * , char const   * ,
                                      char const   * ) ;
extern PyObject *PyModule_Create2(struct PyModuleDef * , int apiver ) ;
extern char *_Py_PackageContext ;
extern void Py_SetProgramName(wchar_t * ) ;
extern wchar_t *Py_GetProgramName(void) ;
extern void Py_SetPythonHome(wchar_t * ) ;
extern wchar_t *Py_GetPythonHome(void) ;
extern void Py_Initialize(void) ;
extern void Py_InitializeEx(int  ) ;
extern void Py_Finalize(void) ;
extern int Py_IsInitialized(void) ;
extern PyThreadState *Py_NewInterpreter(void) ;
extern void Py_EndInterpreter(PyThreadState * ) ;
extern int PyRun_SimpleStringFlags(char const   * , PyCompilerFlags * ) ;
extern int PyRun_AnyFileFlags(FILE * , char const   * , PyCompilerFlags * ) ;
extern int PyRun_AnyFileExFlags(FILE *fp , char const   *filename ,
                                int closeit , PyCompilerFlags *flags ) ;
extern int PyRun_SimpleFileExFlags(FILE *fp , char const   *filename ,
                                   int closeit , PyCompilerFlags *flags ) ;
extern int PyRun_InteractiveOneFlags(FILE *fp , char const   *filename ,
                                     PyCompilerFlags *flags ) ;
extern int PyRun_InteractiveLoopFlags(FILE *fp , char const   *filename ,
                                      PyCompilerFlags *flags ) ;
extern struct _mod *PyParser_ASTFromString(char const   *s ,
                                           char const   *filename , int start ,
                                           PyCompilerFlags *flags ,
                                           PyArena *arena ) ;
extern struct _mod *PyParser_ASTFromFile(FILE *fp , char const   *filename ,
                                         char const   *enc , int start ,
                                         char *ps1 , char *ps2 ,
                                         PyCompilerFlags *flags , int *errcode ,
                                         PyArena *arena ) ;
extern struct _node *PyParser_SimpleParseStringFlags(char const   * , int  ,
                                                     int  ) ;
extern struct _node *PyParser_SimpleParseFileFlags(FILE * , char const   * ,
                                                   int  , int  ) ;
extern PyObject *PyRun_StringFlags(char const   * , int  , PyObject * ,
                                   PyObject * , PyCompilerFlags * ) ;
extern PyObject *PyRun_FileExFlags(FILE *fp , char const   *filename ,
                                   int start , PyObject *globals ,
                                   PyObject *locals , int closeit ,
                                   PyCompilerFlags *flags ) ;
extern PyObject *Py_CompileStringExFlags(char const   *str ,
                                         char const   *filename , int start ,
                                         PyCompilerFlags *flags , int optimize ) ;
extern struct symtable *Py_SymtableString(char const   *str ,
                                          char const   *filename , int start ) ;
extern void PyErr_Print(void) ;
extern void PyErr_PrintEx(int  ) ;
extern void PyErr_Display(PyObject * , PyObject * , PyObject * ) ;
extern void _Py_PyAtExit(void (*func)(void) ) ;
extern int Py_AtExit(void (*func)(void) ) ;
extern void Py_Exit(int  ) ;
extern void _Py_RestoreSignals(void) ;
extern int Py_FdIsInteractive(FILE * , char const   * ) ;
extern int Py_Main(int argc , wchar_t **argv ) ;
extern wchar_t *Py_GetProgramFullPath(void) ;
extern wchar_t *Py_GetPrefix(void) ;
extern wchar_t *Py_GetExecPrefix(void) ;
extern wchar_t *Py_GetPath(void) ;
extern void Py_SetPath(wchar_t const   * ) ;
extern char const   *Py_GetVersion(void) ;
extern char const   *Py_GetPlatform(void) ;
extern char const   *Py_GetCopyright(void) ;
extern char const   *Py_GetCompiler(void) ;
extern char const   *Py_GetBuildInfo(void) ;
extern char const   *_Py_hgidentifier(void) ;
extern char const   *_Py_hgversion(void) ;
extern PyObject *_PyBuiltin_Init(void) ;
extern PyObject *_PySys_Init(void) ;
extern void _PyImport_Init(void) ;
extern void _PyExc_Init(void) ;
extern void _PyImportHooks_Init(void) ;
extern int _PyFrame_Init(void) ;
extern void _PyFloat_Init(void) ;
extern int PyByteArray_Init(void) ;
extern void _PyExc_Fini(void) ;
extern void _PyImport_Fini(void) ;
extern void PyMethod_Fini(void) ;
extern void PyFrame_Fini(void) ;
extern void PyCFunction_Fini(void) ;
extern void PyDict_Fini(void) ;
extern void PyTuple_Fini(void) ;
extern void PyList_Fini(void) ;
extern void PySet_Fini(void) ;
extern void PyBytes_Fini(void) ;
extern void PyByteArray_Fini(void) ;
extern void PyFloat_Fini(void) ;
extern void PyOS_FiniInterrupts(void) ;
extern void _PyGC_Fini(void) ;
extern char *PyOS_Readline(FILE * , FILE * , char * ) ;
extern int (*PyOS_InputHook)(void) ;
extern char *(*PyOS_ReadlineFunctionPointer)(FILE * , FILE * , char * ) ;
extern PyThreadState *_PyOS_ReadlineTState ;
extern PyOS_sighandler_t PyOS_getsig(int  ) ;
extern PyOS_sighandler_t PyOS_setsig(int  , void (*)(int  ) ) ;
extern PyObject *PyEval_CallObjectWithKeywords(PyObject * , PyObject * ,
                                               PyObject * ) ;
extern PyObject *PyEval_CallFunction(PyObject *obj , char const   *format  , ...) ;
extern PyObject *PyEval_CallMethod(PyObject *obj , char const   *methodname ,
                                   char const   *format  , ...) ;
extern void PyEval_SetProfile(int (*)(PyObject * , struct _frame * , int  ,
                                      PyObject * ) , PyObject * ) ;
extern void PyEval_SetTrace(int (*)(PyObject * , struct _frame * , int  ,
                                    PyObject * ) , PyObject * ) ;
extern PyObject *PyEval_GetBuiltins(void) ;
extern PyObject *PyEval_GetGlobals(void) ;
extern PyObject *PyEval_GetLocals(void) ;
extern struct _frame *PyEval_GetFrame(void) ;
extern int PyEval_MergeCompilerFlags(PyCompilerFlags *cf ) ;
extern int Py_AddPendingCall(int (*func)(void * ) , void *arg ) ;
extern int Py_MakePendingCalls(void) ;
extern void Py_SetRecursionLimit(int  ) ;
extern int Py_GetRecursionLimit(void) ;
extern int _Py_CheckRecursiveCall(char *where ) ;
extern int _Py_CheckRecursionLimit ;
extern char const   *PyEval_GetFuncName(PyObject * ) ;
extern char const   *PyEval_GetFuncDesc(PyObject * ) ;
extern PyObject *PyEval_GetCallStats(PyObject * ) ;
extern PyObject *PyEval_EvalFrame(struct _frame * ) ;
extern PyObject *PyEval_EvalFrameEx(struct _frame *f , int exc ) ;
extern PyThreadState *PyEval_SaveThread(void) ;
extern void PyEval_RestoreThread(PyThreadState * ) ;
extern int PyEval_ThreadsInitialized(void) ;
extern void PyEval_InitThreads(void) ;
extern void _PyEval_FiniThreads(void) ;
extern void PyEval_AcquireLock(void) ;
extern void PyEval_ReleaseLock(void) ;
extern void PyEval_AcquireThread(PyThreadState *tstate ) ;
extern void PyEval_ReleaseThread(PyThreadState *tstate ) ;
extern void PyEval_ReInitThreads(void) ;
extern void _PyEval_SetSwitchInterval(unsigned long microseconds ) ;
extern unsigned long _PyEval_GetSwitchInterval(void) ;
extern int _PyEval_SliceIndex(PyObject * , Py_ssize_t * ) ;
extern void _PyEval_SignalAsyncExc(void) ;
extern PyObject *PySys_GetObject(char const   * ) ;
extern int PySys_SetObject(char const   * , PyObject * ) ;
extern void PySys_SetArgv(int  , wchar_t ** ) ;
extern void PySys_SetArgvEx(int  , wchar_t ** , int  ) ;
extern void PySys_SetPath(wchar_t const   * ) ;
extern void ( /* format attribute */  PySys_WriteStdout)(char const   *format 
                                                         , ...) ;
extern void ( /* format attribute */  PySys_WriteStderr)(char const   *format 
                                                         , ...) ;
extern void PySys_FormatStdout(char const   *format  , ...) ;
extern void PySys_FormatStderr(char const   *format  , ...) ;
extern PyObject *_PySys_TraceFunc ;
extern PyObject *_PySys_ProfileFunc ;
extern void PySys_ResetWarnOptions(void) ;
extern void PySys_AddWarnOption(wchar_t const   * ) ;
extern void PySys_AddWarnOptionUnicode(PyObject * ) ;
extern int PySys_HasWarnOptions(void) ;
extern void PySys_AddXOption(wchar_t const   * ) ;
extern PyObject *PySys_GetXOptions(void) ;
extern int PyOS_InterruptOccurred(void) ;
extern void PyOS_InitInterrupts(void) ;
extern void PyOS_AfterFork(void) ;
extern long PyImport_GetMagicNumber(void) ;
extern char const   *PyImport_GetMagicTag(void) ;
extern PyObject *PyImport_ExecCodeModule(char *name , PyObject *co ) ;
extern PyObject *PyImport_ExecCodeModuleEx(char *name , PyObject *co ,
                                           char *pathname ) ;
extern PyObject *PyImport_ExecCodeModuleWithPathnames(char *name ,
                                                      PyObject *co ,
                                                      char *pathname ,
                                                      char *cpathname ) ;
extern PyObject *PyImport_ExecCodeModuleObject(PyObject *name , PyObject *co ,
                                               PyObject *pathname ,
                                               PyObject *cpathname ) ;
extern PyObject *PyImport_GetModuleDict(void) ;
extern PyObject *PyImport_AddModuleObject(PyObject *name ) ;
extern PyObject *PyImport_AddModule(char const   *name ) ;
extern PyObject *PyImport_ImportModule(char const   *name ) ;
extern PyObject *PyImport_ImportModuleNoBlock(char const   *name ) ;
extern PyObject *PyImport_ImportModuleLevel(char *name , PyObject *globals ,
                                            PyObject *locals ,
                                            PyObject *fromlist , int level ) ;
extern PyObject *PyImport_ImportModuleLevelObject(PyObject *name ,
                                                  PyObject *globals ,
                                                  PyObject *locals ,
                                                  PyObject *fromlist ,
                                                  int level ) ;
extern PyObject *PyImport_GetImporter(PyObject *path ) ;
extern PyObject *PyImport_Import(PyObject *name ) ;
extern PyObject *PyImport_ReloadModule(PyObject *m ) ;
extern void PyImport_Cleanup(void) ;
extern int PyImport_ImportFrozenModuleObject(PyObject *name ) ;
extern int PyImport_ImportFrozenModule(char *name ) ;
extern void _PyImport_AcquireLock(void) ;
extern int _PyImport_ReleaseLock(void) ;
extern void _PyImport_ReInitLock(void) ;
extern PyObject *_PyImport_FindBuiltin(char const   *name ) ;
extern PyObject *_PyImport_FindExtensionObject(PyObject * , PyObject * ) ;
extern int _PyImport_FixupBuiltin(PyObject *mod , char *name ) ;
extern int _PyImport_FixupExtensionObject(PyObject * , PyObject * , PyObject * ) ;
extern struct _inittab *PyImport_Inittab ;
extern int PyImport_ExtendInittab(struct _inittab *newtab ) ;
extern PyTypeObject PyNullImporter_Type ;
extern int PyImport_AppendInittab(char const   *name ,
                                  PyObject *(*initfunc)(void) ) ;
extern struct _frozen *PyImport_FrozenModules ;
extern PyObject *PyObject_Call(PyObject *callable_object , PyObject *args ,
                               PyObject *kw ) ;
extern PyObject *PyObject_CallObject(PyObject *callable_object , PyObject *args ) ;
extern PyObject *PyObject_CallFunction(PyObject *callable_object , char *format 
                                       , ...) ;
extern PyObject *PyObject_CallMethod(PyObject *o , char *method , char *format 
                                     , ...) ;
extern PyObject *_PyObject_CallFunction_SizeT(PyObject *callable , char *format 
                                              , ...) ;
extern PyObject *_PyObject_CallMethod_SizeT(PyObject *o , char *name ,
                                            char *format  , ...) ;
extern PyObject *PyObject_CallFunctionObjArgs(PyObject *callable  , ...) ;
extern PyObject *PyObject_CallMethodObjArgs(PyObject *o , PyObject *method 
                                            , ...) ;
extern PyObject *PyObject_Type(PyObject *o ) ;
extern Py_ssize_t PyObject_Size(PyObject *o ) ;
extern Py_ssize_t PyObject_Length(PyObject *o ) ;
extern Py_ssize_t _PyObject_LengthHint(PyObject *o , Py_ssize_t  ) ;
extern PyObject *PyObject_GetItem(PyObject *o , PyObject *key ) ;
extern int PyObject_SetItem(PyObject *o , PyObject *key , PyObject *v ) ;
extern int PyObject_DelItemString(PyObject *o , char *key ) ;
extern int PyObject_DelItem(PyObject *o , PyObject *key ) ;
extern int PyObject_AsCharBuffer(PyObject *obj , char const   **buffer ,
                                 Py_ssize_t *buffer_len ) ;
extern int PyObject_CheckReadBuffer(PyObject *obj ) ;
extern int PyObject_AsReadBuffer(PyObject *obj , void const   **buffer ,
                                 Py_ssize_t *buffer_len ) ;
extern int PyObject_AsWriteBuffer(PyObject *obj , void **buffer ,
                                  Py_ssize_t *buffer_len ) ;
extern int PyObject_GetBuffer(PyObject *obj , Py_buffer *view , int flags ) ;
extern void *PyBuffer_GetPointer(Py_buffer *view , Py_ssize_t *indices ) ;
extern int PyBuffer_SizeFromFormat(char const   * ) ;
extern int PyBuffer_ToContiguous(void *buf , Py_buffer *view , Py_ssize_t len ,
                                 char fort ) ;
extern int PyBuffer_FromContiguous(Py_buffer *view , void *buf ,
                                   Py_ssize_t len , char fort ) ;
extern int PyObject_CopyData(PyObject *dest , PyObject *src ) ;
extern int PyBuffer_IsContiguous(Py_buffer *view , char fort ) ;
extern void PyBuffer_FillContiguousStrides(int ndims , Py_ssize_t *shape ,
                                           Py_ssize_t *strides , int itemsize ,
                                           char fort ) ;
extern int PyBuffer_FillInfo(Py_buffer *view , PyObject *o , void *buf ,
                             Py_ssize_t len , int readonly , int flags ) ;
extern void PyBuffer_Release(Py_buffer *view ) ;
extern PyObject *PyObject_Format(PyObject *obj , PyObject *format_spec ) ;
extern PyObject *PyObject_GetIter(PyObject * ) ;
extern PyObject *PyIter_Next(PyObject * ) ;
extern int PyNumber_Check(PyObject *o ) ;
extern PyObject *PyNumber_Add(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Subtract(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Multiply(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_FloorDivide(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_TrueDivide(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Remainder(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Divmod(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Power(PyObject *o1 , PyObject *o2 , PyObject *o3 ) ;
extern PyObject *PyNumber_Negative(PyObject *o ) ;
extern PyObject *PyNumber_Positive(PyObject *o ) ;
extern PyObject *PyNumber_Absolute(PyObject *o ) ;
extern PyObject *PyNumber_Invert(PyObject *o ) ;
extern PyObject *PyNumber_Lshift(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Rshift(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_And(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Xor(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Or(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_Index(PyObject *o ) ;
extern Py_ssize_t PyNumber_AsSsize_t(PyObject *o , PyObject *exc ) ;
extern PyObject *_PyNumber_ConvertIntegralToInt(PyObject *integral ,
                                                char const   *error_format ) ;
extern PyObject *PyNumber_Long(PyObject *o ) ;
extern PyObject *PyNumber_Float(PyObject *o ) ;
extern PyObject *PyNumber_InPlaceAdd(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceSubtract(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceMultiply(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceFloorDivide(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceTrueDivide(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceRemainder(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlacePower(PyObject *o1 , PyObject *o2 ,
                                       PyObject *o3 ) ;
extern PyObject *PyNumber_InPlaceLshift(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceRshift(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceAnd(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceXor(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_InPlaceOr(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PyNumber_ToBase(PyObject *n , int base ) ;
extern int PySequence_Check(PyObject *o ) ;
extern Py_ssize_t PySequence_Size(PyObject *o ) ;
extern Py_ssize_t PySequence_Length(PyObject *o ) ;
extern PyObject *PySequence_Concat(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PySequence_Repeat(PyObject *o , Py_ssize_t count ) ;
extern PyObject *PySequence_GetItem(PyObject *o , Py_ssize_t i ) ;
extern PyObject *PySequence_GetSlice(PyObject *o , Py_ssize_t i1 ,
                                     Py_ssize_t i2 ) ;
extern int PySequence_SetItem(PyObject *o , Py_ssize_t i , PyObject *v ) ;
extern int PySequence_DelItem(PyObject *o , Py_ssize_t i ) ;
extern int PySequence_SetSlice(PyObject *o , Py_ssize_t i1 , Py_ssize_t i2 ,
                               PyObject *v ) ;
extern int PySequence_DelSlice(PyObject *o , Py_ssize_t i1 , Py_ssize_t i2 ) ;
extern PyObject *PySequence_Tuple(PyObject *o ) ;
extern PyObject *PySequence_List(PyObject *o ) ;
extern PyObject *PySequence_Fast(PyObject *o , char const   *m ) ;
extern Py_ssize_t PySequence_Count(PyObject *o , PyObject *value ) ;
extern int PySequence_Contains(PyObject *seq , PyObject *ob ) ;
extern Py_ssize_t _PySequence_IterSearch(PyObject *seq , PyObject *obj ,
                                         int operation ) ;
extern int PySequence_In(PyObject *o , PyObject *value ) ;
extern Py_ssize_t PySequence_Index(PyObject *o , PyObject *value ) ;
extern PyObject *PySequence_InPlaceConcat(PyObject *o1 , PyObject *o2 ) ;
extern PyObject *PySequence_InPlaceRepeat(PyObject *o , Py_ssize_t count ) ;
extern int PyMapping_Check(PyObject *o ) ;
extern Py_ssize_t PyMapping_Size(PyObject *o ) ;
extern Py_ssize_t PyMapping_Length(PyObject *o ) ;
extern int PyMapping_HasKeyString(PyObject *o , char *key ) ;
extern int PyMapping_HasKey(PyObject *o , PyObject *key ) ;
extern PyObject *PyMapping_Keys(PyObject *o ) ;
extern PyObject *PyMapping_Values(PyObject *o ) ;
extern PyObject *PyMapping_Items(PyObject *o ) ;
extern PyObject *PyMapping_GetItemString(PyObject *o , char *key ) ;
extern int PyMapping_SetItemString(PyObject *o , char *key , PyObject *value ) ;
extern int PyObject_IsInstance(PyObject *object , PyObject *typeorclass ) ;
extern int PyObject_IsSubclass(PyObject *object , PyObject *typeorclass ) ;
extern int _PyObject_RealIsInstance(PyObject *inst , PyObject *cls ) ;
extern int _PyObject_RealIsSubclass(PyObject *derived , PyObject *cls ) ;
extern char * const  *_PySequence_BytesToCharpArray(PyObject *self ) ;
extern void _Py_FreeCharPArray(char * const  *array ) ;
extern void _Py_add_one_to_index_F(int nd , Py_ssize_t *index ,
                                   Py_ssize_t const   *shape ) ;
extern void _Py_add_one_to_index_C(int nd , Py_ssize_t *index ,
                                   Py_ssize_t const   *shape ) ;
extern PyTypeObject PyFilter_Type ;
extern PyTypeObject PyMap_Type ;
extern PyTypeObject PyZip_Type ;
extern PyTypeObject PyCode_Type ;
extern PyCodeObject *PyCode_New(int  , int  , int  , int  , int  , PyObject * ,
                                PyObject * , PyObject * , PyObject * ,
                                PyObject * , PyObject * , PyObject * ,
                                PyObject * , int  , PyObject * ) ;
extern PyCodeObject *PyCode_NewEmpty(char const   *filename ,
                                     char const   *funcname , int firstlineno ) ;
extern int PyCode_Addr2Line(PyCodeObject * , int  ) ;
extern int _PyCode_CheckLineNumber(PyCodeObject *co , int lasti ,
                                   PyAddrPair *bounds ) ;
extern PyObject *PyCode_Optimize(PyObject *code , PyObject *consts ,
                                 PyObject *names , PyObject *lineno_obj ) ;
extern PyCodeObject *PyNode_Compile(struct _node * , char const   * ) ;
extern PyCodeObject *PyAST_CompileEx(struct _mod *mod , char const   *filename ,
                                     PyCompilerFlags *flags , int optimize ,
                                     PyArena *arena ) ;
extern PyFutureFeatures *PyFuture_FromAST(struct _mod * , char const   * ) ;
extern PyObject *PyEval_EvalCode(PyObject * , PyObject * , PyObject * ) ;
extern PyObject *PyEval_EvalCodeEx(PyObject *co , PyObject *globals ,
                                   PyObject *locals , PyObject **args ,
                                   int argc , PyObject **kwds , int kwdc ,
                                   PyObject **defs , int defc ,
                                   PyObject *kwdefs , PyObject *closure ) ;
extern PyObject *_PyEval_CallTracing(PyObject *func , PyObject *args ) ;
extern unsigned int const   _Py_ctype_table[256] ;
extern unsigned char const   _Py_ctype_tolower[256] ;
extern unsigned char const   _Py_ctype_toupper[256] ;
extern double PyOS_string_to_double(char const   *str , char **endptr ,
                                    PyObject *overflow_exception ) ;
extern char *PyOS_double_to_string(double val , char format_code ,
                                   int precision , int flags , int *type ) ;
extern double _Py_parse_inf_or_nan(char const   *p , char **endptr ) ;
extern int PyOS_mystrnicmp(char const   * , char const   * , Py_ssize_t  ) ;
extern int PyOS_mystricmp(char const   * , char const   * ) ;
extern double _Py_dg_strtod(char const   *str , char **ptr ) ;
extern char *_Py_dg_dtoa(double d , int mode , int ndigits , int *decpt ,
                         int *sign , char **rve ) ;
extern void _Py_dg_freedtoa(char *s ) ;
extern wchar_t *_Py_char2wchar(char const   *arg , size_t *size ) ;
extern char *_Py_wchar2char(wchar_t const   *text , size_t *error_pos ) ;
extern int _Py_wstat(wchar_t const   *path , struct stat *buf ) ;
extern int _Py_stat(PyObject *path , struct stat *statbuf ) ;
extern FILE *_Py_wfopen(wchar_t const   *path , wchar_t const   *mode ) ;
extern FILE *_Py_fopen(PyObject *path , char const   *mode ) ;
extern int _Py_wreadlink(wchar_t const   *path , wchar_t *buf , size_t bufsiz ) ;
extern wchar_t *_Py_wrealpath(wchar_t const   *path , wchar_t *resolved_path ,
                              size_t resolved_path_size ) ;
extern wchar_t *_Py_wgetcwd(wchar_t *buf , size_t size ) ;
extern PyObject *_Py_Mangle(PyObject *p , PyObject *name ) ;
extern PyObject *PyMember_GetOne(char const   * , struct PyMemberDef * ) ;
extern int PyMember_SetOne(char * , struct PyMemberDef * , PyObject * ) ;
extern int poll(struct pollfd *__fds , nfds_t __nfds , int __timeout ) ;
extern int ppoll(struct pollfd *__fds , nfds_t __nfds ,
                 struct timespec  const  *__timeout , __sigset_t const   *__ss ) ;
static PyObject *SelectError  ;
static void reap_obj(pylist *fd2obj ) 
{ 
  int i ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[390] == 0) {
    {
    fprintf(_coverage_fout, "390\n");
    fflush(_coverage_fout);
    ___coverage_array[390] = 1;
    }
  }
  }
  i = 0;
  {
  if (___coverage_array[391] == 0) {
    {
    fprintf(_coverage_fout, "391\n");
    fflush(_coverage_fout);
    ___coverage_array[391] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[392] == 0) {
      {
      fprintf(_coverage_fout, "392\n");
      fflush(_coverage_fout);
      ___coverage_array[392] = 1;
      }
    }
    }
    if (i < 1025) {
      {
      if (___coverage_array[393] == 0) {
        {
        fprintf(_coverage_fout, "393\n");
        fflush(_coverage_fout);
        ___coverage_array[393] = 1;
        }
      }
      }
      if ((fd2obj + i)->sentinel >= 0) {
        {
        if (___coverage_array[394] == 0) {
          {
          fprintf(_coverage_fout, "394\n");
          fflush(_coverage_fout);
          ___coverage_array[394] = 1;
          }
        }
        }

      } else {
        {
        if (___coverage_array[395] == 0) {
          {
          fprintf(_coverage_fout, "395\n");
          fflush(_coverage_fout);
          ___coverage_array[395] = 1;
          }
        }
        }
        break;
      }
    } else {
      {
      if (___coverage_array[396] == 0) {
        {
        fprintf(_coverage_fout, "396\n");
        fflush(_coverage_fout);
        ___coverage_array[396] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[397] == 0) {
      {
      fprintf(_coverage_fout, "397\n");
      fflush(_coverage_fout);
      ___coverage_array[397] = 1;
      }
    }
    }
    while (1) {
      {
      if (___coverage_array[398] == 0) {
        {
        fprintf(_coverage_fout, "398\n");
        fflush(_coverage_fout);
        ___coverage_array[398] = 1;
        }
      }
      }
      if ((unsigned long )(fd2obj + i)->obj == (unsigned long )((void *)0)) {
        {
        if (___coverage_array[399] == 0) {
          {
          fprintf(_coverage_fout, "399\n");
          fflush(_coverage_fout);
          ___coverage_array[399] = 1;
          }
        }
        }

      } else {
        {
        if (___coverage_array[400] == 0) {
          {
          fprintf(_coverage_fout, "400\n");
          fflush(_coverage_fout);
          ___coverage_array[400] = 1;
          }
        }
        }
        while (1) {
          {
          if (___coverage_array[401] == 0) {
            {
            fprintf(_coverage_fout, "401\n");
            fflush(_coverage_fout);
            ___coverage_array[401] = 1;
            }
          }
          }
          (((fd2obj + i)->obj)->ob_refcnt) --;
          {
          if (___coverage_array[402] == 0) {
            {
            fprintf(_coverage_fout, "402\n");
            fflush(_coverage_fout);
            ___coverage_array[402] = 1;
            }
          }
          }
          if (((fd2obj + i)->obj)->ob_refcnt != 0) {
            {
            if (___coverage_array[403] == 0) {
              {
              fprintf(_coverage_fout, "403\n");
              fflush(_coverage_fout);
              ___coverage_array[403] = 1;
              }
            }
            }

          } else {
            {
            if (___coverage_array[404] == 0) {
              {
              fprintf(_coverage_fout, "404\n");
              fflush(_coverage_fout);
              ___coverage_array[404] = 1;
              }
            }
            }
            (*((((fd2obj + i)->obj)->ob_type)->tp_dealloc))((fd2obj + i)->obj);
          }
          {
          if (___coverage_array[405] == 0) {
            {
            fprintf(_coverage_fout, "405\n");
            fflush(_coverage_fout);
            ___coverage_array[405] = 1;
            }
          }
          }
          break;
        }
      }
      {
      if (___coverage_array[406] == 0) {
        {
        fprintf(_coverage_fout, "406\n");
        fflush(_coverage_fout);
        ___coverage_array[406] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[407] == 0) {
      {
      fprintf(_coverage_fout, "407\n");
      fflush(_coverage_fout);
      ___coverage_array[407] = 1;
      }
    }
    }
    (fd2obj + i)->obj = (PyObject *)((void *)0);
    {
    if (___coverage_array[408] == 0) {
      {
      fprintf(_coverage_fout, "408\n");
      fflush(_coverage_fout);
      ___coverage_array[408] = 1;
      }
    }
    }
    i ++;
  }
  {
  if (___coverage_array[409] == 0) {
    {
    fprintf(_coverage_fout, "409\n");
    fflush(_coverage_fout);
    ___coverage_array[409] = 1;
    }
  }
  }
  (fd2obj + 0)->sentinel = -1;
  {
  if (___coverage_array[410] == 0) {
    {
    fprintf(_coverage_fout, "410\n");
    fflush(_coverage_fout);
    ___coverage_array[410] = 1;
    }
  }
  }
  return;
}
}
static int seq2set(PyObject *seq , fd_set *set , pylist *fd2obj ) 
{ 
  int max ;
  int index___0 ;
  Py_ssize_t i ;
  Py_ssize_t len ;
  PyObject *fast_seq ;
  PyObject *o ;
  int __d0 ;
  int __d1 ;
  int v ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[411] == 0) {
    {
    fprintf(_coverage_fout, "411\n");
    fflush(_coverage_fout);
    ___coverage_array[411] = 1;
    }
  }
  }
  max = -1;
  {
  if (___coverage_array[412] == 0) {
    {
    fprintf(_coverage_fout, "412\n");
    fflush(_coverage_fout);
    ___coverage_array[412] = 1;
    }
  }
  }
  index___0 = 0;
  {
  if (___coverage_array[413] == 0) {
    {
    fprintf(_coverage_fout, "413\n");
    fflush(_coverage_fout);
    ___coverage_array[413] = 1;
    }
  }
  }
  len = -1;
  {
  if (___coverage_array[414] == 0) {
    {
    fprintf(_coverage_fout, "414\n");
    fflush(_coverage_fout);
    ___coverage_array[414] = 1;
    }
  }
  }
  fast_seq = (PyObject *)((void *)0);
  {
  if (___coverage_array[415] == 0) {
    {
    fprintf(_coverage_fout, "415\n");
    fflush(_coverage_fout);
    ___coverage_array[415] = 1;
    }
  }
  }
  o = (PyObject *)((void *)0);
  {
  if (___coverage_array[416] == 0) {
    {
    fprintf(_coverage_fout, "416\n");
    fflush(_coverage_fout);
    ___coverage_array[416] = 1;
    }
  }
  }
  (fd2obj + 0)->obj = (PyObject *)0;
  {
  if (___coverage_array[417] == 0) {
    {
    fprintf(_coverage_fout, "417\n");
    fflush(_coverage_fout);
    ___coverage_array[417] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[418] == 0) {
      {
      fprintf(_coverage_fout, "418\n");
      fflush(_coverage_fout);
      ___coverage_array[418] = 1;
      }
    }
    }
    __asm__  volatile   ("cld; rep; stosl": "=c" (__d0), "=D" (__d1): "a" (0),
                         "0" (sizeof(fd_set ) / sizeof(__fd_mask )),
                         "1" (& set->fds_bits[0]): "memory");
    {
    if (___coverage_array[419] == 0) {
      {
      fprintf(_coverage_fout, "419\n");
      fflush(_coverage_fout);
      ___coverage_array[419] = 1;
      }
    }
    }
    break;
  }
  {
  if (___coverage_array[420] == 0) {
    {
    fprintf(_coverage_fout, "420\n");
    fflush(_coverage_fout);
    ___coverage_array[420] = 1;
    }
  }
  }
  fast_seq = PySequence_Fast(seq, "arguments 1-3 must be sequences");
  {
  if (___coverage_array[421] == 0) {
    {
    fprintf(_coverage_fout, "421\n");
    fflush(_coverage_fout);
    ___coverage_array[421] = 1;
    }
  }
  }
  if (! fast_seq) {
    {
    if (___coverage_array[422] == 0) {
      {
      fprintf(_coverage_fout, "422\n");
      fflush(_coverage_fout);
      ___coverage_array[422] = 1;
      }
    }
    }
    return (-1);
  } else {
    {
    if (___coverage_array[423] == 0) {
      {
      fprintf(_coverage_fout, "423\n");
      fflush(_coverage_fout);
      ___coverage_array[423] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[424] == 0) {
    {
    fprintf(_coverage_fout, "424\n");
    fflush(_coverage_fout);
    ___coverage_array[424] = 1;
    }
  }
  }
  if (((fast_seq->ob_type)->tp_flags & (1L << 25)) != 0L) {
    {
    if (___coverage_array[425] == 0) {
      {
      fprintf(_coverage_fout, "425\n");
      fflush(_coverage_fout);
      ___coverage_array[425] = 1;
      }
    }
    }
    len = ((PyVarObject *)fast_seq)->ob_size;
  } else {
    {
    if (___coverage_array[426] == 0) {
      {
      fprintf(_coverage_fout, "426\n");
      fflush(_coverage_fout);
      ___coverage_array[426] = 1;
      }
    }
    }
    len = ((PyVarObject *)fast_seq)->ob_size;
  }
  {
  if (___coverage_array[427] == 0) {
    {
    fprintf(_coverage_fout, "427\n");
    fflush(_coverage_fout);
    ___coverage_array[427] = 1;
    }
  }
  }
  i = 0;
  {
  if (___coverage_array[428] == 0) {
    {
    fprintf(_coverage_fout, "428\n");
    fflush(_coverage_fout);
    ___coverage_array[428] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[429] == 0) {
      {
      fprintf(_coverage_fout, "429\n");
      fflush(_coverage_fout);
      ___coverage_array[429] = 1;
      }
    }
    }
    if (i < len) {
      {
      if (___coverage_array[430] == 0) {
        {
        fprintf(_coverage_fout, "430\n");
        fflush(_coverage_fout);
        ___coverage_array[430] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[431] == 0) {
        {
        fprintf(_coverage_fout, "431\n");
        fflush(_coverage_fout);
        ___coverage_array[431] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[432] == 0) {
      {
      fprintf(_coverage_fout, "432\n");
      fflush(_coverage_fout);
      ___coverage_array[432] = 1;
      }
    }
    }
    if (((fast_seq->ob_type)->tp_flags & (1L << 25)) != 0L) {
      {
      if (___coverage_array[433] == 0) {
        {
        fprintf(_coverage_fout, "433\n");
        fflush(_coverage_fout);
        ___coverage_array[433] = 1;
        }
      }
      }
      o = *(((PyListObject *)fast_seq)->ob_item + i);
    } else {
      {
      if (___coverage_array[434] == 0) {
        {
        fprintf(_coverage_fout, "434\n");
        fflush(_coverage_fout);
        ___coverage_array[434] = 1;
        }
      }
      }
      o = ((PyTupleObject *)fast_seq)->ob_item[i];
    }
    {
    if (___coverage_array[435] == 0) {
      {
      fprintf(_coverage_fout, "435\n");
      fflush(_coverage_fout);
      ___coverage_array[435] = 1;
      }
    }
    }
    if (o) {
      {
      if (___coverage_array[436] == 0) {
        {
        fprintf(_coverage_fout, "436\n");
        fflush(_coverage_fout);
        ___coverage_array[436] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[437] == 0) {
        {
        fprintf(_coverage_fout, "437\n");
        fflush(_coverage_fout);
        ___coverage_array[437] = 1;
        }
      }
      }
      return (-1);
    }
    {
    if (___coverage_array[438] == 0) {
      {
      fprintf(_coverage_fout, "438\n");
      fflush(_coverage_fout);
      ___coverage_array[438] = 1;
      }
    }
    }
    (o->ob_refcnt) ++;
    {
    if (___coverage_array[439] == 0) {
      {
      fprintf(_coverage_fout, "439\n");
      fflush(_coverage_fout);
      ___coverage_array[439] = 1;
      }
    }
    }
    v = PyObject_AsFileDescriptor(o);
    {
    if (___coverage_array[440] == 0) {
      {
      fprintf(_coverage_fout, "440\n");
      fflush(_coverage_fout);
      ___coverage_array[440] = 1;
      }
    }
    }
    if (v == -1) {
      {
      if (___coverage_array[441] == 0) {
        {
        fprintf(_coverage_fout, "441\n");
        fflush(_coverage_fout);
        ___coverage_array[441] = 1;
        }
      }
      }
      goto finally;
    } else {
      {
      if (___coverage_array[442] == 0) {
        {
        fprintf(_coverage_fout, "442\n");
        fflush(_coverage_fout);
        ___coverage_array[442] = 1;
        }
      }
      }

    }
    {
    if (___coverage_array[443] == 0) {
      {
      fprintf(_coverage_fout, "443\n");
      fflush(_coverage_fout);
      ___coverage_array[443] = 1;
      }
    }
    }
    if (v < 0) {
      {
      if (___coverage_array[444] == 0) {
        {
        fprintf(_coverage_fout, "444\n");
        fflush(_coverage_fout);
        ___coverage_array[444] = 1;
        }
      }
      }
      PyErr_SetString(PyExc_ValueError,
                      "filedescriptor out of range in select()");
      {
      if (___coverage_array[445] == 0) {
        {
        fprintf(_coverage_fout, "445\n");
        fflush(_coverage_fout);
        ___coverage_array[445] = 1;
        }
      }
      }
      goto finally;
    } else {
      {
      if (___coverage_array[446] == 0) {
        {
        fprintf(_coverage_fout, "446\n");
        fflush(_coverage_fout);
        ___coverage_array[446] = 1;
        }
      }
      }
      if (v >= 1024) {
        {
        if (___coverage_array[447] == 0) {
          {
          fprintf(_coverage_fout, "447\n");
          fflush(_coverage_fout);
          ___coverage_array[447] = 1;
          }
        }
        }
        PyErr_SetString(PyExc_ValueError,
                        "filedescriptor out of range in select()");
        {
        if (___coverage_array[448] == 0) {
          {
          fprintf(_coverage_fout, "448\n");
          fflush(_coverage_fout);
          ___coverage_array[448] = 1;
          }
        }
        }
        goto finally;
      } else {
        {
        if (___coverage_array[449] == 0) {
          {
          fprintf(_coverage_fout, "449\n");
          fflush(_coverage_fout);
          ___coverage_array[449] = 1;
          }
        }
        }

      }
    }
    {
    if (___coverage_array[450] == 0) {
      {
      fprintf(_coverage_fout, "450\n");
      fflush(_coverage_fout);
      ___coverage_array[450] = 1;
      }
    }
    }
    if (v > max) {
      {
      if (___coverage_array[451] == 0) {
        {
        fprintf(_coverage_fout, "451\n");
        fflush(_coverage_fout);
        ___coverage_array[451] = 1;
        }
      }
      }
      max = v;
    } else {
      {
      if (___coverage_array[452] == 0) {
        {
        fprintf(_coverage_fout, "452\n");
        fflush(_coverage_fout);
        ___coverage_array[452] = 1;
        }
      }
      }

    }
    {
    if (___coverage_array[453] == 0) {
      {
      fprintf(_coverage_fout, "453\n");
      fflush(_coverage_fout);
      ___coverage_array[453] = 1;
      }
    }
    }
    __asm__  volatile   ("btsl %1,%0": "=m" (set->fds_bits[v / (8 * (int )sizeof(__fd_mask ))]): "r" (v % (8 * (int )sizeof(__fd_mask ))): "cc",
                         "memory");
    {
    if (___coverage_array[454] == 0) {
      {
      fprintf(_coverage_fout, "454\n");
      fflush(_coverage_fout);
      ___coverage_array[454] = 1;
      }
    }
    }
    if (index___0 >= 1024) {
      {
      if (___coverage_array[455] == 0) {
        {
        fprintf(_coverage_fout, "455\n");
        fflush(_coverage_fout);
        ___coverage_array[455] = 1;
        }
      }
      }
      PyErr_SetString(PyExc_ValueError, "too many file descriptors in select()");
      {
      if (___coverage_array[456] == 0) {
        {
        fprintf(_coverage_fout, "456\n");
        fflush(_coverage_fout);
        ___coverage_array[456] = 1;
        }
      }
      }
      goto finally;
    } else {
      {
      if (___coverage_array[457] == 0) {
        {
        fprintf(_coverage_fout, "457\n");
        fflush(_coverage_fout);
        ___coverage_array[457] = 1;
        }
      }
      }

    }
    {
    if (___coverage_array[458] == 0) {
      {
      fprintf(_coverage_fout, "458\n");
      fflush(_coverage_fout);
      ___coverage_array[458] = 1;
      }
    }
    }
    (fd2obj + index___0)->obj = o;
    {
    if (___coverage_array[459] == 0) {
      {
      fprintf(_coverage_fout, "459\n");
      fflush(_coverage_fout);
      ___coverage_array[459] = 1;
      }
    }
    }
    (fd2obj + index___0)->fd = v;
    {
    if (___coverage_array[460] == 0) {
      {
      fprintf(_coverage_fout, "460\n");
      fflush(_coverage_fout);
      ___coverage_array[460] = 1;
      }
    }
    }
    (fd2obj + index___0)->sentinel = 0;
    {
    if (___coverage_array[461] == 0) {
      {
      fprintf(_coverage_fout, "461\n");
      fflush(_coverage_fout);
      ___coverage_array[461] = 1;
      }
    }
    }
    index___0 ++;
    {
    if (___coverage_array[462] == 0) {
      {
      fprintf(_coverage_fout, "462\n");
      fflush(_coverage_fout);
      ___coverage_array[462] = 1;
      }
    }
    }
    (fd2obj + index___0)->sentinel = -1;
    {
    if (___coverage_array[463] == 0) {
      {
      fprintf(_coverage_fout, "463\n");
      fflush(_coverage_fout);
      ___coverage_array[463] = 1;
      }
    }
    }
    i ++;
  }
  {
  if (___coverage_array[464] == 0) {
    {
    fprintf(_coverage_fout, "464\n");
    fflush(_coverage_fout);
    ___coverage_array[464] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[465] == 0) {
      {
      fprintf(_coverage_fout, "465\n");
      fflush(_coverage_fout);
      ___coverage_array[465] = 1;
      }
    }
    }
    (fast_seq->ob_refcnt) --;
    {
    if (___coverage_array[466] == 0) {
      {
      fprintf(_coverage_fout, "466\n");
      fflush(_coverage_fout);
      ___coverage_array[466] = 1;
      }
    }
    }
    if (fast_seq->ob_refcnt != 0) {
      {
      if (___coverage_array[467] == 0) {
        {
        fprintf(_coverage_fout, "467\n");
        fflush(_coverage_fout);
        ___coverage_array[467] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[468] == 0) {
        {
        fprintf(_coverage_fout, "468\n");
        fflush(_coverage_fout);
        ___coverage_array[468] = 1;
        }
      }
      }
      (*((fast_seq->ob_type)->tp_dealloc))(fast_seq);
    }
    {
    if (___coverage_array[469] == 0) {
      {
      fprintf(_coverage_fout, "469\n");
      fflush(_coverage_fout);
      ___coverage_array[469] = 1;
      }
    }
    }
    break;
  }
  {
  if (___coverage_array[470] == 0) {
    {
    fprintf(_coverage_fout, "470\n");
    fflush(_coverage_fout);
    ___coverage_array[470] = 1;
    }
  }
  }
  return (max + 1);
  {
  if (___coverage_array[471] == 0) {
    {
    fprintf(_coverage_fout, "471\n");
    fflush(_coverage_fout);
    ___coverage_array[471] = 1;
    }
  }
  }
  finally: 
  while (1) {
    {
    if (___coverage_array[472] == 0) {
      {
      fprintf(_coverage_fout, "472\n");
      fflush(_coverage_fout);
      ___coverage_array[472] = 1;
      }
    }
    }
    if ((unsigned long )o == (unsigned long )((void *)0)) {
      {
      if (___coverage_array[473] == 0) {
        {
        fprintf(_coverage_fout, "473\n");
        fflush(_coverage_fout);
        ___coverage_array[473] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[474] == 0) {
        {
        fprintf(_coverage_fout, "474\n");
        fflush(_coverage_fout);
        ___coverage_array[474] = 1;
        }
      }
      }
      while (1) {
        {
        if (___coverage_array[475] == 0) {
          {
          fprintf(_coverage_fout, "475\n");
          fflush(_coverage_fout);
          ___coverage_array[475] = 1;
          }
        }
        }
        (o->ob_refcnt) --;
        {
        if (___coverage_array[476] == 0) {
          {
          fprintf(_coverage_fout, "476\n");
          fflush(_coverage_fout);
          ___coverage_array[476] = 1;
          }
        }
        }
        if (o->ob_refcnt != 0) {
          {
          if (___coverage_array[477] == 0) {
            {
            fprintf(_coverage_fout, "477\n");
            fflush(_coverage_fout);
            ___coverage_array[477] = 1;
            }
          }
          }

        } else {
          {
          if (___coverage_array[478] == 0) {
            {
            fprintf(_coverage_fout, "478\n");
            fflush(_coverage_fout);
            ___coverage_array[478] = 1;
            }
          }
          }
          (*((o->ob_type)->tp_dealloc))(o);
        }
        {
        if (___coverage_array[479] == 0) {
          {
          fprintf(_coverage_fout, "479\n");
          fflush(_coverage_fout);
          ___coverage_array[479] = 1;
          }
        }
        }
        break;
      }
    }
    {
    if (___coverage_array[480] == 0) {
      {
      fprintf(_coverage_fout, "480\n");
      fflush(_coverage_fout);
      ___coverage_array[480] = 1;
      }
    }
    }
    break;
  }
  {
  if (___coverage_array[481] == 0) {
    {
    fprintf(_coverage_fout, "481\n");
    fflush(_coverage_fout);
    ___coverage_array[481] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[482] == 0) {
      {
      fprintf(_coverage_fout, "482\n");
      fflush(_coverage_fout);
      ___coverage_array[482] = 1;
      }
    }
    }
    (fast_seq->ob_refcnt) --;
    {
    if (___coverage_array[483] == 0) {
      {
      fprintf(_coverage_fout, "483\n");
      fflush(_coverage_fout);
      ___coverage_array[483] = 1;
      }
    }
    }
    if (fast_seq->ob_refcnt != 0) {
      {
      if (___coverage_array[484] == 0) {
        {
        fprintf(_coverage_fout, "484\n");
        fflush(_coverage_fout);
        ___coverage_array[484] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[485] == 0) {
        {
        fprintf(_coverage_fout, "485\n");
        fflush(_coverage_fout);
        ___coverage_array[485] = 1;
        }
      }
      }
      (*((fast_seq->ob_type)->tp_dealloc))(fast_seq);
    }
    {
    if (___coverage_array[486] == 0) {
      {
      fprintf(_coverage_fout, "486\n");
      fflush(_coverage_fout);
      ___coverage_array[486] = 1;
      }
    }
    }
    break;
  }
  {
  if (___coverage_array[487] == 0) {
    {
    fprintf(_coverage_fout, "487\n");
    fflush(_coverage_fout);
    ___coverage_array[487] = 1;
    }
  }
  }
  return (-1);
}
}
static PyObject *set2list(fd_set *set , pylist *fd2obj ) 
{ 
  int i ;
  int j ;
  int count ;
  PyObject *list ;
  PyObject *o ;
  int fd ;
  register char __result ;
  int tmp ;
  register char __result___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[488] == 0) {
    {
    fprintf(_coverage_fout, "488\n");
    fflush(_coverage_fout);
    ___coverage_array[488] = 1;
    }
  }
  }
  count = 0;
  {
  if (___coverage_array[489] == 0) {
    {
    fprintf(_coverage_fout, "489\n");
    fflush(_coverage_fout);
    ___coverage_array[489] = 1;
    }
  }
  }
  j = 0;
  {
  if (___coverage_array[490] == 0) {
    {
    fprintf(_coverage_fout, "490\n");
    fflush(_coverage_fout);
    ___coverage_array[490] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[491] == 0) {
      {
      fprintf(_coverage_fout, "491\n");
      fflush(_coverage_fout);
      ___coverage_array[491] = 1;
      }
    }
    }
    if ((fd2obj + j)->sentinel >= 0) {
      {
      if (___coverage_array[492] == 0) {
        {
        fprintf(_coverage_fout, "492\n");
        fflush(_coverage_fout);
        ___coverage_array[492] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[493] == 0) {
        {
        fprintf(_coverage_fout, "493\n");
        fflush(_coverage_fout);
        ___coverage_array[493] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[494] == 0) {
      {
      fprintf(_coverage_fout, "494\n");
      fflush(_coverage_fout);
      ___coverage_array[494] = 1;
      }
    }
    }
    __asm__  volatile   ("btl %1,%2 ; setcb %b0": "=q" (__result): "r" ((fd2obj + j)->fd % (8 * (int )sizeof(__fd_mask ))),
                         "m" (set->fds_bits[(fd2obj + j)->fd / (8 * (int )sizeof(__fd_mask ))]): "cc");
    {
    if (___coverage_array[495] == 0) {
      {
      fprintf(_coverage_fout, "495\n");
      fflush(_coverage_fout);
      ___coverage_array[495] = 1;
      }
    }
    }
    if (__result) {
      {
      if (___coverage_array[496] == 0) {
        {
        fprintf(_coverage_fout, "496\n");
        fflush(_coverage_fout);
        ___coverage_array[496] = 1;
        }
      }
      }
      count ++;
    } else {
      {
      if (___coverage_array[497] == 0) {
        {
        fprintf(_coverage_fout, "497\n");
        fflush(_coverage_fout);
        ___coverage_array[497] = 1;
        }
      }
      }

    }
    {
    if (___coverage_array[498] == 0) {
      {
      fprintf(_coverage_fout, "498\n");
      fflush(_coverage_fout);
      ___coverage_array[498] = 1;
      }
    }
    }
    j ++;
  }
  {
  if (___coverage_array[499] == 0) {
    {
    fprintf(_coverage_fout, "499\n");
    fflush(_coverage_fout);
    ___coverage_array[499] = 1;
    }
  }
  }
  list = PyList_New(count);
  {
  if (___coverage_array[500] == 0) {
    {
    fprintf(_coverage_fout, "500\n");
    fflush(_coverage_fout);
    ___coverage_array[500] = 1;
    }
  }
  }
  if (! list) {
    {
    if (___coverage_array[501] == 0) {
      {
      fprintf(_coverage_fout, "501\n");
      fflush(_coverage_fout);
      ___coverage_array[501] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[502] == 0) {
      {
      fprintf(_coverage_fout, "502\n");
      fflush(_coverage_fout);
      ___coverage_array[502] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[503] == 0) {
    {
    fprintf(_coverage_fout, "503\n");
    fflush(_coverage_fout);
    ___coverage_array[503] = 1;
    }
  }
  }
  i = 0;
  {
  if (___coverage_array[504] == 0) {
    {
    fprintf(_coverage_fout, "504\n");
    fflush(_coverage_fout);
    ___coverage_array[504] = 1;
    }
  }
  }
  j = 0;
  {
  if (___coverage_array[505] == 0) {
    {
    fprintf(_coverage_fout, "505\n");
    fflush(_coverage_fout);
    ___coverage_array[505] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[506] == 0) {
      {
      fprintf(_coverage_fout, "506\n");
      fflush(_coverage_fout);
      ___coverage_array[506] = 1;
      }
    }
    }
    if ((fd2obj + j)->sentinel >= 0) {
      {
      if (___coverage_array[507] == 0) {
        {
        fprintf(_coverage_fout, "507\n");
        fflush(_coverage_fout);
        ___coverage_array[507] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[508] == 0) {
        {
        fprintf(_coverage_fout, "508\n");
        fflush(_coverage_fout);
        ___coverage_array[508] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[509] == 0) {
      {
      fprintf(_coverage_fout, "509\n");
      fflush(_coverage_fout);
      ___coverage_array[509] = 1;
      }
    }
    }
    fd = (fd2obj + j)->fd;
    {
    if (___coverage_array[510] == 0) {
      {
      fprintf(_coverage_fout, "510\n");
      fflush(_coverage_fout);
      ___coverage_array[510] = 1;
      }
    }
    }
    __asm__  volatile   ("btl %1,%2 ; setcb %b0": "=q" (__result___0): "r" (fd % (8 * (int )sizeof(__fd_mask ))),
                         "m" (set->fds_bits[fd / (8 * (int )sizeof(__fd_mask ))]): "cc");
    {
    if (___coverage_array[511] == 0) {
      {
      fprintf(_coverage_fout, "511\n");
      fflush(_coverage_fout);
      ___coverage_array[511] = 1;
      }
    }
    }
    if (__result___0) {
      {
      if (___coverage_array[512] == 0) {
        {
        fprintf(_coverage_fout, "512\n");
        fflush(_coverage_fout);
        ___coverage_array[512] = 1;
        }
      }
      }
      if (fd > 1024) {
        {
        if (___coverage_array[513] == 0) {
          {
          fprintf(_coverage_fout, "513\n");
          fflush(_coverage_fout);
          ___coverage_array[513] = 1;
          }
        }
        }
        PyErr_SetString(PyExc_SystemError,
                        "filedescriptor out of range returned in select()");
        {
        if (___coverage_array[514] == 0) {
          {
          fprintf(_coverage_fout, "514\n");
          fflush(_coverage_fout);
          ___coverage_array[514] = 1;
          }
        }
        }
        goto finally;
      } else {
        {
        if (___coverage_array[515] == 0) {
          {
          fprintf(_coverage_fout, "515\n");
          fflush(_coverage_fout);
          ___coverage_array[515] = 1;
          }
        }
        }

      }
      {
      if (___coverage_array[516] == 0) {
        {
        fprintf(_coverage_fout, "516\n");
        fflush(_coverage_fout);
        ___coverage_array[516] = 1;
        }
      }
      }
      o = (fd2obj + j)->obj;
      {
      if (___coverage_array[517] == 0) {
        {
        fprintf(_coverage_fout, "517\n");
        fflush(_coverage_fout);
        ___coverage_array[517] = 1;
        }
      }
      }
      (fd2obj + j)->obj = (PyObject *)((void *)0);
      {
      if (___coverage_array[518] == 0) {
        {
        fprintf(_coverage_fout, "518\n");
        fflush(_coverage_fout);
        ___coverage_array[518] = 1;
        }
      }
      }
      tmp = PyList_SetItem(list, i, o);
      {
      if (___coverage_array[519] == 0) {
        {
        fprintf(_coverage_fout, "519\n");
        fflush(_coverage_fout);
        ___coverage_array[519] = 1;
        }
      }
      }
      if (tmp < 0) {
        {
        if (___coverage_array[520] == 0) {
          {
          fprintf(_coverage_fout, "520\n");
          fflush(_coverage_fout);
          ___coverage_array[520] = 1;
          }
        }
        }
        goto finally;
      } else {
        {
        if (___coverage_array[521] == 0) {
          {
          fprintf(_coverage_fout, "521\n");
          fflush(_coverage_fout);
          ___coverage_array[521] = 1;
          }
        }
        }

      }
      {
      if (___coverage_array[522] == 0) {
        {
        fprintf(_coverage_fout, "522\n");
        fflush(_coverage_fout);
        ___coverage_array[522] = 1;
        }
      }
      }
      i ++;
    } else {
      {
      if (___coverage_array[523] == 0) {
        {
        fprintf(_coverage_fout, "523\n");
        fflush(_coverage_fout);
        ___coverage_array[523] = 1;
        }
      }
      }

    }
    {
    if (___coverage_array[524] == 0) {
      {
      fprintf(_coverage_fout, "524\n");
      fflush(_coverage_fout);
      ___coverage_array[524] = 1;
      }
    }
    }
    j ++;
  }
  {
  if (___coverage_array[525] == 0) {
    {
    fprintf(_coverage_fout, "525\n");
    fflush(_coverage_fout);
    ___coverage_array[525] = 1;
    }
  }
  }
  return (list);
  {
  if (___coverage_array[526] == 0) {
    {
    fprintf(_coverage_fout, "526\n");
    fflush(_coverage_fout);
    ___coverage_array[526] = 1;
    }
  }
  }
  finally: 
  while (1) {
    {
    if (___coverage_array[527] == 0) {
      {
      fprintf(_coverage_fout, "527\n");
      fflush(_coverage_fout);
      ___coverage_array[527] = 1;
      }
    }
    }
    (list->ob_refcnt) --;
    {
    if (___coverage_array[528] == 0) {
      {
      fprintf(_coverage_fout, "528\n");
      fflush(_coverage_fout);
      ___coverage_array[528] = 1;
      }
    }
    }
    if (list->ob_refcnt != 0) {
      {
      if (___coverage_array[529] == 0) {
        {
        fprintf(_coverage_fout, "529\n");
        fflush(_coverage_fout);
        ___coverage_array[529] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[530] == 0) {
        {
        fprintf(_coverage_fout, "530\n");
        fflush(_coverage_fout);
        ___coverage_array[530] = 1;
        }
      }
      }
      (*((list->ob_type)->tp_dealloc))(list);
    }
    {
    if (___coverage_array[531] == 0) {
      {
      fprintf(_coverage_fout, "531\n");
      fflush(_coverage_fout);
      ___coverage_array[531] = 1;
      }
    }
    }
    break;
  }
  {
  if (___coverage_array[532] == 0) {
    {
    fprintf(_coverage_fout, "532\n");
    fflush(_coverage_fout);
    ___coverage_array[532] = 1;
    }
  }
  }
  return ((PyObject *)((void *)0));
}
}
static PyObject *select_select(PyObject *self , PyObject *args ) 
{ 
  pylist rfd2obj[1025] ;
  pylist wfd2obj[1025] ;
  pylist efd2obj[1025] ;
  PyObject *ifdlist ;
  PyObject *ofdlist ;
  PyObject *efdlist ;
  PyObject *ret ;
  PyObject *tout ;
  fd_set ifdset ;
  fd_set ofdset ;
  fd_set efdset ;
  double timeout ;
  struct timeval tv ;
  struct timeval *tvp ;
  long seconds ;
  int imax ;
  int omax ;
  int emax ;
  int max ;
  int n ;
  int tmp ;
  PyObject *tmp___0 ;
  int tmp___1 ;
  PyThreadState *_save ;
  PyObject *tmp___2 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[533] == 0) {
    {
    fprintf(_coverage_fout, "533\n");
    fflush(_coverage_fout);
    ___coverage_array[533] = 1;
    }
  }
  }
  ret = (PyObject *)((void *)0);
  {
  if (___coverage_array[534] == 0) {
    {
    fprintf(_coverage_fout, "534\n");
    fflush(_coverage_fout);
    ___coverage_array[534] = 1;
    }
  }
  }
  tout = & _Py_NoneStruct;
  {
  if (___coverage_array[535] == 0) {
    {
    fprintf(_coverage_fout, "535\n");
    fflush(_coverage_fout);
    ___coverage_array[535] = 1;
    }
  }
  }
  tmp = PyArg_UnpackTuple(args, "select", 3, 4, & ifdlist, & ofdlist, & efdlist,
                          & tout);
  {
  if (___coverage_array[536] == 0) {
    {
    fprintf(_coverage_fout, "536\n");
    fflush(_coverage_fout);
    ___coverage_array[536] = 1;
    }
  }
  }
  if (tmp) {
    {
    if (___coverage_array[537] == 0) {
      {
      fprintf(_coverage_fout, "537\n");
      fflush(_coverage_fout);
      ___coverage_array[537] = 1;
      }
    }
    }

  } else {
    {
    if (___coverage_array[538] == 0) {
      {
      fprintf(_coverage_fout, "538\n");
      fflush(_coverage_fout);
      ___coverage_array[538] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  }
  {
  if (___coverage_array[539] == 0) {
    {
    fprintf(_coverage_fout, "539\n");
    fflush(_coverage_fout);
    ___coverage_array[539] = 1;
    }
  }
  }
  if ((unsigned long )tout == (unsigned long )(& _Py_NoneStruct)) {
    {
    if (___coverage_array[540] == 0) {
      {
      fprintf(_coverage_fout, "540\n");
      fflush(_coverage_fout);
      ___coverage_array[540] = 1;
      }
    }
    }
    tvp = (struct timeval *)0;
  } else {
    {
    if (___coverage_array[541] == 0) {
      {
      fprintf(_coverage_fout, "541\n");
      fflush(_coverage_fout);
      ___coverage_array[541] = 1;
      }
    }
    }
    tmp___1 = PyNumber_Check(tout);
    {
    if (___coverage_array[542] == 0) {
      {
      fprintf(_coverage_fout, "542\n");
      fflush(_coverage_fout);
      ___coverage_array[542] = 1;
      }
    }
    }
    if (tmp___1) {
      {
      if (___coverage_array[543] == 0) {
        {
        fprintf(_coverage_fout, "543\n");
        fflush(_coverage_fout);
        ___coverage_array[543] = 1;
        }
      }
      }
      timeout = PyFloat_AsDouble(tout);
      {
      if (___coverage_array[544] == 0) {
        {
        fprintf(_coverage_fout, "544\n");
        fflush(_coverage_fout);
        ___coverage_array[544] = 1;
        }
      }
      }
      if (timeout == (double )-1) {
        {
        if (___coverage_array[545] == 0) {
          {
          fprintf(_coverage_fout, "545\n");
          fflush(_coverage_fout);
          ___coverage_array[545] = 1;
          }
        }
        }
        tmp___0 = PyErr_Occurred();
        {
        if (___coverage_array[546] == 0) {
          {
          fprintf(_coverage_fout, "546\n");
          fflush(_coverage_fout);
          ___coverage_array[546] = 1;
          }
        }
        }
        if (tmp___0) {
          {
          if (___coverage_array[547] == 0) {
            {
            fprintf(_coverage_fout, "547\n");
            fflush(_coverage_fout);
            ___coverage_array[547] = 1;
            }
          }
          }
          return ((PyObject *)((void *)0));
        } else {
          {
          if (___coverage_array[548] == 0) {
            {
            fprintf(_coverage_fout, "548\n");
            fflush(_coverage_fout);
            ___coverage_array[548] = 1;
            }
          }
          }

        }
      } else {
        {
        if (___coverage_array[549] == 0) {
          {
          fprintf(_coverage_fout, "549\n");
          fflush(_coverage_fout);
          ___coverage_array[549] = 1;
          }
        }
        }

      }
      {
      if (___coverage_array[550] == 0) {
        {
        fprintf(_coverage_fout, "550\n");
        fflush(_coverage_fout);
        ___coverage_array[550] = 1;
        }
      }
      }
      if (timeout > (double )2147483647L) {
        {
        if (___coverage_array[551] == 0) {
          {
          fprintf(_coverage_fout, "551\n");
          fflush(_coverage_fout);
          ___coverage_array[551] = 1;
          }
        }
        }
        PyErr_SetString(PyExc_OverflowError, "timeout period too long");
        {
        if (___coverage_array[552] == 0) {
          {
          fprintf(_coverage_fout, "552\n");
          fflush(_coverage_fout);
          ___coverage_array[552] = 1;
          }
        }
        }
        return ((PyObject *)((void *)0));
      } else {
        {
        if (___coverage_array[553] == 0) {
          {
          fprintf(_coverage_fout, "553\n");
          fflush(_coverage_fout);
          ___coverage_array[553] = 1;
          }
        }
        }

      }
      {
      if (___coverage_array[554] == 0) {
        {
        fprintf(_coverage_fout, "554\n");
        fflush(_coverage_fout);
        ___coverage_array[554] = 1;
        }
      }
      }
      seconds = (long )timeout;
      {
      if (___coverage_array[555] == 0) {
        {
        fprintf(_coverage_fout, "555\n");
        fflush(_coverage_fout);
        ___coverage_array[555] = 1;
        }
      }
      }
      timeout -= (double )seconds;
      {
      if (___coverage_array[556] == 0) {
        {
        fprintf(_coverage_fout, "556\n");
        fflush(_coverage_fout);
        ___coverage_array[556] = 1;
        }
      }
      }
      tv.tv_sec = seconds;
      {
      if (___coverage_array[557] == 0) {
        {
        fprintf(_coverage_fout, "557\n");
        fflush(_coverage_fout);
        ___coverage_array[557] = 1;
        }
      }
      }
      tv.tv_usec = (long )(timeout * 1E6);
      {
      if (___coverage_array[558] == 0) {
        {
        fprintf(_coverage_fout, "558\n");
        fflush(_coverage_fout);
        ___coverage_array[558] = 1;
        }
      }
      }
      tvp = & tv;
    } else {
      {
      if (___coverage_array[559] == 0) {
        {
        fprintf(_coverage_fout, "559\n");
        fflush(_coverage_fout);
        ___coverage_array[559] = 1;
        }
      }
      }
      PyErr_SetString(PyExc_TypeError, "timeout must be a float or None");
      {
      if (___coverage_array[560] == 0) {
        {
        fprintf(_coverage_fout, "560\n");
        fflush(_coverage_fout);
        ___coverage_array[560] = 1;
        }
      }
      }
      return ((PyObject *)((void *)0));
    }
  }
  {
  if (___coverage_array[561] == 0) {
    {
    fprintf(_coverage_fout, "561\n");
    fflush(_coverage_fout);
    ___coverage_array[561] = 1;
    }
  }
  }
  rfd2obj[0].sentinel = -1;
  {
  if (___coverage_array[562] == 0) {
    {
    fprintf(_coverage_fout, "562\n");
    fflush(_coverage_fout);
    ___coverage_array[562] = 1;
    }
  }
  }
  wfd2obj[0].sentinel = -1;
  {
  if (___coverage_array[563] == 0) {
    {
    fprintf(_coverage_fout, "563\n");
    fflush(_coverage_fout);
    ___coverage_array[563] = 1;
    }
  }
  }
  efd2obj[0].sentinel = -1;
  {
  if (___coverage_array[564] == 0) {
    {
    fprintf(_coverage_fout, "564\n");
    fflush(_coverage_fout);
    ___coverage_array[564] = 1;
    }
  }
  }
  imax = seq2set(ifdlist, & ifdset, (pylist *)(rfd2obj));
  {
  if (___coverage_array[565] == 0) {
    {
    fprintf(_coverage_fout, "565\n");
    fflush(_coverage_fout);
    ___coverage_array[565] = 1;
    }
  }
  }
  if (imax < 0) {
    {
    if (___coverage_array[566] == 0) {
      {
      fprintf(_coverage_fout, "566\n");
      fflush(_coverage_fout);
      ___coverage_array[566] = 1;
      }
    }
    }
    goto finally;
  } else {
    {
    if (___coverage_array[567] == 0) {
      {
      fprintf(_coverage_fout, "567\n");
      fflush(_coverage_fout);
      ___coverage_array[567] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[568] == 0) {
    {
    fprintf(_coverage_fout, "568\n");
    fflush(_coverage_fout);
    ___coverage_array[568] = 1;
    }
  }
  }
  omax = seq2set(ofdlist, & ofdset, (pylist *)(wfd2obj));
  {
  if (___coverage_array[569] == 0) {
    {
    fprintf(_coverage_fout, "569\n");
    fflush(_coverage_fout);
    ___coverage_array[569] = 1;
    }
  }
  }
  if (omax < 0) {
    {
    if (___coverage_array[570] == 0) {
      {
      fprintf(_coverage_fout, "570\n");
      fflush(_coverage_fout);
      ___coverage_array[570] = 1;
      }
    }
    }
    goto finally;
  } else {
    {
    if (___coverage_array[571] == 0) {
      {
      fprintf(_coverage_fout, "571\n");
      fflush(_coverage_fout);
      ___coverage_array[571] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[572] == 0) {
    {
    fprintf(_coverage_fout, "572\n");
    fflush(_coverage_fout);
    ___coverage_array[572] = 1;
    }
  }
  }
  emax = seq2set(efdlist, & efdset, (pylist *)(efd2obj));
  {
  if (___coverage_array[573] == 0) {
    {
    fprintf(_coverage_fout, "573\n");
    fflush(_coverage_fout);
    ___coverage_array[573] = 1;
    }
  }
  }
  if (emax < 0) {
    {
    if (___coverage_array[574] == 0) {
      {
      fprintf(_coverage_fout, "574\n");
      fflush(_coverage_fout);
      ___coverage_array[574] = 1;
      }
    }
    }
    goto finally;
  } else {
    {
    if (___coverage_array[575] == 0) {
      {
      fprintf(_coverage_fout, "575\n");
      fflush(_coverage_fout);
      ___coverage_array[575] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[576] == 0) {
    {
    fprintf(_coverage_fout, "576\n");
    fflush(_coverage_fout);
    ___coverage_array[576] = 1;
    }
  }
  }
  max = imax;
  {
  if (___coverage_array[577] == 0) {
    {
    fprintf(_coverage_fout, "577\n");
    fflush(_coverage_fout);
    ___coverage_array[577] = 1;
    }
  }
  }
  if (omax > max) {
    {
    if (___coverage_array[578] == 0) {
      {
      fprintf(_coverage_fout, "578\n");
      fflush(_coverage_fout);
      ___coverage_array[578] = 1;
      }
    }
    }
    max = omax;
  } else {
    {
    if (___coverage_array[579] == 0) {
      {
      fprintf(_coverage_fout, "579\n");
      fflush(_coverage_fout);
      ___coverage_array[579] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[580] == 0) {
    {
    fprintf(_coverage_fout, "580\n");
    fflush(_coverage_fout);
    ___coverage_array[580] = 1;
    }
  }
  }
  if (emax > max) {
    {
    if (___coverage_array[581] == 0) {
      {
      fprintf(_coverage_fout, "581\n");
      fflush(_coverage_fout);
      ___coverage_array[581] = 1;
      }
    }
    }
    max = emax;
  } else {
    {
    if (___coverage_array[582] == 0) {
      {
      fprintf(_coverage_fout, "582\n");
      fflush(_coverage_fout);
      ___coverage_array[582] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[583] == 0) {
    {
    fprintf(_coverage_fout, "583\n");
    fflush(_coverage_fout);
    ___coverage_array[583] = 1;
    }
  }
  }
  _save = PyEval_SaveThread();
  {
  if (___coverage_array[584] == 0) {
    {
    fprintf(_coverage_fout, "584\n");
    fflush(_coverage_fout);
    ___coverage_array[584] = 1;
    }
  }
  }
  n = select(max, (fd_set */* __restrict  */)(& ifdset),
             (fd_set */* __restrict  */)(& ofdset),
             (fd_set */* __restrict  */)(& efdset),
             (struct timeval */* __restrict  */)tvp);
  {
  if (___coverage_array[585] == 0) {
    {
    fprintf(_coverage_fout, "585\n");
    fflush(_coverage_fout);
    ___coverage_array[585] = 1;
    }
  }
  }
  PyEval_RestoreThread(_save);
  {
  if (___coverage_array[586] == 0) {
    {
    fprintf(_coverage_fout, "586\n");
    fflush(_coverage_fout);
    ___coverage_array[586] = 1;
    }
  }
  }
  if (n < 0) {
    {
    if (___coverage_array[587] == 0) {
      {
      fprintf(_coverage_fout, "587\n");
      fflush(_coverage_fout);
      ___coverage_array[587] = 1;
      }
    }
    }
    PyErr_SetFromErrno(SelectError);
  } else {
    {
    if (___coverage_array[588] == 0) {
      {
      fprintf(_coverage_fout, "588\n");
      fflush(_coverage_fout);
      ___coverage_array[588] = 1;
      }
    }
    }
    ifdlist = set2list(& ifdset, (pylist *)(rfd2obj));
    {
    if (___coverage_array[589] == 0) {
      {
      fprintf(_coverage_fout, "589\n");
      fflush(_coverage_fout);
      ___coverage_array[589] = 1;
      }
    }
    }
    ofdlist = set2list(& ofdset, (pylist *)(wfd2obj));
    {
    if (___coverage_array[590] == 0) {
      {
      fprintf(_coverage_fout, "590\n");
      fflush(_coverage_fout);
      ___coverage_array[590] = 1;
      }
    }
    }
    efdlist = set2list(& efdset, (pylist *)(efd2obj));
    {
    if (___coverage_array[591] == 0) {
      {
      fprintf(_coverage_fout, "591\n");
      fflush(_coverage_fout);
      ___coverage_array[591] = 1;
      }
    }
    }
    tmp___2 = PyErr_Occurred();
    {
    if (___coverage_array[592] == 0) {
      {
      fprintf(_coverage_fout, "592\n");
      fflush(_coverage_fout);
      ___coverage_array[592] = 1;
      }
    }
    }
    if (tmp___2) {
      {
      if (___coverage_array[593] == 0) {
        {
        fprintf(_coverage_fout, "593\n");
        fflush(_coverage_fout);
        ___coverage_array[593] = 1;
        }
      }
      }
      ret = (PyObject *)((void *)0);
    } else {
      {
      if (___coverage_array[594] == 0) {
        {
        fprintf(_coverage_fout, "594\n");
        fflush(_coverage_fout);
        ___coverage_array[594] = 1;
        }
      }
      }
      ret = PyTuple_Pack(3, ifdlist, ofdlist, efdlist);
    }
    {
    if (___coverage_array[595] == 0) {
      {
      fprintf(_coverage_fout, "595\n");
      fflush(_coverage_fout);
      ___coverage_array[595] = 1;
      }
    }
    }
    while (1) {
      {
      if (___coverage_array[596] == 0) {
        {
        fprintf(_coverage_fout, "596\n");
        fflush(_coverage_fout);
        ___coverage_array[596] = 1;
        }
      }
      }
      (ifdlist->ob_refcnt) --;
      {
      if (___coverage_array[597] == 0) {
        {
        fprintf(_coverage_fout, "597\n");
        fflush(_coverage_fout);
        ___coverage_array[597] = 1;
        }
      }
      }
      if (ifdlist->ob_refcnt != 0) {
        {
        if (___coverage_array[598] == 0) {
          {
          fprintf(_coverage_fout, "598\n");
          fflush(_coverage_fout);
          ___coverage_array[598] = 1;
          }
        }
        }

      } else {
        {
        if (___coverage_array[599] == 0) {
          {
          fprintf(_coverage_fout, "599\n");
          fflush(_coverage_fout);
          ___coverage_array[599] = 1;
          }
        }
        }
        (*((ifdlist->ob_type)->tp_dealloc))(ifdlist);
      }
      {
      if (___coverage_array[600] == 0) {
        {
        fprintf(_coverage_fout, "600\n");
        fflush(_coverage_fout);
        ___coverage_array[600] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[601] == 0) {
      {
      fprintf(_coverage_fout, "601\n");
      fflush(_coverage_fout);
      ___coverage_array[601] = 1;
      }
    }
    }
    while (1) {
      {
      if (___coverage_array[602] == 0) {
        {
        fprintf(_coverage_fout, "602\n");
        fflush(_coverage_fout);
        ___coverage_array[602] = 1;
        }
      }
      }
      (ofdlist->ob_refcnt) --;
      {
      if (___coverage_array[603] == 0) {
        {
        fprintf(_coverage_fout, "603\n");
        fflush(_coverage_fout);
        ___coverage_array[603] = 1;
        }
      }
      }
      if (ofdlist->ob_refcnt != 0) {
        {
        if (___coverage_array[604] == 0) {
          {
          fprintf(_coverage_fout, "604\n");
          fflush(_coverage_fout);
          ___coverage_array[604] = 1;
          }
        }
        }

      } else {
        {
        if (___coverage_array[605] == 0) {
          {
          fprintf(_coverage_fout, "605\n");
          fflush(_coverage_fout);
          ___coverage_array[605] = 1;
          }
        }
        }
        (*((ofdlist->ob_type)->tp_dealloc))(ofdlist);
      }
      {
      if (___coverage_array[606] == 0) {
        {
        fprintf(_coverage_fout, "606\n");
        fflush(_coverage_fout);
        ___coverage_array[606] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[607] == 0) {
      {
      fprintf(_coverage_fout, "607\n");
      fflush(_coverage_fout);
      ___coverage_array[607] = 1;
      }
    }
    }
    while (1) {
      {
      if (___coverage_array[608] == 0) {
        {
        fprintf(_coverage_fout, "608\n");
        fflush(_coverage_fout);
        ___coverage_array[608] = 1;
        }
      }
      }
      (efdlist->ob_refcnt) --;
      {
      if (___coverage_array[609] == 0) {
        {
        fprintf(_coverage_fout, "609\n");
        fflush(_coverage_fout);
        ___coverage_array[609] = 1;
        }
      }
      }
      if (efdlist->ob_refcnt != 0) {
        {
        if (___coverage_array[610] == 0) {
          {
          fprintf(_coverage_fout, "610\n");
          fflush(_coverage_fout);
          ___coverage_array[610] = 1;
          }
        }
        }

      } else {
        {
        if (___coverage_array[611] == 0) {
          {
          fprintf(_coverage_fout, "611\n");
          fflush(_coverage_fout);
          ___coverage_array[611] = 1;
          }
        }
        }
        (*((efdlist->ob_type)->tp_dealloc))(efdlist);
      }
      {
      if (___coverage_array[612] == 0) {
        {
        fprintf(_coverage_fout, "612\n");
        fflush(_coverage_fout);
        ___coverage_array[612] = 1;
        }
      }
      }
      break;
    }
  }
  {
  if (___coverage_array[613] == 0) {
    {
    fprintf(_coverage_fout, "613\n");
    fflush(_coverage_fout);
    ___coverage_array[613] = 1;
    }
  }
  }
  finally: 
  reap_obj((pylist *)(rfd2obj));
  {
  if (___coverage_array[614] == 0) {
    {
    fprintf(_coverage_fout, "614\n");
    fflush(_coverage_fout);
    ___coverage_array[614] = 1;
    }
  }
  }
  reap_obj((pylist *)(wfd2obj));
  {
  if (___coverage_array[615] == 0) {
    {
    fprintf(_coverage_fout, "615\n");
    fflush(_coverage_fout);
    ___coverage_array[615] = 1;
    }
  }
  }
  reap_obj((pylist *)(efd2obj));
  {
  if (___coverage_array[616] == 0) {
    {
    fprintf(_coverage_fout, "616\n");
    fflush(_coverage_fout);
    ___coverage_array[616] = 1;
    }
  }
  }
  return (ret);
}
}
static void poll_dealloc(pollObject *self ) ;
static PyObject *poll_register(pollObject *self , PyObject *args ) ;
static char poll_register_doc[247] ;
static PyObject *poll_modify(pollObject *self , PyObject *args ) ;
static char poll_modify_doc[235] ;
static PyObject *poll_unregister(pollObject *self , PyObject *o ) ;
static char poll_unregister_doc[86] ;
static PyObject *poll_poll(pollObject *self , PyObject *args ) ;
static char poll_poll_doc[180] ;
static PyMethodDef poll_methods[5] ;
static PyTypeObject poll_Type ;
static int update_ufd_array(pollObject *self ) 
{ 
  Py_ssize_t i ;
  Py_ssize_t pos ;
  PyObject *key ;
  PyObject *value ;
  struct pollfd *old_ufds ;
  unsigned long tmp ;
  void *tmp___0 ;
  void *tmp___1 ;
  long tmp___2 ;
  long tmp___3 ;
  int tmp___4 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[617] == 0) {
    {
    fprintf(_coverage_fout, "617\n");
    fflush(_coverage_fout);
    ___coverage_array[617] = 1;
    }
  }
  }
  old_ufds = self->ufds;
  {
  if (___coverage_array[618] == 0) {
    {
    fprintf(_coverage_fout, "618\n");
    fflush(_coverage_fout);
    ___coverage_array[618] = 1;
    }
  }
  }
  self->ufd_len = PyDict_Size(self->dict);
  {
  if (___coverage_array[619] == 0) {
    {
    fprintf(_coverage_fout, "619\n");
    fflush(_coverage_fout);
    ___coverage_array[619] = 1;
    }
  }
  }
  if ((unsigned long )((size_t )self->ufd_len) > (unsigned long )((Py_ssize_t )(4294967295U >> 1)) / sizeof(struct pollfd )) {
    {
    if (___coverage_array[620] == 0) {
      {
      fprintf(_coverage_fout, "620\n");
      fflush(_coverage_fout);
      ___coverage_array[620] = 1;
      }
    }
    }
    self->ufds = (struct pollfd *)((void *)0);
  } else {
    {
    if (___coverage_array[621] == 0) {
      {
      fprintf(_coverage_fout, "621\n");
      fflush(_coverage_fout);
      ___coverage_array[621] = 1;
      }
    }
    }
    if ((size_t )((unsigned long )self->ufd_len * sizeof(struct pollfd )) > (size_t )((Py_ssize_t )(4294967295U >> 1))) {
      {
      if (___coverage_array[622] == 0) {
        {
        fprintf(_coverage_fout, "622\n");
        fflush(_coverage_fout);
        ___coverage_array[622] = 1;
        }
      }
      }
      tmp___1 = (void *)0;
    } else {
      {
      if (___coverage_array[623] == 0) {
        {
        fprintf(_coverage_fout, "623\n");
        fflush(_coverage_fout);
        ___coverage_array[623] = 1;
        }
      }
      }
      if ((unsigned long )self->ufd_len * sizeof(struct pollfd )) {
        {
        if (___coverage_array[624] == 0) {
          {
          fprintf(_coverage_fout, "624\n");
          fflush(_coverage_fout);
          ___coverage_array[624] = 1;
          }
        }
        }
        tmp = (unsigned long )self->ufd_len * sizeof(struct pollfd );
      } else {
        {
        if (___coverage_array[625] == 0) {
          {
          fprintf(_coverage_fout, "625\n");
          fflush(_coverage_fout);
          ___coverage_array[625] = 1;
          }
        }
        }
        tmp = 1UL;
      }
      {
      if (___coverage_array[626] == 0) {
        {
        fprintf(_coverage_fout, "626\n");
        fflush(_coverage_fout);
        ___coverage_array[626] = 1;
        }
      }
      }
      tmp___0 = realloc((void *)self->ufds, (size_t )tmp);
      {
      if (___coverage_array[627] == 0) {
        {
        fprintf(_coverage_fout, "627\n");
        fflush(_coverage_fout);
        ___coverage_array[627] = 1;
        }
      }
      }
      tmp___1 = tmp___0;
    }
    {
    if (___coverage_array[628] == 0) {
      {
      fprintf(_coverage_fout, "628\n");
      fflush(_coverage_fout);
      ___coverage_array[628] = 1;
      }
    }
    }
    self->ufds = (struct pollfd *)tmp___1;
  }
  {
  if (___coverage_array[629] == 0) {
    {
    fprintf(_coverage_fout, "629\n");
    fflush(_coverage_fout);
    ___coverage_array[629] = 1;
    }
  }
  }
  if ((unsigned long )self->ufds == (unsigned long )((void *)0)) {
    {
    if (___coverage_array[630] == 0) {
      {
      fprintf(_coverage_fout, "630\n");
      fflush(_coverage_fout);
      ___coverage_array[630] = 1;
      }
    }
    }
    self->ufds = old_ufds;
    {
    if (___coverage_array[631] == 0) {
      {
      fprintf(_coverage_fout, "631\n");
      fflush(_coverage_fout);
      ___coverage_array[631] = 1;
      }
    }
    }
    PyErr_NoMemory();
    {
    if (___coverage_array[632] == 0) {
      {
      fprintf(_coverage_fout, "632\n");
      fflush(_coverage_fout);
      ___coverage_array[632] = 1;
      }
    }
    }
    return (0);
  } else {
    {
    if (___coverage_array[633] == 0) {
      {
      fprintf(_coverage_fout, "633\n");
      fflush(_coverage_fout);
      ___coverage_array[633] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[634] == 0) {
    {
    fprintf(_coverage_fout, "634\n");
    fflush(_coverage_fout);
    ___coverage_array[634] = 1;
    }
  }
  }
  pos = 0;
  {
  if (___coverage_array[635] == 0) {
    {
    fprintf(_coverage_fout, "635\n");
    fflush(_coverage_fout);
    ___coverage_array[635] = 1;
    }
  }
  }
  i = pos;
  {
  if (___coverage_array[636] == 0) {
    {
    fprintf(_coverage_fout, "636\n");
    fflush(_coverage_fout);
    ___coverage_array[636] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[637] == 0) {
      {
      fprintf(_coverage_fout, "637\n");
      fflush(_coverage_fout);
      ___coverage_array[637] = 1;
      }
    }
    }
    tmp___4 = PyDict_Next(self->dict, & pos, & key, & value);
    {
    if (___coverage_array[638] == 0) {
      {
      fprintf(_coverage_fout, "638\n");
      fflush(_coverage_fout);
      ___coverage_array[638] = 1;
      }
    }
    }
    if (tmp___4) {
      {
      if (___coverage_array[639] == 0) {
        {
        fprintf(_coverage_fout, "639\n");
        fflush(_coverage_fout);
        ___coverage_array[639] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[640] == 0) {
        {
        fprintf(_coverage_fout, "640\n");
        fflush(_coverage_fout);
        ___coverage_array[640] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[641] == 0) {
      {
      fprintf(_coverage_fout, "641\n");
      fflush(_coverage_fout);
      ___coverage_array[641] = 1;
      }
    }
    }
    tmp___2 = PyLong_AsLong(key);
    {
    if (___coverage_array[642] == 0) {
      {
      fprintf(_coverage_fout, "642\n");
      fflush(_coverage_fout);
      ___coverage_array[642] = 1;
      }
    }
    }
    (self->ufds + i)->fd = (int )tmp___2;
    {
    if (___coverage_array[643] == 0) {
      {
      fprintf(_coverage_fout, "643\n");
      fflush(_coverage_fout);
      ___coverage_array[643] = 1;
      }
    }
    }
    tmp___3 = PyLong_AsLong(value);
    {
    if (___coverage_array[644] == 0) {
      {
      fprintf(_coverage_fout, "644\n");
      fflush(_coverage_fout);
      ___coverage_array[644] = 1;
      }
    }
    }
    (self->ufds + i)->events = (short )tmp___3;
    {
    if (___coverage_array[645] == 0) {
      {
      fprintf(_coverage_fout, "645\n");
      fflush(_coverage_fout);
      ___coverage_array[645] = 1;
      }
    }
    }
    i ++;
  }
  {
  if (___coverage_array[646] == 0) {
    {
    fprintf(_coverage_fout, "646\n");
    fflush(_coverage_fout);
    ___coverage_array[646] = 1;
    }
  }
  }
  self->ufd_uptodate = 1;
  {
  if (___coverage_array[647] == 0) {
    {
    fprintf(_coverage_fout, "647\n");
    fflush(_coverage_fout);
    ___coverage_array[647] = 1;
    }
  }
  }
  return (1);
}
}
static char poll_register_doc[247]  = 
  {      (char )'r',      (char )'e',      (char )'g',      (char )'i', 
        (char )'s',      (char )'t',      (char )'e',      (char )'r', 
        (char )'(',      (char )'f',      (char )'d',      (char )' ', 
        (char )'[',      (char )',',      (char )' ',      (char )'e', 
        (char )'v',      (char )'e',      (char )'n',      (char )'t', 
        (char )'m',      (char )'a',      (char )'s',      (char )'k', 
        (char )']',      (char )' ',      (char )')',      (char )' ', 
        (char )'-',      (char )'>',      (char )' ',      (char )'N', 
        (char )'o',      (char )'n',      (char )'e',      (char )'\n', 
        (char )'\n',      (char )'R',      (char )'e',      (char )'g', 
        (char )'i',      (char )'s',      (char )'t',      (char )'e', 
        (char )'r',      (char )' ',      (char )'a',      (char )' ', 
        (char )'f',      (char )'i',      (char )'l',      (char )'e', 
        (char )' ',      (char )'d',      (char )'e',      (char )'s', 
        (char )'c',      (char )'r',      (char )'i',      (char )'p', 
        (char )'t',      (char )'o',      (char )'r',      (char )' ', 
        (char )'w',      (char )'i',      (char )'t',      (char )'h', 
        (char )' ',      (char )'t',      (char )'h',      (char )'e', 
        (char )' ',      (char )'p',      (char )'o',      (char )'l', 
        (char )'l',      (char )'i',      (char )'n',      (char )'g', 
        (char )' ',      (char )'o',      (char )'b',      (char )'j', 
        (char )'e',      (char )'c',      (char )'t',      (char )'.', 
        (char )'\n',      (char )'f',      (char )'d',      (char )' ', 
        (char )'-',      (char )'-',      (char )' ',      (char )'e', 
        (char )'i',      (char )'t',      (char )'h',      (char )'e', 
        (char )'r',      (char )' ',      (char )'a',      (char )'n', 
        (char )' ',      (char )'i',      (char )'n',      (char )'t', 
        (char )'e',      (char )'g',      (char )'e',      (char )'r', 
        (char )',',      (char )' ',      (char )'o',      (char )'r', 
        (char )' ',      (char )'a',      (char )'n',      (char )' ', 
        (char )'o',      (char )'b',      (char )'j',      (char )'e', 
        (char )'c',      (char )'t',      (char )' ',      (char )'w', 
        (char )'i',      (char )'t',      (char )'h',      (char )' ', 
        (char )'a',      (char )' ',      (char )'f',      (char )'i', 
        (char )'l',      (char )'e',      (char )'n',      (char )'o', 
        (char )'(',      (char )')',      (char )' ',      (char )'m', 
        (char )'e',      (char )'t',      (char )'h',      (char )'o', 
        (char )'d',      (char )' ',      (char )'r',      (char )'e', 
        (char )'t',      (char )'u',      (char )'r',      (char )'n', 
        (char )'i',      (char )'n',      (char )'g',      (char )' ', 
        (char )'a',      (char )'n',      (char )'\n',      (char )' ', 
        (char )' ',      (char )' ',      (char )' ',      (char )' ', 
        (char )' ',      (char )'i',      (char )'n',      (char )'t', 
        (char )'.',      (char )'\n',      (char )'e',      (char )'v', 
        (char )'e',      (char )'n',      (char )'t',      (char )'s', 
        (char )' ',      (char )'-',      (char )'-',      (char )' ', 
        (char )'a',      (char )'n',      (char )' ',      (char )'o', 
        (char )'p',      (char )'t',      (char )'i',      (char )'o', 
        (char )'n',      (char )'a',      (char )'l',      (char )' ', 
        (char )'b',      (char )'i',      (char )'t',      (char )'m', 
        (char )'a',      (char )'s',      (char )'k',      (char )' ', 
        (char )'d',      (char )'e',      (char )'s',      (char )'c', 
        (char )'r',      (char )'i',      (char )'b',      (char )'i', 
        (char )'n',      (char )'g',      (char )' ',      (char )'t', 
        (char )'h',      (char )'e',      (char )' ',      (char )'t', 
        (char )'y',      (char )'p',      (char )'e',      (char )' ', 
        (char )'o',      (char )'f',      (char )' ',      (char )'e', 
        (char )'v',      (char )'e',      (char )'n',      (char )'t', 
        (char )'s',      (char )' ',      (char )'t',      (char )'o', 
        (char )' ',      (char )'c',      (char )'h',      (char )'e', 
        (char )'c',      (char )'k',      (char )' ',      (char )'f', 
        (char )'o',      (char )'r',      (char )'\000'};
static PyObject *poll_register(pollObject *self , PyObject *args ) 
{ 
  PyObject *o ;
  PyObject *key ;
  PyObject *value ;
  int fd ;
  int events ;
  int err ;
  int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[648] == 0) {
    {
    fprintf(_coverage_fout, "648\n");
    fflush(_coverage_fout);
    ___coverage_array[648] = 1;
    }
  }
  }
  events = 7;
  {
  if (___coverage_array[649] == 0) {
    {
    fprintf(_coverage_fout, "649\n");
    fflush(_coverage_fout);
    ___coverage_array[649] = 1;
    }
  }
  }
  tmp = PyArg_ParseTuple(args, "O|i:register", & o, & events);
  {
  if (___coverage_array[650] == 0) {
    {
    fprintf(_coverage_fout, "650\n");
    fflush(_coverage_fout);
    ___coverage_array[650] = 1;
    }
  }
  }
  if (tmp) {
    {
    if (___coverage_array[651] == 0) {
      {
      fprintf(_coverage_fout, "651\n");
      fflush(_coverage_fout);
      ___coverage_array[651] = 1;
      }
    }
    }

  } else {
    {
    if (___coverage_array[652] == 0) {
      {
      fprintf(_coverage_fout, "652\n");
      fflush(_coverage_fout);
      ___coverage_array[652] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  }
  {
  if (___coverage_array[653] == 0) {
    {
    fprintf(_coverage_fout, "653\n");
    fflush(_coverage_fout);
    ___coverage_array[653] = 1;
    }
  }
  }
  fd = PyObject_AsFileDescriptor(o);
  {
  if (___coverage_array[654] == 0) {
    {
    fprintf(_coverage_fout, "654\n");
    fflush(_coverage_fout);
    ___coverage_array[654] = 1;
    }
  }
  }
  if (fd == -1) {
    {
    if (___coverage_array[655] == 0) {
      {
      fprintf(_coverage_fout, "655\n");
      fflush(_coverage_fout);
      ___coverage_array[655] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[656] == 0) {
      {
      fprintf(_coverage_fout, "656\n");
      fflush(_coverage_fout);
      ___coverage_array[656] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[657] == 0) {
    {
    fprintf(_coverage_fout, "657\n");
    fflush(_coverage_fout);
    ___coverage_array[657] = 1;
    }
  }
  }
  key = PyLong_FromLong((long )fd);
  {
  if (___coverage_array[658] == 0) {
    {
    fprintf(_coverage_fout, "658\n");
    fflush(_coverage_fout);
    ___coverage_array[658] = 1;
    }
  }
  }
  if ((unsigned long )key == (unsigned long )((void *)0)) {
    {
    if (___coverage_array[659] == 0) {
      {
      fprintf(_coverage_fout, "659\n");
      fflush(_coverage_fout);
      ___coverage_array[659] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[660] == 0) {
      {
      fprintf(_coverage_fout, "660\n");
      fflush(_coverage_fout);
      ___coverage_array[660] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[661] == 0) {
    {
    fprintf(_coverage_fout, "661\n");
    fflush(_coverage_fout);
    ___coverage_array[661] = 1;
    }
  }
  }
  value = PyLong_FromLong((long )events);
  {
  if (___coverage_array[662] == 0) {
    {
    fprintf(_coverage_fout, "662\n");
    fflush(_coverage_fout);
    ___coverage_array[662] = 1;
    }
  }
  }
  if ((unsigned long )value == (unsigned long )((void *)0)) {
    {
    if (___coverage_array[663] == 0) {
      {
      fprintf(_coverage_fout, "663\n");
      fflush(_coverage_fout);
      ___coverage_array[663] = 1;
      }
    }
    }
    while (1) {
      {
      if (___coverage_array[664] == 0) {
        {
        fprintf(_coverage_fout, "664\n");
        fflush(_coverage_fout);
        ___coverage_array[664] = 1;
        }
      }
      }
      (key->ob_refcnt) --;
      {
      if (___coverage_array[665] == 0) {
        {
        fprintf(_coverage_fout, "665\n");
        fflush(_coverage_fout);
        ___coverage_array[665] = 1;
        }
      }
      }
      if (key->ob_refcnt != 0) {
        {
        if (___coverage_array[666] == 0) {
          {
          fprintf(_coverage_fout, "666\n");
          fflush(_coverage_fout);
          ___coverage_array[666] = 1;
          }
        }
        }

      } else {
        {
        if (___coverage_array[667] == 0) {
          {
          fprintf(_coverage_fout, "667\n");
          fflush(_coverage_fout);
          ___coverage_array[667] = 1;
          }
        }
        }
        (*((key->ob_type)->tp_dealloc))(key);
      }
      {
      if (___coverage_array[668] == 0) {
        {
        fprintf(_coverage_fout, "668\n");
        fflush(_coverage_fout);
        ___coverage_array[668] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[669] == 0) {
      {
      fprintf(_coverage_fout, "669\n");
      fflush(_coverage_fout);
      ___coverage_array[669] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[670] == 0) {
      {
      fprintf(_coverage_fout, "670\n");
      fflush(_coverage_fout);
      ___coverage_array[670] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[671] == 0) {
    {
    fprintf(_coverage_fout, "671\n");
    fflush(_coverage_fout);
    ___coverage_array[671] = 1;
    }
  }
  }
  err = PyDict_SetItem(self->dict, key, value);
  {
  if (___coverage_array[672] == 0) {
    {
    fprintf(_coverage_fout, "672\n");
    fflush(_coverage_fout);
    ___coverage_array[672] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[673] == 0) {
      {
      fprintf(_coverage_fout, "673\n");
      fflush(_coverage_fout);
      ___coverage_array[673] = 1;
      }
    }
    }
    (key->ob_refcnt) --;
    {
    if (___coverage_array[674] == 0) {
      {
      fprintf(_coverage_fout, "674\n");
      fflush(_coverage_fout);
      ___coverage_array[674] = 1;
      }
    }
    }
    if (key->ob_refcnt != 0) {
      {
      if (___coverage_array[675] == 0) {
        {
        fprintf(_coverage_fout, "675\n");
        fflush(_coverage_fout);
        ___coverage_array[675] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[676] == 0) {
        {
        fprintf(_coverage_fout, "676\n");
        fflush(_coverage_fout);
        ___coverage_array[676] = 1;
        }
      }
      }
      (*((key->ob_type)->tp_dealloc))(key);
    }
    {
    if (___coverage_array[677] == 0) {
      {
      fprintf(_coverage_fout, "677\n");
      fflush(_coverage_fout);
      ___coverage_array[677] = 1;
      }
    }
    }
    break;
  }
  {
  if (___coverage_array[678] == 0) {
    {
    fprintf(_coverage_fout, "678\n");
    fflush(_coverage_fout);
    ___coverage_array[678] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[679] == 0) {
      {
      fprintf(_coverage_fout, "679\n");
      fflush(_coverage_fout);
      ___coverage_array[679] = 1;
      }
    }
    }
    (value->ob_refcnt) --;
    {
    if (___coverage_array[680] == 0) {
      {
      fprintf(_coverage_fout, "680\n");
      fflush(_coverage_fout);
      ___coverage_array[680] = 1;
      }
    }
    }
    if (value->ob_refcnt != 0) {
      {
      if (___coverage_array[681] == 0) {
        {
        fprintf(_coverage_fout, "681\n");
        fflush(_coverage_fout);
        ___coverage_array[681] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[682] == 0) {
        {
        fprintf(_coverage_fout, "682\n");
        fflush(_coverage_fout);
        ___coverage_array[682] = 1;
        }
      }
      }
      (*((value->ob_type)->tp_dealloc))(value);
    }
    {
    if (___coverage_array[683] == 0) {
      {
      fprintf(_coverage_fout, "683\n");
      fflush(_coverage_fout);
      ___coverage_array[683] = 1;
      }
    }
    }
    break;
  }
  {
  if (___coverage_array[684] == 0) {
    {
    fprintf(_coverage_fout, "684\n");
    fflush(_coverage_fout);
    ___coverage_array[684] = 1;
    }
  }
  }
  if (err < 0) {
    {
    if (___coverage_array[685] == 0) {
      {
      fprintf(_coverage_fout, "685\n");
      fflush(_coverage_fout);
      ___coverage_array[685] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[686] == 0) {
      {
      fprintf(_coverage_fout, "686\n");
      fflush(_coverage_fout);
      ___coverage_array[686] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[687] == 0) {
    {
    fprintf(_coverage_fout, "687\n");
    fflush(_coverage_fout);
    ___coverage_array[687] = 1;
    }
  }
  }
  self->ufd_uptodate = 0;
  {
  if (___coverage_array[688] == 0) {
    {
    fprintf(_coverage_fout, "688\n");
    fflush(_coverage_fout);
    ___coverage_array[688] = 1;
    }
  }
  }
  (_Py_NoneStruct.ob_refcnt) ++;
  {
  if (___coverage_array[689] == 0) {
    {
    fprintf(_coverage_fout, "689\n");
    fflush(_coverage_fout);
    ___coverage_array[689] = 1;
    }
  }
  }
  return (& _Py_NoneStruct);
}
}
static char poll_modify_doc[235]  = 
  {      (char )'m',      (char )'o',      (char )'d',      (char )'i', 
        (char )'f',      (char )'y',      (char )'(',      (char )'f', 
        (char )'d',      (char )',',      (char )' ',      (char )'e', 
        (char )'v',      (char )'e',      (char )'n',      (char )'t', 
        (char )'m',      (char )'a',      (char )'s',      (char )'k', 
        (char )')',      (char )' ',      (char )'-',      (char )'>', 
        (char )' ',      (char )'N',      (char )'o',      (char )'n', 
        (char )'e',      (char )'\n',      (char )'\n',      (char )'M', 
        (char )'o',      (char )'d',      (char )'i',      (char )'f', 
        (char )'y',      (char )' ',      (char )'a',      (char )'n', 
        (char )' ',      (char )'a',      (char )'l',      (char )'r', 
        (char )'e',      (char )'a',      (char )'d',      (char )'y', 
        (char )' ',      (char )'r',      (char )'e',      (char )'g', 
        (char )'i',      (char )'s',      (char )'t',      (char )'e', 
        (char )'r',      (char )'e',      (char )'d',      (char )' ', 
        (char )'f',      (char )'i',      (char )'l',      (char )'e', 
        (char )' ',      (char )'d',      (char )'e',      (char )'s', 
        (char )'c',      (char )'r',      (char )'i',      (char )'p', 
        (char )'t',      (char )'o',      (char )'r',      (char )'.', 
        (char )'\n',      (char )'f',      (char )'d',      (char )' ', 
        (char )'-',      (char )'-',      (char )' ',      (char )'e', 
        (char )'i',      (char )'t',      (char )'h',      (char )'e', 
        (char )'r',      (char )' ',      (char )'a',      (char )'n', 
        (char )' ',      (char )'i',      (char )'n',      (char )'t', 
        (char )'e',      (char )'g',      (char )'e',      (char )'r', 
        (char )',',      (char )' ',      (char )'o',      (char )'r', 
        (char )' ',      (char )'a',      (char )'n',      (char )' ', 
        (char )'o',      (char )'b',      (char )'j',      (char )'e', 
        (char )'c',      (char )'t',      (char )' ',      (char )'w', 
        (char )'i',      (char )'t',      (char )'h',      (char )' ', 
        (char )'a',      (char )' ',      (char )'f',      (char )'i', 
        (char )'l',      (char )'e',      (char )'n',      (char )'o', 
        (char )'(',      (char )')',      (char )' ',      (char )'m', 
        (char )'e',      (char )'t',      (char )'h',      (char )'o', 
        (char )'d',      (char )' ',      (char )'r',      (char )'e', 
        (char )'t',      (char )'u',      (char )'r',      (char )'n', 
        (char )'i',      (char )'n',      (char )'g',      (char )' ', 
        (char )'a',      (char )'n',      (char )'\n',      (char )' ', 
        (char )' ',      (char )' ',      (char )' ',      (char )' ', 
        (char )' ',      (char )'i',      (char )'n',      (char )'t', 
        (char )'.',      (char )'\n',      (char )'e',      (char )'v', 
        (char )'e',      (char )'n',      (char )'t',      (char )'s', 
        (char )' ',      (char )'-',      (char )'-',      (char )' ', 
        (char )'a',      (char )'n',      (char )' ',      (char )'o', 
        (char )'p',      (char )'t',      (char )'i',      (char )'o', 
        (char )'n',      (char )'a',      (char )'l',      (char )' ', 
        (char )'b',      (char )'i',      (char )'t',      (char )'m', 
        (char )'a',      (char )'s',      (char )'k',      (char )' ', 
        (char )'d',      (char )'e',      (char )'s',      (char )'c', 
        (char )'r',      (char )'i',      (char )'b',      (char )'i', 
        (char )'n',      (char )'g',      (char )' ',      (char )'t', 
        (char )'h',      (char )'e',      (char )' ',      (char )'t', 
        (char )'y',      (char )'p',      (char )'e',      (char )' ', 
        (char )'o',      (char )'f',      (char )' ',      (char )'e', 
        (char )'v',      (char )'e',      (char )'n',      (char )'t', 
        (char )'s',      (char )' ',      (char )'t',      (char )'o', 
        (char )' ',      (char )'c',      (char )'h',      (char )'e', 
        (char )'c',      (char )'k',      (char )' ',      (char )'f', 
        (char )'o',      (char )'r',      (char )'\000'};
static PyObject *poll_modify(pollObject *self , PyObject *args ) 
{ 
  PyObject *o ;
  PyObject *key ;
  PyObject *value ;
  int fd ;
  int events ;
  int err ;
  int tmp ;
  int *tmp___0 ;
  PyObject *tmp___1 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[690] == 0) {
    {
    fprintf(_coverage_fout, "690\n");
    fflush(_coverage_fout);
    ___coverage_array[690] = 1;
    }
  }
  }
  tmp = PyArg_ParseTuple(args, "Oi:modify", & o, & events);
  {
  if (___coverage_array[691] == 0) {
    {
    fprintf(_coverage_fout, "691\n");
    fflush(_coverage_fout);
    ___coverage_array[691] = 1;
    }
  }
  }
  if (tmp) {
    {
    if (___coverage_array[692] == 0) {
      {
      fprintf(_coverage_fout, "692\n");
      fflush(_coverage_fout);
      ___coverage_array[692] = 1;
      }
    }
    }

  } else {
    {
    if (___coverage_array[693] == 0) {
      {
      fprintf(_coverage_fout, "693\n");
      fflush(_coverage_fout);
      ___coverage_array[693] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  }
  {
  if (___coverage_array[694] == 0) {
    {
    fprintf(_coverage_fout, "694\n");
    fflush(_coverage_fout);
    ___coverage_array[694] = 1;
    }
  }
  }
  fd = PyObject_AsFileDescriptor(o);
  {
  if (___coverage_array[695] == 0) {
    {
    fprintf(_coverage_fout, "695\n");
    fflush(_coverage_fout);
    ___coverage_array[695] = 1;
    }
  }
  }
  if (fd == -1) {
    {
    if (___coverage_array[696] == 0) {
      {
      fprintf(_coverage_fout, "696\n");
      fflush(_coverage_fout);
      ___coverage_array[696] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[697] == 0) {
      {
      fprintf(_coverage_fout, "697\n");
      fflush(_coverage_fout);
      ___coverage_array[697] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[698] == 0) {
    {
    fprintf(_coverage_fout, "698\n");
    fflush(_coverage_fout);
    ___coverage_array[698] = 1;
    }
  }
  }
  key = PyLong_FromLong((long )fd);
  {
  if (___coverage_array[699] == 0) {
    {
    fprintf(_coverage_fout, "699\n");
    fflush(_coverage_fout);
    ___coverage_array[699] = 1;
    }
  }
  }
  if ((unsigned long )key == (unsigned long )((void *)0)) {
    {
    if (___coverage_array[700] == 0) {
      {
      fprintf(_coverage_fout, "700\n");
      fflush(_coverage_fout);
      ___coverage_array[700] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[701] == 0) {
      {
      fprintf(_coverage_fout, "701\n");
      fflush(_coverage_fout);
      ___coverage_array[701] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[702] == 0) {
    {
    fprintf(_coverage_fout, "702\n");
    fflush(_coverage_fout);
    ___coverage_array[702] = 1;
    }
  }
  }
  tmp___1 = PyDict_GetItem(self->dict, key);
  {
  if (___coverage_array[703] == 0) {
    {
    fprintf(_coverage_fout, "703\n");
    fflush(_coverage_fout);
    ___coverage_array[703] = 1;
    }
  }
  }
  if ((unsigned long )tmp___1 == (unsigned long )((void *)0)) {
    {
    if (___coverage_array[704] == 0) {
      {
      fprintf(_coverage_fout, "704\n");
      fflush(_coverage_fout);
      ___coverage_array[704] = 1;
      }
    }
    }
    tmp___0 = __errno_location();
    {
    if (___coverage_array[705] == 0) {
      {
      fprintf(_coverage_fout, "705\n");
      fflush(_coverage_fout);
      ___coverage_array[705] = 1;
      }
    }
    }
    *tmp___0 = 2;
    {
    if (___coverage_array[706] == 0) {
      {
      fprintf(_coverage_fout, "706\n");
      fflush(_coverage_fout);
      ___coverage_array[706] = 1;
      }
    }
    }
    PyErr_SetFromErrno(PyExc_IOError);
    {
    if (___coverage_array[707] == 0) {
      {
      fprintf(_coverage_fout, "707\n");
      fflush(_coverage_fout);
      ___coverage_array[707] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[708] == 0) {
      {
      fprintf(_coverage_fout, "708\n");
      fflush(_coverage_fout);
      ___coverage_array[708] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[709] == 0) {
    {
    fprintf(_coverage_fout, "709\n");
    fflush(_coverage_fout);
    ___coverage_array[709] = 1;
    }
  }
  }
  value = PyLong_FromLong((long )events);
  {
  if (___coverage_array[710] == 0) {
    {
    fprintf(_coverage_fout, "710\n");
    fflush(_coverage_fout);
    ___coverage_array[710] = 1;
    }
  }
  }
  if ((unsigned long )value == (unsigned long )((void *)0)) {
    {
    if (___coverage_array[711] == 0) {
      {
      fprintf(_coverage_fout, "711\n");
      fflush(_coverage_fout);
      ___coverage_array[711] = 1;
      }
    }
    }
    while (1) {
      {
      if (___coverage_array[712] == 0) {
        {
        fprintf(_coverage_fout, "712\n");
        fflush(_coverage_fout);
        ___coverage_array[712] = 1;
        }
      }
      }
      (key->ob_refcnt) --;
      {
      if (___coverage_array[713] == 0) {
        {
        fprintf(_coverage_fout, "713\n");
        fflush(_coverage_fout);
        ___coverage_array[713] = 1;
        }
      }
      }
      if (key->ob_refcnt != 0) {
        {
        if (___coverage_array[714] == 0) {
          {
          fprintf(_coverage_fout, "714\n");
          fflush(_coverage_fout);
          ___coverage_array[714] = 1;
          }
        }
        }

      } else {
        {
        if (___coverage_array[715] == 0) {
          {
          fprintf(_coverage_fout, "715\n");
          fflush(_coverage_fout);
          ___coverage_array[715] = 1;
          }
        }
        }
        (*((key->ob_type)->tp_dealloc))(key);
      }
      {
      if (___coverage_array[716] == 0) {
        {
        fprintf(_coverage_fout, "716\n");
        fflush(_coverage_fout);
        ___coverage_array[716] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[717] == 0) {
      {
      fprintf(_coverage_fout, "717\n");
      fflush(_coverage_fout);
      ___coverage_array[717] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[718] == 0) {
      {
      fprintf(_coverage_fout, "718\n");
      fflush(_coverage_fout);
      ___coverage_array[718] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[719] == 0) {
    {
    fprintf(_coverage_fout, "719\n");
    fflush(_coverage_fout);
    ___coverage_array[719] = 1;
    }
  }
  }
  err = PyDict_SetItem(self->dict, key, value);
  {
  if (___coverage_array[720] == 0) {
    {
    fprintf(_coverage_fout, "720\n");
    fflush(_coverage_fout);
    ___coverage_array[720] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[721] == 0) {
      {
      fprintf(_coverage_fout, "721\n");
      fflush(_coverage_fout);
      ___coverage_array[721] = 1;
      }
    }
    }
    (key->ob_refcnt) --;
    {
    if (___coverage_array[722] == 0) {
      {
      fprintf(_coverage_fout, "722\n");
      fflush(_coverage_fout);
      ___coverage_array[722] = 1;
      }
    }
    }
    if (key->ob_refcnt != 0) {
      {
      if (___coverage_array[723] == 0) {
        {
        fprintf(_coverage_fout, "723\n");
        fflush(_coverage_fout);
        ___coverage_array[723] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[724] == 0) {
        {
        fprintf(_coverage_fout, "724\n");
        fflush(_coverage_fout);
        ___coverage_array[724] = 1;
        }
      }
      }
      (*((key->ob_type)->tp_dealloc))(key);
    }
    {
    if (___coverage_array[725] == 0) {
      {
      fprintf(_coverage_fout, "725\n");
      fflush(_coverage_fout);
      ___coverage_array[725] = 1;
      }
    }
    }
    break;
  }
  {
  if (___coverage_array[726] == 0) {
    {
    fprintf(_coverage_fout, "726\n");
    fflush(_coverage_fout);
    ___coverage_array[726] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[727] == 0) {
      {
      fprintf(_coverage_fout, "727\n");
      fflush(_coverage_fout);
      ___coverage_array[727] = 1;
      }
    }
    }
    (value->ob_refcnt) --;
    {
    if (___coverage_array[728] == 0) {
      {
      fprintf(_coverage_fout, "728\n");
      fflush(_coverage_fout);
      ___coverage_array[728] = 1;
      }
    }
    }
    if (value->ob_refcnt != 0) {
      {
      if (___coverage_array[729] == 0) {
        {
        fprintf(_coverage_fout, "729\n");
        fflush(_coverage_fout);
        ___coverage_array[729] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[730] == 0) {
        {
        fprintf(_coverage_fout, "730\n");
        fflush(_coverage_fout);
        ___coverage_array[730] = 1;
        }
      }
      }
      (*((value->ob_type)->tp_dealloc))(value);
    }
    {
    if (___coverage_array[731] == 0) {
      {
      fprintf(_coverage_fout, "731\n");
      fflush(_coverage_fout);
      ___coverage_array[731] = 1;
      }
    }
    }
    break;
  }
  {
  if (___coverage_array[732] == 0) {
    {
    fprintf(_coverage_fout, "732\n");
    fflush(_coverage_fout);
    ___coverage_array[732] = 1;
    }
  }
  }
  if (err < 0) {
    {
    if (___coverage_array[733] == 0) {
      {
      fprintf(_coverage_fout, "733\n");
      fflush(_coverage_fout);
      ___coverage_array[733] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[734] == 0) {
      {
      fprintf(_coverage_fout, "734\n");
      fflush(_coverage_fout);
      ___coverage_array[734] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[735] == 0) {
    {
    fprintf(_coverage_fout, "735\n");
    fflush(_coverage_fout);
    ___coverage_array[735] = 1;
    }
  }
  }
  self->ufd_uptodate = 0;
  {
  if (___coverage_array[736] == 0) {
    {
    fprintf(_coverage_fout, "736\n");
    fflush(_coverage_fout);
    ___coverage_array[736] = 1;
    }
  }
  }
  (_Py_NoneStruct.ob_refcnt) ++;
  {
  if (___coverage_array[737] == 0) {
    {
    fprintf(_coverage_fout, "737\n");
    fflush(_coverage_fout);
    ___coverage_array[737] = 1;
    }
  }
  }
  return (& _Py_NoneStruct);
}
}
static char poll_unregister_doc[86]  = 
  {      (char )'u',      (char )'n',      (char )'r',      (char )'e', 
        (char )'g',      (char )'i',      (char )'s',      (char )'t', 
        (char )'e',      (char )'r',      (char )'(',      (char )'f', 
        (char )'d',      (char )')',      (char )' ',      (char )'-', 
        (char )'>',      (char )' ',      (char )'N',      (char )'o', 
        (char )'n',      (char )'e',      (char )'\n',      (char )'\n', 
        (char )'R',      (char )'e',      (char )'m',      (char )'o', 
        (char )'v',      (char )'e',      (char )' ',      (char )'a', 
        (char )' ',      (char )'f',      (char )'i',      (char )'l', 
        (char )'e',      (char )' ',      (char )'d',      (char )'e', 
        (char )'s',      (char )'c',      (char )'r',      (char )'i', 
        (char )'p',      (char )'t',      (char )'o',      (char )'r', 
        (char )' ',      (char )'b',      (char )'e',      (char )'i', 
        (char )'n',      (char )'g',      (char )' ',      (char )'t', 
        (char )'r',      (char )'a',      (char )'c',      (char )'k', 
        (char )'e',      (char )'d',      (char )' ',      (char )'b', 
        (char )'y',      (char )' ',      (char )'t',      (char )'h', 
        (char )'e',      (char )' ',      (char )'p',      (char )'o', 
        (char )'l',      (char )'l',      (char )'i',      (char )'n', 
        (char )'g',      (char )' ',      (char )'o',      (char )'b', 
        (char )'j',      (char )'e',      (char )'c',      (char )'t', 
        (char )'.',      (char )'\000'};
static PyObject *poll_unregister(pollObject *self , PyObject *o ) 
{ 
  PyObject *key ;
  int fd ;
  int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[738] == 0) {
    {
    fprintf(_coverage_fout, "738\n");
    fflush(_coverage_fout);
    ___coverage_array[738] = 1;
    }
  }
  }
  fd = PyObject_AsFileDescriptor(o);
  {
  if (___coverage_array[739] == 0) {
    {
    fprintf(_coverage_fout, "739\n");
    fflush(_coverage_fout);
    ___coverage_array[739] = 1;
    }
  }
  }
  if (fd == -1) {
    {
    if (___coverage_array[740] == 0) {
      {
      fprintf(_coverage_fout, "740\n");
      fflush(_coverage_fout);
      ___coverage_array[740] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[741] == 0) {
      {
      fprintf(_coverage_fout, "741\n");
      fflush(_coverage_fout);
      ___coverage_array[741] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[742] == 0) {
    {
    fprintf(_coverage_fout, "742\n");
    fflush(_coverage_fout);
    ___coverage_array[742] = 1;
    }
  }
  }
  key = PyLong_FromLong((long )fd);
  {
  if (___coverage_array[743] == 0) {
    {
    fprintf(_coverage_fout, "743\n");
    fflush(_coverage_fout);
    ___coverage_array[743] = 1;
    }
  }
  }
  if ((unsigned long )key == (unsigned long )((void *)0)) {
    {
    if (___coverage_array[744] == 0) {
      {
      fprintf(_coverage_fout, "744\n");
      fflush(_coverage_fout);
      ___coverage_array[744] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[745] == 0) {
      {
      fprintf(_coverage_fout, "745\n");
      fflush(_coverage_fout);
      ___coverage_array[745] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[746] == 0) {
    {
    fprintf(_coverage_fout, "746\n");
    fflush(_coverage_fout);
    ___coverage_array[746] = 1;
    }
  }
  }
  tmp = PyDict_DelItem(self->dict, key);
  {
  if (___coverage_array[747] == 0) {
    {
    fprintf(_coverage_fout, "747\n");
    fflush(_coverage_fout);
    ___coverage_array[747] = 1;
    }
  }
  }
  if (tmp == -1) {
    {
    if (___coverage_array[748] == 0) {
      {
      fprintf(_coverage_fout, "748\n");
      fflush(_coverage_fout);
      ___coverage_array[748] = 1;
      }
    }
    }
    while (1) {
      {
      if (___coverage_array[749] == 0) {
        {
        fprintf(_coverage_fout, "749\n");
        fflush(_coverage_fout);
        ___coverage_array[749] = 1;
        }
      }
      }
      (key->ob_refcnt) --;
      {
      if (___coverage_array[750] == 0) {
        {
        fprintf(_coverage_fout, "750\n");
        fflush(_coverage_fout);
        ___coverage_array[750] = 1;
        }
      }
      }
      if (key->ob_refcnt != 0) {
        {
        if (___coverage_array[751] == 0) {
          {
          fprintf(_coverage_fout, "751\n");
          fflush(_coverage_fout);
          ___coverage_array[751] = 1;
          }
        }
        }

      } else {
        {
        if (___coverage_array[752] == 0) {
          {
          fprintf(_coverage_fout, "752\n");
          fflush(_coverage_fout);
          ___coverage_array[752] = 1;
          }
        }
        }
        (*((key->ob_type)->tp_dealloc))(key);
      }
      {
      if (___coverage_array[753] == 0) {
        {
        fprintf(_coverage_fout, "753\n");
        fflush(_coverage_fout);
        ___coverage_array[753] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[754] == 0) {
      {
      fprintf(_coverage_fout, "754\n");
      fflush(_coverage_fout);
      ___coverage_array[754] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[755] == 0) {
      {
      fprintf(_coverage_fout, "755\n");
      fflush(_coverage_fout);
      ___coverage_array[755] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[756] == 0) {
    {
    fprintf(_coverage_fout, "756\n");
    fflush(_coverage_fout);
    ___coverage_array[756] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[757] == 0) {
      {
      fprintf(_coverage_fout, "757\n");
      fflush(_coverage_fout);
      ___coverage_array[757] = 1;
      }
    }
    }
    (key->ob_refcnt) --;
    {
    if (___coverage_array[758] == 0) {
      {
      fprintf(_coverage_fout, "758\n");
      fflush(_coverage_fout);
      ___coverage_array[758] = 1;
      }
    }
    }
    if (key->ob_refcnt != 0) {
      {
      if (___coverage_array[759] == 0) {
        {
        fprintf(_coverage_fout, "759\n");
        fflush(_coverage_fout);
        ___coverage_array[759] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[760] == 0) {
        {
        fprintf(_coverage_fout, "760\n");
        fflush(_coverage_fout);
        ___coverage_array[760] = 1;
        }
      }
      }
      (*((key->ob_type)->tp_dealloc))(key);
    }
    {
    if (___coverage_array[761] == 0) {
      {
      fprintf(_coverage_fout, "761\n");
      fflush(_coverage_fout);
      ___coverage_array[761] = 1;
      }
    }
    }
    break;
  }
  {
  if (___coverage_array[762] == 0) {
    {
    fprintf(_coverage_fout, "762\n");
    fflush(_coverage_fout);
    ___coverage_array[762] = 1;
    }
  }
  }
  self->ufd_uptodate = 0;
  {
  if (___coverage_array[763] == 0) {
    {
    fprintf(_coverage_fout, "763\n");
    fflush(_coverage_fout);
    ___coverage_array[763] = 1;
    }
  }
  }
  (_Py_NoneStruct.ob_refcnt) ++;
  {
  if (___coverage_array[764] == 0) {
    {
    fprintf(_coverage_fout, "764\n");
    fflush(_coverage_fout);
    ___coverage_array[764] = 1;
    }
  }
  }
  return (& _Py_NoneStruct);
}
}
static char poll_poll_doc[180]  = 
  {      (char )'p',      (char )'o',      (char )'l',      (char )'l', 
        (char )'(',      (char )' ',      (char )'[',      (char )'t', 
        (char )'i',      (char )'m',      (char )'e',      (char )'o', 
        (char )'u',      (char )'t',      (char )']',      (char )' ', 
        (char )')',      (char )' ',      (char )'-',      (char )'>', 
        (char )' ',      (char )'l',      (char )'i',      (char )'s', 
        (char )'t',      (char )' ',      (char )'o',      (char )'f', 
        (char )' ',      (char )'(',      (char )'f',      (char )'d', 
        (char )',',      (char )' ',      (char )'e',      (char )'v', 
        (char )'e',      (char )'n',      (char )'t',      (char )')', 
        (char )' ',      (char )'2',      (char )'-',      (char )'t', 
        (char )'u',      (char )'p',      (char )'l',      (char )'e', 
        (char )'s',      (char )'\n',      (char )'\n',      (char )'P', 
        (char )'o',      (char )'l',      (char )'l',      (char )'s', 
        (char )' ',      (char )'t',      (char )'h',      (char )'e', 
        (char )' ',      (char )'s',      (char )'e',      (char )'t', 
        (char )' ',      (char )'o',      (char )'f',      (char )' ', 
        (char )'r',      (char )'e',      (char )'g',      (char )'i', 
        (char )'s',      (char )'t',      (char )'e',      (char )'r', 
        (char )'e',      (char )'d',      (char )' ',      (char )'f', 
        (char )'i',      (char )'l',      (char )'e',      (char )' ', 
        (char )'d',      (char )'e',      (char )'s',      (char )'c', 
        (char )'r',      (char )'i',      (char )'p',      (char )'t', 
        (char )'o',      (char )'r',      (char )'s',      (char )',', 
        (char )' ',      (char )'r',      (char )'e',      (char )'t', 
        (char )'u',      (char )'r',      (char )'n',      (char )'i', 
        (char )'n',      (char )'g',      (char )' ',      (char )'a', 
        (char )' ',      (char )'l',      (char )'i',      (char )'s', 
        (char )'t',      (char )' ',      (char )'c',      (char )'o', 
        (char )'n',      (char )'t',      (char )'a',      (char )'i', 
        (char )'n',      (char )'i',      (char )'n',      (char )'g', 
        (char )' ',      (char )'\n',      (char )'a',      (char )'n', 
        (char )'y',      (char )' ',      (char )'d',      (char )'e', 
        (char )'s',      (char )'c',      (char )'r',      (char )'i', 
        (char )'p',      (char )'t',      (char )'o',      (char )'r', 
        (char )'s',      (char )' ',      (char )'t',      (char )'h', 
        (char )'a',      (char )'t',      (char )' ',      (char )'h', 
        (char )'a',      (char )'v',      (char )'e',      (char )' ', 
        (char )'e',      (char )'v',      (char )'e',      (char )'n', 
        (char )'t',      (char )'s',      (char )' ',      (char )'o', 
        (char )'r',      (char )' ',      (char )'e',      (char )'r', 
        (char )'r',      (char )'o',      (char )'r',      (char )'s', 
        (char )' ',      (char )'t',      (char )'o',      (char )' ', 
        (char )'r',      (char )'e',      (char )'p',      (char )'o', 
        (char )'r',      (char )'t',      (char )'.',      (char )'\000'};
static PyObject *poll_poll(pollObject *self , PyObject *args ) 
{ 
  PyObject *result_list ;
  PyObject *tout ;
  int timeout ;
  int poll_result ;
  int i ;
  int j ;
  PyObject *value ;
  PyObject *num ;
  int tmp ;
  long tmp___0 ;
  PyObject *tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  PyThreadState *_save ;
  int tmp___4 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[765] == 0) {
    {
    fprintf(_coverage_fout, "765\n");
    fflush(_coverage_fout);
    ___coverage_array[765] = 1;
    }
  }
  }
  result_list = (PyObject *)((void *)0);
  {
  if (___coverage_array[766] == 0) {
    {
    fprintf(_coverage_fout, "766\n");
    fflush(_coverage_fout);
    ___coverage_array[766] = 1;
    }
  }
  }
  tout = (PyObject *)((void *)0);
  {
  if (___coverage_array[767] == 0) {
    {
    fprintf(_coverage_fout, "767\n");
    fflush(_coverage_fout);
    ___coverage_array[767] = 1;
    }
  }
  }
  timeout = 0;
  {
  if (___coverage_array[768] == 0) {
    {
    fprintf(_coverage_fout, "768\n");
    fflush(_coverage_fout);
    ___coverage_array[768] = 1;
    }
  }
  }
  value = (PyObject *)((void *)0);
  {
  if (___coverage_array[769] == 0) {
    {
    fprintf(_coverage_fout, "769\n");
    fflush(_coverage_fout);
    ___coverage_array[769] = 1;
    }
  }
  }
  num = (PyObject *)((void *)0);
  {
  if (___coverage_array[770] == 0) {
    {
    fprintf(_coverage_fout, "770\n");
    fflush(_coverage_fout);
    ___coverage_array[770] = 1;
    }
  }
  }
  tmp = PyArg_UnpackTuple(args, "poll", 0, 1, & tout);
  {
  if (___coverage_array[771] == 0) {
    {
    fprintf(_coverage_fout, "771\n");
    fflush(_coverage_fout);
    ___coverage_array[771] = 1;
    }
  }
  }
  if (tmp) {
    {
    if (___coverage_array[772] == 0) {
      {
      fprintf(_coverage_fout, "772\n");
      fflush(_coverage_fout);
      ___coverage_array[772] = 1;
      }
    }
    }

  } else {
    {
    if (___coverage_array[773] == 0) {
      {
      fprintf(_coverage_fout, "773\n");
      fflush(_coverage_fout);
      ___coverage_array[773] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  }
  {
  if (___coverage_array[774] == 0) {
    {
    fprintf(_coverage_fout, "774\n");
    fflush(_coverage_fout);
    ___coverage_array[774] = 1;
    }
  }
  }
  if ((unsigned long )tout == (unsigned long )((void *)0)) {
    {
    if (___coverage_array[775] == 0) {
      {
      fprintf(_coverage_fout, "775\n");
      fflush(_coverage_fout);
      ___coverage_array[775] = 1;
      }
    }
    }
    timeout = -1;
  } else {
    {
    if (___coverage_array[776] == 0) {
      {
      fprintf(_coverage_fout, "776\n");
      fflush(_coverage_fout);
      ___coverage_array[776] = 1;
      }
    }
    }
    if ((unsigned long )tout == (unsigned long )(& _Py_NoneStruct)) {
      {
      if (___coverage_array[777] == 0) {
        {
        fprintf(_coverage_fout, "777\n");
        fflush(_coverage_fout);
        ___coverage_array[777] = 1;
        }
      }
      }
      timeout = -1;
    } else {
      {
      if (___coverage_array[778] == 0) {
        {
        fprintf(_coverage_fout, "778\n");
        fflush(_coverage_fout);
        ___coverage_array[778] = 1;
        }
      }
      }
      tmp___2 = PyNumber_Check(tout);
      {
      if (___coverage_array[779] == 0) {
        {
        fprintf(_coverage_fout, "779\n");
        fflush(_coverage_fout);
        ___coverage_array[779] = 1;
        }
      }
      }
      if (tmp___2) {
        {
        if (___coverage_array[780] == 0) {
          {
          fprintf(_coverage_fout, "780\n");
          fflush(_coverage_fout);
          ___coverage_array[780] = 1;
          }
        }
        }
        tout = PyNumber_Long(tout);
        {
        if (___coverage_array[781] == 0) {
          {
          fprintf(_coverage_fout, "781\n");
          fflush(_coverage_fout);
          ___coverage_array[781] = 1;
          }
        }
        }
        if (! tout) {
          {
          if (___coverage_array[782] == 0) {
            {
            fprintf(_coverage_fout, "782\n");
            fflush(_coverage_fout);
            ___coverage_array[782] = 1;
            }
          }
          }
          return ((PyObject *)((void *)0));
        } else {
          {
          if (___coverage_array[783] == 0) {
            {
            fprintf(_coverage_fout, "783\n");
            fflush(_coverage_fout);
            ___coverage_array[783] = 1;
            }
          }
          }

        }
        {
        if (___coverage_array[784] == 0) {
          {
          fprintf(_coverage_fout, "784\n");
          fflush(_coverage_fout);
          ___coverage_array[784] = 1;
          }
        }
        }
        tmp___0 = PyLong_AsLong(tout);
        {
        if (___coverage_array[785] == 0) {
          {
          fprintf(_coverage_fout, "785\n");
          fflush(_coverage_fout);
          ___coverage_array[785] = 1;
          }
        }
        }
        timeout = (int )tmp___0;
        {
        if (___coverage_array[786] == 0) {
          {
          fprintf(_coverage_fout, "786\n");
          fflush(_coverage_fout);
          ___coverage_array[786] = 1;
          }
        }
        }
        while (1) {
          {
          if (___coverage_array[787] == 0) {
            {
            fprintf(_coverage_fout, "787\n");
            fflush(_coverage_fout);
            ___coverage_array[787] = 1;
            }
          }
          }
          (tout->ob_refcnt) --;
          {
          if (___coverage_array[788] == 0) {
            {
            fprintf(_coverage_fout, "788\n");
            fflush(_coverage_fout);
            ___coverage_array[788] = 1;
            }
          }
          }
          if (tout->ob_refcnt != 0) {
            {
            if (___coverage_array[789] == 0) {
              {
              fprintf(_coverage_fout, "789\n");
              fflush(_coverage_fout);
              ___coverage_array[789] = 1;
              }
            }
            }

          } else {
            {
            if (___coverage_array[790] == 0) {
              {
              fprintf(_coverage_fout, "790\n");
              fflush(_coverage_fout);
              ___coverage_array[790] = 1;
              }
            }
            }
            (*((tout->ob_type)->tp_dealloc))(tout);
          }
          {
          if (___coverage_array[791] == 0) {
            {
            fprintf(_coverage_fout, "791\n");
            fflush(_coverage_fout);
            ___coverage_array[791] = 1;
            }
          }
          }
          break;
        }
        {
        if (___coverage_array[792] == 0) {
          {
          fprintf(_coverage_fout, "792\n");
          fflush(_coverage_fout);
          ___coverage_array[792] = 1;
          }
        }
        }
        if (timeout == -1) {
          {
          if (___coverage_array[793] == 0) {
            {
            fprintf(_coverage_fout, "793\n");
            fflush(_coverage_fout);
            ___coverage_array[793] = 1;
            }
          }
          }
          tmp___1 = PyErr_Occurred();
          {
          if (___coverage_array[794] == 0) {
            {
            fprintf(_coverage_fout, "794\n");
            fflush(_coverage_fout);
            ___coverage_array[794] = 1;
            }
          }
          }
          if (tmp___1) {
            {
            if (___coverage_array[795] == 0) {
              {
              fprintf(_coverage_fout, "795\n");
              fflush(_coverage_fout);
              ___coverage_array[795] = 1;
              }
            }
            }
            return ((PyObject *)((void *)0));
          } else {
            {
            if (___coverage_array[796] == 0) {
              {
              fprintf(_coverage_fout, "796\n");
              fflush(_coverage_fout);
              ___coverage_array[796] = 1;
              }
            }
            }

          }
        } else {
          {
          if (___coverage_array[797] == 0) {
            {
            fprintf(_coverage_fout, "797\n");
            fflush(_coverage_fout);
            ___coverage_array[797] = 1;
            }
          }
          }

        }
      } else {
        {
        if (___coverage_array[798] == 0) {
          {
          fprintf(_coverage_fout, "798\n");
          fflush(_coverage_fout);
          ___coverage_array[798] = 1;
          }
        }
        }
        PyErr_SetString(PyExc_TypeError, "timeout must be an integer or None");
        {
        if (___coverage_array[799] == 0) {
          {
          fprintf(_coverage_fout, "799\n");
          fflush(_coverage_fout);
          ___coverage_array[799] = 1;
          }
        }
        }
        return ((PyObject *)((void *)0));
      }
    }
  }
  {
  if (___coverage_array[800] == 0) {
    {
    fprintf(_coverage_fout, "800\n");
    fflush(_coverage_fout);
    ___coverage_array[800] = 1;
    }
  }
  }
  if (! self->ufd_uptodate) {
    {
    if (___coverage_array[801] == 0) {
      {
      fprintf(_coverage_fout, "801\n");
      fflush(_coverage_fout);
      ___coverage_array[801] = 1;
      }
    }
    }
    tmp___3 = update_ufd_array(self);
    {
    if (___coverage_array[802] == 0) {
      {
      fprintf(_coverage_fout, "802\n");
      fflush(_coverage_fout);
      ___coverage_array[802] = 1;
      }
    }
    }
    if (tmp___3 == 0) {
      {
      if (___coverage_array[803] == 0) {
        {
        fprintf(_coverage_fout, "803\n");
        fflush(_coverage_fout);
        ___coverage_array[803] = 1;
        }
      }
      }
      return ((PyObject *)((void *)0));
    } else {
      {
      if (___coverage_array[804] == 0) {
        {
        fprintf(_coverage_fout, "804\n");
        fflush(_coverage_fout);
        ___coverage_array[804] = 1;
        }
      }
      }

    }
  } else {
    {
    if (___coverage_array[805] == 0) {
      {
      fprintf(_coverage_fout, "805\n");
      fflush(_coverage_fout);
      ___coverage_array[805] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[806] == 0) {
    {
    fprintf(_coverage_fout, "806\n");
    fflush(_coverage_fout);
    ___coverage_array[806] = 1;
    }
  }
  }
  _save = PyEval_SaveThread();
  {
  if (___coverage_array[807] == 0) {
    {
    fprintf(_coverage_fout, "807\n");
    fflush(_coverage_fout);
    ___coverage_array[807] = 1;
    }
  }
  }
  poll_result = poll(self->ufds, (nfds_t )self->ufd_len, timeout);
  {
  if (___coverage_array[808] == 0) {
    {
    fprintf(_coverage_fout, "808\n");
    fflush(_coverage_fout);
    ___coverage_array[808] = 1;
    }
  }
  }
  PyEval_RestoreThread(_save);
  {
  if (___coverage_array[809] == 0) {
    {
    fprintf(_coverage_fout, "809\n");
    fflush(_coverage_fout);
    ___coverage_array[809] = 1;
    }
  }
  }
  if (poll_result < 0) {
    {
    if (___coverage_array[810] == 0) {
      {
      fprintf(_coverage_fout, "810\n");
      fflush(_coverage_fout);
      ___coverage_array[810] = 1;
      }
    }
    }
    PyErr_SetFromErrno(SelectError);
    {
    if (___coverage_array[811] == 0) {
      {
      fprintf(_coverage_fout, "811\n");
      fflush(_coverage_fout);
      ___coverage_array[811] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[812] == 0) {
      {
      fprintf(_coverage_fout, "812\n");
      fflush(_coverage_fout);
      ___coverage_array[812] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[813] == 0) {
    {
    fprintf(_coverage_fout, "813\n");
    fflush(_coverage_fout);
    ___coverage_array[813] = 1;
    }
  }
  }
  result_list = PyList_New(poll_result);
  {
  if (___coverage_array[814] == 0) {
    {
    fprintf(_coverage_fout, "814\n");
    fflush(_coverage_fout);
    ___coverage_array[814] = 1;
    }
  }
  }
  if (! result_list) {
    {
    if (___coverage_array[815] == 0) {
      {
      fprintf(_coverage_fout, "815\n");
      fflush(_coverage_fout);
      ___coverage_array[815] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[816] == 0) {
      {
      fprintf(_coverage_fout, "816\n");
      fflush(_coverage_fout);
      ___coverage_array[816] = 1;
      }
    }
    }
    i = 0;
    {
    if (___coverage_array[817] == 0) {
      {
      fprintf(_coverage_fout, "817\n");
      fflush(_coverage_fout);
      ___coverage_array[817] = 1;
      }
    }
    }
    j = 0;
    {
    if (___coverage_array[818] == 0) {
      {
      fprintf(_coverage_fout, "818\n");
      fflush(_coverage_fout);
      ___coverage_array[818] = 1;
      }
    }
    }
    while (1) {
      {
      if (___coverage_array[819] == 0) {
        {
        fprintf(_coverage_fout, "819\n");
        fflush(_coverage_fout);
        ___coverage_array[819] = 1;
        }
      }
      }
      if (j < poll_result) {
        {
        if (___coverage_array[820] == 0) {
          {
          fprintf(_coverage_fout, "820\n");
          fflush(_coverage_fout);
          ___coverage_array[820] = 1;
          }
        }
        }

      } else {
        {
        if (___coverage_array[821] == 0) {
          {
          fprintf(_coverage_fout, "821\n");
          fflush(_coverage_fout);
          ___coverage_array[821] = 1;
          }
        }
        }
        break;
      }
      {
      if (___coverage_array[822] == 0) {
        {
        fprintf(_coverage_fout, "822\n");
        fflush(_coverage_fout);
        ___coverage_array[822] = 1;
        }
      }
      }
      while (1) {
        {
        if (___coverage_array[823] == 0) {
          {
          fprintf(_coverage_fout, "823\n");
          fflush(_coverage_fout);
          ___coverage_array[823] = 1;
          }
        }
        }
        if (! (self->ufds + i)->revents) {
          {
          if (___coverage_array[824] == 0) {
            {
            fprintf(_coverage_fout, "824\n");
            fflush(_coverage_fout);
            ___coverage_array[824] = 1;
            }
          }
          }

        } else {
          {
          if (___coverage_array[825] == 0) {
            {
            fprintf(_coverage_fout, "825\n");
            fflush(_coverage_fout);
            ___coverage_array[825] = 1;
            }
          }
          }
          break;
        }
        {
        if (___coverage_array[826] == 0) {
          {
          fprintf(_coverage_fout, "826\n");
          fflush(_coverage_fout);
          ___coverage_array[826] = 1;
          }
        }
        }
        i ++;
      }
      {
      if (___coverage_array[827] == 0) {
        {
        fprintf(_coverage_fout, "827\n");
        fflush(_coverage_fout);
        ___coverage_array[827] = 1;
        }
      }
      }
      value = PyTuple_New(2);
      {
      if (___coverage_array[828] == 0) {
        {
        fprintf(_coverage_fout, "828\n");
        fflush(_coverage_fout);
        ___coverage_array[828] = 1;
        }
      }
      }
      if ((unsigned long )value == (unsigned long )((void *)0)) {
        {
        if (___coverage_array[829] == 0) {
          {
          fprintf(_coverage_fout, "829\n");
          fflush(_coverage_fout);
          ___coverage_array[829] = 1;
          }
        }
        }
        goto error;
      } else {
        {
        if (___coverage_array[830] == 0) {
          {
          fprintf(_coverage_fout, "830\n");
          fflush(_coverage_fout);
          ___coverage_array[830] = 1;
          }
        }
        }

      }
      {
      if (___coverage_array[831] == 0) {
        {
        fprintf(_coverage_fout, "831\n");
        fflush(_coverage_fout);
        ___coverage_array[831] = 1;
        }
      }
      }
      num = PyLong_FromLong((long )(self->ufds + i)->fd);
      {
      if (___coverage_array[832] == 0) {
        {
        fprintf(_coverage_fout, "832\n");
        fflush(_coverage_fout);
        ___coverage_array[832] = 1;
        }
      }
      }
      if ((unsigned long )num == (unsigned long )((void *)0)) {
        {
        if (___coverage_array[833] == 0) {
          {
          fprintf(_coverage_fout, "833\n");
          fflush(_coverage_fout);
          ___coverage_array[833] = 1;
          }
        }
        }
        while (1) {
          {
          if (___coverage_array[834] == 0) {
            {
            fprintf(_coverage_fout, "834\n");
            fflush(_coverage_fout);
            ___coverage_array[834] = 1;
            }
          }
          }
          (value->ob_refcnt) --;
          {
          if (___coverage_array[835] == 0) {
            {
            fprintf(_coverage_fout, "835\n");
            fflush(_coverage_fout);
            ___coverage_array[835] = 1;
            }
          }
          }
          if (value->ob_refcnt != 0) {
            {
            if (___coverage_array[836] == 0) {
              {
              fprintf(_coverage_fout, "836\n");
              fflush(_coverage_fout);
              ___coverage_array[836] = 1;
              }
            }
            }

          } else {
            {
            if (___coverage_array[837] == 0) {
              {
              fprintf(_coverage_fout, "837\n");
              fflush(_coverage_fout);
              ___coverage_array[837] = 1;
              }
            }
            }
            (*((value->ob_type)->tp_dealloc))(value);
          }
          {
          if (___coverage_array[838] == 0) {
            {
            fprintf(_coverage_fout, "838\n");
            fflush(_coverage_fout);
            ___coverage_array[838] = 1;
            }
          }
          }
          break;
        }
        {
        if (___coverage_array[839] == 0) {
          {
          fprintf(_coverage_fout, "839\n");
          fflush(_coverage_fout);
          ___coverage_array[839] = 1;
          }
        }
        }
        goto error;
      } else {
        {
        if (___coverage_array[840] == 0) {
          {
          fprintf(_coverage_fout, "840\n");
          fflush(_coverage_fout);
          ___coverage_array[840] = 1;
          }
        }
        }

      }
      {
      if (___coverage_array[841] == 0) {
        {
        fprintf(_coverage_fout, "841\n");
        fflush(_coverage_fout);
        ___coverage_array[841] = 1;
        }
      }
      }
      ((PyTupleObject *)value)->ob_item[0] = num;
      {
      if (___coverage_array[842] == 0) {
        {
        fprintf(_coverage_fout, "842\n");
        fflush(_coverage_fout);
        ___coverage_array[842] = 1;
        }
      }
      }
      num = PyLong_FromLong((long )((int )(self->ufds + i)->revents & 65535));
      {
      if (___coverage_array[843] == 0) {
        {
        fprintf(_coverage_fout, "843\n");
        fflush(_coverage_fout);
        ___coverage_array[843] = 1;
        }
      }
      }
      if ((unsigned long )num == (unsigned long )((void *)0)) {
        {
        if (___coverage_array[844] == 0) {
          {
          fprintf(_coverage_fout, "844\n");
          fflush(_coverage_fout);
          ___coverage_array[844] = 1;
          }
        }
        }
        while (1) {
          {
          if (___coverage_array[845] == 0) {
            {
            fprintf(_coverage_fout, "845\n");
            fflush(_coverage_fout);
            ___coverage_array[845] = 1;
            }
          }
          }
          (value->ob_refcnt) --;
          {
          if (___coverage_array[846] == 0) {
            {
            fprintf(_coverage_fout, "846\n");
            fflush(_coverage_fout);
            ___coverage_array[846] = 1;
            }
          }
          }
          if (value->ob_refcnt != 0) {
            {
            if (___coverage_array[847] == 0) {
              {
              fprintf(_coverage_fout, "847\n");
              fflush(_coverage_fout);
              ___coverage_array[847] = 1;
              }
            }
            }

          } else {
            {
            if (___coverage_array[848] == 0) {
              {
              fprintf(_coverage_fout, "848\n");
              fflush(_coverage_fout);
              ___coverage_array[848] = 1;
              }
            }
            }
            (*((value->ob_type)->tp_dealloc))(value);
          }
          {
          if (___coverage_array[849] == 0) {
            {
            fprintf(_coverage_fout, "849\n");
            fflush(_coverage_fout);
            ___coverage_array[849] = 1;
            }
          }
          }
          break;
        }
        {
        if (___coverage_array[850] == 0) {
          {
          fprintf(_coverage_fout, "850\n");
          fflush(_coverage_fout);
          ___coverage_array[850] = 1;
          }
        }
        }
        goto error;
      } else {
        {
        if (___coverage_array[851] == 0) {
          {
          fprintf(_coverage_fout, "851\n");
          fflush(_coverage_fout);
          ___coverage_array[851] = 1;
          }
        }
        }

      }
      {
      if (___coverage_array[852] == 0) {
        {
        fprintf(_coverage_fout, "852\n");
        fflush(_coverage_fout);
        ___coverage_array[852] = 1;
        }
      }
      }
      ((PyTupleObject *)value)->ob_item[1] = num;
      {
      if (___coverage_array[853] == 0) {
        {
        fprintf(_coverage_fout, "853\n");
        fflush(_coverage_fout);
        ___coverage_array[853] = 1;
        }
      }
      }
      tmp___4 = PyList_SetItem(result_list, j, value);
      {
      if (___coverage_array[854] == 0) {
        {
        fprintf(_coverage_fout, "854\n");
        fflush(_coverage_fout);
        ___coverage_array[854] = 1;
        }
      }
      }
      if (tmp___4 == -1) {
        {
        if (___coverage_array[855] == 0) {
          {
          fprintf(_coverage_fout, "855\n");
          fflush(_coverage_fout);
          ___coverage_array[855] = 1;
          }
        }
        }
        while (1) {
          {
          if (___coverage_array[856] == 0) {
            {
            fprintf(_coverage_fout, "856\n");
            fflush(_coverage_fout);
            ___coverage_array[856] = 1;
            }
          }
          }
          (value->ob_refcnt) --;
          {
          if (___coverage_array[857] == 0) {
            {
            fprintf(_coverage_fout, "857\n");
            fflush(_coverage_fout);
            ___coverage_array[857] = 1;
            }
          }
          }
          if (value->ob_refcnt != 0) {
            {
            if (___coverage_array[858] == 0) {
              {
              fprintf(_coverage_fout, "858\n");
              fflush(_coverage_fout);
              ___coverage_array[858] = 1;
              }
            }
            }

          } else {
            {
            if (___coverage_array[859] == 0) {
              {
              fprintf(_coverage_fout, "859\n");
              fflush(_coverage_fout);
              ___coverage_array[859] = 1;
              }
            }
            }
            (*((value->ob_type)->tp_dealloc))(value);
          }
          {
          if (___coverage_array[860] == 0) {
            {
            fprintf(_coverage_fout, "860\n");
            fflush(_coverage_fout);
            ___coverage_array[860] = 1;
            }
          }
          }
          break;
        }
        {
        if (___coverage_array[861] == 0) {
          {
          fprintf(_coverage_fout, "861\n");
          fflush(_coverage_fout);
          ___coverage_array[861] = 1;
          }
        }
        }
        goto error;
      } else {
        {
        if (___coverage_array[862] == 0) {
          {
          fprintf(_coverage_fout, "862\n");
          fflush(_coverage_fout);
          ___coverage_array[862] = 1;
          }
        }
        }

      }
      {
      if (___coverage_array[863] == 0) {
        {
        fprintf(_coverage_fout, "863\n");
        fflush(_coverage_fout);
        ___coverage_array[863] = 1;
        }
      }
      }
      i ++;
      {
      if (___coverage_array[864] == 0) {
        {
        fprintf(_coverage_fout, "864\n");
        fflush(_coverage_fout);
        ___coverage_array[864] = 1;
        }
      }
      }
      j ++;
    }
  }
  {
  if (___coverage_array[865] == 0) {
    {
    fprintf(_coverage_fout, "865\n");
    fflush(_coverage_fout);
    ___coverage_array[865] = 1;
    }
  }
  }
  return (result_list);
  {
  if (___coverage_array[866] == 0) {
    {
    fprintf(_coverage_fout, "866\n");
    fflush(_coverage_fout);
    ___coverage_array[866] = 1;
    }
  }
  }
  error: 
  while (1) {
    {
    if (___coverage_array[867] == 0) {
      {
      fprintf(_coverage_fout, "867\n");
      fflush(_coverage_fout);
      ___coverage_array[867] = 1;
      }
    }
    }
    (result_list->ob_refcnt) --;
    {
    if (___coverage_array[868] == 0) {
      {
      fprintf(_coverage_fout, "868\n");
      fflush(_coverage_fout);
      ___coverage_array[868] = 1;
      }
    }
    }
    if (result_list->ob_refcnt != 0) {
      {
      if (___coverage_array[869] == 0) {
        {
        fprintf(_coverage_fout, "869\n");
        fflush(_coverage_fout);
        ___coverage_array[869] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[870] == 0) {
        {
        fprintf(_coverage_fout, "870\n");
        fflush(_coverage_fout);
        ___coverage_array[870] = 1;
        }
      }
      }
      (*((result_list->ob_type)->tp_dealloc))(result_list);
    }
    {
    if (___coverage_array[871] == 0) {
      {
      fprintf(_coverage_fout, "871\n");
      fflush(_coverage_fout);
      ___coverage_array[871] = 1;
      }
    }
    }
    break;
  }
  {
  if (___coverage_array[872] == 0) {
    {
    fprintf(_coverage_fout, "872\n");
    fflush(_coverage_fout);
    ___coverage_array[872] = 1;
    }
  }
  }
  return ((PyObject *)((void *)0));
}
}
static PyMethodDef poll_methods[5]  = {      {"register", (PyObject *(*)(PyObject * , PyObject * ))(& poll_register), 1,
      (char const   *)(poll_register_doc)}, 
        {"modify", (PyObject *(*)(PyObject * , PyObject * ))(& poll_modify), 1,
      (char const   *)(poll_modify_doc)}, 
        {"unregister",
      (PyObject *(*)(PyObject * , PyObject * ))(& poll_unregister), 8,
      (char const   *)(poll_unregister_doc)}, 
        {"poll", (PyObject *(*)(PyObject * , PyObject * ))(& poll_poll), 1,
      (char const   *)(poll_poll_doc)}, 
        {(char const   *)((void *)0),
      (PyObject *(*)(PyObject * , PyObject * ))((void *)0), 0, (char const   *)0}};
static pollObject *newPollObject(void) 
{ 
  pollObject *self ;
  PyObject *tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[873] == 0) {
    {
    fprintf(_coverage_fout, "873\n");
    fflush(_coverage_fout);
    ___coverage_array[873] = 1;
    }
  }
  }
  tmp = _PyObject_New(& poll_Type);
  {
  if (___coverage_array[874] == 0) {
    {
    fprintf(_coverage_fout, "874\n");
    fflush(_coverage_fout);
    ___coverage_array[874] = 1;
    }
  }
  }
  self = (pollObject *)tmp;
  {
  if (___coverage_array[875] == 0) {
    {
    fprintf(_coverage_fout, "875\n");
    fflush(_coverage_fout);
    ___coverage_array[875] = 1;
    }
  }
  }
  if ((unsigned long )self == (unsigned long )((void *)0)) {
    {
    if (___coverage_array[876] == 0) {
      {
      fprintf(_coverage_fout, "876\n");
      fflush(_coverage_fout);
      ___coverage_array[876] = 1;
      }
    }
    }
    return ((pollObject *)((void *)0));
  } else {
    {
    if (___coverage_array[877] == 0) {
      {
      fprintf(_coverage_fout, "877\n");
      fflush(_coverage_fout);
      ___coverage_array[877] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[878] == 0) {
    {
    fprintf(_coverage_fout, "878\n");
    fflush(_coverage_fout);
    ___coverage_array[878] = 1;
    }
  }
  }
  self->ufd_uptodate = 0;
  {
  if (___coverage_array[879] == 0) {
    {
    fprintf(_coverage_fout, "879\n");
    fflush(_coverage_fout);
    ___coverage_array[879] = 1;
    }
  }
  }
  self->ufds = (struct pollfd *)((void *)0);
  {
  if (___coverage_array[880] == 0) {
    {
    fprintf(_coverage_fout, "880\n");
    fflush(_coverage_fout);
    ___coverage_array[880] = 1;
    }
  }
  }
  self->dict = PyDict_New();
  {
  if (___coverage_array[881] == 0) {
    {
    fprintf(_coverage_fout, "881\n");
    fflush(_coverage_fout);
    ___coverage_array[881] = 1;
    }
  }
  }
  if ((unsigned long )self->dict == (unsigned long )((void *)0)) {
    {
    if (___coverage_array[882] == 0) {
      {
      fprintf(_coverage_fout, "882\n");
      fflush(_coverage_fout);
      ___coverage_array[882] = 1;
      }
    }
    }
    while (1) {
      {
      if (___coverage_array[883] == 0) {
        {
        fprintf(_coverage_fout, "883\n");
        fflush(_coverage_fout);
        ___coverage_array[883] = 1;
        }
      }
      }
      (((PyObject *)self)->ob_refcnt) --;
      {
      if (___coverage_array[884] == 0) {
        {
        fprintf(_coverage_fout, "884\n");
        fflush(_coverage_fout);
        ___coverage_array[884] = 1;
        }
      }
      }
      if (((PyObject *)self)->ob_refcnt != 0) {
        {
        if (___coverage_array[885] == 0) {
          {
          fprintf(_coverage_fout, "885\n");
          fflush(_coverage_fout);
          ___coverage_array[885] = 1;
          }
        }
        }

      } else {
        {
        if (___coverage_array[886] == 0) {
          {
          fprintf(_coverage_fout, "886\n");
          fflush(_coverage_fout);
          ___coverage_array[886] = 1;
          }
        }
        }
        (*((((PyObject *)self)->ob_type)->tp_dealloc))((PyObject *)self);
      }
      {
      if (___coverage_array[887] == 0) {
        {
        fprintf(_coverage_fout, "887\n");
        fflush(_coverage_fout);
        ___coverage_array[887] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[888] == 0) {
      {
      fprintf(_coverage_fout, "888\n");
      fflush(_coverage_fout);
      ___coverage_array[888] = 1;
      }
    }
    }
    return ((pollObject *)((void *)0));
  } else {
    {
    if (___coverage_array[889] == 0) {
      {
      fprintf(_coverage_fout, "889\n");
      fflush(_coverage_fout);
      ___coverage_array[889] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[890] == 0) {
    {
    fprintf(_coverage_fout, "890\n");
    fflush(_coverage_fout);
    ___coverage_array[890] = 1;
    }
  }
  }
  return (self);
}
}
static void poll_dealloc(pollObject *self ) 
{ 


  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[891] == 0) {
    {
    fprintf(_coverage_fout, "891\n");
    fflush(_coverage_fout);
    ___coverage_array[891] = 1;
    }
  }
  }
  if ((unsigned long )self->ufds != (unsigned long )((void *)0)) {
    {
    if (___coverage_array[892] == 0) {
      {
      fprintf(_coverage_fout, "892\n");
      fflush(_coverage_fout);
      ___coverage_array[892] = 1;
      }
    }
    }
    free((void *)self->ufds);
  } else {
    {
    if (___coverage_array[893] == 0) {
      {
      fprintf(_coverage_fout, "893\n");
      fflush(_coverage_fout);
      ___coverage_array[893] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[894] == 0) {
    {
    fprintf(_coverage_fout, "894\n");
    fflush(_coverage_fout);
    ___coverage_array[894] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[895] == 0) {
      {
      fprintf(_coverage_fout, "895\n");
      fflush(_coverage_fout);
      ___coverage_array[895] = 1;
      }
    }
    }
    if ((unsigned long )self->dict == (unsigned long )((void *)0)) {
      {
      if (___coverage_array[896] == 0) {
        {
        fprintf(_coverage_fout, "896\n");
        fflush(_coverage_fout);
        ___coverage_array[896] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[897] == 0) {
        {
        fprintf(_coverage_fout, "897\n");
        fflush(_coverage_fout);
        ___coverage_array[897] = 1;
        }
      }
      }
      while (1) {
        {
        if (___coverage_array[898] == 0) {
          {
          fprintf(_coverage_fout, "898\n");
          fflush(_coverage_fout);
          ___coverage_array[898] = 1;
          }
        }
        }
        ((self->dict)->ob_refcnt) --;
        {
        if (___coverage_array[899] == 0) {
          {
          fprintf(_coverage_fout, "899\n");
          fflush(_coverage_fout);
          ___coverage_array[899] = 1;
          }
        }
        }
        if ((self->dict)->ob_refcnt != 0) {
          {
          if (___coverage_array[900] == 0) {
            {
            fprintf(_coverage_fout, "900\n");
            fflush(_coverage_fout);
            ___coverage_array[900] = 1;
            }
          }
          }

        } else {
          {
          if (___coverage_array[901] == 0) {
            {
            fprintf(_coverage_fout, "901\n");
            fflush(_coverage_fout);
            ___coverage_array[901] = 1;
            }
          }
          }
          (*(((self->dict)->ob_type)->tp_dealloc))(self->dict);
        }
        {
        if (___coverage_array[902] == 0) {
          {
          fprintf(_coverage_fout, "902\n");
          fflush(_coverage_fout);
          ___coverage_array[902] = 1;
          }
        }
        }
        break;
      }
    }
    {
    if (___coverage_array[903] == 0) {
      {
      fprintf(_coverage_fout, "903\n");
      fflush(_coverage_fout);
      ___coverage_array[903] = 1;
      }
    }
    }
    break;
  }
  {
  if (___coverage_array[904] == 0) {
    {
    fprintf(_coverage_fout, "904\n");
    fflush(_coverage_fout);
    ___coverage_array[904] = 1;
    }
  }
  }
  PyObject_Free((void *)self);
  {
  if (___coverage_array[905] == 0) {
    {
    fprintf(_coverage_fout, "905\n");
    fflush(_coverage_fout);
    ___coverage_array[905] = 1;
    }
  }
  }
  return;
}
}
static PyTypeObject poll_Type  = 
     {{{1, (struct _typeobject *)((void *)0)}, 0}, "select.poll",
    (Py_ssize_t )sizeof(pollObject ), 0,
    (void (*)(PyObject * ))(& poll_dealloc),
    (int (*)(PyObject * , FILE * , int  ))0,
    (PyObject *(*)(PyObject * , char * ))0,
    (int (*)(PyObject * , char * , PyObject * ))0, (void *)0,
    (PyObject *(*)(PyObject * ))0, (PyNumberMethods *)0, (PySequenceMethods *)0,
    (PyMappingMethods *)0, (Py_hash_t (*)(PyObject * ))0,
    (PyObject *(*)(PyObject * , PyObject * , PyObject * ))0,
    (PyObject *(*)(PyObject * ))0, (PyObject *(*)(PyObject * , PyObject * ))0,
    (int (*)(PyObject * , PyObject * , PyObject * ))0, (PyBufferProcs *)0,
    1L << 18, (char const   *)0,
    (int (*)(PyObject * , int (*)(PyObject * , void * ) , void * ))0,
    (int (*)(PyObject * ))0, (PyObject *(*)(PyObject * , PyObject * , int  ))0,
    0, (PyObject *(*)(PyObject * ))0, (PyObject *(*)(PyObject * ))0,
    poll_methods, (struct PyMemberDef *)0, (struct PyGetSetDef *)0,
    (struct _typeobject *)0, (PyObject *)0,
    (PyObject *(*)(PyObject * , PyObject * , PyObject * ))0,
    (int (*)(PyObject * , PyObject * , PyObject * ))0, 0,
    (int (*)(PyObject * , PyObject * , PyObject * ))0,
    (PyObject *(*)(struct _typeobject * , Py_ssize_t  ))0,
    (PyObject *(*)(struct _typeobject * , PyObject * , PyObject * ))0,
    (void (*)(void * ))0, (int (*)(PyObject * ))0, (PyObject *)0, (PyObject *)0,
    (PyObject *)0, (PyObject *)0, (PyObject *)0, (void (*)(PyObject * ))0, 0U};
static char poll_doc[127]  = 
  {      (char )'R',      (char )'e',      (char )'t',      (char )'u', 
        (char )'r',      (char )'n',      (char )'s',      (char )' ', 
        (char )'a',      (char )' ',      (char )'p',      (char )'o', 
        (char )'l',      (char )'l',      (char )'i',      (char )'n', 
        (char )'g',      (char )' ',      (char )'o',      (char )'b', 
        (char )'j',      (char )'e',      (char )'c',      (char )'t', 
        (char )',',      (char )' ',      (char )'w',      (char )'h', 
        (char )'i',      (char )'c',      (char )'h',      (char )' ', 
        (char )'s',      (char )'u',      (char )'p',      (char )'p', 
        (char )'o',      (char )'r',      (char )'t',      (char )'s', 
        (char )' ',      (char )'r',      (char )'e',      (char )'g', 
        (char )'i',      (char )'s',      (char )'t',      (char )'e', 
        (char )'r',      (char )'i',      (char )'n',      (char )'g', 
        (char )' ',      (char )'a',      (char )'n',      (char )'d', 
        (char )'\n',      (char )'u',      (char )'n',      (char )'r', 
        (char )'e',      (char )'g',      (char )'i',      (char )'s', 
        (char )'t',      (char )'e',      (char )'r',      (char )'i', 
        (char )'n',      (char )'g',      (char )' ',      (char )'f', 
        (char )'i',      (char )'l',      (char )'e',      (char )' ', 
        (char )'d',      (char )'e',      (char )'s',      (char )'c', 
        (char )'r',      (char )'i',      (char )'p',      (char )'t', 
        (char )'o',      (char )'r',      (char )'s',      (char )',', 
        (char )' ',      (char )'a',      (char )'n',      (char )'d', 
        (char )' ',      (char )'t',      (char )'h',      (char )'e', 
        (char )'n',      (char )' ',      (char )'p',      (char )'o', 
        (char )'l',      (char )'l',      (char )'i',      (char )'n', 
        (char )'g',      (char )' ',      (char )'t',      (char )'h', 
        (char )'e',      (char )'m',      (char )' ',      (char )'f', 
        (char )'o',      (char )'r',      (char )' ',      (char )'I', 
        (char )'/',      (char )'O',      (char )' ',      (char )'e', 
        (char )'v',      (char )'e',      (char )'n',      (char )'t', 
        (char )'s',      (char )'.',      (char )'\000'};
static PyObject *select_poll(PyObject *self , PyObject *unused ) 
{ 
  pollObject *tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[906] == 0) {
    {
    fprintf(_coverage_fout, "906\n");
    fflush(_coverage_fout);
    ___coverage_array[906] = 1;
    }
  }
  }
  tmp = newPollObject();
  {
  if (___coverage_array[907] == 0) {
    {
    fprintf(_coverage_fout, "907\n");
    fflush(_coverage_fout);
    ___coverage_array[907] = 1;
    }
  }
  }
  return ((PyObject *)tmp);
}
}
extern  __attribute__((__nothrow__)) int epoll_create(int __size ) ;
extern  __attribute__((__nothrow__)) int epoll_create1(int __flags ) ;
extern  __attribute__((__nothrow__)) int epoll_ctl(int __epfd , int __op ,
                                                   int __fd ,
                                                   struct epoll_event *__event ) ;
extern int epoll_wait(int __epfd , struct epoll_event *__events ,
                      int __maxevents , int __timeout ) ;
extern int epoll_pwait(int __epfd , struct epoll_event *__events ,
                       int __maxevents , int __timeout ,
                       __sigset_t const   *__ss ) ;
static void pyepoll_dealloc(pyEpoll_Object *self ) ;
static char pyepoll_doc[237] ;
static PyObject *pyepoll_fromfd(PyObject *cls , PyObject *args ) ;
static char pyepoll_fromfd_doc[69] ;
static PyObject *pyepoll_close(pyEpoll_Object *self ) ;
static char pyepoll_close_doc[122] ;
static PyObject *pyepoll_fileno(pyEpoll_Object *self ) ;
static char pyepoll_fileno_doc[59] ;
static PyObject *pyepoll_modify(pyEpoll_Object *self , PyObject *args ,
                                PyObject *kwds ) ;
static char pyepoll_modify_doc[141] ;
static PyObject *pyepoll_register(pyEpoll_Object *self , PyObject *args ,
                                  PyObject *kwds ) ;
static char pyepoll_register_doc[323] ;
static PyObject *pyepoll_unregister(pyEpoll_Object *self , PyObject *args ,
                                    PyObject *kwds ) ;
static char pyepoll_unregister_doc[75] ;
static PyObject *pyepoll_poll(pyEpoll_Object *self , PyObject *args ,
                              PyObject *kwds ) ;
static char pyepoll_poll_doc[236] ;
static PyMethodDef pyepoll_methods[8] ;
static PyObject *pyepoll_get_closed(pyEpoll_Object *self ) ;
static PyGetSetDef pyepoll_getsetlist[2] ;
static PyObject *pyepoll_new(PyTypeObject *type , PyObject *args ,
                             PyObject *kwds ) ;
static PyTypeObject pyEpoll_Type ;
static PyObject *pyepoll_err_closed(void) 
{ 


  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[908] == 0) {
    {
    fprintf(_coverage_fout, "908\n");
    fflush(_coverage_fout);
    ___coverage_array[908] = 1;
    }
  }
  }
  PyErr_SetString(PyExc_ValueError, "I/O operation on closed epoll fd");
  {
  if (___coverage_array[909] == 0) {
    {
    fprintf(_coverage_fout, "909\n");
    fflush(_coverage_fout);
    ___coverage_array[909] = 1;
    }
  }
  }
  return ((PyObject *)((void *)0));
}
}
static int pyepoll_internal_close(pyEpoll_Object *self ) 
{ 
  int save_errno ;
  int epfd ;
  PyThreadState *_save ;
  int *tmp ;
  int tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[910] == 0) {
    {
    fprintf(_coverage_fout, "910\n");
    fflush(_coverage_fout);
    ___coverage_array[910] = 1;
    }
  }
  }
  save_errno = 0;
  {
  if (___coverage_array[911] == 0) {
    {
    fprintf(_coverage_fout, "911\n");
    fflush(_coverage_fout);
    ___coverage_array[911] = 1;
    }
  }
  }
  if (self->epfd >= 0) {
    {
    if (___coverage_array[912] == 0) {
      {
      fprintf(_coverage_fout, "912\n");
      fflush(_coverage_fout);
      ___coverage_array[912] = 1;
      }
    }
    }
    epfd = self->epfd;
    {
    if (___coverage_array[913] == 0) {
      {
      fprintf(_coverage_fout, "913\n");
      fflush(_coverage_fout);
      ___coverage_array[913] = 1;
      }
    }
    }
    self->epfd = -1;
    {
    if (___coverage_array[914] == 0) {
      {
      fprintf(_coverage_fout, "914\n");
      fflush(_coverage_fout);
      ___coverage_array[914] = 1;
      }
    }
    }
    _save = PyEval_SaveThread();
    {
    if (___coverage_array[915] == 0) {
      {
      fprintf(_coverage_fout, "915\n");
      fflush(_coverage_fout);
      ___coverage_array[915] = 1;
      }
    }
    }
    tmp___0 = close(epfd);
    {
    if (___coverage_array[916] == 0) {
      {
      fprintf(_coverage_fout, "916\n");
      fflush(_coverage_fout);
      ___coverage_array[916] = 1;
      }
    }
    }
    if (tmp___0 < 0) {
      {
      if (___coverage_array[917] == 0) {
        {
        fprintf(_coverage_fout, "917\n");
        fflush(_coverage_fout);
        ___coverage_array[917] = 1;
        }
      }
      }
      tmp = __errno_location();
      {
      if (___coverage_array[918] == 0) {
        {
        fprintf(_coverage_fout, "918\n");
        fflush(_coverage_fout);
        ___coverage_array[918] = 1;
        }
      }
      }
      save_errno = *tmp;
    } else {
      {
      if (___coverage_array[919] == 0) {
        {
        fprintf(_coverage_fout, "919\n");
        fflush(_coverage_fout);
        ___coverage_array[919] = 1;
        }
      }
      }

    }
    {
    if (___coverage_array[920] == 0) {
      {
      fprintf(_coverage_fout, "920\n");
      fflush(_coverage_fout);
      ___coverage_array[920] = 1;
      }
    }
    }
    PyEval_RestoreThread(_save);
  } else {
    {
    if (___coverage_array[921] == 0) {
      {
      fprintf(_coverage_fout, "921\n");
      fflush(_coverage_fout);
      ___coverage_array[921] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[922] == 0) {
    {
    fprintf(_coverage_fout, "922\n");
    fflush(_coverage_fout);
    ___coverage_array[922] = 1;
    }
  }
  }
  return (save_errno);
}
}
static PyObject *newPyEpoll_Object(PyTypeObject *type , int sizehint , int fd ) 
{ 
  pyEpoll_Object *self ;
  PyObject *tmp ;
  PyThreadState *_save ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[923] == 0) {
    {
    fprintf(_coverage_fout, "923\n");
    fflush(_coverage_fout);
    ___coverage_array[923] = 1;
    }
  }
  }
  if (sizehint == -1) {
    {
    if (___coverage_array[924] == 0) {
      {
      fprintf(_coverage_fout, "924\n");
      fflush(_coverage_fout);
      ___coverage_array[924] = 1;
      }
    }
    }
    sizehint = 1023;
  } else {
    {
    if (___coverage_array[925] == 0) {
      {
      fprintf(_coverage_fout, "925\n");
      fflush(_coverage_fout);
      ___coverage_array[925] = 1;
      }
    }
    }
    if (sizehint < 1) {
      {
      if (___coverage_array[926] == 0) {
        {
        fprintf(_coverage_fout, "926\n");
        fflush(_coverage_fout);
        ___coverage_array[926] = 1;
        }
      }
      }
      PyErr_Format(PyExc_ValueError, "sizehint must be greater zero, got %d",
                   sizehint);
      {
      if (___coverage_array[927] == 0) {
        {
        fprintf(_coverage_fout, "927\n");
        fflush(_coverage_fout);
        ___coverage_array[927] = 1;
        }
      }
      }
      return ((PyObject *)((void *)0));
    } else {
      {
      if (___coverage_array[928] == 0) {
        {
        fprintf(_coverage_fout, "928\n");
        fflush(_coverage_fout);
        ___coverage_array[928] = 1;
        }
      }
      }

    }
  }
  {
  if (___coverage_array[929] == 0) {
    {
    fprintf(_coverage_fout, "929\n");
    fflush(_coverage_fout);
    ___coverage_array[929] = 1;
    }
  }
  }
  tmp = (*(type->tp_alloc))(type, 0);
  {
  if (___coverage_array[930] == 0) {
    {
    fprintf(_coverage_fout, "930\n");
    fflush(_coverage_fout);
    ___coverage_array[930] = 1;
    }
  }
  }
  self = (pyEpoll_Object *)tmp;
  {
  if (___coverage_array[931] == 0) {
    {
    fprintf(_coverage_fout, "931\n");
    fflush(_coverage_fout);
    ___coverage_array[931] = 1;
    }
  }
  }
  if ((unsigned long )self == (unsigned long )((void *)0)) {
    {
    if (___coverage_array[932] == 0) {
      {
      fprintf(_coverage_fout, "932\n");
      fflush(_coverage_fout);
      ___coverage_array[932] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[933] == 0) {
      {
      fprintf(_coverage_fout, "933\n");
      fflush(_coverage_fout);
      ___coverage_array[933] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[934] == 0) {
    {
    fprintf(_coverage_fout, "934\n");
    fflush(_coverage_fout);
    ___coverage_array[934] = 1;
    }
  }
  }
  if (fd == -1) {
    {
    if (___coverage_array[935] == 0) {
      {
      fprintf(_coverage_fout, "935\n");
      fflush(_coverage_fout);
      ___coverage_array[935] = 1;
      }
    }
    }
    _save = PyEval_SaveThread();
    {
    if (___coverage_array[936] == 0) {
      {
      fprintf(_coverage_fout, "936\n");
      fflush(_coverage_fout);
      ___coverage_array[936] = 1;
      }
    }
    }
    self->epfd = epoll_create(sizehint);
    {
    if (___coverage_array[937] == 0) {
      {
      fprintf(_coverage_fout, "937\n");
      fflush(_coverage_fout);
      ___coverage_array[937] = 1;
      }
    }
    }
    PyEval_RestoreThread(_save);
  } else {
    {
    if (___coverage_array[938] == 0) {
      {
      fprintf(_coverage_fout, "938\n");
      fflush(_coverage_fout);
      ___coverage_array[938] = 1;
      }
    }
    }
    self->epfd = fd;
  }
  {
  if (___coverage_array[939] == 0) {
    {
    fprintf(_coverage_fout, "939\n");
    fflush(_coverage_fout);
    ___coverage_array[939] = 1;
    }
  }
  }
  if (self->epfd < 0) {
    {
    if (___coverage_array[940] == 0) {
      {
      fprintf(_coverage_fout, "940\n");
      fflush(_coverage_fout);
      ___coverage_array[940] = 1;
      }
    }
    }
    while (1) {
      {
      if (___coverage_array[941] == 0) {
        {
        fprintf(_coverage_fout, "941\n");
        fflush(_coverage_fout);
        ___coverage_array[941] = 1;
        }
      }
      }
      (((PyObject *)self)->ob_refcnt) --;
      {
      if (___coverage_array[942] == 0) {
        {
        fprintf(_coverage_fout, "942\n");
        fflush(_coverage_fout);
        ___coverage_array[942] = 1;
        }
      }
      }
      if (((PyObject *)self)->ob_refcnt != 0) {
        {
        if (___coverage_array[943] == 0) {
          {
          fprintf(_coverage_fout, "943\n");
          fflush(_coverage_fout);
          ___coverage_array[943] = 1;
          }
        }
        }

      } else {
        {
        if (___coverage_array[944] == 0) {
          {
          fprintf(_coverage_fout, "944\n");
          fflush(_coverage_fout);
          ___coverage_array[944] = 1;
          }
        }
        }
        (*((((PyObject *)self)->ob_type)->tp_dealloc))((PyObject *)self);
      }
      {
      if (___coverage_array[945] == 0) {
        {
        fprintf(_coverage_fout, "945\n");
        fflush(_coverage_fout);
        ___coverage_array[945] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[946] == 0) {
      {
      fprintf(_coverage_fout, "946\n");
      fflush(_coverage_fout);
      ___coverage_array[946] = 1;
      }
    }
    }
    PyErr_SetFromErrno(PyExc_IOError);
    {
    if (___coverage_array[947] == 0) {
      {
      fprintf(_coverage_fout, "947\n");
      fflush(_coverage_fout);
      ___coverage_array[947] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[948] == 0) {
      {
      fprintf(_coverage_fout, "948\n");
      fflush(_coverage_fout);
      ___coverage_array[948] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[949] == 0) {
    {
    fprintf(_coverage_fout, "949\n");
    fflush(_coverage_fout);
    ___coverage_array[949] = 1;
    }
  }
  }
  return ((PyObject *)self);
}
}
static char *kwlist[2]  = {      (char *)"sizehint",      (char *)((void *)0)};
static PyObject *pyepoll_new(PyTypeObject *type , PyObject *args ,
                             PyObject *kwds ) 
{ 
  int sizehint ;
  int tmp ;
  PyObject *tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[950] == 0) {
    {
    fprintf(_coverage_fout, "950\n");
    fflush(_coverage_fout);
    ___coverage_array[950] = 1;
    }
  }
  }
  sizehint = -1;
  {
  if (___coverage_array[951] == 0) {
    {
    fprintf(_coverage_fout, "951\n");
    fflush(_coverage_fout);
    ___coverage_array[951] = 1;
    }
  }
  }
  tmp = PyArg_ParseTupleAndKeywords(args, kwds, "|i:epoll", kwlist, & sizehint);
  {
  if (___coverage_array[952] == 0) {
    {
    fprintf(_coverage_fout, "952\n");
    fflush(_coverage_fout);
    ___coverage_array[952] = 1;
    }
  }
  }
  if (tmp) {
    {
    if (___coverage_array[953] == 0) {
      {
      fprintf(_coverage_fout, "953\n");
      fflush(_coverage_fout);
      ___coverage_array[953] = 1;
      }
    }
    }

  } else {
    {
    if (___coverage_array[954] == 0) {
      {
      fprintf(_coverage_fout, "954\n");
      fflush(_coverage_fout);
      ___coverage_array[954] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  }
  {
  if (___coverage_array[955] == 0) {
    {
    fprintf(_coverage_fout, "955\n");
    fflush(_coverage_fout);
    ___coverage_array[955] = 1;
    }
  }
  }
  tmp___0 = newPyEpoll_Object(type, sizehint, -1);
  {
  if (___coverage_array[956] == 0) {
    {
    fprintf(_coverage_fout, "956\n");
    fflush(_coverage_fout);
    ___coverage_array[956] = 1;
    }
  }
  }
  return (tmp___0);
}
}
static void pyepoll_dealloc(pyEpoll_Object *self ) 
{ 


  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[957] == 0) {
    {
    fprintf(_coverage_fout, "957\n");
    fflush(_coverage_fout);
    ___coverage_array[957] = 1;
    }
  }
  }
  pyepoll_internal_close(self);
  {
  if (___coverage_array[958] == 0) {
    {
    fprintf(_coverage_fout, "958\n");
    fflush(_coverage_fout);
    ___coverage_array[958] = 1;
    }
  }
  }
  (*((((PyObject *)self)->ob_type)->tp_free))((void *)self);
  {
  if (___coverage_array[959] == 0) {
    {
    fprintf(_coverage_fout, "959\n");
    fflush(_coverage_fout);
    ___coverage_array[959] = 1;
    }
  }
  }
  return;
}
}
static PyObject *pyepoll_close(pyEpoll_Object *self ) 
{ 
  int *tmp ;
  int *tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[960] == 0) {
    {
    fprintf(_coverage_fout, "960\n");
    fflush(_coverage_fout);
    ___coverage_array[960] = 1;
    }
  }
  }
  tmp = __errno_location();
  {
  if (___coverage_array[961] == 0) {
    {
    fprintf(_coverage_fout, "961\n");
    fflush(_coverage_fout);
    ___coverage_array[961] = 1;
    }
  }
  }
  *tmp = pyepoll_internal_close(self);
  {
  if (___coverage_array[962] == 0) {
    {
    fprintf(_coverage_fout, "962\n");
    fflush(_coverage_fout);
    ___coverage_array[962] = 1;
    }
  }
  }
  tmp___0 = __errno_location();
  {
  if (___coverage_array[963] == 0) {
    {
    fprintf(_coverage_fout, "963\n");
    fflush(_coverage_fout);
    ___coverage_array[963] = 1;
    }
  }
  }
  if (*tmp___0 < 0) {
    {
    if (___coverage_array[964] == 0) {
      {
      fprintf(_coverage_fout, "964\n");
      fflush(_coverage_fout);
      ___coverage_array[964] = 1;
      }
    }
    }
    PyErr_SetFromErrno(PyExc_IOError);
    {
    if (___coverage_array[965] == 0) {
      {
      fprintf(_coverage_fout, "965\n");
      fflush(_coverage_fout);
      ___coverage_array[965] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[966] == 0) {
      {
      fprintf(_coverage_fout, "966\n");
      fflush(_coverage_fout);
      ___coverage_array[966] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[967] == 0) {
    {
    fprintf(_coverage_fout, "967\n");
    fflush(_coverage_fout);
    ___coverage_array[967] = 1;
    }
  }
  }
  (_Py_NoneStruct.ob_refcnt) ++;
  {
  if (___coverage_array[968] == 0) {
    {
    fprintf(_coverage_fout, "968\n");
    fflush(_coverage_fout);
    ___coverage_array[968] = 1;
    }
  }
  }
  return (& _Py_NoneStruct);
}
}
static char pyepoll_close_doc[122]  = 
  {      (char )'c',      (char )'l',      (char )'o',      (char )'s', 
        (char )'e',      (char )'(',      (char )')',      (char )' ', 
        (char )'-',      (char )'>',      (char )' ',      (char )'N', 
        (char )'o',      (char )'n',      (char )'e',      (char )'\n', 
        (char )'\n',      (char )'C',      (char )'l',      (char )'o', 
        (char )'s',      (char )'e',      (char )' ',      (char )'t', 
        (char )'h',      (char )'e',      (char )' ',      (char )'e', 
        (char )'p',      (char )'o',      (char )'l',      (char )'l', 
        (char )' ',      (char )'c',      (char )'o',      (char )'n', 
        (char )'t',      (char )'r',      (char )'o',      (char )'l', 
        (char )' ',      (char )'f',      (char )'i',      (char )'l', 
        (char )'e',      (char )' ',      (char )'d',      (char )'e', 
        (char )'s',      (char )'c',      (char )'r',      (char )'i', 
        (char )'p',      (char )'t',      (char )'o',      (char )'r', 
        (char )'.',      (char )' ',      (char )'F',      (char )'u', 
        (char )'r',      (char )'t',      (char )'h',      (char )'e', 
        (char )'r',      (char )' ',      (char )'o',      (char )'p', 
        (char )'e',      (char )'r',      (char )'a',      (char )'t', 
        (char )'i',      (char )'o',      (char )'n',      (char )'s', 
        (char )' ',      (char )'o',      (char )'n',      (char )' ', 
        (char )'t',      (char )'h',      (char )'e',      (char )' ', 
        (char )'e',      (char )'p',      (char )'o',      (char )'l', 
        (char )'l',      (char )'\n',      (char )'o',      (char )'b', 
        (char )'j',      (char )'e',      (char )'c',      (char )'t', 
        (char )' ',      (char )'w',      (char )'i',      (char )'l', 
        (char )'l',      (char )' ',      (char )'r',      (char )'a', 
        (char )'i',      (char )'s',      (char )'e',      (char )' ', 
        (char )'a',      (char )'n',      (char )' ',      (char )'e', 
        (char )'x',      (char )'c',      (char )'e',      (char )'p', 
        (char )'t',      (char )'i',      (char )'o',      (char )'n', 
        (char )'.',      (char )'\000'};
static PyObject *pyepoll_get_closed(pyEpoll_Object *self ) 
{ 


  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[969] == 0) {
    {
    fprintf(_coverage_fout, "969\n");
    fflush(_coverage_fout);
    ___coverage_array[969] = 1;
    }
  }
  }
  if (self->epfd < 0) {
    {
    if (___coverage_array[970] == 0) {
      {
      fprintf(_coverage_fout, "970\n");
      fflush(_coverage_fout);
      ___coverage_array[970] = 1;
      }
    }
    }
    (((PyObject *)(& _Py_TrueStruct))->ob_refcnt) ++;
    {
    if (___coverage_array[971] == 0) {
      {
      fprintf(_coverage_fout, "971\n");
      fflush(_coverage_fout);
      ___coverage_array[971] = 1;
      }
    }
    }
    return ((PyObject *)(& _Py_TrueStruct));
  } else {
    {
    if (___coverage_array[972] == 0) {
      {
      fprintf(_coverage_fout, "972\n");
      fflush(_coverage_fout);
      ___coverage_array[972] = 1;
      }
    }
    }
    (((PyObject *)(& _Py_FalseStruct))->ob_refcnt) ++;
    {
    if (___coverage_array[973] == 0) {
      {
      fprintf(_coverage_fout, "973\n");
      fflush(_coverage_fout);
      ___coverage_array[973] = 1;
      }
    }
    }
    return ((PyObject *)(& _Py_FalseStruct));
  }
}
}
static PyObject *pyepoll_fileno(pyEpoll_Object *self ) 
{ 
  PyObject *tmp ;
  PyObject *tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[974] == 0) {
    {
    fprintf(_coverage_fout, "974\n");
    fflush(_coverage_fout);
    ___coverage_array[974] = 1;
    }
  }
  }
  if (self->epfd < 0) {
    {
    if (___coverage_array[975] == 0) {
      {
      fprintf(_coverage_fout, "975\n");
      fflush(_coverage_fout);
      ___coverage_array[975] = 1;
      }
    }
    }
    tmp = pyepoll_err_closed();
    {
    if (___coverage_array[976] == 0) {
      {
      fprintf(_coverage_fout, "976\n");
      fflush(_coverage_fout);
      ___coverage_array[976] = 1;
      }
    }
    }
    return (tmp);
  } else {
    {
    if (___coverage_array[977] == 0) {
      {
      fprintf(_coverage_fout, "977\n");
      fflush(_coverage_fout);
      ___coverage_array[977] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[978] == 0) {
    {
    fprintf(_coverage_fout, "978\n");
    fflush(_coverage_fout);
    ___coverage_array[978] = 1;
    }
  }
  }
  tmp___0 = PyLong_FromLong((long )self->epfd);
  {
  if (___coverage_array[979] == 0) {
    {
    fprintf(_coverage_fout, "979\n");
    fflush(_coverage_fout);
    ___coverage_array[979] = 1;
    }
  }
  }
  return (tmp___0);
}
}
static char pyepoll_fileno_doc[59]  = 
  {      (char )'f',      (char )'i',      (char )'l',      (char )'e', 
        (char )'n',      (char )'o',      (char )'(',      (char )')', 
        (char )' ',      (char )'-',      (char )'>',      (char )' ', 
        (char )'i',      (char )'n',      (char )'t',      (char )'\n', 
        (char )'\n',      (char )'R',      (char )'e',      (char )'t', 
        (char )'u',      (char )'r',      (char )'n',      (char )' ', 
        (char )'t',      (char )'h',      (char )'e',      (char )' ', 
        (char )'e',      (char )'p',      (char )'o',      (char )'l', 
        (char )'l',      (char )' ',      (char )'c',      (char )'o', 
        (char )'n',      (char )'t',      (char )'r',      (char )'o', 
        (char )'l',      (char )' ',      (char )'f',      (char )'i', 
        (char )'l',      (char )'e',      (char )' ',      (char )'d', 
        (char )'e',      (char )'s',      (char )'c',      (char )'r', 
        (char )'i',      (char )'p',      (char )'t',      (char )'o', 
        (char )'r',      (char )'.',      (char )'\000'};
static PyObject *pyepoll_fromfd(PyObject *cls , PyObject *args ) 
{ 
  int fd ;
  int tmp ;
  PyObject *tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[980] == 0) {
    {
    fprintf(_coverage_fout, "980\n");
    fflush(_coverage_fout);
    ___coverage_array[980] = 1;
    }
  }
  }
  tmp = PyArg_ParseTuple(args, "i:fromfd", & fd);
  {
  if (___coverage_array[981] == 0) {
    {
    fprintf(_coverage_fout, "981\n");
    fflush(_coverage_fout);
    ___coverage_array[981] = 1;
    }
  }
  }
  if (tmp) {
    {
    if (___coverage_array[982] == 0) {
      {
      fprintf(_coverage_fout, "982\n");
      fflush(_coverage_fout);
      ___coverage_array[982] = 1;
      }
    }
    }

  } else {
    {
    if (___coverage_array[983] == 0) {
      {
      fprintf(_coverage_fout, "983\n");
      fflush(_coverage_fout);
      ___coverage_array[983] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  }
  {
  if (___coverage_array[984] == 0) {
    {
    fprintf(_coverage_fout, "984\n");
    fflush(_coverage_fout);
    ___coverage_array[984] = 1;
    }
  }
  }
  tmp___0 = newPyEpoll_Object((PyTypeObject *)cls, -1, fd);
  {
  if (___coverage_array[985] == 0) {
    {
    fprintf(_coverage_fout, "985\n");
    fflush(_coverage_fout);
    ___coverage_array[985] = 1;
    }
  }
  }
  return (tmp___0);
}
}
static char pyepoll_fromfd_doc[69]  = 
  {      (char )'f',      (char )'r',      (char )'o',      (char )'m', 
        (char )'f',      (char )'d',      (char )'(',      (char )'f', 
        (char )'d',      (char )')',      (char )' ',      (char )'-', 
        (char )'>',      (char )' ',      (char )'e',      (char )'p', 
        (char )'o',      (char )'l',      (char )'l',      (char )'\n', 
        (char )'\n',      (char )'C',      (char )'r',      (char )'e', 
        (char )'a',      (char )'t',      (char )'e',      (char )' ', 
        (char )'a',      (char )'n',      (char )' ',      (char )'e', 
        (char )'p',      (char )'o',      (char )'l',      (char )'l', 
        (char )' ',      (char )'o',      (char )'b',      (char )'j', 
        (char )'e',      (char )'c',      (char )'t',      (char )' ', 
        (char )'f',      (char )'r',      (char )'o',      (char )'m', 
        (char )' ',      (char )'a',      (char )' ',      (char )'g', 
        (char )'i',      (char )'v',      (char )'e',      (char )'n', 
        (char )' ',      (char )'c',      (char )'o',      (char )'n', 
        (char )'t',      (char )'r',      (char )'o',      (char )'l', 
        (char )' ',      (char )'f',      (char )'d',      (char )'.', 
        (char )'\000'};
static PyObject *pyepoll_internal_ctl(int epfd , int op , PyObject *pfd ,
                                      unsigned int events ) 
{ 
  struct epoll_event ev ;
  int result ;
  int fd ;
  PyObject *tmp ;
  PyThreadState *_save ;
  PyThreadState *_save___0 ;
  int *tmp___0 ;
  int *tmp___1 ;
  int *tmp___2 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[986] == 0) {
    {
    fprintf(_coverage_fout, "986\n");
    fflush(_coverage_fout);
    ___coverage_array[986] = 1;
    }
  }
  }
  if (epfd < 0) {
    {
    if (___coverage_array[987] == 0) {
      {
      fprintf(_coverage_fout, "987\n");
      fflush(_coverage_fout);
      ___coverage_array[987] = 1;
      }
    }
    }
    tmp = pyepoll_err_closed();
    {
    if (___coverage_array[988] == 0) {
      {
      fprintf(_coverage_fout, "988\n");
      fflush(_coverage_fout);
      ___coverage_array[988] = 1;
      }
    }
    }
    return (tmp);
  } else {
    {
    if (___coverage_array[989] == 0) {
      {
      fprintf(_coverage_fout, "989\n");
      fflush(_coverage_fout);
      ___coverage_array[989] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[990] == 0) {
    {
    fprintf(_coverage_fout, "990\n");
    fflush(_coverage_fout);
    ___coverage_array[990] = 1;
    }
  }
  }
  fd = PyObject_AsFileDescriptor(pfd);
  {
  if (___coverage_array[991] == 0) {
    {
    fprintf(_coverage_fout, "991\n");
    fflush(_coverage_fout);
    ___coverage_array[991] = 1;
    }
  }
  }
  if (fd == -1) {
    {
    if (___coverage_array[992] == 0) {
      {
      fprintf(_coverage_fout, "992\n");
      fflush(_coverage_fout);
      ___coverage_array[992] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[993] == 0) {
      {
      fprintf(_coverage_fout, "993\n");
      fflush(_coverage_fout);
      ___coverage_array[993] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[994] == 0) {
    {
    fprintf(_coverage_fout, "994\n");
    fflush(_coverage_fout);
    ___coverage_array[994] = 1;
    }
  }
  }
  switch (op) {
  {
  if (___coverage_array[995] == 0) {
    {
    fprintf(_coverage_fout, "995\n");
    fflush(_coverage_fout);
    ___coverage_array[995] = 1;
    }
  }
  }
  case 3: 
  case 1: 
  ev.events = events;
  {
  if (___coverage_array[996] == 0) {
    {
    fprintf(_coverage_fout, "996\n");
    fflush(_coverage_fout);
    ___coverage_array[996] = 1;
    }
  }
  }
  ev.data.fd = fd;
  {
  if (___coverage_array[997] == 0) {
    {
    fprintf(_coverage_fout, "997\n");
    fflush(_coverage_fout);
    ___coverage_array[997] = 1;
    }
  }
  }
  _save = PyEval_SaveThread();
  {
  if (___coverage_array[998] == 0) {
    {
    fprintf(_coverage_fout, "998\n");
    fflush(_coverage_fout);
    ___coverage_array[998] = 1;
    }
  }
  }
  result = epoll_ctl(epfd, op, fd, & ev);
  {
  if (___coverage_array[999] == 0) {
    {
    fprintf(_coverage_fout, "999\n");
    fflush(_coverage_fout);
    ___coverage_array[999] = 1;
    }
  }
  }
  PyEval_RestoreThread(_save);
  {
  if (___coverage_array[1000] == 0) {
    {
    fprintf(_coverage_fout, "1000\n");
    fflush(_coverage_fout);
    ___coverage_array[1000] = 1;
    }
  }
  }
  break;
  {
  if (___coverage_array[1001] == 0) {
    {
    fprintf(_coverage_fout, "1001\n");
    fflush(_coverage_fout);
    ___coverage_array[1001] = 1;
    }
  }
  }
  case 2: 
  _save___0 = PyEval_SaveThread();
  {
  if (___coverage_array[1002] == 0) {
    {
    fprintf(_coverage_fout, "1002\n");
    fflush(_coverage_fout);
    ___coverage_array[1002] = 1;
    }
  }
  }
  result = epoll_ctl(epfd, op, fd, & ev);
  {
  if (___coverage_array[1003] == 0) {
    {
    fprintf(_coverage_fout, "1003\n");
    fflush(_coverage_fout);
    ___coverage_array[1003] = 1;
    }
  }
  }
  tmp___1 = __errno_location();
  {
  if (___coverage_array[1004] == 0) {
    {
    fprintf(_coverage_fout, "1004\n");
    fflush(_coverage_fout);
    ___coverage_array[1004] = 1;
    }
  }
  }
  if (*tmp___1 == 9) {
    {
    if (___coverage_array[1005] == 0) {
      {
      fprintf(_coverage_fout, "1005\n");
      fflush(_coverage_fout);
      ___coverage_array[1005] = 1;
      }
    }
    }
    result = 0;
    {
    if (___coverage_array[1006] == 0) {
      {
      fprintf(_coverage_fout, "1006\n");
      fflush(_coverage_fout);
      ___coverage_array[1006] = 1;
      }
    }
    }
    tmp___0 = __errno_location();
    {
    if (___coverage_array[1007] == 0) {
      {
      fprintf(_coverage_fout, "1007\n");
      fflush(_coverage_fout);
      ___coverage_array[1007] = 1;
      }
    }
    }
    *tmp___0 = 0;
  } else {
    {
    if (___coverage_array[1008] == 0) {
      {
      fprintf(_coverage_fout, "1008\n");
      fflush(_coverage_fout);
      ___coverage_array[1008] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[1009] == 0) {
    {
    fprintf(_coverage_fout, "1009\n");
    fflush(_coverage_fout);
    ___coverage_array[1009] = 1;
    }
  }
  }
  PyEval_RestoreThread(_save___0);
  {
  if (___coverage_array[1010] == 0) {
    {
    fprintf(_coverage_fout, "1010\n");
    fflush(_coverage_fout);
    ___coverage_array[1010] = 1;
    }
  }
  }
  break;
  {
  if (___coverage_array[1011] == 0) {
    {
    fprintf(_coverage_fout, "1011\n");
    fflush(_coverage_fout);
    ___coverage_array[1011] = 1;
    }
  }
  }
  default: 
  result = -1;
  {
  if (___coverage_array[1012] == 0) {
    {
    fprintf(_coverage_fout, "1012\n");
    fflush(_coverage_fout);
    ___coverage_array[1012] = 1;
    }
  }
  }
  tmp___2 = __errno_location();
  {
  if (___coverage_array[1013] == 0) {
    {
    fprintf(_coverage_fout, "1013\n");
    fflush(_coverage_fout);
    ___coverage_array[1013] = 1;
    }
  }
  }
  *tmp___2 = 22;
  }
  {
  if (___coverage_array[1014] == 0) {
    {
    fprintf(_coverage_fout, "1014\n");
    fflush(_coverage_fout);
    ___coverage_array[1014] = 1;
    }
  }
  }
  if (result < 0) {
    {
    if (___coverage_array[1015] == 0) {
      {
      fprintf(_coverage_fout, "1015\n");
      fflush(_coverage_fout);
      ___coverage_array[1015] = 1;
      }
    }
    }
    PyErr_SetFromErrno(PyExc_IOError);
    {
    if (___coverage_array[1016] == 0) {
      {
      fprintf(_coverage_fout, "1016\n");
      fflush(_coverage_fout);
      ___coverage_array[1016] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[1017] == 0) {
      {
      fprintf(_coverage_fout, "1017\n");
      fflush(_coverage_fout);
      ___coverage_array[1017] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[1018] == 0) {
    {
    fprintf(_coverage_fout, "1018\n");
    fflush(_coverage_fout);
    ___coverage_array[1018] = 1;
    }
  }
  }
  (_Py_NoneStruct.ob_refcnt) ++;
  {
  if (___coverage_array[1019] == 0) {
    {
    fprintf(_coverage_fout, "1019\n");
    fflush(_coverage_fout);
    ___coverage_array[1019] = 1;
    }
  }
  }
  return (& _Py_NoneStruct);
}
}
static char *kwlist___0[3]  = {      (char *)"fd",      (char *)"eventmask",      (char *)((void *)0)};
static PyObject *pyepoll_register(pyEpoll_Object *self , PyObject *args ,
                                  PyObject *kwds ) 
{ 
  PyObject *pfd ;
  unsigned int events ;
  int tmp ;
  PyObject *tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[1020] == 0) {
    {
    fprintf(_coverage_fout, "1020\n");
    fflush(_coverage_fout);
    ___coverage_array[1020] = 1;
    }
  }
  }
  events = 7U;
  {
  if (___coverage_array[1021] == 0) {
    {
    fprintf(_coverage_fout, "1021\n");
    fflush(_coverage_fout);
    ___coverage_array[1021] = 1;
    }
  }
  }
  tmp = PyArg_ParseTupleAndKeywords(args, kwds, "O|I:register", kwlist___0,
                                    & pfd, & events);
  {
  if (___coverage_array[1022] == 0) {
    {
    fprintf(_coverage_fout, "1022\n");
    fflush(_coverage_fout);
    ___coverage_array[1022] = 1;
    }
  }
  }
  if (tmp) {
    {
    if (___coverage_array[1023] == 0) {
      {
      fprintf(_coverage_fout, "1023\n");
      fflush(_coverage_fout);
      ___coverage_array[1023] = 1;
      }
    }
    }

  } else {
    {
    if (___coverage_array[1024] == 0) {
      {
      fprintf(_coverage_fout, "1024\n");
      fflush(_coverage_fout);
      ___coverage_array[1024] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  }
  {
  if (___coverage_array[1025] == 0) {
    {
    fprintf(_coverage_fout, "1025\n");
    fflush(_coverage_fout);
    ___coverage_array[1025] = 1;
    }
  }
  }
  tmp___0 = pyepoll_internal_ctl(self->epfd, 1, pfd, events);
  {
  if (___coverage_array[1026] == 0) {
    {
    fprintf(_coverage_fout, "1026\n");
    fflush(_coverage_fout);
    ___coverage_array[1026] = 1;
    }
  }
  }
  return (tmp___0);
}
}
static char pyepoll_register_doc[323]  = 
  {      (char )'r',      (char )'e',      (char )'g',      (char )'i', 
        (char )'s',      (char )'t',      (char )'e',      (char )'r', 
        (char )'(',      (char )'f',      (char )'d',      (char )'[', 
        (char )',',      (char )' ',      (char )'e',      (char )'v', 
        (char )'e',      (char )'n',      (char )'t',      (char )'m', 
        (char )'a',      (char )'s',      (char )'k',      (char )']', 
        (char )')',      (char )' ',      (char )'-',      (char )'>', 
        (char )' ',      (char )'N',      (char )'o',      (char )'n', 
        (char )'e',      (char )'\n',      (char )'\n',      (char )'R', 
        (char )'e',      (char )'g',      (char )'i',      (char )'s', 
        (char )'t',      (char )'e',      (char )'r',      (char )'s', 
        (char )' ',      (char )'a',      (char )' ',      (char )'n', 
        (char )'e',      (char )'w',      (char )' ',      (char )'f', 
        (char )'d',      (char )' ',      (char )'o',      (char )'r', 
        (char )' ',      (char )'m',      (char )'o',      (char )'d', 
        (char )'i',      (char )'f',      (char )'i',      (char )'e', 
        (char )'s',      (char )' ',      (char )'a',      (char )'n', 
        (char )' ',      (char )'a',      (char )'l',      (char )'r', 
        (char )'e',      (char )'a',      (char )'d',      (char )'y', 
        (char )' ',      (char )'r',      (char )'e',      (char )'g', 
        (char )'i',      (char )'s',      (char )'t',      (char )'e', 
        (char )'r',      (char )'e',      (char )'d',      (char )' ', 
        (char )'f',      (char )'d',      (char )'.',      (char )'\n', 
        (char )'f',      (char )'d',      (char )' ',      (char )'i', 
        (char )'s',      (char )' ',      (char )'t',      (char )'h', 
        (char )'e',      (char )' ',      (char )'t',      (char )'a', 
        (char )'r',      (char )'g',      (char )'e',      (char )'t', 
        (char )' ',      (char )'f',      (char )'i',      (char )'l', 
        (char )'e',      (char )' ',      (char )'d',      (char )'e', 
        (char )'s',      (char )'c',      (char )'r',      (char )'i', 
        (char )'p',      (char )'t',      (char )'o',      (char )'r', 
        (char )' ',      (char )'o',      (char )'f',      (char )' ', 
        (char )'t',      (char )'h',      (char )'e',      (char )' ', 
        (char )'o',      (char )'p',      (char )'e',      (char )'r', 
        (char )'a',      (char )'t',      (char )'i',      (char )'o', 
        (char )'n',      (char )'.',      (char )'\n',      (char )'e', 
        (char )'v',      (char )'e',      (char )'n',      (char )'t', 
        (char )'s',      (char )' ',      (char )'i',      (char )'s', 
        (char )' ',      (char )'a',      (char )' ',      (char )'b', 
        (char )'i',      (char )'t',      (char )' ',      (char )'s', 
        (char )'e',      (char )'t',      (char )' ',      (char )'c', 
        (char )'o',      (char )'m',      (char )'p',      (char )'o', 
        (char )'s',      (char )'e',      (char )'d',      (char )' ', 
        (char )'o',      (char )'f',      (char )' ',      (char )'t', 
        (char )'h',      (char )'e',      (char )' ',      (char )'v', 
        (char )'a',      (char )'r',      (char )'i',      (char )'o', 
        (char )'u',      (char )'s',      (char )' ',      (char )'E', 
        (char )'P',      (char )'O',      (char )'L',      (char )'L', 
        (char )' ',      (char )'c',      (char )'o',      (char )'n', 
        (char )'s',      (char )'t',      (char )'a',      (char )'n', 
        (char )'t',      (char )'s',      (char )';',      (char )' ', 
        (char )'t',      (char )'h',      (char )'e',      (char )' ', 
        (char )'d',      (char )'e',      (char )'f',      (char )'a', 
        (char )'u',      (char )'l',      (char )'t',      (char )'\n', 
        (char )'i',      (char )'s',      (char )' ',      (char )'E', 
        (char )'P',      (char )'O',      (char )'L',      (char )'L', 
        (char )'_',      (char )'I',      (char )'N',      (char )' ', 
        (char )'|',      (char )' ',      (char )'E',      (char )'P', 
        (char )'O',      (char )'L',      (char )'L',      (char )'_', 
        (char )'O',      (char )'U',      (char )'T',      (char )' ', 
        (char )'|',      (char )' ',      (char )'E',      (char )'P', 
        (char )'O',      (char )'L',      (char )'L',      (char )'_', 
        (char )'P',      (char )'R',      (char )'I',      (char )'.', 
        (char )'\n',      (char )'\n',      (char )'T',      (char )'h', 
        (char )'e',      (char )' ',      (char )'e',      (char )'p', 
        (char )'o',      (char )'l',      (char )'l',      (char )' ', 
        (char )'i',      (char )'n',      (char )'t',      (char )'e', 
        (char )'r',      (char )'f',      (char )'a',      (char )'c', 
        (char )'e',      (char )' ',      (char )'s',      (char )'u', 
        (char )'p',      (char )'p',      (char )'o',      (char )'r', 
        (char )'t',      (char )'s',      (char )' ',      (char )'a', 
        (char )'l',      (char )'l',      (char )' ',      (char )'f', 
        (char )'i',      (char )'l',      (char )'e',      (char )' ', 
        (char )'d',      (char )'e',      (char )'s',      (char )'c', 
        (char )'r',      (char )'i',      (char )'p',      (char )'t', 
        (char )'o',      (char )'r',      (char )'s',      (char )' ', 
        (char )'t',      (char )'h',      (char )'a',      (char )'t', 
        (char )' ',      (char )'s',      (char )'u',      (char )'p', 
        (char )'p',      (char )'o',      (char )'r',      (char )'t', 
        (char )' ',      (char )'p',      (char )'o',      (char )'l', 
        (char )'l',      (char )'.',      (char )'\000'};
static char *kwlist___1[3]  = {      (char *)"fd",      (char *)"eventmask",      (char *)((void *)0)};
static PyObject *pyepoll_modify(pyEpoll_Object *self , PyObject *args ,
                                PyObject *kwds ) 
{ 
  PyObject *pfd ;
  unsigned int events ;
  int tmp ;
  PyObject *tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[1027] == 0) {
    {
    fprintf(_coverage_fout, "1027\n");
    fflush(_coverage_fout);
    ___coverage_array[1027] = 1;
    }
  }
  }
  tmp = PyArg_ParseTupleAndKeywords(args, kwds, "OI:modify", kwlist___1, & pfd,
                                    & events);
  {
  if (___coverage_array[1028] == 0) {
    {
    fprintf(_coverage_fout, "1028\n");
    fflush(_coverage_fout);
    ___coverage_array[1028] = 1;
    }
  }
  }
  if (tmp) {
    {
    if (___coverage_array[1029] == 0) {
      {
      fprintf(_coverage_fout, "1029\n");
      fflush(_coverage_fout);
      ___coverage_array[1029] = 1;
      }
    }
    }

  } else {
    {
    if (___coverage_array[1030] == 0) {
      {
      fprintf(_coverage_fout, "1030\n");
      fflush(_coverage_fout);
      ___coverage_array[1030] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  }
  {
  if (___coverage_array[1031] == 0) {
    {
    fprintf(_coverage_fout, "1031\n");
    fflush(_coverage_fout);
    ___coverage_array[1031] = 1;
    }
  }
  }
  tmp___0 = pyepoll_internal_ctl(self->epfd, 3, pfd, events);
  {
  if (___coverage_array[1032] == 0) {
    {
    fprintf(_coverage_fout, "1032\n");
    fflush(_coverage_fout);
    ___coverage_array[1032] = 1;
    }
  }
  }
  return (tmp___0);
}
}
static char pyepoll_modify_doc[141]  = 
  {      (char )'m',      (char )'o',      (char )'d',      (char )'i', 
        (char )'f',      (char )'y',      (char )'(',      (char )'f', 
        (char )'d',      (char )',',      (char )' ',      (char )'e', 
        (char )'v',      (char )'e',      (char )'n',      (char )'t', 
        (char )'m',      (char )'a',      (char )'s',      (char )'k', 
        (char )')',      (char )' ',      (char )'-',      (char )'>', 
        (char )' ',      (char )'N',      (char )'o',      (char )'n', 
        (char )'e',      (char )'\n',      (char )'\n',      (char )'f', 
        (char )'d',      (char )' ',      (char )'i',      (char )'s', 
        (char )' ',      (char )'t',      (char )'h',      (char )'e', 
        (char )' ',      (char )'t',      (char )'a',      (char )'r', 
        (char )'g',      (char )'e',      (char )'t',      (char )' ', 
        (char )'f',      (char )'i',      (char )'l',      (char )'e', 
        (char )' ',      (char )'d',      (char )'e',      (char )'s', 
        (char )'c',      (char )'r',      (char )'i',      (char )'p', 
        (char )'t',      (char )'o',      (char )'r',      (char )' ', 
        (char )'o',      (char )'f',      (char )' ',      (char )'t', 
        (char )'h',      (char )'e',      (char )' ',      (char )'o', 
        (char )'p',      (char )'e',      (char )'r',      (char )'a', 
        (char )'t',      (char )'i',      (char )'o',      (char )'n', 
        (char )'\n',      (char )'e',      (char )'v',      (char )'e', 
        (char )'n',      (char )'t',      (char )'s',      (char )' ', 
        (char )'i',      (char )'s',      (char )' ',      (char )'a', 
        (char )' ',      (char )'b',      (char )'i',      (char )'t', 
        (char )' ',      (char )'s',      (char )'e',      (char )'t', 
        (char )' ',      (char )'c',      (char )'o',      (char )'m', 
        (char )'p',      (char )'o',      (char )'s',      (char )'e', 
        (char )'d',      (char )' ',      (char )'o',      (char )'f', 
        (char )' ',      (char )'t',      (char )'h',      (char )'e', 
        (char )' ',      (char )'v',      (char )'a',      (char )'r', 
        (char )'i',      (char )'o',      (char )'u',      (char )'s', 
        (char )' ',      (char )'E',      (char )'P',      (char )'O', 
        (char )'L',      (char )'L',      (char )' ',      (char )'c', 
        (char )'o',      (char )'n',      (char )'s',      (char )'t', 
        (char )'a',      (char )'n',      (char )'t',      (char )'s', 
        (char )'\000'};
static char *kwlist___2[2]  = {      (char *)"fd",      (char *)((void *)0)};
static PyObject *pyepoll_unregister(pyEpoll_Object *self , PyObject *args ,
                                    PyObject *kwds ) 
{ 
  PyObject *pfd ;
  int tmp ;
  PyObject *tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[1033] == 0) {
    {
    fprintf(_coverage_fout, "1033\n");
    fflush(_coverage_fout);
    ___coverage_array[1033] = 1;
    }
  }
  }
  tmp = PyArg_ParseTupleAndKeywords(args, kwds, "O:unregister", kwlist___2,
                                    & pfd);
  {
  if (___coverage_array[1034] == 0) {
    {
    fprintf(_coverage_fout, "1034\n");
    fflush(_coverage_fout);
    ___coverage_array[1034] = 1;
    }
  }
  }
  if (tmp) {
    {
    if (___coverage_array[1035] == 0) {
      {
      fprintf(_coverage_fout, "1035\n");
      fflush(_coverage_fout);
      ___coverage_array[1035] = 1;
      }
    }
    }

  } else {
    {
    if (___coverage_array[1036] == 0) {
      {
      fprintf(_coverage_fout, "1036\n");
      fflush(_coverage_fout);
      ___coverage_array[1036] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  }
  {
  if (___coverage_array[1037] == 0) {
    {
    fprintf(_coverage_fout, "1037\n");
    fflush(_coverage_fout);
    ___coverage_array[1037] = 1;
    }
  }
  }
  tmp___0 = pyepoll_internal_ctl(self->epfd, 2, pfd, 0U);
  {
  if (___coverage_array[1038] == 0) {
    {
    fprintf(_coverage_fout, "1038\n");
    fflush(_coverage_fout);
    ___coverage_array[1038] = 1;
    }
  }
  }
  return (tmp___0);
}
}
static char pyepoll_unregister_doc[75]  = 
  {      (char )'u',      (char )'n',      (char )'r',      (char )'e', 
        (char )'g',      (char )'i',      (char )'s',      (char )'t', 
        (char )'e',      (char )'r',      (char )'(',      (char )'f', 
        (char )'d',      (char )')',      (char )' ',      (char )'-', 
        (char )'>',      (char )' ',      (char )'N',      (char )'o', 
        (char )'n',      (char )'e',      (char )'\n',      (char )'\n', 
        (char )'f',      (char )'d',      (char )' ',      (char )'i', 
        (char )'s',      (char )' ',      (char )'t',      (char )'h', 
        (char )'e',      (char )' ',      (char )'t',      (char )'a', 
        (char )'r',      (char )'g',      (char )'e',      (char )'t', 
        (char )' ',      (char )'f',      (char )'i',      (char )'l', 
        (char )'e',      (char )' ',      (char )'d',      (char )'e', 
        (char )'s',      (char )'c',      (char )'r',      (char )'i', 
        (char )'p',      (char )'t',      (char )'o',      (char )'r', 
        (char )' ',      (char )'o',      (char )'f',      (char )' ', 
        (char )'t',      (char )'h',      (char )'e',      (char )' ', 
        (char )'o',      (char )'p',      (char )'e',      (char )'r', 
        (char )'a',      (char )'t',      (char )'i',      (char )'o', 
        (char )'n',      (char )'.',      (char )'\000'};
static char *kwlist___3[3]  = {      (char *)"timeout",      (char *)"maxevents",      (char *)((void *)0)};
static PyObject *pyepoll_poll(pyEpoll_Object *self , PyObject *args ,
                              PyObject *kwds ) 
{ 
  double dtimeout ;
  int timeout ;
  int maxevents ;
  int nfds ;
  int i ;
  PyObject *elist ;
  PyObject *etuple ;
  struct epoll_event *evs ;
  PyObject *tmp ;
  int tmp___0 ;
  void *tmp___1 ;
  PyThreadState *_save ;
  PyObject *_py_tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[1039] == 0) {
    {
    fprintf(_coverage_fout, "1039\n");
    fflush(_coverage_fout);
    ___coverage_array[1039] = 1;
    }
  }
  }
  dtimeout = - 1.;
  {
  if (___coverage_array[1040] == 0) {
    {
    fprintf(_coverage_fout, "1040\n");
    fflush(_coverage_fout);
    ___coverage_array[1040] = 1;
    }
  }
  }
  maxevents = -1;
  {
  if (___coverage_array[1041] == 0) {
    {
    fprintf(_coverage_fout, "1041\n");
    fflush(_coverage_fout);
    ___coverage_array[1041] = 1;
    }
  }
  }
  elist = (PyObject *)((void *)0);
  {
  if (___coverage_array[1042] == 0) {
    {
    fprintf(_coverage_fout, "1042\n");
    fflush(_coverage_fout);
    ___coverage_array[1042] = 1;
    }
  }
  }
  etuple = (PyObject *)((void *)0);
  {
  if (___coverage_array[1043] == 0) {
    {
    fprintf(_coverage_fout, "1043\n");
    fflush(_coverage_fout);
    ___coverage_array[1043] = 1;
    }
  }
  }
  evs = (struct epoll_event *)((void *)0);
  {
  if (___coverage_array[1044] == 0) {
    {
    fprintf(_coverage_fout, "1044\n");
    fflush(_coverage_fout);
    ___coverage_array[1044] = 1;
    }
  }
  }
  if (self->epfd < 0) {
    {
    if (___coverage_array[1045] == 0) {
      {
      fprintf(_coverage_fout, "1045\n");
      fflush(_coverage_fout);
      ___coverage_array[1045] = 1;
      }
    }
    }
    tmp = pyepoll_err_closed();
    {
    if (___coverage_array[1046] == 0) {
      {
      fprintf(_coverage_fout, "1046\n");
      fflush(_coverage_fout);
      ___coverage_array[1046] = 1;
      }
    }
    }
    return (tmp);
  } else {
    {
    if (___coverage_array[1047] == 0) {
      {
      fprintf(_coverage_fout, "1047\n");
      fflush(_coverage_fout);
      ___coverage_array[1047] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[1048] == 0) {
    {
    fprintf(_coverage_fout, "1048\n");
    fflush(_coverage_fout);
    ___coverage_array[1048] = 1;
    }
  }
  }
  tmp___0 = PyArg_ParseTupleAndKeywords(args, kwds, "|di:poll", kwlist___3,
                                        & dtimeout, & maxevents);
  {
  if (___coverage_array[1049] == 0) {
    {
    fprintf(_coverage_fout, "1049\n");
    fflush(_coverage_fout);
    ___coverage_array[1049] = 1;
    }
  }
  }
  if (tmp___0) {
    {
    if (___coverage_array[1050] == 0) {
      {
      fprintf(_coverage_fout, "1050\n");
      fflush(_coverage_fout);
      ___coverage_array[1050] = 1;
      }
    }
    }

  } else {
    {
    if (___coverage_array[1051] == 0) {
      {
      fprintf(_coverage_fout, "1051\n");
      fflush(_coverage_fout);
      ___coverage_array[1051] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  }
  {
  if (___coverage_array[1052] == 0) {
    {
    fprintf(_coverage_fout, "1052\n");
    fflush(_coverage_fout);
    ___coverage_array[1052] = 1;
    }
  }
  }
  if (dtimeout < (double )0) {
    {
    if (___coverage_array[1053] == 0) {
      {
      fprintf(_coverage_fout, "1053\n");
      fflush(_coverage_fout);
      ___coverage_array[1053] = 1;
      }
    }
    }
    timeout = -1;
  } else {
    {
    if (___coverage_array[1054] == 0) {
      {
      fprintf(_coverage_fout, "1054\n");
      fflush(_coverage_fout);
      ___coverage_array[1054] = 1;
      }
    }
    }
    if (dtimeout * 1000.0 > (double )2147483647) {
      {
      if (___coverage_array[1055] == 0) {
        {
        fprintf(_coverage_fout, "1055\n");
        fflush(_coverage_fout);
        ___coverage_array[1055] = 1;
        }
      }
      }
      PyErr_SetString(PyExc_OverflowError, "timeout is too large");
      {
      if (___coverage_array[1056] == 0) {
        {
        fprintf(_coverage_fout, "1056\n");
        fflush(_coverage_fout);
        ___coverage_array[1056] = 1;
        }
      }
      }
      return ((PyObject *)((void *)0));
    } else {
      {
      if (___coverage_array[1057] == 0) {
        {
        fprintf(_coverage_fout, "1057\n");
        fflush(_coverage_fout);
        ___coverage_array[1057] = 1;
        }
      }
      }
      timeout = (int )(dtimeout * 1000.0);
    }
  }
  {
  if (___coverage_array[1058] == 0) {
    {
    fprintf(_coverage_fout, "1058\n");
    fflush(_coverage_fout);
    ___coverage_array[1058] = 1;
    }
  }
  }
  if (maxevents == -1) {
    {
    if (___coverage_array[1059] == 0) {
      {
      fprintf(_coverage_fout, "1059\n");
      fflush(_coverage_fout);
      ___coverage_array[1059] = 1;
      }
    }
    }
    maxevents = 1023;
  } else {
    {
    if (___coverage_array[1060] == 0) {
      {
      fprintf(_coverage_fout, "1060\n");
      fflush(_coverage_fout);
      ___coverage_array[1060] = 1;
      }
    }
    }
    if (maxevents < 1) {
      {
      if (___coverage_array[1061] == 0) {
        {
        fprintf(_coverage_fout, "1061\n");
        fflush(_coverage_fout);
        ___coverage_array[1061] = 1;
        }
      }
      }
      PyErr_Format(PyExc_ValueError, "maxevents must be greater than 0, got %d",
                   maxevents);
      {
      if (___coverage_array[1062] == 0) {
        {
        fprintf(_coverage_fout, "1062\n");
        fflush(_coverage_fout);
        ___coverage_array[1062] = 1;
        }
      }
      }
      return ((PyObject *)((void *)0));
    } else {
      {
      if (___coverage_array[1063] == 0) {
        {
        fprintf(_coverage_fout, "1063\n");
        fflush(_coverage_fout);
        ___coverage_array[1063] = 1;
        }
      }
      }

    }
  }
  {
  if (___coverage_array[1064] == 0) {
    {
    fprintf(_coverage_fout, "1064\n");
    fflush(_coverage_fout);
    ___coverage_array[1064] = 1;
    }
  }
  }
  if ((unsigned long )((size_t )maxevents) > (unsigned long )((Py_ssize_t )(4294967295U >> 1)) / sizeof(struct epoll_event )) {
    {
    if (___coverage_array[1065] == 0) {
      {
      fprintf(_coverage_fout, "1065\n");
      fflush(_coverage_fout);
      ___coverage_array[1065] = 1;
      }
    }
    }
    evs = (struct epoll_event *)((void *)0);
  } else {
    {
    if (___coverage_array[1066] == 0) {
      {
      fprintf(_coverage_fout, "1066\n");
      fflush(_coverage_fout);
      ___coverage_array[1066] = 1;
      }
    }
    }
    tmp___1 = PyMem_Malloc((size_t )((unsigned long )maxevents * sizeof(struct epoll_event )));
    {
    if (___coverage_array[1067] == 0) {
      {
      fprintf(_coverage_fout, "1067\n");
      fflush(_coverage_fout);
      ___coverage_array[1067] = 1;
      }
    }
    }
    evs = (struct epoll_event *)tmp___1;
  }
  {
  if (___coverage_array[1068] == 0) {
    {
    fprintf(_coverage_fout, "1068\n");
    fflush(_coverage_fout);
    ___coverage_array[1068] = 1;
    }
  }
  }
  if ((unsigned long )evs == (unsigned long )((void *)0)) {
    {
    if (___coverage_array[1069] == 0) {
      {
      fprintf(_coverage_fout, "1069\n");
      fflush(_coverage_fout);
      ___coverage_array[1069] = 1;
      }
    }
    }
    while (1) {
      {
      if (___coverage_array[1070] == 0) {
        {
        fprintf(_coverage_fout, "1070\n");
        fflush(_coverage_fout);
        ___coverage_array[1070] = 1;
        }
      }
      }
      (((PyObject *)self)->ob_refcnt) --;
      {
      if (___coverage_array[1071] == 0) {
        {
        fprintf(_coverage_fout, "1071\n");
        fflush(_coverage_fout);
        ___coverage_array[1071] = 1;
        }
      }
      }
      if (((PyObject *)self)->ob_refcnt != 0) {
        {
        if (___coverage_array[1072] == 0) {
          {
          fprintf(_coverage_fout, "1072\n");
          fflush(_coverage_fout);
          ___coverage_array[1072] = 1;
          }
        }
        }

      } else {
        {
        if (___coverage_array[1073] == 0) {
          {
          fprintf(_coverage_fout, "1073\n");
          fflush(_coverage_fout);
          ___coverage_array[1073] = 1;
          }
        }
        }
        (*((((PyObject *)self)->ob_type)->tp_dealloc))((PyObject *)self);
      }
      {
      if (___coverage_array[1074] == 0) {
        {
        fprintf(_coverage_fout, "1074\n");
        fflush(_coverage_fout);
        ___coverage_array[1074] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[1075] == 0) {
      {
      fprintf(_coverage_fout, "1075\n");
      fflush(_coverage_fout);
      ___coverage_array[1075] = 1;
      }
    }
    }
    PyErr_NoMemory();
    {
    if (___coverage_array[1076] == 0) {
      {
      fprintf(_coverage_fout, "1076\n");
      fflush(_coverage_fout);
      ___coverage_array[1076] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[1077] == 0) {
      {
      fprintf(_coverage_fout, "1077\n");
      fflush(_coverage_fout);
      ___coverage_array[1077] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[1078] == 0) {
    {
    fprintf(_coverage_fout, "1078\n");
    fflush(_coverage_fout);
    ___coverage_array[1078] = 1;
    }
  }
  }
  _save = PyEval_SaveThread();
  {
  if (___coverage_array[1079] == 0) {
    {
    fprintf(_coverage_fout, "1079\n");
    fflush(_coverage_fout);
    ___coverage_array[1079] = 1;
    }
  }
  }
  nfds = epoll_wait(self->epfd, evs, maxevents, timeout);
  {
  if (___coverage_array[1080] == 0) {
    {
    fprintf(_coverage_fout, "1080\n");
    fflush(_coverage_fout);
    ___coverage_array[1080] = 1;
    }
  }
  }
  PyEval_RestoreThread(_save);
  {
  if (___coverage_array[1081] == 0) {
    {
    fprintf(_coverage_fout, "1081\n");
    fflush(_coverage_fout);
    ___coverage_array[1081] = 1;
    }
  }
  }
  if (nfds < 0) {
    {
    if (___coverage_array[1082] == 0) {
      {
      fprintf(_coverage_fout, "1082\n");
      fflush(_coverage_fout);
      ___coverage_array[1082] = 1;
      }
    }
    }
    PyErr_SetFromErrno(PyExc_IOError);
    {
    if (___coverage_array[1083] == 0) {
      {
      fprintf(_coverage_fout, "1083\n");
      fflush(_coverage_fout);
      ___coverage_array[1083] = 1;
      }
    }
    }
    goto error;
  } else {
    {
    if (___coverage_array[1084] == 0) {
      {
      fprintf(_coverage_fout, "1084\n");
      fflush(_coverage_fout);
      ___coverage_array[1084] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[1085] == 0) {
    {
    fprintf(_coverage_fout, "1085\n");
    fflush(_coverage_fout);
    ___coverage_array[1085] = 1;
    }
  }
  }
  elist = PyList_New(nfds);
  {
  if (___coverage_array[1086] == 0) {
    {
    fprintf(_coverage_fout, "1086\n");
    fflush(_coverage_fout);
    ___coverage_array[1086] = 1;
    }
  }
  }
  if ((unsigned long )elist == (unsigned long )((void *)0)) {
    {
    if (___coverage_array[1087] == 0) {
      {
      fprintf(_coverage_fout, "1087\n");
      fflush(_coverage_fout);
      ___coverage_array[1087] = 1;
      }
    }
    }
    goto error;
  } else {
    {
    if (___coverage_array[1088] == 0) {
      {
      fprintf(_coverage_fout, "1088\n");
      fflush(_coverage_fout);
      ___coverage_array[1088] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[1089] == 0) {
    {
    fprintf(_coverage_fout, "1089\n");
    fflush(_coverage_fout);
    ___coverage_array[1089] = 1;
    }
  }
  }
  i = 0;
  {
  if (___coverage_array[1090] == 0) {
    {
    fprintf(_coverage_fout, "1090\n");
    fflush(_coverage_fout);
    ___coverage_array[1090] = 1;
    }
  }
  }
  while (1) {
    {
    if (___coverage_array[1091] == 0) {
      {
      fprintf(_coverage_fout, "1091\n");
      fflush(_coverage_fout);
      ___coverage_array[1091] = 1;
      }
    }
    }
    if (i < nfds) {
      {
      if (___coverage_array[1092] == 0) {
        {
        fprintf(_coverage_fout, "1092\n");
        fflush(_coverage_fout);
        ___coverage_array[1092] = 1;
        }
      }
      }

    } else {
      {
      if (___coverage_array[1093] == 0) {
        {
        fprintf(_coverage_fout, "1093\n");
        fflush(_coverage_fout);
        ___coverage_array[1093] = 1;
        }
      }
      }
      break;
    }
    {
    if (___coverage_array[1094] == 0) {
      {
      fprintf(_coverage_fout, "1094\n");
      fflush(_coverage_fout);
      ___coverage_array[1094] = 1;
      }
    }
    }
    etuple = Py_BuildValue("iI", (evs + i)->data.fd, (evs + i)->events);
    {
    if (___coverage_array[1095] == 0) {
      {
      fprintf(_coverage_fout, "1095\n");
      fflush(_coverage_fout);
      ___coverage_array[1095] = 1;
      }
    }
    }
    if ((unsigned long )etuple == (unsigned long )((void *)0)) {
      {
      if (___coverage_array[1096] == 0) {
        {
        fprintf(_coverage_fout, "1096\n");
        fflush(_coverage_fout);
        ___coverage_array[1096] = 1;
        }
      }
      }
      while (1) {
        {
        if (___coverage_array[1097] == 0) {
          {
          fprintf(_coverage_fout, "1097\n");
          fflush(_coverage_fout);
          ___coverage_array[1097] = 1;
          }
        }
        }
        if (elist) {
          {
          if (___coverage_array[1098] == 0) {
            {
            fprintf(_coverage_fout, "1098\n");
            fflush(_coverage_fout);
            ___coverage_array[1098] = 1;
            }
          }
          }
          _py_tmp = elist;
          {
          if (___coverage_array[1099] == 0) {
            {
            fprintf(_coverage_fout, "1099\n");
            fflush(_coverage_fout);
            ___coverage_array[1099] = 1;
            }
          }
          }
          elist = (PyObject *)((void *)0);
          {
          if (___coverage_array[1100] == 0) {
            {
            fprintf(_coverage_fout, "1100\n");
            fflush(_coverage_fout);
            ___coverage_array[1100] = 1;
            }
          }
          }
          while (1) {
            {
            if (___coverage_array[1101] == 0) {
              {
              fprintf(_coverage_fout, "1101\n");
              fflush(_coverage_fout);
              ___coverage_array[1101] = 1;
              }
            }
            }
            (_py_tmp->ob_refcnt) --;
            {
            if (___coverage_array[1102] == 0) {
              {
              fprintf(_coverage_fout, "1102\n");
              fflush(_coverage_fout);
              ___coverage_array[1102] = 1;
              }
            }
            }
            if (_py_tmp->ob_refcnt != 0) {
              {
              if (___coverage_array[1103] == 0) {
                {
                fprintf(_coverage_fout, "1103\n");
                fflush(_coverage_fout);
                ___coverage_array[1103] = 1;
                }
              }
              }

            } else {
              {
              if (___coverage_array[1104] == 0) {
                {
                fprintf(_coverage_fout, "1104\n");
                fflush(_coverage_fout);
                ___coverage_array[1104] = 1;
                }
              }
              }
              (*((_py_tmp->ob_type)->tp_dealloc))(_py_tmp);
            }
            {
            if (___coverage_array[1105] == 0) {
              {
              fprintf(_coverage_fout, "1105\n");
              fflush(_coverage_fout);
              ___coverage_array[1105] = 1;
              }
            }
            }
            break;
          }
        } else {
          {
          if (___coverage_array[1106] == 0) {
            {
            fprintf(_coverage_fout, "1106\n");
            fflush(_coverage_fout);
            ___coverage_array[1106] = 1;
            }
          }
          }

        }
        {
        if (___coverage_array[1107] == 0) {
          {
          fprintf(_coverage_fout, "1107\n");
          fflush(_coverage_fout);
          ___coverage_array[1107] = 1;
          }
        }
        }
        break;
      }
      {
      if (___coverage_array[1108] == 0) {
        {
        fprintf(_coverage_fout, "1108\n");
        fflush(_coverage_fout);
        ___coverage_array[1108] = 1;
        }
      }
      }
      goto error;
    } else {
      {
      if (___coverage_array[1109] == 0) {
        {
        fprintf(_coverage_fout, "1109\n");
        fflush(_coverage_fout);
        ___coverage_array[1109] = 1;
        }
      }
      }

    }
    {
    if (___coverage_array[1110] == 0) {
      {
      fprintf(_coverage_fout, "1110\n");
      fflush(_coverage_fout);
      ___coverage_array[1110] = 1;
      }
    }
    }
    *(((PyListObject *)elist)->ob_item + i) = etuple;
    {
    if (___coverage_array[1111] == 0) {
      {
      fprintf(_coverage_fout, "1111\n");
      fflush(_coverage_fout);
      ___coverage_array[1111] = 1;
      }
    }
    }
    i ++;
  }
  {
  if (___coverage_array[1112] == 0) {
    {
    fprintf(_coverage_fout, "1112\n");
    fflush(_coverage_fout);
    ___coverage_array[1112] = 1;
    }
  }
  }
  error: 
  PyMem_Free((void *)evs);
  {
  if (___coverage_array[1113] == 0) {
    {
    fprintf(_coverage_fout, "1113\n");
    fflush(_coverage_fout);
    ___coverage_array[1113] = 1;
    }
  }
  }
  return (elist);
}
}
static char pyepoll_poll_doc[236]  = 
  {      (char )'p',      (char )'o',      (char )'l',      (char )'l', 
        (char )'(',      (char )'[',      (char )'t',      (char )'i', 
        (char )'m',      (char )'e',      (char )'o',      (char )'u', 
        (char )'t',      (char )'=',      (char )'-',      (char )'1', 
        (char )'[',      (char )',',      (char )' ',      (char )'m', 
        (char )'a',      (char )'x',      (char )'e',      (char )'v', 
        (char )'e',      (char )'n',      (char )'t',      (char )'s', 
        (char )'=',      (char )'-',      (char )'1',      (char )']', 
        (char )']',      (char )')',      (char )' ',      (char )'-', 
        (char )'>',      (char )' ',      (char )'[',      (char )'(', 
        (char )'f',      (char )'d',      (char )',',      (char )' ', 
        (char )'e',      (char )'v',      (char )'e',      (char )'n', 
        (char )'t',      (char )'s',      (char )')',      (char )',', 
        (char )' ',      (char )'(',      (char )'.',      (char )'.', 
        (char )'.',      (char )')',      (char )']',      (char )'\n', 
        (char )'\n',      (char )'W',      (char )'a',      (char )'i', 
        (char )'t',      (char )' ',      (char )'f',      (char )'o', 
        (char )'r',      (char )' ',      (char )'e',      (char )'v', 
        (char )'e',      (char )'n',      (char )'t',      (char )'s', 
        (char )' ',      (char )'o',      (char )'n',      (char )' ', 
        (char )'t',      (char )'h',      (char )'e',      (char )' ', 
        (char )'e',      (char )'p',      (char )'o',      (char )'l', 
        (char )'l',      (char )' ',      (char )'f',      (char )'i', 
        (char )'l',      (char )'e',      (char )' ',      (char )'d', 
        (char )'e',      (char )'s',      (char )'c',      (char )'r', 
        (char )'i',      (char )'p',      (char )'t',      (char )'o', 
        (char )'r',      (char )' ',      (char )'f',      (char )'o', 
        (char )'r',      (char )' ',      (char )'a',      (char )' ', 
        (char )'m',      (char )'a',      (char )'x',      (char )'i', 
        (char )'m',      (char )'u',      (char )'m',      (char )' ', 
        (char )'t',      (char )'i',      (char )'m',      (char )'e', 
        (char )' ',      (char )'o',      (char )'f',      (char )' ', 
        (char )'t',      (char )'i',      (char )'m',      (char )'e', 
        (char )'o',      (char )'u',      (char )'t',      (char )'\n', 
        (char )'i',      (char )'n',      (char )' ',      (char )'s', 
        (char )'e',      (char )'c',      (char )'o',      (char )'n', 
        (char )'d',      (char )'s',      (char )' ',      (char )'(', 
        (char )'a',      (char )'s',      (char )' ',      (char )'f', 
        (char )'l',      (char )'o',      (char )'a',      (char )'t', 
        (char )')',      (char )'.',      (char )' ',      (char )'-', 
        (char )'1',      (char )' ',      (char )'m',      (char )'a', 
        (char )'k',      (char )'e',      (char )'s',      (char )' ', 
        (char )'p',      (char )'o',      (char )'l',      (char )'l', 
        (char )' ',      (char )'w',      (char )'a',      (char )'i', 
        (char )'t',      (char )' ',      (char )'i',      (char )'n', 
        (char )'d',      (char )'e',      (char )'f',      (char )'i', 
        (char )'n',      (char )'i',      (char )'t',      (char )'e', 
        (char )'l',      (char )'y',      (char )'.',      (char )'\n', 
        (char )'U',      (char )'p',      (char )' ',      (char )'t', 
        (char )'o',      (char )' ',      (char )'m',      (char )'a', 
        (char )'x',      (char )'e',      (char )'v',      (char )'e', 
        (char )'n',      (char )'t',      (char )'s',      (char )' ', 
        (char )'a',      (char )'r',      (char )'e',      (char )' ', 
        (char )'r',      (char )'e',      (char )'t',      (char )'u', 
        (char )'r',      (char )'n',      (char )'e',      (char )'d', 
        (char )' ',      (char )'t',      (char )'o',      (char )' ', 
        (char )'t',      (char )'h',      (char )'e',      (char )' ', 
        (char )'c',      (char )'a',      (char )'l',      (char )'l', 
        (char )'e',      (char )'r',      (char )'.',      (char )'\000'};
static PyMethodDef pyepoll_methods[8]  = 
  {      {"fromfd", & pyepoll_fromfd, 17, (char const   *)(pyepoll_fromfd_doc)}, 
        {"close", (PyObject *(*)(PyObject * , PyObject * ))(& pyepoll_close), 4,
      (char const   *)(pyepoll_close_doc)}, 
        {"fileno", (PyObject *(*)(PyObject * , PyObject * ))(& pyepoll_fileno), 4,
      (char const   *)(pyepoll_fileno_doc)}, 
        {"modify", (PyObject *(*)(PyObject * , PyObject * ))(& pyepoll_modify), 3,
      (char const   *)(pyepoll_modify_doc)}, 
        {"register", (PyObject *(*)(PyObject * , PyObject * ))(& pyepoll_register),
      3, (char const   *)(pyepoll_register_doc)}, 
        {"unregister",
      (PyObject *(*)(PyObject * , PyObject * ))(& pyepoll_unregister), 3,
      (char const   *)(pyepoll_unregister_doc)}, 
        {"poll", (PyObject *(*)(PyObject * , PyObject * ))(& pyepoll_poll), 3,
      (char const   *)(pyepoll_poll_doc)}, 
        {(char const   *)((void *)0),
      (PyObject *(*)(PyObject * , PyObject * ))((void *)0), 0, (char const   *)0}};
static PyGetSetDef pyepoll_getsetlist[2]  = {      {(char *)"closed",
      (PyObject *(*)(PyObject * , void * ))(& pyepoll_get_closed),
      (int (*)(PyObject * , PyObject * , void * ))((void *)0),
      (char *)"True if the epoll handler is closed", (void *)0}, 
        {(char *)0, (PyObject *(*)(PyObject * , void * ))0,
      (int (*)(PyObject * , PyObject * , void * ))0, (char *)0, (void *)0}};
static char pyepoll_doc[237]  = 
  {      (char )'s',      (char )'e',      (char )'l',      (char )'e', 
        (char )'c',      (char )'t',      (char )'.',      (char )'e', 
        (char )'p',      (char )'o',      (char )'l',      (char )'l', 
        (char )'(',      (char )'[',      (char )'s',      (char )'i', 
        (char )'z',      (char )'e',      (char )'h',      (char )'i', 
        (char )'n',      (char )'t',      (char )'=',      (char )'-', 
        (char )'1',      (char )']',      (char )')',      (char )'\n', 
        (char )'\n',      (char )'R',      (char )'e',      (char )'t', 
        (char )'u',      (char )'r',      (char )'n',      (char )'s', 
        (char )' ',      (char )'a',      (char )'n',      (char )' ', 
        (char )'e',      (char )'p',      (char )'o',      (char )'l', 
        (char )'l',      (char )'i',      (char )'n',      (char )'g', 
        (char )' ',      (char )'o',      (char )'b',      (char )'j', 
        (char )'e',      (char )'c',      (char )'t',      (char )'\n', 
        (char )'\n',      (char )'s',      (char )'i',      (char )'z', 
        (char )'e',      (char )'h',      (char )'i',      (char )'n', 
        (char )'t',      (char )' ',      (char )'m',      (char )'u', 
        (char )'s',      (char )'t',      (char )' ',      (char )'b', 
        (char )'e',      (char )' ',      (char )'a',      (char )' ', 
        (char )'p',      (char )'o',      (char )'s',      (char )'i', 
        (char )'t',      (char )'i',      (char )'v',      (char )'e', 
        (char )' ',      (char )'i',      (char )'n',      (char )'t', 
        (char )'e',      (char )'g',      (char )'e',      (char )'r', 
        (char )' ',      (char )'o',      (char )'r',      (char )' ', 
        (char )'-',      (char )'1',      (char )' ',      (char )'f', 
        (char )'o',      (char )'r',      (char )' ',      (char )'t', 
        (char )'h',      (char )'e',      (char )' ',      (char )'d', 
        (char )'e',      (char )'f',      (char )'a',      (char )'u', 
        (char )'l',      (char )'t',      (char )' ',      (char )'s', 
        (char )'i',      (char )'z',      (char )'e',      (char )'.', 
        (char )' ',      (char )'T',      (char )'h',      (char )'e', 
        (char )'\n',      (char )'s',      (char )'i',      (char )'z', 
        (char )'e',      (char )'h',      (char )'i',      (char )'n', 
        (char )'t',      (char )' ',      (char )'i',      (char )'s', 
        (char )' ',      (char )'u',      (char )'s',      (char )'e', 
        (char )'d',      (char )' ',      (char )'t',      (char )'o', 
        (char )' ',      (char )'o',      (char )'p',      (char )'t', 
        (char )'i',      (char )'m',      (char )'i',      (char )'z', 
        (char )'e',      (char )' ',      (char )'i',      (char )'n', 
        (char )'t',      (char )'e',      (char )'r',      (char )'n', 
        (char )'a',      (char )'l',      (char )' ',      (char )'d', 
        (char )'a',      (char )'t',      (char )'a',      (char )' ', 
        (char )'s',      (char )'t',      (char )'r',      (char )'u', 
        (char )'c',      (char )'t',      (char )'u',      (char )'r', 
        (char )'e',      (char )'s',      (char )'.',      (char )' ', 
        (char )'I',      (char )'t',      (char )' ',      (char )'d', 
        (char )'o',      (char )'e',      (char )'s',      (char )'n', 
        (char )'\'',      (char )'t',      (char )' ',      (char )'l', 
        (char )'i',      (char )'m',      (char )'i',      (char )'t', 
        (char )'\n',      (char )'t',      (char )'h',      (char )'e', 
        (char )' ',      (char )'m',      (char )'a',      (char )'x', 
        (char )'i',      (char )'m',      (char )'u',      (char )'m', 
        (char )' ',      (char )'n',      (char )'u',      (char )'m', 
        (char )'b',      (char )'e',      (char )'r',      (char )' ', 
        (char )'o',      (char )'f',      (char )' ',      (char )'m', 
        (char )'o',      (char )'n',      (char )'i',      (char )'t', 
        (char )'o',      (char )'r',      (char )'e',      (char )'d', 
        (char )' ',      (char )'e',      (char )'v',      (char )'e', 
        (char )'n',      (char )'t',      (char )'s',      (char )'.', 
        (char )'\000'};
static PyTypeObject pyEpoll_Type  = 
     {{{1, (struct _typeobject *)((void *)0)}, 0}, "select.epoll",
    (Py_ssize_t )sizeof(pyEpoll_Object ), 0,
    (void (*)(PyObject * ))(& pyepoll_dealloc),
    (int (*)(PyObject * , FILE * , int  ))0,
    (PyObject *(*)(PyObject * , char * ))0,
    (int (*)(PyObject * , char * , PyObject * ))0, (void *)0,
    (PyObject *(*)(PyObject * ))0, (PyNumberMethods *)0, (PySequenceMethods *)0,
    (PyMappingMethods *)0, (Py_hash_t (*)(PyObject * ))0,
    (PyObject *(*)(PyObject * , PyObject * , PyObject * ))0,
    (PyObject *(*)(PyObject * ))0, & PyObject_GenericGetAttr,
    (int (*)(PyObject * , PyObject * , PyObject * ))0, (PyBufferProcs *)0,
    1L << 18, (char const   *)(pyepoll_doc),
    (int (*)(PyObject * , int (*)(PyObject * , void * ) , void * ))0,
    (int (*)(PyObject * ))0, (PyObject *(*)(PyObject * , PyObject * , int  ))0,
    0, (PyObject *(*)(PyObject * ))0, (PyObject *(*)(PyObject * ))0,
    pyepoll_methods, (struct PyMemberDef *)0, pyepoll_getsetlist,
    (struct _typeobject *)0, (PyObject *)0,
    (PyObject *(*)(PyObject * , PyObject * , PyObject * ))0,
    (int (*)(PyObject * , PyObject * , PyObject * ))0, 0,
    (int (*)(PyObject * , PyObject * , PyObject * ))0,
    (PyObject *(*)(struct _typeobject * , Py_ssize_t  ))0, & pyepoll_new,
    (void (*)(void * ))0, (int (*)(PyObject * ))0, (PyObject *)0, (PyObject *)0,
    (PyObject *)0, (PyObject *)0, (PyObject *)0, (void (*)(PyObject * ))0, 0U};
static char select_doc[1004]  = 
  {      (char )'s',      (char )'e',      (char )'l',      (char )'e', 
        (char )'c',      (char )'t',      (char )'(',      (char )'r', 
        (char )'l',      (char )'i',      (char )'s',      (char )'t', 
        (char )',',      (char )' ',      (char )'w',      (char )'l', 
        (char )'i',      (char )'s',      (char )'t',      (char )',', 
        (char )' ',      (char )'x',      (char )'l',      (char )'i', 
        (char )'s',      (char )'t',      (char )'[',      (char )',', 
        (char )' ',      (char )'t',      (char )'i',      (char )'m', 
        (char )'e',      (char )'o',      (char )'u',      (char )'t', 
        (char )']',      (char )')',      (char )' ',      (char )'-', 
        (char )'>',      (char )' ',      (char )'(',      (char )'r', 
        (char )'l',      (char )'i',      (char )'s',      (char )'t', 
        (char )',',      (char )' ',      (char )'w',      (char )'l', 
        (char )'i',      (char )'s',      (char )'t',      (char )',', 
        (char )' ',      (char )'x',      (char )'l',      (char )'i', 
        (char )'s',      (char )'t',      (char )')',      (char )'\n', 
        (char )'\n',      (char )'W',      (char )'a',      (char )'i', 
        (char )'t',      (char )' ',      (char )'u',      (char )'n', 
        (char )'t',      (char )'i',      (char )'l',      (char )' ', 
        (char )'o',      (char )'n',      (char )'e',      (char )' ', 
        (char )'o',      (char )'r',      (char )' ',      (char )'m', 
        (char )'o',      (char )'r',      (char )'e',      (char )' ', 
        (char )'f',      (char )'i',      (char )'l',      (char )'e', 
        (char )' ',      (char )'d',      (char )'e',      (char )'s', 
        (char )'c',      (char )'r',      (char )'i',      (char )'p', 
        (char )'t',      (char )'o',      (char )'r',      (char )'s', 
        (char )' ',      (char )'a',      (char )'r',      (char )'e', 
        (char )' ',      (char )'r',      (char )'e',      (char )'a', 
        (char )'d',      (char )'y',      (char )' ',      (char )'f', 
        (char )'o',      (char )'r',      (char )' ',      (char )'s', 
        (char )'o',      (char )'m',      (char )'e',      (char )' ', 
        (char )'k',      (char )'i',      (char )'n',      (char )'d', 
        (char )' ',      (char )'o',      (char )'f',      (char )' ', 
        (char )'I',      (char )'/',      (char )'O',      (char )'.', 
        (char )'\n',      (char )'T',      (char )'h',      (char )'e', 
        (char )' ',      (char )'f',      (char )'i',      (char )'r', 
        (char )'s',      (char )'t',      (char )' ',      (char )'t', 
        (char )'h',      (char )'r',      (char )'e',      (char )'e', 
        (char )' ',      (char )'a',      (char )'r',      (char )'g', 
        (char )'u',      (char )'m',      (char )'e',      (char )'n', 
        (char )'t',      (char )'s',      (char )' ',      (char )'a', 
        (char )'r',      (char )'e',      (char )' ',      (char )'s', 
        (char )'e',      (char )'q',      (char )'u',      (char )'e', 
        (char )'n',      (char )'c',      (char )'e',      (char )'s', 
        (char )' ',      (char )'o',      (char )'f',      (char )' ', 
        (char )'f',      (char )'i',      (char )'l',      (char )'e', 
        (char )' ',      (char )'d',      (char )'e',      (char )'s', 
        (char )'c',      (char )'r',      (char )'i',      (char )'p', 
        (char )'t',      (char )'o',      (char )'r',      (char )'s', 
        (char )' ',      (char )'t',      (char )'o',      (char )' ', 
        (char )'b',      (char )'e',      (char )' ',      (char )'w', 
        (char )'a',      (char )'i',      (char )'t',      (char )'e', 
        (char )'d',      (char )' ',      (char )'f',      (char )'o', 
        (char )'r',      (char )':',      (char )'\n',      (char )'r', 
        (char )'l',      (char )'i',      (char )'s',      (char )'t', 
        (char )' ',      (char )'-',      (char )'-',      (char )' ', 
        (char )'w',      (char )'a',      (char )'i',      (char )'t', 
        (char )' ',      (char )'u',      (char )'n',      (char )'t', 
        (char )'i',      (char )'l',      (char )' ',      (char )'r', 
        (char )'e',      (char )'a',      (char )'d',      (char )'y', 
        (char )' ',      (char )'f',      (char )'o',      (char )'r', 
        (char )' ',      (char )'r',      (char )'e',      (char )'a', 
        (char )'d',      (char )'i',      (char )'n',      (char )'g', 
        (char )'\n',      (char )'w',      (char )'l',      (char )'i', 
        (char )'s',      (char )'t',      (char )' ',      (char )'-', 
        (char )'-',      (char )' ',      (char )'w',      (char )'a', 
        (char )'i',      (char )'t',      (char )' ',      (char )'u', 
        (char )'n',      (char )'t',      (char )'i',      (char )'l', 
        (char )' ',      (char )'r',      (char )'e',      (char )'a', 
        (char )'d',      (char )'y',      (char )' ',      (char )'f', 
        (char )'o',      (char )'r',      (char )' ',      (char )'w', 
        (char )'r',      (char )'i',      (char )'t',      (char )'i', 
        (char )'n',      (char )'g',      (char )'\n',      (char )'x', 
        (char )'l',      (char )'i',      (char )'s',      (char )'t', 
        (char )' ',      (char )'-',      (char )'-',      (char )' ', 
        (char )'w',      (char )'a',      (char )'i',      (char )'t', 
        (char )' ',      (char )'f',      (char )'o',      (char )'r', 
        (char )' ',      (char )'a',      (char )'n',      (char )' ', 
        (char )'`',      (char )'`',      (char )'e',      (char )'x', 
        (char )'c',      (char )'e',      (char )'p',      (char )'t', 
        (char )'i',      (char )'o',      (char )'n',      (char )'a', 
        (char )'l',      (char )' ',      (char )'c',      (char )'o', 
        (char )'n',      (char )'d',      (char )'i',      (char )'t', 
        (char )'i',      (char )'o',      (char )'n',      (char )'\'', 
        (char )'\'',      (char )'\n',      (char )'I',      (char )'f', 
        (char )' ',      (char )'o',      (char )'n',      (char )'l', 
        (char )'y',      (char )' ',      (char )'o',      (char )'n', 
        (char )'e',      (char )' ',      (char )'k',      (char )'i', 
        (char )'n',      (char )'d',      (char )' ',      (char )'o', 
        (char )'f',      (char )' ',      (char )'c',      (char )'o', 
        (char )'n',      (char )'d',      (char )'i',      (char )'t', 
        (char )'i',      (char )'o',      (char )'n',      (char )' ', 
        (char )'i',      (char )'s',      (char )' ',      (char )'r', 
        (char )'e',      (char )'q',      (char )'u',      (char )'i', 
        (char )'r',      (char )'e',      (char )'d',      (char )',', 
        (char )' ',      (char )'p',      (char )'a',      (char )'s', 
        (char )'s',      (char )' ',      (char )'[',      (char )']', 
        (char )' ',      (char )'f',      (char )'o',      (char )'r', 
        (char )' ',      (char )'t',      (char )'h',      (char )'e', 
        (char )' ',      (char )'o',      (char )'t',      (char )'h', 
        (char )'e',      (char )'r',      (char )' ',      (char )'l', 
        (char )'i',      (char )'s',      (char )'t',      (char )'s', 
        (char )'.',      (char )'\n',      (char )'A',      (char )' ', 
        (char )'f',      (char )'i',      (char )'l',      (char )'e', 
        (char )' ',      (char )'d',      (char )'e',      (char )'s', 
        (char )'c',      (char )'r',      (char )'i',      (char )'p', 
        (char )'t',      (char )'o',      (char )'r',      (char )' ', 
        (char )'i',      (char )'s',      (char )' ',      (char )'e', 
        (char )'i',      (char )'t',      (char )'h',      (char )'e', 
        (char )'r',      (char )' ',      (char )'a',      (char )' ', 
        (char )'s',      (char )'o',      (char )'c',      (char )'k', 
        (char )'e',      (char )'t',      (char )' ',      (char )'o', 
        (char )'r',      (char )' ',      (char )'f',      (char )'i', 
        (char )'l',      (char )'e',      (char )' ',      (char )'o', 
        (char )'b',      (char )'j',      (char )'e',      (char )'c', 
        (char )'t',      (char )',',      (char )' ',      (char )'o', 
        (char )'r',      (char )' ',      (char )'a',      (char )' ', 
        (char )'s',      (char )'m',      (char )'a',      (char )'l', 
        (char )'l',      (char )' ',      (char )'i',      (char )'n', 
        (char )'t',      (char )'e',      (char )'g',      (char )'e', 
        (char )'r',      (char )'\n',      (char )'g',      (char )'o', 
        (char )'t',      (char )'t',      (char )'e',      (char )'n', 
        (char )' ',      (char )'f',      (char )'r',      (char )'o', 
        (char )'m',      (char )' ',      (char )'a',      (char )' ', 
        (char )'f',      (char )'i',      (char )'l',      (char )'e', 
        (char )'n',      (char )'o',      (char )'(',      (char )')', 
        (char )' ',      (char )'m',      (char )'e',      (char )'t', 
        (char )'h',      (char )'o',      (char )'d',      (char )' ', 
        (char )'c',      (char )'a',      (char )'l',      (char )'l', 
        (char )' ',      (char )'o',      (char )'n',      (char )' ', 
        (char )'o',      (char )'n',      (char )'e',      (char )' ', 
        (char )'o',      (char )'f',      (char )' ',      (char )'t', 
        (char )'h',      (char )'o',      (char )'s',      (char )'e', 
        (char )'.',      (char )'\n',      (char )'\n',      (char )'T', 
        (char )'h',      (char )'e',      (char )' ',      (char )'o', 
        (char )'p',      (char )'t',      (char )'i',      (char )'o', 
        (char )'n',      (char )'a',      (char )'l',      (char )' ', 
        (char )'4',      (char )'t',      (char )'h',      (char )' ', 
        (char )'a',      (char )'r',      (char )'g',      (char )'u', 
        (char )'m',      (char )'e',      (char )'n',      (char )'t', 
        (char )' ',      (char )'s',      (char )'p',      (char )'e', 
        (char )'c',      (char )'i',      (char )'f',      (char )'i', 
        (char )'e',      (char )'s',      (char )' ',      (char )'a', 
        (char )' ',      (char )'t',      (char )'i',      (char )'m', 
        (char )'e',      (char )'o',      (char )'u',      (char )'t', 
        (char )' ',      (char )'i',      (char )'n',      (char )' ', 
        (char )'s',      (char )'e',      (char )'c',      (char )'o', 
        (char )'n',      (char )'d',      (char )'s',      (char )';', 
        (char )' ',      (char )'i',      (char )'t',      (char )' ', 
        (char )'m',      (char )'a',      (char )'y',      (char )' ', 
        (char )'b',      (char )'e',      (char )'\n',      (char )'a', 
        (char )' ',      (char )'f',      (char )'l',      (char )'o', 
        (char )'a',      (char )'t',      (char )'i',      (char )'n', 
        (char )'g',      (char )' ',      (char )'p',      (char )'o', 
        (char )'i',      (char )'n',      (char )'t',      (char )' ', 
        (char )'n',      (char )'u',      (char )'m',      (char )'b', 
        (char )'e',      (char )'r',      (char )' ',      (char )'t', 
        (char )'o',      (char )' ',      (char )'s',      (char )'p', 
        (char )'e',      (char )'c',      (char )'i',      (char )'f', 
        (char )'y',      (char )' ',      (char )'f',      (char )'r', 
        (char )'a',      (char )'c',      (char )'t',      (char )'i', 
        (char )'o',      (char )'n',      (char )'s',      (char )' ', 
        (char )'o',      (char )'f',      (char )' ',      (char )'s', 
        (char )'e',      (char )'c',      (char )'o',      (char )'n', 
        (char )'d',      (char )'s',      (char )'.',      (char )' ', 
        (char )' ',      (char )'I',      (char )'f',      (char )' ', 
        (char )'i',      (char )'t',      (char )' ',      (char )'i', 
        (char )'s',      (char )' ',      (char )'a',      (char )'b', 
        (char )'s',      (char )'e',      (char )'n',      (char )'t', 
        (char )'\n',      (char )'o',      (char )'r',      (char )' ', 
        (char )'N',      (char )'o',      (char )'n',      (char )'e', 
        (char )',',      (char )' ',      (char )'t',      (char )'h', 
        (char )'e',      (char )' ',      (char )'c',      (char )'a', 
        (char )'l',      (char )'l',      (char )' ',      (char )'w', 
        (char )'i',      (char )'l',      (char )'l',      (char )' ', 
        (char )'n',      (char )'e',      (char )'v',      (char )'e', 
        (char )'r',      (char )' ',      (char )'t',      (char )'i', 
        (char )'m',      (char )'e',      (char )' ',      (char )'o', 
        (char )'u',      (char )'t',      (char )'.',      (char )'\n', 
        (char )'\n',      (char )'T',      (char )'h',      (char )'e', 
        (char )' ',      (char )'r',      (char )'e',      (char )'t', 
        (char )'u',      (char )'r',      (char )'n',      (char )' ', 
        (char )'v',      (char )'a',      (char )'l',      (char )'u', 
        (char )'e',      (char )' ',      (char )'i',      (char )'s', 
        (char )' ',      (char )'a',      (char )' ',      (char )'t', 
        (char )'u',      (char )'p',      (char )'l',      (char )'e', 
        (char )' ',      (char )'o',      (char )'f',      (char )' ', 
        (char )'t',      (char )'h',      (char )'r',      (char )'e', 
        (char )'e',      (char )' ',      (char )'l',      (char )'i', 
        (char )'s',      (char )'t',      (char )'s',      (char )' ', 
        (char )'c',      (char )'o',      (char )'r',      (char )'r', 
        (char )'e',      (char )'s',      (char )'p',      (char )'o', 
        (char )'n',      (char )'d',      (char )'i',      (char )'n', 
        (char )'g',      (char )' ',      (char )'t',      (char )'o', 
        (char )' ',      (char )'t',      (char )'h',      (char )'e', 
        (char )' ',      (char )'f',      (char )'i',      (char )'r', 
        (char )'s',      (char )'t',      (char )' ',      (char )'t', 
        (char )'h',      (char )'r',      (char )'e',      (char )'e', 
        (char )'\n',      (char )'a',      (char )'r',      (char )'g', 
        (char )'u',      (char )'m',      (char )'e',      (char )'n', 
        (char )'t',      (char )'s',      (char )';',      (char )' ', 
        (char )'e',      (char )'a',      (char )'c',      (char )'h', 
        (char )' ',      (char )'c',      (char )'o',      (char )'n', 
        (char )'t',      (char )'a',      (char )'i',      (char )'n', 
        (char )'s',      (char )' ',      (char )'t',      (char )'h', 
        (char )'e',      (char )' ',      (char )'s',      (char )'u', 
        (char )'b',      (char )'s',      (char )'e',      (char )'t', 
        (char )' ',      (char )'o',      (char )'f',      (char )' ', 
        (char )'t',      (char )'h',      (char )'e',      (char )' ', 
        (char )'c',      (char )'o',      (char )'r',      (char )'r', 
        (char )'e',      (char )'s',      (char )'p',      (char )'o', 
        (char )'n',      (char )'d',      (char )'i',      (char )'n', 
        (char )'g',      (char )' ',      (char )'f',      (char )'i', 
        (char )'l',      (char )'e',      (char )' ',      (char )'d', 
        (char )'e',      (char )'s',      (char )'c',      (char )'r', 
        (char )'i',      (char )'p',      (char )'t',      (char )'o', 
        (char )'r',      (char )'s',      (char )'\n',      (char )'t', 
        (char )'h',      (char )'a',      (char )'t',      (char )' ', 
        (char )'a',      (char )'r',      (char )'e',      (char )' ', 
        (char )'r',      (char )'e',      (char )'a',      (char )'d', 
        (char )'y',      (char )'.',      (char )'\n',      (char )'\n', 
        (char )'*',      (char )'*',      (char )'*',      (char )' ', 
        (char )'I',      (char )'M',      (char )'P',      (char )'O', 
        (char )'R',      (char )'T',      (char )'A',      (char )'N', 
        (char )'T',      (char )' ',      (char )'N',      (char )'O', 
        (char )'T',      (char )'I',      (char )'C',      (char )'E', 
        (char )' ',      (char )'*',      (char )'*',      (char )'*', 
        (char )'\n',      (char )'O',      (char )'n',      (char )' ', 
        (char )'W',      (char )'i',      (char )'n',      (char )'d', 
        (char )'o',      (char )'w',      (char )'s',      (char )' ', 
        (char )'a',      (char )'n',      (char )'d',      (char )' ', 
        (char )'O',      (char )'p',      (char )'e',      (char )'n', 
        (char )'V',      (char )'M',      (char )'S',      (char )',', 
        (char )' ',      (char )'o',      (char )'n',      (char )'l', 
        (char )'y',      (char )' ',      (char )'s',      (char )'o', 
        (char )'c',      (char )'k',      (char )'e',      (char )'t', 
        (char )'s',      (char )' ',      (char )'a',      (char )'r', 
        (char )'e',      (char )' ',      (char )'s',      (char )'u', 
        (char )'p',      (char )'p',      (char )'o',      (char )'r', 
        (char )'t',      (char )'e',      (char )'d',      (char )';', 
        (char )' ',      (char )'o',      (char )'n',      (char )' ', 
        (char )'U',      (char )'n',      (char )'i',      (char )'x', 
        (char )',',      (char )' ',      (char )'a',      (char )'l', 
        (char )'l',      (char )' ',      (char )'f',      (char )'i', 
        (char )'l',      (char )'e',      (char )'\n',      (char )'d', 
        (char )'e',      (char )'s',      (char )'c',      (char )'r', 
        (char )'i',      (char )'p',      (char )'t',      (char )'o', 
        (char )'r',      (char )'s',      (char )' ',      (char )'c', 
        (char )'a',      (char )'n',      (char )' ',      (char )'b', 
        (char )'e',      (char )' ',      (char )'u',      (char )'s', 
        (char )'e',      (char )'d',      (char )'.',      (char )'\000'};
static PyMethodDef select_methods[3]  = {      {"select", & select_select, 1, (char const   *)(select_doc)}, 
        {"poll", & select_poll, 4, (char const   *)(poll_doc)}, 
        {(char const   *)0, (PyObject *(*)(PyObject * , PyObject * ))0, 0,
      (char const   *)0}};
static char module_doc[177]  = 
  {      (char )'T',      (char )'h',      (char )'i',      (char )'s', 
        (char )' ',      (char )'m',      (char )'o',      (char )'d', 
        (char )'u',      (char )'l',      (char )'e',      (char )' ', 
        (char )'s',      (char )'u',      (char )'p',      (char )'p', 
        (char )'o',      (char )'r',      (char )'t',      (char )'s', 
        (char )' ',      (char )'a',      (char )'s',      (char )'y', 
        (char )'n',      (char )'c',      (char )'h',      (char )'r', 
        (char )'o',      (char )'n',      (char )'o',      (char )'u', 
        (char )'s',      (char )' ',      (char )'I',      (char )'/', 
        (char )'O',      (char )' ',      (char )'o',      (char )'n', 
        (char )' ',      (char )'m',      (char )'u',      (char )'l', 
        (char )'t',      (char )'i',      (char )'p',      (char )'l', 
        (char )'e',      (char )' ',      (char )'f',      (char )'i', 
        (char )'l',      (char )'e',      (char )' ',      (char )'d', 
        (char )'e',      (char )'s',      (char )'c',      (char )'r', 
        (char )'i',      (char )'p',      (char )'t',      (char )'o', 
        (char )'r',      (char )'s',      (char )'.',      (char )'\n', 
        (char )'\n',      (char )'*',      (char )'*',      (char )'*', 
        (char )' ',      (char )'I',      (char )'M',      (char )'P', 
        (char )'O',      (char )'R',      (char )'T',      (char )'A', 
        (char )'N',      (char )'T',      (char )' ',      (char )'N', 
        (char )'O',      (char )'T',      (char )'I',      (char )'C', 
        (char )'E',      (char )' ',      (char )'*',      (char )'*', 
        (char )'*',      (char )'\n',      (char )'O',      (char )'n', 
        (char )' ',      (char )'W',      (char )'i',      (char )'n', 
        (char )'d',      (char )'o',      (char )'w',      (char )'s', 
        (char )' ',      (char )'a',      (char )'n',      (char )'d', 
        (char )' ',      (char )'O',      (char )'p',      (char )'e', 
        (char )'n',      (char )'V',      (char )'M',      (char )'S', 
        (char )',',      (char )' ',      (char )'o',      (char )'n', 
        (char )'l',      (char )'y',      (char )' ',      (char )'s', 
        (char )'o',      (char )'c',      (char )'k',      (char )'e', 
        (char )'t',      (char )'s',      (char )' ',      (char )'a', 
        (char )'r',      (char )'e',      (char )' ',      (char )'s', 
        (char )'u',      (char )'p',      (char )'p',      (char )'o', 
        (char )'r',      (char )'t',      (char )'e',      (char )'d', 
        (char )';',      (char )' ',      (char )'o',      (char )'n', 
        (char )' ',      (char )'U',      (char )'n',      (char )'i', 
        (char )'x',      (char )',',      (char )' ',      (char )'a', 
        (char )'l',      (char )'l',      (char )' ',      (char )'f', 
        (char )'i',      (char )'l',      (char )'e',      (char )' ', 
        (char )'d',      (char )'e',      (char )'s',      (char )'c', 
        (char )'r',      (char )'i',      (char )'p',      (char )'t', 
        (char )'o',      (char )'r',      (char )'s',      (char )'.', 
        (char )'\000'};
static struct PyModuleDef selectmodule  = 
     {{{1, (struct _typeobject *)((void *)0)}, (PyObject *(*)(void))((void *)0),
     0, (PyObject *)((void *)0)}, "select", (char const   *)(module_doc), -1,
    select_methods, (int (*)(PyObject * ))((void *)0),
    (int (*)(PyObject * , int (*)(PyObject * , void * ) , void * ))((void *)0),
    (int (*)(PyObject * ))((void *)0), (void (*)(void * ))((void *)0)};
PyObject *PyInit_select(void) 
{ 
  PyObject *m ;
  int tmp ;
  int tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/home/vagrant/workspace/benchmarks/many-bugs/python/python-bug-69223-69224/./coverage/cov.tmp",
                           "wb");
    if (___coverage_array_already_memset == 0) {
      {
      ___coverage_array_already_memset = 1;
      memset(___coverage_array, 0, sizeof(___coverage_array));
      }
    }
    }
  }
  }
  {
  if (___coverage_array[1114] == 0) {
    {
    fprintf(_coverage_fout, "1114\n");
    fflush(_coverage_fout);
    ___coverage_array[1114] = 1;
    }
  }
  }
  m = PyModule_Create2(& selectmodule, 1013);
  {
  if (___coverage_array[1115] == 0) {
    {
    fprintf(_coverage_fout, "1115\n");
    fflush(_coverage_fout);
    ___coverage_array[1115] = 1;
    }
  }
  }
  if ((unsigned long )m == (unsigned long )((void *)0)) {
    {
    if (___coverage_array[1116] == 0) {
      {
      fprintf(_coverage_fout, "1116\n");
      fflush(_coverage_fout);
      ___coverage_array[1116] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[1117] == 0) {
      {
      fprintf(_coverage_fout, "1117\n");
      fflush(_coverage_fout);
      ___coverage_array[1117] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[1118] == 0) {
    {
    fprintf(_coverage_fout, "1118\n");
    fflush(_coverage_fout);
    ___coverage_array[1118] = 1;
    }
  }
  }
  SelectError = PyErr_NewException("select.error", (PyObject *)((void *)0),
                                   (PyObject *)((void *)0));
  {
  if (___coverage_array[1119] == 0) {
    {
    fprintf(_coverage_fout, "1119\n");
    fflush(_coverage_fout);
    ___coverage_array[1119] = 1;
    }
  }
  }
  (SelectError->ob_refcnt) ++;
  {
  if (___coverage_array[1120] == 0) {
    {
    fprintf(_coverage_fout, "1120\n");
    fflush(_coverage_fout);
    ___coverage_array[1120] = 1;
    }
  }
  }
  PyModule_AddObject(m, "error", SelectError);
  {
  if (___coverage_array[1121] == 0) {
    {
    fprintf(_coverage_fout, "1121\n");
    fflush(_coverage_fout);
    ___coverage_array[1121] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "PIPE_BUF", 4096L);
  {
  if (___coverage_array[1122] == 0) {
    {
    fprintf(_coverage_fout, "1122\n");
    fflush(_coverage_fout);
    ___coverage_array[1122] = 1;
    }
  }
  }
  tmp = PyType_Ready(& poll_Type);
  {
  if (___coverage_array[1123] == 0) {
    {
    fprintf(_coverage_fout, "1123\n");
    fflush(_coverage_fout);
    ___coverage_array[1123] = 1;
    }
  }
  }
  if (tmp < 0) {
    {
    if (___coverage_array[1124] == 0) {
      {
      fprintf(_coverage_fout, "1124\n");
      fflush(_coverage_fout);
      ___coverage_array[1124] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[1125] == 0) {
      {
      fprintf(_coverage_fout, "1125\n");
      fflush(_coverage_fout);
      ___coverage_array[1125] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[1126] == 0) {
    {
    fprintf(_coverage_fout, "1126\n");
    fflush(_coverage_fout);
    ___coverage_array[1126] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "POLLIN", 1L);
  {
  if (___coverage_array[1127] == 0) {
    {
    fprintf(_coverage_fout, "1127\n");
    fflush(_coverage_fout);
    ___coverage_array[1127] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "POLLPRI", 2L);
  {
  if (___coverage_array[1128] == 0) {
    {
    fprintf(_coverage_fout, "1128\n");
    fflush(_coverage_fout);
    ___coverage_array[1128] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "POLLOUT", 4L);
  {
  if (___coverage_array[1129] == 0) {
    {
    fprintf(_coverage_fout, "1129\n");
    fflush(_coverage_fout);
    ___coverage_array[1129] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "POLLERR", 8L);
  {
  if (___coverage_array[1130] == 0) {
    {
    fprintf(_coverage_fout, "1130\n");
    fflush(_coverage_fout);
    ___coverage_array[1130] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "POLLHUP", 16L);
  {
  if (___coverage_array[1131] == 0) {
    {
    fprintf(_coverage_fout, "1131\n");
    fflush(_coverage_fout);
    ___coverage_array[1131] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "POLLNVAL", 32L);
  {
  if (___coverage_array[1132] == 0) {
    {
    fprintf(_coverage_fout, "1132\n");
    fflush(_coverage_fout);
    ___coverage_array[1132] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "POLLRDNORM", 64L);
  {
  if (___coverage_array[1133] == 0) {
    {
    fprintf(_coverage_fout, "1133\n");
    fflush(_coverage_fout);
    ___coverage_array[1133] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "POLLRDBAND", 128L);
  {
  if (___coverage_array[1134] == 0) {
    {
    fprintf(_coverage_fout, "1134\n");
    fflush(_coverage_fout);
    ___coverage_array[1134] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "POLLWRNORM", 256L);
  {
  if (___coverage_array[1135] == 0) {
    {
    fprintf(_coverage_fout, "1135\n");
    fflush(_coverage_fout);
    ___coverage_array[1135] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "POLLWRBAND", 512L);
  {
  if (___coverage_array[1136] == 0) {
    {
    fprintf(_coverage_fout, "1136\n");
    fflush(_coverage_fout);
    ___coverage_array[1136] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "POLLMSG", 1024L);
  {
  if (___coverage_array[1137] == 0) {
    {
    fprintf(_coverage_fout, "1137\n");
    fflush(_coverage_fout);
    ___coverage_array[1137] = 1;
    }
  }
  }
  ((PyObject *)(& pyEpoll_Type))->ob_type = & PyType_Type;
  {
  if (___coverage_array[1138] == 0) {
    {
    fprintf(_coverage_fout, "1138\n");
    fflush(_coverage_fout);
    ___coverage_array[1138] = 1;
    }
  }
  }
  tmp___0 = PyType_Ready(& pyEpoll_Type);
  {
  if (___coverage_array[1139] == 0) {
    {
    fprintf(_coverage_fout, "1139\n");
    fflush(_coverage_fout);
    ___coverage_array[1139] = 1;
    }
  }
  }
  if (tmp___0 < 0) {
    {
    if (___coverage_array[1140] == 0) {
      {
      fprintf(_coverage_fout, "1140\n");
      fflush(_coverage_fout);
      ___coverage_array[1140] = 1;
      }
    }
    }
    return ((PyObject *)((void *)0));
  } else {
    {
    if (___coverage_array[1141] == 0) {
      {
      fprintf(_coverage_fout, "1141\n");
      fflush(_coverage_fout);
      ___coverage_array[1141] = 1;
      }
    }
    }

  }
  {
  if (___coverage_array[1142] == 0) {
    {
    fprintf(_coverage_fout, "1142\n");
    fflush(_coverage_fout);
    ___coverage_array[1142] = 1;
    }
  }
  }
  (((PyObject *)(& pyEpoll_Type))->ob_refcnt) ++;
  {
  if (___coverage_array[1143] == 0) {
    {
    fprintf(_coverage_fout, "1143\n");
    fflush(_coverage_fout);
    ___coverage_array[1143] = 1;
    }
  }
  }
  PyModule_AddObject(m, "epoll", (PyObject *)(& pyEpoll_Type));
  {
  if (___coverage_array[1144] == 0) {
    {
    fprintf(_coverage_fout, "1144\n");
    fflush(_coverage_fout);
    ___coverage_array[1144] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "EPOLLIN", 1L);
  {
  if (___coverage_array[1145] == 0) {
    {
    fprintf(_coverage_fout, "1145\n");
    fflush(_coverage_fout);
    ___coverage_array[1145] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "EPOLLOUT", 4L);
  {
  if (___coverage_array[1146] == 0) {
    {
    fprintf(_coverage_fout, "1146\n");
    fflush(_coverage_fout);
    ___coverage_array[1146] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "EPOLLPRI", 2L);
  {
  if (___coverage_array[1147] == 0) {
    {
    fprintf(_coverage_fout, "1147\n");
    fflush(_coverage_fout);
    ___coverage_array[1147] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "EPOLLERR", 8L);
  {
  if (___coverage_array[1148] == 0) {
    {
    fprintf(_coverage_fout, "1148\n");
    fflush(_coverage_fout);
    ___coverage_array[1148] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "EPOLLHUP", 16L);
  {
  if (___coverage_array[1149] == 0) {
    {
    fprintf(_coverage_fout, "1149\n");
    fflush(_coverage_fout);
    ___coverage_array[1149] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "EPOLLET", (-0x7FFFFFFF-1));
  {
  if (___coverage_array[1150] == 0) {
    {
    fprintf(_coverage_fout, "1150\n");
    fflush(_coverage_fout);
    ___coverage_array[1150] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "EPOLLONESHOT", 1073741824L);
  {
  if (___coverage_array[1151] == 0) {
    {
    fprintf(_coverage_fout, "1151\n");
    fflush(_coverage_fout);
    ___coverage_array[1151] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "EPOLLRDNORM", 64L);
  {
  if (___coverage_array[1152] == 0) {
    {
    fprintf(_coverage_fout, "1152\n");
    fflush(_coverage_fout);
    ___coverage_array[1152] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "EPOLLRDBAND", 128L);
  {
  if (___coverage_array[1153] == 0) {
    {
    fprintf(_coverage_fout, "1153\n");
    fflush(_coverage_fout);
    ___coverage_array[1153] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "EPOLLWRNORM", 256L);
  {
  if (___coverage_array[1154] == 0) {
    {
    fprintf(_coverage_fout, "1154\n");
    fflush(_coverage_fout);
    ___coverage_array[1154] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "EPOLLWRBAND", 512L);
  {
  if (___coverage_array[1155] == 0) {
    {
    fprintf(_coverage_fout, "1155\n");
    fflush(_coverage_fout);
    ___coverage_array[1155] = 1;
    }
  }
  }
  PyModule_AddIntConstant(m, "EPOLLMSG", 1024L);
  {
  if (___coverage_array[1156] == 0) {
    {
    fprintf(_coverage_fout, "1156\n");
    fflush(_coverage_fout);
    ___coverage_array[1156] = 1;
    }
  }
  }
  return (m);
}
}
