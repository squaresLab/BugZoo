from test.test_email import test_main

test_main()
