/* XXX: It is probably best to move timefuncs.h content in here, and
   remove it but user code may rely on it. */
#include "timefuncs.h"
