#define TK_STRING                          1
#define TK_CRLF                            2
#define TK_COLON                           3
#define TK_TAB                             4
