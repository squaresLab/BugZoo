#ifndef _HTTP_PARSER_H_
#define _HTTP_PARSER_H_

typedef enum {
    PARSE_UNSET,
    PARSE_SUCCESS,
    PARSE_ERROR,
    PARSE_NEED_MORE
} parse_status_t;

#endif
