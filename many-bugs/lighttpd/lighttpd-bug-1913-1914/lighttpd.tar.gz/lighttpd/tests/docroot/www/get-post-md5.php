<?php
	print md5($_POST[$_GET["var"]]);
?>
