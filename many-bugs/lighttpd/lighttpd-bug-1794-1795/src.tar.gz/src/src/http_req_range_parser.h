#define TK_BYTES                           1
#define TK_EQUAL                           2
#define TK_COMMA                           3
#define TK_MINUS                           4
#define TK_NUMBER                          5
