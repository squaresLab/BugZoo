typedef unsigned int size_t;
struct __locale_data;
struct __locale_struct {
   struct __locale_data *__locales[13] ;
   unsigned short const   *__ctype_b ;
   int const   *__ctype_tolower ;
   int const   *__ctype_toupper ;
   char const   *__names[13] ;
};
typedef struct __locale_struct *__locale_t;
typedef __locale_t locale_t;
typedef unsigned char __u_char;
typedef unsigned short __u_short;
typedef unsigned int __u_int;
typedef unsigned long __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;
typedef long long __quad_t;
typedef unsigned long long __u_quad_t;
typedef __u_quad_t __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef __u_quad_t __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long __off_t;
typedef __quad_t __off64_t;
typedef int __pid_t;
struct __anonstruct___fsid_t_1 {
   int __val[2] ;
};
typedef struct __anonstruct___fsid_t_1 __fsid_t;
typedef long __clock_t;
typedef unsigned long __rlim_t;
typedef __u_quad_t __rlim64_t;
typedef unsigned int __id_t;
typedef long __time_t;
typedef unsigned int __useconds_t;
typedef long __suseconds_t;
typedef int __daddr_t;
typedef long __swblk_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void *__timer_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef __quad_t __blkcnt64_t;
typedef unsigned long __fsblkcnt_t;
typedef __u_quad_t __fsblkcnt64_t;
typedef unsigned long __fsfilcnt_t;
typedef __u_quad_t __fsfilcnt64_t;
typedef int __ssize_t;
typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;
typedef int __intptr_t;
typedef unsigned int __socklen_t;
typedef long wchar_t;
struct __anonstruct___wait_terminated_2 {
   unsigned int __w_termsig : 7 ;
   unsigned int __w_coredump : 1 ;
   unsigned int __w_retcode : 8 ;
   unsigned int  : 16 ;
};
struct __anonstruct___wait_stopped_3 {
   unsigned int __w_stopval : 8 ;
   unsigned int __w_stopsig : 8 ;
   unsigned int  : 16 ;
};
union wait {
   int w_status ;
   struct __anonstruct___wait_terminated_2 __wait_terminated ;
   struct __anonstruct___wait_stopped_3 __wait_stopped ;
};
union __anonunion___WAIT_STATUS_4 {
   union wait *__uptr ;
   int *__iptr ;
};
typedef union __anonunion___WAIT_STATUS_4  __attribute__((__transparent_union__)) __WAIT_STATUS;
struct __anonstruct_div_t_5 {
   int quot ;
   int rem ;
};
typedef struct __anonstruct_div_t_5 div_t;
struct __anonstruct_ldiv_t_6 {
   long quot ;
   long rem ;
};
typedef struct __anonstruct_ldiv_t_6 ldiv_t;
struct __anonstruct_lldiv_t_7 {
   long long quot ;
   long long rem ;
};
typedef struct __anonstruct_lldiv_t_7 lldiv_t;
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;
typedef __loff_t loff_t;
typedef __ino64_t ino_t;
typedef __dev_t dev_t;
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __nlink_t nlink_t;
typedef __uid_t uid_t;
typedef __off64_t off_t;
typedef __pid_t pid_t;
typedef __id_t id_t;
typedef __ssize_t ssize_t;
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;
typedef __key_t key_t;
typedef __clock_t clock_t;
typedef __time_t time_t;
typedef __clockid_t clockid_t;
typedef __timer_t timer_t;
typedef unsigned long ulong;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char u_int8_t;
typedef unsigned short u_int16_t;
typedef unsigned int u_int32_t;
typedef unsigned long long u_int64_t;
typedef int register_t;
typedef int __sig_atomic_t;
struct __anonstruct___sigset_t_8 {
   unsigned long __val[1024U / (8U * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_8 __sigset_t;
typedef __sigset_t sigset_t;
struct timespec {
   __time_t tv_sec ;
   long tv_nsec ;
};
struct timeval {
   __time_t tv_sec ;
   __suseconds_t tv_usec ;
};
typedef __suseconds_t suseconds_t;
typedef long __fd_mask;
struct __anonstruct_fd_set_9 {
   __fd_mask __fds_bits[1024 / (8 * (int )sizeof(__fd_mask ))] ;
};
typedef struct __anonstruct_fd_set_9 fd_set;
typedef __fd_mask fd_mask;
typedef __blksize_t blksize_t;
typedef __blkcnt64_t blkcnt_t;
typedef __fsblkcnt64_t fsblkcnt_t;
typedef __fsfilcnt64_t fsfilcnt_t;
typedef unsigned long pthread_t;
union __anonunion_pthread_attr_t_10 {
   char __size[36] ;
   long __align ;
};
typedef union __anonunion_pthread_attr_t_10 pthread_attr_t;
struct __pthread_internal_slist {
   struct __pthread_internal_slist *__next ;
};
typedef struct __pthread_internal_slist __pthread_slist_t;
union __anonunion____missing_field_name_12 {
   int __spins ;
   __pthread_slist_t __list ;
};
struct __pthread_mutex_s {
   int __lock ;
   unsigned int __count ;
   int __owner ;
   int __kind ;
   unsigned int __nusers ;
   union __anonunion____missing_field_name_12 __annonCompField1 ;
};
union __anonunion_pthread_mutex_t_11 {
   struct __pthread_mutex_s __data ;
   char __size[24] ;
   long __align ;
};
typedef union __anonunion_pthread_mutex_t_11 pthread_mutex_t;
union __anonunion_pthread_mutexattr_t_13 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_mutexattr_t_13 pthread_mutexattr_t;
struct __anonstruct___data_15 {
   int __lock ;
   unsigned int __futex ;
   unsigned long long __total_seq ;
   unsigned long long __wakeup_seq ;
   unsigned long long __woken_seq ;
   void *__mutex ;
   unsigned int __nwaiters ;
   unsigned int __broadcast_seq ;
};
union __anonunion_pthread_cond_t_14 {
   struct __anonstruct___data_15 __data ;
   char __size[48] ;
   long long __align ;
};
typedef union __anonunion_pthread_cond_t_14 pthread_cond_t;
union __anonunion_pthread_condattr_t_16 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_condattr_t_16 pthread_condattr_t;
typedef unsigned int pthread_key_t;
typedef int pthread_once_t;
struct __anonstruct___data_18 {
   int __lock ;
   unsigned int __nr_readers ;
   unsigned int __readers_wakeup ;
   unsigned int __writer_wakeup ;
   unsigned int __nr_readers_queued ;
   unsigned int __nr_writers_queued ;
   unsigned char __flags ;
   unsigned char __shared ;
   unsigned char __pad1 ;
   unsigned char __pad2 ;
   int __writer ;
};
union __anonunion_pthread_rwlock_t_17 {
   struct __anonstruct___data_18 __data ;
   char __size[32] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlock_t_17 pthread_rwlock_t;
union __anonunion_pthread_rwlockattr_t_19 {
   char __size[8] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlockattr_t_19 pthread_rwlockattr_t;
typedef int volatile   pthread_spinlock_t;
union __anonunion_pthread_barrier_t_20 {
   char __size[20] ;
   long __align ;
};
typedef union __anonunion_pthread_barrier_t_20 pthread_barrier_t;
union __anonunion_pthread_barrierattr_t_21 {
   char __size[4] ;
   int __align ;
};
typedef union __anonunion_pthread_barrierattr_t_21 pthread_barrierattr_t;
struct random_data {
   int32_t *fptr ;
   int32_t *rptr ;
   int32_t *state ;
   int rand_type ;
   int rand_deg ;
   int rand_sep ;
   int32_t *end_ptr ;
};
struct drand48_data {
   unsigned short __x[3] ;
   unsigned short __old_x[3] ;
   unsigned short __c ;
   unsigned short __init ;
   unsigned long long __a ;
};
typedef int (*__compar_fn_t)(void const   * , void const   * );
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_23 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_22 {
   int __count ;
   union __anonunion___value_23 __value ;
};
typedef struct __anonstruct___mbstate_t_22 __mbstate_t;
struct __anonstruct__G_fpos_t_24 {
   __off_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos_t_24 _G_fpos_t;
struct __anonstruct__G_fpos64_t_25 {
   __off64_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos64_t_25 _G_fpos64_t;
typedef short _G_int16_t;
typedef int _G_int32_t;
typedef unsigned short _G_uint16_t;
typedef unsigned int _G_uint32_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_jump_t;
struct _IO_jump_t;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
enum __codecvt_result {
    __codecvt_ok = 0,
    __codecvt_partial = 1,
    __codecvt_error = 2,
    __codecvt_noconv = 3
} ;
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15U * sizeof(int ) - 4U * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
struct _IO_FILE_plus;
struct _IO_FILE_plus;
typedef __ssize_t __io_read_fn(void *__cookie , char *__buf , size_t __nbytes );
typedef __ssize_t __io_write_fn(void *__cookie , char const   *__buf , size_t __n );
typedef int __io_seek_fn(void *__cookie , __off64_t *__pos , int __w );
typedef int __io_close_fn(void *__cookie );
typedef __gnuc_va_list va_list;
typedef _G_fpos64_t fpos_t;
enum __anonenum_Vg_ClientRequest_26 {
    VG_USERREQ__RUNNING_ON_VALGRIND = 4097,
    VG_USERREQ__DISCARD_TRANSLATIONS = 4098,
    VG_USERREQ__CLIENT_CALL0 = 4353,
    VG_USERREQ__CLIENT_CALL1 = 4354,
    VG_USERREQ__CLIENT_CALL2 = 4355,
    VG_USERREQ__CLIENT_CALL3 = 4356,
    VG_USERREQ__COUNT_ERRORS = 4609,
    VG_USERREQ__MALLOCLIKE_BLOCK = 4865,
    VG_USERREQ__FREELIKE_BLOCK = 4866,
    VG_USERREQ__CREATE_MEMPOOL = 4867,
    VG_USERREQ__DESTROY_MEMPOOL = 4868,
    VG_USERREQ__MEMPOOL_ALLOC = 4869,
    VG_USERREQ__MEMPOOL_FREE = 4870,
    VG_USERREQ__PRINTF = 5121,
    VG_USERREQ__PRINTF_BACKTRACE = 5122,
    VG_USERREQ__STACK_REGISTER = 5377,
    VG_USERREQ__STACK_DEREGISTER = 5378,
    VG_USERREQ__STACK_CHANGE = 5379
} ;
typedef enum __anonenum_Vg_ClientRequest_26 Vg_ClientRequest;
typedef int ptrdiff_t;
typedef signed char gint8;
typedef unsigned char guint8;
typedef short gint16;
typedef unsigned short guint16;
typedef int gint32;
typedef unsigned int guint32;
typedef long long gint64;
typedef unsigned long long guint64;
typedef int gssize;
typedef unsigned int gsize;
typedef gint64 goffset;
typedef int gintptr;
typedef unsigned int guintptr;
struct _GStaticMutex;
typedef struct _GStaticMutex GStaticMutex;
struct _GMutex;
union __anonunion_static_mutex_27 {
   char pad[24] ;
   double dummy_double ;
   void *dummy_pointer ;
   long dummy_long ;
};
struct _GStaticMutex {
   struct _GMutex *runtime_mutex ;
   union __anonunion_static_mutex_27 static_mutex ;
};
union _GSystemThread;
typedef union _GSystemThread GSystemThread;
union _GSystemThread {
   char data[4] ;
   double dummy_double ;
   void *dummy_pointer ;
   long dummy_long ;
};
typedef int GPid;
typedef char gchar;
typedef short gshort;
typedef long glong;
typedef int gint;
typedef gint gboolean;
typedef unsigned char guchar;
typedef unsigned short gushort;
typedef unsigned long gulong;
typedef unsigned int guint;
typedef float gfloat;
typedef double gdouble;
typedef void *gpointer;
typedef void const   *gconstpointer;
typedef gint (*GCompareFunc)(gconstpointer a , gconstpointer b );
typedef gint (*GCompareDataFunc)(gconstpointer a , gconstpointer b , gpointer user_data );
typedef gboolean (*GEqualFunc)(gconstpointer a , gconstpointer b );
typedef void (*GDestroyNotify)(gpointer data );
typedef void (*GFunc)(gpointer data , gpointer user_data );
typedef guint (*GHashFunc)(gconstpointer key );
typedef void (*GHFunc)(gpointer key , gpointer value , gpointer user_data );
typedef void (*GFreeFunc)(gpointer data );
typedef gchar const   *(*GTranslateFunc)(gchar const   *str , gpointer data );
union _GDoubleIEEE754;
typedef union _GDoubleIEEE754 GDoubleIEEE754;
union _GFloatIEEE754;
typedef union _GFloatIEEE754 GFloatIEEE754;
struct __anonstruct_mpn_28 {
   guint mantissa : 23 ;
   guint biased_exponent : 8 ;
   guint sign : 1 ;
};
union _GFloatIEEE754 {
   gfloat v_float ;
   struct __anonstruct_mpn_28 mpn ;
};
struct __anonstruct_mpn_29 {
   guint mantissa_low : 32 ;
   guint mantissa_high : 20 ;
   guint biased_exponent : 11 ;
   guint sign : 1 ;
};
union _GDoubleIEEE754 {
   gdouble v_double ;
   struct __anonstruct_mpn_29 mpn ;
};
struct _GTimeVal;
typedef struct _GTimeVal GTimeVal;
struct _GTimeVal {
   glong tv_sec ;
   glong tv_usec ;
};
struct _GArray;
typedef struct _GArray GArray;
struct _GByteArray;
typedef struct _GByteArray GByteArray;
struct _GPtrArray;
typedef struct _GPtrArray GPtrArray;
struct _GArray {
   gchar *data ;
   guint len ;
};
struct _GByteArray {
   guint8 *data ;
   guint len ;
};
struct _GPtrArray {
   gpointer *pdata ;
   guint len ;
};
typedef guint32 GQuark;
struct _GError;
typedef struct _GError GError;
struct _GError {
   GQuark domain ;
   gint code ;
   gchar *message ;
};
enum __anonenum_GUserDirectory_30 {
    G_USER_DIRECTORY_DESKTOP = 0,
    G_USER_DIRECTORY_DOCUMENTS = 1,
    G_USER_DIRECTORY_DOWNLOAD = 2,
    G_USER_DIRECTORY_MUSIC = 3,
    G_USER_DIRECTORY_PICTURES = 4,
    G_USER_DIRECTORY_PUBLIC_SHARE = 5,
    G_USER_DIRECTORY_TEMPLATES = 6,
    G_USER_DIRECTORY_VIDEOS = 7,
    G_USER_N_DIRECTORIES = 8
} ;
typedef enum __anonenum_GUserDirectory_30 GUserDirectory;
struct _GDebugKey;
typedef struct _GDebugKey GDebugKey;
struct _GDebugKey {
   gchar const   *key ;
   guint value ;
};
typedef void (*GVoidFunc)(void);
struct _GTrashStack;
typedef struct _GTrashStack GTrashStack;
struct _GTrashStack {
   GTrashStack *next ;
};
enum __anonenum_GThreadError_31 {
    G_THREAD_ERROR_AGAIN = 0
} ;
typedef enum __anonenum_GThreadError_31 GThreadError;
typedef gpointer (*GThreadFunc)(gpointer data );
enum __anonenum_GThreadPriority_32 {
    G_THREAD_PRIORITY_LOW = 0,
    G_THREAD_PRIORITY_NORMAL = 1,
    G_THREAD_PRIORITY_HIGH = 2,
    G_THREAD_PRIORITY_URGENT = 3
} ;
typedef enum __anonenum_GThreadPriority_32 GThreadPriority;
struct _GThread;
typedef struct _GThread GThread;
struct _GThread {
   gpointer (*func)(gpointer data ) ;
   gpointer data ;
   gboolean joinable ;
   GThreadPriority priority ;
};
typedef struct _GMutex GMutex;
struct _GCond;
typedef struct _GCond GCond;
struct _GPrivate;
typedef struct _GPrivate GPrivate;
struct _GStaticPrivate;
typedef struct _GStaticPrivate GStaticPrivate;
struct _GThreadFunctions;
typedef struct _GThreadFunctions GThreadFunctions;
struct _GThreadFunctions {
   GMutex *(*mutex_new)(void) ;
   void (*mutex_lock)(GMutex *mutex ) ;
   gboolean (*mutex_trylock)(GMutex *mutex ) ;
   void (*mutex_unlock)(GMutex *mutex ) ;
   void (*mutex_free)(GMutex *mutex ) ;
   GCond *(*cond_new)(void) ;
   void (*cond_signal)(GCond *cond ) ;
   void (*cond_broadcast)(GCond *cond ) ;
   void (*cond_wait)(GCond *cond , GMutex *mutex ) ;
   gboolean (*cond_timed_wait)(GCond *cond , GMutex *mutex , GTimeVal *end_time ) ;
   void (*cond_free)(GCond *cond ) ;
   GPrivate *(*private_new)(void (*destructor)(gpointer data ) ) ;
   gpointer (*private_get)(GPrivate *private_key ) ;
   void (*private_set)(GPrivate *private_key , gpointer data ) ;
   void (*thread_create)(gpointer (*func)(gpointer data ) , gpointer data , gulong stack_size , gboolean joinable , gboolean bound , GThreadPriority priority , gpointer thread , GError **error ) ;
   void (*thread_yield)(void) ;
   void (*thread_join)(gpointer thread ) ;
   void (*thread_exit)(void) ;
   void (*thread_set_priority)(gpointer thread , GThreadPriority priority ) ;
   void (*thread_self)(gpointer thread ) ;
   gboolean (*thread_equal)(gpointer thread1 , gpointer thread2 ) ;
};
struct _GStaticPrivate {
   guint index ;
};
struct _GStaticRecMutex;
typedef struct _GStaticRecMutex GStaticRecMutex;
struct _GStaticRecMutex {
   GStaticMutex mutex ;
   guint depth ;
   GSystemThread owner ;
};
struct _GStaticRWLock;
typedef struct _GStaticRWLock GStaticRWLock;
struct _GStaticRWLock {
   GStaticMutex mutex ;
   GCond *read_cond ;
   GCond *write_cond ;
   guint read_counter ;
   gboolean have_writer ;
   guint want_to_read ;
   guint want_to_write ;
};
enum __anonenum_GOnceStatus_33 {
    G_ONCE_STATUS_NOTCALLED = 0,
    G_ONCE_STATUS_PROGRESS = 1,
    G_ONCE_STATUS_READY = 2
} ;
typedef enum __anonenum_GOnceStatus_33 GOnceStatus;
struct _GOnce;
typedef struct _GOnce GOnce;
struct _GOnce {
   GOnceStatus volatile   status ;
   gpointer volatile   retval ;
};
struct _GAsyncQueue;
typedef struct _GAsyncQueue GAsyncQueue;
typedef __sig_atomic_t sig_atomic_t;
union sigval {
   int sival_int ;
   void *sival_ptr ;
};
typedef union sigval sigval_t;
struct __anonstruct__kill_35 {
   __pid_t si_pid ;
   __uid_t si_uid ;
};
struct __anonstruct__timer_36 {
   int si_tid ;
   int si_overrun ;
   sigval_t si_sigval ;
};
struct __anonstruct__rt_37 {
   __pid_t si_pid ;
   __uid_t si_uid ;
   sigval_t si_sigval ;
};
struct __anonstruct__sigchld_38 {
   __pid_t si_pid ;
   __uid_t si_uid ;
   int si_status ;
   __clock_t si_utime ;
   __clock_t si_stime ;
};
struct __anonstruct__sigfault_39 {
   void *si_addr ;
};
struct __anonstruct__sigpoll_40 {
   long si_band ;
   int si_fd ;
};
union __anonunion__sifields_34 {
   int _pad[128U / sizeof(int ) - 3U] ;
   struct __anonstruct__kill_35 _kill ;
   struct __anonstruct__timer_36 _timer ;
   struct __anonstruct__rt_37 _rt ;
   struct __anonstruct__sigchld_38 _sigchld ;
   struct __anonstruct__sigfault_39 _sigfault ;
   struct __anonstruct__sigpoll_40 _sigpoll ;
};
struct siginfo {
   int si_signo ;
   int si_errno ;
   int si_code ;
   union __anonunion__sifields_34 _sifields ;
};
typedef struct siginfo siginfo_t;
enum __anonenum_41 {
    SI_ASYNCNL = -60,
    SI_TKILL = -6,
    SI_SIGIO = -5,
    SI_ASYNCIO = -4,
    SI_MESGQ = -3,
    SI_TIMER = -2,
    SI_QUEUE = -1,
    SI_USER = 0,
    SI_KERNEL = 128
} ;
enum __anonenum_42 {
    ILL_ILLOPC = 1,
    ILL_ILLOPN = 2,
    ILL_ILLADR = 3,
    ILL_ILLTRP = 4,
    ILL_PRVOPC = 5,
    ILL_PRVREG = 6,
    ILL_COPROC = 7,
    ILL_BADSTK = 8
} ;
enum __anonenum_43 {
    FPE_INTDIV = 1,
    FPE_INTOVF = 2,
    FPE_FLTDIV = 3,
    FPE_FLTOVF = 4,
    FPE_FLTUND = 5,
    FPE_FLTRES = 6,
    FPE_FLTINV = 7,
    FPE_FLTSUB = 8
} ;
enum __anonenum_44 {
    SEGV_MAPERR = 1,
    SEGV_ACCERR = 2
} ;
enum __anonenum_45 {
    BUS_ADRALN = 1,
    BUS_ADRERR = 2,
    BUS_OBJERR = 3
} ;
enum __anonenum_46 {
    TRAP_BRKPT = 1,
    TRAP_TRACE = 2
} ;
enum __anonenum_47 {
    CLD_EXITED = 1,
    CLD_KILLED = 2,
    CLD_DUMPED = 3,
    CLD_TRAPPED = 4,
    CLD_STOPPED = 5,
    CLD_CONTINUED = 6
} ;
enum __anonenum_48 {
    POLL_IN = 1,
    POLL_OUT = 2,
    POLL_MSG = 3,
    POLL_ERR = 4,
    POLL_PRI = 5,
    POLL_HUP = 6
} ;
struct __anonstruct__sigev_thread_50 {
   void (*_function)(sigval_t  ) ;
   void *_attribute ;
};
union __anonunion__sigev_un_49 {
   int _pad[64U / sizeof(int ) - 3U] ;
   __pid_t _tid ;
   struct __anonstruct__sigev_thread_50 _sigev_thread ;
};
struct sigevent {
   sigval_t sigev_value ;
   int sigev_signo ;
   int sigev_notify ;
   union __anonunion__sigev_un_49 _sigev_un ;
};
typedef struct sigevent sigevent_t;
enum __anonenum_51 {
    SIGEV_SIGNAL = 0,
    SIGEV_NONE = 1,
    SIGEV_THREAD = 2,
    SIGEV_THREAD_ID = 4
} ;
typedef void (*__sighandler_t)(int  );
typedef void (*sig_t)(int  );
union __anonunion___sigaction_handler_52 {
   void (*sa_handler)(int  ) ;
   void (*sa_sigaction)(int  , siginfo_t * , void * ) ;
};
struct sigaction {
   union __anonunion___sigaction_handler_52 __sigaction_handler ;
   __sigset_t sa_mask ;
   int sa_flags ;
   void (*sa_restorer)(void) ;
};
struct sigvec {
   void (*sv_handler)(int  ) ;
   int sv_mask ;
   int sv_flags ;
};
typedef signed char __s8;
typedef unsigned char __u8;
typedef short __s16;
typedef unsigned short __u16;
typedef int __s32;
typedef unsigned int __u32;
typedef long long __s64;
typedef unsigned long long __u64;
typedef unsigned short umode_t;
struct __anonstruct___kernel_fd_set_53 {
   unsigned long fds_bits[1024U / (8U * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___kernel_fd_set_53 __kernel_fd_set;
typedef void (*__kernel_sighandler_t)(int  );
typedef int __kernel_key_t;
typedef int __kernel_mqd_t;
typedef unsigned long __kernel_ino_t;
typedef unsigned short __kernel_mode_t;
typedef unsigned short __kernel_nlink_t;
typedef long __kernel_off_t;
typedef int __kernel_pid_t;
typedef unsigned short __kernel_ipc_pid_t;
typedef unsigned short __kernel_uid_t;
typedef unsigned short __kernel_gid_t;
typedef unsigned int __kernel_size_t;
typedef int __kernel_ssize_t;
typedef int __kernel_ptrdiff_t;
typedef long __kernel_time_t;
typedef long __kernel_suseconds_t;
typedef long __kernel_clock_t;
typedef int __kernel_timer_t;
typedef int __kernel_clockid_t;
typedef int __kernel_daddr_t;
typedef char *__kernel_caddr_t;
typedef unsigned short __kernel_uid16_t;
typedef unsigned short __kernel_gid16_t;
typedef unsigned int __kernel_uid32_t;
typedef unsigned int __kernel_gid32_t;
typedef unsigned short __kernel_old_uid_t;
typedef unsigned short __kernel_old_gid_t;
typedef unsigned short __kernel_old_dev_t;
typedef long long __kernel_loff_t;
struct __anonstruct___kernel_fsid_t_54 {
   int val[2] ;
};
typedef struct __anonstruct___kernel_fsid_t_54 __kernel_fsid_t;
typedef __u16 __le16;
typedef __u16 __be16;
typedef __u32 __le32;
typedef __u32 __be32;
typedef __u64 __le64;
typedef __u64 __be64;
typedef __u16 __sum16;
typedef __u32 __wsum;
struct _fpx_sw_bytes {
   __u32 magic1 ;
   __u32 extended_size ;
   __u64 xstate_bv ;
   __u32 xstate_size ;
   __u32 padding[7] ;
};
struct _fpreg {
   unsigned short significand[4] ;
   unsigned short exponent ;
};
struct _fpxreg {
   unsigned short significand[4] ;
   unsigned short exponent ;
   unsigned short padding[3] ;
};
struct _xmmreg {
   unsigned long element[4] ;
};
union __anonunion____missing_field_name_55 {
   unsigned long padding2[12] ;
   struct _fpx_sw_bytes sw_reserved ;
};
struct _fpstate {
   unsigned long cw ;
   unsigned long sw ;
   unsigned long tag ;
   unsigned long ipoff ;
   unsigned long cssel ;
   unsigned long dataoff ;
   unsigned long datasel ;
   struct _fpreg _st[8] ;
   unsigned short status ;
   unsigned short magic ;
   unsigned long _fxsr_env[6] ;
   unsigned long mxcsr ;
   unsigned long reserved ;
   struct _fpxreg _fxsr_st[8] ;
   struct _xmmreg _xmm[8] ;
   unsigned long padding1[44] ;
   union __anonunion____missing_field_name_55 __annonCompField2 ;
};
struct sigcontext {
   unsigned short gs ;
   unsigned short __gsh ;
   unsigned short fs ;
   unsigned short __fsh ;
   unsigned short es ;
   unsigned short __esh ;
   unsigned short ds ;
   unsigned short __dsh ;
   unsigned long edi ;
   unsigned long esi ;
   unsigned long ebp ;
   unsigned long esp ;
   unsigned long ebx ;
   unsigned long edx ;
   unsigned long ecx ;
   unsigned long eax ;
   unsigned long trapno ;
   unsigned long err ;
   unsigned long eip ;
   unsigned short cs ;
   unsigned short __csh ;
   unsigned long eflags ;
   unsigned long esp_at_signal ;
   unsigned short ss ;
   unsigned short __ssh ;
   struct _fpstate *fpstate ;
   unsigned long oldmask ;
   unsigned long cr2 ;
};
struct _xsave_hdr {
   __u64 xstate_bv ;
   __u64 reserved1[2] ;
   __u64 reserved2[5] ;
};
struct _ymmh_state {
   __u32 ymmh_space[64] ;
};
struct _xstate {
   struct _fpstate fpstate ;
   struct _xsave_hdr xstate_hdr ;
   struct _ymmh_state ymmh ;
};
struct sigstack {
   void *ss_sp ;
   int ss_onstack ;
};
enum __anonenum_56 {
    SS_ONSTACK = 1,
    SS_DISABLE = 2
} ;
struct sigaltstack {
   void *ss_sp ;
   int ss_flags ;
   size_t ss_size ;
};
typedef struct sigaltstack stack_t;
typedef int greg_t;
typedef greg_t gregset_t[19];
struct _libc_fpreg {
   unsigned short significand[4] ;
   unsigned short exponent ;
};
struct _libc_fpstate {
   unsigned long cw ;
   unsigned long sw ;
   unsigned long tag ;
   unsigned long ipoff ;
   unsigned long cssel ;
   unsigned long dataoff ;
   unsigned long datasel ;
   struct _libc_fpreg _st[8] ;
   unsigned long status ;
};
typedef struct _libc_fpstate *fpregset_t;
struct __anonstruct_mcontext_t_57 {
   gregset_t gregs ;
   fpregset_t fpregs ;
   unsigned long oldmask ;
   unsigned long cr2 ;
};
typedef struct __anonstruct_mcontext_t_57 mcontext_t;
struct ucontext {
   unsigned long uc_flags ;
   struct ucontext *uc_link ;
   stack_t uc_stack ;
   mcontext_t uc_mcontext ;
   __sigset_t uc_sigmask ;
   struct _libc_fpstate __fpregs_mem ;
};
typedef struct ucontext ucontext_t;
struct tm {
   int tm_sec ;
   int tm_min ;
   int tm_hour ;
   int tm_mday ;
   int tm_mon ;
   int tm_year ;
   int tm_wday ;
   int tm_yday ;
   int tm_isdst ;
   long tm_gmtoff ;
   char const   *tm_zone ;
};
struct itimerspec {
   struct timespec it_interval ;
   struct timespec it_value ;
};
struct sigevent;
enum __anonenum_GBookmarkFileError_58 {
    G_BOOKMARK_FILE_ERROR_INVALID_URI = 0,
    G_BOOKMARK_FILE_ERROR_INVALID_VALUE = 1,
    G_BOOKMARK_FILE_ERROR_APP_NOT_REGISTERED = 2,
    G_BOOKMARK_FILE_ERROR_URI_NOT_FOUND = 3,
    G_BOOKMARK_FILE_ERROR_READ = 4,
    G_BOOKMARK_FILE_ERROR_UNKNOWN_ENCODING = 5,
    G_BOOKMARK_FILE_ERROR_WRITE = 6,
    G_BOOKMARK_FILE_ERROR_FILE_NOT_FOUND = 7
} ;
typedef enum __anonenum_GBookmarkFileError_58 GBookmarkFileError;
struct _GBookmarkFile;
typedef struct _GBookmarkFile GBookmarkFile;
enum __anonenum_GSliceConfig_59 {
    G_SLICE_CONFIG_ALWAYS_MALLOC = 1,
    G_SLICE_CONFIG_BYPASS_MAGAZINES = 2,
    G_SLICE_CONFIG_WORKING_SET_MSECS = 3,
    G_SLICE_CONFIG_COLOR_INCREMENT = 4,
    G_SLICE_CONFIG_CHUNK_SIZES = 5,
    G_SLICE_CONFIG_CONTENTION_COUNTER = 6
} ;
typedef enum __anonenum_GSliceConfig_59 GSliceConfig;
struct _GMemVTable;
typedef struct _GMemVTable GMemVTable;
struct _GMemVTable {
   gpointer (*malloc)(gsize n_bytes ) ;
   gpointer (*realloc)(gpointer mem , gsize n_bytes ) ;
   void (*free)(gpointer mem ) ;
   gpointer (*calloc)(gsize n_blocks , gsize n_block_bytes ) ;
   gpointer (*try_malloc)(gsize n_bytes ) ;
   gpointer (*try_realloc)(gpointer mem , gsize n_bytes ) ;
};
struct _GAllocator;
typedef struct _GAllocator GAllocator;
struct _GMemChunk;
typedef struct _GMemChunk GMemChunk;
struct _GList;
typedef struct _GList GList;
struct _GList {
   gpointer data ;
   GList *next ;
   GList *prev ;
};
struct _GCache;
typedef struct _GCache GCache;
typedef gpointer (*GCacheNewFunc)(gpointer key );
typedef gpointer (*GCacheDupFunc)(gpointer value );
typedef void (*GCacheDestroyFunc)(gpointer value );
enum __anonenum_GChecksumType_60 {
    G_CHECKSUM_MD5 = 0,
    G_CHECKSUM_SHA1 = 1,
    G_CHECKSUM_SHA256 = 2
} ;
typedef enum __anonenum_GChecksumType_60 GChecksumType;
struct _GChecksum;
typedef struct _GChecksum GChecksum;
struct _GCompletion;
typedef struct _GCompletion GCompletion;
typedef gchar *(*GCompletionFunc)(gpointer  );
typedef gint (*GCompletionStrncmpFunc)(gchar const   *s1 , gchar const   *s2 , gsize n );
struct _GCompletion {
   GList *items ;
   gchar *(*func)(gpointer  ) ;
   gchar *prefix ;
   GList *cache ;
   gint (*strncmp_func)(gchar const   *s1 , gchar const   *s2 , gsize n ) ;
};
enum __anonenum_GConvertError_61 {
    G_CONVERT_ERROR_NO_CONVERSION = 0,
    G_CONVERT_ERROR_ILLEGAL_SEQUENCE = 1,
    G_CONVERT_ERROR_FAILED = 2,
    G_CONVERT_ERROR_PARTIAL_INPUT = 3,
    G_CONVERT_ERROR_BAD_URI = 4,
    G_CONVERT_ERROR_NOT_ABSOLUTE_PATH = 5
} ;
typedef enum __anonenum_GConvertError_61 GConvertError;
struct _GIConv;
typedef struct _GIConv *GIConv;
struct _GData;
typedef struct _GData GData;
typedef void (*GDataForeachFunc)(GQuark key_id , gpointer data , gpointer user_data );
typedef gint32 GTime;
typedef guint16 GDateYear;
typedef guint8 GDateDay;
struct _GDate;
typedef struct _GDate GDate;
enum __anonenum_GDateDMY_62 {
    G_DATE_DAY = 0,
    G_DATE_MONTH = 1,
    G_DATE_YEAR = 2
} ;
typedef enum __anonenum_GDateDMY_62 GDateDMY;
enum __anonenum_GDateWeekday_63 {
    G_DATE_BAD_WEEKDAY = 0,
    G_DATE_MONDAY = 1,
    G_DATE_TUESDAY = 2,
    G_DATE_WEDNESDAY = 3,
    G_DATE_THURSDAY = 4,
    G_DATE_FRIDAY = 5,
    G_DATE_SATURDAY = 6,
    G_DATE_SUNDAY = 7
} ;
typedef enum __anonenum_GDateWeekday_63 GDateWeekday;
enum __anonenum_GDateMonth_64 {
    G_DATE_BAD_MONTH = 0,
    G_DATE_JANUARY = 1,
    G_DATE_FEBRUARY = 2,
    G_DATE_MARCH = 3,
    G_DATE_APRIL = 4,
    G_DATE_MAY = 5,
    G_DATE_JUNE = 6,
    G_DATE_JULY = 7,
    G_DATE_AUGUST = 8,
    G_DATE_SEPTEMBER = 9,
    G_DATE_OCTOBER = 10,
    G_DATE_NOVEMBER = 11,
    G_DATE_DECEMBER = 12
} ;
typedef enum __anonenum_GDateMonth_64 GDateMonth;
struct _GDate {
   guint julian_days : 32 ;
   guint julian : 1 ;
   guint dmy : 1 ;
   guint day : 6 ;
   guint month : 4 ;
   guint year : 16 ;
};
struct _GDir;
typedef struct _GDir GDir;
enum __anonenum_GFileError_65 {
    G_FILE_ERROR_EXIST = 0,
    G_FILE_ERROR_ISDIR = 1,
    G_FILE_ERROR_ACCES = 2,
    G_FILE_ERROR_NAMETOOLONG = 3,
    G_FILE_ERROR_NOENT = 4,
    G_FILE_ERROR_NOTDIR = 5,
    G_FILE_ERROR_NXIO = 6,
    G_FILE_ERROR_NODEV = 7,
    G_FILE_ERROR_ROFS = 8,
    G_FILE_ERROR_TXTBSY = 9,
    G_FILE_ERROR_FAULT = 10,
    G_FILE_ERROR_LOOP = 11,
    G_FILE_ERROR_NOSPC = 12,
    G_FILE_ERROR_NOMEM = 13,
    G_FILE_ERROR_MFILE = 14,
    G_FILE_ERROR_NFILE = 15,
    G_FILE_ERROR_BADF = 16,
    G_FILE_ERROR_INVAL = 17,
    G_FILE_ERROR_PIPE = 18,
    G_FILE_ERROR_AGAIN = 19,
    G_FILE_ERROR_INTR = 20,
    G_FILE_ERROR_IO = 21,
    G_FILE_ERROR_PERM = 22,
    G_FILE_ERROR_NOSYS = 23,
    G_FILE_ERROR_FAILED = 24
} ;
typedef enum __anonenum_GFileError_65 GFileError;
enum __anonenum_GFileTest_66 {
    G_FILE_TEST_IS_REGULAR = 1,
    G_FILE_TEST_IS_SYMLINK = 2,
    G_FILE_TEST_IS_DIR = 4,
    G_FILE_TEST_IS_EXECUTABLE = 8,
    G_FILE_TEST_EXISTS = 16
} ;
typedef enum __anonenum_GFileTest_66 GFileTest;
struct _GHashTable;
typedef struct _GHashTable GHashTable;
typedef gboolean (*GHRFunc)(gpointer key , gpointer value , gpointer user_data );
struct _GHashTableIter;
typedef struct _GHashTableIter GHashTableIter;
struct _GHashTableIter {
   gpointer dummy1 ;
   gpointer dummy2 ;
   gpointer dummy3 ;
   int dummy4 ;
   gboolean dummy5 ;
   gpointer dummy6 ;
};
struct _GHook;
typedef struct _GHook GHook;
struct _GHookList;
typedef struct _GHookList GHookList;
typedef gint (*GHookCompareFunc)(GHook *new_hook , GHook *sibling );
typedef gboolean (*GHookFindFunc)(GHook *hook , gpointer data );
typedef void (*GHookMarshaller)(GHook *hook , gpointer marshal_data );
typedef gboolean (*GHookCheckMarshaller)(GHook *hook , gpointer marshal_data );
typedef void (*GHookFunc)(gpointer data );
typedef gboolean (*GHookCheckFunc)(gpointer data );
typedef void (*GHookFinalizeFunc)(GHookList *hook_list , GHook *hook );
enum __anonenum_GHookFlagMask_67 {
    G_HOOK_FLAG_ACTIVE = 1,
    G_HOOK_FLAG_IN_CALL = 2,
    G_HOOK_FLAG_MASK = 15
} ;
typedef enum __anonenum_GHookFlagMask_67 GHookFlagMask;
struct _GHookList {
   gulong seq_id ;
   guint hook_size : 16 ;
   guint is_setup : 1 ;
   GHook *hooks ;
   gpointer dummy3 ;
   void (*finalize_hook)(GHookList *hook_list , GHook *hook ) ;
   gpointer dummy[2] ;
};
struct _GHook {
   gpointer data ;
   GHook *next ;
   GHook *prev ;
   guint ref_count ;
   gulong hook_id ;
   guint flags ;
   gpointer func ;
   void (*destroy)(gpointer data ) ;
};
struct _GPollFD;
typedef struct _GPollFD GPollFD;
typedef gint (*GPollFunc)(GPollFD *ufds , guint nfsd , gint timeout_ );
struct _GPollFD {
   gint fd ;
   gushort events ;
   gushort revents ;
};
struct _GSList;
typedef struct _GSList GSList;
struct _GSList {
   gpointer data ;
   GSList *next ;
};
struct _GMainContext;
typedef struct _GMainContext GMainContext;
struct _GMainLoop;
typedef struct _GMainLoop GMainLoop;
struct _GSource;
typedef struct _GSource GSource;
struct _GSourceCallbackFuncs;
typedef struct _GSourceCallbackFuncs GSourceCallbackFuncs;
struct _GSourceFuncs;
typedef struct _GSourceFuncs GSourceFuncs;
typedef gboolean (*GSourceFunc)(gpointer data );
typedef void (*GChildWatchFunc)(GPid pid , gint status , gpointer data );
struct _GSource {
   gpointer callback_data ;
   GSourceCallbackFuncs *callback_funcs ;
   GSourceFuncs *source_funcs ;
   guint ref_count ;
   GMainContext *context ;
   gint priority ;
   guint flags ;
   guint source_id ;
   GSList *poll_fds ;
   GSource *prev ;
   GSource *next ;
   gpointer reserved1 ;
   gpointer reserved2 ;
};
struct _GSourceCallbackFuncs {
   void (*ref)(gpointer cb_data ) ;
   void (*unref)(gpointer cb_data ) ;
   void (*get)(gpointer cb_data , GSource *source , GSourceFunc *func , gpointer *data ) ;
};
typedef void (*GSourceDummyMarshal)(void);
struct _GSourceFuncs {
   gboolean (*prepare)(GSource *source , gint *timeout_ ) ;
   gboolean (*check)(GSource *source ) ;
   gboolean (*dispatch)(GSource *source , gboolean (*callback)(gpointer data ) , gpointer user_data ) ;
   void (*finalize)(GSource *source ) ;
   gboolean (*closure_callback)(gpointer data ) ;
   void (*closure_marshal)(void) ;
};
typedef guint32 gunichar;
typedef guint16 gunichar2;
enum __anonenum_GUnicodeType_68 {
    G_UNICODE_CONTROL = 0,
    G_UNICODE_FORMAT = 1,
    G_UNICODE_UNASSIGNED = 2,
    G_UNICODE_PRIVATE_USE = 3,
    G_UNICODE_SURROGATE = 4,
    G_UNICODE_LOWERCASE_LETTER = 5,
    G_UNICODE_MODIFIER_LETTER = 6,
    G_UNICODE_OTHER_LETTER = 7,
    G_UNICODE_TITLECASE_LETTER = 8,
    G_UNICODE_UPPERCASE_LETTER = 9,
    G_UNICODE_COMBINING_MARK = 10,
    G_UNICODE_ENCLOSING_MARK = 11,
    G_UNICODE_NON_SPACING_MARK = 12,
    G_UNICODE_DECIMAL_NUMBER = 13,
    G_UNICODE_LETTER_NUMBER = 14,
    G_UNICODE_OTHER_NUMBER = 15,
    G_UNICODE_CONNECT_PUNCTUATION = 16,
    G_UNICODE_DASH_PUNCTUATION = 17,
    G_UNICODE_CLOSE_PUNCTUATION = 18,
    G_UNICODE_FINAL_PUNCTUATION = 19,
    G_UNICODE_INITIAL_PUNCTUATION = 20,
    G_UNICODE_OTHER_PUNCTUATION = 21,
    G_UNICODE_OPEN_PUNCTUATION = 22,
    G_UNICODE_CURRENCY_SYMBOL = 23,
    G_UNICODE_MODIFIER_SYMBOL = 24,
    G_UNICODE_MATH_SYMBOL = 25,
    G_UNICODE_OTHER_SYMBOL = 26,
    G_UNICODE_LINE_SEPARATOR = 27,
    G_UNICODE_PARAGRAPH_SEPARATOR = 28,
    G_UNICODE_SPACE_SEPARATOR = 29
} ;
typedef enum __anonenum_GUnicodeType_68 GUnicodeType;
enum __anonenum_GUnicodeBreakType_69 {
    G_UNICODE_BREAK_MANDATORY = 0,
    G_UNICODE_BREAK_CARRIAGE_RETURN = 1,
    G_UNICODE_BREAK_LINE_FEED = 2,
    G_UNICODE_BREAK_COMBINING_MARK = 3,
    G_UNICODE_BREAK_SURROGATE = 4,
    G_UNICODE_BREAK_ZERO_WIDTH_SPACE = 5,
    G_UNICODE_BREAK_INSEPARABLE = 6,
    G_UNICODE_BREAK_NON_BREAKING_GLUE = 7,
    G_UNICODE_BREAK_CONTINGENT = 8,
    G_UNICODE_BREAK_SPACE = 9,
    G_UNICODE_BREAK_AFTER = 10,
    G_UNICODE_BREAK_BEFORE = 11,
    G_UNICODE_BREAK_BEFORE_AND_AFTER = 12,
    G_UNICODE_BREAK_HYPHEN = 13,
    G_UNICODE_BREAK_NON_STARTER = 14,
    G_UNICODE_BREAK_OPEN_PUNCTUATION = 15,
    G_UNICODE_BREAK_CLOSE_PUNCTUATION = 16,
    G_UNICODE_BREAK_QUOTATION = 17,
    G_UNICODE_BREAK_EXCLAMATION = 18,
    G_UNICODE_BREAK_IDEOGRAPHIC = 19,
    G_UNICODE_BREAK_NUMERIC = 20,
    G_UNICODE_BREAK_INFIX_SEPARATOR = 21,
    G_UNICODE_BREAK_SYMBOL = 22,
    G_UNICODE_BREAK_ALPHABETIC = 23,
    G_UNICODE_BREAK_PREFIX = 24,
    G_UNICODE_BREAK_POSTFIX = 25,
    G_UNICODE_BREAK_COMPLEX_CONTEXT = 26,
    G_UNICODE_BREAK_AMBIGUOUS = 27,
    G_UNICODE_BREAK_UNKNOWN = 28,
    G_UNICODE_BREAK_NEXT_LINE = 29,
    G_UNICODE_BREAK_WORD_JOINER = 30,
    G_UNICODE_BREAK_HANGUL_L_JAMO = 31,
    G_UNICODE_BREAK_HANGUL_V_JAMO = 32,
    G_UNICODE_BREAK_HANGUL_T_JAMO = 33,
    G_UNICODE_BREAK_HANGUL_LV_SYLLABLE = 34,
    G_UNICODE_BREAK_HANGUL_LVT_SYLLABLE = 35
} ;
typedef enum __anonenum_GUnicodeBreakType_69 GUnicodeBreakType;
enum __anonenum_GUnicodeScript_70 {
    G_UNICODE_SCRIPT_INVALID_CODE = -1,
    G_UNICODE_SCRIPT_COMMON = 0,
    G_UNICODE_SCRIPT_INHERITED = 1,
    G_UNICODE_SCRIPT_ARABIC = 2,
    G_UNICODE_SCRIPT_ARMENIAN = 3,
    G_UNICODE_SCRIPT_BENGALI = 4,
    G_UNICODE_SCRIPT_BOPOMOFO = 5,
    G_UNICODE_SCRIPT_CHEROKEE = 6,
    G_UNICODE_SCRIPT_COPTIC = 7,
    G_UNICODE_SCRIPT_CYRILLIC = 8,
    G_UNICODE_SCRIPT_DESERET = 9,
    G_UNICODE_SCRIPT_DEVANAGARI = 10,
    G_UNICODE_SCRIPT_ETHIOPIC = 11,
    G_UNICODE_SCRIPT_GEORGIAN = 12,
    G_UNICODE_SCRIPT_GOTHIC = 13,
    G_UNICODE_SCRIPT_GREEK = 14,
    G_UNICODE_SCRIPT_GUJARATI = 15,
    G_UNICODE_SCRIPT_GURMUKHI = 16,
    G_UNICODE_SCRIPT_HAN = 17,
    G_UNICODE_SCRIPT_HANGUL = 18,
    G_UNICODE_SCRIPT_HEBREW = 19,
    G_UNICODE_SCRIPT_HIRAGANA = 20,
    G_UNICODE_SCRIPT_KANNADA = 21,
    G_UNICODE_SCRIPT_KATAKANA = 22,
    G_UNICODE_SCRIPT_KHMER = 23,
    G_UNICODE_SCRIPT_LAO = 24,
    G_UNICODE_SCRIPT_LATIN = 25,
    G_UNICODE_SCRIPT_MALAYALAM = 26,
    G_UNICODE_SCRIPT_MONGOLIAN = 27,
    G_UNICODE_SCRIPT_MYANMAR = 28,
    G_UNICODE_SCRIPT_OGHAM = 29,
    G_UNICODE_SCRIPT_OLD_ITALIC = 30,
    G_UNICODE_SCRIPT_ORIYA = 31,
    G_UNICODE_SCRIPT_RUNIC = 32,
    G_UNICODE_SCRIPT_SINHALA = 33,
    G_UNICODE_SCRIPT_SYRIAC = 34,
    G_UNICODE_SCRIPT_TAMIL = 35,
    G_UNICODE_SCRIPT_TELUGU = 36,
    G_UNICODE_SCRIPT_THAANA = 37,
    G_UNICODE_SCRIPT_THAI = 38,
    G_UNICODE_SCRIPT_TIBETAN = 39,
    G_UNICODE_SCRIPT_CANADIAN_ABORIGINAL = 40,
    G_UNICODE_SCRIPT_YI = 41,
    G_UNICODE_SCRIPT_TAGALOG = 42,
    G_UNICODE_SCRIPT_HANUNOO = 43,
    G_UNICODE_SCRIPT_BUHID = 44,
    G_UNICODE_SCRIPT_TAGBANWA = 45,
    G_UNICODE_SCRIPT_BRAILLE = 46,
    G_UNICODE_SCRIPT_CYPRIOT = 47,
    G_UNICODE_SCRIPT_LIMBU = 48,
    G_UNICODE_SCRIPT_OSMANYA = 49,
    G_UNICODE_SCRIPT_SHAVIAN = 50,
    G_UNICODE_SCRIPT_LINEAR_B = 51,
    G_UNICODE_SCRIPT_TAI_LE = 52,
    G_UNICODE_SCRIPT_UGARITIC = 53,
    G_UNICODE_SCRIPT_NEW_TAI_LUE = 54,
    G_UNICODE_SCRIPT_BUGINESE = 55,
    G_UNICODE_SCRIPT_GLAGOLITIC = 56,
    G_UNICODE_SCRIPT_TIFINAGH = 57,
    G_UNICODE_SCRIPT_SYLOTI_NAGRI = 58,
    G_UNICODE_SCRIPT_OLD_PERSIAN = 59,
    G_UNICODE_SCRIPT_KHAROSHTHI = 60,
    G_UNICODE_SCRIPT_UNKNOWN = 61,
    G_UNICODE_SCRIPT_BALINESE = 62,
    G_UNICODE_SCRIPT_CUNEIFORM = 63,
    G_UNICODE_SCRIPT_PHOENICIAN = 64,
    G_UNICODE_SCRIPT_PHAGS_PA = 65,
    G_UNICODE_SCRIPT_NKO = 66,
    G_UNICODE_SCRIPT_KAYAH_LI = 67,
    G_UNICODE_SCRIPT_LEPCHA = 68,
    G_UNICODE_SCRIPT_REJANG = 69,
    G_UNICODE_SCRIPT_SUNDANESE = 70,
    G_UNICODE_SCRIPT_SAURASHTRA = 71,
    G_UNICODE_SCRIPT_CHAM = 72,
    G_UNICODE_SCRIPT_OL_CHIKI = 73,
    G_UNICODE_SCRIPT_VAI = 74,
    G_UNICODE_SCRIPT_CARIAN = 75,
    G_UNICODE_SCRIPT_LYCIAN = 76,
    G_UNICODE_SCRIPT_LYDIAN = 77
} ;
typedef enum __anonenum_GUnicodeScript_70 GUnicodeScript;
enum __anonenum_GNormalizeMode_71 {
    G_NORMALIZE_DEFAULT = 0,
    G_NORMALIZE_NFD = 0,
    G_NORMALIZE_DEFAULT_COMPOSE = 1,
    G_NORMALIZE_NFC = 1,
    G_NORMALIZE_ALL = 2,
    G_NORMALIZE_NFKD = 2,
    G_NORMALIZE_ALL_COMPOSE = 3,
    G_NORMALIZE_NFKC = 3
} ;
typedef enum __anonenum_GNormalizeMode_71 GNormalizeMode;
struct _GString;
typedef struct _GString GString;
struct _GStringChunk;
typedef struct _GStringChunk GStringChunk;
struct _GString {
   gchar *str ;
   gsize len ;
   gsize allocated_len ;
};
struct _GIOChannel;
typedef struct _GIOChannel GIOChannel;
struct _GIOFuncs;
typedef struct _GIOFuncs GIOFuncs;
enum __anonenum_GIOError_72 {
    G_IO_ERROR_NONE = 0,
    G_IO_ERROR_AGAIN = 1,
    G_IO_ERROR_INVAL = 2,
    G_IO_ERROR_UNKNOWN = 3
} ;
typedef enum __anonenum_GIOError_72 GIOError;
enum __anonenum_GIOChannelError_73 {
    G_IO_CHANNEL_ERROR_FBIG = 0,
    G_IO_CHANNEL_ERROR_INVAL = 1,
    G_IO_CHANNEL_ERROR_IO = 2,
    G_IO_CHANNEL_ERROR_ISDIR = 3,
    G_IO_CHANNEL_ERROR_NOSPC = 4,
    G_IO_CHANNEL_ERROR_NXIO = 5,
    G_IO_CHANNEL_ERROR_OVERFLOW = 6,
    G_IO_CHANNEL_ERROR_PIPE = 7,
    G_IO_CHANNEL_ERROR_FAILED = 8
} ;
typedef enum __anonenum_GIOChannelError_73 GIOChannelError;
enum __anonenum_GIOStatus_74 {
    G_IO_STATUS_ERROR = 0,
    G_IO_STATUS_NORMAL = 1,
    G_IO_STATUS_EOF = 2,
    G_IO_STATUS_AGAIN = 3
} ;
typedef enum __anonenum_GIOStatus_74 GIOStatus;
enum __anonenum_GSeekType_75 {
    G_SEEK_CUR = 0,
    G_SEEK_SET = 1,
    G_SEEK_END = 2
} ;
typedef enum __anonenum_GSeekType_75 GSeekType;
enum __anonenum_GIOCondition_76 {
    G_IO_IN = 1,
    G_IO_OUT = 4,
    G_IO_PRI = 2,
    G_IO_ERR = 8,
    G_IO_HUP = 16,
    G_IO_NVAL = 32
} ;
typedef enum __anonenum_GIOCondition_76 GIOCondition;
enum __anonenum_GIOFlags_77 {
    G_IO_FLAG_APPEND = 1,
    G_IO_FLAG_NONBLOCK = 2,
    G_IO_FLAG_IS_READABLE = 4,
    G_IO_FLAG_IS_WRITEABLE = 8,
    G_IO_FLAG_IS_SEEKABLE = 16,
    G_IO_FLAG_MASK = 31,
    G_IO_FLAG_GET_MASK = 31,
    G_IO_FLAG_SET_MASK = 3
} ;
typedef enum __anonenum_GIOFlags_77 GIOFlags;
struct _GIOChannel {
   gint ref_count ;
   GIOFuncs *funcs ;
   gchar *encoding ;
   GIConv read_cd ;
   GIConv write_cd ;
   gchar *line_term ;
   guint line_term_len ;
   gsize buf_size ;
   GString *read_buf ;
   GString *encoded_read_buf ;
   GString *write_buf ;
   gchar partial_write_buf[6] ;
   guint use_buffer : 1 ;
   guint do_encode : 1 ;
   guint close_on_unref : 1 ;
   guint is_readable : 1 ;
   guint is_writeable : 1 ;
   guint is_seekable : 1 ;
   gpointer reserved1 ;
   gpointer reserved2 ;
};
typedef gboolean (*GIOFunc)(GIOChannel *source , GIOCondition condition , gpointer data );
struct _GIOFuncs {
   GIOStatus (*io_read)(GIOChannel *channel , gchar *buf , gsize count , gsize *bytes_read , GError **err ) ;
   GIOStatus (*io_write)(GIOChannel *channel , gchar const   *buf , gsize count , gsize *bytes_written , GError **err ) ;
   GIOStatus (*io_seek)(GIOChannel *channel , gint64 offset , GSeekType type , GError **err ) ;
   GIOStatus (*io_close)(GIOChannel *channel , GError **err ) ;
   GSource *(*io_create_watch)(GIOChannel *channel , GIOCondition condition ) ;
   void (*io_free)(GIOChannel *channel ) ;
   GIOStatus (*io_set_flags)(GIOChannel *channel , GIOFlags flags , GError **err ) ;
   GIOFlags (*io_get_flags)(GIOChannel *channel ) ;
};
enum __anonenum_GKeyFileError_78 {
    G_KEY_FILE_ERROR_UNKNOWN_ENCODING = 0,
    G_KEY_FILE_ERROR_PARSE = 1,
    G_KEY_FILE_ERROR_NOT_FOUND = 2,
    G_KEY_FILE_ERROR_KEY_NOT_FOUND = 3,
    G_KEY_FILE_ERROR_GROUP_NOT_FOUND = 4,
    G_KEY_FILE_ERROR_INVALID_VALUE = 5
} ;
typedef enum __anonenum_GKeyFileError_78 GKeyFileError;
struct _GKeyFile;
typedef struct _GKeyFile GKeyFile;
enum __anonenum_GKeyFileFlags_79 {
    G_KEY_FILE_NONE = 0,
    G_KEY_FILE_KEEP_COMMENTS = 1,
    G_KEY_FILE_KEEP_TRANSLATIONS = 2
} ;
typedef enum __anonenum_GKeyFileFlags_79 GKeyFileFlags;
struct _GMappedFile;
typedef struct _GMappedFile GMappedFile;
enum __anonenum_GMarkupError_80 {
    G_MARKUP_ERROR_BAD_UTF8 = 0,
    G_MARKUP_ERROR_EMPTY = 1,
    G_MARKUP_ERROR_PARSE = 2,
    G_MARKUP_ERROR_UNKNOWN_ELEMENT = 3,
    G_MARKUP_ERROR_UNKNOWN_ATTRIBUTE = 4,
    G_MARKUP_ERROR_INVALID_CONTENT = 5,
    G_MARKUP_ERROR_MISSING_ATTRIBUTE = 6
} ;
typedef enum __anonenum_GMarkupError_80 GMarkupError;
enum __anonenum_GMarkupParseFlags_81 {
    G_MARKUP_DO_NOT_USE_THIS_UNSUPPORTED_FLAG = 1,
    G_MARKUP_TREAT_CDATA_AS_TEXT = 2,
    G_MARKUP_PREFIX_ERROR_POSITION = 4
} ;
typedef enum __anonenum_GMarkupParseFlags_81 GMarkupParseFlags;
struct _GMarkupParseContext;
typedef struct _GMarkupParseContext GMarkupParseContext;
struct _GMarkupParser;
typedef struct _GMarkupParser GMarkupParser;
struct _GMarkupParser {
   void (*start_element)(GMarkupParseContext *context , gchar const   *element_name , gchar const   **attribute_names , gchar const   **attribute_values , gpointer user_data , GError **error ) ;
   void (*end_element)(GMarkupParseContext *context , gchar const   *element_name , gpointer user_data , GError **error ) ;
   void (*text)(GMarkupParseContext *context , gchar const   *text , gsize text_len , gpointer user_data , GError **error ) ;
   void (*passthrough)(GMarkupParseContext *context , gchar const   *passthrough_text , gsize text_len , gpointer user_data , GError **error ) ;
   void (*error)(GMarkupParseContext *context , GError *error , gpointer user_data ) ;
};
enum __anonenum_GMarkupCollectType_82 {
    G_MARKUP_COLLECT_INVALID = 0,
    G_MARKUP_COLLECT_STRING = 1,
    G_MARKUP_COLLECT_STRDUP = 2,
    G_MARKUP_COLLECT_BOOLEAN = 3,
    G_MARKUP_COLLECT_TRISTATE = 4,
    G_MARKUP_COLLECT_OPTIONAL = 65536
} ;
typedef enum __anonenum_GMarkupCollectType_82 GMarkupCollectType;
enum __anonenum_GLogLevelFlags_83 {
    G_LOG_FLAG_RECURSION = 1,
    G_LOG_FLAG_FATAL = 2,
    G_LOG_LEVEL_ERROR = 4,
    G_LOG_LEVEL_CRITICAL = 8,
    G_LOG_LEVEL_WARNING = 16,
    G_LOG_LEVEL_MESSAGE = 32,
    G_LOG_LEVEL_INFO = 64,
    G_LOG_LEVEL_DEBUG = 128,
    G_LOG_LEVEL_MASK = -4
} ;
typedef enum __anonenum_GLogLevelFlags_83 GLogLevelFlags;
typedef void (*GLogFunc)(gchar const   *log_domain , GLogLevelFlags log_level , gchar const   *message , gpointer user_data );
typedef void (*GPrintFunc)(gchar const   *string );
struct _GNode;
typedef struct _GNode GNode;
enum __anonenum_GTraverseFlags_84 {
    G_TRAVERSE_LEAVES = 1,
    G_TRAVERSE_NON_LEAVES = 2,
    G_TRAVERSE_ALL = 3,
    G_TRAVERSE_MASK = 3,
    G_TRAVERSE_LEAFS = 1,
    G_TRAVERSE_NON_LEAFS = 2
} ;
typedef enum __anonenum_GTraverseFlags_84 GTraverseFlags;
enum __anonenum_GTraverseType_85 {
    G_IN_ORDER = 0,
    G_PRE_ORDER = 1,
    G_POST_ORDER = 2,
    G_LEVEL_ORDER = 3
} ;
typedef enum __anonenum_GTraverseType_85 GTraverseType;
typedef gboolean (*GNodeTraverseFunc)(GNode *node , gpointer data );
typedef void (*GNodeForeachFunc)(GNode *node , gpointer data );
typedef gpointer (*GCopyFunc)(gconstpointer src , gpointer data );
struct _GNode {
   gpointer data ;
   GNode *next ;
   GNode *prev ;
   GNode *parent ;
   GNode *children ;
};
struct _GOptionContext;
typedef struct _GOptionContext GOptionContext;
struct _GOptionGroup;
typedef struct _GOptionGroup GOptionGroup;
struct _GOptionEntry;
typedef struct _GOptionEntry GOptionEntry;
enum __anonenum_GOptionFlags_86 {
    G_OPTION_FLAG_HIDDEN = 1,
    G_OPTION_FLAG_IN_MAIN = 2,
    G_OPTION_FLAG_REVERSE = 4,
    G_OPTION_FLAG_NO_ARG = 8,
    G_OPTION_FLAG_FILENAME = 16,
    G_OPTION_FLAG_OPTIONAL_ARG = 32,
    G_OPTION_FLAG_NOALIAS = 64
} ;
typedef enum __anonenum_GOptionFlags_86 GOptionFlags;
enum __anonenum_GOptionArg_87 {
    G_OPTION_ARG_NONE = 0,
    G_OPTION_ARG_STRING = 1,
    G_OPTION_ARG_INT = 2,
    G_OPTION_ARG_CALLBACK = 3,
    G_OPTION_ARG_FILENAME = 4,
    G_OPTION_ARG_STRING_ARRAY = 5,
    G_OPTION_ARG_FILENAME_ARRAY = 6,
    G_OPTION_ARG_DOUBLE = 7,
    G_OPTION_ARG_INT64 = 8
} ;
typedef enum __anonenum_GOptionArg_87 GOptionArg;
typedef gboolean (*GOptionArgFunc)(gchar const   *option_name , gchar const   *value , gpointer data , GError **error );
typedef gboolean (*GOptionParseFunc)(GOptionContext *context , GOptionGroup *group , gpointer data , GError **error );
typedef void (*GOptionErrorFunc)(GOptionContext *context , GOptionGroup *group , gpointer data , GError **error );
enum __anonenum_GOptionError_88 {
    G_OPTION_ERROR_UNKNOWN_OPTION = 0,
    G_OPTION_ERROR_BAD_VALUE = 1,
    G_OPTION_ERROR_FAILED = 2
} ;
typedef enum __anonenum_GOptionError_88 GOptionError;
struct _GOptionEntry {
   gchar const   *long_name ;
   gchar short_name ;
   gint flags ;
   GOptionArg arg ;
   gpointer arg_data ;
   gchar const   *description ;
   gchar const   *arg_description ;
};
struct _GPatternSpec;
typedef struct _GPatternSpec GPatternSpec;
struct _GQueue;
typedef struct _GQueue GQueue;
struct _GQueue {
   GList *head ;
   GList *tail ;
   guint length ;
};
struct _GRand;
typedef struct _GRand GRand;
struct _GRelation;
typedef struct _GRelation GRelation;
struct _GTuples;
typedef struct _GTuples GTuples;
struct _GTuples {
   guint len ;
};
enum __anonenum_GRegexError_89 {
    G_REGEX_ERROR_COMPILE = 0,
    G_REGEX_ERROR_OPTIMIZE = 1,
    G_REGEX_ERROR_REPLACE = 2,
    G_REGEX_ERROR_MATCH = 3,
    G_REGEX_ERROR_INTERNAL = 4,
    G_REGEX_ERROR_STRAY_BACKSLASH = 101,
    G_REGEX_ERROR_MISSING_CONTROL_CHAR = 102,
    G_REGEX_ERROR_UNRECOGNIZED_ESCAPE = 103,
    G_REGEX_ERROR_QUANTIFIERS_OUT_OF_ORDER = 104,
    G_REGEX_ERROR_QUANTIFIER_TOO_BIG = 105,
    G_REGEX_ERROR_UNTERMINATED_CHARACTER_CLASS = 106,
    G_REGEX_ERROR_INVALID_ESCAPE_IN_CHARACTER_CLASS = 107,
    G_REGEX_ERROR_RANGE_OUT_OF_ORDER = 108,
    G_REGEX_ERROR_NOTHING_TO_REPEAT = 109,
    G_REGEX_ERROR_UNRECOGNIZED_CHARACTER = 112,
    G_REGEX_ERROR_POSIX_NAMED_CLASS_OUTSIDE_CLASS = 113,
    G_REGEX_ERROR_UNMATCHED_PARENTHESIS = 114,
    G_REGEX_ERROR_INEXISTENT_SUBPATTERN_REFERENCE = 115,
    G_REGEX_ERROR_UNTERMINATED_COMMENT = 118,
    G_REGEX_ERROR_EXPRESSION_TOO_LARGE = 120,
    G_REGEX_ERROR_MEMORY_ERROR = 121,
    G_REGEX_ERROR_VARIABLE_LENGTH_LOOKBEHIND = 125,
    G_REGEX_ERROR_MALFORMED_CONDITION = 126,
    G_REGEX_ERROR_TOO_MANY_CONDITIONAL_BRANCHES = 127,
    G_REGEX_ERROR_ASSERTION_EXPECTED = 128,
    G_REGEX_ERROR_UNKNOWN_POSIX_CLASS_NAME = 130,
    G_REGEX_ERROR_POSIX_COLLATING_ELEMENTS_NOT_SUPPORTED = 131,
    G_REGEX_ERROR_HEX_CODE_TOO_LARGE = 134,
    G_REGEX_ERROR_INVALID_CONDITION = 135,
    G_REGEX_ERROR_SINGLE_BYTE_MATCH_IN_LOOKBEHIND = 136,
    G_REGEX_ERROR_INFINITE_LOOP = 140,
    G_REGEX_ERROR_MISSING_SUBPATTERN_NAME_TERMINATOR = 142,
    G_REGEX_ERROR_DUPLICATE_SUBPATTERN_NAME = 143,
    G_REGEX_ERROR_MALFORMED_PROPERTY = 146,
    G_REGEX_ERROR_UNKNOWN_PROPERTY = 147,
    G_REGEX_ERROR_SUBPATTERN_NAME_TOO_LONG = 148,
    G_REGEX_ERROR_TOO_MANY_SUBPATTERNS = 149,
    G_REGEX_ERROR_INVALID_OCTAL_VALUE = 151,
    G_REGEX_ERROR_TOO_MANY_BRANCHES_IN_DEFINE = 154,
    G_REGEX_ERROR_DEFINE_REPETION = 155,
    G_REGEX_ERROR_INCONSISTENT_NEWLINE_OPTIONS = 156,
    G_REGEX_ERROR_MISSING_BACK_REFERENCE = 157
} ;
typedef enum __anonenum_GRegexError_89 GRegexError;
enum __anonenum_GRegexCompileFlags_90 {
    G_REGEX_CASELESS = 1,
    G_REGEX_MULTILINE = 2,
    G_REGEX_DOTALL = 4,
    G_REGEX_EXTENDED = 8,
    G_REGEX_ANCHORED = 16,
    G_REGEX_DOLLAR_ENDONLY = 32,
    G_REGEX_UNGREEDY = 512,
    G_REGEX_RAW = 2048,
    G_REGEX_NO_AUTO_CAPTURE = 4096,
    G_REGEX_OPTIMIZE = 8192,
    G_REGEX_DUPNAMES = 524288,
    G_REGEX_NEWLINE_CR = 1048576,
    G_REGEX_NEWLINE_LF = 2097152,
    G_REGEX_NEWLINE_CRLF = 3145728
} ;
typedef enum __anonenum_GRegexCompileFlags_90 GRegexCompileFlags;
enum __anonenum_GRegexMatchFlags_91 {
    G_REGEX_MATCH_ANCHORED = 16,
    G_REGEX_MATCH_NOTBOL = 128,
    G_REGEX_MATCH_NOTEOL = 256,
    G_REGEX_MATCH_NOTEMPTY = 1024,
    G_REGEX_MATCH_PARTIAL = 32768,
    G_REGEX_MATCH_NEWLINE_CR = 1048576,
    G_REGEX_MATCH_NEWLINE_LF = 2097152,
    G_REGEX_MATCH_NEWLINE_CRLF = 3145728,
    G_REGEX_MATCH_NEWLINE_ANY = 4194304
} ;
typedef enum __anonenum_GRegexMatchFlags_91 GRegexMatchFlags;
struct _GRegex;
typedef struct _GRegex GRegex;
struct _GMatchInfo;
typedef struct _GMatchInfo GMatchInfo;
typedef gboolean (*GRegexEvalCallback)(GMatchInfo const   *match_info , GString *result , gpointer user_data );
struct _GScanner;
typedef struct _GScanner GScanner;
struct _GScannerConfig;
typedef struct _GScannerConfig GScannerConfig;
union _GTokenValue;
typedef union _GTokenValue GTokenValue;
typedef void (*GScannerMsgFunc)(GScanner *scanner , gchar *message , gboolean error );
enum __anonenum_GErrorType_92 {
    G_ERR_UNKNOWN = 0,
    G_ERR_UNEXP_EOF = 1,
    G_ERR_UNEXP_EOF_IN_STRING = 2,
    G_ERR_UNEXP_EOF_IN_COMMENT = 3,
    G_ERR_NON_DIGIT_IN_CONST = 4,
    G_ERR_DIGIT_RADIX = 5,
    G_ERR_FLOAT_RADIX = 6,
    G_ERR_FLOAT_MALFORMED = 7
} ;
typedef enum __anonenum_GErrorType_92 GErrorType;
enum __anonenum_GTokenType_93 {
    G_TOKEN_EOF = 0,
    G_TOKEN_LEFT_PAREN = 40,
    G_TOKEN_RIGHT_PAREN = 41,
    G_TOKEN_LEFT_CURLY = 123,
    G_TOKEN_RIGHT_CURLY = 125,
    G_TOKEN_LEFT_BRACE = 91,
    G_TOKEN_RIGHT_BRACE = 93,
    G_TOKEN_EQUAL_SIGN = 61,
    G_TOKEN_COMMA = 44,
    G_TOKEN_NONE = 256,
    G_TOKEN_ERROR = 257,
    G_TOKEN_CHAR = 258,
    G_TOKEN_BINARY = 259,
    G_TOKEN_OCTAL = 260,
    G_TOKEN_INT = 261,
    G_TOKEN_HEX = 262,
    G_TOKEN_FLOAT = 263,
    G_TOKEN_STRING = 264,
    G_TOKEN_SYMBOL = 265,
    G_TOKEN_IDENTIFIER = 266,
    G_TOKEN_IDENTIFIER_NULL = 267,
    G_TOKEN_COMMENT_SINGLE = 268,
    G_TOKEN_COMMENT_MULTI = 269,
    G_TOKEN_LAST = 270
} ;
typedef enum __anonenum_GTokenType_93 GTokenType;
union _GTokenValue {
   gpointer v_symbol ;
   gchar *v_identifier ;
   gulong v_binary ;
   gulong v_octal ;
   gulong v_int ;
   guint64 v_int64 ;
   gdouble v_float ;
   gulong v_hex ;
   gchar *v_string ;
   gchar *v_comment ;
   guchar v_char ;
   guint v_error ;
};
struct _GScannerConfig {
   gchar *cset_skip_characters ;
   gchar *cset_identifier_first ;
   gchar *cset_identifier_nth ;
   gchar *cpair_comment_single ;
   guint case_sensitive : 1 ;
   guint skip_comment_multi : 1 ;
   guint skip_comment_single : 1 ;
   guint scan_comment_multi : 1 ;
   guint scan_identifier : 1 ;
   guint scan_identifier_1char : 1 ;
   guint scan_identifier_NULL : 1 ;
   guint scan_symbols : 1 ;
   guint scan_binary : 1 ;
   guint scan_octal : 1 ;
   guint scan_float : 1 ;
   guint scan_hex : 1 ;
   guint scan_hex_dollar : 1 ;
   guint scan_string_sq : 1 ;
   guint scan_string_dq : 1 ;
   guint numbers_2_int : 1 ;
   guint int_2_float : 1 ;
   guint identifier_2_string : 1 ;
   guint char_2_token : 1 ;
   guint symbol_2_token : 1 ;
   guint scope_0_fallback : 1 ;
   guint store_int64 : 1 ;
   guint padding_dummy ;
};
struct _GScanner {
   gpointer user_data ;
   guint max_parse_errors ;
   guint parse_errors ;
   gchar const   *input_name ;
   GData *qdata ;
   GScannerConfig *config ;
   GTokenType token ;
   GTokenValue value ;
   guint line ;
   guint position ;
   GTokenType next_token ;
   GTokenValue next_value ;
   guint next_line ;
   guint next_position ;
   GHashTable *symbol_table ;
   gint input_fd ;
   gchar const   *text ;
   gchar const   *text_end ;
   gchar *buffer ;
   guint scope_id ;
   void (*msg_handler)(GScanner *scanner , gchar *message , gboolean error ) ;
};
struct _GSequence;
typedef struct _GSequence GSequence;
struct _GSequenceNode;
typedef struct _GSequenceNode GSequenceIter;
typedef gint (*GSequenceIterCompareFunc)(GSequenceIter *a , GSequenceIter *b , gpointer data );
enum __anonenum_GShellError_94 {
    G_SHELL_ERROR_BAD_QUOTING = 0,
    G_SHELL_ERROR_EMPTY_STRING = 1,
    G_SHELL_ERROR_FAILED = 2
} ;
typedef enum __anonenum_GShellError_94 GShellError;
enum __anonenum_GSpawnError_95 {
    G_SPAWN_ERROR_FORK = 0,
    G_SPAWN_ERROR_READ = 1,
    G_SPAWN_ERROR_CHDIR = 2,
    G_SPAWN_ERROR_ACCES = 3,
    G_SPAWN_ERROR_PERM = 4,
    G_SPAWN_ERROR_2BIG = 5,
    G_SPAWN_ERROR_NOEXEC = 6,
    G_SPAWN_ERROR_NAMETOOLONG = 7,
    G_SPAWN_ERROR_NOENT = 8,
    G_SPAWN_ERROR_NOMEM = 9,
    G_SPAWN_ERROR_NOTDIR = 10,
    G_SPAWN_ERROR_LOOP = 11,
    G_SPAWN_ERROR_TXTBUSY = 12,
    G_SPAWN_ERROR_IO = 13,
    G_SPAWN_ERROR_NFILE = 14,
    G_SPAWN_ERROR_MFILE = 15,
    G_SPAWN_ERROR_INVAL = 16,
    G_SPAWN_ERROR_ISDIR = 17,
    G_SPAWN_ERROR_LIBBAD = 18,
    G_SPAWN_ERROR_FAILED = 19
} ;
typedef enum __anonenum_GSpawnError_95 GSpawnError;
typedef void (*GSpawnChildSetupFunc)(gpointer user_data );
enum __anonenum_GSpawnFlags_96 {
    G_SPAWN_LEAVE_DESCRIPTORS_OPEN = 1,
    G_SPAWN_DO_NOT_REAP_CHILD = 2,
    G_SPAWN_SEARCH_PATH = 4,
    G_SPAWN_STDOUT_TO_DEV_NULL = 8,
    G_SPAWN_STDERR_TO_DEV_NULL = 16,
    G_SPAWN_CHILD_INHERITS_STDIN = 32,
    G_SPAWN_FILE_AND_ARGV_ZERO = 64
} ;
typedef enum __anonenum_GSpawnFlags_96 GSpawnFlags;
enum __anonenum_GAsciiType_97 {
    G_ASCII_ALNUM = 1,
    G_ASCII_ALPHA = 2,
    G_ASCII_CNTRL = 4,
    G_ASCII_DIGIT = 8,
    G_ASCII_GRAPH = 16,
    G_ASCII_LOWER = 32,
    G_ASCII_PRINT = 64,
    G_ASCII_PUNCT = 128,
    G_ASCII_SPACE = 256,
    G_ASCII_UPPER = 512,
    G_ASCII_XDIGIT = 1024
} ;
typedef enum __anonenum_GAsciiType_97 GAsciiType;
struct GTestCase;
typedef struct GTestCase GTestCase;
struct GTestSuite;
typedef struct GTestSuite GTestSuite;
enum __anonenum_GTestTrapFlags_98 {
    G_TEST_TRAP_SILENCE_STDOUT = 128,
    G_TEST_TRAP_SILENCE_STDERR = 256,
    G_TEST_TRAP_INHERIT_STDIN = 512
} ;
typedef enum __anonenum_GTestTrapFlags_98 GTestTrapFlags;
struct __anonstruct_GTestConfig_99 {
   gboolean test_initialized ;
   gboolean test_quick ;
   gboolean test_perf ;
   gboolean test_verbose ;
   gboolean test_quiet ;
};
typedef struct __anonstruct_GTestConfig_99 GTestConfig;
enum __anonenum_GTestLogType_100 {
    G_TEST_LOG_NONE = 0,
    G_TEST_LOG_ERROR = 1,
    G_TEST_LOG_START_BINARY = 2,
    G_TEST_LOG_LIST_CASE = 3,
    G_TEST_LOG_SKIP_CASE = 4,
    G_TEST_LOG_START_CASE = 5,
    G_TEST_LOG_STOP_CASE = 6,
    G_TEST_LOG_MIN_RESULT = 7,
    G_TEST_LOG_MAX_RESULT = 8,
    G_TEST_LOG_MESSAGE = 9
} ;
typedef enum __anonenum_GTestLogType_100 GTestLogType;
struct __anonstruct_GTestLogMsg_101 {
   GTestLogType log_type ;
   guint n_strings ;
   gchar **strings ;
   guint n_nums ;
   long double *nums ;
};
typedef struct __anonstruct_GTestLogMsg_101 GTestLogMsg;
struct __anonstruct_GTestLogBuffer_102 {
   GString *data ;
   GSList *msgs ;
};
typedef struct __anonstruct_GTestLogBuffer_102 GTestLogBuffer;
typedef gboolean (*GTestLogFatalFunc)(gchar const   *log_domain , GLogLevelFlags log_level , gchar const   *message , gpointer user_data );
struct _GThreadPool;
typedef struct _GThreadPool GThreadPool;
struct _GThreadPool {
   void (*func)(gpointer data , gpointer user_data ) ;
   gpointer user_data ;
   gboolean exclusive ;
};
struct _GTimer;
typedef struct _GTimer GTimer;
struct _GTree;
typedef struct _GTree GTree;
typedef gboolean (*GTraverseFunc)(gpointer key , gpointer value , gpointer data );
struct _GVariantType;
typedef struct _GVariantType GVariantType;
struct _GVariant;
typedef struct _GVariant GVariant;
enum __anonenum_GVariantClass_103 {
    G_VARIANT_CLASS_BOOLEAN = 98,
    G_VARIANT_CLASS_BYTE = 121,
    G_VARIANT_CLASS_INT16 = 110,
    G_VARIANT_CLASS_UINT16 = 113,
    G_VARIANT_CLASS_INT32 = 105,
    G_VARIANT_CLASS_UINT32 = 117,
    G_VARIANT_CLASS_INT64 = 120,
    G_VARIANT_CLASS_UINT64 = 116,
    G_VARIANT_CLASS_HANDLE = 104,
    G_VARIANT_CLASS_DOUBLE = 100,
    G_VARIANT_CLASS_STRING = 115,
    G_VARIANT_CLASS_OBJECT_PATH = 111,
    G_VARIANT_CLASS_SIGNATURE = 103,
    G_VARIANT_CLASS_VARIANT = 118,
    G_VARIANT_CLASS_MAYBE = 109,
    G_VARIANT_CLASS_ARRAY = 97,
    G_VARIANT_CLASS_TUPLE = 40,
    G_VARIANT_CLASS_DICT_ENTRY = 123
} ;
typedef enum __anonenum_GVariantClass_103 GVariantClass;
struct _GVariantIter;
typedef struct _GVariantIter GVariantIter;
struct _GVariantIter {
   gsize x[16] ;
};
struct _GVariantBuilder;
typedef struct _GVariantBuilder GVariantBuilder;
struct _GVariantBuilder {
   gsize x[16] ;
};
struct iovec {
   void *iov_base ;
   size_t iov_len ;
};
enum __anonenum_handler_t_104 {
    HANDLER_UNSET = 0,
    HANDLER_GO_ON = 1,
    HANDLER_FINISHED = 2,
    HANDLER_COMEBACK = 3,
    HANDLER_WAIT_FOR_EVENT = 4,
    HANDLER_ERROR = 5,
    HANDLER_WAIT_FOR_FD = 6
} ;
typedef enum __anonenum_handler_t_104 handler_t;
struct __anonstruct_buffer_105 {
   char *ptr ;
   size_t used ;
   size_t size ;
};
typedef struct __anonstruct_buffer_105 buffer;
typedef void (*buffer_ptr_free_t)(void *p );
struct __anonstruct_buffer_ptr_106 {
   void **ptr ;
   size_t size ;
   size_t used ;
   void (*free)(void *p ) ;
};
typedef struct __anonstruct_buffer_ptr_106 buffer_ptr;
struct __anonstruct_buffer_array_107 {
   buffer **ptr ;
   size_t used ;
   size_t size ;
};
typedef struct __anonstruct_buffer_array_107 buffer_array;
struct __anonstruct_read_buffer_108 {
   char *ptr ;
   size_t offset ;
   size_t used ;
   size_t size ;
};
typedef struct __anonstruct_read_buffer_108 read_buffer;
enum __anonenum_buffer_encoding_t_109 {
    ENCODING_UNSET = 0,
    ENCODING_REL_URI = 1,
    ENCODING_REL_URI_PART = 2,
    ENCODING_HTML = 3,
    ENCODING_MINIMAL_XML = 4,
    ENCODING_HEX = 5
} ;
typedef enum __anonenum_buffer_encoding_t_109 buffer_encoding_t;
struct __anonstruct_buffer_pool_110 {
   buffer **ptr ;
   size_t used ;
   size_t size ;
};
typedef struct __anonstruct_buffer_pool_110 buffer_pool;
struct real_pcre;
struct real_pcre;
typedef struct real_pcre pcre;
struct pcre_extra {
   unsigned long flags ;
   void *study_data ;
   unsigned long match_limit ;
   void *callout_data ;
   unsigned char const   *tables ;
   unsigned long match_limit_recursion ;
};
typedef struct pcre_extra pcre_extra;
struct pcre_callout_block {
   int version ;
   int callout_number ;
   int *offset_vector ;
   char const   *subject ;
   int subject_length ;
   int start_match ;
   int current_position ;
   int capture_top ;
   int capture_last ;
   void *callout_data ;
   int pattern_position ;
   int next_item_length ;
};
typedef struct pcre_callout_block pcre_callout_block;
enum __anonenum_data_type_t_111 {
    TYPE_UNSET = 0,
    TYPE_STRING = 1,
    TYPE_COUNT = 2,
    TYPE_ARRAY = 3,
    TYPE_INTEGER = 4,
    TYPE_FASTCGI = 5,
    TYPE_CONFIG = 6
} ;
typedef enum __anonenum_data_type_t_111 data_type_t;
struct data_unset {
   data_type_t type ;
   buffer *key ;
   int is_index_key ;
   struct data_unset *(*copy)(struct data_unset  const  *src ) ;
   void (*free)(struct data_unset *p ) ;
   void (*reset)(struct data_unset *p ) ;
   int (*insert_dup)(struct data_unset *dst , struct data_unset *src ) ;
   void (*print)(struct data_unset  const  *p , int depth ) ;
};
typedef struct data_unset data_unset;
struct __anonstruct_array_112 {
   data_unset **data ;
   size_t *sorted ;
   size_t used ;
   size_t size ;
   size_t unique_ndx ;
   size_t next_power_of_2 ;
   int is_weakref ;
};
typedef struct __anonstruct_array_112 array;
struct __anonstruct_data_count_113 {
   data_type_t type ;
   buffer *key ;
   int is_index_key ;
   struct data_unset *(*copy)(struct data_unset  const  *src ) ;
   void (*free)(struct data_unset *p ) ;
   void (*reset)(struct data_unset *p ) ;
   int (*insert_dup)(struct data_unset *dst , struct data_unset *src ) ;
   void (*print)(struct data_unset  const  *p , int depth ) ;
   int count ;
};
typedef struct __anonstruct_data_count_113 data_count;
struct __anonstruct_data_string_114 {
   data_type_t type ;
   buffer *key ;
   int is_index_key ;
   struct data_unset *(*copy)(struct data_unset  const  *src ) ;
   void (*free)(struct data_unset *p ) ;
   void (*reset)(struct data_unset *p ) ;
   int (*insert_dup)(struct data_unset *dst , struct data_unset *src ) ;
   void (*print)(struct data_unset  const  *p , int depth ) ;
   buffer *value ;
};
typedef struct __anonstruct_data_string_114 data_string;
struct __anonstruct_data_array_115 {
   data_type_t type ;
   buffer *key ;
   int is_index_key ;
   struct data_unset *(*copy)(struct data_unset  const  *src ) ;
   void (*free)(struct data_unset *p ) ;
   void (*reset)(struct data_unset *p ) ;
   int (*insert_dup)(struct data_unset *dst , struct data_unset *src ) ;
   void (*print)(struct data_unset  const  *p , int depth ) ;
   array *value ;
};
typedef struct __anonstruct_data_array_115 data_array;
enum __anonenum_config_cond_t_116 {
    CONFIG_COND_UNSET = 0,
    CONFIG_COND_EQ = 1,
    CONFIG_COND_MATCH = 2,
    CONFIG_COND_NE = 3,
    CONFIG_COND_NOMATCH = 4
} ;
typedef enum __anonenum_config_cond_t_116 config_cond_t;
enum __anonenum_comp_key_t_117 {
    COMP_UNSET = 0,
    COMP_SERVER_SOCKET = 1,
    COMP_HTTP_URL = 2,
    COMP_HTTP_HOST = 3,
    COMP_HTTP_REFERER = 4,
    COMP_HTTP_USER_AGENT = 5,
    COMP_HTTP_COOKIE = 6,
    COMP_HTTP_SCHEME = 7,
    COMP_HTTP_REMOTE_IP = 8,
    COMP_HTTP_QUERY_STRING = 9,
    COMP_HTTP_REQUEST_METHOD = 10,
    COMP_PHYSICAL_PATH = 11,
    COMP_PHYSICAL_PATH_EXISTS = 12,
    COMP_LAST_ELEMENT = 13
} ;
typedef enum __anonenum_comp_key_t_117 comp_key_t;
struct _data_config;
typedef struct _data_config data_config;
struct _data_config {
   data_type_t type ;
   buffer *key ;
   int is_index_key ;
   struct data_unset *(*copy)(struct data_unset  const  *src ) ;
   void (*free)(struct data_unset *p ) ;
   void (*reset)(struct data_unset *p ) ;
   int (*insert_dup)(struct data_unset *dst , struct data_unset *src ) ;
   void (*print)(struct data_unset  const  *p , int depth ) ;
   array *value ;
   buffer *comp_key ;
   comp_key_t comp ;
   config_cond_t cond ;
   buffer *op ;
   int context_ndx ;
   array *childs ;
   data_config *parent ;
   data_config *prev ;
   data_config *next ;
   buffer *string ;
   pcre *regex ;
   pcre_extra *regex_study ;
};
struct __anonstruct_data_integer_118 {
   data_type_t type ;
   buffer *key ;
   int is_index_key ;
   struct data_unset *(*copy)(struct data_unset  const  *src ) ;
   void (*free)(struct data_unset *p ) ;
   void (*reset)(struct data_unset *p ) ;
   int (*insert_dup)(struct data_unset *dst , struct data_unset *src ) ;
   void (*print)(struct data_unset  const  *p , int depth ) ;
   int value ;
};
typedef struct __anonstruct_data_integer_118 data_integer;
enum __anonenum_type_119 {
    UNUSED_CHUNK = 0,
    MEM_CHUNK = 1,
    FILE_CHUNK = 2
} ;
struct __anonstruct_mmap_121 {
   char *start ;
   size_t length ;
   off_t offset ;
};
struct __anonstruct_copy_122 {
   int fd ;
   off_t length ;
   off_t offset ;
};
struct __anonstruct_file_120 {
   buffer *name ;
   off_t start ;
   off_t length ;
   int fd ;
   struct __anonstruct_mmap_121 mmap ;
   int is_temp ;
   struct __anonstruct_copy_122 copy ;
};
struct __anonstruct_async_123 {
   off_t written ;
   int ret_val ;
};
struct chunk {
   enum __anonenum_type_119 type ;
   buffer *mem ;
   struct __anonstruct_file_120 file ;
   off_t offset ;
   struct __anonstruct_async_123 async ;
   struct chunk *next ;
};
typedef struct chunk chunk;
struct __anonstruct_chunkqueue_124 {
   chunk *first ;
   chunk *last ;
   array *tempdirs ;
   int is_closed ;
   off_t bytes_in ;
   off_t bytes_out ;
};
typedef struct __anonstruct_chunkqueue_124 chunkqueue;
enum __anonenum_parse_status_t_125 {
    PARSE_UNSET = 0,
    PARSE_SUCCESS = 1,
    PARSE_ERROR = 2,
    PARSE_NEED_MORE = 3
} ;
typedef enum __anonenum_parse_status_t_125 parse_status_t;
struct __anonstruct_http_resp_126 {
   int protocol ;
   int status ;
   buffer *reason ;
   array *headers ;
};
typedef struct __anonstruct_http_resp_126 http_resp;
struct __anonstruct_http_resp_ctx_t_127 {
   int ok ;
   buffer *errmsg ;
   http_resp *resp ;
   buffer_pool *unused_buffers ;
};
typedef struct __anonstruct_http_resp_ctx_t_127 http_resp_ctx_t;
struct __anonstruct_http_resp_tokenizer_t_128 {
   chunkqueue *cq ;
   chunk *c ;
   size_t offset ;
   chunk *lookup_c ;
   size_t lookup_offset ;
   int is_key ;
   int is_statusline ;
};
typedef struct __anonstruct_http_resp_tokenizer_t_128 http_resp_tokenizer_t;
extern  __attribute__((__nothrow__)) void *memcpy(void * __restrict  __dest , void const   * __restrict  __src , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memmove(void *__dest , void const   *__src , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memccpy(void * __restrict  __dest , void const   * __restrict  __src , int __c , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memset(void *__s , int __c , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int memcmp(void const   *__s1 , void const   *__s2 , size_t __n )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memchr(void const   *__s , int __c , size_t __n )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strcpy(char * __restrict  __dest , char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncpy(char * __restrict  __dest , char const   * __restrict  __src , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strcat(char * __restrict  __dest , char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncat(char * __restrict  __dest , char const   * __restrict  __src , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcmp(char const   *__s1 , char const   *__s2 )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncmp(char const   *__s1 , char const   *__s2 , size_t __n )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcoll(char const   *__s1 , char const   *__s2 )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm(char * __restrict  __dest , char const   * __restrict  __src , size_t __n )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int strcoll_l(char const   *__s1 , char const   *__s2 , __locale_t __l )  __attribute__((__pure__, __nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm_l(char *__dest , char const   *__src , size_t __n , __locale_t __l )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) char *strdup(char const   *__s )  __attribute__((__nonnull__(1), __malloc__)) ;
extern  __attribute__((__nothrow__)) char *strndup(char const   *__string , size_t __n )  __attribute__((__nonnull__(1), __malloc__)) ;
extern  __attribute__((__nothrow__)) char *strchr(char const   *__s , int __c )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strrchr(char const   *__s , int __c )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strcspn(char const   *__s , char const   *__reject )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strspn(char const   *__s , char const   *__accept )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strpbrk(char const   *__s , char const   *__accept )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strstr(char const   *__haystack , char const   *__needle )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strtok(char * __restrict  __s , char const   * __restrict  __delim )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *__strtok_r(char * __restrict  __s , char const   * __restrict  __delim , char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) char *strtok_r(char * __restrict  __s , char const   * __restrict  __delim , char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) size_t strlen(char const   *__s )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strnlen(char const   *__string , size_t __maxlen )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strerror(int __errnum ) ;
extern  __attribute__((__nothrow__)) int strerror_r(int __errnum , char *__buf , size_t __buflen )  __asm__("__xpg_strerror_r") __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *strerror_l(int __errnum , __locale_t __l ) ;
extern  __attribute__((__nothrow__)) void __bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void bcopy(void const   *__src , void *__dest , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int bcmp(void const   *__s1 , void const   *__s2 , size_t __n )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *index(char const   *__s , int __c )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *rindex(char const   *__s , int __c )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int ffs(int __i )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int strcasecmp(char const   *__s1 , char const   *__s2 )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncasecmp(char const   *__s1 , char const   *__s2 , size_t __n )  __attribute__((__pure__, __nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsep(char ** __restrict  __stringp , char const   * __restrict  __delim )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsignal(int __sig ) ;
extern  __attribute__((__nothrow__)) char *__stpcpy(char * __restrict  __dest , char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpcpy(char * __restrict  __dest , char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *__stpncpy(char * __restrict  __dest , char const   * __restrict  __src , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpncpy(char * __restrict  __dest , char const   * __restrict  __src , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern void *__rawmemchr(void const   *__s , int __c ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c1(char const   *__s , int __reject ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c1(char const   *__s , int __reject ) 
{ register size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if ((int const   )*(__s + __result) != (int const   )__reject) {

      } else {
        break;
      }
    } else {
      break;
    }
    __result ++;
  }
  return ((unsigned int __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c2(char const   *__s , int __reject1 , int __reject2 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c2(char const   *__s , int __reject1 , int __reject2 ) 
{ register size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        if ((int const   )*(__s + __result) != (int const   )__reject2) {

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __result ++;
  }
  return ((unsigned int __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c3(char const   *__s , int __reject1 , int __reject2 , int __reject3 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strcspn_c3(char const   *__s , int __reject1 , int __reject2 , int __reject3 ) 
{ register size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) != 0) {
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          if ((int const   )*(__s + __result) != (int const   )__reject3) {

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __result ++;
  }
  return ((unsigned int __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c1(char const   *__s , int __accept ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c1(char const   *__s , int __accept ) 
{ register size_t __result ;

  {
  __result = (size_t )0;
  while ((int const   )*(__s + __result) == (int const   )__accept) {
    __result ++;
  }
  return ((unsigned int __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c2(char const   *__s , int __accept1 , int __accept2 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c2(char const   *__s , int __accept1 , int __accept2 ) 
{ register size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) == (int const   )__accept1) {

    } else {
      if ((int const   )*(__s + __result) == (int const   )__accept2) {

      } else {
        break;
      }
    }
    __result ++;
  }
  return ((unsigned int __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c3(char const   *__s , int __accept1 , int __accept2 , int __accept3 ) ;
__inline extern size_t __attribute__((__gnu_inline__))  __strspn_c3(char const   *__s , int __accept1 , int __accept2 , int __accept3 ) 
{ register size_t __result ;

  {
  __result = (size_t )0;
  while (1) {
    if ((int const   )*(__s + __result) == (int const   )__accept1) {

    } else {
      if ((int const   )*(__s + __result) == (int const   )__accept2) {

      } else {
        if ((int const   )*(__s + __result) == (int const   )__accept3) {

        } else {
          break;
        }
      }
    }
    __result ++;
  }
  return ((unsigned int __attribute__((__gnu_inline__))  )__result);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c2(char const   *__s , int __accept1 , int __accept2 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c2(char const   *__s , int __accept1 , int __accept2 ) 
{ char *tmp ;

  {
  while (1) {
    if ((int const   )*__s != 0) {
      if ((int const   )*__s != (int const   )__accept1) {
        if ((int const   )*__s != (int const   )__accept2) {

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __s ++;
  }
  if ((int const   )*__s == 0) {
    tmp = (char *)((void *)0);
  } else {
    tmp = (char *)((unsigned int )__s);
  }
  return ((char __attribute__((__gnu_inline__))  *)tmp);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c3(char const   *__s , int __accept1 , int __accept2 , int __accept3 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strpbrk_c3(char const   *__s , int __accept1 , int __accept2 , int __accept3 ) 
{ char *tmp ;

  {
  while (1) {
    if ((int const   )*__s != 0) {
      if ((int const   )*__s != (int const   )__accept1) {
        if ((int const   )*__s != (int const   )__accept2) {
          if ((int const   )*__s != (int const   )__accept3) {

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    __s ++;
  }
  if ((int const   )*__s == 0) {
    tmp = (char *)((void *)0);
  } else {
    tmp = (char *)((unsigned int )__s);
  }
  return ((char __attribute__((__gnu_inline__))  *)tmp);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strtok_r_1c(char *__s , char __sep , char **__nextp ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strtok_r_1c(char *__s , char __sep , char **__nextp ) 
{ char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  if ((unsigned int )__s == (unsigned int )((void *)0)) {
    __s = *__nextp;
  } else {

  }
  while ((int )*__s == (int )__sep) {
    __s ++;
  }
  __result = (char *)((void *)0);
  if ((int )*__s != 0) {
    tmp = __s;
    __s ++;
    __result = tmp;
    while ((int )*__s != 0) {
      tmp___0 = __s;
      __s ++;
      if ((int )*tmp___0 == (int )__sep) {
        *(__s + -1) = (char )'\000';
        break;
      } else {

      }
    }
  } else {

  }
  *__nextp = __s;
  return ((char __attribute__((__gnu_inline__))  *)__result);
}
}
extern char *__strsep_g(char **__stringp , char const   *__delim ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_1c(char **__s , char __reject ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_1c(char **__s , char __reject ) 
{ register char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  void *tmp___1 ;
  char *tmp___2 ;

  {
  __retval = *__s;
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    tmp___0 = tmp___2;
    *__s = tmp___0;
    if ((unsigned int )tmp___0 != (unsigned int )((void *)0)) {
      tmp = *__s;
      (*__s) ++;
      *tmp = (char )'\000';
    } else {

    }
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strsep_2c(char **__s , char __reject1 , char __reject2 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_2c(char **__s , char __reject1 , char __reject2 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  __retval = *__s;
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    __cp = __retval;
    while (1) {
      if ((int )*__cp == 0) {
        __cp = (char *)((void *)0);
        break;
      } else {

      }
      if ((int )*__cp == (int )__reject1) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else {
        if ((int )*__cp == (int )__reject2) {
          tmp = __cp;
          __cp ++;
          *tmp = (char )'\000';
          break;
        } else {

        }
      }
      __cp ++;
    }
    *__s = __cp;
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
__inline extern char __attribute__((__gnu_inline__))  *__strsep_3c(char **__s , char __reject1 , char __reject2 , char __reject3 ) ;
__inline extern char __attribute__((__gnu_inline__))  *__strsep_3c(char **__s , char __reject1 , char __reject2 , char __reject3 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  __retval = *__s;
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    __cp = __retval;
    while (1) {
      if ((int )*__cp == 0) {
        __cp = (char *)((void *)0);
        break;
      } else {

      }
      if ((int )*__cp == (int )__reject1) {
        tmp = __cp;
        __cp ++;
        *tmp = (char )'\000';
        break;
      } else {
        if ((int )*__cp == (int )__reject2) {
          tmp = __cp;
          __cp ++;
          *tmp = (char )'\000';
          break;
        } else {
          if ((int )*__cp == (int )__reject3) {
            tmp = __cp;
            __cp ++;
            *tmp = (char )'\000';
            break;
          } else {

          }
        }
      }
      __cp ++;
    }
    *__s = __cp;
  } else {

  }
  return ((char __attribute__((__gnu_inline__))  *)__retval);
}
}
extern  __attribute__((__nothrow__)) void *malloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *calloc(size_t __nmemb , size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strdup(char const   *__string )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strndup(char const   *__string , size_t __n )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) size_t __ctype_get_mb_cur_max(void) ;
__inline extern  __attribute__((__nothrow__)) double __attribute__((__gnu_inline__))  atof(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  atoi(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) long __attribute__((__gnu_inline__))  atol(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) long long __attribute__((__gnu_inline__))  atoll(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
extern  __attribute__((__nothrow__)) double strtod(char const   * __restrict  __nptr , char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) float strtof(char const   * __restrict  __nptr , char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long double strtold(char const   * __restrict  __nptr , char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long strtol(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long strtoul(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long long strtoq(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long long strtouq(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long long strtoll(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long long strtoull(char const   * __restrict  __nptr , char ** __restrict  __endptr , int __base )  __attribute__((__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) double __attribute__((__gnu_inline__))  atof(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern double __attribute__((__gnu_inline__))  atof(char const   *__nptr ) 
{ double tmp ;

  {
  tmp = strtod((char const   */* __restrict  */)__nptr, (char **/* __restrict  */)((char **)((void *)0)));
  return ((double __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  atoi(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern int __attribute__((__gnu_inline__))  atoi(char const   *__nptr ) 
{ long tmp ;

  {
  tmp = strtol((char const   */* __restrict  */)__nptr, (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((int __attribute__((__gnu_inline__))  )((int )tmp));
}
}
__inline extern  __attribute__((__nothrow__)) long __attribute__((__gnu_inline__))  atol(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern long __attribute__((__gnu_inline__))  atol(char const   *__nptr ) 
{ long tmp ;

  {
  tmp = strtol((char const   */* __restrict  */)__nptr, (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((long __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long long __attribute__((__gnu_inline__))  atoll(char const   *__nptr )  __attribute__((__pure__, __nonnull__(1))) ;
__inline extern long long __attribute__((__gnu_inline__))  atoll(char const   *__nptr ) 
{ long long tmp ;

  {
  tmp = strtoll((char const   */* __restrict  */)__nptr, (char **/* __restrict  */)((char **)((void *)0)), 10);
  return ((long long __attribute__((__gnu_inline__))  )tmp);
}
}
extern  __attribute__((__nothrow__)) char *l64a(long __n ) ;
extern  __attribute__((__nothrow__)) long a64l(char const   *__s )  __attribute__((__pure__, __nonnull__(1))) ;
extern int select(int __nfds , fd_set * __restrict  __readfds , fd_set * __restrict  __writefds , fd_set * __restrict  __exceptfds , struct timeval * __restrict  __timeout ) ;
extern int pselect(int __nfds , fd_set * __restrict  __readfds , fd_set * __restrict  __writefds , fd_set * __restrict  __exceptfds , struct timespec  const  * __restrict  __timeout , __sigset_t const   * __restrict  __sigmask ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  gnu_dev_major(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  gnu_dev_minor(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long __attribute__((__gnu_inline__))  gnu_dev_makedev(unsigned int __major , unsigned int __minor ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  gnu_dev_major(unsigned long long __dev ) ;
__inline extern unsigned int __attribute__((__gnu_inline__))  gnu_dev_major(unsigned long long __dev ) 
{ 

  {
  return ((unsigned int __attribute__((__gnu_inline__))  )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int __attribute__((__gnu_inline__))  gnu_dev_minor(unsigned long long __dev ) ;
__inline extern unsigned int __attribute__((__gnu_inline__))  gnu_dev_minor(unsigned long long __dev ) 
{ 

  {
  return ((unsigned int __attribute__((__gnu_inline__))  )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long __attribute__((__gnu_inline__))  gnu_dev_makedev(unsigned int __major , unsigned int __minor ) ;
__inline extern unsigned long long __attribute__((__gnu_inline__))  gnu_dev_makedev(unsigned int __major , unsigned int __minor ) 
{ 

  {
  return ((unsigned long long __attribute__((__gnu_inline__))  )(((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32)));
}
}
extern  __attribute__((__nothrow__)) long random(void) ;
extern  __attribute__((__nothrow__)) void srandom(unsigned int __seed ) ;
extern  __attribute__((__nothrow__)) char *initstate(unsigned int __seed , char *__statebuf , size_t __statelen )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *setstate(char *__statebuf )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int random_r(struct random_data * __restrict  __buf , int32_t * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int srandom_r(unsigned int __seed , struct random_data *__buf )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int initstate_r(unsigned int __seed , char * __restrict  __statebuf , size_t __statelen , struct random_data * __restrict  __buf )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) int setstate_r(char * __restrict  __statebuf , struct random_data * __restrict  __buf )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int rand(void) ;
extern  __attribute__((__nothrow__)) void srand(unsigned int __seed ) ;
extern  __attribute__((__nothrow__)) int rand_r(unsigned int *__seed ) ;
extern  __attribute__((__nothrow__)) double drand48(void) ;
extern  __attribute__((__nothrow__)) double erand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long lrand48(void) ;
extern  __attribute__((__nothrow__)) long nrand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long mrand48(void) ;
extern  __attribute__((__nothrow__)) long jrand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void srand48(long __seedval ) ;
extern  __attribute__((__nothrow__)) unsigned short *seed48(unsigned short *__seed16v )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void lcong48(unsigned short *__param )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int drand48_r(struct drand48_data * __restrict  __buffer , double * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int erand48_r(unsigned short *__xsubi , struct drand48_data * __restrict  __buffer , double * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int lrand48_r(struct drand48_data * __restrict  __buffer , long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int nrand48_r(unsigned short *__xsubi , struct drand48_data * __restrict  __buffer , long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int mrand48_r(struct drand48_data * __restrict  __buffer , long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int jrand48_r(unsigned short *__xsubi , struct drand48_data * __restrict  __buffer , long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int srand48_r(long __seedval , struct drand48_data *__buffer )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int seed48_r(unsigned short *__seed16v , struct drand48_data *__buffer )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int lcong48_r(unsigned short *__param , struct drand48_data *__buffer )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *realloc(void *__ptr , size_t __size )  __attribute__((__warn_unused_result__)) ;
extern  __attribute__((__nothrow__)) void free(void *__ptr ) ;
extern  __attribute__((__nothrow__)) void cfree(void *__ptr ) ;
extern  __attribute__((__nothrow__)) void *alloca(size_t __size ) ;
extern  __attribute__((__nothrow__)) void *valloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) int posix_memalign(void **__memptr , size_t __alignment , size_t __size )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__, __noreturn__)) void abort(void) ;
extern  __attribute__((__nothrow__)) int atexit(void (*__func)(void) )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int on_exit(void (*__func)(int __status , void *__arg ) , void *__arg )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__, __noreturn__)) void exit(int __status ) ;
extern  __attribute__((__nothrow__, __noreturn__)) void _Exit(int __status ) ;
extern  __attribute__((__nothrow__)) char *getenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *__secure_getenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int putenv(char *__string )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int setenv(char const   *__name , char const   *__value , int __replace )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int unsetenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int clearenv(void) ;
extern  __attribute__((__nothrow__)) char *mktemp(char *__template )  __attribute__((__nonnull__(1))) ;
extern int mkstemp(char *__template )  __asm__("mkstemp64") __attribute__((__nonnull__(1))) ;
extern int mkstemps(char *__template , int __suffixlen )  __asm__("mkstemps64") __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *mkdtemp(char *__template )  __attribute__((__nonnull__(1))) ;
extern int system(char const   *__command ) ;
extern  __attribute__((__nothrow__)) char *realpath(char const   * __restrict  __name , char * __restrict  __resolved ) ;
extern void *bsearch(void const   *__key , void const   *__base , size_t __nmemb , size_t __size , int (*__compar)(void const   * , void const   * ) )  __attribute__((__nonnull__(1,2,5))) ;
extern void qsort(void *__base , size_t __nmemb , size_t __size , int (*__compar)(void const   * , void const   * ) )  __attribute__((__nonnull__(1,4))) ;
extern  __attribute__((__nothrow__)) int abs(int __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long labs(long __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long long llabs(long long __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) div_t div(int __numer , int __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) ldiv_t ldiv(long __numer , long __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) lldiv_t lldiv(long long __numer , long long __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) char *ecvt(double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *fcvt(double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *gcvt(double __value , int __ndigit , char *__buf )  __attribute__((__nonnull__(3))) ;
extern  __attribute__((__nothrow__)) char *qecvt(long double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *qfcvt(long double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *qgcvt(long double __value , int __ndigit , char *__buf )  __attribute__((__nonnull__(3))) ;
extern  __attribute__((__nothrow__)) int ecvt_r(double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign , char * __restrict  __buf , size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int fcvt_r(double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign , char * __restrict  __buf , size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int qecvt_r(long double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign , char * __restrict  __buf , size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int qfcvt_r(long double __value , int __ndigit , int * __restrict  __decpt , int * __restrict  __sign , char * __restrict  __buf , size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int mblen(char const   *__s , size_t __n ) ;
extern  __attribute__((__nothrow__)) int mbtowc(wchar_t * __restrict  __pwc , char const   * __restrict  __s , size_t __n ) ;
extern  __attribute__((__nothrow__)) int wctomb(char *__s , wchar_t __wchar ) ;
extern  __attribute__((__nothrow__)) size_t mbstowcs(wchar_t * __restrict  __pwcs , char const   * __restrict  __s , size_t __n ) ;
extern  __attribute__((__nothrow__)) size_t wcstombs(char * __restrict  __s , wchar_t const   * __restrict  __pwcs , size_t __n ) ;
extern  __attribute__((__nothrow__)) int rpmatch(char const   *__response )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int getsubopt(char ** __restrict  __optionp , char * const  * __restrict  __tokens , char ** __restrict  __valuep )  __attribute__((__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) int getloadavg(double *__loadavg , int __nelem )  __attribute__((__nonnull__(1))) ;
extern struct _IO_FILE_plus _IO_2_1_stdin_ ;
extern struct _IO_FILE_plus _IO_2_1_stdout_ ;
extern struct _IO_FILE_plus _IO_2_1_stderr_ ;
extern int __underflow(_IO_FILE * ) ;
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_feof(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_ferror(_IO_FILE *__fp ) ;
extern int _IO_peekc_locked(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) void _IO_flockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) void _IO_funlockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) int _IO_ftrylockfile(_IO_FILE * ) ;
extern int _IO_vfscanf(_IO_FILE * __restrict   , char const   * __restrict   , __gnuc_va_list  , int * __restrict   ) ;
extern int _IO_vfprintf(_IO_FILE * __restrict   , char const   * __restrict   , __gnuc_va_list  ) ;
extern __ssize_t _IO_padn(_IO_FILE * , int  , __ssize_t  ) ;
extern size_t _IO_sgetn(_IO_FILE * , void * , size_t  ) ;
extern __off64_t _IO_seekoff(_IO_FILE * , __off64_t  , int  , int  ) ;
extern __off64_t _IO_seekpos(_IO_FILE * , __off64_t  , int  ) ;
extern  __attribute__((__nothrow__)) void _IO_free_backup_area(_IO_FILE * ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
extern  __attribute__((__nothrow__)) int remove(char const   *__filename ) ;
extern  __attribute__((__nothrow__)) int rename(char const   *__old , char const   *__new ) ;
extern  __attribute__((__nothrow__)) int renameat(int __oldfd , char const   *__old , int __newfd , char const   *__new ) ;
extern FILE *tmpfile(void)  __asm__("tmpfile64")  ;
extern  __attribute__((__nothrow__)) char *tmpnam(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tmpnam_r(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tempnam(char const   *__dir , char const   *__pfx )  __attribute__((__malloc__)) ;
extern int fclose(FILE *__stream ) ;
extern int fflush(FILE *__stream ) ;
extern int fflush_unlocked(FILE *__stream ) ;
extern FILE *fopen(char const   * __restrict  __filename , char const   * __restrict  __modes )  __asm__("fopen64")  ;
extern FILE *freopen(char const   * __restrict  __filename , char const   * __restrict  __modes , FILE * __restrict  __stream )  __asm__("freopen64")  ;
extern  __attribute__((__nothrow__)) FILE *fdopen(int __fd , char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *fmemopen(void *__s , size_t __len , char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *open_memstream(char **__bufloc , size_t *__sizeloc ) ;
extern  __attribute__((__nothrow__)) void setbuf(FILE * __restrict  __stream , char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) int setvbuf(FILE * __restrict  __stream , char * __restrict  __buf , int __modes , size_t __n ) ;
extern  __attribute__((__nothrow__)) void setbuffer(FILE * __restrict  __stream , char * __restrict  __buf , size_t __size ) ;
extern  __attribute__((__nothrow__)) void setlinebuf(FILE *__stream ) ;
extern int fprintf(FILE * __restrict  __stream , char const   * __restrict  __format  , ...) ;
extern int printf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sprintf(char * __restrict  __s , char const   * __restrict  __format  , ...) ;
extern int vfprintf(FILE * __restrict  __s , char const   * __restrict  __format , __gnuc_va_list __arg ) ;
__inline extern int __attribute__((__gnu_inline__))  vprintf(char const   * __restrict  __fmt , __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vsprintf(char * __restrict  __s , char const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  snprintf)(char * __restrict  __s , size_t __maxlen , char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsnprintf)(char * __restrict  __s , size_t __maxlen , char const   * __restrict  __format , __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  vdprintf)(int __fd , char const   * __restrict  __fmt , __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  dprintf)(int __fd , char const   * __restrict  __fmt  , ...) ;
extern int fscanf(FILE * __restrict  __stream , char const   * __restrict  __format  , ...)  __asm__("__isoc99_fscanf")  ;
extern int scanf(char const   * __restrict  __format  , ...)  __asm__("__isoc99_scanf")  ;
extern  __attribute__((__nothrow__)) int sscanf(char const   * __restrict  __s , char const   * __restrict  __format  , ...)  __asm__("__isoc99_sscanf")  ;
extern int ( /* format attribute */  vfscanf)(FILE * __restrict  __s , char const   * __restrict  __format , __gnuc_va_list __arg )  __asm__("__isoc99_vfscanf")  ;
extern int ( /* format attribute */  vscanf)(char const   * __restrict  __format , __gnuc_va_list __arg )  __asm__("__isoc99_vscanf")  ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsscanf)(char const   * __restrict  __s , char const   * __restrict  __format , __gnuc_va_list __arg )  __asm__("__isoc99_vsscanf")  ;
extern int fgetc(FILE *__stream ) ;
extern int getc(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  getchar(void) ;
__inline extern int __attribute__((__gnu_inline__))  getc_unlocked(FILE *__fp ) ;
__inline extern int __attribute__((__gnu_inline__))  getchar_unlocked(void) ;
__inline extern int __attribute__((__gnu_inline__))  fgetc_unlocked(FILE *__fp ) ;
extern int fputc(int __c , FILE *__stream ) ;
extern int putc(int __c , FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  putchar(int __c ) ;
__inline extern int __attribute__((__gnu_inline__))  fputc_unlocked(int __c , FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  putc_unlocked(int __c , FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  putchar_unlocked(int __c ) ;
extern int getw(FILE *__stream ) ;
extern int putw(int __w , FILE *__stream ) ;
extern char *fgets(char * __restrict  __s , int __n , FILE * __restrict  __stream ) ;
extern char *gets(char *__s ) ;
extern __ssize_t __getdelim(char ** __restrict  __lineptr , size_t * __restrict  __n , int __delimiter , FILE * __restrict  __stream ) ;
extern __ssize_t getdelim(char ** __restrict  __lineptr , size_t * __restrict  __n , int __delimiter , FILE * __restrict  __stream ) ;
extern __ssize_t getline(char ** __restrict  __lineptr , size_t * __restrict  __n , FILE * __restrict  __stream ) ;
extern int fputs(char const   * __restrict  __s , FILE * __restrict  __stream ) ;
extern int puts(char const   *__s ) ;
extern int ungetc(int __c , FILE *__stream ) ;
extern size_t fread(void * __restrict  __ptr , size_t __size , size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite(void const   * __restrict  __ptr , size_t __size , size_t __n , FILE * __restrict  __s ) ;
extern size_t fread_unlocked(void * __restrict  __ptr , size_t __size , size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite_unlocked(void const   * __restrict  __ptr , size_t __size , size_t __n , FILE * __restrict  __stream ) ;
extern int fseek(FILE *__stream , long __off , int __whence ) ;
extern long ftell(FILE *__stream ) ;
extern void rewind(FILE *__stream ) ;
extern int fseeko(FILE *__stream , __off64_t __off , int __whence )  __asm__("fseeko64")  ;
extern __off64_t ftello(FILE *__stream )  __asm__("ftello64")  ;
extern int fgetpos(FILE * __restrict  __stream , fpos_t * __restrict  __pos )  __asm__("fgetpos64")  ;
extern int fsetpos(FILE *__stream , fpos_t const   *__pos )  __asm__("fsetpos64")  ;
extern  __attribute__((__nothrow__)) void clearerr(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int feof(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ferror(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void clearerr_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  feof_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ferror_unlocked(FILE *__stream ) ;
extern void perror(char const   *__s ) ;
extern int sys_nerr ;
extern char const   * const  sys_errlist[] ;
extern  __attribute__((__nothrow__)) int fileno(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int fileno_unlocked(FILE *__stream ) ;
extern FILE *popen(char const   *__command , char const   *__modes ) ;
extern int pclose(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) char *ctermid(char *__s ) ;
extern  __attribute__((__nothrow__)) void flockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ftrylockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void funlockfile(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  vprintf(char const   * __restrict  __fmt , __gnuc_va_list __arg ) 
{ int tmp ;

  {
  tmp = vfprintf((FILE */* __restrict  */)stdout, __fmt, __arg);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  getchar(void) 
{ int tmp ;

  {
  tmp = _IO_getc(stdin);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  fgetc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end), 0L);
  if (tmp___3) {
    tmp___0 = __uflow(__fp);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = __fp->_IO_read_ptr;
    (__fp->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  getc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end), 0L);
  if (tmp___3) {
    tmp___0 = __uflow(__fp);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = __fp->_IO_read_ptr;
    (__fp->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  getchar_unlocked(void) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  tmp___3 = __builtin_expect((long )((unsigned int )stdin->_IO_read_ptr >= (unsigned int )stdin->_IO_read_end), 0L);
  if (tmp___3) {
    tmp___0 = __uflow(stdin);
    tmp___2 = tmp___0;
  } else {
    tmp___1 = stdin->_IO_read_ptr;
    (stdin->_IO_read_ptr) ++;
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___2);
}
}
__inline extern int __attribute__((__gnu_inline__))  putchar(int __c ) 
{ int tmp ;

  {
  tmp = _IO_putc(__c, stdout);
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  fputc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end), 0L);
  if (tmp___4) {
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = __stream->_IO_write_ptr;
    (__stream->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern int __attribute__((__gnu_inline__))  putc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end), 0L);
  if (tmp___4) {
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = __stream->_IO_write_ptr;
    (__stream->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern int __attribute__((__gnu_inline__))  putchar_unlocked(int __c ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  tmp___4 = __builtin_expect((long )((unsigned int )stdout->_IO_write_ptr >= (unsigned int )stdout->_IO_write_end), 0L);
  if (tmp___4) {
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    tmp___3 = tmp___0;
  } else {
    tmp___1 = stdout->_IO_write_ptr;
    (stdout->_IO_write_ptr) ++;
    tmp___2 = (char )__c;
    *tmp___1 = tmp___2;
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  return ((int __attribute__((__gnu_inline__))  )tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  feof_unlocked(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  feof_unlocked(FILE *__stream ) 
{ 

  {
  return ((int __attribute__((__gnu_inline__))  )((__stream->_flags & 0x10) != 0));
}
}
__inline extern  __attribute__((__nothrow__)) int __attribute__((__gnu_inline__))  ferror_unlocked(FILE *__stream ) ;
__inline extern int __attribute__((__gnu_inline__))  ferror_unlocked(FILE *__stream ) 
{ 

  {
  return ((int __attribute__((__gnu_inline__))  )((__stream->_flags & 0x20) != 0));
}
}
extern  __attribute__((__nothrow__, __noreturn__)) void __assert_fail(char const   *__assertion , char const   *__file , unsigned int __line , char const   *__function ) ;
extern  __attribute__((__nothrow__, __noreturn__)) void __assert_perror_fail(int __errnum , char const   *__file , unsigned int __line , char const   *__function ) ;
extern  __attribute__((__nothrow__, __noreturn__)) void __assert(char const   *__assertion , char const   *__file , int __line ) ;
int ( /* format attribute */  VALGRIND_PRINTF)(char const   *format  , ...)  __attribute__((__weak__)) ;
int ( /* format attribute */  VALGRIND_PRINTF)(char const   *format  , ...)  __attribute__((__weak__)) ;
int ( /* format attribute */  VALGRIND_PRINTF)(char const   *format  , ...) 
{ unsigned long _qzz_res ;
  va_list vargs ;
  unsigned int _zzq_args[5] ;

  {
  __builtin_va_start(vargs, format);
  _zzq_args[0] = 5121U;
  _zzq_args[1] = (unsigned int )((unsigned long )format);
  _zzq_args[2] = (unsigned int )((unsigned long )vargs);
  _zzq_args[3] = 0U;
  _zzq_args[4] = 0U;
  __asm__  volatile   ("roll $29, %%eax ; roll $3, %%eax\n\t"
                       "rorl $27, %%eax ; rorl $5, %%eax\n\t"
                       "roll $13, %%eax ; roll $19, %%eax": "=d" (_qzz_res): "a" (& _zzq_args[0]), "0" (0): "cc", "memory");
  __builtin_va_end(vargs);
  return ((int )_qzz_res);
}
}
int ( /* format attribute */  VALGRIND_PRINTF_BACKTRACE)(char const   *format  , ...)  __attribute__((__weak__)) ;
int ( /* format attribute */  VALGRIND_PRINTF_BACKTRACE)(char const   *format  , ...)  __attribute__((__weak__)) ;
int ( /* format attribute */  VALGRIND_PRINTF_BACKTRACE)(char const   *format  , ...) 
{ unsigned long _qzz_res ;
  va_list vargs ;
  unsigned int _zzq_args[5] ;

  {
  __builtin_va_start(vargs, format);
  _zzq_args[0] = 5122U;
  _zzq_args[1] = (unsigned int )((unsigned long )format);
  _zzq_args[2] = (unsigned int )((unsigned long )vargs);
  _zzq_args[3] = 0U;
  _zzq_args[4] = 0U;
  __asm__  volatile   ("roll $29, %%eax ; roll $3, %%eax\n\t"
                       "rorl $27, %%eax ; rorl $5, %%eax\n\t"
                       "roll $13, %%eax ; roll $19, %%eax": "=d" (_qzz_res): "a" (& _zzq_args[0]), "0" (0): "cc", "memory");
  __builtin_va_end(vargs);
  return ((int )_qzz_res);
}
}
extern GArray *g_array_new(gboolean zero_terminated , gboolean clear_ , guint element_size ) ;
extern GArray *g_array_sized_new(gboolean zero_terminated , gboolean clear_ , guint element_size , guint reserved_size ) ;
extern gchar *g_array_free(GArray *array , gboolean free_segment ) ;
extern GArray *g_array_ref(GArray *array ) ;
extern void g_array_unref(GArray *array ) ;
extern guint g_array_get_element_size(GArray *array ) ;
extern GArray *g_array_append_vals(GArray *array , gconstpointer data , guint len ) ;
extern GArray *g_array_prepend_vals(GArray *array , gconstpointer data , guint len ) ;
extern GArray *g_array_insert_vals(GArray *array , guint index_ , gconstpointer data , guint len ) ;
extern GArray *g_array_set_size(GArray *array , guint length ) ;
extern GArray *g_array_remove_index(GArray *array , guint index_ ) ;
extern GArray *g_array_remove_index_fast(GArray *array , guint index_ ) ;
extern GArray *g_array_remove_range(GArray *array , guint index_ , guint length ) ;
extern void g_array_sort(GArray *array , gint (*compare_func)(gconstpointer a , gconstpointer b ) ) ;
extern void g_array_sort_with_data(GArray *array , gint (*compare_func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer user_data ) ;
extern GPtrArray *g_ptr_array_new(void) ;
extern GPtrArray *g_ptr_array_new_with_free_func(void (*element_free_func)(gpointer data ) ) ;
extern GPtrArray *g_ptr_array_sized_new(guint reserved_size ) ;
extern gpointer *g_ptr_array_free(GPtrArray *array , gboolean free_seg ) ;
extern GPtrArray *g_ptr_array_ref(GPtrArray *array ) ;
extern void g_ptr_array_unref(GPtrArray *array ) ;
extern void g_ptr_array_set_free_func(GPtrArray *array , void (*element_free_func)(gpointer data ) ) ;
extern void g_ptr_array_set_size(GPtrArray *array , gint length ) ;
extern gpointer g_ptr_array_remove_index(GPtrArray *array , guint index_ ) ;
extern gpointer g_ptr_array_remove_index_fast(GPtrArray *array , guint index_ ) ;
extern gboolean g_ptr_array_remove(GPtrArray *array , gpointer data ) ;
extern gboolean g_ptr_array_remove_fast(GPtrArray *array , gpointer data ) ;
extern void g_ptr_array_remove_range(GPtrArray *array , guint index_ , guint length ) ;
extern void g_ptr_array_add(GPtrArray *array , gpointer data ) ;
extern void g_ptr_array_sort(GPtrArray *array , gint (*compare_func)(gconstpointer a , gconstpointer b ) ) ;
extern void g_ptr_array_sort_with_data(GPtrArray *array , gint (*compare_func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer user_data ) ;
extern void g_ptr_array_foreach(GPtrArray *array , void (*func)(gpointer data , gpointer user_data ) , gpointer user_data ) ;
extern GByteArray *g_byte_array_new(void) ;
extern GByteArray *g_byte_array_sized_new(guint reserved_size ) ;
extern guint8 *g_byte_array_free(GByteArray *array , gboolean free_segment ) ;
extern GByteArray *g_byte_array_ref(GByteArray *array ) ;
extern void g_byte_array_unref(GByteArray *array ) ;
extern GByteArray *g_byte_array_append(GByteArray *array , guint8 const   *data , guint len ) ;
extern GByteArray *g_byte_array_prepend(GByteArray *array , guint8 const   *data , guint len ) ;
extern GByteArray *g_byte_array_set_size(GByteArray *array , guint length ) ;
extern GByteArray *g_byte_array_remove_index(GByteArray *array , guint index_ ) ;
extern GByteArray *g_byte_array_remove_index_fast(GByteArray *array , guint index_ ) ;
extern GByteArray *g_byte_array_remove_range(GByteArray *array , guint index_ , guint length ) ;
extern void g_byte_array_sort(GByteArray *array , gint (*compare_func)(gconstpointer a , gconstpointer b ) ) ;
extern void g_byte_array_sort_with_data(GByteArray *array , gint (*compare_func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer user_data ) ;
extern GQuark g_quark_try_string(gchar const   *string ) ;
extern GQuark g_quark_from_static_string(gchar const   *string ) ;
extern GQuark g_quark_from_string(gchar const   *string ) ;
extern gchar const   *g_quark_to_string(GQuark quark )  __attribute__((__const__)) ;
extern gchar const   *g_intern_string(gchar const   *string ) ;
extern gchar const   *g_intern_static_string(gchar const   *string ) ;
extern GError *( /* format attribute */  g_error_new)(GQuark domain , gint code , gchar const   *format  , ...) ;
extern GError *g_error_new_literal(GQuark domain , gint code , gchar const   *message ) ;
extern GError *g_error_new_valist(GQuark domain , gint code , gchar const   *format , va_list args ) ;
extern void g_error_free(GError *error ) ;
extern GError *g_error_copy(GError const   *error ) ;
extern gboolean g_error_matches(GError const   *error , GQuark domain , gint code ) ;
extern void ( /* format attribute */  g_set_error)(GError **err , GQuark domain , gint code , gchar const   *format  , ...) ;
extern void g_set_error_literal(GError **err , GQuark domain , gint code , gchar const   *message ) ;
extern void g_propagate_error(GError **dest , GError *src ) ;
extern void g_clear_error(GError **err ) ;
extern void ( /* format attribute */  g_prefix_error)(GError **err , gchar const   *format  , ...) ;
extern void ( /* format attribute */  g_propagate_prefixed_error)(GError **dest , GError *src , gchar const   *format  , ...) ;
extern gchar const   *g_get_user_name(void) ;
extern gchar const   *g_get_real_name(void) ;
extern gchar const   *g_get_home_dir(void) ;
extern gchar const   *g_get_tmp_dir(void) ;
extern gchar const   *g_get_host_name(void) ;
extern gchar *g_get_prgname(void) ;
extern void g_set_prgname(gchar const   *prgname ) ;
extern gchar const   *g_get_application_name(void) ;
extern void g_set_application_name(gchar const   *application_name ) ;
extern void g_reload_user_special_dirs_cache(void) ;
extern gchar const   *g_get_user_data_dir(void) ;
extern gchar const   *g_get_user_config_dir(void) ;
extern gchar const   *g_get_user_cache_dir(void) ;
extern gchar const   * const  *g_get_system_data_dirs(void) ;
extern gchar const   * const  *g_get_system_config_dirs(void) ;
extern gchar const   * const  *g_get_language_names(void) ;
extern gchar const   *g_get_user_special_dir(GUserDirectory directory ) ;
extern guint g_parse_debug_string(gchar const   *string , GDebugKey const   *keys , guint nkeys ) ;
extern gint ( /* format attribute */  g_snprintf)(gchar *string , gulong n , gchar const   *format  , ...) ;
extern gint g_vsnprintf(gchar *string , gulong n , gchar const   *format , va_list args ) ;
extern gboolean g_path_is_absolute(gchar const   *file_name ) ;
extern gchar const   *g_path_skip_root(gchar const   *file_name ) ;
extern gchar const   *g_basename(gchar const   *file_name ) ;
extern gchar *g_get_current_dir(void) ;
extern gchar *g_path_get_basename(gchar const   *file_name )  __attribute__((__malloc__)) ;
extern gchar *g_path_get_dirname(gchar const   *file_name )  __attribute__((__malloc__)) ;
extern void g_nullify_pointer(gpointer *nullify_location ) ;
extern gchar const   *g_getenv(gchar const   *variable ) ;
extern gboolean g_setenv(gchar const   *variable , gchar const   *value , gboolean overwrite ) ;
extern void g_unsetenv(gchar const   *variable ) ;
extern gchar **g_listenv(void) ;
extern gchar const   *_g_getenv_nomalloc(gchar const   *variable , gchar *buffer ) ;
extern void g_atexit(void (*func)(void) ) ;
extern gchar *g_find_program_in_path(gchar const   *program ) ;
__inline static gint g_bit_nth_lsf(gulong mask , gint nth_bit )  __attribute__((__unused__, __const__)) ;
__inline static gint g_bit_nth_msf(gulong mask , gint nth_bit )  __attribute__((__unused__, __const__)) ;
__inline static guint g_bit_storage(gulong number )  __attribute__((__unused__, __const__)) ;
__inline static void g_trash_stack_push(GTrashStack **stack_p , gpointer data_p )  __attribute__((__unused__)) ;
__inline static gpointer g_trash_stack_pop(GTrashStack **stack_p )  __attribute__((__unused__)) ;
__inline static gpointer g_trash_stack_peek(GTrashStack **stack_p )  __attribute__((__unused__)) ;
__inline static guint g_trash_stack_height(GTrashStack **stack_p )  __attribute__((__unused__)) ;
__inline static gint g_bit_nth_lsf(gulong mask , gint nth_bit )  __attribute__((__unused__, __const__)) ;
__inline static gint g_bit_nth_lsf(gulong mask , gint nth_bit ) 
{ int _g_boolean_var_ ;
  long tmp ;

  {
  if (nth_bit < -1) {
    _g_boolean_var_ = 1;
  } else {
    _g_boolean_var_ = 0;
  }
  tmp = __builtin_expect((long )_g_boolean_var_, 0L);
  if (tmp) {
    nth_bit = -1;
  } else {

  }
  while (nth_bit < 31) {
    nth_bit ++;
    if (mask & (1UL << nth_bit)) {
      return (nth_bit);
    } else {

    }
  }
  return (-1);
}
}
__inline static gint g_bit_nth_msf(gulong mask , gint nth_bit )  __attribute__((__unused__, __const__)) ;
__inline static gint g_bit_nth_msf(gulong mask , gint nth_bit ) 
{ int _g_boolean_var_ ;
  long tmp ;

  {
  if (nth_bit < 0) {
    nth_bit = 32;
  } else {
    if (nth_bit > 32) {
      _g_boolean_var_ = 1;
    } else {
      _g_boolean_var_ = 0;
    }
    tmp = __builtin_expect((long )_g_boolean_var_, 0L);
    if (tmp) {
      nth_bit = 32;
    } else {

    }
  }
  while (nth_bit > 0) {
    nth_bit --;
    if (mask & (1UL << nth_bit)) {
      return (nth_bit);
    } else {

    }
  }
  return (-1);
}
}
__inline static guint g_bit_storage(gulong number )  __attribute__((__unused__, __const__)) ;
__inline static guint g_bit_storage(gulong number ) 
{ int _g_boolean_var_ ;
  long tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int _g_boolean_var____0 ;
  long tmp___2 ;

  {
  if (number) {
    _g_boolean_var____0 = 1;
  } else {
    _g_boolean_var____0 = 0;
  }
  tmp___2 = __builtin_expect((long )_g_boolean_var____0, 1L);
  if (tmp___2) {
    tmp___0 = __builtin_clzl(number);
    tmp___1 = (31 ^ tmp___0) + 1;
  } else {
    tmp___1 = 1;
  }
  return ((unsigned int )tmp___1);
}
}
__inline static void g_trash_stack_push(GTrashStack **stack_p , gpointer data_p )  __attribute__((__unused__)) ;
__inline static void g_trash_stack_push(GTrashStack **stack_p , gpointer data_p ) 
{ GTrashStack *data ;

  {
  data = (GTrashStack *)data_p;
  data->next = *stack_p;
  *stack_p = data;
  return;
}
}
__inline static gpointer g_trash_stack_pop(GTrashStack **stack_p )  __attribute__((__unused__)) ;
__inline static gpointer g_trash_stack_pop(GTrashStack **stack_p ) 
{ GTrashStack *data ;

  {
  data = *stack_p;
  if (data) {
    *stack_p = data->next;
    data->next = (GTrashStack *)((void *)0);
  } else {

  }
  return ((void *)data);
}
}
__inline static gpointer g_trash_stack_peek(GTrashStack **stack_p )  __attribute__((__unused__)) ;
__inline static gpointer g_trash_stack_peek(GTrashStack **stack_p ) 
{ GTrashStack *data ;

  {
  data = *stack_p;
  return ((void *)data);
}
}
__inline static guint g_trash_stack_height(GTrashStack **stack_p )  __attribute__((__unused__)) ;
__inline static guint g_trash_stack_height(GTrashStack **stack_p ) 
{ GTrashStack *data ;
  guint i ;

  {
  i = (guint )0;
  data = *stack_p;
  while (data) {
    i ++;
    data = data->next;
  }
  return (i);
}
}
extern guint const   glib_major_version ;
extern guint const   glib_minor_version ;
extern guint const   glib_micro_version ;
extern guint const   glib_interface_age ;
extern guint const   glib_binary_age ;
extern gchar const   *glib_check_version(guint required_major , guint required_minor , guint required_micro ) ;
extern gint g_atomic_int_exchange_and_add(gint volatile __attribute__((__may_alias__))  *atomic , gint val ) ;
extern void g_atomic_int_add(gint volatile __attribute__((__may_alias__))  *atomic , gint val ) ;
extern gboolean g_atomic_int_compare_and_exchange(gint volatile __attribute__((__may_alias__))  *atomic , gint oldval , gint newval ) ;
extern gboolean g_atomic_pointer_compare_and_exchange(gpointer volatile __attribute__((__may_alias__))  *atomic , gpointer oldval , gpointer newval ) ;
extern gint g_atomic_int_get(gint volatile __attribute__((__may_alias__))  *atomic ) ;
extern void g_atomic_int_set(gint volatile __attribute__((__may_alias__))  *atomic , gint newval ) ;
extern gpointer g_atomic_pointer_get(gpointer volatile __attribute__((__may_alias__))  *atomic ) ;
extern void g_atomic_pointer_set(gpointer volatile __attribute__((__may_alias__))  *atomic , gpointer newval ) ;
extern GQuark g_thread_error_quark(void) ;
extern GThreadFunctions g_thread_functions_for_glib_use ;
extern gboolean g_thread_use_default_impl ;
extern gboolean g_threads_got_initialized ;
extern guint64 (*g_thread_gettime)(void) ;
extern void g_thread_init(GThreadFunctions *vtable ) ;
extern void g_thread_init_with_errorcheck_mutexes(GThreadFunctions *vtable ) ;
extern gboolean g_thread_get_initialized(void) ;
extern GMutex *g_static_mutex_get_mutex_impl(GMutex **mutex ) ;
extern GThread *g_thread_create_full(gpointer (*func)(gpointer data ) , gpointer data , gulong stack_size , gboolean joinable , gboolean bound , GThreadPriority priority , GError **error ) ;
extern GThread *g_thread_self(void) ;
extern void g_thread_exit(gpointer retval ) ;
extern gpointer g_thread_join(GThread *thread ) ;
extern void g_thread_set_priority(GThread *thread , GThreadPriority priority ) ;
extern void g_static_mutex_init(GStaticMutex *mutex ) ;
extern void g_static_mutex_free(GStaticMutex *mutex ) ;
extern void g_static_private_init(GStaticPrivate *private_key ) ;
extern gpointer g_static_private_get(GStaticPrivate *private_key ) ;
extern void g_static_private_set(GStaticPrivate *private_key , gpointer data , void (*notify)(gpointer data ) ) ;
extern void g_static_private_free(GStaticPrivate *private_key ) ;
extern void g_static_rec_mutex_init(GStaticRecMutex *mutex ) ;
extern void g_static_rec_mutex_lock(GStaticRecMutex *mutex ) ;
extern gboolean g_static_rec_mutex_trylock(GStaticRecMutex *mutex ) ;
extern void g_static_rec_mutex_unlock(GStaticRecMutex *mutex ) ;
extern void g_static_rec_mutex_lock_full(GStaticRecMutex *mutex , guint depth ) ;
extern guint g_static_rec_mutex_unlock_full(GStaticRecMutex *mutex ) ;
extern void g_static_rec_mutex_free(GStaticRecMutex *mutex ) ;
extern void g_static_rw_lock_init(GStaticRWLock *lock ) ;
extern void g_static_rw_lock_reader_lock(GStaticRWLock *lock ) ;
extern gboolean g_static_rw_lock_reader_trylock(GStaticRWLock *lock ) ;
extern void g_static_rw_lock_reader_unlock(GStaticRWLock *lock ) ;
extern void g_static_rw_lock_writer_lock(GStaticRWLock *lock ) ;
extern gboolean g_static_rw_lock_writer_trylock(GStaticRWLock *lock ) ;
extern void g_static_rw_lock_writer_unlock(GStaticRWLock *lock ) ;
extern void g_static_rw_lock_free(GStaticRWLock *lock ) ;
extern void g_thread_foreach(void (*thread_func)(gpointer data , gpointer user_data ) , gpointer user_data ) ;
extern gpointer g_once_impl(GOnce *once , gpointer (*func)(gpointer data ) , gpointer arg ) ;
__inline static gboolean g_once_init_enter(gsize volatile   *value_location )  __attribute__((__unused__)) ;
extern gboolean g_once_init_enter_impl(gsize volatile   *value_location ) ;
extern void g_once_init_leave(gsize volatile   *value_location , gsize initialization_value ) ;
__inline static gboolean g_once_init_enter(gsize volatile   *value_location )  __attribute__((__unused__)) ;
__inline static gboolean g_once_init_enter(gsize volatile   *value_location ) 
{ gboolean tmp ;
  int _g_boolean_var_ ;
  gpointer tmp___0 ;
  long tmp___1 ;

  {
  tmp___0 = g_atomic_pointer_get((gpointer volatile __attribute__((__may_alias__))  *)((void *)value_location));
  if ((unsigned int )tmp___0 != (unsigned int )((void *)0)) {
    _g_boolean_var_ = 1;
  } else {
    _g_boolean_var_ = 0;
  }
  tmp___1 = __builtin_expect((long )_g_boolean_var_, 1L);
  if (tmp___1) {
    return (0);
  } else {
    tmp = g_once_init_enter_impl(value_location);
    return (tmp);
  }
}
}
extern void glib_dummy_decl(void) ;
extern GAsyncQueue *g_async_queue_new(void) ;
extern GAsyncQueue *g_async_queue_new_full(void (*item_free_func)(gpointer data ) ) ;
extern void g_async_queue_lock(GAsyncQueue *queue ) ;
extern void g_async_queue_unlock(GAsyncQueue *queue ) ;
extern GAsyncQueue *g_async_queue_ref(GAsyncQueue *queue ) ;
extern void g_async_queue_unref(GAsyncQueue *queue ) ;
extern void g_async_queue_ref_unlocked(GAsyncQueue *queue ) ;
extern void g_async_queue_unref_and_unlock(GAsyncQueue *queue ) ;
extern void g_async_queue_push(GAsyncQueue *queue , gpointer data ) ;
extern void g_async_queue_push_unlocked(GAsyncQueue *queue , gpointer data ) ;
extern void g_async_queue_push_sorted(GAsyncQueue *queue , gpointer data , gint (*func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer user_data ) ;
extern void g_async_queue_push_sorted_unlocked(GAsyncQueue *queue , gpointer data , gint (*func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer user_data ) ;
extern gpointer g_async_queue_pop(GAsyncQueue *queue ) ;
extern gpointer g_async_queue_pop_unlocked(GAsyncQueue *queue ) ;
extern gpointer g_async_queue_try_pop(GAsyncQueue *queue ) ;
extern gpointer g_async_queue_try_pop_unlocked(GAsyncQueue *queue ) ;
extern gpointer g_async_queue_timed_pop(GAsyncQueue *queue , GTimeVal *end_time ) ;
extern gpointer g_async_queue_timed_pop_unlocked(GAsyncQueue *queue , GTimeVal *end_time ) ;
extern gint g_async_queue_length(GAsyncQueue *queue ) ;
extern gint g_async_queue_length_unlocked(GAsyncQueue *queue ) ;
extern void g_async_queue_sort(GAsyncQueue *queue , gint (*func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer user_data ) ;
extern void g_async_queue_sort_unlocked(GAsyncQueue *queue , gint (*func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer user_data ) ;
extern GMutex *_g_async_queue_get_mutex(GAsyncQueue *queue ) ;
__inline extern int __attribute__((__gnu_inline__))  __sigismember(__sigset_t const   *__set , int __sig ) ;
__inline extern int __attribute__((__gnu_inline__))  __sigaddset(__sigset_t *__set , int __sig ) ;
__inline extern int __attribute__((__gnu_inline__))  __sigdelset(__sigset_t *__set , int __sig ) ;
__inline extern int __attribute__((__gnu_inline__))  __sigismember(__sigset_t const   *__set , int __sig ) 
{ unsigned long __mask ;
  unsigned long __word ;
  int tmp ;

  {
  __mask = 1UL << (unsigned int )(__sig - 1) % (8U * sizeof(unsigned long ));
  __word = (unsigned long )((unsigned int )(__sig - 1) / (8U * sizeof(unsigned long )));
  if (__set->__val[__word] & __mask) {
    tmp = 1;
  } else {
    tmp = 0;
  }
  return ((int __attribute__((__gnu_inline__))  )tmp);
}
}
__inline extern int __attribute__((__gnu_inline__))  __sigaddset(__sigset_t *__set , int __sig ) 
{ unsigned long __mask ;
  unsigned long __word ;

  {
  __mask = 1UL << (unsigned int )(__sig - 1) % (8U * sizeof(unsigned long ));
  __word = (unsigned long )((unsigned int )(__sig - 1) / (8U * sizeof(unsigned long )));
  __set->__val[__word] |= __mask;
  return ((int __attribute__((__gnu_inline__))  )0);
}
}
__inline extern int __attribute__((__gnu_inline__))  __sigdelset(__sigset_t *__set , int __sig ) 
{ unsigned long __mask ;
  unsigned long __word ;

  {
  __mask = 1UL << (unsigned int )(__sig - 1) % (8U * sizeof(unsigned long ));
  __word = (unsigned long )((unsigned int )(__sig - 1) / (8U * sizeof(unsigned long )));
  __set->__val[__word] &= ~ __mask;
  return ((int __attribute__((__gnu_inline__))  )0);
}
}
extern  __attribute__((__nothrow__)) __sighandler_t __sysv_signal(int __sig , void (*__handler)(int  ) ) ;
extern  __attribute__((__nothrow__)) __sighandler_t signal(int __sig , void (*__handler)(int  ) ) ;
extern  __attribute__((__nothrow__)) int kill(__pid_t __pid , int __sig ) ;
extern  __attribute__((__nothrow__)) int killpg(__pid_t __pgrp , int __sig ) ;
extern  __attribute__((__nothrow__)) int raise(int __sig ) ;
extern  __attribute__((__nothrow__)) __sighandler_t ssignal(int __sig , void (*__handler)(int  ) ) ;
extern  __attribute__((__nothrow__)) int gsignal(int __sig ) ;
extern void psignal(int __sig , char const   *__s ) ;
extern void psiginfo(siginfo_t const   *__pinfo , char const   *__s ) ;
extern int __sigpause(int __sig_or_mask , int __is_sig ) ;
extern  __attribute__((__nothrow__)) int sigblock(int __mask )  __attribute__((__deprecated__)) ;
extern  __attribute__((__nothrow__)) int sigsetmask(int __mask )  __attribute__((__deprecated__)) ;
extern  __attribute__((__nothrow__)) int siggetmask(void)  __attribute__((__deprecated__)) ;
extern  __attribute__((__nothrow__)) int sigemptyset(sigset_t *__set )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int sigfillset(sigset_t *__set )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int sigaddset(sigset_t *__set , int __signo )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int sigdelset(sigset_t *__set , int __signo )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int sigismember(sigset_t const   *__set , int __signo )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int sigprocmask(int __how , sigset_t const   * __restrict  __set , sigset_t * __restrict  __oset ) ;
extern int sigsuspend(sigset_t const   *__set )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int sigaction(int __sig , struct sigaction  const  * __restrict  __act , struct sigaction * __restrict  __oact ) ;
extern  __attribute__((__nothrow__)) int sigpending(sigset_t *__set )  __attribute__((__nonnull__(1))) ;
extern int sigwait(sigset_t const   * __restrict  __set , int * __restrict  __sig )  __attribute__((__nonnull__(1,2))) ;
extern int sigwaitinfo(sigset_t const   * __restrict  __set , siginfo_t * __restrict  __info )  __attribute__((__nonnull__(1))) ;
extern int sigtimedwait(sigset_t const   * __restrict  __set , siginfo_t * __restrict  __info , struct timespec  const  * __restrict  __timeout )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int sigqueue(__pid_t __pid , int __sig , union sigval __val ) ;
extern char const   * const  _sys_siglist[65] ;
extern char const   * const  sys_siglist[65] ;
extern  __attribute__((__nothrow__)) int sigvec(int __sig , struct sigvec  const  *__vec , struct sigvec *__ovec ) ;
extern  __attribute__((__nothrow__)) int sigreturn(struct sigcontext *__scp ) ;
extern  __attribute__((__nothrow__)) int siginterrupt(int __sig , int __interrupt ) ;
extern  __attribute__((__nothrow__)) int sigstack(struct sigstack *__ss , struct sigstack *__oss )  __attribute__((__deprecated__)) ;
extern  __attribute__((__nothrow__)) int sigaltstack(struct sigaltstack  const  * __restrict  __ss , struct sigaltstack * __restrict  __oss ) ;
extern  __attribute__((__nothrow__)) int pthread_sigmask(int __how , __sigset_t const   * __restrict  __newmask , __sigset_t * __restrict  __oldmask ) ;
extern  __attribute__((__nothrow__)) int pthread_kill(pthread_t __threadid , int __signo ) ;
extern  __attribute__((__nothrow__)) int __libc_current_sigrtmin(void) ;
extern  __attribute__((__nothrow__)) int __libc_current_sigrtmax(void) ;
extern void g_on_error_query(gchar const   *prg_name ) ;
extern void g_on_error_stack_trace(gchar const   *prg_name ) ;
extern gsize g_base64_encode_step(guchar const   *in , gsize len , gboolean break_lines , gchar *out , gint *state , gint *save ) ;
extern gsize g_base64_encode_close(gboolean break_lines , gchar *out , gint *state , gint *save ) ;
extern gchar *g_base64_encode(guchar const   *data , gsize len )  __attribute__((__malloc__)) ;
extern gsize g_base64_decode_step(gchar const   *in , gsize len , guchar *out , gint *state , guint *save ) ;
extern guchar *g_base64_decode(gchar const   *text , gsize *out_len )  __attribute__((__malloc__)) ;
extern guchar *g_base64_decode_inplace(gchar *text , gsize *out_len ) ;
extern void g_bit_lock(gint volatile   *address , gint lock_bit ) ;
extern gboolean g_bit_trylock(gint volatile   *address , gint lock_bit ) ;
extern void g_bit_unlock(gint volatile   *address , gint lock_bit ) ;
extern  __attribute__((__nothrow__)) clock_t clock(void) ;
extern  __attribute__((__nothrow__)) time_t time(time_t *__timer ) ;
extern  __attribute__((__nothrow__)) double difftime(time_t __time1 , time_t __time0 )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) time_t mktime(struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) size_t strftime(char * __restrict  __s , size_t __maxsize , char const   * __restrict  __format , struct tm  const  * __restrict  __tp ) ;
extern  __attribute__((__nothrow__)) size_t strftime_l(char * __restrict  __s , size_t __maxsize , char const   * __restrict  __format , struct tm  const  * __restrict  __tp , __locale_t __loc ) ;
extern  __attribute__((__nothrow__)) struct tm *gmtime(time_t const   *__timer ) ;
extern  __attribute__((__nothrow__)) struct tm *localtime(time_t const   *__timer ) ;
extern  __attribute__((__nothrow__)) struct tm *gmtime_r(time_t const   * __restrict  __timer , struct tm * __restrict  __tp ) ;
extern  __attribute__((__nothrow__)) struct tm *localtime_r(time_t const   * __restrict  __timer , struct tm * __restrict  __tp ) ;
extern  __attribute__((__nothrow__)) char *asctime(struct tm  const  *__tp ) ;
extern  __attribute__((__nothrow__)) char *ctime(time_t const   *__timer ) ;
extern  __attribute__((__nothrow__)) char *asctime_r(struct tm  const  * __restrict  __tp , char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) char *ctime_r(time_t const   * __restrict  __timer , char * __restrict  __buf ) ;
extern char *__tzname[2] ;
extern int __daylight ;
extern long __timezone ;
extern char *tzname[2] ;
extern  __attribute__((__nothrow__)) void tzset(void) ;
extern int daylight ;
extern long timezone ;
extern  __attribute__((__nothrow__)) int stime(time_t const   *__when ) ;
extern  __attribute__((__nothrow__)) time_t timegm(struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) time_t timelocal(struct tm *__tp ) ;
extern  __attribute__((__nothrow__)) int dysize(int __year )  __attribute__((__const__)) ;
extern int nanosleep(struct timespec  const  *__requested_time , struct timespec *__remaining ) ;
extern  __attribute__((__nothrow__)) int clock_getres(clockid_t __clock_id , struct timespec *__res ) ;
extern  __attribute__((__nothrow__)) int clock_gettime(clockid_t __clock_id , struct timespec *__tp ) ;
extern  __attribute__((__nothrow__)) int clock_settime(clockid_t __clock_id , struct timespec  const  *__tp ) ;
extern int clock_nanosleep(clockid_t __clock_id , int __flags , struct timespec  const  *__req , struct timespec *__rem ) ;
extern  __attribute__((__nothrow__)) int clock_getcpuclockid(pid_t __pid , clockid_t *__clock_id ) ;
extern  __attribute__((__nothrow__)) int timer_create(clockid_t __clock_id , struct sigevent * __restrict  __evp , timer_t * __restrict  __timerid ) ;
extern  __attribute__((__nothrow__)) int timer_delete(timer_t __timerid ) ;
extern  __attribute__((__nothrow__)) int timer_settime(timer_t __timerid , int __flags , struct itimerspec  const  * __restrict  __value , struct itimerspec * __restrict  __ovalue ) ;
extern  __attribute__((__nothrow__)) int timer_gettime(timer_t __timerid , struct itimerspec *__value ) ;
extern  __attribute__((__nothrow__)) int timer_getoverrun(timer_t __timerid ) ;
extern GQuark g_bookmark_file_error_quark(void) ;
extern GBookmarkFile *g_bookmark_file_new(void) ;
extern void g_bookmark_file_free(GBookmarkFile *bookmark ) ;
extern gboolean g_bookmark_file_load_from_file(GBookmarkFile *bookmark , gchar const   *filename , GError **error ) ;
extern gboolean g_bookmark_file_load_from_data(GBookmarkFile *bookmark , gchar const   *data , gsize length , GError **error ) ;
extern gboolean g_bookmark_file_load_from_data_dirs(GBookmarkFile *bookmark , gchar const   *file , gchar **full_path , GError **error ) ;
extern gchar *g_bookmark_file_to_data(GBookmarkFile *bookmark , gsize *length , GError **error )  __attribute__((__malloc__)) ;
extern gboolean g_bookmark_file_to_file(GBookmarkFile *bookmark , gchar const   *filename , GError **error ) ;
extern void g_bookmark_file_set_title(GBookmarkFile *bookmark , gchar const   *uri , gchar const   *title ) ;
extern gchar *g_bookmark_file_get_title(GBookmarkFile *bookmark , gchar const   *uri , GError **error )  __attribute__((__malloc__)) ;
extern void g_bookmark_file_set_description(GBookmarkFile *bookmark , gchar const   *uri , gchar const   *description ) ;
extern gchar *g_bookmark_file_get_description(GBookmarkFile *bookmark , gchar const   *uri , GError **error )  __attribute__((__malloc__)) ;
extern void g_bookmark_file_set_mime_type(GBookmarkFile *bookmark , gchar const   *uri , gchar const   *mime_type ) ;
extern gchar *g_bookmark_file_get_mime_type(GBookmarkFile *bookmark , gchar const   *uri , GError **error )  __attribute__((__malloc__)) ;
extern void g_bookmark_file_set_groups(GBookmarkFile *bookmark , gchar const   *uri , gchar const   **groups , gsize length ) ;
extern void g_bookmark_file_add_group(GBookmarkFile *bookmark , gchar const   *uri , gchar const   *group ) ;
extern gboolean g_bookmark_file_has_group(GBookmarkFile *bookmark , gchar const   *uri , gchar const   *group , GError **error ) ;
extern gchar **g_bookmark_file_get_groups(GBookmarkFile *bookmark , gchar const   *uri , gsize *length , GError **error )  __attribute__((__malloc__)) ;
extern void g_bookmark_file_add_application(GBookmarkFile *bookmark , gchar const   *uri , gchar const   *name , gchar const   *exec ) ;
extern gboolean g_bookmark_file_has_application(GBookmarkFile *bookmark , gchar const   *uri , gchar const   *name , GError **error ) ;
extern gchar **g_bookmark_file_get_applications(GBookmarkFile *bookmark , gchar const   *uri , gsize *length , GError **error )  __attribute__((__malloc__)) ;
extern gboolean g_bookmark_file_set_app_info(GBookmarkFile *bookmark , gchar const   *uri , gchar const   *name , gchar const   *exec , gint count , time_t stamp , GError **error ) ;
extern gboolean g_bookmark_file_get_app_info(GBookmarkFile *bookmark , gchar const   *uri , gchar const   *name , gchar **exec , guint *count , time_t *stamp , GError **error ) ;
extern void g_bookmark_file_set_is_private(GBookmarkFile *bookmark , gchar const   *uri , gboolean is_private ) ;
extern gboolean g_bookmark_file_get_is_private(GBookmarkFile *bookmark , gchar const   *uri , GError **error ) ;
extern void g_bookmark_file_set_icon(GBookmarkFile *bookmark , gchar const   *uri , gchar const   *href , gchar const   *mime_type ) ;
extern gboolean g_bookmark_file_get_icon(GBookmarkFile *bookmark , gchar const   *uri , gchar **href , gchar **mime_type , GError **error ) ;
extern void g_bookmark_file_set_added(GBookmarkFile *bookmark , gchar const   *uri , time_t added ) ;
extern time_t g_bookmark_file_get_added(GBookmarkFile *bookmark , gchar const   *uri , GError **error ) ;
extern void g_bookmark_file_set_modified(GBookmarkFile *bookmark , gchar const   *uri , time_t modified ) ;
extern time_t g_bookmark_file_get_modified(GBookmarkFile *bookmark , gchar const   *uri , GError **error ) ;
extern void g_bookmark_file_set_visited(GBookmarkFile *bookmark , gchar const   *uri , time_t visited ) ;
extern time_t g_bookmark_file_get_visited(GBookmarkFile *bookmark , gchar const   *uri , GError **error ) ;
extern gboolean g_bookmark_file_has_item(GBookmarkFile *bookmark , gchar const   *uri ) ;
extern gint g_bookmark_file_get_size(GBookmarkFile *bookmark ) ;
extern gchar **g_bookmark_file_get_uris(GBookmarkFile *bookmark , gsize *length )  __attribute__((__malloc__)) ;
extern gboolean g_bookmark_file_remove_group(GBookmarkFile *bookmark , gchar const   *uri , gchar const   *group , GError **error ) ;
extern gboolean g_bookmark_file_remove_application(GBookmarkFile *bookmark , gchar const   *uri , gchar const   *name , GError **error ) ;
extern gboolean g_bookmark_file_remove_item(GBookmarkFile *bookmark , gchar const   *uri , GError **error ) ;
extern gboolean g_bookmark_file_move_item(GBookmarkFile *bookmark , gchar const   *old_uri , gchar const   *new_uri , GError **error ) ;
extern gpointer g_slice_alloc(gsize block_size )  __attribute__((__malloc__, __alloc_size__(1))) ;
extern gpointer g_slice_alloc0(gsize block_size )  __attribute__((__malloc__, __alloc_size__(1))) ;
extern gpointer g_slice_copy(gsize block_size , gconstpointer mem_block )  __attribute__((__malloc__, __alloc_size__(1))) ;
extern void g_slice_free1(gsize block_size , gpointer mem_block ) ;
extern void g_slice_free_chain_with_offset(gsize block_size , gpointer mem_chain , gsize next_offset ) ;
extern void g_slice_set_config(GSliceConfig ckey , gint64 value ) ;
extern gint64 g_slice_get_config(GSliceConfig ckey ) ;
extern gint64 *g_slice_get_config_state(GSliceConfig ckey , gint64 address , guint *n_values ) ;
extern void g_free(gpointer mem ) ;
extern gpointer g_malloc(gsize n_bytes )  __attribute__((__malloc__, __alloc_size__(1))) ;
extern gpointer g_malloc0(gsize n_bytes )  __attribute__((__malloc__, __alloc_size__(1))) ;
extern gpointer g_realloc(gpointer mem , gsize n_bytes )  __attribute__((__warn_unused_result__)) ;
extern gpointer g_try_malloc(gsize n_bytes )  __attribute__((__malloc__, __alloc_size__(1))) ;
extern gpointer g_try_malloc0(gsize n_bytes )  __attribute__((__malloc__, __alloc_size__(1))) ;
extern gpointer g_try_realloc(gpointer mem , gsize n_bytes )  __attribute__((__warn_unused_result__)) ;
extern gpointer g_malloc_n(gsize n_blocks , gsize n_block_bytes )  __attribute__((__malloc__, __alloc_size__(1,2))) ;
extern gpointer g_malloc0_n(gsize n_blocks , gsize n_block_bytes )  __attribute__((__malloc__, __alloc_size__(1,2))) ;
extern gpointer g_realloc_n(gpointer mem , gsize n_blocks , gsize n_block_bytes )  __attribute__((__warn_unused_result__)) ;
extern gpointer g_try_malloc_n(gsize n_blocks , gsize n_block_bytes )  __attribute__((__malloc__, __alloc_size__(1,2))) ;
extern gpointer g_try_malloc0_n(gsize n_blocks , gsize n_block_bytes )  __attribute__((__malloc__, __alloc_size__(1,2))) ;
extern gpointer g_try_realloc_n(gpointer mem , gsize n_blocks , gsize n_block_bytes )  __attribute__((__warn_unused_result__)) ;
extern void g_mem_set_vtable(GMemVTable *vtable ) ;
extern gboolean g_mem_is_system_malloc(void) ;
extern gboolean g_mem_gc_friendly ;
extern GMemVTable *glib_mem_profiler_table ;
extern void g_mem_profile(void) ;
extern GMemChunk *g_mem_chunk_new(gchar const   *name , gint atom_size , gsize area_size , gint type ) ;
extern void g_mem_chunk_destroy(GMemChunk *mem_chunk ) ;
extern gpointer g_mem_chunk_alloc(GMemChunk *mem_chunk ) ;
extern gpointer g_mem_chunk_alloc0(GMemChunk *mem_chunk ) ;
extern void g_mem_chunk_free(GMemChunk *mem_chunk , gpointer mem ) ;
extern void g_mem_chunk_clean(GMemChunk *mem_chunk ) ;
extern void g_mem_chunk_reset(GMemChunk *mem_chunk ) ;
extern void g_mem_chunk_print(GMemChunk *mem_chunk ) ;
extern void g_mem_chunk_info(void) ;
extern void g_blow_chunks(void) ;
extern GAllocator *g_allocator_new(gchar const   *name , guint n_preallocs ) ;
extern void g_allocator_free(GAllocator *allocator ) ;
extern GList *g_list_alloc(void)  __attribute__((__warn_unused_result__)) ;
extern void g_list_free(GList *list ) ;
extern void g_list_free_1(GList *list ) ;
extern GList *g_list_append(GList *list , gpointer data )  __attribute__((__warn_unused_result__)) ;
extern GList *g_list_prepend(GList *list , gpointer data )  __attribute__((__warn_unused_result__)) ;
extern GList *g_list_insert(GList *list , gpointer data , gint position )  __attribute__((__warn_unused_result__)) ;
extern GList *g_list_insert_sorted(GList *list , gpointer data , gint (*func)(gconstpointer a , gconstpointer b ) )  __attribute__((__warn_unused_result__)) ;
extern GList *g_list_insert_sorted_with_data(GList *list , gpointer data , gint (*func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer user_data )  __attribute__((__warn_unused_result__)) ;
extern GList *g_list_insert_before(GList *list , GList *sibling , gpointer data )  __attribute__((__warn_unused_result__)) ;
extern GList *g_list_concat(GList *list1 , GList *list2 )  __attribute__((__warn_unused_result__)) ;
extern GList *g_list_remove(GList *list , gconstpointer data )  __attribute__((__warn_unused_result__)) ;
extern GList *g_list_remove_all(GList *list , gconstpointer data )  __attribute__((__warn_unused_result__)) ;
extern GList *g_list_remove_link(GList *list , GList *llink )  __attribute__((__warn_unused_result__)) ;
extern GList *g_list_delete_link(GList *list , GList *link_ )  __attribute__((__warn_unused_result__)) ;
extern GList *g_list_reverse(GList *list )  __attribute__((__warn_unused_result__)) ;
extern GList *g_list_copy(GList *list )  __attribute__((__warn_unused_result__)) ;
extern GList *g_list_nth(GList *list , guint n ) ;
extern GList *g_list_nth_prev(GList *list , guint n ) ;
extern GList *g_list_find(GList *list , gconstpointer data ) ;
extern GList *g_list_find_custom(GList *list , gconstpointer data , gint (*func)(gconstpointer a , gconstpointer b ) ) ;
extern gint g_list_position(GList *list , GList *llink ) ;
extern gint g_list_index(GList *list , gconstpointer data ) ;
extern GList *g_list_last(GList *list ) ;
extern GList *g_list_first(GList *list ) ;
extern guint g_list_length(GList *list ) ;
extern void g_list_foreach(GList *list , void (*func)(gpointer data , gpointer user_data ) , gpointer user_data ) ;
extern GList *g_list_sort(GList *list , gint (*compare_func)(gconstpointer a , gconstpointer b ) )  __attribute__((__warn_unused_result__)) ;
extern GList *g_list_sort_with_data(GList *list , gint (*compare_func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer user_data )  __attribute__((__warn_unused_result__)) ;
extern gpointer g_list_nth_data(GList *list , guint n ) ;
extern void g_list_push_allocator(gpointer allocator ) ;
extern void g_list_pop_allocator(void) ;
extern GCache *g_cache_new(gpointer (*value_new_func)(gpointer key ) , void (*value_destroy_func)(gpointer value ) , gpointer (*key_dup_func)(gpointer value ) , void (*key_destroy_func)(gpointer value ) , guint (*hash_key_func)(gconstpointer key ) , guint (*hash_value_func)(gconstpointer key ) , gboolean (*key_equal_func)(gconstpointer a , gconstpointer b ) ) ;
extern void g_cache_destroy(GCache *cache ) ;
extern gpointer g_cache_insert(GCache *cache , gpointer key ) ;
extern void g_cache_remove(GCache *cache , gconstpointer value ) ;
extern void g_cache_key_foreach(GCache *cache , void (*func)(gpointer key , gpointer value , gpointer user_data ) , gpointer user_data ) ;
extern void g_cache_value_foreach(GCache *cache , void (*func)(gpointer key , gpointer value , gpointer user_data ) , gpointer user_data ) ;
extern gssize g_checksum_type_get_length(GChecksumType checksum_type ) ;
extern GChecksum *g_checksum_new(GChecksumType checksum_type ) ;
extern void g_checksum_reset(GChecksum *checksum ) ;
extern GChecksum *g_checksum_copy(GChecksum const   *checksum ) ;
extern void g_checksum_free(GChecksum *checksum ) ;
extern void g_checksum_update(GChecksum *checksum , guchar const   *data , gssize length ) ;
extern gchar const   *g_checksum_get_string(GChecksum *checksum ) ;
extern void g_checksum_get_digest(GChecksum *checksum , guint8 *buffer , gsize *digest_len ) ;
extern gchar *g_compute_checksum_for_data(GChecksumType checksum_type , guchar const   *data , gsize length ) ;
extern gchar *g_compute_checksum_for_string(GChecksumType checksum_type , gchar const   *str , gssize length ) ;
extern GCompletion *g_completion_new(gchar *(*func)(gpointer  ) ) ;
extern void g_completion_add_items(GCompletion *cmp , GList *items ) ;
extern void g_completion_remove_items(GCompletion *cmp , GList *items ) ;
extern void g_completion_clear_items(GCompletion *cmp ) ;
extern GList *g_completion_complete(GCompletion *cmp , gchar const   *prefix , gchar **new_prefix ) ;
extern GList *g_completion_complete_utf8(GCompletion *cmp , gchar const   *prefix , gchar **new_prefix ) ;
extern void g_completion_set_compare(GCompletion *cmp , gint (*strncmp_func)(gchar const   *s1 , gchar const   *s2 , gsize n ) ) ;
extern void g_completion_free(GCompletion *cmp ) ;
extern GQuark g_convert_error_quark(void) ;
extern GIConv g_iconv_open(gchar const   *to_codeset , gchar const   *from_codeset ) ;
extern gsize g_iconv(GIConv converter , gchar **inbuf , gsize *inbytes_left , gchar **outbuf , gsize *outbytes_left ) ;
extern gint g_iconv_close(GIConv converter ) ;
extern gchar *g_convert(gchar const   *str , gssize len , gchar const   *to_codeset , gchar const   *from_codeset , gsize *bytes_read , gsize *bytes_written , GError **error )  __attribute__((__malloc__)) ;
extern gchar *g_convert_with_iconv(gchar const   *str , gssize len , GIConv converter , gsize *bytes_read , gsize *bytes_written , GError **error )  __attribute__((__malloc__)) ;
extern gchar *g_convert_with_fallback(gchar const   *str , gssize len , gchar const   *to_codeset , gchar const   *from_codeset , gchar const   *fallback , gsize *bytes_read , gsize *bytes_written , GError **error )  __attribute__((__malloc__)) ;
extern gchar *g_locale_to_utf8(gchar const   *opsysstring , gssize len , gsize *bytes_read , gsize *bytes_written , GError **error )  __attribute__((__malloc__)) ;
extern gchar *g_locale_from_utf8(gchar const   *utf8string , gssize len , gsize *bytes_read , gsize *bytes_written , GError **error )  __attribute__((__malloc__)) ;
extern gchar *g_filename_to_utf8(gchar const   *opsysstring , gssize len , gsize *bytes_read , gsize *bytes_written , GError **error )  __attribute__((__malloc__)) ;
extern gchar *g_filename_from_utf8(gchar const   *utf8string , gssize len , gsize *bytes_read , gsize *bytes_written , GError **error )  __attribute__((__malloc__)) ;
extern gchar *g_filename_from_uri(gchar const   *uri , gchar **hostname , GError **error )  __attribute__((__malloc__)) ;
extern gchar *g_filename_to_uri(gchar const   *filename , gchar const   *hostname , GError **error )  __attribute__((__malloc__)) ;
extern gchar *g_filename_display_name(gchar const   *filename )  __attribute__((__malloc__)) ;
extern gboolean g_get_filename_charsets(gchar const   ***charsets ) ;
extern gchar *g_filename_display_basename(gchar const   *filename )  __attribute__((__malloc__)) ;
extern gchar **g_uri_list_extract_uris(gchar const   *uri_list )  __attribute__((__malloc__)) ;
extern void g_datalist_init(GData **datalist ) ;
extern void g_datalist_clear(GData **datalist ) ;
extern gpointer g_datalist_id_get_data(GData **datalist , GQuark key_id ) ;
extern void g_datalist_id_set_data_full(GData **datalist , GQuark key_id , gpointer data , void (*destroy_func)(gpointer data ) ) ;
extern gpointer g_datalist_id_remove_no_notify(GData **datalist , GQuark key_id ) ;
extern void g_datalist_foreach(GData **datalist , void (*func)(GQuark key_id , gpointer data , gpointer user_data ) , gpointer user_data ) ;
extern void g_datalist_set_flags(GData **datalist , guint flags ) ;
extern void g_datalist_unset_flags(GData **datalist , guint flags ) ;
extern guint g_datalist_get_flags(GData **datalist ) ;
extern void g_dataset_destroy(gconstpointer dataset_location ) ;
extern gpointer g_dataset_id_get_data(gconstpointer dataset_location , GQuark key_id ) ;
extern void g_dataset_id_set_data_full(gconstpointer dataset_location , GQuark key_id , gpointer data , void (*destroy_func)(gpointer data ) ) ;
extern gpointer g_dataset_id_remove_no_notify(gconstpointer dataset_location , GQuark key_id ) ;
extern void g_dataset_foreach(gconstpointer dataset_location , void (*func)(GQuark key_id , gpointer data , gpointer user_data ) , gpointer user_data ) ;
extern GDate *g_date_new(void) ;
extern GDate *g_date_new_dmy(GDateDay day , GDateMonth month , GDateYear year ) ;
extern GDate *g_date_new_julian(guint32 julian_day ) ;
extern void g_date_free(GDate *date ) ;
extern gboolean g_date_valid(GDate const   *date ) ;
extern gboolean g_date_valid_day(GDateDay day )  __attribute__((__const__)) ;
extern gboolean g_date_valid_month(GDateMonth month )  __attribute__((__const__)) ;
extern gboolean g_date_valid_year(GDateYear year )  __attribute__((__const__)) ;
extern gboolean g_date_valid_weekday(GDateWeekday weekday )  __attribute__((__const__)) ;
extern gboolean g_date_valid_julian(guint32 julian_date )  __attribute__((__const__)) ;
extern gboolean g_date_valid_dmy(GDateDay day , GDateMonth month , GDateYear year )  __attribute__((__const__)) ;
extern GDateWeekday g_date_get_weekday(GDate const   *date ) ;
extern GDateMonth g_date_get_month(GDate const   *date ) ;
extern GDateYear g_date_get_year(GDate const   *date ) ;
extern GDateDay g_date_get_day(GDate const   *date ) ;
extern guint32 g_date_get_julian(GDate const   *date ) ;
extern guint g_date_get_day_of_year(GDate const   *date ) ;
extern guint g_date_get_monday_week_of_year(GDate const   *date ) ;
extern guint g_date_get_sunday_week_of_year(GDate const   *date ) ;
extern guint g_date_get_iso8601_week_of_year(GDate const   *date ) ;
extern void g_date_clear(GDate *date , guint n_dates ) ;
extern void g_date_set_parse(GDate *date , gchar const   *str ) ;
extern void g_date_set_time_t(GDate *date , time_t timet ) ;
extern void g_date_set_time_val(GDate *date , GTimeVal *timeval ) ;
extern void g_date_set_time(GDate *date , GTime time_ ) ;
extern void g_date_set_month(GDate *date , GDateMonth month ) ;
extern void g_date_set_day(GDate *date , GDateDay day ) ;
extern void g_date_set_year(GDate *date , GDateYear year ) ;
extern void g_date_set_dmy(GDate *date , GDateDay day , GDateMonth month , GDateYear y ) ;
extern void g_date_set_julian(GDate *date , guint32 julian_date ) ;
extern gboolean g_date_is_first_of_month(GDate const   *date ) ;
extern gboolean g_date_is_last_of_month(GDate const   *date ) ;
extern void g_date_add_days(GDate *date , guint n_days ) ;
extern void g_date_subtract_days(GDate *date , guint n_days ) ;
extern void g_date_add_months(GDate *date , guint n_months ) ;
extern void g_date_subtract_months(GDate *date , guint n_months ) ;
extern void g_date_add_years(GDate *date , guint n_years ) ;
extern void g_date_subtract_years(GDate *date , guint n_years ) ;
extern gboolean g_date_is_leap_year(GDateYear year )  __attribute__((__const__)) ;
extern guint8 g_date_get_days_in_month(GDateMonth month , GDateYear year )  __attribute__((__const__)) ;
extern guint8 g_date_get_monday_weeks_in_year(GDateYear year )  __attribute__((__const__)) ;
extern guint8 g_date_get_sunday_weeks_in_year(GDateYear year )  __attribute__((__const__)) ;
extern gint g_date_days_between(GDate const   *date1 , GDate const   *date2 ) ;
extern gint g_date_compare(GDate const   *lhs , GDate const   *rhs ) ;
extern void g_date_to_struct_tm(GDate const   *date , struct tm *tm ) ;
extern void g_date_clamp(GDate *date , GDate const   *min_date , GDate const   *max_date ) ;
extern void g_date_order(GDate *date1 , GDate *date2 ) ;
extern gsize g_date_strftime(gchar *s , gsize slen , gchar const   *format , GDate const   *date ) ;
extern GDir *g_dir_open(gchar const   *path , guint flags , GError **error ) ;
extern gchar const   *g_dir_read_name(GDir *dir ) ;
extern void g_dir_rewind(GDir *dir ) ;
extern void g_dir_close(GDir *dir ) ;
extern GQuark g_file_error_quark(void) ;
extern GFileError g_file_error_from_errno(gint err_no ) ;
extern gboolean g_file_test(gchar const   *filename , GFileTest test ) ;
extern gboolean g_file_get_contents(gchar const   *filename , gchar **contents , gsize *length , GError **error ) ;
extern gboolean g_file_set_contents(gchar const   *filename , gchar const   *contents , gssize length , GError **error ) ;
extern gchar *g_file_read_link(gchar const   *filename , GError **error ) ;
extern gint g_mkstemp(gchar *tmpl ) ;
extern gint g_mkstemp_full(gchar *tmpl , int flags , int mode ) ;
extern gint g_file_open_tmp(gchar const   *tmpl , gchar **name_used , GError **error ) ;
extern char *g_format_size_for_display(goffset size ) ;
extern gchar *g_build_path(gchar const   *separator , gchar const   *first_element  , ...)  __attribute__((__sentinel__, __malloc__)) ;
extern gchar *g_build_pathv(gchar const   *separator , gchar **args )  __attribute__((__malloc__)) ;
extern gchar *g_build_filename(gchar const   *first_element  , ...)  __attribute__((__sentinel__, __malloc__)) ;
extern gchar *g_build_filenamev(gchar **args )  __attribute__((__malloc__)) ;
extern int g_mkdir_with_parents(gchar const   *pathname , int mode ) ;
extern GHashTable *g_hash_table_new(guint (*hash_func)(gconstpointer key ) , gboolean (*key_equal_func)(gconstpointer a , gconstpointer b ) ) ;
extern GHashTable *g_hash_table_new_full(guint (*hash_func)(gconstpointer key ) , gboolean (*key_equal_func)(gconstpointer a , gconstpointer b ) , void (*key_destroy_func)(gpointer data ) , void (*value_destroy_func)(gpointer data ) ) ;
extern void g_hash_table_destroy(GHashTable *hash_table ) ;
extern void g_hash_table_insert(GHashTable *hash_table , gpointer key , gpointer value ) ;
extern void g_hash_table_replace(GHashTable *hash_table , gpointer key , gpointer value ) ;
extern gboolean g_hash_table_remove(GHashTable *hash_table , gconstpointer key ) ;
extern void g_hash_table_remove_all(GHashTable *hash_table ) ;
extern gboolean g_hash_table_steal(GHashTable *hash_table , gconstpointer key ) ;
extern void g_hash_table_steal_all(GHashTable *hash_table ) ;
extern gpointer g_hash_table_lookup(GHashTable *hash_table , gconstpointer key ) ;
extern gboolean g_hash_table_lookup_extended(GHashTable *hash_table , gconstpointer lookup_key , gpointer *orig_key , gpointer *value ) ;
extern void g_hash_table_foreach(GHashTable *hash_table , void (*func)(gpointer key , gpointer value , gpointer user_data ) , gpointer user_data ) ;
extern gpointer g_hash_table_find(GHashTable *hash_table , gboolean (*predicate)(gpointer key , gpointer value , gpointer user_data ) , gpointer user_data ) ;
extern guint g_hash_table_foreach_remove(GHashTable *hash_table , gboolean (*func)(gpointer key , gpointer value , gpointer user_data ) , gpointer user_data ) ;
extern guint g_hash_table_foreach_steal(GHashTable *hash_table , gboolean (*func)(gpointer key , gpointer value , gpointer user_data ) , gpointer user_data ) ;
extern guint g_hash_table_size(GHashTable *hash_table ) ;
extern GList *g_hash_table_get_keys(GHashTable *hash_table ) ;
extern GList *g_hash_table_get_values(GHashTable *hash_table ) ;
extern void g_hash_table_iter_init(GHashTableIter *iter , GHashTable *hash_table ) ;
extern gboolean g_hash_table_iter_next(GHashTableIter *iter , gpointer *key , gpointer *value ) ;
extern GHashTable *g_hash_table_iter_get_hash_table(GHashTableIter *iter ) ;
extern void g_hash_table_iter_remove(GHashTableIter *iter ) ;
extern void g_hash_table_iter_steal(GHashTableIter *iter ) ;
extern GHashTable *g_hash_table_ref(GHashTable *hash_table ) ;
extern void g_hash_table_unref(GHashTable *hash_table ) ;
extern gboolean g_str_equal(gconstpointer v1 , gconstpointer v2 ) ;
extern guint g_str_hash(gconstpointer v ) ;
extern gboolean g_int_equal(gconstpointer v1 , gconstpointer v2 ) ;
extern guint g_int_hash(gconstpointer v ) ;
extern gboolean g_int64_equal(gconstpointer v1 , gconstpointer v2 ) ;
extern guint g_int64_hash(gconstpointer v ) ;
extern gboolean g_double_equal(gconstpointer v1 , gconstpointer v2 ) ;
extern guint g_double_hash(gconstpointer v ) ;
extern guint g_direct_hash(gconstpointer v )  __attribute__((__const__)) ;
extern gboolean g_direct_equal(gconstpointer v1 , gconstpointer v2 )  __attribute__((__const__)) ;
extern void g_hook_list_init(GHookList *hook_list , guint hook_size ) ;
extern void g_hook_list_clear(GHookList *hook_list ) ;
extern GHook *g_hook_alloc(GHookList *hook_list ) ;
extern void g_hook_free(GHookList *hook_list , GHook *hook ) ;
extern GHook *g_hook_ref(GHookList *hook_list , GHook *hook ) ;
extern void g_hook_unref(GHookList *hook_list , GHook *hook ) ;
extern gboolean g_hook_destroy(GHookList *hook_list , gulong hook_id ) ;
extern void g_hook_destroy_link(GHookList *hook_list , GHook *hook ) ;
extern void g_hook_prepend(GHookList *hook_list , GHook *hook ) ;
extern void g_hook_insert_before(GHookList *hook_list , GHook *sibling , GHook *hook ) ;
extern void g_hook_insert_sorted(GHookList *hook_list , GHook *hook , gint (*func)(GHook *new_hook , GHook *sibling ) ) ;
extern GHook *g_hook_get(GHookList *hook_list , gulong hook_id ) ;
extern GHook *g_hook_find(GHookList *hook_list , gboolean need_valids , gboolean (*func)(GHook *hook , gpointer data ) , gpointer data ) ;
extern GHook *g_hook_find_data(GHookList *hook_list , gboolean need_valids , gpointer data ) ;
extern GHook *g_hook_find_func(GHookList *hook_list , gboolean need_valids , gpointer func ) ;
extern GHook *g_hook_find_func_data(GHookList *hook_list , gboolean need_valids , gpointer func , gpointer data ) ;
extern GHook *g_hook_first_valid(GHookList *hook_list , gboolean may_be_in_call ) ;
extern GHook *g_hook_next_valid(GHookList *hook_list , GHook *hook , gboolean may_be_in_call ) ;
extern gint g_hook_compare_ids(GHook *new_hook , GHook *sibling ) ;
extern void g_hook_list_invoke(GHookList *hook_list , gboolean may_recurse ) ;
extern void g_hook_list_invoke_check(GHookList *hook_list , gboolean may_recurse ) ;
extern void g_hook_list_marshal(GHookList *hook_list , gboolean may_recurse , void (*marshaller)(GHook *hook , gpointer marshal_data ) , gpointer marshal_data ) ;
extern void g_hook_list_marshal_check(GHookList *hook_list , gboolean may_recurse , gboolean (*marshaller)(GHook *hook , gpointer marshal_data ) , gpointer marshal_data ) ;
extern gboolean g_hostname_is_non_ascii(gchar const   *hostname ) ;
extern gboolean g_hostname_is_ascii_encoded(gchar const   *hostname ) ;
extern gboolean g_hostname_is_ip_address(gchar const   *hostname ) ;
extern gchar *g_hostname_to_ascii(gchar const   *hostname ) ;
extern gchar *g_hostname_to_unicode(gchar const   *hostname ) ;
extern gint g_poll(GPollFD *fds , guint nfds , gint timeout ) ;
extern GSList *g_slist_alloc(void)  __attribute__((__warn_unused_result__)) ;
extern void g_slist_free(GSList *list ) ;
extern void g_slist_free_1(GSList *list ) ;
extern GSList *g_slist_append(GSList *list , gpointer data )  __attribute__((__warn_unused_result__)) ;
extern GSList *g_slist_prepend(GSList *list , gpointer data )  __attribute__((__warn_unused_result__)) ;
extern GSList *g_slist_insert(GSList *list , gpointer data , gint position )  __attribute__((__warn_unused_result__)) ;
extern GSList *g_slist_insert_sorted(GSList *list , gpointer data , gint (*func)(gconstpointer a , gconstpointer b ) )  __attribute__((__warn_unused_result__)) ;
extern GSList *g_slist_insert_sorted_with_data(GSList *list , gpointer data , gint (*func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer user_data )  __attribute__((__warn_unused_result__)) ;
extern GSList *g_slist_insert_before(GSList *slist , GSList *sibling , gpointer data )  __attribute__((__warn_unused_result__)) ;
extern GSList *g_slist_concat(GSList *list1 , GSList *list2 )  __attribute__((__warn_unused_result__)) ;
extern GSList *g_slist_remove(GSList *list , gconstpointer data )  __attribute__((__warn_unused_result__)) ;
extern GSList *g_slist_remove_all(GSList *list , gconstpointer data )  __attribute__((__warn_unused_result__)) ;
extern GSList *g_slist_remove_link(GSList *list , GSList *link_ )  __attribute__((__warn_unused_result__)) ;
extern GSList *g_slist_delete_link(GSList *list , GSList *link_ )  __attribute__((__warn_unused_result__)) ;
extern GSList *g_slist_reverse(GSList *list )  __attribute__((__warn_unused_result__)) ;
extern GSList *g_slist_copy(GSList *list )  __attribute__((__warn_unused_result__)) ;
extern GSList *g_slist_nth(GSList *list , guint n ) ;
extern GSList *g_slist_find(GSList *list , gconstpointer data ) ;
extern GSList *g_slist_find_custom(GSList *list , gconstpointer data , gint (*func)(gconstpointer a , gconstpointer b ) ) ;
extern gint g_slist_position(GSList *list , GSList *llink ) ;
extern gint g_slist_index(GSList *list , gconstpointer data ) ;
extern GSList *g_slist_last(GSList *list ) ;
extern guint g_slist_length(GSList *list ) ;
extern void g_slist_foreach(GSList *list , void (*func)(gpointer data , gpointer user_data ) , gpointer user_data ) ;
extern GSList *g_slist_sort(GSList *list , gint (*compare_func)(gconstpointer a , gconstpointer b ) )  __attribute__((__warn_unused_result__)) ;
extern GSList *g_slist_sort_with_data(GSList *list , gint (*compare_func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer user_data )  __attribute__((__warn_unused_result__)) ;
extern gpointer g_slist_nth_data(GSList *list , guint n ) ;
extern void g_slist_push_allocator(gpointer dummy ) ;
extern void g_slist_pop_allocator(void) ;
extern GMainContext *g_main_context_new(void) ;
extern GMainContext *g_main_context_ref(GMainContext *context ) ;
extern void g_main_context_unref(GMainContext *context ) ;
extern GMainContext *g_main_context_default(void) ;
extern gboolean g_main_context_iteration(GMainContext *context , gboolean may_block ) ;
extern gboolean g_main_context_pending(GMainContext *context ) ;
extern GSource *g_main_context_find_source_by_id(GMainContext *context , guint source_id ) ;
extern GSource *g_main_context_find_source_by_user_data(GMainContext *context , gpointer user_data ) ;
extern GSource *g_main_context_find_source_by_funcs_user_data(GMainContext *context , GSourceFuncs *funcs , gpointer user_data ) ;
extern void g_main_context_wakeup(GMainContext *context ) ;
extern gboolean g_main_context_acquire(GMainContext *context ) ;
extern void g_main_context_release(GMainContext *context ) ;
extern gboolean g_main_context_is_owner(GMainContext *context ) ;
extern gboolean g_main_context_wait(GMainContext *context , GCond *cond , GMutex *mutex ) ;
extern gboolean g_main_context_prepare(GMainContext *context , gint *priority ) ;
extern gint g_main_context_query(GMainContext *context , gint max_priority , gint *timeout_ , GPollFD *fds , gint n_fds ) ;
extern gint g_main_context_check(GMainContext *context , gint max_priority , GPollFD *fds , gint n_fds ) ;
extern void g_main_context_dispatch(GMainContext *context ) ;
extern void g_main_context_set_poll_func(GMainContext *context , gint (*func)(GPollFD *ufds , guint nfsd , gint timeout_ ) ) ;
extern GPollFunc g_main_context_get_poll_func(GMainContext *context ) ;
extern void g_main_context_add_poll(GMainContext *context , GPollFD *fd , gint priority ) ;
extern void g_main_context_remove_poll(GMainContext *context , GPollFD *fd ) ;
extern gint g_main_depth(void) ;
extern GSource *g_main_current_source(void) ;
extern void g_main_context_push_thread_default(GMainContext *context ) ;
extern void g_main_context_pop_thread_default(GMainContext *context ) ;
extern GMainContext *g_main_context_get_thread_default(void) ;
extern GMainLoop *g_main_loop_new(GMainContext *context , gboolean is_running ) ;
extern void g_main_loop_run(GMainLoop *loop ) ;
extern void g_main_loop_quit(GMainLoop *loop ) ;
extern GMainLoop *g_main_loop_ref(GMainLoop *loop ) ;
extern void g_main_loop_unref(GMainLoop *loop ) ;
extern gboolean g_main_loop_is_running(GMainLoop *loop ) ;
extern GMainContext *g_main_loop_get_context(GMainLoop *loop ) ;
extern GSource *g_source_new(GSourceFuncs *source_funcs , guint struct_size ) ;
extern GSource *g_source_ref(GSource *source ) ;
extern void g_source_unref(GSource *source ) ;
extern guint g_source_attach(GSource *source , GMainContext *context ) ;
extern void g_source_destroy(GSource *source ) ;
extern void g_source_set_priority(GSource *source , gint priority ) ;
extern gint g_source_get_priority(GSource *source ) ;
extern void g_source_set_can_recurse(GSource *source , gboolean can_recurse ) ;
extern gboolean g_source_get_can_recurse(GSource *source ) ;
extern guint g_source_get_id(GSource *source ) ;
extern GMainContext *g_source_get_context(GSource *source ) ;
extern void g_source_set_callback(GSource *source , gboolean (*func)(gpointer data ) , gpointer data , void (*notify)(gpointer data ) ) ;
extern void g_source_set_funcs(GSource *source , GSourceFuncs *funcs ) ;
extern gboolean g_source_is_destroyed(GSource *source ) ;
extern void g_source_set_callback_indirect(GSource *source , gpointer callback_data , GSourceCallbackFuncs *callback_funcs ) ;
extern void g_source_add_poll(GSource *source , GPollFD *fd ) ;
extern void g_source_remove_poll(GSource *source , GPollFD *fd ) ;
extern void g_source_get_current_time(GSource *source , GTimeVal *timeval ) ;
extern GSource *g_idle_source_new(void) ;
extern GSource *g_child_watch_source_new(GPid pid ) ;
extern GSource *g_timeout_source_new(guint interval ) ;
extern GSource *g_timeout_source_new_seconds(guint interval ) ;
extern void g_get_current_time(GTimeVal *result ) ;
extern gboolean g_source_remove(guint tag ) ;
extern gboolean g_source_remove_by_user_data(gpointer user_data ) ;
extern gboolean g_source_remove_by_funcs_user_data(GSourceFuncs *funcs , gpointer user_data ) ;
extern guint g_timeout_add_full(gint priority , guint interval , gboolean (*function)(gpointer data ) , gpointer data , void (*notify)(gpointer data ) ) ;
extern guint g_timeout_add(guint interval , gboolean (*function)(gpointer data ) , gpointer data ) ;
extern guint g_timeout_add_seconds_full(gint priority , guint interval , gboolean (*function)(gpointer data ) , gpointer data , void (*notify)(gpointer data ) ) ;
extern guint g_timeout_add_seconds(guint interval , gboolean (*function)(gpointer data ) , gpointer data ) ;
extern guint g_child_watch_add_full(gint priority , GPid pid , void (*function)(GPid pid , gint status , gpointer data ) , gpointer data , void (*notify)(gpointer data ) ) ;
extern guint g_child_watch_add(GPid pid , void (*function)(GPid pid , gint status , gpointer data ) , gpointer data ) ;
extern guint g_idle_add(gboolean (*function)(gpointer data ) , gpointer data ) ;
extern guint g_idle_add_full(gint priority , gboolean (*function)(gpointer data ) , gpointer data , void (*notify)(gpointer data ) ) ;
extern gboolean g_idle_remove_by_data(gpointer data ) ;
extern GSourceFuncs g_timeout_funcs ;
extern GSourceFuncs g_child_watch_funcs ;
extern GSourceFuncs g_idle_funcs ;
extern gboolean g_get_charset(char const   **charset ) ;
extern gboolean g_unichar_isalnum(gunichar c )  __attribute__((__const__)) ;
extern gboolean g_unichar_isalpha(gunichar c )  __attribute__((__const__)) ;
extern gboolean g_unichar_iscntrl(gunichar c )  __attribute__((__const__)) ;
extern gboolean g_unichar_isdigit(gunichar c )  __attribute__((__const__)) ;
extern gboolean g_unichar_isgraph(gunichar c )  __attribute__((__const__)) ;
extern gboolean g_unichar_islower(gunichar c )  __attribute__((__const__)) ;
extern gboolean g_unichar_isprint(gunichar c )  __attribute__((__const__)) ;
extern gboolean g_unichar_ispunct(gunichar c )  __attribute__((__const__)) ;
extern gboolean g_unichar_isspace(gunichar c )  __attribute__((__const__)) ;
extern gboolean g_unichar_isupper(gunichar c )  __attribute__((__const__)) ;
extern gboolean g_unichar_isxdigit(gunichar c )  __attribute__((__const__)) ;
extern gboolean g_unichar_istitle(gunichar c )  __attribute__((__const__)) ;
extern gboolean g_unichar_isdefined(gunichar c )  __attribute__((__const__)) ;
extern gboolean g_unichar_iswide(gunichar c )  __attribute__((__const__)) ;
extern gboolean g_unichar_iswide_cjk(gunichar c )  __attribute__((__const__)) ;
extern gboolean g_unichar_iszerowidth(gunichar c )  __attribute__((__const__)) ;
extern gboolean g_unichar_ismark(gunichar c )  __attribute__((__const__)) ;
extern gunichar g_unichar_toupper(gunichar c )  __attribute__((__const__)) ;
extern gunichar g_unichar_tolower(gunichar c )  __attribute__((__const__)) ;
extern gunichar g_unichar_totitle(gunichar c )  __attribute__((__const__)) ;
extern gint g_unichar_digit_value(gunichar c )  __attribute__((__const__)) ;
extern gint g_unichar_xdigit_value(gunichar c )  __attribute__((__const__)) ;
extern GUnicodeType g_unichar_type(gunichar c )  __attribute__((__const__)) ;
extern GUnicodeBreakType g_unichar_break_type(gunichar c )  __attribute__((__const__)) ;
extern gint g_unichar_combining_class(gunichar uc )  __attribute__((__const__)) ;
extern void g_unicode_canonical_ordering(gunichar *string , gsize len ) ;
extern gunichar *g_unicode_canonical_decomposition(gunichar ch , gsize *result_len )  __attribute__((__malloc__)) ;
extern gchar const   * const  g_utf8_skip ;
extern gunichar g_utf8_get_char(gchar const   *p )  __attribute__((__pure__)) ;
extern gunichar g_utf8_get_char_validated(gchar const   *p , gssize max_len )  __attribute__((__pure__)) ;
extern gchar *g_utf8_offset_to_pointer(gchar const   *str , glong offset )  __attribute__((__pure__)) ;
extern glong g_utf8_pointer_to_offset(gchar const   *str , gchar const   *pos )  __attribute__((__pure__)) ;
extern gchar *g_utf8_prev_char(gchar const   *p )  __attribute__((__pure__)) ;
extern gchar *g_utf8_find_next_char(gchar const   *p , gchar const   *end )  __attribute__((__pure__)) ;
extern gchar *g_utf8_find_prev_char(gchar const   *str , gchar const   *p )  __attribute__((__pure__)) ;
extern glong g_utf8_strlen(gchar const   *p , gssize max )  __attribute__((__pure__)) ;
extern gchar *g_utf8_strncpy(gchar *dest , gchar const   *src , gsize n ) ;
extern gchar *g_utf8_strchr(gchar const   *p , gssize len , gunichar c ) ;
extern gchar *g_utf8_strrchr(gchar const   *p , gssize len , gunichar c ) ;
extern gchar *g_utf8_strreverse(gchar const   *str , gssize len ) ;
extern gunichar2 *g_utf8_to_utf16(gchar const   *str , glong len , glong *items_read , glong *items_written , GError **error )  __attribute__((__malloc__)) ;
extern gunichar *g_utf8_to_ucs4(gchar const   *str , glong len , glong *items_read , glong *items_written , GError **error )  __attribute__((__malloc__)) ;
extern gunichar *g_utf8_to_ucs4_fast(gchar const   *str , glong len , glong *items_written )  __attribute__((__malloc__)) ;
extern gunichar *g_utf16_to_ucs4(gunichar2 const   *str , glong len , glong *items_read , glong *items_written , GError **error )  __attribute__((__malloc__)) ;
extern gchar *g_utf16_to_utf8(gunichar2 const   *str , glong len , glong *items_read , glong *items_written , GError **error )  __attribute__((__malloc__)) ;
extern gunichar2 *g_ucs4_to_utf16(gunichar const   *str , glong len , glong *items_read , glong *items_written , GError **error )  __attribute__((__malloc__)) ;
extern gchar *g_ucs4_to_utf8(gunichar const   *str , glong len , glong *items_read , glong *items_written , GError **error )  __attribute__((__malloc__)) ;
extern gint g_unichar_to_utf8(gunichar c , gchar *outbuf ) ;
extern gboolean g_utf8_validate(gchar const   *str , gssize max_len , gchar const   **end ) ;
extern gboolean g_unichar_validate(gunichar ch )  __attribute__((__const__)) ;
extern gchar *g_utf8_strup(gchar const   *str , gssize len )  __attribute__((__malloc__)) ;
extern gchar *g_utf8_strdown(gchar const   *str , gssize len )  __attribute__((__malloc__)) ;
extern gchar *g_utf8_casefold(gchar const   *str , gssize len )  __attribute__((__malloc__)) ;
extern gchar *g_utf8_normalize(gchar const   *str , gssize len , GNormalizeMode mode )  __attribute__((__malloc__)) ;
extern gint g_utf8_collate(gchar const   *str1 , gchar const   *str2 )  __attribute__((__pure__)) ;
extern gchar *g_utf8_collate_key(gchar const   *str , gssize len )  __attribute__((__malloc__)) ;
extern gchar *g_utf8_collate_key_for_filename(gchar const   *str , gssize len )  __attribute__((__malloc__)) ;
extern gboolean g_unichar_get_mirror_char(gunichar ch , gunichar *mirrored_ch ) ;
extern GUnicodeScript g_unichar_get_script(gunichar ch )  __attribute__((__const__)) ;
extern gchar *_g_utf8_make_valid(gchar const   *name ) ;
extern GStringChunk *g_string_chunk_new(gsize size ) ;
extern void g_string_chunk_free(GStringChunk *chunk ) ;
extern void g_string_chunk_clear(GStringChunk *chunk ) ;
extern gchar *g_string_chunk_insert(GStringChunk *chunk , gchar const   *string ) ;
extern gchar *g_string_chunk_insert_len(GStringChunk *chunk , gchar const   *string , gssize len ) ;
extern gchar *g_string_chunk_insert_const(GStringChunk *chunk , gchar const   *string ) ;
extern GString *g_string_new(gchar const   *init ) ;
extern GString *g_string_new_len(gchar const   *init , gssize len ) ;
extern GString *g_string_sized_new(gsize dfl_size ) ;
extern gchar *g_string_free(GString *string , gboolean free_segment ) ;
extern gboolean g_string_equal(GString const   *v , GString const   *v2 ) ;
extern guint g_string_hash(GString const   *str ) ;
extern GString *g_string_assign(GString *string , gchar const   *rval ) ;
extern GString *g_string_truncate(GString *string , gsize len ) ;
extern GString *g_string_set_size(GString *string , gsize len ) ;
extern GString *g_string_insert_len(GString *string , gssize pos , gchar const   *val , gssize len ) ;
extern GString *g_string_append(GString *string , gchar const   *val ) ;
extern GString *g_string_append_len(GString *string , gchar const   *val , gssize len ) ;
extern GString *g_string_append_c(GString *string , gchar c ) ;
extern GString *g_string_append_unichar(GString *string , gunichar wc ) ;
extern GString *g_string_prepend(GString *string , gchar const   *val ) ;
extern GString *g_string_prepend_c(GString *string , gchar c ) ;
extern GString *g_string_prepend_unichar(GString *string , gunichar wc ) ;
extern GString *g_string_prepend_len(GString *string , gchar const   *val , gssize len ) ;
extern GString *g_string_insert(GString *string , gssize pos , gchar const   *val ) ;
extern GString *g_string_insert_c(GString *string , gssize pos , gchar c ) ;
extern GString *g_string_insert_unichar(GString *string , gssize pos , gunichar wc ) ;
extern GString *g_string_overwrite(GString *string , gsize pos , gchar const   *val ) ;
extern GString *g_string_overwrite_len(GString *string , gsize pos , gchar const   *val , gssize len ) ;
extern GString *g_string_erase(GString *string , gssize pos , gssize len ) ;
extern GString *g_string_ascii_down(GString *string ) ;
extern GString *g_string_ascii_up(GString *string ) ;
extern void g_string_vprintf(GString *string , gchar const   *format , va_list args ) ;
extern void ( /* format attribute */  g_string_printf)(GString *string , gchar const   *format  , ...) ;
extern void g_string_append_vprintf(GString *string , gchar const   *format , va_list args ) ;
extern void ( /* format attribute */  g_string_append_printf)(GString *string , gchar const   *format  , ...) ;
extern GString *g_string_append_uri_escaped(GString *string , char const   *unescaped , char const   *reserved_chars_allowed , gboolean allow_utf8 ) ;
__inline static GString *g_string_append_c_inline(GString *gstring , gchar c ) 
{ gsize tmp ;

  {
  if (gstring->len + 1U < gstring->allocated_len) {
    tmp = gstring->len;
    (gstring->len) ++;
    *(gstring->str + tmp) = c;
    *(gstring->str + gstring->len) = (char)0;
  } else {
    g_string_insert_c(gstring, -1, c);
  }
  return (gstring);
}
}
extern GString *g_string_down(GString *string ) ;
extern GString *g_string_up(GString *string ) ;
extern void g_io_channel_init(GIOChannel *channel ) ;
extern GIOChannel *g_io_channel_ref(GIOChannel *channel ) ;
extern void g_io_channel_unref(GIOChannel *channel ) ;
extern GIOError g_io_channel_read(GIOChannel *channel , gchar *buf , gsize count , gsize *bytes_read ) ;
extern GIOError g_io_channel_write(GIOChannel *channel , gchar const   *buf , gsize count , gsize *bytes_written ) ;
extern GIOError g_io_channel_seek(GIOChannel *channel , gint64 offset , GSeekType type ) ;
extern void g_io_channel_close(GIOChannel *channel ) ;
extern GIOStatus g_io_channel_shutdown(GIOChannel *channel , gboolean flush , GError **err ) ;
extern guint g_io_add_watch_full(GIOChannel *channel , gint priority , GIOCondition condition , gboolean (*func)(GIOChannel *source , GIOCondition condition , gpointer data ) , gpointer user_data , void (*notify)(gpointer data ) ) ;
extern GSource *g_io_create_watch(GIOChannel *channel , GIOCondition condition ) ;
extern guint g_io_add_watch(GIOChannel *channel , GIOCondition condition , gboolean (*func)(GIOChannel *source , GIOCondition condition , gpointer data ) , gpointer user_data ) ;
extern void g_io_channel_set_buffer_size(GIOChannel *channel , gsize size ) ;
extern gsize g_io_channel_get_buffer_size(GIOChannel *channel ) ;
extern GIOCondition g_io_channel_get_buffer_condition(GIOChannel *channel ) ;
extern GIOStatus g_io_channel_set_flags(GIOChannel *channel , GIOFlags flags , GError **error ) ;
extern GIOFlags g_io_channel_get_flags(GIOChannel *channel ) ;
extern void g_io_channel_set_line_term(GIOChannel *channel , gchar const   *line_term , gint length ) ;
extern gchar const   *g_io_channel_get_line_term(GIOChannel *channel , gint *length ) ;
extern void g_io_channel_set_buffered(GIOChannel *channel , gboolean buffered ) ;
extern gboolean g_io_channel_get_buffered(GIOChannel *channel ) ;
extern GIOStatus g_io_channel_set_encoding(GIOChannel *channel , gchar const   *encoding , GError **error ) ;
extern gchar const   *g_io_channel_get_encoding(GIOChannel *channel ) ;
extern void g_io_channel_set_close_on_unref(GIOChannel *channel , gboolean do_close ) ;
extern gboolean g_io_channel_get_close_on_unref(GIOChannel *channel ) ;
extern GIOStatus g_io_channel_flush(GIOChannel *channel , GError **error ) ;
extern GIOStatus g_io_channel_read_line(GIOChannel *channel , gchar **str_return , gsize *length , gsize *terminator_pos , GError **error ) ;
extern GIOStatus g_io_channel_read_line_string(GIOChannel *channel , GString *buffer , gsize *terminator_pos , GError **error ) ;
extern GIOStatus g_io_channel_read_to_end(GIOChannel *channel , gchar **str_return , gsize *length , GError **error ) ;
extern GIOStatus g_io_channel_read_chars(GIOChannel *channel , gchar *buf , gsize count , gsize *bytes_read , GError **error ) ;
extern GIOStatus g_io_channel_read_unichar(GIOChannel *channel , gunichar *thechar , GError **error ) ;
extern GIOStatus g_io_channel_write_chars(GIOChannel *channel , gchar const   *buf , gssize count , gsize *bytes_written , GError **error ) ;
extern GIOStatus g_io_channel_write_unichar(GIOChannel *channel , gunichar thechar , GError **error ) ;
extern GIOStatus g_io_channel_seek_position(GIOChannel *channel , gint64 offset , GSeekType type , GError **error ) ;
extern GIOChannel *g_io_channel_new_file(gchar const   *filename , gchar const   *mode , GError **error ) ;
extern GQuark g_io_channel_error_quark(void) ;
extern GIOChannelError g_io_channel_error_from_errno(gint en ) ;
extern GIOChannel *g_io_channel_unix_new(int fd ) ;
extern gint g_io_channel_unix_get_fd(GIOChannel *channel ) ;
extern GSourceFuncs g_io_watch_funcs ;
extern GQuark g_key_file_error_quark(void) ;
extern GKeyFile *g_key_file_new(void) ;
extern void g_key_file_free(GKeyFile *key_file ) ;
extern void g_key_file_set_list_separator(GKeyFile *key_file , gchar separator ) ;
extern gboolean g_key_file_load_from_file(GKeyFile *key_file , gchar const   *file , GKeyFileFlags flags , GError **error ) ;
extern gboolean g_key_file_load_from_data(GKeyFile *key_file , gchar const   *data , gsize length , GKeyFileFlags flags , GError **error ) ;
extern gboolean g_key_file_load_from_dirs(GKeyFile *key_file , gchar const   *file , gchar const   **search_dirs , gchar **full_path , GKeyFileFlags flags , GError **error ) ;
extern gboolean g_key_file_load_from_data_dirs(GKeyFile *key_file , gchar const   *file , gchar **full_path , GKeyFileFlags flags , GError **error ) ;
extern gchar *g_key_file_to_data(GKeyFile *key_file , gsize *length , GError **error )  __attribute__((__malloc__)) ;
extern gchar *g_key_file_get_start_group(GKeyFile *key_file )  __attribute__((__malloc__)) ;
extern gchar **g_key_file_get_groups(GKeyFile *key_file , gsize *length )  __attribute__((__malloc__)) ;
extern gchar **g_key_file_get_keys(GKeyFile *key_file , gchar const   *group_name , gsize *length , GError **error )  __attribute__((__malloc__)) ;
extern gboolean g_key_file_has_group(GKeyFile *key_file , gchar const   *group_name ) ;
extern gboolean g_key_file_has_key(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , GError **error ) ;
extern gchar *g_key_file_get_value(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , GError **error )  __attribute__((__malloc__)) ;
extern void g_key_file_set_value(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gchar const   *value ) ;
extern gchar *g_key_file_get_string(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , GError **error )  __attribute__((__malloc__)) ;
extern void g_key_file_set_string(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gchar const   *string ) ;
extern gchar *g_key_file_get_locale_string(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gchar const   *locale , GError **error )  __attribute__((__malloc__)) ;
extern void g_key_file_set_locale_string(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gchar const   *locale , gchar const   *string ) ;
extern gboolean g_key_file_get_boolean(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , GError **error ) ;
extern void g_key_file_set_boolean(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gboolean value ) ;
extern gint g_key_file_get_integer(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , GError **error ) ;
extern void g_key_file_set_integer(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gint value ) ;
extern gdouble g_key_file_get_double(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , GError **error ) ;
extern void g_key_file_set_double(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gdouble value ) ;
extern gchar **g_key_file_get_string_list(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gsize *length , GError **error )  __attribute__((__malloc__)) ;
extern void g_key_file_set_string_list(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gchar const   * const  *list , gsize length ) ;
extern gchar **g_key_file_get_locale_string_list(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gchar const   *locale , gsize *length , GError **error )  __attribute__((__malloc__)) ;
extern void g_key_file_set_locale_string_list(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gchar const   *locale , gchar const   * const  *list , gsize length ) ;
extern gboolean *g_key_file_get_boolean_list(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gsize *length , GError **error )  __attribute__((__malloc__)) ;
extern void g_key_file_set_boolean_list(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gboolean *list , gsize length ) ;
extern gint *g_key_file_get_integer_list(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gsize *length , GError **error )  __attribute__((__malloc__)) ;
extern void g_key_file_set_double_list(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gdouble *list , gsize length ) ;
extern gdouble *g_key_file_get_double_list(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gsize *length , GError **error )  __attribute__((__malloc__)) ;
extern void g_key_file_set_integer_list(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gint *list , gsize length ) ;
extern gboolean g_key_file_set_comment(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , gchar const   *comment , GError **error ) ;
extern gchar *g_key_file_get_comment(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , GError **error )  __attribute__((__malloc__)) ;
extern gboolean g_key_file_remove_comment(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , GError **error ) ;
extern gboolean g_key_file_remove_key(GKeyFile *key_file , gchar const   *group_name , gchar const   *key , GError **error ) ;
extern gboolean g_key_file_remove_group(GKeyFile *key_file , gchar const   *group_name , GError **error ) ;
extern GMappedFile *g_mapped_file_new(gchar const   *filename , gboolean writable , GError **error )  __attribute__((__malloc__)) ;
extern gsize g_mapped_file_get_length(GMappedFile *file ) ;
extern gchar *g_mapped_file_get_contents(GMappedFile *file ) ;
extern GMappedFile *g_mapped_file_ref(GMappedFile *file ) ;
extern void g_mapped_file_unref(GMappedFile *file ) ;
extern void g_mapped_file_free(GMappedFile *file ) ;
extern GQuark g_markup_error_quark(void) ;
extern GMarkupParseContext *g_markup_parse_context_new(GMarkupParser const   *parser , GMarkupParseFlags flags , gpointer user_data , void (*user_data_dnotify)(gpointer data ) ) ;
extern void g_markup_parse_context_free(GMarkupParseContext *context ) ;
extern gboolean g_markup_parse_context_parse(GMarkupParseContext *context , gchar const   *text , gssize text_len , GError **error ) ;
extern void g_markup_parse_context_push(GMarkupParseContext *context , GMarkupParser *parser , gpointer user_data ) ;
extern gpointer g_markup_parse_context_pop(GMarkupParseContext *context ) ;
extern gboolean g_markup_parse_context_end_parse(GMarkupParseContext *context , GError **error ) ;
extern gchar const   *g_markup_parse_context_get_element(GMarkupParseContext *context ) ;
extern GSList const   *g_markup_parse_context_get_element_stack(GMarkupParseContext *context ) ;
extern void g_markup_parse_context_get_position(GMarkupParseContext *context , gint *line_number , gint *char_number ) ;
extern gpointer g_markup_parse_context_get_user_data(GMarkupParseContext *context ) ;
extern gchar *g_markup_escape_text(gchar const   *text , gssize length ) ;
extern gchar *( /* format attribute */  g_markup_printf_escaped)(char const   *format  , ...) ;
extern gchar *g_markup_vprintf_escaped(char const   *format , va_list args ) ;
extern gboolean g_markup_collect_attributes(gchar const   *element_name , gchar const   **attribute_names , gchar const   **attribute_values , GError **error , GMarkupCollectType first_type , gchar const   *first_attr  , ...) ;
extern gsize g_printf_string_upper_bound(gchar const   *format , va_list args ) ;
extern guint g_log_set_handler(gchar const   *log_domain , GLogLevelFlags log_levels , void (*log_func)(gchar const   *log_domain , GLogLevelFlags log_level , gchar const   *message , gpointer user_data ) , gpointer user_data ) ;
extern void g_log_remove_handler(gchar const   *log_domain , guint handler_id ) ;
extern void g_log_default_handler(gchar const   *log_domain , GLogLevelFlags log_level , gchar const   *message , gpointer unused_data ) ;
extern GLogFunc g_log_set_default_handler(void (*log_func)(gchar const   *log_domain , GLogLevelFlags log_level , gchar const   *message , gpointer user_data ) , gpointer user_data ) ;
extern void ( /* format attribute */  g_log)(gchar const   *log_domain , GLogLevelFlags log_level , gchar const   *format  , ...) ;
extern void g_logv(gchar const   *log_domain , GLogLevelFlags log_level , gchar const   *format , va_list args ) ;
extern GLogLevelFlags g_log_set_fatal_mask(gchar const   *log_domain , GLogLevelFlags fatal_mask ) ;
extern GLogLevelFlags g_log_set_always_fatal(GLogLevelFlags fatal_mask ) ;
extern void __attribute__((__visibility__("hidden")))  _g_log_fallback_handler(gchar const   *log_domain , GLogLevelFlags log_level , gchar const   *message , gpointer unused_data ) ;
extern void g_return_if_fail_warning(char const   *log_domain , char const   *pretty_function , char const   *expression ) ;
extern void g_warn_message(char const   *domain , char const   *file , int line , char const   *func , char const   *warnexpr ) ;
extern  __attribute__((__noreturn__)) void g_assert_warning(char const   *log_domain , char const   *file , int line , char const   *pretty_function , char const   *expression ) ;
extern void ( /* format attribute */  g_print)(gchar const   *format  , ...) ;
extern GPrintFunc g_set_print_handler(void (*func)(gchar const   *string ) ) ;
extern void ( /* format attribute */  g_printerr)(gchar const   *format  , ...) ;
extern GPrintFunc g_set_printerr_handler(void (*func)(gchar const   *string ) ) ;
extern GNode *g_node_new(gpointer data ) ;
extern void g_node_destroy(GNode *root ) ;
extern void g_node_unlink(GNode *node ) ;
extern GNode *g_node_copy_deep(GNode *node , gpointer (*copy_func)(gconstpointer src , gpointer data ) , gpointer data ) ;
extern GNode *g_node_copy(GNode *node ) ;
extern GNode *g_node_insert(GNode *parent , gint position , GNode *node ) ;
extern GNode *g_node_insert_before(GNode *parent , GNode *sibling , GNode *node ) ;
extern GNode *g_node_insert_after(GNode *parent , GNode *sibling , GNode *node ) ;
extern GNode *g_node_prepend(GNode *parent , GNode *node ) ;
extern guint g_node_n_nodes(GNode *root , GTraverseFlags flags ) ;
extern GNode *g_node_get_root(GNode *node ) ;
extern gboolean g_node_is_ancestor(GNode *node , GNode *descendant ) ;
extern guint g_node_depth(GNode *node ) ;
extern GNode *g_node_find(GNode *root , GTraverseType order , GTraverseFlags flags , gpointer data ) ;
extern void g_node_traverse(GNode *root , GTraverseType order , GTraverseFlags flags , gint max_depth , gboolean (*func)(GNode *node , gpointer data ) , gpointer data ) ;
extern guint g_node_max_height(GNode *root ) ;
extern void g_node_children_foreach(GNode *node , GTraverseFlags flags , void (*func)(GNode *node , gpointer data ) , gpointer data ) ;
extern void g_node_reverse_children(GNode *node ) ;
extern guint g_node_n_children(GNode *node ) ;
extern GNode *g_node_nth_child(GNode *node , guint n ) ;
extern GNode *g_node_last_child(GNode *node ) ;
extern GNode *g_node_find_child(GNode *node , GTraverseFlags flags , gpointer data ) ;
extern gint g_node_child_position(GNode *node , GNode *child ) ;
extern gint g_node_child_index(GNode *node , gpointer data ) ;
extern GNode *g_node_first_sibling(GNode *node ) ;
extern GNode *g_node_last_sibling(GNode *node ) ;
extern void g_node_push_allocator(gpointer dummy ) ;
extern void g_node_pop_allocator(void) ;
extern GQuark g_option_error_quark(void) ;
extern GOptionContext *g_option_context_new(gchar const   *parameter_string ) ;
extern void g_option_context_set_summary(GOptionContext *context , gchar const   *summary ) ;
extern gchar const   *g_option_context_get_summary(GOptionContext *context ) ;
extern void g_option_context_set_description(GOptionContext *context , gchar const   *description ) ;
extern gchar const   *g_option_context_get_description(GOptionContext *context ) ;
extern void g_option_context_free(GOptionContext *context ) ;
extern void g_option_context_set_help_enabled(GOptionContext *context , gboolean help_enabled ) ;
extern gboolean g_option_context_get_help_enabled(GOptionContext *context ) ;
extern void g_option_context_set_ignore_unknown_options(GOptionContext *context , gboolean ignore_unknown ) ;
extern gboolean g_option_context_get_ignore_unknown_options(GOptionContext *context ) ;
extern void g_option_context_add_main_entries(GOptionContext *context , GOptionEntry const   *entries , gchar const   *translation_domain ) ;
extern gboolean g_option_context_parse(GOptionContext *context , gint *argc , gchar ***argv , GError **error ) ;
extern void g_option_context_set_translate_func(GOptionContext *context , gchar const   *(*func)(gchar const   *str , gpointer data ) , gpointer data , void (*destroy_notify)(gpointer data ) ) ;
extern void g_option_context_set_translation_domain(GOptionContext *context , gchar const   *domain ) ;
extern void g_option_context_add_group(GOptionContext *context , GOptionGroup *group ) ;
extern void g_option_context_set_main_group(GOptionContext *context , GOptionGroup *group ) ;
extern GOptionGroup *g_option_context_get_main_group(GOptionContext *context ) ;
extern gchar *g_option_context_get_help(GOptionContext *context , gboolean main_help , GOptionGroup *group ) ;
extern GOptionGroup *g_option_group_new(gchar const   *name , gchar const   *description , gchar const   *help_description , gpointer user_data , void (*destroy)(gpointer data ) ) ;
extern void g_option_group_set_parse_hooks(GOptionGroup *group , gboolean (*pre_parse_func)(GOptionContext *context , GOptionGroup *group , gpointer data , GError **error ) , gboolean (*post_parse_func)(GOptionContext *context , GOptionGroup *group , gpointer data , GError **error ) ) ;
extern void g_option_group_set_error_hook(GOptionGroup *group , void (*error_func)(GOptionContext *context , GOptionGroup *group , gpointer data , GError **error ) ) ;
extern void g_option_group_free(GOptionGroup *group ) ;
extern void g_option_group_add_entries(GOptionGroup *group , GOptionEntry const   *entries ) ;
extern void g_option_group_set_translate_func(GOptionGroup *group , gchar const   *(*func)(gchar const   *str , gpointer data ) , gpointer data , void (*destroy_notify)(gpointer data ) ) ;
extern void g_option_group_set_translation_domain(GOptionGroup *group , gchar const   *domain ) ;
extern GPatternSpec *g_pattern_spec_new(gchar const   *pattern ) ;
extern void g_pattern_spec_free(GPatternSpec *pspec ) ;
extern gboolean g_pattern_spec_equal(GPatternSpec *pspec1 , GPatternSpec *pspec2 ) ;
extern gboolean g_pattern_match(GPatternSpec *pspec , guint string_length , gchar const   *string , gchar const   *string_reversed ) ;
extern gboolean g_pattern_match_string(GPatternSpec *pspec , gchar const   *string ) ;
extern gboolean g_pattern_match_simple(gchar const   *pattern , gchar const   *string ) ;
extern guint g_spaced_primes_closest(guint num )  __attribute__((__const__)) ;
extern void g_qsort_with_data(gconstpointer pbase , gint total_elems , gsize size , gint (*compare_func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer user_data ) ;
extern GQueue *g_queue_new(void) ;
extern void g_queue_free(GQueue *queue ) ;
extern void g_queue_init(GQueue *queue ) ;
extern void g_queue_clear(GQueue *queue ) ;
extern gboolean g_queue_is_empty(GQueue *queue ) ;
extern guint g_queue_get_length(GQueue *queue ) ;
extern void g_queue_reverse(GQueue *queue ) ;
extern GQueue *g_queue_copy(GQueue *queue ) ;
extern void g_queue_foreach(GQueue *queue , void (*func)(gpointer data , gpointer user_data ) , gpointer user_data ) ;
extern GList *g_queue_find(GQueue *queue , gconstpointer data ) ;
extern GList *g_queue_find_custom(GQueue *queue , gconstpointer data , gint (*func)(gconstpointer a , gconstpointer b ) ) ;
extern void g_queue_sort(GQueue *queue , gint (*compare_func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer user_data ) ;
extern void g_queue_push_head(GQueue *queue , gpointer data ) ;
extern void g_queue_push_tail(GQueue *queue , gpointer data ) ;
extern void g_queue_push_nth(GQueue *queue , gpointer data , gint n ) ;
extern gpointer g_queue_pop_head(GQueue *queue ) ;
extern gpointer g_queue_pop_tail(GQueue *queue ) ;
extern gpointer g_queue_pop_nth(GQueue *queue , guint n ) ;
extern gpointer g_queue_peek_head(GQueue *queue ) ;
extern gpointer g_queue_peek_tail(GQueue *queue ) ;
extern gpointer g_queue_peek_nth(GQueue *queue , guint n ) ;
extern gint g_queue_index(GQueue *queue , gconstpointer data ) ;
extern void g_queue_remove(GQueue *queue , gconstpointer data ) ;
extern void g_queue_remove_all(GQueue *queue , gconstpointer data ) ;
extern void g_queue_insert_before(GQueue *queue , GList *sibling , gpointer data ) ;
extern void g_queue_insert_after(GQueue *queue , GList *sibling , gpointer data ) ;
extern void g_queue_insert_sorted(GQueue *queue , gpointer data , gint (*func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer user_data ) ;
extern void g_queue_push_head_link(GQueue *queue , GList *link_ ) ;
extern void g_queue_push_tail_link(GQueue *queue , GList *link_ ) ;
extern void g_queue_push_nth_link(GQueue *queue , gint n , GList *link_ ) ;
extern GList *g_queue_pop_head_link(GQueue *queue ) ;
extern GList *g_queue_pop_tail_link(GQueue *queue ) ;
extern GList *g_queue_pop_nth_link(GQueue *queue , guint n ) ;
extern GList *g_queue_peek_head_link(GQueue *queue ) ;
extern GList *g_queue_peek_tail_link(GQueue *queue ) ;
extern GList *g_queue_peek_nth_link(GQueue *queue , guint n ) ;
extern gint g_queue_link_index(GQueue *queue , GList *link_ ) ;
extern void g_queue_unlink(GQueue *queue , GList *link_ ) ;
extern void g_queue_delete_link(GQueue *queue , GList *link_ ) ;
extern GRand *g_rand_new_with_seed(guint32 seed ) ;
extern GRand *g_rand_new_with_seed_array(guint32 const   *seed , guint seed_length ) ;
extern GRand *g_rand_new(void) ;
extern void g_rand_free(GRand *rand_ ) ;
extern GRand *g_rand_copy(GRand *rand_ ) ;
extern void g_rand_set_seed(GRand *rand_ , guint32 seed ) ;
extern void g_rand_set_seed_array(GRand *rand_ , guint32 const   *seed , guint seed_length ) ;
extern guint32 g_rand_int(GRand *rand_ ) ;
extern gint32 g_rand_int_range(GRand *rand_ , gint32 begin , gint32 end ) ;
extern gdouble g_rand_double(GRand *rand_ ) ;
extern gdouble g_rand_double_range(GRand *rand_ , gdouble begin , gdouble end ) ;
extern void g_random_set_seed(guint32 seed ) ;
extern guint32 g_random_int(void) ;
extern gint32 g_random_int_range(gint32 begin , gint32 end ) ;
extern gdouble g_random_double(void) ;
extern gdouble g_random_double_range(gdouble begin , gdouble end ) ;
extern GRelation *g_relation_new(gint fields ) ;
extern void g_relation_destroy(GRelation *relation ) ;
extern void g_relation_index(GRelation *relation , gint field , guint (*hash_func)(gconstpointer key ) , gboolean (*key_equal_func)(gconstpointer a , gconstpointer b ) ) ;
extern void g_relation_insert(GRelation *relation  , ...) ;
extern gint g_relation_delete(GRelation *relation , gconstpointer key , gint field ) ;
extern GTuples *g_relation_select(GRelation *relation , gconstpointer key , gint field ) ;
extern gint g_relation_count(GRelation *relation , gconstpointer key , gint field ) ;
extern gboolean g_relation_exists(GRelation *relation  , ...) ;
extern void g_relation_print(GRelation *relation ) ;
extern void g_tuples_destroy(GTuples *tuples ) ;
extern gpointer g_tuples_index(GTuples *tuples , gint index_ , gint field ) ;
extern GQuark g_regex_error_quark(void) ;
extern GRegex *g_regex_new(gchar const   *pattern , GRegexCompileFlags compile_options , GRegexMatchFlags match_options , GError **error ) ;
extern GRegex *g_regex_ref(GRegex *regex ) ;
extern void g_regex_unref(GRegex *regex ) ;
extern gchar const   *g_regex_get_pattern(GRegex const   *regex ) ;
extern gint g_regex_get_max_backref(GRegex const   *regex ) ;
extern gint g_regex_get_capture_count(GRegex const   *regex ) ;
extern gint g_regex_get_string_number(GRegex const   *regex , gchar const   *name ) ;
extern gchar *g_regex_escape_string(gchar const   *string , gint length ) ;
extern gboolean g_regex_match_simple(gchar const   *pattern , gchar const   *string , GRegexCompileFlags compile_options , GRegexMatchFlags match_options ) ;
extern gboolean g_regex_match(GRegex const   *regex , gchar const   *string , GRegexMatchFlags match_options , GMatchInfo **match_info ) ;
extern gboolean g_regex_match_full(GRegex const   *regex , gchar const   *string , gssize string_len , gint start_position , GRegexMatchFlags match_options , GMatchInfo **match_info , GError **error ) ;
extern gboolean g_regex_match_all(GRegex const   *regex , gchar const   *string , GRegexMatchFlags match_options , GMatchInfo **match_info ) ;
extern gboolean g_regex_match_all_full(GRegex const   *regex , gchar const   *string , gssize string_len , gint start_position , GRegexMatchFlags match_options , GMatchInfo **match_info , GError **error ) ;
extern gchar **g_regex_split_simple(gchar const   *pattern , gchar const   *string , GRegexCompileFlags compile_options , GRegexMatchFlags match_options ) ;
extern gchar **g_regex_split(GRegex const   *regex , gchar const   *string , GRegexMatchFlags match_options ) ;
extern gchar **g_regex_split_full(GRegex const   *regex , gchar const   *string , gssize string_len , gint start_position , GRegexMatchFlags match_options , gint max_tokens , GError **error ) ;
extern gchar *g_regex_replace(GRegex const   *regex , gchar const   *string , gssize string_len , gint start_position , gchar const   *replacement , GRegexMatchFlags match_options , GError **error ) ;
extern gchar *g_regex_replace_literal(GRegex const   *regex , gchar const   *string , gssize string_len , gint start_position , gchar const   *replacement , GRegexMatchFlags match_options , GError **error ) ;
extern gchar *g_regex_replace_eval(GRegex const   *regex , gchar const   *string , gssize string_len , gint start_position , GRegexMatchFlags match_options , gboolean (*eval)(GMatchInfo const   *match_info , GString *result , gpointer user_data ) , gpointer user_data , GError **error ) ;
extern gboolean g_regex_check_replacement(gchar const   *replacement , gboolean *has_references , GError **error ) ;
extern GRegex *g_match_info_get_regex(GMatchInfo const   *match_info ) ;
extern gchar const   *g_match_info_get_string(GMatchInfo const   *match_info ) ;
extern void g_match_info_free(GMatchInfo *match_info ) ;
extern gboolean g_match_info_next(GMatchInfo *match_info , GError **error ) ;
extern gboolean g_match_info_matches(GMatchInfo const   *match_info ) ;
extern gint g_match_info_get_match_count(GMatchInfo const   *match_info ) ;
extern gboolean g_match_info_is_partial_match(GMatchInfo const   *match_info ) ;
extern gchar *g_match_info_expand_references(GMatchInfo const   *match_info , gchar const   *string_to_expand , GError **error ) ;
extern gchar *g_match_info_fetch(GMatchInfo const   *match_info , gint match_num ) ;
extern gboolean g_match_info_fetch_pos(GMatchInfo const   *match_info , gint match_num , gint *start_pos , gint *end_pos ) ;
extern gchar *g_match_info_fetch_named(GMatchInfo const   *match_info , gchar const   *name ) ;
extern gboolean g_match_info_fetch_named_pos(GMatchInfo const   *match_info , gchar const   *name , gint *start_pos , gint *end_pos ) ;
extern gchar **g_match_info_fetch_all(GMatchInfo const   *match_info ) ;
extern GScanner *g_scanner_new(GScannerConfig const   *config_templ ) ;
extern void g_scanner_destroy(GScanner *scanner ) ;
extern void g_scanner_input_file(GScanner *scanner , gint input_fd ) ;
extern void g_scanner_sync_file_offset(GScanner *scanner ) ;
extern void g_scanner_input_text(GScanner *scanner , gchar const   *text , guint text_len ) ;
extern GTokenType g_scanner_get_next_token(GScanner *scanner ) ;
extern GTokenType g_scanner_peek_next_token(GScanner *scanner ) ;
extern GTokenType g_scanner_cur_token(GScanner *scanner ) ;
extern GTokenValue g_scanner_cur_value(GScanner *scanner ) ;
extern guint g_scanner_cur_line(GScanner *scanner ) ;
extern guint g_scanner_cur_position(GScanner *scanner ) ;
extern gboolean g_scanner_eof(GScanner *scanner ) ;
extern guint g_scanner_set_scope(GScanner *scanner , guint scope_id ) ;
extern void g_scanner_scope_add_symbol(GScanner *scanner , guint scope_id , gchar const   *symbol , gpointer value ) ;
extern void g_scanner_scope_remove_symbol(GScanner *scanner , guint scope_id , gchar const   *symbol ) ;
extern gpointer g_scanner_scope_lookup_symbol(GScanner *scanner , guint scope_id , gchar const   *symbol ) ;
extern void g_scanner_scope_foreach_symbol(GScanner *scanner , guint scope_id , void (*func)(gpointer key , gpointer value , gpointer user_data ) , gpointer user_data ) ;
extern gpointer g_scanner_lookup_symbol(GScanner *scanner , gchar const   *symbol ) ;
extern void g_scanner_unexp_token(GScanner *scanner , GTokenType expected_token , gchar const   *identifier_spec , gchar const   *symbol_spec , gchar const   *symbol_name , gchar const   *message , gint is_error ) ;
extern void ( /* format attribute */  g_scanner_error)(GScanner *scanner , gchar const   *format  , ...) ;
extern void ( /* format attribute */  g_scanner_warn)(GScanner *scanner , gchar const   *format  , ...) ;
extern GSequence *g_sequence_new(void (*data_destroy)(gpointer data ) ) ;
extern void g_sequence_free(GSequence *seq ) ;
extern gint g_sequence_get_length(GSequence *seq ) ;
extern void g_sequence_foreach(GSequence *seq , void (*func)(gpointer data , gpointer user_data ) , gpointer user_data ) ;
extern void g_sequence_foreach_range(GSequenceIter *begin , GSequenceIter *end , void (*func)(gpointer data , gpointer user_data ) , gpointer user_data ) ;
extern void g_sequence_sort(GSequence *seq , gint (*cmp_func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer cmp_data ) ;
extern void g_sequence_sort_iter(GSequence *seq , gint (*cmp_func)(GSequenceIter *a , GSequenceIter *b , gpointer data ) , gpointer cmp_data ) ;
extern GSequenceIter *g_sequence_get_begin_iter(GSequence *seq ) ;
extern GSequenceIter *g_sequence_get_end_iter(GSequence *seq ) ;
extern GSequenceIter *g_sequence_get_iter_at_pos(GSequence *seq , gint pos ) ;
extern GSequenceIter *g_sequence_append(GSequence *seq , gpointer data ) ;
extern GSequenceIter *g_sequence_prepend(GSequence *seq , gpointer data ) ;
extern GSequenceIter *g_sequence_insert_before(GSequenceIter *iter , gpointer data ) ;
extern void g_sequence_move(GSequenceIter *src , GSequenceIter *dest ) ;
extern void g_sequence_swap(GSequenceIter *a , GSequenceIter *b ) ;
extern GSequenceIter *g_sequence_insert_sorted(GSequence *seq , gpointer data , gint (*cmp_func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer cmp_data ) ;
extern GSequenceIter *g_sequence_insert_sorted_iter(GSequence *seq , gpointer data , gint (*iter_cmp)(GSequenceIter *a , GSequenceIter *b , gpointer data ) , gpointer cmp_data ) ;
extern void g_sequence_sort_changed(GSequenceIter *iter , gint (*cmp_func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer cmp_data ) ;
extern void g_sequence_sort_changed_iter(GSequenceIter *iter , gint (*iter_cmp)(GSequenceIter *a , GSequenceIter *b , gpointer data ) , gpointer cmp_data ) ;
extern void g_sequence_remove(GSequenceIter *iter ) ;
extern void g_sequence_remove_range(GSequenceIter *begin , GSequenceIter *end ) ;
extern void g_sequence_move_range(GSequenceIter *dest , GSequenceIter *begin , GSequenceIter *end ) ;
extern GSequenceIter *g_sequence_search(GSequence *seq , gpointer data , gint (*cmp_func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer cmp_data ) ;
extern GSequenceIter *g_sequence_search_iter(GSequence *seq , gpointer data , gint (*iter_cmp)(GSequenceIter *a , GSequenceIter *b , gpointer data ) , gpointer cmp_data ) ;
extern gpointer g_sequence_get(GSequenceIter *iter ) ;
extern void g_sequence_set(GSequenceIter *iter , gpointer data ) ;
extern gboolean g_sequence_iter_is_begin(GSequenceIter *iter ) ;
extern gboolean g_sequence_iter_is_end(GSequenceIter *iter ) ;
extern GSequenceIter *g_sequence_iter_next(GSequenceIter *iter ) ;
extern GSequenceIter *g_sequence_iter_prev(GSequenceIter *iter ) ;
extern gint g_sequence_iter_get_position(GSequenceIter *iter ) ;
extern GSequenceIter *g_sequence_iter_move(GSequenceIter *iter , gint delta ) ;
extern GSequence *g_sequence_iter_get_sequence(GSequenceIter *iter ) ;
extern gint g_sequence_iter_compare(GSequenceIter *a , GSequenceIter *b ) ;
extern GSequenceIter *g_sequence_range_get_midpoint(GSequenceIter *begin , GSequenceIter *end ) ;
extern GQuark g_shell_error_quark(void) ;
extern gchar *g_shell_quote(gchar const   *unquoted_string ) ;
extern gchar *g_shell_unquote(gchar const   *quoted_string , GError **error ) ;
extern gboolean g_shell_parse_argv(gchar const   *command_line , gint *argcp , gchar ***argvp , GError **error ) ;
extern GQuark g_spawn_error_quark(void) ;
extern gboolean g_spawn_async(gchar const   *working_directory , gchar **argv , gchar **envp , GSpawnFlags flags , void (*child_setup)(gpointer user_data ) , gpointer user_data , GPid *child_pid , GError **error ) ;
extern gboolean g_spawn_async_with_pipes(gchar const   *working_directory , gchar **argv , gchar **envp , GSpawnFlags flags , void (*child_setup)(gpointer user_data ) , gpointer user_data , GPid *child_pid , gint *standard_input , gint *standard_output , gint *standard_error , GError **error ) ;
extern gboolean g_spawn_sync(gchar const   *working_directory , gchar **argv , gchar **envp , GSpawnFlags flags , void (*child_setup)(gpointer user_data ) , gpointer user_data , gchar **standard_output , gchar **standard_error , gint *exit_status , GError **error ) ;
extern gboolean g_spawn_command_line_sync(gchar const   *command_line , gchar **standard_output , gchar **standard_error , gint *exit_status , GError **error ) ;
extern gboolean g_spawn_command_line_async(gchar const   *command_line , GError **error ) ;
extern void g_spawn_close_pid(GPid pid ) ;
extern guint16 const   * const  g_ascii_table ;
extern gchar g_ascii_tolower(gchar c )  __attribute__((__const__)) ;
extern gchar g_ascii_toupper(gchar c )  __attribute__((__const__)) ;
extern gint g_ascii_digit_value(gchar c )  __attribute__((__const__)) ;
extern gint g_ascii_xdigit_value(gchar c )  __attribute__((__const__)) ;
extern gchar *g_strdelimit(gchar *string , gchar const   *delimiters , gchar new_delimiter ) ;
extern gchar *g_strcanon(gchar *string , gchar const   *valid_chars , gchar substitutor ) ;
extern gchar const   *g_strerror(gint errnum )  __attribute__((__const__)) ;
extern gchar const   *g_strsignal(gint signum )  __attribute__((__const__)) ;
extern gchar *g_strreverse(gchar *string ) ;
extern gsize g_strlcpy(gchar *dest , gchar const   *src , gsize dest_size ) ;
extern gsize g_strlcat(gchar *dest , gchar const   *src , gsize dest_size ) ;
extern gchar *g_strstr_len(gchar const   *haystack , gssize haystack_len , gchar const   *needle ) ;
extern gchar *g_strrstr(gchar const   *haystack , gchar const   *needle ) ;
extern gchar *g_strrstr_len(gchar const   *haystack , gssize haystack_len , gchar const   *needle ) ;
extern gboolean g_str_has_suffix(gchar const   *str , gchar const   *suffix ) ;
extern gboolean g_str_has_prefix(gchar const   *str , gchar const   *prefix ) ;
extern gdouble g_strtod(gchar const   *nptr , gchar **endptr ) ;
extern gdouble g_ascii_strtod(gchar const   *nptr , gchar **endptr ) ;
extern guint64 g_ascii_strtoull(gchar const   *nptr , gchar **endptr , guint base ) ;
extern gint64 g_ascii_strtoll(gchar const   *nptr , gchar **endptr , guint base ) ;
extern gchar *g_ascii_dtostr(gchar *buffer , gint buf_len , gdouble d ) ;
extern gchar *g_ascii_formatd(gchar *buffer , gint buf_len , gchar const   *format , gdouble d ) ;
extern gchar *g_strchug(gchar *string ) ;
extern gchar *g_strchomp(gchar *string ) ;
extern gint g_ascii_strcasecmp(gchar const   *s1 , gchar const   *s2 ) ;
extern gint g_ascii_strncasecmp(gchar const   *s1 , gchar const   *s2 , gsize n ) ;
extern gchar *g_ascii_strdown(gchar const   *str , gssize len )  __attribute__((__malloc__)) ;
extern gchar *g_ascii_strup(gchar const   *str , gssize len )  __attribute__((__malloc__)) ;
extern gint g_strcasecmp(gchar const   *s1 , gchar const   *s2 ) ;
extern gint g_strncasecmp(gchar const   *s1 , gchar const   *s2 , guint n ) ;
extern gchar *g_strdown(gchar *string ) ;
extern gchar *g_strup(gchar *string ) ;
extern gchar *g_strdup(gchar const   *str )  __attribute__((__malloc__)) ;
extern gchar *( /* format attribute */  g_strdup_printf)(gchar const   *format  , ...)  __attribute__((__malloc__)) ;
extern gchar *g_strdup_vprintf(gchar const   *format , va_list args )  __attribute__((__malloc__)) ;
extern gchar *g_strndup(gchar const   *str , gsize n )  __attribute__((__malloc__)) ;
extern gchar *g_strnfill(gsize length , gchar fill_char )  __attribute__((__malloc__)) ;
extern gchar *g_strconcat(gchar const   *string1  , ...)  __attribute__((__sentinel__, __malloc__)) ;
extern gchar *g_strjoin(gchar const   *separator  , ...)  __attribute__((__sentinel__, __malloc__)) ;
extern gchar *g_strcompress(gchar const   *source )  __attribute__((__malloc__)) ;
extern gchar *g_strescape(gchar const   *source , gchar const   *exceptions )  __attribute__((__malloc__)) ;
extern gpointer g_memdup(gconstpointer mem , guint byte_size )  __attribute__((__malloc__, __alloc_size__(2))) ;
extern gchar **g_strsplit(gchar const   *string , gchar const   *delimiter , gint max_tokens )  __attribute__((__malloc__)) ;
extern gchar **g_strsplit_set(gchar const   *string , gchar const   *delimiters , gint max_tokens )  __attribute__((__malloc__)) ;
extern gchar *g_strjoinv(gchar const   *separator , gchar **str_array )  __attribute__((__malloc__)) ;
extern void g_strfreev(gchar **str_array ) ;
extern gchar **g_strdupv(gchar **str_array )  __attribute__((__malloc__)) ;
extern guint g_strv_length(gchar **str_array ) ;
extern gchar *g_stpcpy(gchar *dest , char const   *src ) ;
extern gchar const   *g_strip_context(gchar const   *msgid , gchar const   *msgval )  __attribute__((__format_arg__(1))) ;
extern gchar const   *g_dgettext(gchar const   *domain , gchar const   *msgid )  __attribute__((__format_arg__(2))) ;
extern gchar const   *g_dngettext(gchar const   *domain , gchar const   *msgid , gchar const   *msgid_plural , gulong n )  __attribute__((__format_arg__(3))) ;
extern gchar const   *g_dpgettext(gchar const   *domain , gchar const   *msgctxtid , gsize msgidoffset )  __attribute__((__format_arg__(2))) ;
extern gchar const   *g_dpgettext2(gchar const   *domain , gchar const   *context , gchar const   *msgid )  __attribute__((__format_arg__(3))) ;
extern int g_strcmp0(char const   *str1 , char const   *str2 ) ;
extern void ( /* format attribute */  g_test_minimized_result)(double minimized_quantity , char const   *format  , ...) ;
extern void ( /* format attribute */  g_test_maximized_result)(double maximized_quantity , char const   *format  , ...) ;
extern void g_test_init(int *argc , char ***argv  , ...) ;
extern int g_test_run(void) ;
extern void g_test_add_func(char const   *testpath , void (*test_func)(void) ) ;
extern void g_test_add_data_func(char const   *testpath , gconstpointer test_data , void (*test_func)(gconstpointer  ) ) ;
extern void ( /* format attribute */  g_test_message)(char const   *format  , ...) ;
extern void g_test_bug_base(char const   *uri_pattern ) ;
extern void g_test_bug(char const   *bug_uri_snippet ) ;
extern void g_test_timer_start(void) ;
extern double g_test_timer_elapsed(void) ;
extern double g_test_timer_last(void) ;
extern void g_test_queue_free(gpointer gfree_pointer ) ;
extern void g_test_queue_destroy(void (*destroy_func)(gpointer data ) , gpointer destroy_data ) ;
extern gboolean g_test_trap_fork(guint64 usec_timeout , GTestTrapFlags test_trap_flags ) ;
extern gboolean g_test_trap_has_passed(void) ;
extern gboolean g_test_trap_reached_timeout(void) ;
extern gint32 g_test_rand_int(void) ;
extern gint32 g_test_rand_int_range(gint32 begin , gint32 end ) ;
extern double g_test_rand_double(void) ;
extern double g_test_rand_double_range(double range_start , double range_end ) ;
extern GTestCase *g_test_create_case(char const   *test_name , gsize data_size , gconstpointer test_data , void (*data_setup)(void) , void (*data_test)(void) , void (*data_teardown)(void) ) ;
extern GTestSuite *g_test_create_suite(char const   *suite_name ) ;
extern GTestSuite *g_test_get_root(void) ;
extern void g_test_suite_add(GTestSuite *suite , GTestCase *test_case ) ;
extern void g_test_suite_add_suite(GTestSuite *suite , GTestSuite *nestedsuite ) ;
extern int g_test_run_suite(GTestSuite *suite ) ;
extern void g_test_trap_assertions(char const   *domain , char const   *file , int line , char const   *func , guint64 assertion_flags , char const   *pattern ) ;
extern  __attribute__((__noreturn__)) void g_assertion_message(char const   *domain , char const   *file , int line , char const   *func , char const   *message ) ;
extern  __attribute__((__noreturn__)) void g_assertion_message_expr(char const   *domain , char const   *file , int line , char const   *func , char const   *expr ) ;
extern  __attribute__((__noreturn__)) void g_assertion_message_cmpstr(char const   *domain , char const   *file , int line , char const   *func , char const   *expr , char const   *arg1 , char const   *cmp , char const   *arg2 ) ;
extern  __attribute__((__noreturn__)) void g_assertion_message_cmpnum(char const   *domain , char const   *file , int line , char const   *func , char const   *expr , long double arg1 , char const   *cmp , long double arg2 , char numtype ) ;
extern  __attribute__((__noreturn__)) void g_assertion_message_error(char const   *domain , char const   *file , int line , char const   *func , char const   *expr , GError *error , GQuark error_domain , int error_code ) ;
extern void g_test_add_vtable(char const   *testpath , gsize data_size , gconstpointer test_data , void (*data_setup)(void) , void (*data_test)(void) , void (*data_teardown)(void) ) ;
extern GTestConfig const   * const  g_test_config_vars ;
extern char const   *g_test_log_type_name(GTestLogType log_type ) ;
extern GTestLogBuffer *g_test_log_buffer_new(void) ;
extern void g_test_log_buffer_free(GTestLogBuffer *tbuffer ) ;
extern void g_test_log_buffer_push(GTestLogBuffer *tbuffer , guint n_bytes , guint8 const   *bytes ) ;
extern GTestLogMsg *g_test_log_buffer_pop(GTestLogBuffer *tbuffer ) ;
extern void g_test_log_msg_free(GTestLogMsg *tmsg ) ;
extern void g_test_log_set_fatal_handler(gboolean (*log_func)(gchar const   *log_domain , GLogLevelFlags log_level , gchar const   *message , gpointer user_data ) , gpointer user_data ) ;
extern GThreadPool *g_thread_pool_new(void (*func)(gpointer data , gpointer user_data ) , gpointer user_data , gint max_threads , gboolean exclusive , GError **error ) ;
extern void g_thread_pool_push(GThreadPool *pool , gpointer data , GError **error ) ;
extern void g_thread_pool_set_max_threads(GThreadPool *pool , gint max_threads , GError **error ) ;
extern gint g_thread_pool_get_max_threads(GThreadPool *pool ) ;
extern guint g_thread_pool_get_num_threads(GThreadPool *pool ) ;
extern guint g_thread_pool_unprocessed(GThreadPool *pool ) ;
extern void g_thread_pool_free(GThreadPool *pool , gboolean immediate , gboolean wait_ ) ;
extern void g_thread_pool_set_max_unused_threads(gint max_threads ) ;
extern gint g_thread_pool_get_max_unused_threads(void) ;
extern guint g_thread_pool_get_num_unused_threads(void) ;
extern void g_thread_pool_stop_unused_threads(void) ;
extern void g_thread_pool_set_sort_function(GThreadPool *pool , gint (*func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer user_data ) ;
extern void g_thread_pool_set_max_idle_time(guint interval ) ;
extern guint g_thread_pool_get_max_idle_time(void) ;
extern GTimer *g_timer_new(void) ;
extern void g_timer_destroy(GTimer *timer ) ;
extern void g_timer_start(GTimer *timer ) ;
extern void g_timer_stop(GTimer *timer ) ;
extern void g_timer_reset(GTimer *timer ) ;
extern void g_timer_continue(GTimer *timer ) ;
extern gdouble g_timer_elapsed(GTimer *timer , gulong *microseconds ) ;
extern void g_usleep(gulong microseconds ) ;
extern void g_time_val_add(GTimeVal *time_ , glong microseconds ) ;
extern gboolean g_time_val_from_iso8601(gchar const   *iso_date , GTimeVal *time_ ) ;
extern gchar *g_time_val_to_iso8601(GTimeVal *time_ )  __attribute__((__malloc__)) ;
extern GTree *g_tree_new(gint (*key_compare_func)(gconstpointer a , gconstpointer b ) ) ;
extern GTree *g_tree_new_with_data(gint (*key_compare_func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer key_compare_data ) ;
extern GTree *g_tree_new_full(gint (*key_compare_func)(gconstpointer a , gconstpointer b , gpointer user_data ) , gpointer key_compare_data , void (*key_destroy_func)(gpointer data ) , void (*value_destroy_func)(gpointer data ) ) ;
extern GTree *g_tree_ref(GTree *tree ) ;
extern void g_tree_unref(GTree *tree ) ;
extern void g_tree_destroy(GTree *tree ) ;
extern void g_tree_insert(GTree *tree , gpointer key , gpointer value ) ;
extern void g_tree_replace(GTree *tree , gpointer key , gpointer value ) ;
extern gboolean g_tree_remove(GTree *tree , gconstpointer key ) ;
extern gboolean g_tree_steal(GTree *tree , gconstpointer key ) ;
extern gpointer g_tree_lookup(GTree *tree , gconstpointer key ) ;
extern gboolean g_tree_lookup_extended(GTree *tree , gconstpointer lookup_key , gpointer *orig_key , gpointer *value ) ;
extern void g_tree_foreach(GTree *tree , gboolean (*func)(gpointer key , gpointer value , gpointer data ) , gpointer user_data ) ;
extern void g_tree_traverse(GTree *tree , gboolean (*traverse_func)(gpointer key , gpointer value , gpointer data ) , GTraverseType traverse_type , gpointer user_data ) ;
extern gpointer g_tree_search(GTree *tree , gint (*search_func)(gconstpointer a , gconstpointer b ) , gconstpointer user_data ) ;
extern gint g_tree_height(GTree *tree ) ;
extern gint g_tree_nnodes(GTree *tree ) ;
extern char *g_uri_unescape_string(char const   *escaped_string , char const   *illegal_characters ) ;
extern char *g_uri_unescape_segment(char const   *escaped_string , char const   *escaped_string_end , char const   *illegal_characters ) ;
extern char *g_uri_parse_scheme(char const   *uri ) ;
extern char *g_uri_escape_string(char const   *unescaped , char const   *reserved_chars_allowed , gboolean allow_utf8 ) ;
extern gboolean g_variant_type_string_is_valid(gchar const   *type_string ) ;
extern gboolean g_variant_type_string_scan(gchar const   *string , gchar const   *limit , gchar const   **endptr ) ;
extern void g_variant_type_free(GVariantType *type ) ;
extern GVariantType *g_variant_type_copy(GVariantType const   *type ) ;
extern GVariantType *g_variant_type_new(gchar const   *type_string ) ;
extern gsize g_variant_type_get_string_length(GVariantType const   *type ) ;
extern gchar const   *g_variant_type_peek_string(GVariantType const   *type ) ;
extern gchar *g_variant_type_dup_string(GVariantType const   *type ) ;
extern gboolean g_variant_type_is_definite(GVariantType const   *type ) ;
extern gboolean g_variant_type_is_container(GVariantType const   *type ) ;
extern gboolean g_variant_type_is_basic(GVariantType const   *type ) ;
extern gboolean g_variant_type_is_maybe(GVariantType const   *type ) ;
extern gboolean g_variant_type_is_array(GVariantType const   *type ) ;
extern gboolean g_variant_type_is_tuple(GVariantType const   *type ) ;
extern gboolean g_variant_type_is_dict_entry(GVariantType const   *type ) ;
extern gboolean g_variant_type_is_variant(GVariantType const   *type ) ;
extern guint g_variant_type_hash(gconstpointer type ) ;
extern gboolean g_variant_type_equal(gconstpointer type1 , gconstpointer type2 ) ;
extern gboolean g_variant_type_is_subtype_of(GVariantType const   *type , GVariantType const   *supertype ) ;
extern GVariantType const   *g_variant_type_element(GVariantType const   *type ) ;
extern GVariantType const   *g_variant_type_first(GVariantType const   *type ) ;
extern GVariantType const   *g_variant_type_next(GVariantType const   *type ) ;
extern gsize g_variant_type_n_items(GVariantType const   *type ) ;
extern GVariantType const   *g_variant_type_key(GVariantType const   *type ) ;
extern GVariantType const   *g_variant_type_value(GVariantType const   *type ) ;
extern GVariantType *g_variant_type_new_array(GVariantType const   *element ) ;
extern GVariantType *g_variant_type_new_maybe(GVariantType const   *element ) ;
extern GVariantType *g_variant_type_new_tuple(GVariantType const   * const  *items , gint length ) ;
extern GVariantType *g_variant_type_new_dict_entry(GVariantType const   *key , GVariantType const   *value ) ;
extern GVariantType const   *g_variant_type_checked_(gchar const   * ) ;
extern void g_variant_unref(GVariant *value ) ;
extern GVariant *g_variant_ref(GVariant *value ) ;
extern GVariant *g_variant_ref_sink(GVariant *value ) ;
extern GVariantType const   *g_variant_get_type(GVariant *value ) ;
extern gchar const   *g_variant_get_type_string(GVariant *value ) ;
extern gboolean g_variant_is_of_type(GVariant *value , GVariantType const   *type ) ;
extern gboolean g_variant_is_container(GVariant *value ) ;
extern GVariantClass g_variant_classify(GVariant *value ) ;
extern GVariant *g_variant_new_boolean(gboolean boolean ) ;
extern GVariant *g_variant_new_byte(guchar byte ) ;
extern GVariant *g_variant_new_int16(gint16 int16 ) ;
extern GVariant *g_variant_new_uint16(guint16 uint16 ) ;
extern GVariant *g_variant_new_int32(gint32 int32 ) ;
extern GVariant *g_variant_new_uint32(guint32 uint32 ) ;
extern GVariant *g_variant_new_int64(gint64 int64 ) ;
extern GVariant *g_variant_new_uint64(guint64 uint64 ) ;
extern GVariant *g_variant_new_handle(gint32 handle ) ;
extern GVariant *g_variant_new_double(gdouble floating ) ;
extern GVariant *g_variant_new_string(gchar const   *string ) ;
extern GVariant *g_variant_new_object_path(gchar const   *object_path ) ;
extern gboolean g_variant_is_object_path(gchar const   *string ) ;
extern GVariant *g_variant_new_signature(gchar const   *signature ) ;
extern gboolean g_variant_is_signature(gchar const   *string ) ;
extern GVariant *g_variant_new_variant(GVariant *value ) ;
extern GVariant *g_variant_new_strv(gchar const   * const  *strv , gssize length ) ;
extern gboolean g_variant_get_boolean(GVariant *value ) ;
extern guchar g_variant_get_byte(GVariant *value ) ;
extern gint16 g_variant_get_int16(GVariant *value ) ;
extern guint16 g_variant_get_uint16(GVariant *value ) ;
extern gint32 g_variant_get_int32(GVariant *value ) ;
extern guint32 g_variant_get_uint32(GVariant *value ) ;
extern gint64 g_variant_get_int64(GVariant *value ) ;
extern guint64 g_variant_get_uint64(GVariant *value ) ;
extern gint32 g_variant_get_handle(GVariant *value ) ;
extern gdouble g_variant_get_double(GVariant *value ) ;
extern GVariant *g_variant_get_variant(GVariant *value ) ;
extern gchar const   *g_variant_get_string(GVariant *value , gsize *length ) ;
extern gchar *g_variant_dup_string(GVariant *value , gsize *length ) ;
extern gchar const   **g_variant_get_strv(GVariant *value , gsize *length ) ;
extern gchar **g_variant_dup_strv(GVariant *value , gsize *length ) ;
extern GVariant *g_variant_new_maybe(GVariantType const   *child_type , GVariant *child ) ;
extern GVariant *g_variant_new_array(GVariantType const   *child_type , GVariant * const  *children , gsize n_children ) ;
extern GVariant *g_variant_new_tuple(GVariant * const  *children , gsize n_children ) ;
extern GVariant *g_variant_new_dict_entry(GVariant *key , GVariant *value ) ;
extern GVariant *g_variant_get_maybe(GVariant *value ) ;
extern gsize g_variant_n_children(GVariant *value ) ;
extern void g_variant_get_child(GVariant *value , gsize index_ , gchar const   *format_string  , ...) ;
extern GVariant *g_variant_get_child_value(GVariant *value , gsize index_ ) ;
extern gconstpointer g_variant_get_fixed_array(GVariant *value , gsize *n_elements , gsize element_size ) ;
extern gsize g_variant_get_size(GVariant *value ) ;
extern gconstpointer g_variant_get_data(GVariant *value ) ;
extern void g_variant_store(GVariant *value , gpointer data ) ;
extern gchar *g_variant_print(GVariant *value , gboolean type_annotate ) ;
extern GString *g_variant_print_string(GVariant *value , GString *string , gboolean type_annotate ) ;
extern guint g_variant_hash(gconstpointer value ) ;
extern gboolean g_variant_equal(gconstpointer one , gconstpointer two ) ;
extern GVariant *g_variant_get_normal_form(GVariant *value ) ;
extern gboolean g_variant_is_normal_form(GVariant *value ) ;
extern GVariant *g_variant_byteswap(GVariant *value ) ;
extern GVariant *g_variant_new_from_data(GVariantType const   *type , gconstpointer data , gsize size , gboolean trusted , void (*notify)(gpointer data ) , gpointer user_data ) ;
extern GVariantIter *g_variant_iter_new(GVariant *value ) ;
extern gsize g_variant_iter_init(GVariantIter *iter , GVariant *value ) ;
extern GVariantIter *g_variant_iter_copy(GVariantIter *iter ) ;
extern gsize g_variant_iter_n_children(GVariantIter *iter ) ;
extern void g_variant_iter_free(GVariantIter *iter ) ;
extern GVariant *g_variant_iter_next_value(GVariantIter *iter ) ;
extern gboolean g_variant_iter_next(GVariantIter *iter , gchar const   *format_string  , ...) ;
extern gboolean g_variant_iter_loop(GVariantIter *iter , gchar const   *format_string  , ...) ;
extern GQuark g_variant_parser_get_error_quark(void) ;
extern GVariantBuilder *g_variant_builder_new(GVariantType const   *type ) ;
extern void g_variant_builder_unref(GVariantBuilder *builder ) ;
extern GVariantBuilder *g_variant_builder_ref(GVariantBuilder *builder ) ;
extern void g_variant_builder_init(GVariantBuilder *builder , GVariantType const   *type ) ;
extern GVariant *g_variant_builder_end(GVariantBuilder *builder ) ;
extern void g_variant_builder_clear(GVariantBuilder *builder ) ;
extern void g_variant_builder_open(GVariantBuilder *builder , GVariantType const   *type ) ;
extern void g_variant_builder_close(GVariantBuilder *builder ) ;
extern void g_variant_builder_add_value(GVariantBuilder *builder , GVariant *value ) ;
extern void g_variant_builder_add(GVariantBuilder *builder , gchar const   *format_string  , ...) ;
extern GVariant *g_variant_new(gchar const   *format_string  , ...) ;
extern void g_variant_get(GVariant *value , gchar const   *format_string  , ...) ;
extern GVariant *g_variant_new_va(gchar const   *format_string , gchar const   **endptr , va_list *app ) ;
extern void g_variant_get_va(GVariant *value , gchar const   *format_string , gchar const   **endptr , va_list *app ) ;
extern GVariant *g_variant_parse(GVariantType const   *type , gchar const   *text , gchar const   *limit , gchar const   **endptr , GError **error ) ;
extern GVariant *g_variant_new_parsed(gchar const   *format  , ...) ;
extern GVariant *g_variant_new_parsed_va(gchar const   *format , va_list *app ) ;
extern  __attribute__((__nothrow__)) ssize_t sendfile(int __out_fd , int __in_fd , __off64_t *__offset , size_t __count )  __asm__("sendfile64")  ;
extern ssize_t readv(int __fd , struct iovec  const  *__iovec , int __count ) ;
extern ssize_t writev(int __fd , struct iovec  const  *__iovec , int __count ) ;
extern ssize_t preadv(int __fd , struct iovec  const  *__iovec , int __count , __off64_t __offset )  __asm__("preadv64")  ;
extern ssize_t pwritev(int __fd , struct iovec  const  *__iovec , int __count , __off64_t __offset )  __asm__("pwritev64")  ;
extern  __attribute__((__nothrow__)) void *mmap(void *__addr , size_t __len , int __prot , int __flags , int __fd , __off64_t __offset )  __asm__("mmap64")  ;
extern  __attribute__((__nothrow__)) int munmap(void *__addr , size_t __len ) ;
extern  __attribute__((__nothrow__)) int mprotect(void *__addr , size_t __len , int __prot ) ;
extern int msync(void *__addr , size_t __len , int __flags ) ;
extern  __attribute__((__nothrow__)) int madvise(void *__addr , size_t __len , int __advice ) ;
extern  __attribute__((__nothrow__)) int posix_madvise(void *__addr , size_t __len , int __advice ) ;
extern  __attribute__((__nothrow__)) int mlock(void const   *__addr , size_t __len ) ;
extern  __attribute__((__nothrow__)) int munlock(void const   *__addr , size_t __len ) ;
extern  __attribute__((__nothrow__)) int mlockall(int __flags ) ;
extern  __attribute__((__nothrow__)) int munlockall(void) ;
extern  __attribute__((__nothrow__)) int mincore(void *__start , size_t __len , unsigned char *__vec ) ;
extern int shm_open(char const   *__name , int __oflag , mode_t __mode ) ;
extern int shm_unlink(char const   *__name ) ;
extern buffer_ptr *buffer_ptr_init(void (*freer)(void *p ) ) ;
extern void buffer_ptr_free(buffer_ptr *b ) ;
extern void buffer_ptr_clear(buffer_ptr *b ) ;
extern void buffer_ptr_append(buffer_ptr *b , void *item ) ;
extern void *buffer_ptr_pop(buffer_ptr *b ) ;
extern void *buffer_ptr_top(buffer_ptr *b ) ;
extern buffer_array *buffer_array_init(void) ;
extern void buffer_array_free(buffer_array *b ) ;
extern void buffer_array_reset(buffer_array *b ) ;
extern buffer *buffer_array_append_get_buffer(buffer_array *b ) ;
extern buffer *buffer_init(void) ;
extern buffer *buffer_init_buffer(buffer *b ) ;
extern buffer *buffer_init_string(char const   *str ) ;
extern void buffer_free(buffer *b ) ;
extern void buffer_reset(buffer *b ) ;
extern int buffer_prepare_copy(buffer *b , size_t size ) ;
extern int buffer_prepare_append(buffer *b , size_t size ) ;
extern int buffer_copy_string(buffer *b , char const   *s ) ;
extern int buffer_copy_string_len(buffer *b , char const   *s , size_t s_len ) ;
extern int buffer_copy_string_buffer(buffer *b , buffer const   *src ) ;
extern int buffer_copy_string_hex(buffer *b , char const   *in , size_t in_len ) ;
extern int buffer_copy_long(buffer *b , long val ) ;
extern int buffer_copy_memory(buffer *b , char const   *s , size_t s_len ) ;
extern int buffer_append_string(buffer *b , char const   *s ) ;
extern int buffer_append_string_len(buffer *b , char const   *s , size_t s_len ) ;
extern int buffer_append_string_buffer(buffer *b , buffer const   *src ) ;
extern int buffer_append_string_lfill(buffer *b , char const   *s , size_t maxlen ) ;
extern int buffer_append_string_rfill(buffer *b , char const   *s , size_t maxlen ) ;
extern int buffer_append_long_hex(buffer *b , unsigned long len ) ;
extern int buffer_append_long(buffer *b , long val ) ;
extern int buffer_copy_off_t(buffer *b , off_t val ) ;
extern int buffer_append_off_t(buffer *b , off_t val ) ;
extern int buffer_append_memory(buffer *b , char const   *s , size_t s_len ) ;
extern char *buffer_search_string_len(buffer *b , char const   *needle , size_t len ) ;
extern int buffer_is_empty(buffer *b ) ;
extern int buffer_is_equal(buffer *a , buffer *b ) ;
extern int buffer_is_equal_right_len(buffer *a , buffer *b , size_t len ) ;
extern int buffer_is_equal_string(buffer *a , char const   *s , size_t b_len ) ;
extern int buffer_caseless_compare(char const   *a , size_t a_len , char const   *b , size_t b_len ) ;
extern int buffer_append_string_encoded(buffer *b , char const   *s , size_t s_len , buffer_encoding_t encoding ) ;
extern int buffer_urldecode_path(buffer *url ) ;
extern int buffer_urldecode_query(buffer *url ) ;
extern int buffer_path_simplify(buffer *dest , buffer *src ) ;
extern int buffer_to_lower(buffer *b ) ;
extern int buffer_to_upper(buffer *b ) ;
extern int LI_ltostr(char *buf , long val ) ;
extern char hex2int(unsigned char c ) ;
extern char int2hex(char i ) ;
extern int light_isdigit(int c ) ;
extern int light_isxdigit(int c ) ;
extern int light_isalpha(int c ) ;
extern int light_isalnum(int c ) ;
extern int buffer_isdigit(buffer *b ) ;
extern int buffer_isxdigit(buffer *b ) ;
extern int buffer_isalpha(buffer *b ) ;
extern int buffer_isalnum(buffer *b ) ;
extern buffer_pool *buffer_pool_init() ;
extern void buffer_pool_free(buffer_pool * ) ;
extern buffer *buffer_pool_get(buffer_pool *bp ) ;
extern void buffer_pool_append(buffer_pool *bp , buffer * ) ;
extern void log_init(void) ;
extern void log_free(void) ;
extern int log_error_open(buffer *file , int use_syslog ) ;
extern int log_error_close() ;
extern int log_error_write(void *srv , char const   *filename , unsigned int line , char const   *fmt  , ...) ;
extern int log_error_cycle() ;
extern char const   *remove_path(char const   *path ) ;
extern int ( /* format attribute */  log_trace)(char const   *fmt  , ...) ;
extern void *(*pcre_malloc)(size_t  ) ;
extern void (*pcre_free)(void * ) ;
extern void *(*pcre_stack_malloc)(size_t  ) ;
extern void (*pcre_stack_free)(void * ) ;
extern int (*pcre_callout)(pcre_callout_block * ) ;
extern pcre *pcre_compile(char const   * , int  , char const   ** , int * , unsigned char const   * ) ;
extern pcre *pcre_compile2(char const   * , int  , int * , char const   ** , int * , unsigned char const   * ) ;
extern int pcre_config(int  , void * ) ;
extern int pcre_copy_named_substring(pcre const   * , char const   * , int * , int  , char const   * , char * , int  ) ;
extern int pcre_copy_substring(char const   * , int * , int  , int  , char * , int  ) ;
extern int pcre_dfa_exec(pcre const   * , pcre_extra const   * , char const   * , int  , int  , int  , int * , int  , int * , int  ) ;
extern int pcre_exec(pcre const   * , pcre_extra const   * , char const   * , int  , int  , int  , int * , int  ) ;
extern void pcre_free_substring(char const   * ) ;
extern void pcre_free_substring_list(char const   ** ) ;
extern int pcre_fullinfo(pcre const   * , pcre_extra const   * , int  , void * ) ;
extern int pcre_get_named_substring(pcre const   * , char const   * , int * , int  , char const   * , char const   ** ) ;
extern int pcre_get_stringnumber(pcre const   * , char const   * ) ;
extern int pcre_get_stringtable_entries(pcre const   * , char const   * , char ** , char ** ) ;
extern int pcre_get_substring(char const   * , int * , int  , int  , char const   ** ) ;
extern int pcre_get_substring_list(char const   * , int * , int  , char const   *** ) ;
extern int pcre_info(pcre const   * , int * , int * ) ;
extern unsigned char const   *pcre_maketables(void) ;
extern int pcre_refcount(pcre * , int  ) ;
extern pcre_extra *pcre_study(pcre const   * , int  , char const   ** ) ;
extern char const   *pcre_version(void) ;
extern data_count *data_count_init(void) ;
extern data_string *data_string_init(void) ;
extern data_string *data_response_init(void) ;
extern data_array *data_array_init(void) ;
extern data_config *data_config_init(void) ;
extern data_integer *data_integer_init(void) ;
extern array *array_init(void) ;
extern array *array_init_array(array *a ) ;
extern void array_free(array *a ) ;
extern void array_reset(array *a ) ;
extern int array_insert_unique(array *a , data_unset *str ) ;
extern data_unset *array_pop(array *a ) ;
extern int array_print(array *a , int depth ) ;
extern data_unset *array_get_unused_element(array *a , data_type_t t ) ;
extern data_unset *array_get_element(array *a , char const   *key , size_t key_len ) ;
extern void array_set_key_value(array *hdrs , char const   *key , size_t key_len , char const   *value , size_t val_len ) ;
extern void array_append_key_value(array *hdrs , char const   *key , size_t key_len , char const   *value , size_t val_len ) ;
extern data_unset *array_replace(array *a , data_unset *du ) ;
extern int array_strcasecmp(char const   *a , size_t a_len , char const   *b , size_t b_len ) ;
extern void array_print_indent(int depth ) ;
extern size_t array_get_max_key_length(array *a ) ;
extern chunkqueue *chunkqueue_init(void) ;
extern int chunkqueue_set_tempdirs(chunkqueue *c , array *tempdirs ) ;
extern int chunkqueue_append_file(chunkqueue *c , buffer *fn , off_t offset , off_t len ) ;
extern int chunkqueue_append_mem(chunkqueue *c , char const   *mem , size_t len ) ;
extern int chunkqueue_append_buffer(chunkqueue *c , buffer *mem ) ;
extern int chunkqueue_prepend_buffer(chunkqueue *c , buffer *mem ) ;
extern buffer *chunkqueue_get_append_buffer(chunkqueue *c ) ;
extern buffer *chunkqueue_get_prepend_buffer(chunkqueue *c ) ;
extern chunk *chunkqueue_get_append_tempfile(chunkqueue *cq ) ;
extern int chunkqueue_steal_tempfile(chunkqueue *cq , chunk *in ) ;
extern off_t chunkqueue_steal_chunk(chunkqueue *cq , chunk *c ) ;
extern off_t chunkqueue_steal_chunks_len(chunkqueue *cq , chunk *c , off_t max_len ) ;
extern off_t chunkqueue_steal_all_chunks(chunkqueue *cq , chunkqueue *in ) ;
extern off_t chunkqueue_skip(chunkqueue *cq , off_t skip ) ;
extern void chunkqueue_remove_empty_last_chunk(chunkqueue *cq ) ;
extern int chunkqueue_remove_finished_chunks(chunkqueue *cq ) ;
extern off_t chunkqueue_length(chunkqueue *c ) ;
extern off_t chunkqueue_written(chunkqueue *c ) ;
extern void chunkqueue_free(chunkqueue *c ) ;
extern void chunkqueue_reset(chunkqueue *c ) ;
extern int chunkqueue_is_empty(chunkqueue *c ) ;
extern void chunkqueue_print(chunkqueue *cq ) ;
extern int chunk_is_done(chunk *c ) ;
extern void chunk_set_done(chunk *c ) ;
http_resp *http_response_init(void) ;
void http_response_free(http_resp *resp ) ;
void http_response_reset(http_resp *resp ) ;
parse_status_t http_response_parse_cq(chunkqueue *cq , http_resp *resp ) ;
extern void *http_resp_parserAlloc(void *(*mallocProc)(size_t  ) ) ;
extern void http_resp_parserFree(void *p , void (*freeProc)(void * ) ) ;
extern void http_resp_parserTrace(FILE *TraceFILE , char *zTracePrompt ) ;
extern void http_resp_parser(void * , int  , buffer * , http_resp_ctx_t * ) ;
http_resp *http_response_init(void) 
{ http_resp *resp ;
  void *tmp ;

  {
  tmp = calloc(1U, sizeof(*resp));
  resp = (http_resp *)tmp;
  resp->reason = buffer_init();
  resp->headers = array_init();
  resp->status = -1;
  return (resp);
}
}
void http_response_reset(http_resp *resp ) 
{ 

  {
  if (! resp) {
    return;
  } else {

  }
  buffer_reset(resp->reason);
  array_reset(resp->headers);
  resp->status = -1;
  return;
}
}
void http_response_free(http_resp *resp ) 
{ 

  {
  if (! resp) {
    return;
  } else {

  }
  buffer_free(resp->reason);
  array_free(resp->headers);
  free((void *)resp);
  return;
}
}
static int http_resp_get_next_char(http_resp_tokenizer_t *t , unsigned char *c ) 
{ size_t tmp ;

  {
  if (t->offset == ((t->c)->mem)->used - 1U) {
    if (! (t->c)->next) {
      return (-1);
    } else {

    }
    t->c = (t->c)->next;
    t->offset = 0U;
  } else {

  }
  tmp = t->offset;
  (t->offset) ++;
  *c = (unsigned char )*(((t->c)->mem)->ptr + tmp);
  t->lookup_offset = t->offset;
  t->lookup_c = t->c;
  return (0);
}
}
static int http_resp_lookup_next_char(http_resp_tokenizer_t *t , unsigned char *c ) 
{ size_t tmp ;

  {
  if (t->lookup_offset == ((t->lookup_c)->mem)->used - 1U) {
    if (! (t->lookup_c)->next) {
      return (-1);
    } else {

    }
    t->lookup_c = (t->lookup_c)->next;
    t->lookup_offset = 0U;
  } else {

  }
  tmp = t->lookup_offset;
  (t->lookup_offset) ++;
  *c = (unsigned char )*(((t->lookup_c)->mem)->ptr + tmp);
  return (0);
}
}
static int http_resp_tokenizer(http_resp_tokenizer_t *t , int *token_id , buffer *token ) 
{ unsigned char c ;
  int tid ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  tid = 0;
  while (1) {
    if (tid == 0) {
      tmp___1 = http_resp_get_next_char(t, & c);
      if (0 == tmp___1) {

      } else {
        break;
      }
    } else {
      break;
    }
    switch ((int )c) {
    case 58: 
    tid = 3;
    t->is_key = 0;
    break;
    case 32: 
    case 9: 
    break;
    case 13: 
    tmp = http_resp_lookup_next_char(t, & c);
    if (0 != tmp) {
      return (-1);
    } else {

    }
    if ((int )c == 10) {
      tid = 1;
      t->c = t->lookup_c;
      t->offset = t->lookup_offset;
      t->is_statusline = 0;
      t->is_key = 1;
    } else {
      fprintf((FILE */* __restrict  */)stderr, (char const   */* __restrict  */)"%s.%d: CR with out LF\r\n", "http_resp.c", 133);
      return (-1);
    }
    break;
    case 10: 
    tid = 1;
    t->is_statusline = 0;
    t->is_key = 1;
    break;
    default: ;
    while (1) {
      if ((int )c >= 32) {
        if ((int )c != 127) {
          if ((int )c != 255) {

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
      if (t->is_statusline) {
        if ((int )c == 58) {
          t->is_statusline = 0;
          break;
        } else {

        }
        if ((int )c == 32) {
          break;
        } else {

        }
      } else {
        if (t->is_key) {
          if ((int )c == 58) {
            break;
          } else {

          }
        } else {

        }
      }
      tmp___0 = http_resp_lookup_next_char(t, & c);
      if (0 != tmp___0) {
        return (-1);
      } else {

      }
    }
    if ((unsigned int )t->c == (unsigned int )t->lookup_c) {
      if (t->offset == t->lookup_offset + 1U) {
        fprintf((FILE */* __restrict  */)stderr, (char const   */* __restrict  */)"%s.%d: invalid char in string\n", "http_resp.c", 160);
        return (-1);
      } else {

      }
    } else {

    }
    tid = 2;
    (t->lookup_offset) --;
    if ((unsigned int )t->c == (unsigned int )t->lookup_c) {
      buffer_copy_string_len(token, (char const   *)((((t->c)->mem)->ptr + t->offset) - 1), (t->lookup_offset - t->offset) + 1U);
    } else {
      buffer_copy_string_len(token, (char const   *)((((t->c)->mem)->ptr + t->offset) - 1), ((t->c)->mem)->used - t->offset);
      t->c = (t->c)->next;
      while ((unsigned int )t->c != (unsigned int )t->lookup_c) {
        buffer_append_string_buffer(token, (buffer const   *)(t->c)->mem);
        t->offset = ((t->c)->mem)->used - 1U;
        t->c = (t->c)->next;
      }
      buffer_append_string_len(token, (char const   *)((t->c)->mem)->ptr, t->lookup_offset);
    }
    t->offset = t->lookup_offset;
    break;
    }
  }
  if (tid) {
    *token_id = tid;
    return (1);
  } else {

  }
  return (-1);
}
}
parse_status_t http_response_parse_cq(chunkqueue *cq , http_resp *resp ) 
{ http_resp_tokenizer_t t ;
  void *pParser ;
  int token_id ;
  buffer *token ;
  http_resp_ctx_t context ;
  parse_status_t ret ;
  int last_token_id ;
  int tmp ;
  char const   *tmp___0 ;
  char const   *tmp___1 ;
  char const   *tmp___2 ;
  int tmp___3 ;
  char const   *tmp___4 ;
  char const   *tmp___5 ;
  int tmp___6 ;
  char const   *tmp___7 ;
  char const   *tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  chunk *c ;

  {
  pParser = (void *)0;
  token_id = 0;
  token = (buffer *)((void *)0);
  ret = (parse_status_t )0;
  last_token_id = 0;
  if (! cq->first) {
    return ((enum __anonenum_parse_status_t_125 )3);
  } else {

  }
  t.cq = cq;
  t.c = cq->first;
  t.offset = (unsigned int )(t.c)->offset;
  t.is_key = 0;
  t.is_statusline = 1;
  context.ok = 1;
  context.errmsg = buffer_init();
  context.resp = resp;
  context.unused_buffers = buffer_pool_init();
  array_reset(resp->headers);
  pParser = http_resp_parserAlloc(& malloc);
  token = buffer_pool_get(context.unused_buffers);
  while (1) {
    tmp = http_resp_tokenizer(& t, & token_id, token);
    if (1 == tmp) {
      if (context.ok) {

      } else {
        break;
      }
    } else {
      break;
    }
    http_resp_parser(pParser, token_id, token, & context);
    token = buffer_pool_get(context.unused_buffers);
    if (last_token_id == 1) {
      if (token_id == 1) {
        break;
      } else {

      }
    } else {

    }
    last_token_id = token_id;
  }
  if (context.ok == 0) {
    ret = (enum __anonenum_parse_status_t_125 )2;
    tmp___3 = buffer_is_empty(context.errmsg);
    if (tmp___3) {
      tmp___2 = remove_path("http_resp.c");
      log_trace("%s.%d: (trace) %s", tmp___2, 249, "parsing failed ...");
    } else {
      if (context.errmsg) {
        if ((context.errmsg)->ptr) {
          tmp___0 = (char const   *)(context.errmsg)->ptr;
        } else {
          tmp___0 = "(null)";
        }
      } else {
        tmp___0 = "(null)";
      }
      tmp___1 = remove_path("http_resp.c");
      log_trace("%s.%d: (trace) parsing failed: %s", tmp___1, 247, tmp___0);
    }
  } else {

  }
  http_resp_parser(pParser, 0, token, & context);
  http_resp_parserFree(pParser, & free);
  tmp___6 = buffer_is_empty(context.errmsg);
  if (tmp___6) {

  } else {
    if (context.errmsg) {
      if ((context.errmsg)->ptr) {
        tmp___4 = (char const   *)(context.errmsg)->ptr;
      } else {
        tmp___4 = "(null)";
      }
    } else {
      tmp___4 = "(null)";
    }
    tmp___5 = remove_path("http_resp.c");
    log_trace("%s.%d: (trace) parsing failed: %s", tmp___5, 257, tmp___4);
  }
  if (context.ok == 0) {
    tmp___9 = buffer_is_empty(context.errmsg);
    if (tmp___9) {

    } else {
      if (context.errmsg) {
        if ((context.errmsg)->ptr) {
          tmp___7 = (char const   *)(context.errmsg)->ptr;
        } else {
          tmp___7 = "(null)";
        }
      } else {
        tmp___7 = "(null)";
      }
      tmp___8 = remove_path("http_resp.c");
      log_trace("%s.%d: (trace) parsing failed: %s", tmp___8, 263, tmp___7);
    }
    if ((unsigned int )ret == 0U) {
      tmp___11 = buffer_is_empty(context.errmsg);
      if (tmp___11) {
        ret = (enum __anonenum_parse_status_t_125 )3;
      } else {
        ret = (enum __anonenum_parse_status_t_125 )2;
      }
    } else {

    }
  } else {
    c = cq->first;
    while ((unsigned int )c != (unsigned int )t.c) {
      c->offset = (long long )((c->mem)->used - 1U);
      cq->bytes_out += (off_t )((c->mem)->used - 1U);
      c = c->next;
    }
    c->offset = (long long )t.offset;
    cq->bytes_out += (off_t )t.offset;
    ret = (enum __anonenum_parse_status_t_125 )1;
  }
  buffer_pool_append(context.unused_buffers, token);
  buffer_pool_free(context.unused_buffers);
  buffer_free(context.errmsg);
  return (ret);
}
}
