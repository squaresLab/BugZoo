<?php
$attr = new DOMAttr('category');
$attr->value = 1;
print $attr->value;
?>
