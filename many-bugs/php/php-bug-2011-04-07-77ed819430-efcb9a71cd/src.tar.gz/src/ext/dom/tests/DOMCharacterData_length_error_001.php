<?php
$character_data = new DOMCharacterData();
print $character_data->length;
?>
===DONE===
