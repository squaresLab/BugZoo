<?php
	$x = new DomDocument();
	$x->createComment();
?>
===DONE===
