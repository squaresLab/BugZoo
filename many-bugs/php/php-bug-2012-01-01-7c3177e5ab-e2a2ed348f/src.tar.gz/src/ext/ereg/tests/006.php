<?php $a="This is a nice and simple string";
  echo ereg_replace("^This","That",$a);
?>
