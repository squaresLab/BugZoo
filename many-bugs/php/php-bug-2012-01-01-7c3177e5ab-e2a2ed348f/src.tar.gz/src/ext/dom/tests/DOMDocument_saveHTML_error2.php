<?php
DOMDocument::saveHTML(true);
?>
