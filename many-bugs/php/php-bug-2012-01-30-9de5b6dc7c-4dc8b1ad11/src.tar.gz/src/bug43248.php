<?php
echo realpath(dirname(__FILE__) . '/../file/');
?>
