<?php
var_dump(date_parse_from_format()); // invalid parameters
?>
