<?php
var_dump(date_add()); // invalid parameters
?>
