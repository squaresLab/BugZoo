<?php
var_dump(strtotime('mayy 2 2009')); // misspelled month name
?>
