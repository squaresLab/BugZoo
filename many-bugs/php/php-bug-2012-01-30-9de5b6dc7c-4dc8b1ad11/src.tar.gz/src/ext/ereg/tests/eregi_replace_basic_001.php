<?php
/* Prototype  : proto string eregi_replace(string pattern, string replacement, string string)
 * Description: Replace regular expression 
 * Source code: ext/standard/reg.c
 * Alias to functions: 
 */

/*
 * Test a number of simple, valid matches with eregi_replace
 */

echo "*** Testing ereg() : basic functionality ***\n";

include(dirname(__FILE__) . '/regular_expressions.inc');

$replacement = '[this is a replacement]';

foreach ($expressions as $re) {
	list($pattern, $match) = $re;
	echo "--> Pattern: '$pattern'; match: '$match'\n";
	var_dump(eregi_replace($pattern, $replacement, $match . ' this contains some matches ' . $match));
}

echo "Done";
?>
