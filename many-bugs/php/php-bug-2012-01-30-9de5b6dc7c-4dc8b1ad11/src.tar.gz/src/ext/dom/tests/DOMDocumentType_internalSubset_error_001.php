<?php
$doctype = new DOMDocumentType();
$internalSubset = $doctype->internalSubset;
?>
