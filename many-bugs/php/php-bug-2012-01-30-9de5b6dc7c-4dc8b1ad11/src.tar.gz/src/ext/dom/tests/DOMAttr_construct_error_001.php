<?php
$attr = new DOMAttr();
?>
