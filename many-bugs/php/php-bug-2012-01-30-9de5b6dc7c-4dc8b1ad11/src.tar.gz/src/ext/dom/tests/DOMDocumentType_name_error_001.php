<?php
$doctype = new DOMDocumentType();
$name = $doctype->name;
?>
