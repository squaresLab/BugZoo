#!/bin/sh

./sapi/cli/php   -d "=" -f "/root/mountpoint-genprog/genprog-many-bugs/php-bug-2012-01-30-9de5b6dc7c-4dc8b1ad11/php/ext/dom/tests/dom_set_attr_node.php"  2>&1
