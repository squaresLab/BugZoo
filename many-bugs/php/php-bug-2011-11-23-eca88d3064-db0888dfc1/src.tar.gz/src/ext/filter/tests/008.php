<?php

var_dump(filter_list());
var_dump(filter_list(array()));

echo "Done\n";
?>
