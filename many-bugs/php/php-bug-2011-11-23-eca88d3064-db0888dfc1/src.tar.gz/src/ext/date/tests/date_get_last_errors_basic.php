<?php
var_dump(date_get_last_errors()); // no date was parsed, so no errors
?>
