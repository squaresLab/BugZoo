<?php
$fragment = new DOMDocumentFragment();
$fragment->appendXML('<bait>crankbait</bait>');
$document->appendChild($fragment);
?>
