<?php
$fragment = new DOMDocumentFragment();
$fragment->appendXML();
?>
