<?php
$CData = new DOMCdataSection('splithere!');
$CDataSplit = $CData->splitText(5);
var_dump($CDataSplit, $CDataSplit->data);
?>
