<?php
	echo date("Y-m-d H:i:s\n", strtotime("2003-11-19T12:30:42"));
	echo date("Y-m-d H:i:s\n", strtotime("2003-11-19T12:30:42Z"));
?>
