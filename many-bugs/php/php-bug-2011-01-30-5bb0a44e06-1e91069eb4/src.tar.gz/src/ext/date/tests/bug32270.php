<?php

echo date("m/d/Y H:i:s T", -2145888000)."\n";

echo strtotime("Jan 1 1902")."\n";

echo date("m/d/Y H:i:s T", -631123200)."\n";

echo strtotime("Jan 1 1950")."\n";

echo date("m/d/Y H:i:s T", 946713600)."\n";

echo strtotime("Jan 1 2000")."\n";
?>
