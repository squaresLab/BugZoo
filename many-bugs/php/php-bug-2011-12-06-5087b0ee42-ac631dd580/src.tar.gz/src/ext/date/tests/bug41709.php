<?php
date_default_timezone_set("UTC");

$date_string = '00.00.0000 - 00:00:00';
print_r(date_parse($date_string));

?>
