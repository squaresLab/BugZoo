<?php extension_loaded('iconv') or die('skip iconv extension is not available'); ?>
