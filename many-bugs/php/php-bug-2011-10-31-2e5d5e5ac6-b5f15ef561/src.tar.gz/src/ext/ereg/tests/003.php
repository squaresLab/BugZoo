<?php $a="\\'test";
  echo ereg_replace("\\\\'","'",$a)
?>
