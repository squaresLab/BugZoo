#!/bin/sh

./sapi/cli/php  Array -f "/root/mountpoint-genprog/genprog-many-bugs/php-bug-2011-10-31-2e5d5e5ac6-b5f15ef561/php/ext/ereg/tests/spliti_error_002.php"  2>&1
