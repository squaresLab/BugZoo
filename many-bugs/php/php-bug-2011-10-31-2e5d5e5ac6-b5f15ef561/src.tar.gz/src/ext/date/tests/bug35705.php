<?php
date_default_timezone_set("UTC");

echo date(DATE_ISO8601, strtotime('2000-10-10T10:12:30.000')) . "\n";

?>
