<?php
	echo gmdate("Y-m-d H:i:s", strtotime("20050620091407 GMT"));
?>
