<?php
$dom = new DOMDocument('1.0');
$dom->validate(true);
?>
