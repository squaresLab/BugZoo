<?php
	try 
	{
	    $section = new DOMCDataSection();
		
	} 
	catch (Exception $e) 
	{
	    echo $e->getMessage();
	}
?>
