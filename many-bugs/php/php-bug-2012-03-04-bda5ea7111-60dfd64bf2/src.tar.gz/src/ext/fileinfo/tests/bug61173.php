<?php

$finfo = new finfo(1, '', false);
var_dump($finfo);
