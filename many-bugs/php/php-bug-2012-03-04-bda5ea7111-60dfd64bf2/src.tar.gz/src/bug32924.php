<?php 
include_once(dirname(__FILE__).'/inc.inc');
require_once(dirname(__FILE__).'/inc.inc');
?>
END
