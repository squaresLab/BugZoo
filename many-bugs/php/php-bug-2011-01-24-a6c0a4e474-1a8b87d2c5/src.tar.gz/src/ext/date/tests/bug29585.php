<?php
date_default_timezone_set("GMT");
echo gmdate("Y-m-d H:i:s", strtotime("2004W30"));
?>
