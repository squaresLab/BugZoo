<?php
	echo gmdate("Y-m-d H:i:s", strtotime("20 VI. 2005"));
?>
