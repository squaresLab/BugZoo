<?php

echo date('D Y/m/d/H:i:s', strtotime('last saturday', 1112703348)). "\n";
echo date('D Y/m/d/H:i:s', strtotime("last sunday", 1112703348)). "\n";
echo date('D Y/m/d/H:i:s', strtotime('last monday', 1112703348)). "\n";
