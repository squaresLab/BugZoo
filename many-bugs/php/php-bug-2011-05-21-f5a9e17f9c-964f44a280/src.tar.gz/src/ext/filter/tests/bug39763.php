<?php
$arr = array();
parse_str("val=%22probably+a+bug%22", $arr);
echo $arr['val'] . "\n";
parse_str("val=%22probably+a+bug%22");
echo $val . "\n";
?>
