<?php
DOMDocument::validate();
?>
