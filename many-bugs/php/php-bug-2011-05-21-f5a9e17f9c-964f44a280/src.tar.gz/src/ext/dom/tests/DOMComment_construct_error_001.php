<?php
$comment = new DOMComment("comment1", "comment2");
?>
