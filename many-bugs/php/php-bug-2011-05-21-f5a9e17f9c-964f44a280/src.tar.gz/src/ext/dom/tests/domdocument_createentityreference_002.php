<?php
	$objDoc = new DomDocument();
	
	$objRef = $objDoc->createEntityReference();
?>
===DONE===
