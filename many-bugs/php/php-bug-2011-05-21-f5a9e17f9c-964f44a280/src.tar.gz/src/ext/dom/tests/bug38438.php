<?php
$list = new DOMNodeList();
var_dump($list->item(0));
echo "OK\n";
?>
