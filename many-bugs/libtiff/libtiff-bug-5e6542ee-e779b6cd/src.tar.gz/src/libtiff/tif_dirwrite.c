extern void *_coverage_fout ;
typedef unsigned char __u_char;
typedef unsigned short __u_short;
typedef unsigned int __u_int;
typedef unsigned long __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;
typedef long long __quad_t;
typedef unsigned long long __u_quad_t;
typedef __u_quad_t __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef __u_quad_t __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long __off_t;
typedef __quad_t __off64_t;
typedef int __pid_t;
struct __anonstruct___fsid_t_1 {
   int __val[2] ;
};
typedef struct __anonstruct___fsid_t_1 __fsid_t;
typedef long __clock_t;
typedef unsigned long __rlim_t;
typedef __u_quad_t __rlim64_t;
typedef unsigned int __id_t;
typedef long __time_t;
typedef unsigned int __useconds_t;
typedef long __suseconds_t;
typedef int __daddr_t;
typedef long __swblk_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void *__timer_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef __quad_t __blkcnt64_t;
typedef unsigned long __fsblkcnt_t;
typedef __u_quad_t __fsblkcnt64_t;
typedef unsigned long __fsfilcnt_t;
typedef __u_quad_t __fsfilcnt64_t;
typedef int __ssize_t;
typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;
typedef int __intptr_t;
typedef unsigned int __socklen_t;
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;
typedef __loff_t loff_t;
typedef __ino64_t ino_t;
typedef __dev_t dev_t;
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __nlink_t nlink_t;
typedef __uid_t uid_t;
typedef __off64_t off_t;
typedef __pid_t pid_t;
typedef __id_t id_t;
typedef __ssize_t ssize_t;
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;
typedef __key_t key_t;
typedef __clock_t clock_t;
typedef __time_t time_t;
typedef __clockid_t clockid_t;
typedef __timer_t timer_t;
typedef unsigned int size_t;
typedef unsigned long ulong;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char u_int8_t;
typedef unsigned short u_int16_t;
typedef unsigned int u_int32_t;
typedef unsigned long long u_int64_t;
typedef int register_t;
typedef int __sig_atomic_t;
struct __anonstruct___sigset_t_2 {
   unsigned long __val[1024U / (8U * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_2 __sigset_t;
typedef __sigset_t sigset_t;
struct timespec {
   __time_t tv_sec ;
   long tv_nsec ;
};
struct timeval {
   __time_t tv_sec ;
   __suseconds_t tv_usec ;
};
typedef __suseconds_t suseconds_t;
typedef long __fd_mask;
struct __anonstruct_fd_set_3 {
   __fd_mask __fds_bits[1024 / (8 * (int )sizeof(__fd_mask ))] ;
};
typedef struct __anonstruct_fd_set_3 fd_set;
typedef __fd_mask fd_mask;
typedef __blksize_t blksize_t;
typedef __blkcnt64_t blkcnt_t;
typedef __fsblkcnt64_t fsblkcnt_t;
typedef __fsfilcnt64_t fsfilcnt_t;
typedef unsigned long pthread_t;
union __anonunion_pthread_attr_t_4 {
   char __size[36] ;
   long __align ;
};
typedef union __anonunion_pthread_attr_t_4 pthread_attr_t;
struct __pthread_internal_slist {
   struct __pthread_internal_slist *__next ;
};
typedef struct __pthread_internal_slist __pthread_slist_t;
union __anonunion____missing_field_name_6 {
   int __spins ;
   __pthread_slist_t __list ;
};
struct __pthread_mutex_s {
   int __lock ;
   unsigned int __count ;
   int __owner ;
   int __kind ;
   unsigned int __nusers ;
   union __anonunion____missing_field_name_6 __annonCompField1 ;
};
union __anonunion_pthread_mutex_t_5 {
   struct __pthread_mutex_s __data ;
   char __size[24] ;
   long __align ;
};
typedef union __anonunion_pthread_mutex_t_5 pthread_mutex_t;
union __anonunion_pthread_mutexattr_t_7 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_mutexattr_t_7 pthread_mutexattr_t;
struct __anonstruct___data_9 {
   int __lock ;
   unsigned int __futex ;
   unsigned long long __total_seq ;
   unsigned long long __wakeup_seq ;
   unsigned long long __woken_seq ;
   void *__mutex ;
   unsigned int __nwaiters ;
   unsigned int __broadcast_seq ;
};
union __anonunion_pthread_cond_t_8 {
   struct __anonstruct___data_9 __data ;
   char __size[48] ;
   long long __align ;
};
typedef union __anonunion_pthread_cond_t_8 pthread_cond_t;
union __anonunion_pthread_condattr_t_10 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_condattr_t_10 pthread_condattr_t;
typedef unsigned int pthread_key_t;
typedef int pthread_once_t;
struct __anonstruct___data_12 {
   int __lock ;
   unsigned int __nr_readers ;
   unsigned int __readers_wakeup ;
   unsigned int __writer_wakeup ;
   unsigned int __nr_readers_queued ;
   unsigned int __nr_writers_queued ;
   unsigned char __flags ;
   unsigned char __shared ;
   unsigned char __pad1 ;
   unsigned char __pad2 ;
   int __writer ;
};
union __anonunion_pthread_rwlock_t_11 {
   struct __anonstruct___data_12 __data ;
   char __size[32] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlock_t_11 pthread_rwlock_t;
union __anonunion_pthread_rwlockattr_t_13 {
   char __size[8] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlockattr_t_13 pthread_rwlockattr_t;
typedef int volatile   pthread_spinlock_t;
union __anonunion_pthread_barrier_t_14 {
   char __size[20] ;
   long __align ;
};
typedef union __anonunion_pthread_barrier_t_14 pthread_barrier_t;
union __anonunion_pthread_barrierattr_t_15 {
   char __size[4] ;
   int __align ;
};
typedef union __anonunion_pthread_barrierattr_t_15 pthread_barrierattr_t;
struct flock {
   short l_type ;
   short l_whence ;
   __off64_t l_start ;
   __off64_t l_len ;
   __pid_t l_pid ;
};
struct stat {
   __dev_t st_dev ;
   unsigned short __pad1 ;
   __ino_t __st_ino ;
   __mode_t st_mode ;
   __nlink_t st_nlink ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   __dev_t st_rdev ;
   unsigned short __pad2 ;
   __off64_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt64_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __ino64_t st_ino ;
};
struct __locale_data;
struct __locale_struct {
   struct __locale_data *__locales[13] ;
   unsigned short const   *__ctype_b ;
   int const   *__ctype_tolower ;
   int const   *__ctype_toupper ;
   char const   *__names[13] ;
};
typedef struct __locale_struct *__locale_t;
typedef __locale_t locale_t;
typedef int (*__compar_fn_t)(void const   * , void const   * );
enum __anonenum_ACTION_16 {
    FIND = 0,
    ENTER = 1
} ;
typedef enum __anonenum_ACTION_16 ACTION;
struct entry {
   char *key ;
   void *data ;
};
typedef struct entry ENTRY;
struct _ENTRY;
struct _ENTRY;
enum __anonenum_VISIT_17 {
    preorder = 0,
    postorder = 1,
    endorder = 2,
    leaf = 3
} ;
typedef enum __anonenum_VISIT_17 VISIT;
typedef void (*__action_fn_t)(void const   *__nodep , VISIT __value ,
                              int __level );
typedef signed char int8;
typedef unsigned char uint8;
typedef short int16;
typedef unsigned short uint16;
typedef int int32;
typedef unsigned int uint32;
typedef long long int64;
typedef unsigned long long uint64;
typedef int uint16_vap;
struct __anonstruct_TIFFHeaderCommon_18 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
};
typedef struct __anonstruct_TIFFHeaderCommon_18 TIFFHeaderCommon;
struct __anonstruct_TIFFHeaderClassic_19 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint32 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderClassic_19 TIFFHeaderClassic;
struct __anonstruct_TIFFHeaderBig_20 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint16 tiff_offsetsize ;
   uint16 tiff_unused ;
   uint64 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderBig_20 TIFFHeaderBig;
enum __anonenum_TIFFDataType_21 {
    TIFF_NOTYPE = 0,
    TIFF_BYTE = 1,
    TIFF_ASCII = 2,
    TIFF_SHORT = 3,
    TIFF_LONG = 4,
    TIFF_RATIONAL = 5,
    TIFF_SBYTE = 6,
    TIFF_UNDEFINED = 7,
    TIFF_SSHORT = 8,
    TIFF_SLONG = 9,
    TIFF_SRATIONAL = 10,
    TIFF_FLOAT = 11,
    TIFF_DOUBLE = 12,
    TIFF_IFD = 13,
    TIFF_LONG8 = 16,
    TIFF_SLONG8 = 17,
    TIFF_IFD8 = 18
} ;
typedef enum __anonenum_TIFFDataType_21 TIFFDataType;
struct tiff;
typedef struct tiff TIFF;
typedef long tmsize_t;
typedef uint32 ttag_t;
typedef uint16 tdir_t;
typedef uint16 tsample_t;
typedef uint32 tstrile_t;
typedef tstrile_t tstrip_t;
typedef tstrile_t ttile_t;
typedef tmsize_t tsize_t;
typedef void *tdata_t;
typedef uint64 toff_t;
typedef void *thandle_t;
typedef unsigned char TIFFRGBValue;
struct __anonstruct_TIFFDisplay_22 {
   float d_mat[3][3] ;
   float d_YCR ;
   float d_YCG ;
   float d_YCB ;
   uint32 d_Vrwr ;
   uint32 d_Vrwg ;
   uint32 d_Vrwb ;
   float d_Y0R ;
   float d_Y0G ;
   float d_Y0B ;
   float d_gammaR ;
   float d_gammaG ;
   float d_gammaB ;
};
typedef struct __anonstruct_TIFFDisplay_22 TIFFDisplay;
struct __anonstruct_TIFFYCbCrToRGB_23 {
   TIFFRGBValue *clamptab ;
   int *Cr_r_tab ;
   int *Cb_b_tab ;
   int32 *Cr_g_tab ;
   int32 *Cb_g_tab ;
   int32 *Y_tab ;
};
typedef struct __anonstruct_TIFFYCbCrToRGB_23 TIFFYCbCrToRGB;
struct __anonstruct_TIFFCIELabToRGB_24 {
   int range ;
   float rstep ;
   float gstep ;
   float bstep ;
   float X0 ;
   float Y0 ;
   float Z0 ;
   TIFFDisplay display ;
   float Yr2r[1501] ;
   float Yg2g[1501] ;
   float Yb2b[1501] ;
};
typedef struct __anonstruct_TIFFCIELabToRGB_24 TIFFCIELabToRGB;
struct _TIFFRGBAImage;
typedef struct _TIFFRGBAImage TIFFRGBAImage;
typedef void (*tileContigRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                  uint32  , uint32  , uint32  , int32  ,
                                  int32  , unsigned char * );
typedef void (*tileSeparateRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                    uint32  , uint32  , uint32  , int32  ,
                                    int32  , unsigned char * , unsigned char * ,
                                    unsigned char * , unsigned char * );
union __anonunion_put_25 {
   void (*any)(TIFFRGBAImage * ) ;
   void (*contig)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                  uint32  , int32  , int32  , unsigned char * ) ;
   void (*separate)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                    uint32  , int32  , int32  , unsigned char * ,
                    unsigned char * , unsigned char * , unsigned char * ) ;
};
struct _TIFFRGBAImage {
   TIFF *tif ;
   int stoponerr ;
   int isContig ;
   int alpha ;
   uint32 width ;
   uint32 height ;
   uint16 bitspersample ;
   uint16 samplesperpixel ;
   uint16 orientation ;
   uint16 req_orientation ;
   uint16 photometric ;
   uint16 *redcmap ;
   uint16 *greencmap ;
   uint16 *bluecmap ;
   int (*get)(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
   union __anonunion_put_25 put ;
   TIFFRGBValue *Map ;
   uint32 **BWmap ;
   uint32 **PALmap ;
   TIFFYCbCrToRGB *ycbcr ;
   TIFFCIELabToRGB *cielab ;
   uint8 *UaToAa ;
   uint8 *Bitdepth16To8 ;
   int row_offset ;
   int col_offset ;
};
typedef int (*TIFFInitMethod)(TIFF * , int  );
struct __anonstruct_TIFFCodec_26 {
   char *name ;
   uint16 scheme ;
   int (*init)(TIFF * , int  ) ;
};
typedef struct __anonstruct_TIFFCodec_26 TIFFCodec;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_28 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_27 {
   int __count ;
   union __anonunion___value_28 __value ;
};
typedef struct __anonstruct___mbstate_t_27 __mbstate_t;
struct __anonstruct__G_fpos_t_29 {
   __off_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos_t_29 _G_fpos_t;
struct __anonstruct__G_fpos64_t_30 {
   __off64_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos64_t_30 _G_fpos64_t;
typedef short _G_int16_t;
typedef int _G_int32_t;
typedef unsigned short _G_uint16_t;
typedef unsigned int _G_uint32_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_jump_t;
struct _IO_jump_t;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
enum __codecvt_result {
    __codecvt_ok = 0,
    __codecvt_partial = 1,
    __codecvt_error = 2,
    __codecvt_noconv = 3
} ;
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15U * sizeof(int ) - 4U * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
struct _IO_FILE_plus;
struct _IO_FILE_plus;
typedef __ssize_t __io_read_fn(void *__cookie , char *__buf , size_t __nbytes );
typedef __ssize_t __io_write_fn(void *__cookie , char const   *__buf ,
                                size_t __n );
typedef int __io_seek_fn(void *__cookie , __off64_t *__pos , int __w );
typedef int __io_close_fn(void *__cookie );
typedef __gnuc_va_list va_list;
typedef _G_fpos64_t fpos_t;
typedef void (*TIFFErrorHandler)(char const   * , char const   * , va_list  );
typedef void (*TIFFErrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  );
typedef tmsize_t (*TIFFReadWriteProc)(thandle_t  , void * , tmsize_t  );
typedef uint64 (*TIFFSeekProc)(thandle_t  , uint64  , int  );
typedef int (*TIFFCloseProc)(thandle_t  );
typedef uint64 (*TIFFSizeProc)(thandle_t  );
typedef int (*TIFFMapFileProc)(thandle_t  , void **base , toff_t *size );
typedef void (*TIFFUnmapFileProc)(thandle_t  , void *base , toff_t size );
typedef void (*TIFFExtendProc)(TIFF * );
struct _TIFFField;
typedef struct _TIFFField TIFFField;
struct _TIFFFieldArray;
typedef struct _TIFFFieldArray TIFFFieldArray;
typedef int (*TIFFVSetMethod)(TIFF * , uint32  , va_list  );
typedef int (*TIFFVGetMethod)(TIFF * , uint32  , va_list  );
typedef void (*TIFFPrintMethod)(TIFF * , FILE * , long  );
struct __anonstruct_TIFFTagMethods_31 {
   int (*vsetfield)(TIFF * , uint32  , va_list  ) ;
   int (*vgetfield)(TIFF * , uint32  , va_list  ) ;
   void (*printdir)(TIFF * , FILE * , long  ) ;
};
typedef struct __anonstruct_TIFFTagMethods_31 TIFFTagMethods;
struct __anonstruct_TIFFFieldInfo_32 {
   ttag_t field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
};
typedef struct __anonstruct_TIFFFieldInfo_32 TIFFFieldInfo;
struct __anonstruct_TIFFTagValue_33 {
   TIFFField const   *info ;
   int count ;
   void *value ;
};
typedef struct __anonstruct_TIFFTagValue_33 TIFFTagValue;
struct __anonstruct_TIFFDirectory_34 {
   unsigned long td_fieldsset[4] ;
   uint32 td_imagewidth ;
   uint32 td_imagelength ;
   uint32 td_imagedepth ;
   uint32 td_tilewidth ;
   uint32 td_tilelength ;
   uint32 td_tiledepth ;
   uint32 td_subfiletype ;
   uint16 td_bitspersample ;
   uint16 td_sampleformat ;
   uint16 td_compression ;
   uint16 td_photometric ;
   uint16 td_threshholding ;
   uint16 td_fillorder ;
   uint16 td_orientation ;
   uint16 td_samplesperpixel ;
   uint32 td_rowsperstrip ;
   uint16 td_minsamplevalue ;
   uint16 td_maxsamplevalue ;
   double td_sminsamplevalue ;
   double td_smaxsamplevalue ;
   float td_xresolution ;
   float td_yresolution ;
   uint16 td_resolutionunit ;
   uint16 td_planarconfig ;
   float td_xposition ;
   float td_yposition ;
   uint16 td_pagenumber[2] ;
   uint16 *td_colormap[3] ;
   uint16 td_halftonehints[2] ;
   uint16 td_extrasamples ;
   uint16 *td_sampleinfo ;
   uint32 td_stripsperimage ;
   uint32 td_nstrips ;
   uint64 *td_stripoffset ;
   uint64 *td_stripbytecount ;
   int td_stripbytecountsorted ;
   uint16 td_nsubifd ;
   uint64 *td_subifd ;
   uint16 td_ycbcrsubsampling[2] ;
   uint16 td_ycbcrpositioning ;
   uint16 *td_transferfunction[3] ;
   int td_inknameslen ;
   char *td_inknames ;
   int td_customValueCount ;
   TIFFTagValue *td_customValues ;
};
typedef struct __anonstruct_TIFFDirectory_34 TIFFDirectory;
enum __anonenum_TIFFSetGetFieldType_35 {
    TIFF_SETGET_UNDEFINED = 0,
    TIFF_SETGET_ASCII = 1,
    TIFF_SETGET_UINT8 = 2,
    TIFF_SETGET_SINT8 = 3,
    TIFF_SETGET_UINT16 = 4,
    TIFF_SETGET_SINT16 = 5,
    TIFF_SETGET_UINT32 = 6,
    TIFF_SETGET_SINT32 = 7,
    TIFF_SETGET_UINT64 = 8,
    TIFF_SETGET_SINT64 = 9,
    TIFF_SETGET_FLOAT = 10,
    TIFF_SETGET_DOUBLE = 11,
    TIFF_SETGET_IFD8 = 12,
    TIFF_SETGET_INT = 13,
    TIFF_SETGET_UINT16_PAIR = 14,
    TIFF_SETGET_C0_ASCII = 15,
    TIFF_SETGET_C0_UINT8 = 16,
    TIFF_SETGET_C0_SINT8 = 17,
    TIFF_SETGET_C0_UINT16 = 18,
    TIFF_SETGET_C0_SINT16 = 19,
    TIFF_SETGET_C0_UINT32 = 20,
    TIFF_SETGET_C0_SINT32 = 21,
    TIFF_SETGET_C0_UINT64 = 22,
    TIFF_SETGET_C0_SINT64 = 23,
    TIFF_SETGET_C0_FLOAT = 24,
    TIFF_SETGET_C0_DOUBLE = 25,
    TIFF_SETGET_C0_IFD8 = 26,
    TIFF_SETGET_C16_ASCII = 27,
    TIFF_SETGET_C16_UINT8 = 28,
    TIFF_SETGET_C16_SINT8 = 29,
    TIFF_SETGET_C16_UINT16 = 30,
    TIFF_SETGET_C16_SINT16 = 31,
    TIFF_SETGET_C16_UINT32 = 32,
    TIFF_SETGET_C16_SINT32 = 33,
    TIFF_SETGET_C16_UINT64 = 34,
    TIFF_SETGET_C16_SINT64 = 35,
    TIFF_SETGET_C16_FLOAT = 36,
    TIFF_SETGET_C16_DOUBLE = 37,
    TIFF_SETGET_C16_IFD8 = 38,
    TIFF_SETGET_C32_ASCII = 39,
    TIFF_SETGET_C32_UINT8 = 40,
    TIFF_SETGET_C32_SINT8 = 41,
    TIFF_SETGET_C32_UINT16 = 42,
    TIFF_SETGET_C32_SINT16 = 43,
    TIFF_SETGET_C32_UINT32 = 44,
    TIFF_SETGET_C32_SINT32 = 45,
    TIFF_SETGET_C32_UINT64 = 46,
    TIFF_SETGET_C32_SINT64 = 47,
    TIFF_SETGET_C32_FLOAT = 48,
    TIFF_SETGET_C32_DOUBLE = 49,
    TIFF_SETGET_C32_IFD8 = 50,
    TIFF_SETGET_OTHER = 51
} ;
typedef enum __anonenum_TIFFSetGetFieldType_35 TIFFSetGetFieldType;
enum __anonenum_TIFFFieldArrayType_36 {
    tfiatImage = 0,
    tfiatExif = 1,
    tfiatOther = 2
} ;
typedef enum __anonenum_TIFFFieldArrayType_36 TIFFFieldArrayType;
struct _TIFFFieldArray {
   TIFFFieldArrayType type ;
   uint32 allocated_size ;
   uint32 count ;
   TIFFField *fields ;
};
struct _TIFFField {
   uint32 field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   uint32 reserved ;
   TIFFSetGetFieldType set_field_type ;
   TIFFSetGetFieldType get_field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
   TIFFFieldArray *field_subfields ;
};
struct __anonstruct_TIFFDirEntry_37 {
   uint16 tdir_tag ;
   uint16 tdir_type ;
   uint64 tdir_count ;
   uint64 tdir_offset ;
};
typedef struct __anonstruct_TIFFDirEntry_37 TIFFDirEntry;
struct client_info {
   struct client_info *next ;
   void *data ;
   char *name ;
};
typedef struct client_info TIFFClientInfoLink;
typedef unsigned char tidataval_t;
typedef tidataval_t *tidata_t;
typedef void (*TIFFVoidMethod)(TIFF * );
typedef int (*TIFFBoolMethod)(TIFF * );
typedef int (*TIFFPreMethod)(TIFF * , uint16  );
typedef int (*TIFFCodeMethod)(TIFF *tif , uint8 *buf , tmsize_t size ,
                              uint16 sample );
typedef int (*TIFFSeekMethod)(TIFF * , uint32  );
typedef void (*TIFFPostMethod)(TIFF *tif , uint8 *buf , tmsize_t size );
typedef uint32 (*TIFFStripMethod)(TIFF * , uint32  );
typedef void (*TIFFTileMethod)(TIFF * , uint32 * , uint32 * );
union __anonunion_tif_header_38 {
   TIFFHeaderCommon common ;
   TIFFHeaderClassic classic ;
   TIFFHeaderBig big ;
};
struct tiff {
   char *tif_name ;
   int tif_fd ;
   int tif_mode ;
   uint32 tif_flags ;
   uint64 tif_diroff ;
   uint64 tif_nextdiroff ;
   uint64 *tif_dirlist ;
   uint16 tif_dirlistsize ;
   uint16 tif_dirnumber ;
   TIFFDirectory tif_dir ;
   TIFFDirectory tif_customdir ;
   union __anonunion_tif_header_38 tif_header ;
   uint16 tif_header_size ;
   uint32 tif_row ;
   uint16 tif_curdir ;
   uint32 tif_curstrip ;
   uint64 tif_curoff ;
   uint64 tif_dataoff ;
   uint16 tif_nsubifd ;
   uint64 tif_subifdoff ;
   uint32 tif_col ;
   uint32 tif_curtile ;
   tmsize_t tif_tilesize ;
   int tif_decodestatus ;
   int (*tif_fixuptags)(TIFF * ) ;
   int (*tif_setupdecode)(TIFF * ) ;
   int (*tif_predecode)(TIFF * , uint16  ) ;
   int (*tif_setupencode)(TIFF * ) ;
   int tif_encodestatus ;
   int (*tif_preencode)(TIFF * , uint16  ) ;
   int (*tif_postencode)(TIFF * ) ;
   int (*tif_decoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_decodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_encodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_decodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   void (*tif_close)(TIFF * ) ;
   int (*tif_seek)(TIFF * , uint32  ) ;
   void (*tif_cleanup)(TIFF * ) ;
   uint32 (*tif_defstripsize)(TIFF * , uint32  ) ;
   void (*tif_deftilesize)(TIFF * , uint32 * , uint32 * ) ;
   uint8 *tif_data ;
   tmsize_t tif_scanlinesize ;
   tmsize_t tif_scanlineskew ;
   uint8 *tif_rawdata ;
   tmsize_t tif_rawdatasize ;
   uint8 *tif_rawcp ;
   tmsize_t tif_rawcc ;
   uint8 *tif_base ;
   tmsize_t tif_size ;
   int (*tif_mapproc)(thandle_t  , void **base , toff_t *size ) ;
   void (*tif_unmapproc)(thandle_t  , void *base , toff_t size ) ;
   thandle_t tif_clientdata ;
   tmsize_t (*tif_readproc)(thandle_t  , void * , tmsize_t  ) ;
   tmsize_t (*tif_writeproc)(thandle_t  , void * , tmsize_t  ) ;
   uint64 (*tif_seekproc)(thandle_t  , uint64  , int  ) ;
   int (*tif_closeproc)(thandle_t  ) ;
   uint64 (*tif_sizeproc)(thandle_t  ) ;
   void (*tif_postdecode)(TIFF *tif , uint8 *buf , tmsize_t size ) ;
   TIFFField **tif_fields ;
   uint32 tif_nfields ;
   TIFFField const   *tif_foundfield ;
   TIFFTagMethods tif_tagmethods ;
   TIFFClientInfoLink *tif_clientinfo ;
   TIFFFieldArray *tif_fieldscompat ;
   uint32 tif_nfieldscompat ;
};
extern int select(int __nfds , fd_set * __restrict  __readfds ,
                  fd_set * __restrict  __writefds ,
                  fd_set * __restrict  __exceptfds ,
                  struct timeval * __restrict  __timeout ) ;
extern int pselect(int __nfds , fd_set * __restrict  __readfds ,
                   fd_set * __restrict  __writefds ,
                   fd_set * __restrict  __exceptfds ,
                   struct timespec  const  * __restrict  __timeout ,
                   __sigset_t const   * __restrict  __sigmask ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_major(unsigned long long __dev ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5201\n");
  fflush(_coverage_fout);
  return ((unsigned int )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_minor(unsigned long long __dev ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5202\n");
  fflush(_coverage_fout);
  return ((unsigned int )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                   unsigned int __minor ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5203\n");
  fflush(_coverage_fout);
  return (((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32));
}
}
extern int fcntl(int __fd , int __cmd  , ...) ;
extern int open(char const   *__file , int __oflag  , ...)  __asm__("open64") __attribute__((__nonnull__(1))) ;
extern int openat(int __fd , char const   *__file , int __oflag  , ...)  __asm__("openat64") __attribute__((__nonnull__(2))) ;
extern int creat(char const   *__file , __mode_t __mode )  __asm__("creat64") __attribute__((__nonnull__(1))) ;
extern int lockf(int __fd , int __cmd , __off64_t __len )  __asm__("lockf64")  ;
extern  __attribute__((__nothrow__)) int posix_fadvise(int __fd ,
                                                       __off64_t __offset ,
                                                       __off64_t __len ,
                                                       int __advise )  __asm__("posix_fadvise64")  ;
extern int posix_fallocate(int __fd , __off64_t __offset , __off64_t __len )  __asm__("posix_fallocate64")  ;
extern  __attribute__((__nothrow__)) void *memcpy(void * __restrict  __dest ,
                                                  void const   * __restrict  __src ,
                                                  size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memmove(void *__dest ,
                                                   void const   *__src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memccpy(void * __restrict  __dest ,
                                                   void const   * __restrict  __src ,
                                                   int __c , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memset(void *__s , int __c ,
                                                  size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int memcmp(void const   *__s1 ,
                                                void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memchr(void const   *__s , int __c ,
                                                  size_t __n )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strcat(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncat(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcmp(char const   *__s1 ,
                                                char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncmp(char const   *__s1 ,
                                                 char const   *__s2 ,
                                                 size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcoll(char const   *__s1 ,
                                                 char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm(char * __restrict  __dest ,
                                                    char const   * __restrict  __src ,
                                                    size_t __n )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int strcoll_l(char const   *__s1 ,
                                                   char const   *__s2 ,
                                                   __locale_t __l )  __attribute__((__pure__,
__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm_l(char *__dest ,
                                                      char const   *__src ,
                                                      size_t __n ,
                                                      __locale_t __l )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) char *strdup(char const   *__s )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strndup(char const   *__string ,
                                                   size_t __n )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strrchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strcspn(char const   *__s ,
                                                    char const   *__reject )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strspn(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strpbrk(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strstr(char const   *__haystack ,
                                                  char const   *__needle )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strtok(char * __restrict  __s ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *__strtok_r(char * __restrict  __s ,
                                                      char const   * __restrict  __delim ,
                                                      char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) char *strtok_r(char * __restrict  __s ,
                                                    char const   * __restrict  __delim ,
                                                    char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) size_t strlen(char const   *__s )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strnlen(char const   *__string ,
                                                    size_t __maxlen )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strerror(int __errnum ) ;
extern  __attribute__((__nothrow__)) int strerror_r(int __errnum , char *__buf ,
                                                    size_t __buflen )  __asm__("__xpg_strerror_r") __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *strerror_l(int __errnum ,
                                                      __locale_t __l ) ;
extern  __attribute__((__nothrow__)) void __bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void bcopy(void const   *__src ,
                                                void *__dest , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int bcmp(void const   *__s1 ,
                                              void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *index(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *rindex(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int ffs(int __i )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int strcasecmp(char const   *__s1 ,
                                                    char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncasecmp(char const   *__s1 ,
                                                     char const   *__s2 ,
                                                     size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsep(char ** __restrict  __stringp ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsignal(int __sig ) ;
extern  __attribute__((__nothrow__)) char *__stpcpy(char * __restrict  __dest ,
                                                    char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *__stpncpy(char * __restrict  __dest ,
                                                     char const   * __restrict  __src ,
                                                     size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern void *__rawmemchr(void const   *__s , int __c ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5208\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "5209\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "5206\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "5205\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject) {
        fprintf(_coverage_fout, "5204\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "5207\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "5210\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) ;
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5216\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "5217\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "5214\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "5213\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        fprintf(_coverage_fout, "5212\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          fprintf(_coverage_fout, "5211\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "5215\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "5218\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) ;
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5225\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "5226\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "5223\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "5222\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        fprintf(_coverage_fout, "5221\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          fprintf(_coverage_fout, "5220\n");
          fflush(_coverage_fout);
          if ((int const   )*(__s + __result) != (int const   )__reject3) {
            fprintf(_coverage_fout, "5219\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "5224\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "5227\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) ;
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5231\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "5232\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "5229\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept) {
      fprintf(_coverage_fout, "5228\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "5230\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "5233\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5239\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "5240\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "5237\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      fprintf(_coverage_fout, "5234\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "5236\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        fprintf(_coverage_fout, "5235\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    }
    fprintf(_coverage_fout, "5238\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "5241\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5249\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "5250\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "5247\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      fprintf(_coverage_fout, "5242\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "5246\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        fprintf(_coverage_fout, "5243\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "5245\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) == (int const   )__accept3) {
          fprintf(_coverage_fout, "5244\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      }
    }
    fprintf(_coverage_fout, "5248\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "5251\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5259\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "5255\n");
    fflush(_coverage_fout);
    if ((int const   )*__s != 0) {
      fprintf(_coverage_fout, "5254\n");
      fflush(_coverage_fout);
      if ((int const   )*__s != (int const   )__accept1) {
        fprintf(_coverage_fout, "5253\n");
        fflush(_coverage_fout);
        if ((int const   )*__s != (int const   )__accept2) {
          fprintf(_coverage_fout, "5252\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "5256\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "5260\n");
  fflush(_coverage_fout);
  if ((int const   )*__s == 0) {
    fprintf(_coverage_fout, "5257\n");
    fflush(_coverage_fout);
    tmp = (char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "5258\n");
    fflush(_coverage_fout);
    tmp = (char *)((unsigned int )__s);
  }
  fprintf(_coverage_fout, "5261\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5270\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "5266\n");
    fflush(_coverage_fout);
    if ((int const   )*__s != 0) {
      fprintf(_coverage_fout, "5265\n");
      fflush(_coverage_fout);
      if ((int const   )*__s != (int const   )__accept1) {
        fprintf(_coverage_fout, "5264\n");
        fflush(_coverage_fout);
        if ((int const   )*__s != (int const   )__accept2) {
          fprintf(_coverage_fout, "5263\n");
          fflush(_coverage_fout);
          if ((int const   )*__s != (int const   )__accept3) {
            fprintf(_coverage_fout, "5262\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "5267\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "5271\n");
  fflush(_coverage_fout);
  if ((int const   )*__s == 0) {
    fprintf(_coverage_fout, "5268\n");
    fflush(_coverage_fout);
    tmp = (char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "5269\n");
    fflush(_coverage_fout);
    tmp = (char *)((unsigned int )__s);
  }
  fprintf(_coverage_fout, "5272\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) ;
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) 
{ char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5290\n");
  fflush(_coverage_fout);
  if ((unsigned int )__s == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "5273\n");
    fflush(_coverage_fout);
    __s = *__nextp;
  } else {
    fprintf(_coverage_fout, "5274\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "5291\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "5276\n");
    fflush(_coverage_fout);
    if ((int )*__s == (int )__sep) {
      fprintf(_coverage_fout, "5275\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "5277\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "5292\n");
  fflush(_coverage_fout);
  __result = (char *)((void *)0);
  fprintf(_coverage_fout, "5293\n");
  fflush(_coverage_fout);
  if ((int )*__s != 0) {
    fprintf(_coverage_fout, "5285\n");
    fflush(_coverage_fout);
    tmp = __s;
    fprintf(_coverage_fout, "5286\n");
    fflush(_coverage_fout);
    __s ++;
    fprintf(_coverage_fout, "5287\n");
    fflush(_coverage_fout);
    __result = tmp;
    fprintf(_coverage_fout, "5288\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "5281\n");
      fflush(_coverage_fout);
      if ((int )*__s != 0) {
        fprintf(_coverage_fout, "5278\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "5282\n");
      fflush(_coverage_fout);
      tmp___0 = __s;
      fprintf(_coverage_fout, "5283\n");
      fflush(_coverage_fout);
      __s ++;
      fprintf(_coverage_fout, "5284\n");
      fflush(_coverage_fout);
      if ((int )*tmp___0 == (int )__sep) {
        fprintf(_coverage_fout, "5279\n");
        fflush(_coverage_fout);
        *(__s + -1) = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "5280\n");
        fflush(_coverage_fout);

      }
    }
  } else {
    fprintf(_coverage_fout, "5289\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "5294\n");
  fflush(_coverage_fout);
  *__nextp = __s;
  fprintf(_coverage_fout, "5295\n");
  fflush(_coverage_fout);
  return (__result);
}
}
extern char *__strsep_g(char **__stringp , char const   *__delim ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) 
{ register char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  void *tmp___1 ;
  char *tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5305\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "5306\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "5300\n");
    fflush(_coverage_fout);
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    fprintf(_coverage_fout, "5301\n");
    fflush(_coverage_fout);
    tmp___0 = tmp___2;
    fprintf(_coverage_fout, "5302\n");
    fflush(_coverage_fout);
    *__s = tmp___0;
    fprintf(_coverage_fout, "5303\n");
    fflush(_coverage_fout);
    if ((unsigned int )tmp___0 != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "5296\n");
      fflush(_coverage_fout);
      tmp = *__s;
      fprintf(_coverage_fout, "5297\n");
      fflush(_coverage_fout);
      (*__s) ++;
      fprintf(_coverage_fout, "5298\n");
      fflush(_coverage_fout);
      *tmp = (char )'\000';
    } else {
      fprintf(_coverage_fout, "5299\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "5304\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "5307\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) ;
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5325\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "5326\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "5321\n");
    fflush(_coverage_fout);
    __cp = __retval;
    fprintf(_coverage_fout, "5322\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "5318\n");
      fflush(_coverage_fout);
      if ((int )*__cp == 0) {
        fprintf(_coverage_fout, "5308\n");
        fflush(_coverage_fout);
        __cp = (char *)((void *)0);
        break;
      } else {
        fprintf(_coverage_fout, "5309\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5319\n");
      fflush(_coverage_fout);
      if ((int )*__cp == (int )__reject1) {
        fprintf(_coverage_fout, "5310\n");
        fflush(_coverage_fout);
        tmp = __cp;
        fprintf(_coverage_fout, "5311\n");
        fflush(_coverage_fout);
        __cp ++;
        fprintf(_coverage_fout, "5312\n");
        fflush(_coverage_fout);
        *tmp = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "5317\n");
        fflush(_coverage_fout);
        if ((int )*__cp == (int )__reject2) {
          fprintf(_coverage_fout, "5313\n");
          fflush(_coverage_fout);
          tmp = __cp;
          fprintf(_coverage_fout, "5314\n");
          fflush(_coverage_fout);
          __cp ++;
          fprintf(_coverage_fout, "5315\n");
          fflush(_coverage_fout);
          *tmp = (char )'\000';
          break;
        } else {
          fprintf(_coverage_fout, "5316\n");
          fflush(_coverage_fout);

        }
      }
      fprintf(_coverage_fout, "5320\n");
      fflush(_coverage_fout);
      __cp ++;
    }
    fprintf(_coverage_fout, "5323\n");
    fflush(_coverage_fout);
    *__s = __cp;
  } else {
    fprintf(_coverage_fout, "5324\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "5327\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) ;
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5349\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "5350\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "5345\n");
    fflush(_coverage_fout);
    __cp = __retval;
    fprintf(_coverage_fout, "5346\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "5342\n");
      fflush(_coverage_fout);
      if ((int )*__cp == 0) {
        fprintf(_coverage_fout, "5328\n");
        fflush(_coverage_fout);
        __cp = (char *)((void *)0);
        break;
      } else {
        fprintf(_coverage_fout, "5329\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5343\n");
      fflush(_coverage_fout);
      if ((int )*__cp == (int )__reject1) {
        fprintf(_coverage_fout, "5330\n");
        fflush(_coverage_fout);
        tmp = __cp;
        fprintf(_coverage_fout, "5331\n");
        fflush(_coverage_fout);
        __cp ++;
        fprintf(_coverage_fout, "5332\n");
        fflush(_coverage_fout);
        *tmp = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "5341\n");
        fflush(_coverage_fout);
        if ((int )*__cp == (int )__reject2) {
          fprintf(_coverage_fout, "5333\n");
          fflush(_coverage_fout);
          tmp = __cp;
          fprintf(_coverage_fout, "5334\n");
          fflush(_coverage_fout);
          __cp ++;
          fprintf(_coverage_fout, "5335\n");
          fflush(_coverage_fout);
          *tmp = (char )'\000';
          break;
        } else {
          fprintf(_coverage_fout, "5340\n");
          fflush(_coverage_fout);
          if ((int )*__cp == (int )__reject3) {
            fprintf(_coverage_fout, "5336\n");
            fflush(_coverage_fout);
            tmp = __cp;
            fprintf(_coverage_fout, "5337\n");
            fflush(_coverage_fout);
            __cp ++;
            fprintf(_coverage_fout, "5338\n");
            fflush(_coverage_fout);
            *tmp = (char )'\000';
            break;
          } else {
            fprintf(_coverage_fout, "5339\n");
            fflush(_coverage_fout);

          }
        }
      }
      fprintf(_coverage_fout, "5344\n");
      fflush(_coverage_fout);
      __cp ++;
    }
    fprintf(_coverage_fout, "5347\n");
    fflush(_coverage_fout);
    *__s = __cp;
  } else {
    fprintf(_coverage_fout, "5348\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "5351\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
extern  __attribute__((__nothrow__)) void *malloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *calloc(size_t __nmemb ,
                                                  size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strdup(char const   *__string )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strndup(char const   *__string ,
                                                     size_t __n )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_fail(char const   *__assertion ,
                                  char const   *__file , unsigned int __line ,
                                  char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_perror_fail(int __errnum , char const   *__file ,
                                         unsigned int __line ,
                                         char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert(char const   *__assertion , char const   *__file ,
                             int __line ) ;
extern  __attribute__((__nothrow__)) void insque(void *__elem , void *__prev ) ;
extern  __attribute__((__nothrow__)) void remque(void *__elem ) ;
extern  __attribute__((__nothrow__)) ENTRY *hsearch(ENTRY __item ,
                                                    ACTION __action ) ;
extern  __attribute__((__nothrow__)) int hcreate(size_t __nel ) ;
extern  __attribute__((__nothrow__)) void hdestroy(void) ;
extern void *tsearch(void const   *__key , void **__rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void *tfind(void const   *__key , void * const  *__rootp ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *tdelete(void const   * __restrict  __key ,
                     void ** __restrict  __rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void twalk(void const   *__root ,
                  void (*__action)(void const   *__nodep , VISIT __value ,
                                   int __level ) ) ;
extern void *lfind(void const   *__key , void const   *__base ,
                   size_t *__nmemb , size_t __size ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *lsearch(void const   *__key , void *__base , size_t *__nmemb ,
                     size_t __size , int (*__compar)(void const   * ,
                                                     void const   * ) ) ;
extern struct _IO_FILE_plus _IO_2_1_stdin_ ;
extern struct _IO_FILE_plus _IO_2_1_stdout_ ;
extern struct _IO_FILE_plus _IO_2_1_stderr_ ;
extern int __underflow(_IO_FILE * ) ;
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_feof(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_ferror(_IO_FILE *__fp ) ;
extern int _IO_peekc_locked(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) void _IO_flockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) void _IO_funlockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) int _IO_ftrylockfile(_IO_FILE * ) ;
extern int _IO_vfscanf(_IO_FILE * __restrict   , char const   * __restrict   ,
                       __gnuc_va_list  , int * __restrict   ) ;
extern int _IO_vfprintf(_IO_FILE * __restrict   , char const   * __restrict   ,
                        __gnuc_va_list  ) ;
extern __ssize_t _IO_padn(_IO_FILE * , int  , __ssize_t  ) ;
extern size_t _IO_sgetn(_IO_FILE * , void * , size_t  ) ;
extern __off64_t _IO_seekoff(_IO_FILE * , __off64_t  , int  , int  ) ;
extern __off64_t _IO_seekpos(_IO_FILE * , __off64_t  , int  ) ;
extern  __attribute__((__nothrow__)) void _IO_free_backup_area(_IO_FILE * ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
extern  __attribute__((__nothrow__)) int remove(char const   *__filename ) ;
extern  __attribute__((__nothrow__)) int rename(char const   *__old ,
                                                char const   *__new ) ;
extern  __attribute__((__nothrow__)) int renameat(int __oldfd ,
                                                  char const   *__old ,
                                                  int __newfd ,
                                                  char const   *__new ) ;
extern FILE *tmpfile(void)  __asm__("tmpfile64")  ;
extern  __attribute__((__nothrow__)) char *tmpnam(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tmpnam_r(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tempnam(char const   *__dir ,
                                                   char const   *__pfx )  __attribute__((__malloc__)) ;
extern int fclose(FILE *__stream ) ;
extern int fflush(FILE *__stream ) ;
extern int fflush_unlocked(FILE *__stream ) ;
extern FILE *freopen(char const   * __restrict  __filename ,
                     char const   * __restrict  __modes ,
                     FILE * __restrict  __stream )  __asm__("freopen64")  ;
extern  __attribute__((__nothrow__)) FILE *fdopen(int __fd ,
                                                  char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *fmemopen(void *__s , size_t __len ,
                                                    char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *open_memstream(char **__bufloc ,
                                                          size_t *__sizeloc ) ;
extern  __attribute__((__nothrow__)) void setbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) int setvbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ,
                                                 int __modes , size_t __n ) ;
extern  __attribute__((__nothrow__)) void setbuffer(FILE * __restrict  __stream ,
                                                    char * __restrict  __buf ,
                                                    size_t __size ) ;
extern  __attribute__((__nothrow__)) void setlinebuf(FILE *__stream ) ;
extern int fprintf(FILE * __restrict  __stream ,
                   char const   * __restrict  __format  , ...) ;
extern int printf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sprintf(char * __restrict  __s ,
                                                 char const   * __restrict  __format 
                                                 , ...) ;
extern int vfprintf(FILE * __restrict  __s ,
                    char const   * __restrict  __format , __gnuc_va_list __arg ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vsprintf(char * __restrict  __s ,
                                                  char const   * __restrict  __format ,
                                                  __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  snprintf)(char * __restrict  __s ,
                                                                             size_t __maxlen ,
                                                                             char const   * __restrict  __format 
                                                                             , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsnprintf)(char * __restrict  __s ,
                                                                              size_t __maxlen ,
                                                                              char const   * __restrict  __format ,
                                                                              __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  vdprintf)(int __fd ,
                                               char const   * __restrict  __fmt ,
                                               __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  dprintf)(int __fd ,
                                              char const   * __restrict  __fmt 
                                              , ...) ;
extern int fscanf(FILE * __restrict  __stream ,
                  char const   * __restrict  __format  , ...)  __asm__("__isoc99_fscanf")  ;
extern int scanf(char const   * __restrict  __format  , ...)  __asm__("__isoc99_scanf")  ;
extern  __attribute__((__nothrow__)) int sscanf(char const   * __restrict  __s ,
                                                char const   * __restrict  __format 
                                                , ...)  __asm__("__isoc99_sscanf")  ;
extern int ( /* format attribute */  vfscanf)(FILE * __restrict  __s ,
                                              char const   * __restrict  __format ,
                                              __gnuc_va_list __arg )  __asm__("__isoc99_vfscanf")  ;
extern int ( /* format attribute */  vscanf)(char const   * __restrict  __format ,
                                             __gnuc_va_list __arg )  __asm__("__isoc99_vscanf")  ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsscanf)(char const   * __restrict  __s ,
                                                                            char const   * __restrict  __format ,
                                                                            __gnuc_va_list __arg )  __asm__("__isoc99_vsscanf")  ;
extern int fgetc(FILE *__stream ) ;
extern int getc(FILE *__stream ) ;
__inline extern int getchar(void) ;
__inline extern int getc_unlocked(FILE *__fp ) ;
__inline extern int getchar_unlocked(void) ;
__inline extern int fgetc_unlocked(FILE *__fp ) ;
extern int fputc(int __c , FILE *__stream ) ;
extern int putc(int __c , FILE *__stream ) ;
__inline extern int putchar(int __c ) ;
__inline extern int fputc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putchar_unlocked(int __c ) ;
extern int getw(FILE *__stream ) ;
extern int putw(int __w , FILE *__stream ) ;
extern char *fgets(char * __restrict  __s , int __n ,
                   FILE * __restrict  __stream ) ;
extern char *gets(char *__s ) ;
extern __ssize_t __getdelim(char ** __restrict  __lineptr ,
                            size_t * __restrict  __n , int __delimiter ,
                            FILE * __restrict  __stream ) ;
extern __ssize_t getdelim(char ** __restrict  __lineptr ,
                          size_t * __restrict  __n , int __delimiter ,
                          FILE * __restrict  __stream ) ;
extern __ssize_t getline(char ** __restrict  __lineptr ,
                         size_t * __restrict  __n , FILE * __restrict  __stream ) ;
extern int fputs(char const   * __restrict  __s , FILE * __restrict  __stream ) ;
extern int puts(char const   *__s ) ;
extern int ungetc(int __c , FILE *__stream ) ;
extern size_t fread(void * __restrict  __ptr , size_t __size , size_t __n ,
                    FILE * __restrict  __stream ) ;
extern size_t fwrite(void const   * __restrict  __ptr , size_t __size ,
                     size_t __n , FILE * __restrict  __s ) ;
extern size_t fread_unlocked(void * __restrict  __ptr , size_t __size ,
                             size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite_unlocked(void const   * __restrict  __ptr , size_t __size ,
                              size_t __n , FILE * __restrict  __stream ) ;
extern int fseek(FILE *__stream , long __off , int __whence ) ;
extern long ftell(FILE *__stream ) ;
extern void rewind(FILE *__stream ) ;
extern int fseeko(FILE *__stream , __off64_t __off , int __whence )  __asm__("fseeko64")  ;
extern __off64_t ftello(FILE *__stream )  __asm__("ftello64")  ;
extern int fgetpos(FILE * __restrict  __stream , fpos_t * __restrict  __pos )  __asm__("fgetpos64")  ;
extern int fsetpos(FILE *__stream , fpos_t const   *__pos )  __asm__("fsetpos64")  ;
extern  __attribute__((__nothrow__)) void clearerr(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int feof(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ferror(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void clearerr_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
extern void perror(char const   *__s ) ;
extern int sys_nerr ;
extern char const   * const  sys_errlist[] ;
extern  __attribute__((__nothrow__)) int fileno(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int fileno_unlocked(FILE *__stream ) ;
extern FILE *popen(char const   *__command , char const   *__modes ) ;
extern int pclose(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) char *ctermid(char *__s ) ;
extern  __attribute__((__nothrow__)) void flockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ftrylockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void funlockfile(FILE *__stream ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5352\n");
  fflush(_coverage_fout);
  tmp = vfprintf((FILE */* __restrict  */)stdout, __fmt, __arg);
  fprintf(_coverage_fout, "5353\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int getchar(void) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5354\n");
  fflush(_coverage_fout);
  tmp = _IO_getc(stdin);
  fprintf(_coverage_fout, "5355\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int fgetc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5361\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "5362\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "5356\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "5357\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "5358\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "5359\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "5360\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "5363\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int getc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5369\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "5370\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "5364\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "5365\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "5366\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "5367\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "5368\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "5371\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int getchar_unlocked(void) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5377\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )stdin->_IO_read_ptr >= (unsigned int )stdin->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "5378\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "5372\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(stdin);
    fprintf(_coverage_fout, "5373\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "5374\n");
    fflush(_coverage_fout);
    tmp___1 = stdin->_IO_read_ptr;
    fprintf(_coverage_fout, "5375\n");
    fflush(_coverage_fout);
    (stdin->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "5376\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "5379\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int putchar(int __c ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5380\n");
  fflush(_coverage_fout);
  tmp = _IO_putc(__c, stdout);
  fprintf(_coverage_fout, "5381\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int fputc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5389\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "5390\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "5382\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "5383\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "5384\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "5385\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "5386\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "5387\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "5388\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "5391\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern int putc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5399\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "5400\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "5392\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "5393\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "5394\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "5395\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "5396\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "5397\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "5398\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "5401\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern int putchar_unlocked(int __c ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5409\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )stdout->_IO_write_ptr >= (unsigned int )stdout->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "5410\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "5402\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "5403\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "5404\n");
    fflush(_coverage_fout);
    tmp___1 = stdout->_IO_write_ptr;
    fprintf(_coverage_fout, "5405\n");
    fflush(_coverage_fout);
    (stdout->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "5406\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "5407\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "5408\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "5411\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern int feof_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5412\n");
  fflush(_coverage_fout);
  return ((__stream->_flags & 0x10) != 0);
}
}
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
__inline extern int ferror_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5413\n");
  fflush(_coverage_fout);
  return ((__stream->_flags & 0x20) != 0);
}
}
extern char const   *TIFFGetVersion(void) ;
extern TIFFCodec const   *TIFFFindCODEC(uint16  ) ;
extern TIFFCodec *TIFFRegisterCODEC(uint16  , char const   * ,
                                    int (*)(TIFF * , int  ) ) ;
extern void TIFFUnRegisterCODEC(TIFFCodec * ) ;
extern int TIFFIsCODECConfigured(uint16  ) ;
extern TIFFCodec *TIFFGetConfiguredCODECs(void) ;
extern void *_TIFFmalloc(tmsize_t s ) ;
extern void *_TIFFrealloc(void *p , tmsize_t s ) ;
extern void _TIFFmemset(void *p , int v , tmsize_t c ) ;
extern void _TIFFmemcpy(void *d , void const   *s , tmsize_t c ) ;
extern int _TIFFmemcmp(void const   *p1 , void const   *p2 , tmsize_t c ) ;
extern void _TIFFfree(void *p ) ;
extern int TIFFGetTagListCount(TIFF * ) ;
extern uint32 TIFFGetTagListEntry(TIFF * , int tag_index ) ;
extern TIFFField const   *TIFFFindField(TIFF * , uint32  , TIFFDataType  ) ;
extern TIFFField const   *TIFFFieldWithTag(TIFF * , uint32  ) ;
extern TIFFField const   *TIFFFieldWithName(TIFF * , char const   * ) ;
extern TIFFTagMethods *TIFFAccessTagMethods(TIFF * ) ;
extern void *TIFFGetClientInfo(TIFF * , char const   * ) ;
extern void TIFFSetClientInfo(TIFF * , void * , char const   * ) ;
extern void TIFFCleanup(TIFF *tif ) ;
extern void TIFFClose(TIFF *tif ) ;
extern int TIFFFlush(TIFF *tif ) ;
extern int TIFFFlushData(TIFF *tif ) ;
extern int TIFFGetField(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFVGetField(TIFF *tif , uint32 tag , va_list ap ) ;
extern int TIFFGetFieldDefaulted(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFVGetFieldDefaulted(TIFF *tif , uint32 tag , va_list ap ) ;
extern int TIFFReadDirectory(TIFF *tif ) ;
extern int TIFFReadCustomDirectory(TIFF *tif , uint64 diroff ,
                                   TIFFFieldArray const   *infoarray ) ;
extern int TIFFReadEXIFDirectory(TIFF *tif , uint64 diroff ) ;
extern uint64 TIFFScanlineSize64(TIFF *tif ) ;
extern tmsize_t TIFFScanlineSize(TIFF *tif ) ;
extern uint64 TIFFRasterScanlineSize64(TIFF *tif ) ;
extern tmsize_t TIFFRasterScanlineSize(TIFF *tif ) ;
extern uint64 TIFFStripSize64(TIFF *tif ) ;
extern tmsize_t TIFFStripSize(TIFF *tif ) ;
extern uint64 TIFFRawStripSize64(TIFF *tif , uint32 strip ) ;
extern tmsize_t TIFFRawStripSize(TIFF *tif , uint32 strip ) ;
extern uint64 TIFFVStripSize64(TIFF *tif , uint32 nrows ) ;
extern tmsize_t TIFFVStripSize(TIFF *tif , uint32 nrows ) ;
extern uint64 TIFFTileRowSize64(TIFF *tif ) ;
extern tmsize_t TIFFTileRowSize(TIFF *tif ) ;
extern uint64 TIFFTileSize64(TIFF *tif ) ;
extern tmsize_t TIFFTileSize(TIFF *tif ) ;
extern uint64 TIFFVTileSize64(TIFF *tif , uint32 nrows ) ;
extern tmsize_t TIFFVTileSize(TIFF *tif , uint32 nrows ) ;
extern uint32 TIFFDefaultStripSize(TIFF *tif , uint32 request ) ;
extern void TIFFDefaultTileSize(TIFF * , uint32 * , uint32 * ) ;
extern int TIFFFileno(TIFF * ) ;
extern int TIFFSetFileno(TIFF * , int  ) ;
extern thandle_t TIFFClientdata(TIFF * ) ;
extern thandle_t TIFFSetClientdata(TIFF * , thandle_t  ) ;
extern int TIFFGetMode(TIFF * ) ;
extern int TIFFSetMode(TIFF * , int  ) ;
extern int TIFFIsTiled(TIFF * ) ;
extern int TIFFIsByteSwapped(TIFF * ) ;
extern int TIFFIsUpSampled(TIFF * ) ;
extern int TIFFIsMSB2LSB(TIFF * ) ;
extern int TIFFIsBigEndian(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetReadProc(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetWriteProc(TIFF * ) ;
extern TIFFSeekProc TIFFGetSeekProc(TIFF * ) ;
extern TIFFCloseProc TIFFGetCloseProc(TIFF * ) ;
extern TIFFSizeProc TIFFGetSizeProc(TIFF * ) ;
extern TIFFMapFileProc TIFFGetMapFileProc(TIFF * ) ;
extern TIFFUnmapFileProc TIFFGetUnmapFileProc(TIFF * ) ;
extern uint32 TIFFCurrentRow(TIFF * ) ;
extern uint16 TIFFCurrentDirectory(TIFF * ) ;
extern uint16 TIFFNumberOfDirectories(TIFF * ) ;
extern uint64 TIFFCurrentDirOffset(TIFF * ) ;
extern uint32 TIFFCurrentStrip(TIFF * ) ;
extern uint32 TIFFCurrentTile(TIFF *tif ) ;
extern int TIFFReadBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
extern int TIFFWriteBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
extern int TIFFSetupStrips(TIFF * ) ;
extern int TIFFWriteCheck(TIFF * , int  , char const   * ) ;
extern void TIFFFreeDirectory(TIFF * ) ;
extern int TIFFCreateDirectory(TIFF * ) ;
extern int TIFFLastDirectory(TIFF * ) ;
extern int TIFFSetDirectory(TIFF * , uint16  ) ;
extern int TIFFSetSubDirectory(TIFF * , uint64  ) ;
extern int TIFFUnlinkDirectory(TIFF * , uint16  ) ;
extern int TIFFSetField(TIFF * , uint32   , ...) ;
extern int TIFFVSetField(TIFF * , uint32  , va_list  ) ;
int TIFFWriteDirectory(TIFF *tif ) ;
int TIFFCheckpointDirectory(TIFF *tif ) ;
int TIFFRewriteDirectory(TIFF *tif ) ;
extern void TIFFPrintDirectory(TIFF * , FILE * , long  ) ;
extern int TIFFReadScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) ;
extern int TIFFWriteScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) ;
extern int TIFFReadRGBAImage(TIFF * , uint32  , uint32  , uint32 * , int  ) ;
extern int TIFFReadRGBAImageOriented(TIFF * , uint32  , uint32  , uint32 * ,
                                     int  , int  ) ;
extern int TIFFReadRGBAStrip(TIFF * , uint32  , uint32 * ) ;
extern int TIFFReadRGBATile(TIFF * , uint32  , uint32  , uint32 * ) ;
extern int TIFFRGBAImageOK(TIFF * , char * ) ;
extern int TIFFRGBAImageBegin(TIFFRGBAImage * , TIFF * , int  , char * ) ;
extern int TIFFRGBAImageGet(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
extern void TIFFRGBAImageEnd(TIFFRGBAImage * ) ;
extern TIFF *TIFFOpen(char const   * , char const   * ) ;
extern TIFF *TIFFFdOpen(int  , char const   * , char const   * ) ;
extern TIFF *TIFFClientOpen(char const   * , char const   * , thandle_t  ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            uint64 (*)(thandle_t  , uint64  , int  ) ,
                            int (*)(thandle_t  ) , uint64 (*)(thandle_t  ) ,
                            int (*)(thandle_t  , void **base , toff_t *size ) ,
                            void (*)(thandle_t  , void *base , toff_t size ) ) ;
extern char const   *TIFFFileName(TIFF * ) ;
extern char const   *TIFFSetFileName(TIFF * , char const   * ) ;
extern void TIFFError(char const   * , char const   *  , ...) ;
extern void TIFFErrorExt(thandle_t  , char const   * , char const   *  , ...) ;
extern void TIFFWarning(char const   * , char const   *  , ...) ;
extern void TIFFWarningExt(thandle_t  , char const   * , char const   *  , ...) ;
extern TIFFErrorHandler TIFFSetErrorHandler(void (*)(char const   * ,
                                                     char const   * , va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetErrorHandlerExt(void (*)(thandle_t  ,
                                                           char const   * ,
                                                           char const   * ,
                                                           va_list  ) ) ;
extern TIFFErrorHandler TIFFSetWarningHandler(void (*)(char const   * ,
                                                       char const   * ,
                                                       va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetWarningHandlerExt(void (*)(thandle_t  ,
                                                             char const   * ,
                                                             char const   * ,
                                                             va_list  ) ) ;
extern TIFFExtendProc TIFFSetTagExtender(void (*)(TIFF * ) ) ;
extern uint32 TIFFComputeTile(TIFF *tif , uint32 x , uint32 y , uint32 z ,
                              uint16 s ) ;
extern int TIFFCheckTile(TIFF *tif , uint32 x , uint32 y , uint32 z , uint16 s ) ;
extern uint32 TIFFNumberOfTiles(TIFF * ) ;
extern tmsize_t TIFFReadTile(TIFF *tif , void *buf , uint32 x , uint32 y ,
                             uint32 z , uint16 s ) ;
extern tmsize_t TIFFWriteTile(TIFF *tif , void *buf , uint32 x , uint32 y ,
                              uint32 z , uint16 s ) ;
extern uint32 TIFFComputeStrip(TIFF * , uint32  , uint16  ) ;
extern uint32 TIFFNumberOfStrips(TIFF * ) ;
extern tmsize_t TIFFReadEncodedStrip(TIFF *tif , uint32 strip , void *buf ,
                                     tmsize_t size ) ;
extern tmsize_t TIFFReadRawStrip(TIFF *tif , uint32 strip , void *buf ,
                                 tmsize_t size ) ;
extern tmsize_t TIFFReadEncodedTile(TIFF *tif , uint32 tile , void *buf ,
                                    tmsize_t size ) ;
extern tmsize_t TIFFReadRawTile(TIFF *tif , uint32 tile , void *buf ,
                                tmsize_t size ) ;
extern tmsize_t TIFFWriteEncodedStrip(TIFF *tif , uint32 strip , void *data ,
                                      tmsize_t cc ) ;
extern tmsize_t TIFFWriteRawStrip(TIFF *tif , uint32 strip , void *data ,
                                  tmsize_t cc ) ;
extern tmsize_t TIFFWriteEncodedTile(TIFF *tif , uint32 tile , void *data ,
                                     tmsize_t cc ) ;
extern tmsize_t TIFFWriteRawTile(TIFF *tif , uint32 tile , void *data ,
                                 tmsize_t cc ) ;
extern int TIFFDataWidth(TIFFDataType  ) ;
extern void TIFFSetWriteOffset(TIFF *tif , uint64 off ) ;
extern void TIFFSwabShort(uint16 * ) ;
extern void TIFFSwabLong(uint32 * ) ;
extern void TIFFSwabLong8(uint64 * ) ;
extern void TIFFSwabFloat(float * ) ;
extern void TIFFSwabDouble(double * ) ;
extern void TIFFSwabArrayOfShort(uint16 *wp , tmsize_t n ) ;
extern void TIFFSwabArrayOfTriples(uint8 *tp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong(uint32 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong8(uint64 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfFloat(float *fp , tmsize_t n ) ;
extern void TIFFSwabArrayOfDouble(double *dp , tmsize_t n ) ;
extern void TIFFReverseBits(uint8 *cp , tmsize_t n ) ;
extern unsigned char const   *TIFFGetBitRevTable(int  ) ;
extern double LogL16toY(int  ) ;
extern double LogL10toY(int  ) ;
extern void XYZtoRGB24(float * , uint8 * ) ;
extern int uv_decode(double * , double * , int  ) ;
extern void LogLuv24toXYZ(uint32  , float * ) ;
extern void LogLuv32toXYZ(uint32  , float * ) ;
extern int LogL16fromY(double  , int  ) ;
extern int LogL10fromY(double  , int  ) ;
extern int uv_encode(double  , double  , int  ) ;
extern uint32 LogLuv24fromXYZ(float * , int  ) ;
extern uint32 LogLuv32fromXYZ(float * , int  ) ;
extern int TIFFCIELabToRGBInit(TIFFCIELabToRGB * , TIFFDisplay * , float * ) ;
extern void TIFFCIELabToXYZ(TIFFCIELabToRGB * , uint32  , int32  , int32  ,
                            float * , float * , float * ) ;
extern void TIFFXYZToRGB(TIFFCIELabToRGB * , float  , float  , float  ,
                         uint32 * , uint32 * , uint32 * ) ;
extern int TIFFYCbCrToRGBInit(TIFFYCbCrToRGB * , float * , float * ) ;
extern void TIFFYCbCrtoRGB(TIFFYCbCrToRGB * , uint32  , int32  , int32  ,
                           uint32 * , uint32 * , uint32 * ) ;
extern int TIFFMergeFieldInfo(TIFF * , TIFFFieldInfo const   * , uint32  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfo(TIFF * , uint32  ,
                                                TIFFDataType  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfoByName(TIFF * , char const   * ,
                                                      TIFFDataType  ) ;
extern TIFFFieldArray const   *_TIFFGetFields(void) ;
extern TIFFFieldArray const   *_TIFFGetExifFields(void) ;
extern void _TIFFSetupFields(TIFF *tif , TIFFFieldArray const   *infoarray ) ;
extern void _TIFFPrintFieldInfo(TIFF * , FILE * ) ;
extern int _TIFFMergeFields(TIFF * , TIFFField const   * , uint32  ) ;
extern TIFFField const   *_TIFFFindOrRegisterField(TIFF * , uint32  ,
                                                   TIFFDataType  ) ;
extern TIFFField *_TIFFCreateAnonField(TIFF * , uint32  , TIFFDataType  ) ;
extern int _TIFFgetMode(char const   *mode , char const   *module ) ;
extern int _TIFFNoRowEncode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoStripEncode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoTileEncode(TIFF * , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoRowDecode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoStripDecode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoTileDecode(TIFF * , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern void _TIFFNoPostDecode(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern int _TIFFNoPreCode(TIFF *tif , uint16 s ) ;
extern int _TIFFNoSeek(TIFF *tif , uint32 off ) ;
extern void _TIFFSwab16BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab24BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab32BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab64BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern int TIFFFlushData1(TIFF *tif ) ;
extern int TIFFDefaultDirectory(TIFF *tif ) ;
extern void _TIFFSetDefaultCompressionState(TIFF *tif ) ;
extern int TIFFSetCompressionScheme(TIFF *tif , int scheme ) ;
extern int TIFFSetDefaultCompressionState(TIFF *tif ) ;
extern uint32 _TIFFDefaultStripSize(TIFF *tif , uint32 s ) ;
extern void _TIFFDefaultTileSize(TIFF *tif , uint32 *tw , uint32 *th ) ;
extern int _TIFFDataSize(TIFFDataType type ) ;
extern void _TIFFsetByteArray(void ** , void * , uint32  ) ;
extern void _TIFFsetString(char ** , char * ) ;
extern void _TIFFsetShortArray(uint16 ** , uint16 * , uint32  ) ;
extern void _TIFFsetLongArray(uint32 ** , uint32 * , uint32  ) ;
extern void _TIFFsetFloatArray(float ** , float * , uint32  ) ;
extern void _TIFFsetDoubleArray(double ** , double * , uint32  ) ;
extern void _TIFFprintAscii(FILE * , char const   * ) ;
extern void _TIFFprintAsciiTag(FILE * , char const   * , char const   * ) ;
extern void (*_TIFFwarningHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFerrorHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFwarningHandlerExt)(thandle_t  , char const   * ,
                                      char const   * , va_list  ) ;
extern void (*_TIFFerrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  ) ;
extern void *_TIFFCheckMalloc(TIFF *tif , tmsize_t nmemb , tmsize_t elem_size ,
                              char const   *what ) ;
extern void *_TIFFCheckRealloc(TIFF *tif , void *buffer , tmsize_t nmemb ,
                               tmsize_t elem_size , char const   *what ) ;
extern double _TIFFUInt64ToDouble(uint64  ) ;
extern float _TIFFUInt64ToFloat(uint64  ) ;
extern int TIFFInitDumpMode(TIFF * , int  ) ;
extern int TIFFInitPackBits(TIFF * , int  ) ;
extern int TIFFInitCCITTRLE(TIFF * , int  ) ;
extern int TIFFInitCCITTRLEW(TIFF * , int  ) ;
extern int TIFFInitCCITTFax3(TIFF * , int  ) ;
extern int TIFFInitCCITTFax4(TIFF * , int  ) ;
extern int TIFFInitThunderScan(TIFF * , int  ) ;
extern int TIFFInitNeXT(TIFF * , int  ) ;
extern int TIFFInitLZW(TIFF * , int  ) ;
extern int TIFFInitZIP(TIFF * , int  ) ;
extern int TIFFInitPixarLog(TIFF * , int  ) ;
extern int TIFFInitSGILog(TIFF * , int  ) ;
extern TIFFCodec _TIFFBuiltinCODECS[] ;
static int TIFFWriteDirectorySec(TIFF *tif , int isimage , int imagedone ,
                                 uint64 *pdiroff ) ;
static int TIFFWriteDirectoryTagSampleformatPerSample(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag , double value ) ;
static int TIFFWriteDirectoryTagAscii(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      uint32 count , char *value ) ;
static int TIFFWriteDirectoryTagUndefinedArray(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , uint8 *value ) ;
static int TIFFWriteDirectoryTagByte(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint8 value ) ;
static int TIFFWriteDirectoryTagByteArray(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint8 *value ) ;
static int TIFFWriteDirectoryTagBytePerSample(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint8 value ) ;
static int TIFFWriteDirectoryTagSbyte(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      int8 value ) ;
static int TIFFWriteDirectoryTagSbyteArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , int8 *value ) ;
static int TIFFWriteDirectoryTagSbytePerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               int8 value ) ;
static int TIFFWriteDirectoryTagShort(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      uint16 value ) ;
static int TIFFWriteDirectoryTagShortArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , uint16 *value ) ;
static int TIFFWriteDirectoryTagShortPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint16 value ) ;
static int TIFFWriteDirectoryTagSshort(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir , uint16 tag ,
                                       int16 value ) ;
static int TIFFWriteDirectoryTagSshortArray(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , int16 *value ) ;
static int TIFFWriteDirectoryTagSshortPerSample(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                int16 value ) ;
static int TIFFWriteDirectoryTagLong(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint32 value ) ;
static int TIFFWriteDirectoryTagLongArray(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint32 *value ) ;
static int TIFFWriteDirectoryTagLongPerSample(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint32 value ) ;
static int TIFFWriteDirectoryTagSlong(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      int32 value ) ;
static int TIFFWriteDirectoryTagSlongArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , int32 *value ) ;
static int TIFFWriteDirectoryTagSlongPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               int32 value ) ;
static int TIFFWriteDirectoryTagLong8(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      uint64 value ) ;
static int TIFFWriteDirectoryTagLong8Array(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , uint64 *value ) ;
static int TIFFWriteDirectoryTagSlong8(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir , uint16 tag ,
                                       int64 value ) ;
static int TIFFWriteDirectoryTagSlong8Array(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , int64 *value ) ;
static int TIFFWriteDirectoryTagRational(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir , uint16 tag ,
                                         double value ) ;
static int TIFFWriteDirectoryTagRationalArray(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint32 count , float *value ) ;
static int TIFFWriteDirectoryTagSrationalArray(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , float *value ) ;
static int TIFFWriteDirectoryTagFloat(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      float value ) ;
static int TIFFWriteDirectoryTagFloatArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , float *value ) ;
static int TIFFWriteDirectoryTagFloatPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               float value ) ;
static int TIFFWriteDirectoryTagDouble(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir , uint16 tag ,
                                       double value ) ;
static int TIFFWriteDirectoryTagDoubleArray(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , double *value ) ;
static int TIFFWriteDirectoryTagDoublePerSample(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                double value ) ;
static int TIFFWriteDirectoryTagIfdArray(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir , uint16 tag ,
                                         uint32 count , uint32 *value ) ;
static int TIFFWriteDirectoryTagIfd8Array(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint64 *value ) ;
static int TIFFWriteDirectoryTagShortLong(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 value ) ;
static int TIFFWriteDirectoryTagLongLong8Array(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , uint64 *value ) ;
static int TIFFWriteDirectoryTagShortLongLong8Array(TIFF *tif , uint32 *ndir ,
                                                    TIFFDirEntry *dir ,
                                                    uint16 tag , uint32 count ,
                                                    uint64 *value ) ;
static int TIFFWriteDirectoryTagColormap(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir ) ;
static int TIFFWriteDirectoryTagTransferfunction(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ) ;
static int TIFFWriteDirectoryTagSubifd(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir ) ;
static int TIFFWriteDirectoryTagCheckedAscii(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             uint32 count , char *value ) ;
static int TIFFWriteDirectoryTagCheckedUndefinedArray(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag ,
                                                      uint32 count ,
                                                      uint8 *value ) ;
static int TIFFWriteDirectoryTagCheckedByte(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint8 value ) ;
static int TIFFWriteDirectoryTagCheckedByteArray(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint8 *value ) ;
static int TIFFWriteDirectoryTagCheckedSbyte(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             int8 value ) ;
static int TIFFWriteDirectoryTagCheckedSbyteArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  int8 *value ) ;
static int TIFFWriteDirectoryTagCheckedShort(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             uint16 value ) ;
static int TIFFWriteDirectoryTagCheckedShortArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  uint16 *value ) ;
static int TIFFWriteDirectoryTagCheckedSshort(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              int16 value ) ;
static int TIFFWriteDirectoryTagCheckedSshortArray(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   int16 *value ) ;
static int TIFFWriteDirectoryTagCheckedLong(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 value ) ;
static int TIFFWriteDirectoryTagCheckedLongArray(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint32 *value ) ;
static int TIFFWriteDirectoryTagCheckedSlong(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             int32 value ) ;
static int TIFFWriteDirectoryTagCheckedSlongArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  int32 *value ) ;
static int TIFFWriteDirectoryTagCheckedLong8(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             uint64 value ) ;
static int TIFFWriteDirectoryTagCheckedLong8Array(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  uint64 *value ) ;
static int TIFFWriteDirectoryTagCheckedSlong8(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              int64 value ) ;
static int TIFFWriteDirectoryTagCheckedSlong8Array(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   int64 *value ) ;
static int TIFFWriteDirectoryTagCheckedRational(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                double value ) ;
static int TIFFWriteDirectoryTagCheckedRationalArray(TIFF *tif , uint32 *ndir ,
                                                     TIFFDirEntry *dir ,
                                                     uint16 tag , uint32 count ,
                                                     float *value ) ;
static int TIFFWriteDirectoryTagCheckedSrationalArray(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag ,
                                                      uint32 count ,
                                                      float *value ) ;
static int TIFFWriteDirectoryTagCheckedFloat(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             float value ) ;
static int TIFFWriteDirectoryTagCheckedFloatArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  float *value ) ;
static int TIFFWriteDirectoryTagCheckedDouble(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              double value ) ;
static int TIFFWriteDirectoryTagCheckedDoubleArray(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   double *value ) ;
static int TIFFWriteDirectoryTagCheckedIfdArray(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                uint32 count , uint32 *value ) ;
static int TIFFWriteDirectoryTagCheckedIfd8Array(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint64 *value ) ;
static int TIFFWriteDirectoryTagData(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint16 datatype , uint32 count ,
                                     uint32 datalength , void *data ) ;
static int TIFFLinkDirectory(TIFF *tif ) ;
int TIFFWriteDirectory(TIFF *tif ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5414\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectorySec(tif, 1, 1, (uint64 *)((void *)0));
  fprintf(_coverage_fout, "5415\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
int TIFFCheckpointDirectory(TIFF *tif ) 
{ int rc ;
  uint64 tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5418\n");
  fflush(_coverage_fout);
  if ((unsigned int )tif->tif_dir.td_stripoffset == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "5416\n");
    fflush(_coverage_fout);
    TIFFSetupStrips(tif);
  } else {
    fprintf(_coverage_fout, "5417\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "5419\n");
  fflush(_coverage_fout);
  rc = TIFFWriteDirectorySec(tif, 1, 0, (uint64 *)((void *)0));
  fprintf(_coverage_fout, "5420\n");
  fflush(_coverage_fout);
  tmp = (*(tif->tif_seekproc))(tif->tif_clientdata, 0ULL, 2);
  fprintf(_coverage_fout, "5421\n");
  fflush(_coverage_fout);
  TIFFSetWriteOffset(tif, tmp);
  fprintf(_coverage_fout, "5422\n");
  fflush(_coverage_fout);
  return (rc);
}
}
int TIFFWriteCustomDirectory(TIFF *tif , uint64 *pdiroff ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5423\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectorySec(tif, 0, 0, pdiroff);
  fprintf(_coverage_fout, "5424\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
int TIFFRewriteDirectory(TIFF *tif ) ;
static char const   module[21]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'R',      (char const   )'e',      (char const   )'w',      (char const   )'r', 
        (char const   )'i',      (char const   )'t',      (char const   )'e',      (char const   )'D', 
        (char const   )'i',      (char const   )'r',      (char const   )'e',      (char const   )'c', 
        (char const   )'t',      (char const   )'o',      (char const   )'r',      (char const   )'y', 
        (char const   )'\000'};
int TIFFRewriteDirectory(TIFF *tif ) 
{ int tmp ;
  tmsize_t tmp___0 ;
  uint32 nextdir ;
  uint16 dircount ;
  uint32 nextnextdir ;
  uint64 tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  uint32 m ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  uint64 nextdir___0 ;
  uint64 dircount64 ;
  uint16 dircount___0 ;
  uint64 nextnextdir___0 ;
  uint64 tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  uint64 m___0 ;
  tmsize_t tmp___9 ;
  int tmp___10 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5519\n");
  fflush(_coverage_fout);
  if (tif->tif_diroff == 0ULL) {
    fprintf(_coverage_fout, "5425\n");
    fflush(_coverage_fout);
    tmp = TIFFWriteDirectory(tif);
    fprintf(_coverage_fout, "5426\n");
    fflush(_coverage_fout);
    return (tmp);
  } else {
    fprintf(_coverage_fout, "5427\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "5520\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "5470\n");
    fflush(_coverage_fout);
    if ((uint64 )tif->tif_header.classic.tiff_diroff == tif->tif_diroff) {
      fprintf(_coverage_fout, "5431\n");
      fflush(_coverage_fout);
      tif->tif_header.classic.tiff_diroff = 0U;
      fprintf(_coverage_fout, "5432\n");
      fflush(_coverage_fout);
      tif->tif_diroff = 0ULL;
      fprintf(_coverage_fout, "5433\n");
      fflush(_coverage_fout);
      (*(tif->tif_seekproc))(tif->tif_clientdata, 4ULL, 0);
      fprintf(_coverage_fout, "5434\n");
      fflush(_coverage_fout);
      tmp___0 = (*(tif->tif_writeproc))(tif->tif_clientdata,
                                        (void *)(& tif->tif_header.classic.tiff_diroff),
                                        4L);
      fprintf(_coverage_fout, "5435\n");
      fflush(_coverage_fout);
      if (tmp___0 == 4L) {
        fprintf(_coverage_fout, "5428\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "5429\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                     "Error updating TIFF header");
        fprintf(_coverage_fout, "5430\n");
        fflush(_coverage_fout);
        return (0);
      }
    } else {
      fprintf(_coverage_fout, "5468\n");
      fflush(_coverage_fout);
      nextdir = tif->tif_header.classic.tiff_diroff;
      fprintf(_coverage_fout, "5469\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "5459\n");
        fflush(_coverage_fout);
        tmp___1 = (*(tif->tif_seekproc))(tif->tif_clientdata,
                                         (unsigned long long )nextdir, 0);
        fprintf(_coverage_fout, "5460\n");
        fflush(_coverage_fout);
        if (tmp___1 == (uint64 )nextdir) {
          fprintf(_coverage_fout, "5439\n");
          fflush(_coverage_fout);
          tmp___2 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                           (void *)(& dircount), 2L);
          fprintf(_coverage_fout, "5440\n");
          fflush(_coverage_fout);
          if (tmp___2 == 2L) {
            fprintf(_coverage_fout, "5436\n");
            fflush(_coverage_fout);

          } else {
            fprintf(_coverage_fout, "5437\n");
            fflush(_coverage_fout);
            TIFFErrorExt(tif->tif_clientdata, module,
                         "Error fetching directory count");
            fprintf(_coverage_fout, "5438\n");
            fflush(_coverage_fout);
            return (0);
          }
        } else {
          fprintf(_coverage_fout, "5441\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module,
                       "Error fetching directory count");
          fprintf(_coverage_fout, "5442\n");
          fflush(_coverage_fout);
          return (0);
        }
        fprintf(_coverage_fout, "5461\n");
        fflush(_coverage_fout);
        if (tif->tif_flags & 128U) {
          fprintf(_coverage_fout, "5443\n");
          fflush(_coverage_fout);
          TIFFSwabShort(& dircount);
        } else {
          fprintf(_coverage_fout, "5444\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "5462\n");
        fflush(_coverage_fout);
        (*(tif->tif_seekproc))(tif->tif_clientdata,
                               (unsigned long long )((nextdir + 2U) + (uint32 )((int )dircount * 12)),
                               0);
        fprintf(_coverage_fout, "5463\n");
        fflush(_coverage_fout);
        tmp___3 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                         (void *)(& nextnextdir), 4L);
        fprintf(_coverage_fout, "5464\n");
        fflush(_coverage_fout);
        if (tmp___3 == 4L) {
          fprintf(_coverage_fout, "5445\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "5446\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module,
                       "Error fetching directory link");
          fprintf(_coverage_fout, "5447\n");
          fflush(_coverage_fout);
          return (0);
        }
        fprintf(_coverage_fout, "5465\n");
        fflush(_coverage_fout);
        if (tif->tif_flags & 128U) {
          fprintf(_coverage_fout, "5448\n");
          fflush(_coverage_fout);
          TIFFSwabLong(& nextnextdir);
        } else {
          fprintf(_coverage_fout, "5449\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "5466\n");
        fflush(_coverage_fout);
        if ((uint64 )nextnextdir == tif->tif_diroff) {
          fprintf(_coverage_fout, "5453\n");
          fflush(_coverage_fout);
          m = 0U;
          fprintf(_coverage_fout, "5454\n");
          fflush(_coverage_fout);
          (*(tif->tif_seekproc))(tif->tif_clientdata,
                                 (unsigned long long )((nextdir + 2U) + (uint32 )((int )dircount * 12)),
                                 0);
          fprintf(_coverage_fout, "5455\n");
          fflush(_coverage_fout);
          tmp___4 = (*(tif->tif_writeproc))(tif->tif_clientdata, (void *)(& m),
                                            4L);
          fprintf(_coverage_fout, "5456\n");
          fflush(_coverage_fout);
          if (tmp___4 == 4L) {
            fprintf(_coverage_fout, "5450\n");
            fflush(_coverage_fout);

          } else {
            fprintf(_coverage_fout, "5451\n");
            fflush(_coverage_fout);
            TIFFErrorExt(tif->tif_clientdata, module,
                         "Error writing directory link");
            fprintf(_coverage_fout, "5452\n");
            fflush(_coverage_fout);
            return (0);
          }
          fprintf(_coverage_fout, "5457\n");
          fflush(_coverage_fout);
          tif->tif_diroff = 0ULL;
          break;
        } else {
          fprintf(_coverage_fout, "5458\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "5467\n");
        fflush(_coverage_fout);
        nextdir = nextnextdir;
      }
    }
  } else {
    fprintf(_coverage_fout, "5518\n");
    fflush(_coverage_fout);
    if (tif->tif_header.big.tiff_diroff == tif->tif_diroff) {
      fprintf(_coverage_fout, "5474\n");
      fflush(_coverage_fout);
      tif->tif_header.big.tiff_diroff = 0ULL;
      fprintf(_coverage_fout, "5475\n");
      fflush(_coverage_fout);
      tif->tif_diroff = 0ULL;
      fprintf(_coverage_fout, "5476\n");
      fflush(_coverage_fout);
      (*(tif->tif_seekproc))(tif->tif_clientdata, 8ULL, 0);
      fprintf(_coverage_fout, "5477\n");
      fflush(_coverage_fout);
      tmp___5 = (*(tif->tif_writeproc))(tif->tif_clientdata,
                                        (void *)(& tif->tif_header.big.tiff_diroff),
                                        8L);
      fprintf(_coverage_fout, "5478\n");
      fflush(_coverage_fout);
      if (tmp___5 == 8L) {
        fprintf(_coverage_fout, "5471\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "5472\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                     "Error updating TIFF header");
        fprintf(_coverage_fout, "5473\n");
        fflush(_coverage_fout);
        return (0);
      }
    } else {
      fprintf(_coverage_fout, "5516\n");
      fflush(_coverage_fout);
      nextdir___0 = tif->tif_header.big.tiff_diroff;
      fprintf(_coverage_fout, "5517\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "5505\n");
        fflush(_coverage_fout);
        tmp___6 = (*(tif->tif_seekproc))(tif->tif_clientdata, nextdir___0, 0);
        fprintf(_coverage_fout, "5506\n");
        fflush(_coverage_fout);
        if (tmp___6 == nextdir___0) {
          fprintf(_coverage_fout, "5482\n");
          fflush(_coverage_fout);
          tmp___7 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                           (void *)(& dircount64), 8L);
          fprintf(_coverage_fout, "5483\n");
          fflush(_coverage_fout);
          if (tmp___7 == 8L) {
            fprintf(_coverage_fout, "5479\n");
            fflush(_coverage_fout);

          } else {
            fprintf(_coverage_fout, "5480\n");
            fflush(_coverage_fout);
            TIFFErrorExt(tif->tif_clientdata, module,
                         "Error fetching directory count");
            fprintf(_coverage_fout, "5481\n");
            fflush(_coverage_fout);
            return (0);
          }
        } else {
          fprintf(_coverage_fout, "5484\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module,
                       "Error fetching directory count");
          fprintf(_coverage_fout, "5485\n");
          fflush(_coverage_fout);
          return (0);
        }
        fprintf(_coverage_fout, "5507\n");
        fflush(_coverage_fout);
        if (tif->tif_flags & 128U) {
          fprintf(_coverage_fout, "5486\n");
          fflush(_coverage_fout);
          TIFFSwabLong8(& dircount64);
        } else {
          fprintf(_coverage_fout, "5487\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "5508\n");
        fflush(_coverage_fout);
        if (dircount64 > 65535ULL) {
          fprintf(_coverage_fout, "5488\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module,
                       "Sanity check on tag count failed, likely corrupt TIFF");
          fprintf(_coverage_fout, "5489\n");
          fflush(_coverage_fout);
          return (0);
        } else {
          fprintf(_coverage_fout, "5490\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "5509\n");
        fflush(_coverage_fout);
        dircount___0 = (unsigned short )dircount64;
        fprintf(_coverage_fout, "5510\n");
        fflush(_coverage_fout);
        (*(tif->tif_seekproc))(tif->tif_clientdata,
                               (nextdir___0 + 8ULL) + (uint64 )((int )dircount___0 * 20),
                               0);
        fprintf(_coverage_fout, "5511\n");
        fflush(_coverage_fout);
        tmp___8 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                         (void *)(& nextnextdir___0), 8L);
        fprintf(_coverage_fout, "5512\n");
        fflush(_coverage_fout);
        if (tmp___8 == 8L) {
          fprintf(_coverage_fout, "5491\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "5492\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module,
                       "Error fetching directory link");
          fprintf(_coverage_fout, "5493\n");
          fflush(_coverage_fout);
          return (0);
        }
        fprintf(_coverage_fout, "5513\n");
        fflush(_coverage_fout);
        if (tif->tif_flags & 128U) {
          fprintf(_coverage_fout, "5494\n");
          fflush(_coverage_fout);
          TIFFSwabLong8(& nextnextdir___0);
        } else {
          fprintf(_coverage_fout, "5495\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "5514\n");
        fflush(_coverage_fout);
        if (nextnextdir___0 == tif->tif_diroff) {
          fprintf(_coverage_fout, "5499\n");
          fflush(_coverage_fout);
          m___0 = 0ULL;
          fprintf(_coverage_fout, "5500\n");
          fflush(_coverage_fout);
          (*(tif->tif_seekproc))(tif->tif_clientdata,
                                 (nextdir___0 + 8ULL) + (uint64 )((int )dircount___0 * 20),
                                 0);
          fprintf(_coverage_fout, "5501\n");
          fflush(_coverage_fout);
          tmp___9 = (*(tif->tif_writeproc))(tif->tif_clientdata,
                                            (void *)(& m___0), 8L);
          fprintf(_coverage_fout, "5502\n");
          fflush(_coverage_fout);
          if (tmp___9 == 8L) {
            fprintf(_coverage_fout, "5496\n");
            fflush(_coverage_fout);

          } else {
            fprintf(_coverage_fout, "5497\n");
            fflush(_coverage_fout);
            TIFFErrorExt(tif->tif_clientdata, module,
                         "Error writing directory link");
            fprintf(_coverage_fout, "5498\n");
            fflush(_coverage_fout);
            return (0);
          }
          fprintf(_coverage_fout, "5503\n");
          fflush(_coverage_fout);
          tif->tif_diroff = 0ULL;
          break;
        } else {
          fprintf(_coverage_fout, "5504\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "5515\n");
        fflush(_coverage_fout);
        nextdir___0 = nextnextdir___0;
      }
    }
  }
  fprintf(_coverage_fout, "5521\n");
  fflush(_coverage_fout);
  tmp___10 = TIFFWriteDirectory(tif);
  fprintf(_coverage_fout, "5522\n");
  fflush(_coverage_fout);
  return (tmp___10);
}
}
static int TIFFWriteDirectorySec(TIFF *tif , int isimage , int imagedone ,
                                 uint64 *pdiroff ) ;
static char const   module___0[22]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'S',      (char const   )'e', 
        (char const   )'c',      (char const   )'\000'};
static int TIFFWriteDirectorySec(TIFF *tif , int isimage , int imagedone ,
                                 uint64 *pdiroff ) 
{ uint32 ndir ;
  TIFFDirEntry *dir ;
  uint32 dirsize ;
  void *dirmem ;
  uint32 m ;
  tmsize_t orig_rawcc ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  int tmp___17 ;
  int tmp___18 ;
  int tmp___19 ;
  int tmp___20 ;
  int tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;
  int tmp___24 ;
  int tmp___25 ;
  int tmp___26 ;
  int tmp___27 ;
  uint16 na ;
  uint16 *nb ;
  int tmp___28 ;
  int tmp___29 ;
  int tmp___30 ;
  int tmp___31 ;
  int tmp___32 ;
  int tmp___33 ;
  int tmp___34 ;
  int tmp___35 ;
  int tmp___36 ;
  int tmp___37 ;
  int tmp___38 ;
  int tmp___39 ;
  uint32 n ;
  TIFFField const   *o ;
  uint32 pa ;
  char *pb ;
  size_t tmp___40 ;
  int tmp___41 ;
  uint16 p ;
  int tmp___42 ;
  uint32 p___0 ;
  int tmp___43 ;
  uint32 pa___0 ;
  void *pb___0 ;
  int tmp___44 ;
  int tmp___45 ;
  int tmp___46 ;
  int tmp___47 ;
  int tmp___48 ;
  int tmp___49 ;
  int tmp___50 ;
  int tmp___51 ;
  int tmp___52 ;
  int tmp___53 ;
  int tmp___54 ;
  int tmp___55 ;
  int tmp___56 ;
  int tmp___57 ;
  int tmp___58 ;
  int tmp___59 ;
  int tmp___60 ;
  void *tmp___61 ;
  int tmp___62 ;
  uint64 tmp___63 ;
  uint32 na___0 ;
  TIFFDirEntry *nb___0 ;
  uint8 *n___0 ;
  TIFFDirEntry *o___0 ;
  uint8 *n___1 ;
  TIFFDirEntry *o___1 ;
  uint64 tmp___64 ;
  tmsize_t tmp___65 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5997\n");
  fflush(_coverage_fout);
  if (tif->tif_mode == 00) {
    fprintf(_coverage_fout, "5523\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "5524\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "5998\n");
  fflush(_coverage_fout);
  if (imagedone) {
    fprintf(_coverage_fout, "5549\n");
    fflush(_coverage_fout);
    orig_rawcc = tif->tif_rawcc;
    fprintf(_coverage_fout, "5550\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 4096U) {
      fprintf(_coverage_fout, "5528\n");
      fflush(_coverage_fout);
      tif->tif_flags &= 4294963199U;
      fprintf(_coverage_fout, "5529\n");
      fflush(_coverage_fout);
      tmp = (*(tif->tif_postencode))(tif);
      fprintf(_coverage_fout, "5530\n");
      fflush(_coverage_fout);
      if (tmp) {
        fprintf(_coverage_fout, "5525\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "5526\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___0,
                     "Error post-encoding before directory write");
        fprintf(_coverage_fout, "5527\n");
        fflush(_coverage_fout);
        return (0);
      }
    } else {
      fprintf(_coverage_fout, "5531\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "5551\n");
    fflush(_coverage_fout);
    (*(tif->tif_close))(tif);
    fprintf(_coverage_fout, "5552\n");
    fflush(_coverage_fout);
    if (tif->tif_rawcc > 0L) {
      fprintf(_coverage_fout, "5540\n");
      fflush(_coverage_fout);
      if (tif->tif_rawcc != orig_rawcc) {
        fprintf(_coverage_fout, "5538\n");
        fflush(_coverage_fout);
        if ((tif->tif_flags & 64U) != 0U) {
          fprintf(_coverage_fout, "5535\n");
          fflush(_coverage_fout);
          tmp___0 = TIFFFlushData1(tif);
          fprintf(_coverage_fout, "5536\n");
          fflush(_coverage_fout);
          if (tmp___0) {
            fprintf(_coverage_fout, "5532\n");
            fflush(_coverage_fout);

          } else {
            fprintf(_coverage_fout, "5533\n");
            fflush(_coverage_fout);
            TIFFErrorExt(tif->tif_clientdata, module___0,
                         "Error flushing data before directory write");
            fprintf(_coverage_fout, "5534\n");
            fflush(_coverage_fout);
            return (0);
          }
        } else {
          fprintf(_coverage_fout, "5537\n");
          fflush(_coverage_fout);

        }
      } else {
        fprintf(_coverage_fout, "5539\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "5541\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "5553\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 512U) {
      fprintf(_coverage_fout, "5547\n");
      fflush(_coverage_fout);
      if (tif->tif_rawdata) {
        fprintf(_coverage_fout, "5542\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)tif->tif_rawdata);
        fprintf(_coverage_fout, "5543\n");
        fflush(_coverage_fout);
        tif->tif_rawdata = (uint8 *)((void *)0);
        fprintf(_coverage_fout, "5544\n");
        fflush(_coverage_fout);
        tif->tif_rawcc = 0L;
        fprintf(_coverage_fout, "5545\n");
        fflush(_coverage_fout);
        tif->tif_rawdatasize = 0L;
      } else {
        fprintf(_coverage_fout, "5546\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "5548\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "5554\n");
    fflush(_coverage_fout);
    tif->tif_flags &= 4294967215U;
  } else {
    fprintf(_coverage_fout, "5555\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "5999\n");
  fflush(_coverage_fout);
  dir = (TIFFDirEntry *)((void *)0);
  fprintf(_coverage_fout, "6000\n");
  fflush(_coverage_fout);
  dirmem = (void *)0;
  fprintf(_coverage_fout, "6001\n");
  fflush(_coverage_fout);
  dirsize = 0U;
  fprintf(_coverage_fout, "6002\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "5886\n");
    fflush(_coverage_fout);
    ndir = 0U;
    fprintf(_coverage_fout, "5887\n");
    fflush(_coverage_fout);
    if (isimage) {
      fprintf(_coverage_fout, "5774\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 1)) {
        fprintf(_coverage_fout, "5558\n");
        fflush(_coverage_fout);
        tmp___1 = TIFFWriteDirectoryTagShortLong(tif, & ndir, dir,
                                                 (unsigned short)256,
                                                 tif->tif_dir.td_imagewidth);
        fprintf(_coverage_fout, "5559\n");
        fflush(_coverage_fout);
        if (tmp___1) {
          fprintf(_coverage_fout, "5556\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
        fprintf(_coverage_fout, "5560\n");
        fflush(_coverage_fout);
        tmp___2 = TIFFWriteDirectoryTagShortLong(tif, & ndir, dir,
                                                 (unsigned short)257,
                                                 tif->tif_dir.td_imagelength);
        fprintf(_coverage_fout, "5561\n");
        fflush(_coverage_fout);
        if (tmp___2) {
          fprintf(_coverage_fout, "5557\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5562\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5775\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 2)) {
        fprintf(_coverage_fout, "5565\n");
        fflush(_coverage_fout);
        tmp___3 = TIFFWriteDirectoryTagShortLong(tif, & ndir, dir,
                                                 (unsigned short)322,
                                                 tif->tif_dir.td_tilewidth);
        fprintf(_coverage_fout, "5566\n");
        fflush(_coverage_fout);
        if (tmp___3) {
          fprintf(_coverage_fout, "5563\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
        fprintf(_coverage_fout, "5567\n");
        fflush(_coverage_fout);
        tmp___4 = TIFFWriteDirectoryTagShortLong(tif, & ndir, dir,
                                                 (unsigned short)323,
                                                 tif->tif_dir.td_tilelength);
        fprintf(_coverage_fout, "5568\n");
        fflush(_coverage_fout);
        if (tmp___4) {
          fprintf(_coverage_fout, "5564\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5569\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5776\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 3)) {
        fprintf(_coverage_fout, "5572\n");
        fflush(_coverage_fout);
        tmp___5 = TIFFWriteDirectoryTagRational(tif, & ndir, dir,
                                                (unsigned short)282,
                                                (double )tif->tif_dir.td_xresolution);
        fprintf(_coverage_fout, "5573\n");
        fflush(_coverage_fout);
        if (tmp___5) {
          fprintf(_coverage_fout, "5570\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
        fprintf(_coverage_fout, "5574\n");
        fflush(_coverage_fout);
        tmp___6 = TIFFWriteDirectoryTagRational(tif, & ndir, dir,
                                                (unsigned short)283,
                                                (double )tif->tif_dir.td_yresolution);
        fprintf(_coverage_fout, "5575\n");
        fflush(_coverage_fout);
        if (tmp___6) {
          fprintf(_coverage_fout, "5571\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5576\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5777\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 4)) {
        fprintf(_coverage_fout, "5579\n");
        fflush(_coverage_fout);
        tmp___7 = TIFFWriteDirectoryTagRational(tif, & ndir, dir,
                                                (unsigned short)286,
                                                (double )tif->tif_dir.td_xposition);
        fprintf(_coverage_fout, "5580\n");
        fflush(_coverage_fout);
        if (tmp___7) {
          fprintf(_coverage_fout, "5577\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
        fprintf(_coverage_fout, "5581\n");
        fflush(_coverage_fout);
        tmp___8 = TIFFWriteDirectoryTagRational(tif, & ndir, dir,
                                                (unsigned short)287,
                                                (double )tif->tif_dir.td_yposition);
        fprintf(_coverage_fout, "5582\n");
        fflush(_coverage_fout);
        if (tmp___8) {
          fprintf(_coverage_fout, "5578\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5583\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5778\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 5)) {
        fprintf(_coverage_fout, "5585\n");
        fflush(_coverage_fout);
        tmp___9 = TIFFWriteDirectoryTagLong(tif, & ndir, dir,
                                            (unsigned short)254,
                                            tif->tif_dir.td_subfiletype);
        fprintf(_coverage_fout, "5586\n");
        fflush(_coverage_fout);
        if (tmp___9) {
          fprintf(_coverage_fout, "5584\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5587\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5779\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 6)) {
        fprintf(_coverage_fout, "5589\n");
        fflush(_coverage_fout);
        tmp___10 = TIFFWriteDirectoryTagShortPerSample(tif, & ndir, dir,
                                                       (unsigned short)258,
                                                       tif->tif_dir.td_bitspersample);
        fprintf(_coverage_fout, "5590\n");
        fflush(_coverage_fout);
        if (tmp___10) {
          fprintf(_coverage_fout, "5588\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5591\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5780\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 7)) {
        fprintf(_coverage_fout, "5593\n");
        fflush(_coverage_fout);
        tmp___11 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)259,
                                              tif->tif_dir.td_compression);
        fprintf(_coverage_fout, "5594\n");
        fflush(_coverage_fout);
        if (tmp___11) {
          fprintf(_coverage_fout, "5592\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5595\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5781\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 8)) {
        fprintf(_coverage_fout, "5597\n");
        fflush(_coverage_fout);
        tmp___12 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)262,
                                              tif->tif_dir.td_photometric);
        fprintf(_coverage_fout, "5598\n");
        fflush(_coverage_fout);
        if (tmp___12) {
          fprintf(_coverage_fout, "5596\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5599\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5782\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 9)) {
        fprintf(_coverage_fout, "5601\n");
        fflush(_coverage_fout);
        tmp___13 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)263,
                                              tif->tif_dir.td_threshholding);
        fprintf(_coverage_fout, "5602\n");
        fflush(_coverage_fout);
        if (tmp___13) {
          fprintf(_coverage_fout, "5600\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5603\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5783\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 10)) {
        fprintf(_coverage_fout, "5605\n");
        fflush(_coverage_fout);
        tmp___14 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)266,
                                              tif->tif_dir.td_fillorder);
        fprintf(_coverage_fout, "5606\n");
        fflush(_coverage_fout);
        if (tmp___14) {
          fprintf(_coverage_fout, "5604\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5607\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5784\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 15)) {
        fprintf(_coverage_fout, "5609\n");
        fflush(_coverage_fout);
        tmp___15 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)274,
                                              tif->tif_dir.td_orientation);
        fprintf(_coverage_fout, "5610\n");
        fflush(_coverage_fout);
        if (tmp___15) {
          fprintf(_coverage_fout, "5608\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5611\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5785\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 16)) {
        fprintf(_coverage_fout, "5613\n");
        fflush(_coverage_fout);
        tmp___16 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)277,
                                              tif->tif_dir.td_samplesperpixel);
        fprintf(_coverage_fout, "5614\n");
        fflush(_coverage_fout);
        if (tmp___16) {
          fprintf(_coverage_fout, "5612\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5615\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5786\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 17)) {
        fprintf(_coverage_fout, "5617\n");
        fflush(_coverage_fout);
        tmp___17 = TIFFWriteDirectoryTagShortLong(tif, & ndir, dir,
                                                  (unsigned short)278,
                                                  tif->tif_dir.td_rowsperstrip);
        fprintf(_coverage_fout, "5618\n");
        fflush(_coverage_fout);
        if (tmp___17) {
          fprintf(_coverage_fout, "5616\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5619\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5787\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 18)) {
        fprintf(_coverage_fout, "5621\n");
        fflush(_coverage_fout);
        tmp___18 = TIFFWriteDirectoryTagShortPerSample(tif, & ndir, dir,
                                                       (unsigned short)280,
                                                       tif->tif_dir.td_minsamplevalue);
        fprintf(_coverage_fout, "5622\n");
        fflush(_coverage_fout);
        if (tmp___18) {
          fprintf(_coverage_fout, "5620\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5623\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5788\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 19)) {
        fprintf(_coverage_fout, "5625\n");
        fflush(_coverage_fout);
        tmp___19 = TIFFWriteDirectoryTagShortPerSample(tif, & ndir, dir,
                                                       (unsigned short)281,
                                                       tif->tif_dir.td_maxsamplevalue);
        fprintf(_coverage_fout, "5626\n");
        fflush(_coverage_fout);
        if (tmp___19) {
          fprintf(_coverage_fout, "5624\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5627\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5789\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 20)) {
        fprintf(_coverage_fout, "5629\n");
        fflush(_coverage_fout);
        tmp___20 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)284,
                                              tif->tif_dir.td_planarconfig);
        fprintf(_coverage_fout, "5630\n");
        fflush(_coverage_fout);
        if (tmp___20) {
          fprintf(_coverage_fout, "5628\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5631\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5790\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 22)) {
        fprintf(_coverage_fout, "5633\n");
        fflush(_coverage_fout);
        tmp___21 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)296,
                                              tif->tif_dir.td_resolutionunit);
        fprintf(_coverage_fout, "5634\n");
        fflush(_coverage_fout);
        if (tmp___21) {
          fprintf(_coverage_fout, "5632\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5635\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5791\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 23)) {
        fprintf(_coverage_fout, "5637\n");
        fflush(_coverage_fout);
        tmp___22 = TIFFWriteDirectoryTagShortArray(tif, & ndir, dir,
                                                   (unsigned short)297, 2U,
                                                   & tif->tif_dir.td_pagenumber[0]);
        fprintf(_coverage_fout, "5638\n");
        fflush(_coverage_fout);
        if (tmp___22) {
          fprintf(_coverage_fout, "5636\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5639\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5792\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 24)) {
        fprintf(_coverage_fout, "5646\n");
        fflush(_coverage_fout);
        if (! ((tif->tif_flags & 1024U) != 0U)) {
          fprintf(_coverage_fout, "5641\n");
          fflush(_coverage_fout);
          tmp___23 = TIFFWriteDirectoryTagLongLong8Array(tif, & ndir, dir,
                                                         (unsigned short)279,
                                                         tif->tif_dir.td_nstrips,
                                                         tif->tif_dir.td_stripbytecount);
          fprintf(_coverage_fout, "5642\n");
          fflush(_coverage_fout);
          if (tmp___23) {
            fprintf(_coverage_fout, "5640\n");
            fflush(_coverage_fout);

          } else {
            goto bad;
          }
        } else {
          fprintf(_coverage_fout, "5644\n");
          fflush(_coverage_fout);
          tmp___24 = TIFFWriteDirectoryTagLongLong8Array(tif, & ndir, dir,
                                                         (unsigned short)325,
                                                         tif->tif_dir.td_nstrips,
                                                         tif->tif_dir.td_stripbytecount);
          fprintf(_coverage_fout, "5645\n");
          fflush(_coverage_fout);
          if (tmp___24) {
            fprintf(_coverage_fout, "5643\n");
            fflush(_coverage_fout);

          } else {
            goto bad;
          }
        }
      } else {
        fprintf(_coverage_fout, "5647\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5793\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 25)) {
        fprintf(_coverage_fout, "5654\n");
        fflush(_coverage_fout);
        if (! ((tif->tif_flags & 1024U) != 0U)) {
          fprintf(_coverage_fout, "5649\n");
          fflush(_coverage_fout);
          tmp___25 = TIFFWriteDirectoryTagLongLong8Array(tif, & ndir, dir,
                                                         (unsigned short)273,
                                                         tif->tif_dir.td_nstrips,
                                                         tif->tif_dir.td_stripoffset);
          fprintf(_coverage_fout, "5650\n");
          fflush(_coverage_fout);
          if (tmp___25) {
            fprintf(_coverage_fout, "5648\n");
            fflush(_coverage_fout);

          } else {
            goto bad;
          }
        } else {
          fprintf(_coverage_fout, "5652\n");
          fflush(_coverage_fout);
          tmp___26 = TIFFWriteDirectoryTagLongLong8Array(tif, & ndir, dir,
                                                         (unsigned short)324,
                                                         tif->tif_dir.td_nstrips,
                                                         tif->tif_dir.td_stripoffset);
          fprintf(_coverage_fout, "5653\n");
          fflush(_coverage_fout);
          if (tmp___26) {
            fprintf(_coverage_fout, "5651\n");
            fflush(_coverage_fout);

          } else {
            goto bad;
          }
        }
      } else {
        fprintf(_coverage_fout, "5655\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5794\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 26)) {
        fprintf(_coverage_fout, "5657\n");
        fflush(_coverage_fout);
        tmp___27 = TIFFWriteDirectoryTagColormap(tif, & ndir, dir);
        fprintf(_coverage_fout, "5658\n");
        fflush(_coverage_fout);
        if (tmp___27) {
          fprintf(_coverage_fout, "5656\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5659\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5795\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 31)) {
        fprintf(_coverage_fout, "5665\n");
        fflush(_coverage_fout);
        if (tif->tif_dir.td_extrasamples) {
          fprintf(_coverage_fout, "5661\n");
          fflush(_coverage_fout);
          TIFFGetFieldDefaulted(tif, 338U, & na, & nb);
          fprintf(_coverage_fout, "5662\n");
          fflush(_coverage_fout);
          tmp___28 = TIFFWriteDirectoryTagShortArray(tif, & ndir, dir,
                                                     (unsigned short)338,
                                                     (unsigned int )na, nb);
          fprintf(_coverage_fout, "5663\n");
          fflush(_coverage_fout);
          if (tmp___28) {
            fprintf(_coverage_fout, "5660\n");
            fflush(_coverage_fout);

          } else {
            goto bad;
          }
        } else {
          fprintf(_coverage_fout, "5664\n");
          fflush(_coverage_fout);

        }
      } else {
        fprintf(_coverage_fout, "5666\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5796\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & 1UL) {
        fprintf(_coverage_fout, "5668\n");
        fflush(_coverage_fout);
        tmp___29 = TIFFWriteDirectoryTagShortPerSample(tif, & ndir, dir,
                                                       (unsigned short)339,
                                                       tif->tif_dir.td_sampleformat);
        fprintf(_coverage_fout, "5669\n");
        fflush(_coverage_fout);
        if (tmp___29) {
          fprintf(_coverage_fout, "5667\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5670\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5797\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 1)) {
        fprintf(_coverage_fout, "5672\n");
        fflush(_coverage_fout);
        tmp___30 = TIFFWriteDirectoryTagSampleformatPerSample(tif, & ndir, dir,
                                                              (unsigned short)340,
                                                              tif->tif_dir.td_sminsamplevalue);
        fprintf(_coverage_fout, "5673\n");
        fflush(_coverage_fout);
        if (tmp___30) {
          fprintf(_coverage_fout, "5671\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5674\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5798\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 2)) {
        fprintf(_coverage_fout, "5676\n");
        fflush(_coverage_fout);
        tmp___31 = TIFFWriteDirectoryTagSampleformatPerSample(tif, & ndir, dir,
                                                              (unsigned short)341,
                                                              tif->tif_dir.td_smaxsamplevalue);
        fprintf(_coverage_fout, "5677\n");
        fflush(_coverage_fout);
        if (tmp___31) {
          fprintf(_coverage_fout, "5675\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5678\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5799\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 3)) {
        fprintf(_coverage_fout, "5680\n");
        fflush(_coverage_fout);
        tmp___32 = TIFFWriteDirectoryTagLong(tif, & ndir, dir,
                                             (unsigned short)32997,
                                             tif->tif_dir.td_imagedepth);
        fprintf(_coverage_fout, "5681\n");
        fflush(_coverage_fout);
        if (tmp___32) {
          fprintf(_coverage_fout, "5679\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5682\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5800\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 4)) {
        fprintf(_coverage_fout, "5684\n");
        fflush(_coverage_fout);
        tmp___33 = TIFFWriteDirectoryTagLong(tif, & ndir, dir,
                                             (unsigned short)32998,
                                             tif->tif_dir.td_tiledepth);
        fprintf(_coverage_fout, "5685\n");
        fflush(_coverage_fout);
        if (tmp___33) {
          fprintf(_coverage_fout, "5683\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5686\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5801\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 5)) {
        fprintf(_coverage_fout, "5688\n");
        fflush(_coverage_fout);
        tmp___34 = TIFFWriteDirectoryTagShortArray(tif, & ndir, dir,
                                                   (unsigned short)321, 2U,
                                                   & tif->tif_dir.td_halftonehints[0]);
        fprintf(_coverage_fout, "5689\n");
        fflush(_coverage_fout);
        if (tmp___34) {
          fprintf(_coverage_fout, "5687\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5690\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5802\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 7)) {
        fprintf(_coverage_fout, "5692\n");
        fflush(_coverage_fout);
        tmp___35 = TIFFWriteDirectoryTagShortArray(tif, & ndir, dir,
                                                   (unsigned short)530, 2U,
                                                   & tif->tif_dir.td_ycbcrsubsampling[0]);
        fprintf(_coverage_fout, "5693\n");
        fflush(_coverage_fout);
        if (tmp___35) {
          fprintf(_coverage_fout, "5691\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5694\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5803\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 8)) {
        fprintf(_coverage_fout, "5696\n");
        fflush(_coverage_fout);
        tmp___36 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)531,
                                              tif->tif_dir.td_ycbcrpositioning);
        fprintf(_coverage_fout, "5697\n");
        fflush(_coverage_fout);
        if (tmp___36) {
          fprintf(_coverage_fout, "5695\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5698\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5804\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 12)) {
        fprintf(_coverage_fout, "5700\n");
        fflush(_coverage_fout);
        tmp___37 = TIFFWriteDirectoryTagTransferfunction(tif, & ndir, dir);
        fprintf(_coverage_fout, "5701\n");
        fflush(_coverage_fout);
        if (tmp___37) {
          fprintf(_coverage_fout, "5699\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5702\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5805\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 14)) {
        fprintf(_coverage_fout, "5704\n");
        fflush(_coverage_fout);
        tmp___38 = TIFFWriteDirectoryTagAscii(tif, & ndir, dir,
                                              (unsigned short)333,
                                              (unsigned int )tif->tif_dir.td_inknameslen,
                                              tif->tif_dir.td_inknames);
        fprintf(_coverage_fout, "5705\n");
        fflush(_coverage_fout);
        if (tmp___38) {
          fprintf(_coverage_fout, "5703\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5706\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5806\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 17)) {
        fprintf(_coverage_fout, "5708\n");
        fflush(_coverage_fout);
        tmp___39 = TIFFWriteDirectoryTagSubifd(tif, & ndir, dir);
        fprintf(_coverage_fout, "5709\n");
        fflush(_coverage_fout);
        if (tmp___39) {
          fprintf(_coverage_fout, "5707\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5710\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5807\n");
      fflush(_coverage_fout);
      n = 0U;
      fprintf(_coverage_fout, "5808\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "5770\n");
        fflush(_coverage_fout);
        if (n < tif->tif_nfields) {
          fprintf(_coverage_fout, "5711\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "5771\n");
        fflush(_coverage_fout);
        o = (TIFFField const   *)*(tif->tif_fields + n);
        fprintf(_coverage_fout, "5772\n");
        fflush(_coverage_fout);
        if ((int const   )o->field_bit >= 66) {
          fprintf(_coverage_fout, "5768\n");
          fflush(_coverage_fout);
          if (tif->tif_dir.td_fieldsset[(int const   )o->field_bit / 32] & (1UL << ((int const   )o->field_bit & 31))) {
            switch ((int )o->get_field_type) {
            fprintf(_coverage_fout, "5740\n");
            fflush(_coverage_fout);
            case 1: 
            if ((unsigned int const   )o->field_type == 2U) {
              fprintf(_coverage_fout, "5712\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "5713\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_type==TIFF_ASCII", "tif_dirwrite.c", 579U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "5741\n");
            fflush(_coverage_fout);
            if ((int const   )o->field_readcount == -1) {
              fprintf(_coverage_fout, "5714\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "5715\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_readcount==-1", "tif_dirwrite.c", 580U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "5742\n");
            fflush(_coverage_fout);
            if ((int const   )o->field_passcount == 0) {
              fprintf(_coverage_fout, "5716\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "5717\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_passcount==0", "tif_dirwrite.c", 581U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "5743\n");
            fflush(_coverage_fout);
            TIFFGetField(tif, (unsigned int )o->field_tag, & pb);
            fprintf(_coverage_fout, "5744\n");
            fflush(_coverage_fout);
            tmp___40 = strlen((char const   *)pb);
            fprintf(_coverage_fout, "5745\n");
            fflush(_coverage_fout);
            pa = tmp___40;
            fprintf(_coverage_fout, "5746\n");
            fflush(_coverage_fout);
            tmp___41 = TIFFWriteDirectoryTagAscii(tif, & ndir, dir,
                                                  (unsigned short )o->field_tag,
                                                  pa, pb);
            fprintf(_coverage_fout, "5747\n");
            fflush(_coverage_fout);
            if (tmp___41) {
              fprintf(_coverage_fout, "5718\n");
              fflush(_coverage_fout);

            } else {
              goto bad;
            }
            break;
            fprintf(_coverage_fout, "5748\n");
            fflush(_coverage_fout);
            case 4: 
            if ((unsigned int const   )o->field_type == 3U) {
              fprintf(_coverage_fout, "5719\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "5720\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_type==TIFF_SHORT", "tif_dirwrite.c", 591U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "5749\n");
            fflush(_coverage_fout);
            if ((int const   )o->field_readcount == 1) {
              fprintf(_coverage_fout, "5721\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "5722\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_readcount==1", "tif_dirwrite.c", 592U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "5750\n");
            fflush(_coverage_fout);
            if ((int const   )o->field_passcount == 0) {
              fprintf(_coverage_fout, "5723\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "5724\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_passcount==0", "tif_dirwrite.c", 593U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "5751\n");
            fflush(_coverage_fout);
            TIFFGetField(tif, (unsigned int )o->field_tag, & p);
            fprintf(_coverage_fout, "5752\n");
            fflush(_coverage_fout);
            tmp___42 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                                  (unsigned short )o->field_tag,
                                                  p);
            fprintf(_coverage_fout, "5753\n");
            fflush(_coverage_fout);
            if (tmp___42) {
              fprintf(_coverage_fout, "5725\n");
              fflush(_coverage_fout);

            } else {
              goto bad;
            }
            break;
            fprintf(_coverage_fout, "5754\n");
            fflush(_coverage_fout);
            case 6: 
            if ((unsigned int const   )o->field_type == 4U) {
              fprintf(_coverage_fout, "5726\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "5727\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_type==TIFF_LONG", "tif_dirwrite.c", 602U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "5755\n");
            fflush(_coverage_fout);
            if ((int const   )o->field_readcount == 1) {
              fprintf(_coverage_fout, "5728\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "5729\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_readcount==1", "tif_dirwrite.c", 603U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "5756\n");
            fflush(_coverage_fout);
            if ((int const   )o->field_passcount == 0) {
              fprintf(_coverage_fout, "5730\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "5731\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_passcount==0", "tif_dirwrite.c", 604U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "5757\n");
            fflush(_coverage_fout);
            TIFFGetField(tif, (unsigned int )o->field_tag, & p___0);
            fprintf(_coverage_fout, "5758\n");
            fflush(_coverage_fout);
            tmp___43 = TIFFWriteDirectoryTagLong(tif, & ndir, dir,
                                                 (unsigned short )o->field_tag,
                                                 p___0);
            fprintf(_coverage_fout, "5759\n");
            fflush(_coverage_fout);
            if (tmp___43) {
              fprintf(_coverage_fout, "5732\n");
              fflush(_coverage_fout);

            } else {
              goto bad;
            }
            break;
            fprintf(_coverage_fout, "5760\n");
            fflush(_coverage_fout);
            case 40: 
            if ((unsigned int const   )o->field_type == 7U) {
              fprintf(_coverage_fout, "5733\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "5734\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_type==TIFF_UNDEFINED", "tif_dirwrite.c",
                            614U, "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "5761\n");
            fflush(_coverage_fout);
            if ((int const   )o->field_readcount == -3) {
              fprintf(_coverage_fout, "5735\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "5736\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_readcount==-3", "tif_dirwrite.c", 615U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "5762\n");
            fflush(_coverage_fout);
            if ((int const   )o->field_passcount == 1) {
              fprintf(_coverage_fout, "5737\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "5738\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_passcount==1", "tif_dirwrite.c", 616U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "5763\n");
            fflush(_coverage_fout);
            TIFFGetField(tif, (unsigned int )o->field_tag, & pa___0, & pb___0);
            fprintf(_coverage_fout, "5764\n");
            fflush(_coverage_fout);
            tmp___44 = TIFFWriteDirectoryTagUndefinedArray(tif, & ndir, dir,
                                                           (unsigned short )o->field_tag,
                                                           pa___0,
                                                           (uint8 *)pb___0);
            fprintf(_coverage_fout, "5765\n");
            fflush(_coverage_fout);
            if (tmp___44) {
              fprintf(_coverage_fout, "5739\n");
              fflush(_coverage_fout);

            } else {
              goto bad;
            }
            break;
            fprintf(_coverage_fout, "5766\n");
            fflush(_coverage_fout);
            default: 
            __assert_fail("0", "tif_dirwrite.c", 623U, "TIFFWriteDirectorySec");
            break;
            }
          } else {
            fprintf(_coverage_fout, "5767\n");
            fflush(_coverage_fout);

          }
        } else {
          fprintf(_coverage_fout, "5769\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "5773\n");
        fflush(_coverage_fout);
        n ++;
      }
    } else {
      fprintf(_coverage_fout, "5809\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "5888\n");
    fflush(_coverage_fout);
    m = 0U;
    fprintf(_coverage_fout, "5889\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "5860\n");
      fflush(_coverage_fout);
      if (m < (unsigned int )tif->tif_dir.td_customValueCount) {
        fprintf(_coverage_fout, "5810\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      switch ((int )((tif->tif_dir.td_customValues + m)->info)->field_type) {
      fprintf(_coverage_fout, "5827\n");
      fflush(_coverage_fout);
      case 2: 
      tmp___45 = TIFFWriteDirectoryTagAscii(tif, & ndir, dir,
                                            (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                            (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                            (char *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "5828\n");
      fflush(_coverage_fout);
      if (tmp___45) {
        fprintf(_coverage_fout, "5811\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "5829\n");
      fflush(_coverage_fout);
      case 7: 
      tmp___46 = TIFFWriteDirectoryTagUndefinedArray(tif, & ndir, dir,
                                                     (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                     (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                     (uint8 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "5830\n");
      fflush(_coverage_fout);
      if (tmp___46) {
        fprintf(_coverage_fout, "5812\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "5831\n");
      fflush(_coverage_fout);
      case 1: 
      tmp___47 = TIFFWriteDirectoryTagByteArray(tif, & ndir, dir,
                                                (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                (uint8 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "5832\n");
      fflush(_coverage_fout);
      if (tmp___47) {
        fprintf(_coverage_fout, "5813\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "5833\n");
      fflush(_coverage_fout);
      case 6: 
      tmp___48 = TIFFWriteDirectoryTagSbyteArray(tif, & ndir, dir,
                                                 (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                 (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                 (int8 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "5834\n");
      fflush(_coverage_fout);
      if (tmp___48) {
        fprintf(_coverage_fout, "5814\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "5835\n");
      fflush(_coverage_fout);
      case 3: 
      tmp___49 = TIFFWriteDirectoryTagShortArray(tif, & ndir, dir,
                                                 (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                 (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                 (uint16 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "5836\n");
      fflush(_coverage_fout);
      if (tmp___49) {
        fprintf(_coverage_fout, "5815\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "5837\n");
      fflush(_coverage_fout);
      case 8: 
      tmp___50 = TIFFWriteDirectoryTagSshortArray(tif, & ndir, dir,
                                                  (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                  (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                  (int16 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "5838\n");
      fflush(_coverage_fout);
      if (tmp___50) {
        fprintf(_coverage_fout, "5816\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "5839\n");
      fflush(_coverage_fout);
      case 4: 
      tmp___51 = TIFFWriteDirectoryTagLongArray(tif, & ndir, dir,
                                                (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                (uint32 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "5840\n");
      fflush(_coverage_fout);
      if (tmp___51) {
        fprintf(_coverage_fout, "5817\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "5841\n");
      fflush(_coverage_fout);
      case 9: 
      tmp___52 = TIFFWriteDirectoryTagSlongArray(tif, & ndir, dir,
                                                 (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                 (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                 (int32 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "5842\n");
      fflush(_coverage_fout);
      if (tmp___52) {
        fprintf(_coverage_fout, "5818\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "5843\n");
      fflush(_coverage_fout);
      case 16: 
      tmp___53 = TIFFWriteDirectoryTagLong8Array(tif, & ndir, dir,
                                                 (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                 (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                 (uint64 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "5844\n");
      fflush(_coverage_fout);
      if (tmp___53) {
        fprintf(_coverage_fout, "5819\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "5845\n");
      fflush(_coverage_fout);
      case 17: 
      tmp___54 = TIFFWriteDirectoryTagSlong8Array(tif, & ndir, dir,
                                                  (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                  (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                  (int64 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "5846\n");
      fflush(_coverage_fout);
      if (tmp___54) {
        fprintf(_coverage_fout, "5820\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "5847\n");
      fflush(_coverage_fout);
      case 5: 
      tmp___55 = TIFFWriteDirectoryTagRationalArray(tif, & ndir, dir,
                                                    (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                    (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                    (float *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "5848\n");
      fflush(_coverage_fout);
      if (tmp___55) {
        fprintf(_coverage_fout, "5821\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "5849\n");
      fflush(_coverage_fout);
      case 10: 
      tmp___56 = TIFFWriteDirectoryTagSrationalArray(tif, & ndir, dir,
                                                     (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                     (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                     (float *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "5850\n");
      fflush(_coverage_fout);
      if (tmp___56) {
        fprintf(_coverage_fout, "5822\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "5851\n");
      fflush(_coverage_fout);
      case 11: 
      tmp___57 = TIFFWriteDirectoryTagFloatArray(tif, & ndir, dir,
                                                 (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                 (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                 (float *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "5852\n");
      fflush(_coverage_fout);
      if (tmp___57) {
        fprintf(_coverage_fout, "5823\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "5853\n");
      fflush(_coverage_fout);
      case 12: 
      tmp___58 = TIFFWriteDirectoryTagDoubleArray(tif, & ndir, dir,
                                                  (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                  (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                  (double *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "5854\n");
      fflush(_coverage_fout);
      if (tmp___58) {
        fprintf(_coverage_fout, "5824\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "5855\n");
      fflush(_coverage_fout);
      case 13: 
      tmp___59 = TIFFWriteDirectoryTagIfdArray(tif, & ndir, dir,
                                               (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                               (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                               (uint32 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "5856\n");
      fflush(_coverage_fout);
      if (tmp___59) {
        fprintf(_coverage_fout, "5825\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "5857\n");
      fflush(_coverage_fout);
      case 18: 
      tmp___60 = TIFFWriteDirectoryTagIfd8Array(tif, & ndir, dir,
                                                (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                (uint64 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "5858\n");
      fflush(_coverage_fout);
      if (tmp___60) {
        fprintf(_coverage_fout, "5826\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "5859\n");
      fflush(_coverage_fout);
      default: 
      __assert_fail("0", "tif_dirwrite.c", 699U, "TIFFWriteDirectorySec");
      break;
      }
      fprintf(_coverage_fout, "5861\n");
      fflush(_coverage_fout);
      m ++;
    }
    fprintf(_coverage_fout, "5890\n");
    fflush(_coverage_fout);
    if ((unsigned int )dir != (unsigned int )((void *)0)) {
      break;
    } else {
      fprintf(_coverage_fout, "5862\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "5891\n");
    fflush(_coverage_fout);
    tmp___61 = _TIFFmalloc((long )(ndir * sizeof(TIFFDirEntry )));
    fprintf(_coverage_fout, "5892\n");
    fflush(_coverage_fout);
    dir = (TIFFDirEntry *)tmp___61;
    fprintf(_coverage_fout, "5893\n");
    fflush(_coverage_fout);
    if ((unsigned int )dir == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "5863\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___0, "Out of memory");
      goto bad;
    } else {
      fprintf(_coverage_fout, "5864\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "5894\n");
    fflush(_coverage_fout);
    if (isimage) {
      fprintf(_coverage_fout, "5869\n");
      fflush(_coverage_fout);
      if (tif->tif_diroff == 0ULL) {
        fprintf(_coverage_fout, "5866\n");
        fflush(_coverage_fout);
        tmp___62 = TIFFLinkDirectory(tif);
        fprintf(_coverage_fout, "5867\n");
        fflush(_coverage_fout);
        if (tmp___62) {
          fprintf(_coverage_fout, "5865\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "5868\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "5870\n");
      fflush(_coverage_fout);
      tmp___63 = (*(tif->tif_seekproc))(tif->tif_clientdata, 0ULL, 2);
      fprintf(_coverage_fout, "5871\n");
      fflush(_coverage_fout);
      tif->tif_diroff = (tmp___63 + 1ULL) & 0xfffffffffffffffeULL;
    }
    fprintf(_coverage_fout, "5895\n");
    fflush(_coverage_fout);
    if ((unsigned int )pdiroff != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "5872\n");
      fflush(_coverage_fout);
      *pdiroff = tif->tif_diroff;
    } else {
      fprintf(_coverage_fout, "5873\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "5896\n");
    fflush(_coverage_fout);
    if (! (tif->tif_flags & 524288U)) {
      fprintf(_coverage_fout, "5874\n");
      fflush(_coverage_fout);
      dirsize = (2U + ndir * 12U) + 4U;
    } else {
      fprintf(_coverage_fout, "5875\n");
      fflush(_coverage_fout);
      dirsize = (8U + ndir * 20U) + 8U;
    }
    fprintf(_coverage_fout, "5897\n");
    fflush(_coverage_fout);
    tif->tif_dataoff = tif->tif_diroff + (uint64 )dirsize;
    fprintf(_coverage_fout, "5898\n");
    fflush(_coverage_fout);
    if (! (tif->tif_flags & 524288U)) {
      fprintf(_coverage_fout, "5876\n");
      fflush(_coverage_fout);
      tif->tif_dataoff = (unsigned long long )((unsigned int )tif->tif_dataoff);
    } else {
      fprintf(_coverage_fout, "5877\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "5899\n");
    fflush(_coverage_fout);
    if (tif->tif_dataoff < tif->tif_diroff) {
      fprintf(_coverage_fout, "5878\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "Maximum TIFF file size exceeded");
      goto bad;
    } else {
      fprintf(_coverage_fout, "5881\n");
      fflush(_coverage_fout);
      if (tif->tif_dataoff < (unsigned long long )dirsize) {
        fprintf(_coverage_fout, "5879\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___0,
                     "Maximum TIFF file size exceeded");
        goto bad;
      } else {
        fprintf(_coverage_fout, "5880\n");
        fflush(_coverage_fout);

      }
    }
    fprintf(_coverage_fout, "5900\n");
    fflush(_coverage_fout);
    if (tif->tif_dataoff & 1ULL) {
      fprintf(_coverage_fout, "5882\n");
      fflush(_coverage_fout);
      (tif->tif_dataoff) ++;
    } else {
      fprintf(_coverage_fout, "5883\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "5901\n");
    fflush(_coverage_fout);
    if (isimage) {
      fprintf(_coverage_fout, "5884\n");
      fflush(_coverage_fout);
      tif->tif_curdir = (uint16 )((int )tif->tif_curdir + 1);
    } else {
      fprintf(_coverage_fout, "5885\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "6003\n");
  fflush(_coverage_fout);
  if (isimage) {
    fprintf(_coverage_fout, "5918\n");
    fflush(_coverage_fout);
    if (tif->tif_dir.td_fieldsset[1] & (1UL << 17)) {
      fprintf(_coverage_fout, "5916\n");
      fflush(_coverage_fout);
      if (tif->tif_subifdoff == 0ULL) {
        fprintf(_coverage_fout, "5911\n");
        fflush(_coverage_fout);
        na___0 = 0U;
        fprintf(_coverage_fout, "5912\n");
        fflush(_coverage_fout);
        nb___0 = dir;
        fprintf(_coverage_fout, "5913\n");
        fflush(_coverage_fout);
        while (1) {
          fprintf(_coverage_fout, "5905\n");
          fflush(_coverage_fout);
          if (na___0 < ndir) {
            fprintf(_coverage_fout, "5902\n");
            fflush(_coverage_fout);

          } else {
            fprintf(_coverage_fout, "5903\n");
            fflush(_coverage_fout);
            __assert_fail("na<ndir", "tif_dirwrite.c", 745U,
                          "TIFFWriteDirectorySec");
          }
          fprintf(_coverage_fout, "5906\n");
          fflush(_coverage_fout);
          if ((int )nb___0->tdir_tag == 330) {
            break;
          } else {
            fprintf(_coverage_fout, "5904\n");
            fflush(_coverage_fout);

          }
          fprintf(_coverage_fout, "5907\n");
          fflush(_coverage_fout);
          na___0 ++;
          fprintf(_coverage_fout, "5908\n");
          fflush(_coverage_fout);
          nb___0 ++;
        }
        fprintf(_coverage_fout, "5914\n");
        fflush(_coverage_fout);
        if (! (tif->tif_flags & 524288U)) {
          fprintf(_coverage_fout, "5909\n");
          fflush(_coverage_fout);
          tif->tif_subifdoff = ((tif->tif_diroff + 2ULL) + (uint64 )(na___0 * 12U)) + 8ULL;
        } else {
          fprintf(_coverage_fout, "5910\n");
          fflush(_coverage_fout);
          tif->tif_subifdoff = ((tif->tif_diroff + 8ULL) + (uint64 )(na___0 * 20U)) + 12ULL;
        }
      } else {
        fprintf(_coverage_fout, "5915\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "5917\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "5919\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6004\n");
  fflush(_coverage_fout);
  dirmem = _TIFFmalloc((long )dirsize);
  fprintf(_coverage_fout, "6005\n");
  fflush(_coverage_fout);
  if ((unsigned int )dirmem == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "5920\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___0, "Out of memory");
    goto bad;
  } else {
    fprintf(_coverage_fout, "5921\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6006\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "5945\n");
    fflush(_coverage_fout);
    n___0 = (uint8 *)dirmem;
    fprintf(_coverage_fout, "5946\n");
    fflush(_coverage_fout);
    *((uint16 *)n___0) = (unsigned short )ndir;
    fprintf(_coverage_fout, "5947\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "5922\n");
      fflush(_coverage_fout);
      TIFFSwabShort((uint16 *)n___0);
    } else {
      fprintf(_coverage_fout, "5923\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "5948\n");
    fflush(_coverage_fout);
    n___0 += 2;
    fprintf(_coverage_fout, "5949\n");
    fflush(_coverage_fout);
    o___0 = dir;
    fprintf(_coverage_fout, "5950\n");
    fflush(_coverage_fout);
    m = 0U;
    fprintf(_coverage_fout, "5951\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "5931\n");
      fflush(_coverage_fout);
      if (m < ndir) {
        fprintf(_coverage_fout, "5924\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "5932\n");
      fflush(_coverage_fout);
      *((uint16 *)n___0) = o___0->tdir_tag;
      fprintf(_coverage_fout, "5933\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "5925\n");
        fflush(_coverage_fout);
        TIFFSwabShort((uint16 *)n___0);
      } else {
        fprintf(_coverage_fout, "5926\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5934\n");
      fflush(_coverage_fout);
      n___0 += 2;
      fprintf(_coverage_fout, "5935\n");
      fflush(_coverage_fout);
      *((uint16 *)n___0) = o___0->tdir_type;
      fprintf(_coverage_fout, "5936\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "5927\n");
        fflush(_coverage_fout);
        TIFFSwabShort((uint16 *)n___0);
      } else {
        fprintf(_coverage_fout, "5928\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5937\n");
      fflush(_coverage_fout);
      n___0 += 2;
      fprintf(_coverage_fout, "5938\n");
      fflush(_coverage_fout);
      *((uint32 *)n___0) = (unsigned int )o___0->tdir_count;
      fprintf(_coverage_fout, "5939\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "5929\n");
        fflush(_coverage_fout);
        TIFFSwabLong((uint32 *)n___0);
      } else {
        fprintf(_coverage_fout, "5930\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5940\n");
      fflush(_coverage_fout);
      n___0 += 4;
      fprintf(_coverage_fout, "5941\n");
      fflush(_coverage_fout);
      _TIFFmemcpy((void *)n___0, (void const   *)(& o___0->tdir_offset), 4L);
      fprintf(_coverage_fout, "5942\n");
      fflush(_coverage_fout);
      n___0 += 4;
      fprintf(_coverage_fout, "5943\n");
      fflush(_coverage_fout);
      o___0 ++;
      fprintf(_coverage_fout, "5944\n");
      fflush(_coverage_fout);
      m ++;
    }
    fprintf(_coverage_fout, "5952\n");
    fflush(_coverage_fout);
    *((uint32 *)n___0) = (unsigned int )tif->tif_nextdiroff;
  } else {
    fprintf(_coverage_fout, "5976\n");
    fflush(_coverage_fout);
    n___1 = (uint8 *)dirmem;
    fprintf(_coverage_fout, "5977\n");
    fflush(_coverage_fout);
    *((uint64 *)n___1) = (unsigned long long )ndir;
    fprintf(_coverage_fout, "5978\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "5953\n");
      fflush(_coverage_fout);
      TIFFSwabLong8((uint64 *)n___1);
    } else {
      fprintf(_coverage_fout, "5954\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "5979\n");
    fflush(_coverage_fout);
    n___1 += 8;
    fprintf(_coverage_fout, "5980\n");
    fflush(_coverage_fout);
    o___1 = dir;
    fprintf(_coverage_fout, "5981\n");
    fflush(_coverage_fout);
    m = 0U;
    fprintf(_coverage_fout, "5982\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "5962\n");
      fflush(_coverage_fout);
      if (m < ndir) {
        fprintf(_coverage_fout, "5955\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "5963\n");
      fflush(_coverage_fout);
      *((uint16 *)n___1) = o___1->tdir_tag;
      fprintf(_coverage_fout, "5964\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "5956\n");
        fflush(_coverage_fout);
        TIFFSwabShort((uint16 *)n___1);
      } else {
        fprintf(_coverage_fout, "5957\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5965\n");
      fflush(_coverage_fout);
      n___1 += 2;
      fprintf(_coverage_fout, "5966\n");
      fflush(_coverage_fout);
      *((uint16 *)n___1) = o___1->tdir_type;
      fprintf(_coverage_fout, "5967\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "5958\n");
        fflush(_coverage_fout);
        TIFFSwabShort((uint16 *)n___1);
      } else {
        fprintf(_coverage_fout, "5959\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5968\n");
      fflush(_coverage_fout);
      n___1 += 2;
      fprintf(_coverage_fout, "5969\n");
      fflush(_coverage_fout);
      *((uint64 *)n___1) = o___1->tdir_count;
      fprintf(_coverage_fout, "5970\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "5960\n");
        fflush(_coverage_fout);
        TIFFSwabLong8((uint64 *)n___1);
      } else {
        fprintf(_coverage_fout, "5961\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5971\n");
      fflush(_coverage_fout);
      n___1 += 8;
      fprintf(_coverage_fout, "5972\n");
      fflush(_coverage_fout);
      _TIFFmemcpy((void *)n___1, (void const   *)(& o___1->tdir_offset), 8L);
      fprintf(_coverage_fout, "5973\n");
      fflush(_coverage_fout);
      n___1 += 8;
      fprintf(_coverage_fout, "5974\n");
      fflush(_coverage_fout);
      o___1 ++;
      fprintf(_coverage_fout, "5975\n");
      fflush(_coverage_fout);
      m ++;
    }
    fprintf(_coverage_fout, "5983\n");
    fflush(_coverage_fout);
    *((uint64 *)n___1) = tif->tif_nextdiroff;
  }
  fprintf(_coverage_fout, "6007\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)dir);
  fprintf(_coverage_fout, "6008\n");
  fflush(_coverage_fout);
  dir = (TIFFDirEntry *)((void *)0);
  fprintf(_coverage_fout, "6009\n");
  fflush(_coverage_fout);
  tmp___64 = (*(tif->tif_seekproc))(tif->tif_clientdata, tif->tif_diroff, 0);
  fprintf(_coverage_fout, "6010\n");
  fflush(_coverage_fout);
  if (tmp___64 == tif->tif_diroff) {
    fprintf(_coverage_fout, "5984\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "5985\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___0, "IO error writing directory");
    goto bad;
  }
  fprintf(_coverage_fout, "6011\n");
  fflush(_coverage_fout);
  tmp___65 = (*(tif->tif_writeproc))(tif->tif_clientdata, dirmem, (long )dirsize);
  fprintf(_coverage_fout, "6012\n");
  fflush(_coverage_fout);
  if (tmp___65 == (long )dirsize) {
    fprintf(_coverage_fout, "5986\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "5987\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___0, "IO error writing directory");
    goto bad;
  }
  fprintf(_coverage_fout, "6013\n");
  fflush(_coverage_fout);
  _TIFFfree(dirmem);
  fprintf(_coverage_fout, "6014\n");
  fflush(_coverage_fout);
  if (imagedone) {
    fprintf(_coverage_fout, "5988\n");
    fflush(_coverage_fout);
    TIFFFreeDirectory(tif);
    fprintf(_coverage_fout, "5989\n");
    fflush(_coverage_fout);
    tif->tif_flags &= 4294967287U;
    fprintf(_coverage_fout, "5990\n");
    fflush(_coverage_fout);
    (*(tif->tif_cleanup))(tif);
    fprintf(_coverage_fout, "5991\n");
    fflush(_coverage_fout);
    TIFFCreateDirectory(tif);
  } else {
    fprintf(_coverage_fout, "5992\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6015\n");
  fflush(_coverage_fout);
  return (1);
  fprintf(_coverage_fout, "6016\n");
  fflush(_coverage_fout);
  bad: 
  if ((unsigned int )dir != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "5993\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)dir);
  } else {
    fprintf(_coverage_fout, "5994\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6017\n");
  fflush(_coverage_fout);
  if ((unsigned int )dirmem != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "5995\n");
    fflush(_coverage_fout);
    _TIFFfree(dirmem);
  } else {
    fprintf(_coverage_fout, "5996\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6018\n");
  fflush(_coverage_fout);
  return (0);
}
}
static int TIFFWriteDirectoryTagSampleformatPerSample(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag , double value ) 
{ int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  switch ((int )tif->tif_dir.td_sampleformat) {
  fprintf(_coverage_fout, "6037\n");
  fflush(_coverage_fout);
  case 3: 
  if ((int )tif->tif_dir.td_bitspersample <= 32) {
    fprintf(_coverage_fout, "6019\n");
    fflush(_coverage_fout);
    tmp = TIFFWriteDirectoryTagFloatPerSample(tif, ndir, dir, tag, (float )value);
    fprintf(_coverage_fout, "6020\n");
    fflush(_coverage_fout);
    return (tmp);
  } else {
    fprintf(_coverage_fout, "6021\n");
    fflush(_coverage_fout);
    tmp___0 = TIFFWriteDirectoryTagDoublePerSample(tif, ndir, dir, tag, value);
    fprintf(_coverage_fout, "6022\n");
    fflush(_coverage_fout);
    return (tmp___0);
  }
  fprintf(_coverage_fout, "6038\n");
  fflush(_coverage_fout);
  case 2: 
  if ((int )tif->tif_dir.td_bitspersample <= 8) {
    fprintf(_coverage_fout, "6023\n");
    fflush(_coverage_fout);
    tmp___1 = TIFFWriteDirectoryTagSbytePerSample(tif, ndir, dir, tag,
                                                  (signed char )value);
    fprintf(_coverage_fout, "6024\n");
    fflush(_coverage_fout);
    return (tmp___1);
  } else {
    fprintf(_coverage_fout, "6029\n");
    fflush(_coverage_fout);
    if ((int )tif->tif_dir.td_bitspersample <= 16) {
      fprintf(_coverage_fout, "6025\n");
      fflush(_coverage_fout);
      tmp___2 = TIFFWriteDirectoryTagSshortPerSample(tif, ndir, dir, tag,
                                                     (short )value);
      fprintf(_coverage_fout, "6026\n");
      fflush(_coverage_fout);
      return (tmp___2);
    } else {
      fprintf(_coverage_fout, "6027\n");
      fflush(_coverage_fout);
      tmp___3 = TIFFWriteDirectoryTagSlongPerSample(tif, ndir, dir, tag,
                                                    (int )value);
      fprintf(_coverage_fout, "6028\n");
      fflush(_coverage_fout);
      return (tmp___3);
    }
  }
  fprintf(_coverage_fout, "6039\n");
  fflush(_coverage_fout);
  case 1: 
  if ((int )tif->tif_dir.td_bitspersample <= 8) {
    fprintf(_coverage_fout, "6030\n");
    fflush(_coverage_fout);
    tmp___4 = TIFFWriteDirectoryTagBytePerSample(tif, ndir, dir, tag,
                                                 (unsigned char )value);
    fprintf(_coverage_fout, "6031\n");
    fflush(_coverage_fout);
    return (tmp___4);
  } else {
    fprintf(_coverage_fout, "6036\n");
    fflush(_coverage_fout);
    if ((int )tif->tif_dir.td_bitspersample <= 16) {
      fprintf(_coverage_fout, "6032\n");
      fflush(_coverage_fout);
      tmp___5 = TIFFWriteDirectoryTagShortPerSample(tif, ndir, dir, tag,
                                                    (unsigned short )value);
      fprintf(_coverage_fout, "6033\n");
      fflush(_coverage_fout);
      return (tmp___5);
    } else {
      fprintf(_coverage_fout, "6034\n");
      fflush(_coverage_fout);
      tmp___6 = TIFFWriteDirectoryTagLongPerSample(tif, ndir, dir, tag,
                                                   (unsigned int )value);
      fprintf(_coverage_fout, "6035\n");
      fflush(_coverage_fout);
      return (tmp___6);
    }
  }
  fprintf(_coverage_fout, "6040\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "6041\n");
  fflush(_coverage_fout);
  return (1);
  }
}
}
static int TIFFWriteDirectoryTagAscii(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      uint32 count , char *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6045\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6042\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6043\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6044\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6046\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedAscii(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "6047\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagUndefinedArray(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , uint8 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6051\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6048\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6049\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6050\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6052\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedUndefinedArray(tif, ndir, dir, tag, count,
                                                   value);
  fprintf(_coverage_fout, "6053\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagByte(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint8 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6057\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6054\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6055\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6056\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6058\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedByte(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "6059\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagByteArray(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint8 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6063\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6060\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6061\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6062\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6064\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedByteArray(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "6065\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagBytePerSample(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint8 value ) ;
static char const   module___1[35]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'B',      (char const   )'y',      (char const   )'t', 
        (char const   )'e',      (char const   )'P',      (char const   )'e',      (char const   )'r', 
        (char const   )'S',      (char const   )'a',      (char const   )'m',      (char const   )'p', 
        (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagBytePerSample(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint8 value ) 
{ uint8 *m ;
  uint8 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6077\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6066\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6067\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6068\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6078\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_samplesperpixel * sizeof(uint8 )));
  fprintf(_coverage_fout, "6079\n");
  fflush(_coverage_fout);
  m = (uint8 *)tmp;
  fprintf(_coverage_fout, "6080\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6069\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___1, "Out of memory");
    fprintf(_coverage_fout, "6070\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "6071\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6081\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "6082\n");
  fflush(_coverage_fout);
  nb = (unsigned short)0;
  fprintf(_coverage_fout, "6083\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "6073\n");
    fflush(_coverage_fout);
    if ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
      fprintf(_coverage_fout, "6072\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "6074\n");
    fflush(_coverage_fout);
    *na = value;
    fprintf(_coverage_fout, "6075\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "6076\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb + 1);
  }
  fprintf(_coverage_fout, "6084\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedByteArray(tif, ndir, dir, tag,
                                            (unsigned int )tif->tif_dir.td_samplesperpixel,
                                            m);
  fprintf(_coverage_fout, "6085\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "6086\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagSbyte(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      int8 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6090\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6087\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6088\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6089\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6091\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSbyte(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "6092\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSbyteArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , int8 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6096\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6093\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6094\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6095\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6097\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSbyteArray(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "6098\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSbytePerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               int8 value ) ;
static char const   module___2[36]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'S',      (char const   )'b',      (char const   )'y', 
        (char const   )'t',      (char const   )'e',      (char const   )'P',      (char const   )'e', 
        (char const   )'r',      (char const   )'S',      (char const   )'a',      (char const   )'m', 
        (char const   )'p',      (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagSbytePerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               int8 value ) 
{ int8 *m ;
  int8 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6110\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6099\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6100\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6101\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6111\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_samplesperpixel * sizeof(int8 )));
  fprintf(_coverage_fout, "6112\n");
  fflush(_coverage_fout);
  m = (int8 *)tmp;
  fprintf(_coverage_fout, "6113\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6102\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___2, "Out of memory");
    fprintf(_coverage_fout, "6103\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "6104\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6114\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "6115\n");
  fflush(_coverage_fout);
  nb = (unsigned short)0;
  fprintf(_coverage_fout, "6116\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "6106\n");
    fflush(_coverage_fout);
    if ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
      fprintf(_coverage_fout, "6105\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "6107\n");
    fflush(_coverage_fout);
    *na = value;
    fprintf(_coverage_fout, "6108\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "6109\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb + 1);
  }
  fprintf(_coverage_fout, "6117\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedSbyteArray(tif, ndir, dir, tag,
                                             (unsigned int )tif->tif_dir.td_samplesperpixel,
                                             m);
  fprintf(_coverage_fout, "6118\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "6119\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagShort(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      uint16 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6123\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6120\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6121\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6122\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6124\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedShort(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "6125\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagShortArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , uint16 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6129\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6126\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6127\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6128\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6130\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedShortArray(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "6131\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagShortPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint16 value ) ;
static char const   module___3[36]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'S',      (char const   )'h',      (char const   )'o', 
        (char const   )'r',      (char const   )'t',      (char const   )'P',      (char const   )'e', 
        (char const   )'r',      (char const   )'S',      (char const   )'a',      (char const   )'m', 
        (char const   )'p',      (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagShortPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint16 value ) 
{ uint16 *m ;
  uint16 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6143\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6132\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6133\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6134\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6144\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_samplesperpixel * sizeof(uint16 )));
  fprintf(_coverage_fout, "6145\n");
  fflush(_coverage_fout);
  m = (uint16 *)tmp;
  fprintf(_coverage_fout, "6146\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6135\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___3, "Out of memory");
    fprintf(_coverage_fout, "6136\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "6137\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6147\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "6148\n");
  fflush(_coverage_fout);
  nb = (unsigned short)0;
  fprintf(_coverage_fout, "6149\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "6139\n");
    fflush(_coverage_fout);
    if ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
      fprintf(_coverage_fout, "6138\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "6140\n");
    fflush(_coverage_fout);
    *na = value;
    fprintf(_coverage_fout, "6141\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "6142\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb + 1);
  }
  fprintf(_coverage_fout, "6150\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedShortArray(tif, ndir, dir, tag,
                                             (unsigned int )tif->tif_dir.td_samplesperpixel,
                                             m);
  fprintf(_coverage_fout, "6151\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "6152\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagSshort(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir , uint16 tag ,
                                       int16 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6156\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6153\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6154\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6155\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6157\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSshort(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "6158\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSshortArray(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , int16 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6162\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6159\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6160\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6161\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6163\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSshortArray(tif, ndir, dir, tag, count,
                                                value);
  fprintf(_coverage_fout, "6164\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSshortPerSample(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                int16 value ) ;
static char const   module___4[37]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'S',      (char const   )'s',      (char const   )'h', 
        (char const   )'o',      (char const   )'r',      (char const   )'t',      (char const   )'P', 
        (char const   )'e',      (char const   )'r',      (char const   )'S',      (char const   )'a', 
        (char const   )'m',      (char const   )'p',      (char const   )'l',      (char const   )'e', 
        (char const   )'\000'};
static int TIFFWriteDirectoryTagSshortPerSample(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                int16 value ) 
{ int16 *m ;
  int16 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6176\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6165\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6166\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6167\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6177\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_samplesperpixel * sizeof(int16 )));
  fprintf(_coverage_fout, "6178\n");
  fflush(_coverage_fout);
  m = (int16 *)tmp;
  fprintf(_coverage_fout, "6179\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6168\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___4, "Out of memory");
    fprintf(_coverage_fout, "6169\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "6170\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6180\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "6181\n");
  fflush(_coverage_fout);
  nb = (unsigned short)0;
  fprintf(_coverage_fout, "6182\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "6172\n");
    fflush(_coverage_fout);
    if ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
      fprintf(_coverage_fout, "6171\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "6173\n");
    fflush(_coverage_fout);
    *na = value;
    fprintf(_coverage_fout, "6174\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "6175\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb + 1);
  }
  fprintf(_coverage_fout, "6183\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedSshortArray(tif, ndir, dir, tag,
                                              (unsigned int )tif->tif_dir.td_samplesperpixel,
                                              m);
  fprintf(_coverage_fout, "6184\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "6185\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagLong(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint32 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6189\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6186\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6187\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6188\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6190\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedLong(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "6191\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagLongArray(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint32 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6195\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6192\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6193\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6194\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6196\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedLongArray(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "6197\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagLongPerSample(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint32 value ) ;
static char const   module___5[35]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'L',      (char const   )'o',      (char const   )'n', 
        (char const   )'g',      (char const   )'P',      (char const   )'e',      (char const   )'r', 
        (char const   )'S',      (char const   )'a',      (char const   )'m',      (char const   )'p', 
        (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagLongPerSample(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint32 value ) 
{ uint32 *m ;
  uint32 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6209\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6198\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6199\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6200\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6210\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_samplesperpixel * sizeof(uint32 )));
  fprintf(_coverage_fout, "6211\n");
  fflush(_coverage_fout);
  m = (uint32 *)tmp;
  fprintf(_coverage_fout, "6212\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6201\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___5, "Out of memory");
    fprintf(_coverage_fout, "6202\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "6203\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6213\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "6214\n");
  fflush(_coverage_fout);
  nb = (unsigned short)0;
  fprintf(_coverage_fout, "6215\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "6205\n");
    fflush(_coverage_fout);
    if ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
      fprintf(_coverage_fout, "6204\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "6206\n");
    fflush(_coverage_fout);
    *na = value;
    fprintf(_coverage_fout, "6207\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "6208\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb + 1);
  }
  fprintf(_coverage_fout, "6216\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedLongArray(tif, ndir, dir, tag,
                                            (unsigned int )tif->tif_dir.td_samplesperpixel,
                                            m);
  fprintf(_coverage_fout, "6217\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "6218\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagSlong(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      int32 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6222\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6219\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6220\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6221\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6223\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSlong(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "6224\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSlongArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , int32 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6228\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6225\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6226\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6227\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6229\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSlongArray(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "6230\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSlongPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               int32 value ) ;
static char const   module___6[36]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'S',      (char const   )'l',      (char const   )'o', 
        (char const   )'n',      (char const   )'g',      (char const   )'P',      (char const   )'e', 
        (char const   )'r',      (char const   )'S',      (char const   )'a',      (char const   )'m', 
        (char const   )'p',      (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagSlongPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               int32 value ) 
{ int32 *m ;
  int32 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6242\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6231\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6232\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6233\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6243\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_samplesperpixel * sizeof(int32 )));
  fprintf(_coverage_fout, "6244\n");
  fflush(_coverage_fout);
  m = (int32 *)tmp;
  fprintf(_coverage_fout, "6245\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6234\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___6, "Out of memory");
    fprintf(_coverage_fout, "6235\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "6236\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6246\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "6247\n");
  fflush(_coverage_fout);
  nb = (unsigned short)0;
  fprintf(_coverage_fout, "6248\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "6238\n");
    fflush(_coverage_fout);
    if ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
      fprintf(_coverage_fout, "6237\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "6239\n");
    fflush(_coverage_fout);
    *na = value;
    fprintf(_coverage_fout, "6240\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "6241\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb + 1);
  }
  fprintf(_coverage_fout, "6249\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedSlongArray(tif, ndir, dir, tag,
                                             (unsigned int )tif->tif_dir.td_samplesperpixel,
                                             m);
  fprintf(_coverage_fout, "6250\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "6251\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagLong8(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      uint64 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6255\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6252\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6253\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6254\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6256\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedLong8(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "6257\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagLong8Array(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , uint64 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6261\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6258\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6259\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6260\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6262\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedLong8Array(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "6263\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSlong8(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir , uint16 tag ,
                                       int64 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6267\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6264\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6265\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6266\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6268\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSlong8(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "6269\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSlong8Array(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , int64 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6273\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6270\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6271\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6272\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6274\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSlong8Array(tif, ndir, dir, tag, count,
                                                value);
  fprintf(_coverage_fout, "6275\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagRational(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir , uint16 tag ,
                                         double value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6279\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6276\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6277\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6278\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6280\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedRational(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "6281\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagRationalArray(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint32 count , float *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6285\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6282\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6283\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6284\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6286\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedRationalArray(tif, ndir, dir, tag, count,
                                                  value);
  fprintf(_coverage_fout, "6287\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSrationalArray(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , float *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6291\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6288\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6289\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6290\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6292\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSrationalArray(tif, ndir, dir, tag, count,
                                                   value);
  fprintf(_coverage_fout, "6293\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagFloat(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      float value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6297\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6294\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6295\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6296\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6298\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedFloat(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "6299\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagFloatArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , float *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6303\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6300\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6301\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6302\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6304\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedFloatArray(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "6305\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagFloatPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               float value ) ;
static char const   module___7[36]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'F',      (char const   )'l',      (char const   )'o', 
        (char const   )'a',      (char const   )'t',      (char const   )'P',      (char const   )'e', 
        (char const   )'r',      (char const   )'S',      (char const   )'a',      (char const   )'m', 
        (char const   )'p',      (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagFloatPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               float value ) 
{ float *m ;
  float *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6317\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6306\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6307\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6308\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6318\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_samplesperpixel * sizeof(float )));
  fprintf(_coverage_fout, "6319\n");
  fflush(_coverage_fout);
  m = (float *)tmp;
  fprintf(_coverage_fout, "6320\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6309\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___7, "Out of memory");
    fprintf(_coverage_fout, "6310\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "6311\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6321\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "6322\n");
  fflush(_coverage_fout);
  nb = (unsigned short)0;
  fprintf(_coverage_fout, "6323\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "6313\n");
    fflush(_coverage_fout);
    if ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
      fprintf(_coverage_fout, "6312\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "6314\n");
    fflush(_coverage_fout);
    *na = value;
    fprintf(_coverage_fout, "6315\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "6316\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb + 1);
  }
  fprintf(_coverage_fout, "6324\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedFloatArray(tif, ndir, dir, tag,
                                             (unsigned int )tif->tif_dir.td_samplesperpixel,
                                             m);
  fprintf(_coverage_fout, "6325\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "6326\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagDouble(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir , uint16 tag ,
                                       double value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6330\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6327\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6328\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6329\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6331\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedDouble(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "6332\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagDoubleArray(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , double *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6336\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6333\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6334\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6335\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6337\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedDoubleArray(tif, ndir, dir, tag, count,
                                                value);
  fprintf(_coverage_fout, "6338\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagDoublePerSample(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                double value ) ;
static char const   module___8[37]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'D',      (char const   )'o',      (char const   )'u', 
        (char const   )'b',      (char const   )'l',      (char const   )'e',      (char const   )'P', 
        (char const   )'e',      (char const   )'r',      (char const   )'S',      (char const   )'a', 
        (char const   )'m',      (char const   )'p',      (char const   )'l',      (char const   )'e', 
        (char const   )'\000'};
static int TIFFWriteDirectoryTagDoublePerSample(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                double value ) 
{ double *m ;
  double *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6350\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6339\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6340\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6341\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6351\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_samplesperpixel * sizeof(double )));
  fprintf(_coverage_fout, "6352\n");
  fflush(_coverage_fout);
  m = (double *)tmp;
  fprintf(_coverage_fout, "6353\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6342\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___8, "Out of memory");
    fprintf(_coverage_fout, "6343\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "6344\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6354\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "6355\n");
  fflush(_coverage_fout);
  nb = (unsigned short)0;
  fprintf(_coverage_fout, "6356\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "6346\n");
    fflush(_coverage_fout);
    if ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
      fprintf(_coverage_fout, "6345\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "6347\n");
    fflush(_coverage_fout);
    *na = value;
    fprintf(_coverage_fout, "6348\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "6349\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb + 1);
  }
  fprintf(_coverage_fout, "6357\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedDoubleArray(tif, ndir, dir, tag,
                                              (unsigned int )tif->tif_dir.td_samplesperpixel,
                                              m);
  fprintf(_coverage_fout, "6358\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "6359\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagIfdArray(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir , uint16 tag ,
                                         uint32 count , uint32 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6363\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6360\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6361\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6362\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6364\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedIfdArray(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "6365\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagIfd8Array(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint64 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6369\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6366\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6367\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6368\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6370\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedIfd8Array(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "6371\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagShortLong(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 value ) 
{ int tmp ;
  int tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6379\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6372\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6373\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6374\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6380\n");
  fflush(_coverage_fout);
  if (value <= 65535U) {
    fprintf(_coverage_fout, "6375\n");
    fflush(_coverage_fout);
    tmp = TIFFWriteDirectoryTagCheckedShort(tif, ndir, dir, tag,
                                            (unsigned short )value);
    fprintf(_coverage_fout, "6376\n");
    fflush(_coverage_fout);
    return (tmp);
  } else {
    fprintf(_coverage_fout, "6377\n");
    fflush(_coverage_fout);
    tmp___0 = TIFFWriteDirectoryTagCheckedLong(tif, ndir, dir, tag, value);
    fprintf(_coverage_fout, "6378\n");
    fflush(_coverage_fout);
    return (tmp___0);
  }
}
}
static int TIFFWriteDirectoryTagLongLong8Array(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , uint64 *value ) ;
static char const   module___9[36]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'L',      (char const   )'o',      (char const   )'n', 
        (char const   )'g',      (char const   )'L',      (char const   )'o',      (char const   )'n', 
        (char const   )'g',      (char const   )'8',      (char const   )'A',      (char const   )'r', 
        (char const   )'r',      (char const   )'a',      (char const   )'y',      (char const   )'\000'};
static int TIFFWriteDirectoryTagLongLong8Array(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , uint64 *value ) 
{ uint64 *ma ;
  uint32 mb ;
  uint32 *p ;
  uint32 *q ;
  int o ;
  int tmp ;
  void *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6401\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6381\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6382\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6383\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6402\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 524288U) {
    fprintf(_coverage_fout, "6384\n");
    fflush(_coverage_fout);
    tmp = TIFFWriteDirectoryTagCheckedLong8Array(tif, ndir, dir, tag, count,
                                                 value);
    fprintf(_coverage_fout, "6385\n");
    fflush(_coverage_fout);
    return (tmp);
  } else {
    fprintf(_coverage_fout, "6386\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6403\n");
  fflush(_coverage_fout);
  tmp___0 = _TIFFmalloc((long )(count * sizeof(uint32 )));
  fprintf(_coverage_fout, "6404\n");
  fflush(_coverage_fout);
  p = (uint32 *)tmp___0;
  fprintf(_coverage_fout, "6405\n");
  fflush(_coverage_fout);
  if ((unsigned int )p == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6387\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___9, "Out of memory");
    fprintf(_coverage_fout, "6388\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "6389\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6406\n");
  fflush(_coverage_fout);
  q = p;
  fprintf(_coverage_fout, "6407\n");
  fflush(_coverage_fout);
  ma = value;
  fprintf(_coverage_fout, "6408\n");
  fflush(_coverage_fout);
  mb = 0U;
  fprintf(_coverage_fout, "6409\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "6395\n");
    fflush(_coverage_fout);
    if (mb < count) {
      fprintf(_coverage_fout, "6390\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "6396\n");
    fflush(_coverage_fout);
    if (*ma > 4294967295ULL) {
      fprintf(_coverage_fout, "6391\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___9,
                   "Attempt to write value larger than 0xFFFFFFFF in Classic TIFF file.");
      fprintf(_coverage_fout, "6392\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)p);
      fprintf(_coverage_fout, "6393\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "6394\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "6397\n");
    fflush(_coverage_fout);
    *q = (unsigned int )*ma;
    fprintf(_coverage_fout, "6398\n");
    fflush(_coverage_fout);
    ma ++;
    fprintf(_coverage_fout, "6399\n");
    fflush(_coverage_fout);
    mb ++;
    fprintf(_coverage_fout, "6400\n");
    fflush(_coverage_fout);
    q ++;
  }
  fprintf(_coverage_fout, "6410\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedLongArray(tif, ndir, dir, tag, count, p);
  fprintf(_coverage_fout, "6411\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)p);
  fprintf(_coverage_fout, "6412\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagShortLongLong8Array(TIFF *tif , uint32 *ndir ,
                                                    TIFFDirEntry *dir ,
                                                    uint16 tag , uint32 count ,
                                                    uint64 *value ) ;
static char const   module___10[41]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'S',      (char const   )'h',      (char const   )'o', 
        (char const   )'r',      (char const   )'t',      (char const   )'L',      (char const   )'o', 
        (char const   )'n',      (char const   )'g',      (char const   )'L',      (char const   )'o', 
        (char const   )'n',      (char const   )'g',      (char const   )'8',      (char const   )'A', 
        (char const   )'r',      (char const   )'r',      (char const   )'a',      (char const   )'y', 
        (char const   )'\000'};
static int TIFFWriteDirectoryTagShortLongLong8Array(TIFF *tif , uint32 *ndir ,
                                                    TIFFDirEntry *dir ,
                                                    uint16 tag , uint32 count ,
                                                    uint64 *value ) 
{ uint64 *ma ;
  uint32 mb ;
  uint8 n ;
  int o ;
  uint16 *p ;
  uint16 *q ;
  void *tmp ;
  uint32 *p___0 ;
  uint32 *q___0 ;
  void *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6471\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6413\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6414\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6415\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6472\n");
  fflush(_coverage_fout);
  n = (unsigned char)0;
  fprintf(_coverage_fout, "6473\n");
  fflush(_coverage_fout);
  ma = value;
  fprintf(_coverage_fout, "6474\n");
  fflush(_coverage_fout);
  mb = 0U;
  fprintf(_coverage_fout, "6475\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "6425\n");
    fflush(_coverage_fout);
    if (mb < count) {
      fprintf(_coverage_fout, "6416\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "6426\n");
    fflush(_coverage_fout);
    if ((int )n == 0) {
      fprintf(_coverage_fout, "6419\n");
      fflush(_coverage_fout);
      if (*ma > 65535ULL) {
        fprintf(_coverage_fout, "6417\n");
        fflush(_coverage_fout);
        n = (unsigned char)1;
      } else {
        fprintf(_coverage_fout, "6418\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "6420\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "6427\n");
    fflush(_coverage_fout);
    if ((int )n == 1) {
      fprintf(_coverage_fout, "6423\n");
      fflush(_coverage_fout);
      if (*ma > 4294967295ULL) {
        fprintf(_coverage_fout, "6421\n");
        fflush(_coverage_fout);
        n = (unsigned char)2;
        break;
      } else {
        fprintf(_coverage_fout, "6422\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "6424\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "6428\n");
    fflush(_coverage_fout);
    ma ++;
    fprintf(_coverage_fout, "6429\n");
    fflush(_coverage_fout);
    mb ++;
  }
  fprintf(_coverage_fout, "6476\n");
  fflush(_coverage_fout);
  if ((int )n == 0) {
    fprintf(_coverage_fout, "6439\n");
    fflush(_coverage_fout);
    tmp = _TIFFmalloc((long )(count * sizeof(uint16 )));
    fprintf(_coverage_fout, "6440\n");
    fflush(_coverage_fout);
    p = (uint16 *)tmp;
    fprintf(_coverage_fout, "6441\n");
    fflush(_coverage_fout);
    if ((unsigned int )p == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "6430\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___10, "Out of memory");
      fprintf(_coverage_fout, "6431\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "6432\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "6442\n");
    fflush(_coverage_fout);
    ma = value;
    fprintf(_coverage_fout, "6443\n");
    fflush(_coverage_fout);
    mb = 0U;
    fprintf(_coverage_fout, "6444\n");
    fflush(_coverage_fout);
    q = p;
    fprintf(_coverage_fout, "6445\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "6434\n");
      fflush(_coverage_fout);
      if (mb < count) {
        fprintf(_coverage_fout, "6433\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "6435\n");
      fflush(_coverage_fout);
      *q = (unsigned short )*ma;
      fprintf(_coverage_fout, "6436\n");
      fflush(_coverage_fout);
      ma ++;
      fprintf(_coverage_fout, "6437\n");
      fflush(_coverage_fout);
      mb ++;
      fprintf(_coverage_fout, "6438\n");
      fflush(_coverage_fout);
      q ++;
    }
    fprintf(_coverage_fout, "6446\n");
    fflush(_coverage_fout);
    o = TIFFWriteDirectoryTagCheckedShortArray(tif, ndir, dir, tag, count, p);
    fprintf(_coverage_fout, "6447\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)p);
  } else {
    fprintf(_coverage_fout, "6470\n");
    fflush(_coverage_fout);
    if ((int )n == 1) {
      fprintf(_coverage_fout, "6457\n");
      fflush(_coverage_fout);
      tmp___0 = _TIFFmalloc((long )(count * sizeof(uint32 )));
      fprintf(_coverage_fout, "6458\n");
      fflush(_coverage_fout);
      p___0 = (uint32 *)tmp___0;
      fprintf(_coverage_fout, "6459\n");
      fflush(_coverage_fout);
      if ((unsigned int )p___0 == (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "6448\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___10, "Out of memory");
        fprintf(_coverage_fout, "6449\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "6450\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "6460\n");
      fflush(_coverage_fout);
      ma = value;
      fprintf(_coverage_fout, "6461\n");
      fflush(_coverage_fout);
      mb = 0U;
      fprintf(_coverage_fout, "6462\n");
      fflush(_coverage_fout);
      q___0 = p___0;
      fprintf(_coverage_fout, "6463\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "6452\n");
        fflush(_coverage_fout);
        if (mb < count) {
          fprintf(_coverage_fout, "6451\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "6453\n");
        fflush(_coverage_fout);
        *q___0 = (unsigned int )*ma;
        fprintf(_coverage_fout, "6454\n");
        fflush(_coverage_fout);
        ma ++;
        fprintf(_coverage_fout, "6455\n");
        fflush(_coverage_fout);
        mb ++;
        fprintf(_coverage_fout, "6456\n");
        fflush(_coverage_fout);
        q___0 ++;
      }
      fprintf(_coverage_fout, "6464\n");
      fflush(_coverage_fout);
      o = TIFFWriteDirectoryTagCheckedLongArray(tif, ndir, dir, tag, count,
                                                p___0);
      fprintf(_coverage_fout, "6465\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)p___0);
    } else {
      fprintf(_coverage_fout, "6468\n");
      fflush(_coverage_fout);
      if ((int )n == 2) {
        fprintf(_coverage_fout, "6466\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "6467\n");
        fflush(_coverage_fout);
        __assert_fail("n==2", "tif_dirwrite.c", 1511U,
                      "TIFFWriteDirectoryTagShortLongLong8Array");
      }
      fprintf(_coverage_fout, "6469\n");
      fflush(_coverage_fout);
      o = TIFFWriteDirectoryTagCheckedLong8Array(tif, ndir, dir, tag, count,
                                                 value);
    }
  }
  fprintf(_coverage_fout, "6477\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagColormap(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir ) ;
static char const   module___11[30]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'C',      (char const   )'o',      (char const   )'l', 
        (char const   )'o',      (char const   )'r',      (char const   )'m',      (char const   )'a', 
        (char const   )'p',      (char const   )'\000'};
static int TIFFWriteDirectoryTagColormap(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir ) 
{ uint32 m ;
  uint16 *n ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6484\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6478\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6479\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6480\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6485\n");
  fflush(_coverage_fout);
  m = (unsigned int )(1 << (int )tif->tif_dir.td_bitspersample);
  fprintf(_coverage_fout, "6486\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((3U * m) * sizeof(uint16 )));
  fprintf(_coverage_fout, "6487\n");
  fflush(_coverage_fout);
  n = (uint16 *)tmp;
  fprintf(_coverage_fout, "6488\n");
  fflush(_coverage_fout);
  if ((unsigned int )n == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6481\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___11, "Out of memory");
    fprintf(_coverage_fout, "6482\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "6483\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6489\n");
  fflush(_coverage_fout);
  _TIFFmemcpy((void *)(n + 0), (void const   *)tif->tif_dir.td_colormap[0],
              (long )(m * sizeof(uint16 )));
  fprintf(_coverage_fout, "6490\n");
  fflush(_coverage_fout);
  _TIFFmemcpy((void *)(n + m), (void const   *)tif->tif_dir.td_colormap[1],
              (long )(m * sizeof(uint16 )));
  fprintf(_coverage_fout, "6491\n");
  fflush(_coverage_fout);
  _TIFFmemcpy((void *)(n + 2U * m), (void const   *)tif->tif_dir.td_colormap[2],
              (long )(m * sizeof(uint16 )));
  fprintf(_coverage_fout, "6492\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedShortArray(tif, ndir, dir,
                                             (unsigned short)320, 3U * m, n);
  fprintf(_coverage_fout, "6493\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)n);
  fprintf(_coverage_fout, "6494\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagTransferfunction(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ) ;
static char const   module___12[38]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'T',      (char const   )'r',      (char const   )'a', 
        (char const   )'n',      (char const   )'s',      (char const   )'f',      (char const   )'e', 
        (char const   )'r',      (char const   )'f',      (char const   )'u',      (char const   )'n', 
        (char const   )'c',      (char const   )'t',      (char const   )'i',      (char const   )'o', 
        (char const   )'n',      (char const   )'\000'};
static int TIFFWriteDirectoryTagTransferfunction(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ) 
{ uint32 m ;
  uint16 n ;
  uint16 *o ;
  int p ;
  int tmp ;
  int tmp___0 ;
  void *tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6519\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6495\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6496\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6497\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6520\n");
  fflush(_coverage_fout);
  m = (unsigned int )(1 << (int )tif->tif_dir.td_bitspersample);
  fprintf(_coverage_fout, "6521\n");
  fflush(_coverage_fout);
  n = (unsigned short )((int )tif->tif_dir.td_samplesperpixel - (int )tif->tif_dir.td_extrasamples);
  fprintf(_coverage_fout, "6522\n");
  fflush(_coverage_fout);
  if ((int )n > 3) {
    fprintf(_coverage_fout, "6498\n");
    fflush(_coverage_fout);
    n = (unsigned short)3;
  } else {
    fprintf(_coverage_fout, "6499\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6523\n");
  fflush(_coverage_fout);
  if ((int )n == 3) {
    fprintf(_coverage_fout, "6502\n");
    fflush(_coverage_fout);
    tmp = _TIFFmemcmp((void const   *)tif->tif_dir.td_transferfunction[0],
                      (void const   *)tif->tif_dir.td_transferfunction[2],
                      (long )(m * sizeof(uint16 )));
    fprintf(_coverage_fout, "6503\n");
    fflush(_coverage_fout);
    if (tmp) {
      fprintf(_coverage_fout, "6500\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "6501\n");
      fflush(_coverage_fout);
      n = (unsigned short)2;
    }
  } else {
    fprintf(_coverage_fout, "6504\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6524\n");
  fflush(_coverage_fout);
  if ((int )n == 2) {
    fprintf(_coverage_fout, "6507\n");
    fflush(_coverage_fout);
    tmp___0 = _TIFFmemcmp((void const   *)tif->tif_dir.td_transferfunction[0],
                          (void const   *)tif->tif_dir.td_transferfunction[1],
                          (long )(m * sizeof(uint16 )));
    fprintf(_coverage_fout, "6508\n");
    fflush(_coverage_fout);
    if (tmp___0) {
      fprintf(_coverage_fout, "6505\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "6506\n");
      fflush(_coverage_fout);
      n = (unsigned short)1;
    }
  } else {
    fprintf(_coverage_fout, "6509\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6525\n");
  fflush(_coverage_fout);
  if ((int )n == 0) {
    fprintf(_coverage_fout, "6510\n");
    fflush(_coverage_fout);
    n = (unsigned short)1;
  } else {
    fprintf(_coverage_fout, "6511\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6526\n");
  fflush(_coverage_fout);
  tmp___1 = _TIFFmalloc((long )(((uint32 )n * m) * sizeof(uint16 )));
  fprintf(_coverage_fout, "6527\n");
  fflush(_coverage_fout);
  o = (uint16 *)tmp___1;
  fprintf(_coverage_fout, "6528\n");
  fflush(_coverage_fout);
  if ((unsigned int )o == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6512\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___12, "Out of memory");
    fprintf(_coverage_fout, "6513\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "6514\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6529\n");
  fflush(_coverage_fout);
  _TIFFmemcpy((void *)(o + 0),
              (void const   *)tif->tif_dir.td_transferfunction[0],
              (long )(m * sizeof(uint16 )));
  fprintf(_coverage_fout, "6530\n");
  fflush(_coverage_fout);
  if ((int )n > 1) {
    fprintf(_coverage_fout, "6515\n");
    fflush(_coverage_fout);
    _TIFFmemcpy((void *)(o + m),
                (void const   *)tif->tif_dir.td_transferfunction[1],
                (long )(m * sizeof(uint16 )));
  } else {
    fprintf(_coverage_fout, "6516\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6531\n");
  fflush(_coverage_fout);
  if ((int )n > 2) {
    fprintf(_coverage_fout, "6517\n");
    fflush(_coverage_fout);
    _TIFFmemcpy((void *)(o + 2U * m),
                (void const   *)tif->tif_dir.td_transferfunction[2],
                (long )(m * sizeof(uint16 )));
  } else {
    fprintf(_coverage_fout, "6518\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6532\n");
  fflush(_coverage_fout);
  p = TIFFWriteDirectoryTagCheckedShortArray(tif, ndir, dir,
                                             (unsigned short)301,
                                             (uint32 )n * m, o);
  fprintf(_coverage_fout, "6533\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)o);
  fprintf(_coverage_fout, "6534\n");
  fflush(_coverage_fout);
  return (p);
}
}
static int TIFFWriteDirectoryTagSubifd(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir ) ;
static char const   module___13[28]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'S',      (char const   )'u',      (char const   )'b', 
        (char const   )'i',      (char const   )'f',      (char const   )'d',      (char const   )'\000'};
static int TIFFWriteDirectoryTagSubifd(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir ) 
{ uint64 m ;
  int n ;
  uint32 *o ;
  uint64 *pa ;
  uint32 *pb ;
  uint16 p ;
  void *tmp ;
  uint32 *tmp___0 ;
  uint64 *tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6568\n");
  fflush(_coverage_fout);
  if ((int )tif->tif_dir.td_nsubifd == 0) {
    fprintf(_coverage_fout, "6535\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6536\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6569\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6537\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "6538\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "6539\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6570\n");
  fflush(_coverage_fout);
  m = tif->tif_dataoff;
  fprintf(_coverage_fout, "6571\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "6554\n");
    fflush(_coverage_fout);
    tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_nsubifd * sizeof(uint32 )));
    fprintf(_coverage_fout, "6555\n");
    fflush(_coverage_fout);
    o = (uint32 *)tmp;
    fprintf(_coverage_fout, "6556\n");
    fflush(_coverage_fout);
    if ((unsigned int )o == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "6540\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___13, "Out of memory");
      fprintf(_coverage_fout, "6541\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "6542\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "6557\n");
    fflush(_coverage_fout);
    pa = tif->tif_dir.td_subifd;
    fprintf(_coverage_fout, "6558\n");
    fflush(_coverage_fout);
    pb = o;
    fprintf(_coverage_fout, "6559\n");
    fflush(_coverage_fout);
    p = (unsigned short)0;
    fprintf(_coverage_fout, "6560\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "6546\n");
      fflush(_coverage_fout);
      if ((int )p < (int )tif->tif_dir.td_nsubifd) {
        fprintf(_coverage_fout, "6543\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "6547\n");
      fflush(_coverage_fout);
      if (*pa <= 4294967295ULL) {
        fprintf(_coverage_fout, "6544\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "6545\n");
        fflush(_coverage_fout);
        __assert_fail("*pa<=0xFFFFFFFFUL", "tif_dirwrite.c", 1625U,
                      "TIFFWriteDirectoryTagSubifd");
      }
      fprintf(_coverage_fout, "6548\n");
      fflush(_coverage_fout);
      tmp___0 = pb;
      fprintf(_coverage_fout, "6549\n");
      fflush(_coverage_fout);
      pb ++;
      fprintf(_coverage_fout, "6550\n");
      fflush(_coverage_fout);
      tmp___1 = pa;
      fprintf(_coverage_fout, "6551\n");
      fflush(_coverage_fout);
      pa ++;
      fprintf(_coverage_fout, "6552\n");
      fflush(_coverage_fout);
      *tmp___0 = (unsigned int )*tmp___1;
      fprintf(_coverage_fout, "6553\n");
      fflush(_coverage_fout);
      p = (uint16 )((int )p + 1);
    }
    fprintf(_coverage_fout, "6561\n");
    fflush(_coverage_fout);
    n = TIFFWriteDirectoryTagCheckedIfdArray(tif, ndir, dir,
                                             (unsigned short)330,
                                             (unsigned int )tif->tif_dir.td_nsubifd,
                                             o);
    fprintf(_coverage_fout, "6562\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)o);
  } else {
    fprintf(_coverage_fout, "6563\n");
    fflush(_coverage_fout);
    n = TIFFWriteDirectoryTagCheckedIfd8Array(tif, ndir, dir,
                                              (unsigned short)330,
                                              (unsigned int )tif->tif_dir.td_nsubifd,
                                              tif->tif_dir.td_subifd);
  }
  fprintf(_coverage_fout, "6572\n");
  fflush(_coverage_fout);
  if (! n) {
    fprintf(_coverage_fout, "6564\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "6565\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6573\n");
  fflush(_coverage_fout);
  tif->tif_flags |= 8192U;
  fprintf(_coverage_fout, "6574\n");
  fflush(_coverage_fout);
  tif->tif_nsubifd = tif->tif_dir.td_nsubifd;
  fprintf(_coverage_fout, "6575\n");
  fflush(_coverage_fout);
  if ((int )tif->tif_dir.td_nsubifd == 1) {
    fprintf(_coverage_fout, "6566\n");
    fflush(_coverage_fout);
    tif->tif_subifdoff = 0ULL;
  } else {
    fprintf(_coverage_fout, "6567\n");
    fflush(_coverage_fout);
    tif->tif_subifdoff = m;
  }
  fprintf(_coverage_fout, "6576\n");
  fflush(_coverage_fout);
  return (1);
}
}
static int TIFFWriteDirectoryTagCheckedAscii(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             uint32 count , char *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6579\n");
  fflush(_coverage_fout);
  if (sizeof(char ) == 1U) {
    fprintf(_coverage_fout, "6577\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6578\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(char)==1", "tif_dirwrite.c", 1655U,
                  "TIFFWriteDirectoryTagCheckedAscii");
  }
  fprintf(_coverage_fout, "6580\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)2, count,
                                  count, (void *)value);
  fprintf(_coverage_fout, "6581\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedUndefinedArray(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag ,
                                                      uint32 count ,
                                                      uint8 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6584\n");
  fflush(_coverage_fout);
  if (sizeof(uint8 ) == 1U) {
    fprintf(_coverage_fout, "6582\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6583\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint8)==1", "tif_dirwrite.c", 1662U,
                  "TIFFWriteDirectoryTagCheckedUndefinedArray");
  }
  fprintf(_coverage_fout, "6585\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)7, count,
                                  count, (void *)value);
  fprintf(_coverage_fout, "6586\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedByte(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint8 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6589\n");
  fflush(_coverage_fout);
  if (sizeof(uint8 ) == 1U) {
    fprintf(_coverage_fout, "6587\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6588\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint8)==1", "tif_dirwrite.c", 1669U,
                  "TIFFWriteDirectoryTagCheckedByte");
  }
  fprintf(_coverage_fout, "6590\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)1, 1U,
                                  1U, (void *)(& value));
  fprintf(_coverage_fout, "6591\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedByteArray(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint8 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6594\n");
  fflush(_coverage_fout);
  if (sizeof(uint8 ) == 1U) {
    fprintf(_coverage_fout, "6592\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6593\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint8)==1", "tif_dirwrite.c", 1676U,
                  "TIFFWriteDirectoryTagCheckedByteArray");
  }
  fprintf(_coverage_fout, "6595\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)1, count,
                                  count, (void *)value);
  fprintf(_coverage_fout, "6596\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSbyte(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             int8 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6599\n");
  fflush(_coverage_fout);
  if (sizeof(int8 ) == 1U) {
    fprintf(_coverage_fout, "6597\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6598\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int8)==1", "tif_dirwrite.c", 1683U,
                  "TIFFWriteDirectoryTagCheckedSbyte");
  }
  fprintf(_coverage_fout, "6600\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)6, 1U,
                                  1U, (void *)(& value));
  fprintf(_coverage_fout, "6601\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSbyteArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  int8 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6604\n");
  fflush(_coverage_fout);
  if (sizeof(int8 ) == 1U) {
    fprintf(_coverage_fout, "6602\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6603\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int8)==1", "tif_dirwrite.c", 1690U,
                  "TIFFWriteDirectoryTagCheckedSbyteArray");
  }
  fprintf(_coverage_fout, "6605\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)6, count,
                                  count, (void *)value);
  fprintf(_coverage_fout, "6606\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedShort(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             uint16 value ) 
{ uint16 m ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6611\n");
  fflush(_coverage_fout);
  if (sizeof(uint16 ) == 2U) {
    fprintf(_coverage_fout, "6607\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6608\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint16)==2", "tif_dirwrite.c", 1698U,
                  "TIFFWriteDirectoryTagCheckedShort");
  }
  fprintf(_coverage_fout, "6612\n");
  fflush(_coverage_fout);
  m = value;
  fprintf(_coverage_fout, "6613\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6609\n");
    fflush(_coverage_fout);
    TIFFSwabShort(& m);
  } else {
    fprintf(_coverage_fout, "6610\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6614\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)3, 1U,
                                  2U, (void *)(& m));
  fprintf(_coverage_fout, "6615\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedShortArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  uint16 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6622\n");
  fflush(_coverage_fout);
  if (count < 0x80000000) {
    fprintf(_coverage_fout, "6616\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6617\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x80000000", "tif_dirwrite.c", 1708U,
                  "TIFFWriteDirectoryTagCheckedShortArray");
  }
  fprintf(_coverage_fout, "6623\n");
  fflush(_coverage_fout);
  if (sizeof(uint16 ) == 2U) {
    fprintf(_coverage_fout, "6618\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6619\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint16)==2", "tif_dirwrite.c", 1709U,
                  "TIFFWriteDirectoryTagCheckedShortArray");
  }
  fprintf(_coverage_fout, "6624\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6620\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfShort(value, (long )count);
  } else {
    fprintf(_coverage_fout, "6621\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6625\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)3, count,
                                  count * 2U, (void *)value);
  fprintf(_coverage_fout, "6626\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSshort(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              int16 value ) 
{ int16 m ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6631\n");
  fflush(_coverage_fout);
  if (sizeof(int16 ) == 2U) {
    fprintf(_coverage_fout, "6627\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6628\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int16)==2", "tif_dirwrite.c", 1719U,
                  "TIFFWriteDirectoryTagCheckedSshort");
  }
  fprintf(_coverage_fout, "6632\n");
  fflush(_coverage_fout);
  m = value;
  fprintf(_coverage_fout, "6633\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6629\n");
    fflush(_coverage_fout);
    TIFFSwabShort((uint16 *)(& m));
  } else {
    fprintf(_coverage_fout, "6630\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6634\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)8, 1U,
                                  2U, (void *)(& m));
  fprintf(_coverage_fout, "6635\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSshortArray(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   int16 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6642\n");
  fflush(_coverage_fout);
  if (count < 0x80000000) {
    fprintf(_coverage_fout, "6636\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6637\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x80000000", "tif_dirwrite.c", 1729U,
                  "TIFFWriteDirectoryTagCheckedSshortArray");
  }
  fprintf(_coverage_fout, "6643\n");
  fflush(_coverage_fout);
  if (sizeof(int16 ) == 2U) {
    fprintf(_coverage_fout, "6638\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6639\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int16)==2", "tif_dirwrite.c", 1730U,
                  "TIFFWriteDirectoryTagCheckedSshortArray");
  }
  fprintf(_coverage_fout, "6644\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6640\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfShort((uint16 *)value, (long )count);
  } else {
    fprintf(_coverage_fout, "6641\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6645\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)8, count,
                                  count * 2U, (void *)value);
  fprintf(_coverage_fout, "6646\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedLong(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 value ) 
{ uint32 m ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6651\n");
  fflush(_coverage_fout);
  if (sizeof(uint32 ) == 4U) {
    fprintf(_coverage_fout, "6647\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6648\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint32)==4", "tif_dirwrite.c", 1740U,
                  "TIFFWriteDirectoryTagCheckedLong");
  }
  fprintf(_coverage_fout, "6652\n");
  fflush(_coverage_fout);
  m = value;
  fprintf(_coverage_fout, "6653\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6649\n");
    fflush(_coverage_fout);
    TIFFSwabLong(& m);
  } else {
    fprintf(_coverage_fout, "6650\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6654\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)4, 1U,
                                  4U, (void *)(& m));
  fprintf(_coverage_fout, "6655\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedLongArray(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint32 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6662\n");
  fflush(_coverage_fout);
  if (count < 1073741824U) {
    fprintf(_coverage_fout, "6656\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6657\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x40000000", "tif_dirwrite.c", 1750U,
                  "TIFFWriteDirectoryTagCheckedLongArray");
  }
  fprintf(_coverage_fout, "6663\n");
  fflush(_coverage_fout);
  if (sizeof(uint32 ) == 4U) {
    fprintf(_coverage_fout, "6658\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6659\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint32)==4", "tif_dirwrite.c", 1751U,
                  "TIFFWriteDirectoryTagCheckedLongArray");
  }
  fprintf(_coverage_fout, "6664\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6660\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong(value, (long )count);
  } else {
    fprintf(_coverage_fout, "6661\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6665\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)4, count,
                                  count * 4U, (void *)value);
  fprintf(_coverage_fout, "6666\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSlong(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             int32 value ) 
{ int32 m ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6671\n");
  fflush(_coverage_fout);
  if (sizeof(int32 ) == 4U) {
    fprintf(_coverage_fout, "6667\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6668\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int32)==4", "tif_dirwrite.c", 1761U,
                  "TIFFWriteDirectoryTagCheckedSlong");
  }
  fprintf(_coverage_fout, "6672\n");
  fflush(_coverage_fout);
  m = value;
  fprintf(_coverage_fout, "6673\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6669\n");
    fflush(_coverage_fout);
    TIFFSwabLong((uint32 *)(& m));
  } else {
    fprintf(_coverage_fout, "6670\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6674\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)9, 1U,
                                  4U, (void *)(& m));
  fprintf(_coverage_fout, "6675\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSlongArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  int32 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6682\n");
  fflush(_coverage_fout);
  if (count < 1073741824U) {
    fprintf(_coverage_fout, "6676\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6677\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x40000000", "tif_dirwrite.c", 1771U,
                  "TIFFWriteDirectoryTagCheckedSlongArray");
  }
  fprintf(_coverage_fout, "6683\n");
  fflush(_coverage_fout);
  if (sizeof(int32 ) == 4U) {
    fprintf(_coverage_fout, "6678\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6679\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int32)==4", "tif_dirwrite.c", 1772U,
                  "TIFFWriteDirectoryTagCheckedSlongArray");
  }
  fprintf(_coverage_fout, "6684\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6680\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong((uint32 *)value, (long )count);
  } else {
    fprintf(_coverage_fout, "6681\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6685\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)9, count,
                                  count * 4U, (void *)value);
  fprintf(_coverage_fout, "6686\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedLong8(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             uint64 value ) 
{ uint64 m ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6693\n");
  fflush(_coverage_fout);
  if (sizeof(uint64 ) == 8U) {
    fprintf(_coverage_fout, "6687\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6688\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint64)==8", "tif_dirwrite.c", 1782U,
                  "TIFFWriteDirectoryTagCheckedLong8");
  }
  fprintf(_coverage_fout, "6694\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 524288U) {
    fprintf(_coverage_fout, "6689\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6690\n");
    fflush(_coverage_fout);
    __assert_fail("tif->tif_flags&0x80000", "tif_dirwrite.c", 1783U,
                  "TIFFWriteDirectoryTagCheckedLong8");
  }
  fprintf(_coverage_fout, "6695\n");
  fflush(_coverage_fout);
  m = value;
  fprintf(_coverage_fout, "6696\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6691\n");
    fflush(_coverage_fout);
    TIFFSwabLong8(& m);
  } else {
    fprintf(_coverage_fout, "6692\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6697\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)16, 1U,
                                  8U, (void *)(& m));
  fprintf(_coverage_fout, "6698\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedLong8Array(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  uint64 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6707\n");
  fflush(_coverage_fout);
  if (count < 536870912U) {
    fprintf(_coverage_fout, "6699\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6700\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x20000000", "tif_dirwrite.c", 1793U,
                  "TIFFWriteDirectoryTagCheckedLong8Array");
  }
  fprintf(_coverage_fout, "6708\n");
  fflush(_coverage_fout);
  if (sizeof(uint64 ) == 8U) {
    fprintf(_coverage_fout, "6701\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6702\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint64)==8", "tif_dirwrite.c", 1794U,
                  "TIFFWriteDirectoryTagCheckedLong8Array");
  }
  fprintf(_coverage_fout, "6709\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 524288U) {
    fprintf(_coverage_fout, "6703\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6704\n");
    fflush(_coverage_fout);
    __assert_fail("tif->tif_flags&0x80000", "tif_dirwrite.c", 1795U,
                  "TIFFWriteDirectoryTagCheckedLong8Array");
  }
  fprintf(_coverage_fout, "6710\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6705\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong8(value, (long )count);
  } else {
    fprintf(_coverage_fout, "6706\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6711\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)16,
                                  count, count * 8U, (void *)value);
  fprintf(_coverage_fout, "6712\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSlong8(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              int64 value ) 
{ int64 m ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6719\n");
  fflush(_coverage_fout);
  if (sizeof(int64 ) == 8U) {
    fprintf(_coverage_fout, "6713\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6714\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int64)==8", "tif_dirwrite.c", 1805U,
                  "TIFFWriteDirectoryTagCheckedSlong8");
  }
  fprintf(_coverage_fout, "6720\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 524288U) {
    fprintf(_coverage_fout, "6715\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6716\n");
    fflush(_coverage_fout);
    __assert_fail("tif->tif_flags&0x80000", "tif_dirwrite.c", 1806U,
                  "TIFFWriteDirectoryTagCheckedSlong8");
  }
  fprintf(_coverage_fout, "6721\n");
  fflush(_coverage_fout);
  m = value;
  fprintf(_coverage_fout, "6722\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6717\n");
    fflush(_coverage_fout);
    TIFFSwabLong8((uint64 *)(& m));
  } else {
    fprintf(_coverage_fout, "6718\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6723\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)17, 1U,
                                  8U, (void *)(& m));
  fprintf(_coverage_fout, "6724\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSlong8Array(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   int64 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6733\n");
  fflush(_coverage_fout);
  if (count < 536870912U) {
    fprintf(_coverage_fout, "6725\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6726\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x20000000", "tif_dirwrite.c", 1816U,
                  "TIFFWriteDirectoryTagCheckedSlong8Array");
  }
  fprintf(_coverage_fout, "6734\n");
  fflush(_coverage_fout);
  if (sizeof(int64 ) == 8U) {
    fprintf(_coverage_fout, "6727\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6728\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int64)==8", "tif_dirwrite.c", 1817U,
                  "TIFFWriteDirectoryTagCheckedSlong8Array");
  }
  fprintf(_coverage_fout, "6735\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 524288U) {
    fprintf(_coverage_fout, "6729\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6730\n");
    fflush(_coverage_fout);
    __assert_fail("tif->tif_flags&0x80000", "tif_dirwrite.c", 1818U,
                  "TIFFWriteDirectoryTagCheckedSlong8Array");
  }
  fprintf(_coverage_fout, "6736\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6731\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong8((uint64 *)value, (long )count);
  } else {
    fprintf(_coverage_fout, "6732\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6737\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)17,
                                  count, count * 8U, (void *)value);
  fprintf(_coverage_fout, "6738\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedRational(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                double value ) 
{ uint32 m[2] ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6756\n");
  fflush(_coverage_fout);
  if (value >= 0.0) {
    fprintf(_coverage_fout, "6739\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6740\n");
    fflush(_coverage_fout);
    __assert_fail("value>=0.0", "tif_dirwrite.c", 1828U,
                  "TIFFWriteDirectoryTagCheckedRational");
  }
  fprintf(_coverage_fout, "6757\n");
  fflush(_coverage_fout);
  if (sizeof(uint32 ) == 4U) {
    fprintf(_coverage_fout, "6741\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6742\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint32)==4", "tif_dirwrite.c", 1829U,
                  "TIFFWriteDirectoryTagCheckedRational");
  }
  fprintf(_coverage_fout, "6758\n");
  fflush(_coverage_fout);
  if (value <= 0.0) {
    fprintf(_coverage_fout, "6743\n");
    fflush(_coverage_fout);
    m[0] = 0U;
    fprintf(_coverage_fout, "6744\n");
    fflush(_coverage_fout);
    m[1] = 1U;
  } else {
    fprintf(_coverage_fout, "6752\n");
    fflush(_coverage_fout);
    if (value == (double )((unsigned int )value)) {
      fprintf(_coverage_fout, "6745\n");
      fflush(_coverage_fout);
      m[0] = (unsigned int )value;
      fprintf(_coverage_fout, "6746\n");
      fflush(_coverage_fout);
      m[1] = 1U;
    } else {
      fprintf(_coverage_fout, "6751\n");
      fflush(_coverage_fout);
      if (value < 1.0) {
        fprintf(_coverage_fout, "6747\n");
        fflush(_coverage_fout);
        m[0] = (unsigned int )(value * (double )0xFFFFFFFF);
        fprintf(_coverage_fout, "6748\n");
        fflush(_coverage_fout);
        m[1] = 0xFFFFFFFF;
      } else {
        fprintf(_coverage_fout, "6749\n");
        fflush(_coverage_fout);
        m[0] = 0xFFFFFFFF;
        fprintf(_coverage_fout, "6750\n");
        fflush(_coverage_fout);
        m[1] = (unsigned int )((double )0xFFFFFFFF / value);
      }
    }
  }
  fprintf(_coverage_fout, "6759\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6753\n");
    fflush(_coverage_fout);
    TIFFSwabLong(& m[0]);
    fprintf(_coverage_fout, "6754\n");
    fflush(_coverage_fout);
    TIFFSwabLong(& m[1]);
  } else {
    fprintf(_coverage_fout, "6755\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6760\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)5, 1U,
                                  8U, (void *)(& m[0]));
  fprintf(_coverage_fout, "6761\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedRationalArray(TIFF *tif , uint32 *ndir ,
                                                     TIFFDirEntry *dir ,
                                                     uint16 tag , uint32 count ,
                                                     float *value ) ;
static char const   module___14[42]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'C',      (char const   )'h',      (char const   )'e', 
        (char const   )'c',      (char const   )'k',      (char const   )'e',      (char const   )'d', 
        (char const   )'R',      (char const   )'a',      (char const   )'t',      (char const   )'i', 
        (char const   )'o',      (char const   )'n',      (char const   )'a',      (char const   )'l', 
        (char const   )'A',      (char const   )'r',      (char const   )'r',      (char const   )'a', 
        (char const   )'y',      (char const   )'\000'};
static int TIFFWriteDirectoryTagCheckedRationalArray(TIFF *tif , uint32 *ndir ,
                                                     TIFFDirEntry *dir ,
                                                     uint16 tag , uint32 count ,
                                                     float *value ) 
{ uint32 *m ;
  float *na ;
  uint32 *nb ;
  uint32 nc ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6785\n");
  fflush(_coverage_fout);
  if (sizeof(uint32 ) == 4U) {
    fprintf(_coverage_fout, "6762\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6763\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint32)==4", "tif_dirwrite.c", 1867U,
                  "TIFFWriteDirectoryTagCheckedRationalArray");
  }
  fprintf(_coverage_fout, "6786\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((count * 2U) * sizeof(uint32 )));
  fprintf(_coverage_fout, "6787\n");
  fflush(_coverage_fout);
  m = (uint32 *)tmp;
  fprintf(_coverage_fout, "6788\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6764\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___14, "Out of memory");
    fprintf(_coverage_fout, "6765\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "6766\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6789\n");
  fflush(_coverage_fout);
  na = value;
  fprintf(_coverage_fout, "6790\n");
  fflush(_coverage_fout);
  nb = m;
  fprintf(_coverage_fout, "6791\n");
  fflush(_coverage_fout);
  nc = 0U;
  fprintf(_coverage_fout, "6792\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "6778\n");
    fflush(_coverage_fout);
    if (nc < count) {
      fprintf(_coverage_fout, "6767\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "6779\n");
    fflush(_coverage_fout);
    if ((double )*na <= 0.0) {
      fprintf(_coverage_fout, "6768\n");
      fflush(_coverage_fout);
      *(nb + 0) = 0U;
      fprintf(_coverage_fout, "6769\n");
      fflush(_coverage_fout);
      *(nb + 1) = 1U;
    } else {
      fprintf(_coverage_fout, "6777\n");
      fflush(_coverage_fout);
      if (*na == (float )((unsigned int )*na)) {
        fprintf(_coverage_fout, "6770\n");
        fflush(_coverage_fout);
        *(nb + 0) = (unsigned int )*na;
        fprintf(_coverage_fout, "6771\n");
        fflush(_coverage_fout);
        *(nb + 1) = 1U;
      } else {
        fprintf(_coverage_fout, "6776\n");
        fflush(_coverage_fout);
        if ((double )*na < 1.0) {
          fprintf(_coverage_fout, "6772\n");
          fflush(_coverage_fout);
          *(nb + 0) = (unsigned int )(*na * (float )0xFFFFFFFF);
          fprintf(_coverage_fout, "6773\n");
          fflush(_coverage_fout);
          *(nb + 1) = 0xFFFFFFFF;
        } else {
          fprintf(_coverage_fout, "6774\n");
          fflush(_coverage_fout);
          *(nb + 0) = 0xFFFFFFFF;
          fprintf(_coverage_fout, "6775\n");
          fflush(_coverage_fout);
          *(nb + 1) = (unsigned int )((float )0xFFFFFFFF / *na);
        }
      }
    }
    fprintf(_coverage_fout, "6780\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "6781\n");
    fflush(_coverage_fout);
    nb += 2;
    fprintf(_coverage_fout, "6782\n");
    fflush(_coverage_fout);
    nc ++;
  }
  fprintf(_coverage_fout, "6793\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6783\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong(m, (long )(count * 2U));
  } else {
    fprintf(_coverage_fout, "6784\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6794\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)5, count,
                                count * 8U, (void *)(m + 0));
  fprintf(_coverage_fout, "6795\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "6796\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagCheckedSrationalArray(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag ,
                                                      uint32 count ,
                                                      float *value ) ;
static char const   module___15[43]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'C',      (char const   )'h',      (char const   )'e', 
        (char const   )'c',      (char const   )'k',      (char const   )'e',      (char const   )'d', 
        (char const   )'S',      (char const   )'r',      (char const   )'a',      (char const   )'t', 
        (char const   )'i',      (char const   )'o',      (char const   )'n',      (char const   )'a', 
        (char const   )'l',      (char const   )'A',      (char const   )'r',      (char const   )'r', 
        (char const   )'a',      (char const   )'y',      (char const   )'\000'};
static int TIFFWriteDirectoryTagCheckedSrationalArray(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag ,
                                                      uint32 count ,
                                                      float *value ) 
{ int32 *m ;
  float *na ;
  int32 *nb ;
  uint32 nc ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6826\n");
  fflush(_coverage_fout);
  if (sizeof(int32 ) == 4U) {
    fprintf(_coverage_fout, "6797\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6798\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int32)==4", "tif_dirwrite.c", 1913U,
                  "TIFFWriteDirectoryTagCheckedSrationalArray");
  }
  fprintf(_coverage_fout, "6827\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((count * 2U) * sizeof(int32 )));
  fprintf(_coverage_fout, "6828\n");
  fflush(_coverage_fout);
  m = (int32 *)tmp;
  fprintf(_coverage_fout, "6829\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "6799\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___15, "Out of memory");
    fprintf(_coverage_fout, "6800\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "6801\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6830\n");
  fflush(_coverage_fout);
  na = value;
  fprintf(_coverage_fout, "6831\n");
  fflush(_coverage_fout);
  nb = m;
  fprintf(_coverage_fout, "6832\n");
  fflush(_coverage_fout);
  nc = 0U;
  fprintf(_coverage_fout, "6833\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "6819\n");
    fflush(_coverage_fout);
    if (nc < count) {
      fprintf(_coverage_fout, "6802\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "6820\n");
    fflush(_coverage_fout);
    if ((double )*na < 0.0) {
      fprintf(_coverage_fout, "6810\n");
      fflush(_coverage_fout);
      if (*na == (float )((int )*na)) {
        fprintf(_coverage_fout, "6803\n");
        fflush(_coverage_fout);
        *(nb + 0) = (int )*na;
        fprintf(_coverage_fout, "6804\n");
        fflush(_coverage_fout);
        *(nb + 1) = 1;
      } else {
        fprintf(_coverage_fout, "6809\n");
        fflush(_coverage_fout);
        if ((double )*na > - 1.0) {
          fprintf(_coverage_fout, "6805\n");
          fflush(_coverage_fout);
          *(nb + 0) = - ((int )(- *na * (float )0x7FFFFFFF));
          fprintf(_coverage_fout, "6806\n");
          fflush(_coverage_fout);
          *(nb + 1) = 0x7FFFFFFF;
        } else {
          fprintf(_coverage_fout, "6807\n");
          fflush(_coverage_fout);
          *(nb + 0) = -2147483647;
          fprintf(_coverage_fout, "6808\n");
          fflush(_coverage_fout);
          *(nb + 1) = (int )((float )0x7FFFFFFF / - *na);
        }
      }
    } else {
      fprintf(_coverage_fout, "6818\n");
      fflush(_coverage_fout);
      if (*na == (float )((int )*na)) {
        fprintf(_coverage_fout, "6811\n");
        fflush(_coverage_fout);
        *(nb + 0) = (int )*na;
        fprintf(_coverage_fout, "6812\n");
        fflush(_coverage_fout);
        *(nb + 1) = 1;
      } else {
        fprintf(_coverage_fout, "6817\n");
        fflush(_coverage_fout);
        if ((double )*na < 1.0) {
          fprintf(_coverage_fout, "6813\n");
          fflush(_coverage_fout);
          *(nb + 0) = (int )(*na * (float )0x7FFFFFFF);
          fprintf(_coverage_fout, "6814\n");
          fflush(_coverage_fout);
          *(nb + 1) = 0x7FFFFFFF;
        } else {
          fprintf(_coverage_fout, "6815\n");
          fflush(_coverage_fout);
          *(nb + 0) = 0x7FFFFFFF;
          fprintf(_coverage_fout, "6816\n");
          fflush(_coverage_fout);
          *(nb + 1) = (int )((float )0x7FFFFFFF / *na);
        }
      }
    }
    fprintf(_coverage_fout, "6821\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "6822\n");
    fflush(_coverage_fout);
    nb += 2;
    fprintf(_coverage_fout, "6823\n");
    fflush(_coverage_fout);
    nc ++;
  }
  fprintf(_coverage_fout, "6834\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6824\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong((uint32 *)m, (long )(count * 2U));
  } else {
    fprintf(_coverage_fout, "6825\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6835\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)10, count,
                                count * 8U, (void *)(m + 0));
  fprintf(_coverage_fout, "6836\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "6837\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagCheckedFloat(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             float value ) 
{ float m ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6842\n");
  fflush(_coverage_fout);
  if (sizeof(float ) == 4U) {
    fprintf(_coverage_fout, "6838\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6839\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(float)==4", "tif_dirwrite.c", 1970U,
                  "TIFFWriteDirectoryTagCheckedFloat");
  }
  fprintf(_coverage_fout, "6843\n");
  fflush(_coverage_fout);
  m = value;
  fprintf(_coverage_fout, "6844\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6840\n");
    fflush(_coverage_fout);
    TIFFSwabFloat(& m);
  } else {
    fprintf(_coverage_fout, "6841\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6845\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)11, 1U,
                                  4U, (void *)(& m));
  fprintf(_coverage_fout, "6846\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedFloatArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  float *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6853\n");
  fflush(_coverage_fout);
  if (count < 1073741824U) {
    fprintf(_coverage_fout, "6847\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6848\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x40000000", "tif_dirwrite.c", 1981U,
                  "TIFFWriteDirectoryTagCheckedFloatArray");
  }
  fprintf(_coverage_fout, "6854\n");
  fflush(_coverage_fout);
  if (sizeof(float ) == 4U) {
    fprintf(_coverage_fout, "6849\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6850\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(float)==4", "tif_dirwrite.c", 1982U,
                  "TIFFWriteDirectoryTagCheckedFloatArray");
  }
  fprintf(_coverage_fout, "6855\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6851\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfFloat(value, (long )count);
  } else {
    fprintf(_coverage_fout, "6852\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6856\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)11,
                                  count, count * 4U, (void *)value);
  fprintf(_coverage_fout, "6857\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedDouble(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              double value ) 
{ double m ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6862\n");
  fflush(_coverage_fout);
  if (sizeof(double ) == 8U) {
    fprintf(_coverage_fout, "6858\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6859\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(double)==8", "tif_dirwrite.c", 1993U,
                  "TIFFWriteDirectoryTagCheckedDouble");
  }
  fprintf(_coverage_fout, "6863\n");
  fflush(_coverage_fout);
  m = value;
  fprintf(_coverage_fout, "6864\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6860\n");
    fflush(_coverage_fout);
    TIFFSwabDouble(& m);
  } else {
    fprintf(_coverage_fout, "6861\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6865\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)12, 1U,
                                  8U, (void *)(& m));
  fprintf(_coverage_fout, "6866\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedDoubleArray(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   double *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6873\n");
  fflush(_coverage_fout);
  if (count < 536870912U) {
    fprintf(_coverage_fout, "6867\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6868\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x20000000", "tif_dirwrite.c", 2004U,
                  "TIFFWriteDirectoryTagCheckedDoubleArray");
  }
  fprintf(_coverage_fout, "6874\n");
  fflush(_coverage_fout);
  if (sizeof(double ) == 8U) {
    fprintf(_coverage_fout, "6869\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6870\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(double)==8", "tif_dirwrite.c", 2005U,
                  "TIFFWriteDirectoryTagCheckedDoubleArray");
  }
  fprintf(_coverage_fout, "6875\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6871\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfDouble(value, (long )count);
  } else {
    fprintf(_coverage_fout, "6872\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6876\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)12,
                                  count, count * 8U, (void *)value);
  fprintf(_coverage_fout, "6877\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedIfdArray(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                uint32 count , uint32 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6884\n");
  fflush(_coverage_fout);
  if (count < 1073741824U) {
    fprintf(_coverage_fout, "6878\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6879\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x40000000", "tif_dirwrite.c", 2015U,
                  "TIFFWriteDirectoryTagCheckedIfdArray");
  }
  fprintf(_coverage_fout, "6885\n");
  fflush(_coverage_fout);
  if (sizeof(uint32 ) == 4U) {
    fprintf(_coverage_fout, "6880\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6881\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint32)==4", "tif_dirwrite.c", 2016U,
                  "TIFFWriteDirectoryTagCheckedIfdArray");
  }
  fprintf(_coverage_fout, "6886\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6882\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong(value, (long )count);
  } else {
    fprintf(_coverage_fout, "6883\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6887\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)13,
                                  count, count * 4U, (void *)value);
  fprintf(_coverage_fout, "6888\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedIfd8Array(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint64 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6897\n");
  fflush(_coverage_fout);
  if (count < 536870912U) {
    fprintf(_coverage_fout, "6889\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6890\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x20000000", "tif_dirwrite.c", 2025U,
                  "TIFFWriteDirectoryTagCheckedIfd8Array");
  }
  fprintf(_coverage_fout, "6898\n");
  fflush(_coverage_fout);
  if (sizeof(uint64 ) == 8U) {
    fprintf(_coverage_fout, "6891\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6892\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint64)==8", "tif_dirwrite.c", 2026U,
                  "TIFFWriteDirectoryTagCheckedIfd8Array");
  }
  fprintf(_coverage_fout, "6899\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 524288U) {
    fprintf(_coverage_fout, "6893\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "6894\n");
    fflush(_coverage_fout);
    __assert_fail("tif->tif_flags&0x80000", "tif_dirwrite.c", 2027U,
                  "TIFFWriteDirectoryTagCheckedIfd8Array");
  }
  fprintf(_coverage_fout, "6900\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "6895\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong8(value, (long )count);
  } else {
    fprintf(_coverage_fout, "6896\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6901\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)18,
                                  count, count * 8U, (void *)value);
  fprintf(_coverage_fout, "6902\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagData(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint16 datatype , uint32 count ,
                                     uint32 datalength , void *data ) ;
static char const   module___16[26]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'D',      (char const   )'a',      (char const   )'t', 
        (char const   )'a',      (char const   )'\000'};
static int TIFFWriteDirectoryTagData(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint16 datatype , uint32 count ,
                                     uint32 datalength , void *data ) 
{ uint32 m ;
  uint32 n ;
  uint64 na ;
  uint64 nb ;
  uint64 tmp ;
  tmsize_t tmp___0 ;
  uint32 o ;
  unsigned int tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "6960\n");
  fflush(_coverage_fout);
  m = 0U;
  fprintf(_coverage_fout, "6961\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "6907\n");
    fflush(_coverage_fout);
    if (m < *ndir) {
      fprintf(_coverage_fout, "6903\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "6908\n");
    fflush(_coverage_fout);
    if ((int )(dir + m)->tdir_tag != (int )tag) {
      fprintf(_coverage_fout, "6904\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "6905\n");
      fflush(_coverage_fout);
      __assert_fail("dir[m].tdir_tag!=tag", "tif_dirwrite.c", 2041U,
                    "TIFFWriteDirectoryTagData");
    }
    fprintf(_coverage_fout, "6909\n");
    fflush(_coverage_fout);
    if ((int )(dir + m)->tdir_tag > (int )tag) {
      break;
    } else {
      fprintf(_coverage_fout, "6906\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "6910\n");
    fflush(_coverage_fout);
    m ++;
  }
  fprintf(_coverage_fout, "6962\n");
  fflush(_coverage_fout);
  if (m < *ndir) {
    fprintf(_coverage_fout, "6915\n");
    fflush(_coverage_fout);
    n = *ndir;
    fprintf(_coverage_fout, "6916\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "6912\n");
      fflush(_coverage_fout);
      if (n > m) {
        fprintf(_coverage_fout, "6911\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "6913\n");
      fflush(_coverage_fout);
      *(dir + n) = *(dir + (n - 1U));
      fprintf(_coverage_fout, "6914\n");
      fflush(_coverage_fout);
      n --;
    }
  } else {
    fprintf(_coverage_fout, "6917\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "6963\n");
  fflush(_coverage_fout);
  (dir + m)->tdir_tag = tag;
  fprintf(_coverage_fout, "6964\n");
  fflush(_coverage_fout);
  (dir + m)->tdir_type = datatype;
  fprintf(_coverage_fout, "6965\n");
  fflush(_coverage_fout);
  (dir + m)->tdir_count = (unsigned long long )count;
  fprintf(_coverage_fout, "6966\n");
  fflush(_coverage_fout);
  (dir + m)->tdir_offset = 0ULL;
  fprintf(_coverage_fout, "6967\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 524288U) {
    fprintf(_coverage_fout, "6918\n");
    fflush(_coverage_fout);
    tmp___1 = 0x8U;
  } else {
    fprintf(_coverage_fout, "6919\n");
    fflush(_coverage_fout);
    tmp___1 = 0x4U;
  }
  fprintf(_coverage_fout, "6968\n");
  fflush(_coverage_fout);
  if (datalength <= tmp___1) {
    fprintf(_coverage_fout, "6920\n");
    fflush(_coverage_fout);
    _TIFFmemcpy((void *)(& (dir + m)->tdir_offset), (void const   *)data,
                (long )datalength);
  } else {
    fprintf(_coverage_fout, "6948\n");
    fflush(_coverage_fout);
    na = tif->tif_dataoff;
    fprintf(_coverage_fout, "6949\n");
    fflush(_coverage_fout);
    nb = na + (uint64 )datalength;
    fprintf(_coverage_fout, "6950\n");
    fflush(_coverage_fout);
    if (! (tif->tif_flags & 524288U)) {
      fprintf(_coverage_fout, "6921\n");
      fflush(_coverage_fout);
      nb = (unsigned long long )((unsigned int )nb);
    } else {
      fprintf(_coverage_fout, "6922\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "6951\n");
    fflush(_coverage_fout);
    if (nb < na) {
      fprintf(_coverage_fout, "6923\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___16,
                   "Maximum TIFF file size exceeded");
      fprintf(_coverage_fout, "6924\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "6928\n");
      fflush(_coverage_fout);
      if (nb < (uint64 )datalength) {
        fprintf(_coverage_fout, "6925\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___16,
                     "Maximum TIFF file size exceeded");
        fprintf(_coverage_fout, "6926\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "6927\n");
        fflush(_coverage_fout);

      }
    }
    fprintf(_coverage_fout, "6952\n");
    fflush(_coverage_fout);
    tmp = (*(tif->tif_seekproc))(tif->tif_clientdata, na, 0);
    fprintf(_coverage_fout, "6953\n");
    fflush(_coverage_fout);
    if (tmp == na) {
      fprintf(_coverage_fout, "6929\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "6930\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___16, "IO error writing tag data");
      fprintf(_coverage_fout, "6931\n");
      fflush(_coverage_fout);
      return (0);
    }
    fprintf(_coverage_fout, "6954\n");
    fflush(_coverage_fout);
    if ((unsigned long )datalength < 0x80000000UL) {
      fprintf(_coverage_fout, "6932\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "6933\n");
      fflush(_coverage_fout);
      __assert_fail("datalength<0x80000000UL", "tif_dirwrite.c", 2075U,
                    "TIFFWriteDirectoryTagData");
    }
    fprintf(_coverage_fout, "6955\n");
    fflush(_coverage_fout);
    tmp___0 = (*(tif->tif_writeproc))(tif->tif_clientdata, data,
                                      (long )datalength);
    fprintf(_coverage_fout, "6956\n");
    fflush(_coverage_fout);
    if (tmp___0 == (long )datalength) {
      fprintf(_coverage_fout, "6934\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "6935\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___16, "IO error writing tag data");
      fprintf(_coverage_fout, "6936\n");
      fflush(_coverage_fout);
      return (0);
    }
    fprintf(_coverage_fout, "6957\n");
    fflush(_coverage_fout);
    tif->tif_dataoff = nb;
    fprintf(_coverage_fout, "6958\n");
    fflush(_coverage_fout);
    if (tif->tif_dataoff & 1ULL) {
      fprintf(_coverage_fout, "6937\n");
      fflush(_coverage_fout);
      (tif->tif_dataoff) ++;
    } else {
      fprintf(_coverage_fout, "6938\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "6959\n");
    fflush(_coverage_fout);
    if (! (tif->tif_flags & 524288U)) {
      fprintf(_coverage_fout, "6941\n");
      fflush(_coverage_fout);
      o = (unsigned int )na;
      fprintf(_coverage_fout, "6942\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "6939\n");
        fflush(_coverage_fout);
        TIFFSwabLong(& o);
      } else {
        fprintf(_coverage_fout, "6940\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "6943\n");
      fflush(_coverage_fout);
      _TIFFmemcpy((void *)(& (dir + m)->tdir_offset), (void const   *)(& o), 4L);
    } else {
      fprintf(_coverage_fout, "6946\n");
      fflush(_coverage_fout);
      (dir + m)->tdir_offset = na;
      fprintf(_coverage_fout, "6947\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "6944\n");
        fflush(_coverage_fout);
        TIFFSwabLong8(& (dir + m)->tdir_offset);
      } else {
        fprintf(_coverage_fout, "6945\n");
        fflush(_coverage_fout);

      }
    }
  }
  fprintf(_coverage_fout, "6969\n");
  fflush(_coverage_fout);
  (*ndir) ++;
  fprintf(_coverage_fout, "6970\n");
  fflush(_coverage_fout);
  return (1);
}
}
static int TIFFLinkDirectory(TIFF *tif ) ;
static char const   module___17[18]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'L',      (char const   )'i',      (char const   )'n',      (char const   )'k', 
        (char const   )'D',      (char const   )'i',      (char const   )'r',      (char const   )'e', 
        (char const   )'c',      (char const   )'t',      (char const   )'o',      (char const   )'r', 
        (char const   )'y',      (char const   )'\000'};
static int TIFFLinkDirectory(TIFF *tif ) 
{ uint64 tmp ;
  uint32 m ;
  tmsize_t tmp___0 ;
  uint64 m___0 ;
  tmsize_t tmp___1 ;
  uint32 m___1 ;
  uint32 nextdir ;
  tmsize_t tmp___2 ;
  uint16 dircount ;
  uint32 nextnextdir ;
  uint64 tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  uint64 m___2 ;
  uint64 nextdir___0 ;
  tmsize_t tmp___7 ;
  uint64 dircount64 ;
  uint16 dircount___0 ;
  uint64 nextnextdir___0 ;
  uint64 tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;
  tmsize_t tmp___11 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7100\n");
  fflush(_coverage_fout);
  tmp = (*(tif->tif_seekproc))(tif->tif_clientdata, 0ULL, 2);
  fprintf(_coverage_fout, "7101\n");
  fflush(_coverage_fout);
  tif->tif_diroff = (tmp + 1ULL) & 0xfffffffffffffffeULL;
  fprintf(_coverage_fout, "7102\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 8192U) {
    fprintf(_coverage_fout, "7001\n");
    fflush(_coverage_fout);
    if (! (tif->tif_flags & 524288U)) {
      fprintf(_coverage_fout, "6978\n");
      fflush(_coverage_fout);
      m = (unsigned int )tif->tif_diroff;
      fprintf(_coverage_fout, "6979\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "6971\n");
        fflush(_coverage_fout);
        TIFFSwabLong(& m);
      } else {
        fprintf(_coverage_fout, "6972\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "6980\n");
      fflush(_coverage_fout);
      (*(tif->tif_seekproc))(tif->tif_clientdata, tif->tif_subifdoff, 0);
      fprintf(_coverage_fout, "6981\n");
      fflush(_coverage_fout);
      tmp___0 = (*(tif->tif_writeproc))(tif->tif_clientdata, (void *)(& m), 4L);
      fprintf(_coverage_fout, "6982\n");
      fflush(_coverage_fout);
      if (tmp___0 == 4L) {
        fprintf(_coverage_fout, "6973\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "6974\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error writing SubIFD directory link");
        fprintf(_coverage_fout, "6975\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "6983\n");
      fflush(_coverage_fout);
      tif->tif_nsubifd = (uint16 )((int )tif->tif_nsubifd - 1);
      fprintf(_coverage_fout, "6984\n");
      fflush(_coverage_fout);
      if (tif->tif_nsubifd) {
        fprintf(_coverage_fout, "6976\n");
        fflush(_coverage_fout);
        tif->tif_subifdoff += 4ULL;
      } else {
        fprintf(_coverage_fout, "6977\n");
        fflush(_coverage_fout);
        tif->tif_flags &= 4294959103U;
      }
      fprintf(_coverage_fout, "6985\n");
      fflush(_coverage_fout);
      return (1);
    } else {
      fprintf(_coverage_fout, "6993\n");
      fflush(_coverage_fout);
      m___0 = tif->tif_diroff;
      fprintf(_coverage_fout, "6994\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "6986\n");
        fflush(_coverage_fout);
        TIFFSwabLong8(& m___0);
      } else {
        fprintf(_coverage_fout, "6987\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "6995\n");
      fflush(_coverage_fout);
      (*(tif->tif_seekproc))(tif->tif_clientdata, tif->tif_subifdoff, 0);
      fprintf(_coverage_fout, "6996\n");
      fflush(_coverage_fout);
      tmp___1 = (*(tif->tif_writeproc))(tif->tif_clientdata, (void *)(& m___0),
                                        8L);
      fprintf(_coverage_fout, "6997\n");
      fflush(_coverage_fout);
      if (tmp___1 == 8L) {
        fprintf(_coverage_fout, "6988\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "6989\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error writing SubIFD directory link");
        fprintf(_coverage_fout, "6990\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "6998\n");
      fflush(_coverage_fout);
      tif->tif_nsubifd = (uint16 )((int )tif->tif_nsubifd - 1);
      fprintf(_coverage_fout, "6999\n");
      fflush(_coverage_fout);
      if (tif->tif_nsubifd) {
        fprintf(_coverage_fout, "6991\n");
        fflush(_coverage_fout);
        tif->tif_subifdoff += 8ULL;
      } else {
        fprintf(_coverage_fout, "6992\n");
        fflush(_coverage_fout);
        tif->tif_flags &= 4294959103U;
      }
      fprintf(_coverage_fout, "7000\n");
      fflush(_coverage_fout);
      return (1);
    }
  } else {
    fprintf(_coverage_fout, "7002\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7103\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "7044\n");
    fflush(_coverage_fout);
    m___1 = (unsigned int )tif->tif_diroff;
    fprintf(_coverage_fout, "7045\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "7003\n");
      fflush(_coverage_fout);
      TIFFSwabLong(& m___1);
    } else {
      fprintf(_coverage_fout, "7004\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "7046\n");
    fflush(_coverage_fout);
    if (tif->tif_header.classic.tiff_diroff == 0U) {
      fprintf(_coverage_fout, "7008\n");
      fflush(_coverage_fout);
      tif->tif_header.classic.tiff_diroff = (unsigned int )tif->tif_diroff;
      fprintf(_coverage_fout, "7009\n");
      fflush(_coverage_fout);
      (*(tif->tif_seekproc))(tif->tif_clientdata, 4ULL, 0);
      fprintf(_coverage_fout, "7010\n");
      fflush(_coverage_fout);
      tmp___2 = (*(tif->tif_writeproc))(tif->tif_clientdata, (void *)(& m___1),
                                        4L);
      fprintf(_coverage_fout, "7011\n");
      fflush(_coverage_fout);
      if (tmp___2 == 4L) {
        fprintf(_coverage_fout, "7005\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "7006\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                     "Error writing TIFF header");
        fprintf(_coverage_fout, "7007\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "7012\n");
      fflush(_coverage_fout);
      return (1);
    } else {
      fprintf(_coverage_fout, "7013\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "7047\n");
    fflush(_coverage_fout);
    nextdir = tif->tif_header.classic.tiff_diroff;
    fprintf(_coverage_fout, "7048\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "7035\n");
      fflush(_coverage_fout);
      tmp___3 = (*(tif->tif_seekproc))(tif->tif_clientdata,
                                       (unsigned long long )nextdir, 0);
      fprintf(_coverage_fout, "7036\n");
      fflush(_coverage_fout);
      if (tmp___3 == (uint64 )nextdir) {
        fprintf(_coverage_fout, "7017\n");
        fflush(_coverage_fout);
        tmp___4 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                         (void *)(& dircount), 2L);
        fprintf(_coverage_fout, "7018\n");
        fflush(_coverage_fout);
        if (tmp___4 == 2L) {
          fprintf(_coverage_fout, "7014\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "7015\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___17,
                       "Error fetching directory count");
          fprintf(_coverage_fout, "7016\n");
          fflush(_coverage_fout);
          return (0);
        }
      } else {
        fprintf(_coverage_fout, "7019\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error fetching directory count");
        fprintf(_coverage_fout, "7020\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "7037\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "7021\n");
        fflush(_coverage_fout);
        TIFFSwabShort(& dircount);
      } else {
        fprintf(_coverage_fout, "7022\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "7038\n");
      fflush(_coverage_fout);
      (*(tif->tif_seekproc))(tif->tif_clientdata,
                             (unsigned long long )((nextdir + 2U) + (uint32 )((int )dircount * 12)),
                             0);
      fprintf(_coverage_fout, "7039\n");
      fflush(_coverage_fout);
      tmp___5 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                       (void *)(& nextnextdir), 4L);
      fprintf(_coverage_fout, "7040\n");
      fflush(_coverage_fout);
      if (tmp___5 == 4L) {
        fprintf(_coverage_fout, "7023\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "7024\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error fetching directory link");
        fprintf(_coverage_fout, "7025\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "7041\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "7026\n");
        fflush(_coverage_fout);
        TIFFSwabLong(& nextnextdir);
      } else {
        fprintf(_coverage_fout, "7027\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "7042\n");
      fflush(_coverage_fout);
      if (nextnextdir == 0U) {
        fprintf(_coverage_fout, "7031\n");
        fflush(_coverage_fout);
        (*(tif->tif_seekproc))(tif->tif_clientdata,
                               (unsigned long long )((nextdir + 2U) + (uint32 )((int )dircount * 12)),
                               0);
        fprintf(_coverage_fout, "7032\n");
        fflush(_coverage_fout);
        tmp___6 = (*(tif->tif_writeproc))(tif->tif_clientdata,
                                          (void *)(& m___1), 4L);
        fprintf(_coverage_fout, "7033\n");
        fflush(_coverage_fout);
        if (tmp___6 == 4L) {
          fprintf(_coverage_fout, "7028\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "7029\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___17,
                       "Error writing directory link");
          fprintf(_coverage_fout, "7030\n");
          fflush(_coverage_fout);
          return (0);
        }
        break;
      } else {
        fprintf(_coverage_fout, "7034\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "7043\n");
      fflush(_coverage_fout);
      nextdir = nextnextdir;
    }
  } else {
    fprintf(_coverage_fout, "7095\n");
    fflush(_coverage_fout);
    m___2 = tif->tif_diroff;
    fprintf(_coverage_fout, "7096\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "7049\n");
      fflush(_coverage_fout);
      TIFFSwabLong8(& m___2);
    } else {
      fprintf(_coverage_fout, "7050\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "7097\n");
    fflush(_coverage_fout);
    if (tif->tif_header.big.tiff_diroff == 0ULL) {
      fprintf(_coverage_fout, "7054\n");
      fflush(_coverage_fout);
      tif->tif_header.big.tiff_diroff = tif->tif_diroff;
      fprintf(_coverage_fout, "7055\n");
      fflush(_coverage_fout);
      (*(tif->tif_seekproc))(tif->tif_clientdata, 8ULL, 0);
      fprintf(_coverage_fout, "7056\n");
      fflush(_coverage_fout);
      tmp___7 = (*(tif->tif_writeproc))(tif->tif_clientdata, (void *)(& m___2),
                                        8L);
      fprintf(_coverage_fout, "7057\n");
      fflush(_coverage_fout);
      if (tmp___7 == 8L) {
        fprintf(_coverage_fout, "7051\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "7052\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                     "Error writing TIFF header");
        fprintf(_coverage_fout, "7053\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "7058\n");
      fflush(_coverage_fout);
      return (1);
    } else {
      fprintf(_coverage_fout, "7059\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "7098\n");
    fflush(_coverage_fout);
    nextdir___0 = tif->tif_header.big.tiff_diroff;
    fprintf(_coverage_fout, "7099\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "7084\n");
      fflush(_coverage_fout);
      tmp___8 = (*(tif->tif_seekproc))(tif->tif_clientdata, nextdir___0, 0);
      fprintf(_coverage_fout, "7085\n");
      fflush(_coverage_fout);
      if (tmp___8 == nextdir___0) {
        fprintf(_coverage_fout, "7063\n");
        fflush(_coverage_fout);
        tmp___9 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                         (void *)(& dircount64), 8L);
        fprintf(_coverage_fout, "7064\n");
        fflush(_coverage_fout);
        if (tmp___9 == 8L) {
          fprintf(_coverage_fout, "7060\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "7061\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___17,
                       "Error fetching directory count");
          fprintf(_coverage_fout, "7062\n");
          fflush(_coverage_fout);
          return (0);
        }
      } else {
        fprintf(_coverage_fout, "7065\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error fetching directory count");
        fprintf(_coverage_fout, "7066\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "7086\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "7067\n");
        fflush(_coverage_fout);
        TIFFSwabLong8(& dircount64);
      } else {
        fprintf(_coverage_fout, "7068\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "7087\n");
      fflush(_coverage_fout);
      if (dircount64 > 65535ULL) {
        fprintf(_coverage_fout, "7069\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Sanity check on tag count failed, likely corrupt TIFF");
        fprintf(_coverage_fout, "7070\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "7071\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "7088\n");
      fflush(_coverage_fout);
      dircount___0 = (unsigned short )dircount64;
      fprintf(_coverage_fout, "7089\n");
      fflush(_coverage_fout);
      (*(tif->tif_seekproc))(tif->tif_clientdata,
                             (nextdir___0 + 8ULL) + (uint64 )((int )dircount___0 * 20),
                             0);
      fprintf(_coverage_fout, "7090\n");
      fflush(_coverage_fout);
      tmp___10 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                        (void *)(& nextnextdir___0), 8L);
      fprintf(_coverage_fout, "7091\n");
      fflush(_coverage_fout);
      if (tmp___10 == 8L) {
        fprintf(_coverage_fout, "7072\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "7073\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error fetching directory link");
        fprintf(_coverage_fout, "7074\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "7092\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "7075\n");
        fflush(_coverage_fout);
        TIFFSwabLong8(& nextnextdir___0);
      } else {
        fprintf(_coverage_fout, "7076\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "7093\n");
      fflush(_coverage_fout);
      if (nextnextdir___0 == 0ULL) {
        fprintf(_coverage_fout, "7080\n");
        fflush(_coverage_fout);
        (*(tif->tif_seekproc))(tif->tif_clientdata,
                               (nextdir___0 + 8ULL) + (uint64 )((int )dircount___0 * 20),
                               0);
        fprintf(_coverage_fout, "7081\n");
        fflush(_coverage_fout);
        tmp___11 = (*(tif->tif_writeproc))(tif->tif_clientdata,
                                           (void *)(& m___2), 8L);
        fprintf(_coverage_fout, "7082\n");
        fflush(_coverage_fout);
        if (tmp___11 == 8L) {
          fprintf(_coverage_fout, "7077\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "7078\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___17,
                       "Error writing directory link");
          fprintf(_coverage_fout, "7079\n");
          fflush(_coverage_fout);
          return (0);
        }
        break;
      } else {
        fprintf(_coverage_fout, "7083\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "7094\n");
      fflush(_coverage_fout);
      nextdir___0 = nextnextdir___0;
    }
  }
  fprintf(_coverage_fout, "7104\n");
  fflush(_coverage_fout);
  return (1);
}
}
