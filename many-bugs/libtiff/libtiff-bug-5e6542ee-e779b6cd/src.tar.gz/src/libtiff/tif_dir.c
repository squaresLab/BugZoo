void *_coverage_fout ;
typedef unsigned char __u_char;
typedef unsigned short __u_short;
typedef unsigned int __u_int;
typedef unsigned long __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;
typedef long long __quad_t;
typedef unsigned long long __u_quad_t;
typedef __u_quad_t __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef __u_quad_t __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long __off_t;
typedef __quad_t __off64_t;
typedef int __pid_t;
struct __anonstruct___fsid_t_1 {
   int __val[2] ;
};
typedef struct __anonstruct___fsid_t_1 __fsid_t;
typedef long __clock_t;
typedef unsigned long __rlim_t;
typedef __u_quad_t __rlim64_t;
typedef unsigned int __id_t;
typedef long __time_t;
typedef unsigned int __useconds_t;
typedef long __suseconds_t;
typedef int __daddr_t;
typedef long __swblk_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void *__timer_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef __quad_t __blkcnt64_t;
typedef unsigned long __fsblkcnt_t;
typedef __u_quad_t __fsblkcnt64_t;
typedef unsigned long __fsfilcnt_t;
typedef __u_quad_t __fsfilcnt64_t;
typedef int __ssize_t;
typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;
typedef int __intptr_t;
typedef unsigned int __socklen_t;
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;
typedef __loff_t loff_t;
typedef __ino64_t ino_t;
typedef __dev_t dev_t;
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __nlink_t nlink_t;
typedef __uid_t uid_t;
typedef __off64_t off_t;
typedef __pid_t pid_t;
typedef __id_t id_t;
typedef __ssize_t ssize_t;
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;
typedef __key_t key_t;
typedef __clock_t clock_t;
typedef __time_t time_t;
typedef __clockid_t clockid_t;
typedef __timer_t timer_t;
typedef unsigned int size_t;
typedef unsigned long ulong;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char u_int8_t;
typedef unsigned short u_int16_t;
typedef unsigned int u_int32_t;
typedef unsigned long long u_int64_t;
typedef int register_t;
typedef int __sig_atomic_t;
struct __anonstruct___sigset_t_2 {
   unsigned long __val[1024U / (8U * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_2 __sigset_t;
typedef __sigset_t sigset_t;
struct timespec {
   __time_t tv_sec ;
   long tv_nsec ;
};
struct timeval {
   __time_t tv_sec ;
   __suseconds_t tv_usec ;
};
typedef __suseconds_t suseconds_t;
typedef long __fd_mask;
struct __anonstruct_fd_set_3 {
   __fd_mask __fds_bits[1024 / (8 * (int )sizeof(__fd_mask ))] ;
};
typedef struct __anonstruct_fd_set_3 fd_set;
typedef __fd_mask fd_mask;
typedef __blksize_t blksize_t;
typedef __blkcnt64_t blkcnt_t;
typedef __fsblkcnt64_t fsblkcnt_t;
typedef __fsfilcnt64_t fsfilcnt_t;
typedef unsigned long pthread_t;
union __anonunion_pthread_attr_t_4 {
   char __size[36] ;
   long __align ;
};
typedef union __anonunion_pthread_attr_t_4 pthread_attr_t;
struct __pthread_internal_slist {
   struct __pthread_internal_slist *__next ;
};
typedef struct __pthread_internal_slist __pthread_slist_t;
union __anonunion____missing_field_name_6 {
   int __spins ;
   __pthread_slist_t __list ;
};
struct __pthread_mutex_s {
   int __lock ;
   unsigned int __count ;
   int __owner ;
   int __kind ;
   unsigned int __nusers ;
   union __anonunion____missing_field_name_6 __annonCompField1 ;
};
union __anonunion_pthread_mutex_t_5 {
   struct __pthread_mutex_s __data ;
   char __size[24] ;
   long __align ;
};
typedef union __anonunion_pthread_mutex_t_5 pthread_mutex_t;
union __anonunion_pthread_mutexattr_t_7 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_mutexattr_t_7 pthread_mutexattr_t;
struct __anonstruct___data_9 {
   int __lock ;
   unsigned int __futex ;
   unsigned long long __total_seq ;
   unsigned long long __wakeup_seq ;
   unsigned long long __woken_seq ;
   void *__mutex ;
   unsigned int __nwaiters ;
   unsigned int __broadcast_seq ;
};
union __anonunion_pthread_cond_t_8 {
   struct __anonstruct___data_9 __data ;
   char __size[48] ;
   long long __align ;
};
typedef union __anonunion_pthread_cond_t_8 pthread_cond_t;
union __anonunion_pthread_condattr_t_10 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_condattr_t_10 pthread_condattr_t;
typedef unsigned int pthread_key_t;
typedef int pthread_once_t;
struct __anonstruct___data_12 {
   int __lock ;
   unsigned int __nr_readers ;
   unsigned int __readers_wakeup ;
   unsigned int __writer_wakeup ;
   unsigned int __nr_readers_queued ;
   unsigned int __nr_writers_queued ;
   unsigned char __flags ;
   unsigned char __shared ;
   unsigned char __pad1 ;
   unsigned char __pad2 ;
   int __writer ;
};
union __anonunion_pthread_rwlock_t_11 {
   struct __anonstruct___data_12 __data ;
   char __size[32] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlock_t_11 pthread_rwlock_t;
union __anonunion_pthread_rwlockattr_t_13 {
   char __size[8] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlockattr_t_13 pthread_rwlockattr_t;
typedef int volatile   pthread_spinlock_t;
union __anonunion_pthread_barrier_t_14 {
   char __size[20] ;
   long __align ;
};
typedef union __anonunion_pthread_barrier_t_14 pthread_barrier_t;
union __anonunion_pthread_barrierattr_t_15 {
   char __size[4] ;
   int __align ;
};
typedef union __anonunion_pthread_barrierattr_t_15 pthread_barrierattr_t;
struct flock {
   short l_type ;
   short l_whence ;
   __off64_t l_start ;
   __off64_t l_len ;
   __pid_t l_pid ;
};
struct stat {
   __dev_t st_dev ;
   unsigned short __pad1 ;
   __ino_t __st_ino ;
   __mode_t st_mode ;
   __nlink_t st_nlink ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   __dev_t st_rdev ;
   unsigned short __pad2 ;
   __off64_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt64_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __ino64_t st_ino ;
};
struct __locale_data;
struct __locale_struct {
   struct __locale_data *__locales[13] ;
   unsigned short const   *__ctype_b ;
   int const   *__ctype_tolower ;
   int const   *__ctype_toupper ;
   char const   *__names[13] ;
};
typedef struct __locale_struct *__locale_t;
typedef __locale_t locale_t;
typedef int (*__compar_fn_t)(void const   * , void const   * );
enum __anonenum_ACTION_16 {
    FIND = 0,
    ENTER = 1
} ;
typedef enum __anonenum_ACTION_16 ACTION;
struct entry {
   char *key ;
   void *data ;
};
typedef struct entry ENTRY;
struct _ENTRY;
struct _ENTRY;
enum __anonenum_VISIT_17 {
    preorder = 0,
    postorder = 1,
    endorder = 2,
    leaf = 3
} ;
typedef enum __anonenum_VISIT_17 VISIT;
typedef void (*__action_fn_t)(void const   *__nodep , VISIT __value ,
                              int __level );
typedef signed char int8;
typedef unsigned char uint8;
typedef short int16;
typedef unsigned short uint16;
typedef int int32;
typedef unsigned int uint32;
typedef long long int64;
typedef unsigned long long uint64;
typedef int uint16_vap;
struct __anonstruct_TIFFHeaderCommon_18 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
};
typedef struct __anonstruct_TIFFHeaderCommon_18 TIFFHeaderCommon;
struct __anonstruct_TIFFHeaderClassic_19 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint32 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderClassic_19 TIFFHeaderClassic;
struct __anonstruct_TIFFHeaderBig_20 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint16 tiff_offsetsize ;
   uint16 tiff_unused ;
   uint64 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderBig_20 TIFFHeaderBig;
enum __anonenum_TIFFDataType_21 {
    TIFF_NOTYPE = 0,
    TIFF_BYTE = 1,
    TIFF_ASCII = 2,
    TIFF_SHORT = 3,
    TIFF_LONG = 4,
    TIFF_RATIONAL = 5,
    TIFF_SBYTE = 6,
    TIFF_UNDEFINED = 7,
    TIFF_SSHORT = 8,
    TIFF_SLONG = 9,
    TIFF_SRATIONAL = 10,
    TIFF_FLOAT = 11,
    TIFF_DOUBLE = 12,
    TIFF_IFD = 13,
    TIFF_LONG8 = 16,
    TIFF_SLONG8 = 17,
    TIFF_IFD8 = 18
} ;
typedef enum __anonenum_TIFFDataType_21 TIFFDataType;
struct tiff;
typedef struct tiff TIFF;
typedef long tmsize_t;
typedef uint32 ttag_t;
typedef uint16 tdir_t;
typedef uint16 tsample_t;
typedef uint32 tstrile_t;
typedef tstrile_t tstrip_t;
typedef tstrile_t ttile_t;
typedef tmsize_t tsize_t;
typedef void *tdata_t;
typedef uint64 toff_t;
typedef void *thandle_t;
typedef unsigned char TIFFRGBValue;
struct __anonstruct_TIFFDisplay_22 {
   float d_mat[3][3] ;
   float d_YCR ;
   float d_YCG ;
   float d_YCB ;
   uint32 d_Vrwr ;
   uint32 d_Vrwg ;
   uint32 d_Vrwb ;
   float d_Y0R ;
   float d_Y0G ;
   float d_Y0B ;
   float d_gammaR ;
   float d_gammaG ;
   float d_gammaB ;
};
typedef struct __anonstruct_TIFFDisplay_22 TIFFDisplay;
struct __anonstruct_TIFFYCbCrToRGB_23 {
   TIFFRGBValue *clamptab ;
   int *Cr_r_tab ;
   int *Cb_b_tab ;
   int32 *Cr_g_tab ;
   int32 *Cb_g_tab ;
   int32 *Y_tab ;
};
typedef struct __anonstruct_TIFFYCbCrToRGB_23 TIFFYCbCrToRGB;
struct __anonstruct_TIFFCIELabToRGB_24 {
   int range ;
   float rstep ;
   float gstep ;
   float bstep ;
   float X0 ;
   float Y0 ;
   float Z0 ;
   TIFFDisplay display ;
   float Yr2r[1501] ;
   float Yg2g[1501] ;
   float Yb2b[1501] ;
};
typedef struct __anonstruct_TIFFCIELabToRGB_24 TIFFCIELabToRGB;
struct _TIFFRGBAImage;
typedef struct _TIFFRGBAImage TIFFRGBAImage;
typedef void (*tileContigRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                  uint32  , uint32  , uint32  , int32  ,
                                  int32  , unsigned char * );
typedef void (*tileSeparateRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                    uint32  , uint32  , uint32  , int32  ,
                                    int32  , unsigned char * , unsigned char * ,
                                    unsigned char * , unsigned char * );
union __anonunion_put_25 {
   void (*any)(TIFFRGBAImage * ) ;
   void (*contig)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                  uint32  , int32  , int32  , unsigned char * ) ;
   void (*separate)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                    uint32  , int32  , int32  , unsigned char * ,
                    unsigned char * , unsigned char * , unsigned char * ) ;
};
struct _TIFFRGBAImage {
   TIFF *tif ;
   int stoponerr ;
   int isContig ;
   int alpha ;
   uint32 width ;
   uint32 height ;
   uint16 bitspersample ;
   uint16 samplesperpixel ;
   uint16 orientation ;
   uint16 req_orientation ;
   uint16 photometric ;
   uint16 *redcmap ;
   uint16 *greencmap ;
   uint16 *bluecmap ;
   int (*get)(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
   union __anonunion_put_25 put ;
   TIFFRGBValue *Map ;
   uint32 **BWmap ;
   uint32 **PALmap ;
   TIFFYCbCrToRGB *ycbcr ;
   TIFFCIELabToRGB *cielab ;
   uint8 *UaToAa ;
   uint8 *Bitdepth16To8 ;
   int row_offset ;
   int col_offset ;
};
typedef int (*TIFFInitMethod)(TIFF * , int  );
struct __anonstruct_TIFFCodec_26 {
   char *name ;
   uint16 scheme ;
   int (*init)(TIFF * , int  ) ;
};
typedef struct __anonstruct_TIFFCodec_26 TIFFCodec;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_28 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_27 {
   int __count ;
   union __anonunion___value_28 __value ;
};
typedef struct __anonstruct___mbstate_t_27 __mbstate_t;
struct __anonstruct__G_fpos_t_29 {
   __off_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos_t_29 _G_fpos_t;
struct __anonstruct__G_fpos64_t_30 {
   __off64_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos64_t_30 _G_fpos64_t;
typedef short _G_int16_t;
typedef int _G_int32_t;
typedef unsigned short _G_uint16_t;
typedef unsigned int _G_uint32_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_jump_t;
struct _IO_jump_t;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
enum __codecvt_result {
    __codecvt_ok = 0,
    __codecvt_partial = 1,
    __codecvt_error = 2,
    __codecvt_noconv = 3
} ;
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15U * sizeof(int ) - 4U * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
struct _IO_FILE_plus;
struct _IO_FILE_plus;
typedef __ssize_t __io_read_fn(void *__cookie , char *__buf , size_t __nbytes );
typedef __ssize_t __io_write_fn(void *__cookie , char const   *__buf ,
                                size_t __n );
typedef int __io_seek_fn(void *__cookie , __off64_t *__pos , int __w );
typedef int __io_close_fn(void *__cookie );
typedef __gnuc_va_list va_list;
typedef _G_fpos64_t fpos_t;
typedef void (*TIFFErrorHandler)(char const   * , char const   * , va_list  );
typedef void (*TIFFErrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  );
typedef tmsize_t (*TIFFReadWriteProc)(thandle_t  , void * , tmsize_t  );
typedef uint64 (*TIFFSeekProc)(thandle_t  , uint64  , int  );
typedef int (*TIFFCloseProc)(thandle_t  );
typedef uint64 (*TIFFSizeProc)(thandle_t  );
typedef int (*TIFFMapFileProc)(thandle_t  , void **base , toff_t *size );
typedef void (*TIFFUnmapFileProc)(thandle_t  , void *base , toff_t size );
typedef void (*TIFFExtendProc)(TIFF * );
struct _TIFFField;
typedef struct _TIFFField TIFFField;
struct _TIFFFieldArray;
typedef struct _TIFFFieldArray TIFFFieldArray;
typedef int (*TIFFVSetMethod)(TIFF * , uint32  , va_list  );
typedef int (*TIFFVGetMethod)(TIFF * , uint32  , va_list  );
typedef void (*TIFFPrintMethod)(TIFF * , FILE * , long  );
struct __anonstruct_TIFFTagMethods_31 {
   int (*vsetfield)(TIFF * , uint32  , va_list  ) ;
   int (*vgetfield)(TIFF * , uint32  , va_list  ) ;
   void (*printdir)(TIFF * , FILE * , long  ) ;
};
typedef struct __anonstruct_TIFFTagMethods_31 TIFFTagMethods;
struct __anonstruct_TIFFFieldInfo_32 {
   ttag_t field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
};
typedef struct __anonstruct_TIFFFieldInfo_32 TIFFFieldInfo;
struct __anonstruct_TIFFTagValue_33 {
   TIFFField const   *info ;
   int count ;
   void *value ;
};
typedef struct __anonstruct_TIFFTagValue_33 TIFFTagValue;
struct __anonstruct_TIFFDirectory_34 {
   unsigned long td_fieldsset[4] ;
   uint32 td_imagewidth ;
   uint32 td_imagelength ;
   uint32 td_imagedepth ;
   uint32 td_tilewidth ;
   uint32 td_tilelength ;
   uint32 td_tiledepth ;
   uint32 td_subfiletype ;
   uint16 td_bitspersample ;
   uint16 td_sampleformat ;
   uint16 td_compression ;
   uint16 td_photometric ;
   uint16 td_threshholding ;
   uint16 td_fillorder ;
   uint16 td_orientation ;
   uint16 td_samplesperpixel ;
   uint32 td_rowsperstrip ;
   uint16 td_minsamplevalue ;
   uint16 td_maxsamplevalue ;
   double td_sminsamplevalue ;
   double td_smaxsamplevalue ;
   float td_xresolution ;
   float td_yresolution ;
   uint16 td_resolutionunit ;
   uint16 td_planarconfig ;
   float td_xposition ;
   float td_yposition ;
   uint16 td_pagenumber[2] ;
   uint16 *td_colormap[3] ;
   uint16 td_halftonehints[2] ;
   uint16 td_extrasamples ;
   uint16 *td_sampleinfo ;
   uint32 td_stripsperimage ;
   uint32 td_nstrips ;
   uint64 *td_stripoffset ;
   uint64 *td_stripbytecount ;
   int td_stripbytecountsorted ;
   uint16 td_nsubifd ;
   uint64 *td_subifd ;
   uint16 td_ycbcrsubsampling[2] ;
   uint16 td_ycbcrpositioning ;
   uint16 *td_transferfunction[3] ;
   int td_inknameslen ;
   char *td_inknames ;
   int td_customValueCount ;
   TIFFTagValue *td_customValues ;
};
typedef struct __anonstruct_TIFFDirectory_34 TIFFDirectory;
enum __anonenum_TIFFSetGetFieldType_35 {
    TIFF_SETGET_UNDEFINED = 0,
    TIFF_SETGET_ASCII = 1,
    TIFF_SETGET_UINT8 = 2,
    TIFF_SETGET_SINT8 = 3,
    TIFF_SETGET_UINT16 = 4,
    TIFF_SETGET_SINT16 = 5,
    TIFF_SETGET_UINT32 = 6,
    TIFF_SETGET_SINT32 = 7,
    TIFF_SETGET_UINT64 = 8,
    TIFF_SETGET_SINT64 = 9,
    TIFF_SETGET_FLOAT = 10,
    TIFF_SETGET_DOUBLE = 11,
    TIFF_SETGET_IFD8 = 12,
    TIFF_SETGET_INT = 13,
    TIFF_SETGET_UINT16_PAIR = 14,
    TIFF_SETGET_C0_ASCII = 15,
    TIFF_SETGET_C0_UINT8 = 16,
    TIFF_SETGET_C0_SINT8 = 17,
    TIFF_SETGET_C0_UINT16 = 18,
    TIFF_SETGET_C0_SINT16 = 19,
    TIFF_SETGET_C0_UINT32 = 20,
    TIFF_SETGET_C0_SINT32 = 21,
    TIFF_SETGET_C0_UINT64 = 22,
    TIFF_SETGET_C0_SINT64 = 23,
    TIFF_SETGET_C0_FLOAT = 24,
    TIFF_SETGET_C0_DOUBLE = 25,
    TIFF_SETGET_C0_IFD8 = 26,
    TIFF_SETGET_C16_ASCII = 27,
    TIFF_SETGET_C16_UINT8 = 28,
    TIFF_SETGET_C16_SINT8 = 29,
    TIFF_SETGET_C16_UINT16 = 30,
    TIFF_SETGET_C16_SINT16 = 31,
    TIFF_SETGET_C16_UINT32 = 32,
    TIFF_SETGET_C16_SINT32 = 33,
    TIFF_SETGET_C16_UINT64 = 34,
    TIFF_SETGET_C16_SINT64 = 35,
    TIFF_SETGET_C16_FLOAT = 36,
    TIFF_SETGET_C16_DOUBLE = 37,
    TIFF_SETGET_C16_IFD8 = 38,
    TIFF_SETGET_C32_ASCII = 39,
    TIFF_SETGET_C32_UINT8 = 40,
    TIFF_SETGET_C32_SINT8 = 41,
    TIFF_SETGET_C32_UINT16 = 42,
    TIFF_SETGET_C32_SINT16 = 43,
    TIFF_SETGET_C32_UINT32 = 44,
    TIFF_SETGET_C32_SINT32 = 45,
    TIFF_SETGET_C32_UINT64 = 46,
    TIFF_SETGET_C32_SINT64 = 47,
    TIFF_SETGET_C32_FLOAT = 48,
    TIFF_SETGET_C32_DOUBLE = 49,
    TIFF_SETGET_C32_IFD8 = 50,
    TIFF_SETGET_OTHER = 51
} ;
typedef enum __anonenum_TIFFSetGetFieldType_35 TIFFSetGetFieldType;
enum __anonenum_TIFFFieldArrayType_36 {
    tfiatImage = 0,
    tfiatExif = 1,
    tfiatOther = 2
} ;
typedef enum __anonenum_TIFFFieldArrayType_36 TIFFFieldArrayType;
struct _TIFFFieldArray {
   TIFFFieldArrayType type ;
   uint32 allocated_size ;
   uint32 count ;
   TIFFField *fields ;
};
struct _TIFFField {
   uint32 field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   uint32 reserved ;
   TIFFSetGetFieldType set_field_type ;
   TIFFSetGetFieldType get_field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
   TIFFFieldArray *field_subfields ;
};
struct __anonstruct_TIFFDirEntry_37 {
   uint16 tdir_tag ;
   uint16 tdir_type ;
   uint64 tdir_count ;
   uint64 tdir_offset ;
};
typedef struct __anonstruct_TIFFDirEntry_37 TIFFDirEntry;
struct client_info {
   struct client_info *next ;
   void *data ;
   char *name ;
};
typedef struct client_info TIFFClientInfoLink;
typedef unsigned char tidataval_t;
typedef tidataval_t *tidata_t;
typedef void (*TIFFVoidMethod)(TIFF * );
typedef int (*TIFFBoolMethod)(TIFF * );
typedef int (*TIFFPreMethod)(TIFF * , uint16  );
typedef int (*TIFFCodeMethod)(TIFF *tif , uint8 *buf , tmsize_t size ,
                              uint16 sample );
typedef int (*TIFFSeekMethod)(TIFF * , uint32  );
typedef void (*TIFFPostMethod)(TIFF *tif , uint8 *buf , tmsize_t size );
typedef uint32 (*TIFFStripMethod)(TIFF * , uint32  );
typedef void (*TIFFTileMethod)(TIFF * , uint32 * , uint32 * );
union __anonunion_tif_header_38 {
   TIFFHeaderCommon common ;
   TIFFHeaderClassic classic ;
   TIFFHeaderBig big ;
};
struct tiff {
   char *tif_name ;
   int tif_fd ;
   int tif_mode ;
   uint32 tif_flags ;
   uint64 tif_diroff ;
   uint64 tif_nextdiroff ;
   uint64 *tif_dirlist ;
   uint16 tif_dirlistsize ;
   uint16 tif_dirnumber ;
   TIFFDirectory tif_dir ;
   TIFFDirectory tif_customdir ;
   union __anonunion_tif_header_38 tif_header ;
   uint16 tif_header_size ;
   uint32 tif_row ;
   uint16 tif_curdir ;
   uint32 tif_curstrip ;
   uint64 tif_curoff ;
   uint64 tif_dataoff ;
   uint16 tif_nsubifd ;
   uint64 tif_subifdoff ;
   uint32 tif_col ;
   uint32 tif_curtile ;
   tmsize_t tif_tilesize ;
   int tif_decodestatus ;
   int (*tif_fixuptags)(TIFF * ) ;
   int (*tif_setupdecode)(TIFF * ) ;
   int (*tif_predecode)(TIFF * , uint16  ) ;
   int (*tif_setupencode)(TIFF * ) ;
   int tif_encodestatus ;
   int (*tif_preencode)(TIFF * , uint16  ) ;
   int (*tif_postencode)(TIFF * ) ;
   int (*tif_decoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_decodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_encodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_decodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   void (*tif_close)(TIFF * ) ;
   int (*tif_seek)(TIFF * , uint32  ) ;
   void (*tif_cleanup)(TIFF * ) ;
   uint32 (*tif_defstripsize)(TIFF * , uint32  ) ;
   void (*tif_deftilesize)(TIFF * , uint32 * , uint32 * ) ;
   uint8 *tif_data ;
   tmsize_t tif_scanlinesize ;
   tmsize_t tif_scanlineskew ;
   uint8 *tif_rawdata ;
   tmsize_t tif_rawdatasize ;
   uint8 *tif_rawcp ;
   tmsize_t tif_rawcc ;
   uint8 *tif_base ;
   tmsize_t tif_size ;
   int (*tif_mapproc)(thandle_t  , void **base , toff_t *size ) ;
   void (*tif_unmapproc)(thandle_t  , void *base , toff_t size ) ;
   thandle_t tif_clientdata ;
   tmsize_t (*tif_readproc)(thandle_t  , void * , tmsize_t  ) ;
   tmsize_t (*tif_writeproc)(thandle_t  , void * , tmsize_t  ) ;
   uint64 (*tif_seekproc)(thandle_t  , uint64  , int  ) ;
   int (*tif_closeproc)(thandle_t  ) ;
   uint64 (*tif_sizeproc)(thandle_t  ) ;
   void (*tif_postdecode)(TIFF *tif , uint8 *buf , tmsize_t size ) ;
   TIFFField **tif_fields ;
   uint32 tif_nfields ;
   TIFFField const   *tif_foundfield ;
   TIFFTagMethods tif_tagmethods ;
   TIFFClientInfoLink *tif_clientinfo ;
   TIFFFieldArray *tif_fieldscompat ;
   uint32 tif_nfieldscompat ;
};
extern int select(int __nfds , fd_set * __restrict  __readfds ,
                  fd_set * __restrict  __writefds ,
                  fd_set * __restrict  __exceptfds ,
                  struct timeval * __restrict  __timeout ) ;
extern int pselect(int __nfds , fd_set * __restrict  __readfds ,
                   fd_set * __restrict  __writefds ,
                   fd_set * __restrict  __exceptfds ,
                   struct timespec  const  * __restrict  __timeout ,
                   __sigset_t const   * __restrict  __sigmask ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_major(unsigned long long __dev ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1\n");
  fflush(_coverage_fout);
  return ((unsigned int )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_minor(unsigned long long __dev ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2\n");
  fflush(_coverage_fout);
  return ((unsigned int )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                   unsigned int __minor ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3\n");
  fflush(_coverage_fout);
  return (((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32));
}
}
extern int fcntl(int __fd , int __cmd  , ...) ;
extern int open(char const   *__file , int __oflag  , ...)  __asm__("open64") __attribute__((__nonnull__(1))) ;
extern int openat(int __fd , char const   *__file , int __oflag  , ...)  __asm__("openat64") __attribute__((__nonnull__(2))) ;
extern int creat(char const   *__file , __mode_t __mode )  __asm__("creat64") __attribute__((__nonnull__(1))) ;
extern int lockf(int __fd , int __cmd , __off64_t __len )  __asm__("lockf64")  ;
extern  __attribute__((__nothrow__)) int posix_fadvise(int __fd ,
                                                       __off64_t __offset ,
                                                       __off64_t __len ,
                                                       int __advise )  __asm__("posix_fadvise64")  ;
extern int posix_fallocate(int __fd , __off64_t __offset , __off64_t __len )  __asm__("posix_fallocate64")  ;
extern  __attribute__((__nothrow__)) void *memcpy(void * __restrict  __dest ,
                                                  void const   * __restrict  __src ,
                                                  size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memmove(void *__dest ,
                                                   void const   *__src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memccpy(void * __restrict  __dest ,
                                                   void const   * __restrict  __src ,
                                                   int __c , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memset(void *__s , int __c ,
                                                  size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int memcmp(void const   *__s1 ,
                                                void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memchr(void const   *__s , int __c ,
                                                  size_t __n )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strcat(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncat(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcmp(char const   *__s1 ,
                                                char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncmp(char const   *__s1 ,
                                                 char const   *__s2 ,
                                                 size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcoll(char const   *__s1 ,
                                                 char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm(char * __restrict  __dest ,
                                                    char const   * __restrict  __src ,
                                                    size_t __n )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int strcoll_l(char const   *__s1 ,
                                                   char const   *__s2 ,
                                                   __locale_t __l )  __attribute__((__pure__,
__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm_l(char *__dest ,
                                                      char const   *__src ,
                                                      size_t __n ,
                                                      __locale_t __l )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) char *strdup(char const   *__s )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strndup(char const   *__string ,
                                                   size_t __n )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strrchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strcspn(char const   *__s ,
                                                    char const   *__reject )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strspn(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strpbrk(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strstr(char const   *__haystack ,
                                                  char const   *__needle )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strtok(char * __restrict  __s ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *__strtok_r(char * __restrict  __s ,
                                                      char const   * __restrict  __delim ,
                                                      char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) char *strtok_r(char * __restrict  __s ,
                                                    char const   * __restrict  __delim ,
                                                    char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) size_t strlen(char const   *__s )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strnlen(char const   *__string ,
                                                    size_t __maxlen )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strerror(int __errnum ) ;
extern  __attribute__((__nothrow__)) int strerror_r(int __errnum , char *__buf ,
                                                    size_t __buflen )  __asm__("__xpg_strerror_r") __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *strerror_l(int __errnum ,
                                                      __locale_t __l ) ;
extern  __attribute__((__nothrow__)) void __bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void bcopy(void const   *__src ,
                                                void *__dest , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int bcmp(void const   *__s1 ,
                                              void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *index(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *rindex(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int ffs(int __i )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int strcasecmp(char const   *__s1 ,
                                                    char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncasecmp(char const   *__s1 ,
                                                     char const   *__s2 ,
                                                     size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsep(char ** __restrict  __stringp ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsignal(int __sig ) ;
extern  __attribute__((__nothrow__)) char *__stpcpy(char * __restrict  __dest ,
                                                    char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *__stpncpy(char * __restrict  __dest ,
                                                     char const   * __restrict  __src ,
                                                     size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern void *__rawmemchr(void const   *__s , int __c ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "8\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "9\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "6\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "5\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject) {
        fprintf(_coverage_fout, "4\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "7\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "10\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) ;
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "16\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "17\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "14\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "13\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        fprintf(_coverage_fout, "12\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          fprintf(_coverage_fout, "11\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "15\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "18\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) ;
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "25\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "26\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "23\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "22\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        fprintf(_coverage_fout, "21\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          fprintf(_coverage_fout, "20\n");
          fflush(_coverage_fout);
          if ((int const   )*(__s + __result) != (int const   )__reject3) {
            fprintf(_coverage_fout, "19\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "24\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "27\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) ;
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "31\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "32\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "29\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept) {
      fprintf(_coverage_fout, "28\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "30\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "33\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "39\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "40\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "37\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      fprintf(_coverage_fout, "34\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "36\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        fprintf(_coverage_fout, "35\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    }
    fprintf(_coverage_fout, "38\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "41\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "49\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "50\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "47\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      fprintf(_coverage_fout, "42\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "46\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        fprintf(_coverage_fout, "43\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "45\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) == (int const   )__accept3) {
          fprintf(_coverage_fout, "44\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      }
    }
    fprintf(_coverage_fout, "48\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "51\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "59\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "55\n");
    fflush(_coverage_fout);
    if ((int const   )*__s != 0) {
      fprintf(_coverage_fout, "54\n");
      fflush(_coverage_fout);
      if ((int const   )*__s != (int const   )__accept1) {
        fprintf(_coverage_fout, "53\n");
        fflush(_coverage_fout);
        if ((int const   )*__s != (int const   )__accept2) {
          fprintf(_coverage_fout, "52\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "56\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "60\n");
  fflush(_coverage_fout);
  if ((int const   )*__s == 0) {
    fprintf(_coverage_fout, "57\n");
    fflush(_coverage_fout);
    tmp = (char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "58\n");
    fflush(_coverage_fout);
    tmp = (char *)((unsigned int )__s);
  }
  fprintf(_coverage_fout, "61\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "70\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "66\n");
    fflush(_coverage_fout);
    if ((int const   )*__s != 0) {
      fprintf(_coverage_fout, "65\n");
      fflush(_coverage_fout);
      if ((int const   )*__s != (int const   )__accept1) {
        fprintf(_coverage_fout, "64\n");
        fflush(_coverage_fout);
        if ((int const   )*__s != (int const   )__accept2) {
          fprintf(_coverage_fout, "63\n");
          fflush(_coverage_fout);
          if ((int const   )*__s != (int const   )__accept3) {
            fprintf(_coverage_fout, "62\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "67\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "71\n");
  fflush(_coverage_fout);
  if ((int const   )*__s == 0) {
    fprintf(_coverage_fout, "68\n");
    fflush(_coverage_fout);
    tmp = (char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "69\n");
    fflush(_coverage_fout);
    tmp = (char *)((unsigned int )__s);
  }
  fprintf(_coverage_fout, "72\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) ;
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) 
{ char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "90\n");
  fflush(_coverage_fout);
  if ((unsigned int )__s == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "73\n");
    fflush(_coverage_fout);
    __s = *__nextp;
  } else {
    fprintf(_coverage_fout, "74\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "91\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "76\n");
    fflush(_coverage_fout);
    if ((int )*__s == (int )__sep) {
      fprintf(_coverage_fout, "75\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "77\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "92\n");
  fflush(_coverage_fout);
  __result = (char *)((void *)0);
  fprintf(_coverage_fout, "93\n");
  fflush(_coverage_fout);
  if ((int )*__s != 0) {
    fprintf(_coverage_fout, "85\n");
    fflush(_coverage_fout);
    tmp = __s;
    fprintf(_coverage_fout, "86\n");
    fflush(_coverage_fout);
    __s ++;
    fprintf(_coverage_fout, "87\n");
    fflush(_coverage_fout);
    __result = tmp;
    fprintf(_coverage_fout, "88\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "81\n");
      fflush(_coverage_fout);
      if ((int )*__s != 0) {
        fprintf(_coverage_fout, "78\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "82\n");
      fflush(_coverage_fout);
      tmp___0 = __s;
      fprintf(_coverage_fout, "83\n");
      fflush(_coverage_fout);
      __s ++;
      fprintf(_coverage_fout, "84\n");
      fflush(_coverage_fout);
      if ((int )*tmp___0 == (int )__sep) {
        fprintf(_coverage_fout, "79\n");
        fflush(_coverage_fout);
        *(__s + -1) = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "80\n");
        fflush(_coverage_fout);

      }
    }
  } else {
    fprintf(_coverage_fout, "89\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "94\n");
  fflush(_coverage_fout);
  *__nextp = __s;
  fprintf(_coverage_fout, "95\n");
  fflush(_coverage_fout);
  return (__result);
}
}
extern char *__strsep_g(char **__stringp , char const   *__delim ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) 
{ register char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  void *tmp___1 ;
  char *tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "105\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "106\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "100\n");
    fflush(_coverage_fout);
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    fprintf(_coverage_fout, "101\n");
    fflush(_coverage_fout);
    tmp___0 = tmp___2;
    fprintf(_coverage_fout, "102\n");
    fflush(_coverage_fout);
    *__s = tmp___0;
    fprintf(_coverage_fout, "103\n");
    fflush(_coverage_fout);
    if ((unsigned int )tmp___0 != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "96\n");
      fflush(_coverage_fout);
      tmp = *__s;
      fprintf(_coverage_fout, "97\n");
      fflush(_coverage_fout);
      (*__s) ++;
      fprintf(_coverage_fout, "98\n");
      fflush(_coverage_fout);
      *tmp = (char )'\000';
    } else {
      fprintf(_coverage_fout, "99\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "104\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "107\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) ;
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "125\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "126\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "121\n");
    fflush(_coverage_fout);
    __cp = __retval;
    fprintf(_coverage_fout, "122\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "118\n");
      fflush(_coverage_fout);
      if ((int )*__cp == 0) {
        fprintf(_coverage_fout, "108\n");
        fflush(_coverage_fout);
        __cp = (char *)((void *)0);
        break;
      } else {
        fprintf(_coverage_fout, "109\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "119\n");
      fflush(_coverage_fout);
      if ((int )*__cp == (int )__reject1) {
        fprintf(_coverage_fout, "110\n");
        fflush(_coverage_fout);
        tmp = __cp;
        fprintf(_coverage_fout, "111\n");
        fflush(_coverage_fout);
        __cp ++;
        fprintf(_coverage_fout, "112\n");
        fflush(_coverage_fout);
        *tmp = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "117\n");
        fflush(_coverage_fout);
        if ((int )*__cp == (int )__reject2) {
          fprintf(_coverage_fout, "113\n");
          fflush(_coverage_fout);
          tmp = __cp;
          fprintf(_coverage_fout, "114\n");
          fflush(_coverage_fout);
          __cp ++;
          fprintf(_coverage_fout, "115\n");
          fflush(_coverage_fout);
          *tmp = (char )'\000';
          break;
        } else {
          fprintf(_coverage_fout, "116\n");
          fflush(_coverage_fout);

        }
      }
      fprintf(_coverage_fout, "120\n");
      fflush(_coverage_fout);
      __cp ++;
    }
    fprintf(_coverage_fout, "123\n");
    fflush(_coverage_fout);
    *__s = __cp;
  } else {
    fprintf(_coverage_fout, "124\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "127\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) ;
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "149\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "150\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "145\n");
    fflush(_coverage_fout);
    __cp = __retval;
    fprintf(_coverage_fout, "146\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "142\n");
      fflush(_coverage_fout);
      if ((int )*__cp == 0) {
        fprintf(_coverage_fout, "128\n");
        fflush(_coverage_fout);
        __cp = (char *)((void *)0);
        break;
      } else {
        fprintf(_coverage_fout, "129\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "143\n");
      fflush(_coverage_fout);
      if ((int )*__cp == (int )__reject1) {
        fprintf(_coverage_fout, "130\n");
        fflush(_coverage_fout);
        tmp = __cp;
        fprintf(_coverage_fout, "131\n");
        fflush(_coverage_fout);
        __cp ++;
        fprintf(_coverage_fout, "132\n");
        fflush(_coverage_fout);
        *tmp = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "141\n");
        fflush(_coverage_fout);
        if ((int )*__cp == (int )__reject2) {
          fprintf(_coverage_fout, "133\n");
          fflush(_coverage_fout);
          tmp = __cp;
          fprintf(_coverage_fout, "134\n");
          fflush(_coverage_fout);
          __cp ++;
          fprintf(_coverage_fout, "135\n");
          fflush(_coverage_fout);
          *tmp = (char )'\000';
          break;
        } else {
          fprintf(_coverage_fout, "140\n");
          fflush(_coverage_fout);
          if ((int )*__cp == (int )__reject3) {
            fprintf(_coverage_fout, "136\n");
            fflush(_coverage_fout);
            tmp = __cp;
            fprintf(_coverage_fout, "137\n");
            fflush(_coverage_fout);
            __cp ++;
            fprintf(_coverage_fout, "138\n");
            fflush(_coverage_fout);
            *tmp = (char )'\000';
            break;
          } else {
            fprintf(_coverage_fout, "139\n");
            fflush(_coverage_fout);

          }
        }
      }
      fprintf(_coverage_fout, "144\n");
      fflush(_coverage_fout);
      __cp ++;
    }
    fprintf(_coverage_fout, "147\n");
    fflush(_coverage_fout);
    *__s = __cp;
  } else {
    fprintf(_coverage_fout, "148\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "151\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
extern  __attribute__((__nothrow__)) void *malloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *calloc(size_t __nmemb ,
                                                  size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strdup(char const   *__string )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strndup(char const   *__string ,
                                                     size_t __n )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_fail(char const   *__assertion ,
                                  char const   *__file , unsigned int __line ,
                                  char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_perror_fail(int __errnum , char const   *__file ,
                                         unsigned int __line ,
                                         char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert(char const   *__assertion , char const   *__file ,
                             int __line ) ;
extern  __attribute__((__nothrow__)) void insque(void *__elem , void *__prev ) ;
extern  __attribute__((__nothrow__)) void remque(void *__elem ) ;
extern  __attribute__((__nothrow__)) ENTRY *hsearch(ENTRY __item ,
                                                    ACTION __action ) ;
extern  __attribute__((__nothrow__)) int hcreate(size_t __nel ) ;
extern  __attribute__((__nothrow__)) void hdestroy(void) ;
extern void *tsearch(void const   *__key , void **__rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void *tfind(void const   *__key , void * const  *__rootp ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *tdelete(void const   * __restrict  __key ,
                     void ** __restrict  __rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void twalk(void const   *__root ,
                  void (*__action)(void const   *__nodep , VISIT __value ,
                                   int __level ) ) ;
extern void *lfind(void const   *__key , void const   *__base ,
                   size_t *__nmemb , size_t __size ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *lsearch(void const   *__key , void *__base , size_t *__nmemb ,
                     size_t __size , int (*__compar)(void const   * ,
                                                     void const   * ) ) ;
extern struct _IO_FILE_plus _IO_2_1_stdin_ ;
extern struct _IO_FILE_plus _IO_2_1_stdout_ ;
extern struct _IO_FILE_plus _IO_2_1_stderr_ ;
extern int __underflow(_IO_FILE * ) ;
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_feof(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_ferror(_IO_FILE *__fp ) ;
extern int _IO_peekc_locked(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) void _IO_flockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) void _IO_funlockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) int _IO_ftrylockfile(_IO_FILE * ) ;
extern int _IO_vfscanf(_IO_FILE * __restrict   , char const   * __restrict   ,
                       __gnuc_va_list  , int * __restrict   ) ;
extern int _IO_vfprintf(_IO_FILE * __restrict   , char const   * __restrict   ,
                        __gnuc_va_list  ) ;
extern __ssize_t _IO_padn(_IO_FILE * , int  , __ssize_t  ) ;
extern size_t _IO_sgetn(_IO_FILE * , void * , size_t  ) ;
extern __off64_t _IO_seekoff(_IO_FILE * , __off64_t  , int  , int  ) ;
extern __off64_t _IO_seekpos(_IO_FILE * , __off64_t  , int  ) ;
extern  __attribute__((__nothrow__)) void _IO_free_backup_area(_IO_FILE * ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
extern  __attribute__((__nothrow__)) int remove(char const   *__filename ) ;
extern  __attribute__((__nothrow__)) int rename(char const   *__old ,
                                                char const   *__new ) ;
extern  __attribute__((__nothrow__)) int renameat(int __oldfd ,
                                                  char const   *__old ,
                                                  int __newfd ,
                                                  char const   *__new ) ;
extern FILE *tmpfile(void)  __asm__("tmpfile64")  ;
extern  __attribute__((__nothrow__)) char *tmpnam(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tmpnam_r(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tempnam(char const   *__dir ,
                                                   char const   *__pfx )  __attribute__((__malloc__)) ;
extern int fclose(FILE *__stream ) ;
extern int fflush(FILE *__stream ) ;
extern int fflush_unlocked(FILE *__stream ) ;
extern FILE *freopen(char const   * __restrict  __filename ,
                     char const   * __restrict  __modes ,
                     FILE * __restrict  __stream )  __asm__("freopen64")  ;
extern  __attribute__((__nothrow__)) FILE *fdopen(int __fd ,
                                                  char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *fmemopen(void *__s , size_t __len ,
                                                    char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *open_memstream(char **__bufloc ,
                                                          size_t *__sizeloc ) ;
extern  __attribute__((__nothrow__)) void setbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) int setvbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ,
                                                 int __modes , size_t __n ) ;
extern  __attribute__((__nothrow__)) void setbuffer(FILE * __restrict  __stream ,
                                                    char * __restrict  __buf ,
                                                    size_t __size ) ;
extern  __attribute__((__nothrow__)) void setlinebuf(FILE *__stream ) ;
extern int fprintf(FILE * __restrict  __stream ,
                   char const   * __restrict  __format  , ...) ;
extern int printf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sprintf(char * __restrict  __s ,
                                                 char const   * __restrict  __format 
                                                 , ...) ;
extern int vfprintf(FILE * __restrict  __s ,
                    char const   * __restrict  __format , __gnuc_va_list __arg ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vsprintf(char * __restrict  __s ,
                                                  char const   * __restrict  __format ,
                                                  __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  snprintf)(char * __restrict  __s ,
                                                                             size_t __maxlen ,
                                                                             char const   * __restrict  __format 
                                                                             , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsnprintf)(char * __restrict  __s ,
                                                                              size_t __maxlen ,
                                                                              char const   * __restrict  __format ,
                                                                              __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  vdprintf)(int __fd ,
                                               char const   * __restrict  __fmt ,
                                               __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  dprintf)(int __fd ,
                                              char const   * __restrict  __fmt 
                                              , ...) ;
extern int fscanf(FILE * __restrict  __stream ,
                  char const   * __restrict  __format  , ...)  __asm__("__isoc99_fscanf")  ;
extern int scanf(char const   * __restrict  __format  , ...)  __asm__("__isoc99_scanf")  ;
extern  __attribute__((__nothrow__)) int sscanf(char const   * __restrict  __s ,
                                                char const   * __restrict  __format 
                                                , ...)  __asm__("__isoc99_sscanf")  ;
extern int ( /* format attribute */  vfscanf)(FILE * __restrict  __s ,
                                              char const   * __restrict  __format ,
                                              __gnuc_va_list __arg )  __asm__("__isoc99_vfscanf")  ;
extern int ( /* format attribute */  vscanf)(char const   * __restrict  __format ,
                                             __gnuc_va_list __arg )  __asm__("__isoc99_vscanf")  ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsscanf)(char const   * __restrict  __s ,
                                                                            char const   * __restrict  __format ,
                                                                            __gnuc_va_list __arg )  __asm__("__isoc99_vsscanf")  ;
extern int fgetc(FILE *__stream ) ;
extern int getc(FILE *__stream ) ;
__inline extern int getchar(void) ;
__inline extern int getc_unlocked(FILE *__fp ) ;
__inline extern int getchar_unlocked(void) ;
__inline extern int fgetc_unlocked(FILE *__fp ) ;
extern int fputc(int __c , FILE *__stream ) ;
extern int putc(int __c , FILE *__stream ) ;
__inline extern int putchar(int __c ) ;
__inline extern int fputc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putchar_unlocked(int __c ) ;
extern int getw(FILE *__stream ) ;
extern int putw(int __w , FILE *__stream ) ;
extern char *fgets(char * __restrict  __s , int __n ,
                   FILE * __restrict  __stream ) ;
extern char *gets(char *__s ) ;
extern __ssize_t __getdelim(char ** __restrict  __lineptr ,
                            size_t * __restrict  __n , int __delimiter ,
                            FILE * __restrict  __stream ) ;
extern __ssize_t getdelim(char ** __restrict  __lineptr ,
                          size_t * __restrict  __n , int __delimiter ,
                          FILE * __restrict  __stream ) ;
extern __ssize_t getline(char ** __restrict  __lineptr ,
                         size_t * __restrict  __n , FILE * __restrict  __stream ) ;
extern int fputs(char const   * __restrict  __s , FILE * __restrict  __stream ) ;
extern int puts(char const   *__s ) ;
extern int ungetc(int __c , FILE *__stream ) ;
extern size_t fread(void * __restrict  __ptr , size_t __size , size_t __n ,
                    FILE * __restrict  __stream ) ;
extern size_t fwrite(void const   * __restrict  __ptr , size_t __size ,
                     size_t __n , FILE * __restrict  __s ) ;
extern size_t fread_unlocked(void * __restrict  __ptr , size_t __size ,
                             size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite_unlocked(void const   * __restrict  __ptr , size_t __size ,
                              size_t __n , FILE * __restrict  __stream ) ;
extern int fseek(FILE *__stream , long __off , int __whence ) ;
extern long ftell(FILE *__stream ) ;
extern void rewind(FILE *__stream ) ;
extern int fseeko(FILE *__stream , __off64_t __off , int __whence )  __asm__("fseeko64")  ;
extern __off64_t ftello(FILE *__stream )  __asm__("ftello64")  ;
extern int fgetpos(FILE * __restrict  __stream , fpos_t * __restrict  __pos )  __asm__("fgetpos64")  ;
extern int fsetpos(FILE *__stream , fpos_t const   *__pos )  __asm__("fsetpos64")  ;
extern  __attribute__((__nothrow__)) void clearerr(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int feof(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ferror(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void clearerr_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
extern void perror(char const   *__s ) ;
extern int sys_nerr ;
extern char const   * const  sys_errlist[] ;
extern  __attribute__((__nothrow__)) int fileno(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int fileno_unlocked(FILE *__stream ) ;
extern FILE *popen(char const   *__command , char const   *__modes ) ;
extern int pclose(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) char *ctermid(char *__s ) ;
extern  __attribute__((__nothrow__)) void flockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ftrylockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void funlockfile(FILE *__stream ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "152\n");
  fflush(_coverage_fout);
  tmp = vfprintf((FILE */* __restrict  */)stdout, __fmt, __arg);
  fprintf(_coverage_fout, "153\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int getchar(void) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "154\n");
  fflush(_coverage_fout);
  tmp = _IO_getc(stdin);
  fprintf(_coverage_fout, "155\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int fgetc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "161\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "162\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "156\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "157\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "158\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "159\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "160\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "163\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int getc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "169\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "170\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "164\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "165\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "166\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "167\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "168\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "171\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int getchar_unlocked(void) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "177\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )stdin->_IO_read_ptr >= (unsigned int )stdin->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "178\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "172\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(stdin);
    fprintf(_coverage_fout, "173\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "174\n");
    fflush(_coverage_fout);
    tmp___1 = stdin->_IO_read_ptr;
    fprintf(_coverage_fout, "175\n");
    fflush(_coverage_fout);
    (stdin->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "176\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "179\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int putchar(int __c ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "180\n");
  fflush(_coverage_fout);
  tmp = _IO_putc(__c, stdout);
  fprintf(_coverage_fout, "181\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int fputc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "189\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "190\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "182\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "183\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "184\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "185\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "186\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "187\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "188\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "191\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern int putc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "199\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "200\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "192\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "193\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "194\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "195\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "196\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "197\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "198\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "201\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern int putchar_unlocked(int __c ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "209\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )stdout->_IO_write_ptr >= (unsigned int )stdout->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "210\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "202\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "203\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "204\n");
    fflush(_coverage_fout);
    tmp___1 = stdout->_IO_write_ptr;
    fprintf(_coverage_fout, "205\n");
    fflush(_coverage_fout);
    (stdout->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "206\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "207\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "208\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "211\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern int feof_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "212\n");
  fflush(_coverage_fout);
  return ((__stream->_flags & 0x10) != 0);
}
}
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
__inline extern int ferror_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "213\n");
  fflush(_coverage_fout);
  return ((__stream->_flags & 0x20) != 0);
}
}
extern char const   *TIFFGetVersion(void) ;
extern TIFFCodec const   *TIFFFindCODEC(uint16  ) ;
extern TIFFCodec *TIFFRegisterCODEC(uint16  , char const   * ,
                                    int (*)(TIFF * , int  ) ) ;
extern void TIFFUnRegisterCODEC(TIFFCodec * ) ;
extern int TIFFIsCODECConfigured(uint16  ) ;
extern TIFFCodec *TIFFGetConfiguredCODECs(void) ;
extern void *_TIFFmalloc(tmsize_t s ) ;
extern void *_TIFFrealloc(void *p , tmsize_t s ) ;
extern void _TIFFmemset(void *p , int v , tmsize_t c ) ;
extern void _TIFFmemcpy(void *d , void const   *s , tmsize_t c ) ;
extern int _TIFFmemcmp(void const   *p1 , void const   *p2 , tmsize_t c ) ;
extern void _TIFFfree(void *p ) ;
extern int TIFFGetTagListCount(TIFF * ) ;
extern uint32 TIFFGetTagListEntry(TIFF * , int tag_index ) ;
extern TIFFField const   *TIFFFindField(TIFF * , uint32  , TIFFDataType  ) ;
extern TIFFField const   *TIFFFieldWithTag(TIFF * , uint32  ) ;
extern TIFFField const   *TIFFFieldWithName(TIFF * , char const   * ) ;
extern TIFFTagMethods *TIFFAccessTagMethods(TIFF * ) ;
extern void *TIFFGetClientInfo(TIFF * , char const   * ) ;
extern void TIFFSetClientInfo(TIFF * , void * , char const   * ) ;
extern void TIFFCleanup(TIFF *tif ) ;
extern void TIFFClose(TIFF *tif ) ;
extern int TIFFFlush(TIFF *tif ) ;
extern int TIFFFlushData(TIFF *tif ) ;
int TIFFGetField(TIFF *tif , uint32 tag  , ...) ;
int TIFFVGetField(TIFF *tif , uint32 tag , va_list ap ) ;
extern int TIFFGetFieldDefaulted(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFVGetFieldDefaulted(TIFF *tif , uint32 tag , va_list ap ) ;
extern int TIFFReadDirectory(TIFF *tif ) ;
extern int TIFFReadCustomDirectory(TIFF *tif , uint64 diroff ,
                                   TIFFFieldArray const   *infoarray ) ;
extern int TIFFReadEXIFDirectory(TIFF *tif , uint64 diroff ) ;
extern uint64 TIFFScanlineSize64(TIFF *tif ) ;
extern tmsize_t TIFFScanlineSize(TIFF *tif ) ;
extern uint64 TIFFRasterScanlineSize64(TIFF *tif ) ;
extern tmsize_t TIFFRasterScanlineSize(TIFF *tif ) ;
extern uint64 TIFFStripSize64(TIFF *tif ) ;
extern tmsize_t TIFFStripSize(TIFF *tif ) ;
extern uint64 TIFFRawStripSize64(TIFF *tif , uint32 strip ) ;
extern tmsize_t TIFFRawStripSize(TIFF *tif , uint32 strip ) ;
extern uint64 TIFFVStripSize64(TIFF *tif , uint32 nrows ) ;
extern tmsize_t TIFFVStripSize(TIFF *tif , uint32 nrows ) ;
extern uint64 TIFFTileRowSize64(TIFF *tif ) ;
extern tmsize_t TIFFTileRowSize(TIFF *tif ) ;
extern uint64 TIFFTileSize64(TIFF *tif ) ;
extern tmsize_t TIFFTileSize(TIFF *tif ) ;
extern uint64 TIFFVTileSize64(TIFF *tif , uint32 nrows ) ;
extern tmsize_t TIFFVTileSize(TIFF *tif , uint32 nrows ) ;
extern uint32 TIFFDefaultStripSize(TIFF *tif , uint32 request ) ;
extern void TIFFDefaultTileSize(TIFF * , uint32 * , uint32 * ) ;
extern int TIFFFileno(TIFF * ) ;
extern int TIFFSetFileno(TIFF * , int  ) ;
extern thandle_t TIFFClientdata(TIFF * ) ;
extern thandle_t TIFFSetClientdata(TIFF * , thandle_t  ) ;
extern int TIFFGetMode(TIFF * ) ;
extern int TIFFSetMode(TIFF * , int  ) ;
extern int TIFFIsTiled(TIFF * ) ;
extern int TIFFIsByteSwapped(TIFF * ) ;
extern int TIFFIsUpSampled(TIFF * ) ;
extern int TIFFIsMSB2LSB(TIFF * ) ;
extern int TIFFIsBigEndian(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetReadProc(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetWriteProc(TIFF * ) ;
extern TIFFSeekProc TIFFGetSeekProc(TIFF * ) ;
extern TIFFCloseProc TIFFGetCloseProc(TIFF * ) ;
extern TIFFSizeProc TIFFGetSizeProc(TIFF * ) ;
extern TIFFMapFileProc TIFFGetMapFileProc(TIFF * ) ;
extern TIFFUnmapFileProc TIFFGetUnmapFileProc(TIFF * ) ;
extern uint32 TIFFCurrentRow(TIFF * ) ;
extern uint16 TIFFCurrentDirectory(TIFF * ) ;
uint16 TIFFNumberOfDirectories(TIFF *tif ) ;
uint64 TIFFCurrentDirOffset(TIFF *tif ) ;
extern uint32 TIFFCurrentStrip(TIFF * ) ;
extern uint32 TIFFCurrentTile(TIFF *tif ) ;
extern int TIFFReadBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
extern int TIFFWriteBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
extern int TIFFSetupStrips(TIFF * ) ;
extern int TIFFWriteCheck(TIFF * , int  , char const   * ) ;
void TIFFFreeDirectory(TIFF *tif ) ;
int TIFFCreateDirectory(TIFF *tif ) ;
int TIFFLastDirectory(TIFF *tif ) ;
int TIFFSetDirectory(TIFF *tif , uint16 dirn ) ;
int TIFFSetSubDirectory(TIFF *tif , uint64 diroff ) ;
int TIFFUnlinkDirectory(TIFF *tif , uint16 dirn ) ;
int TIFFSetField(TIFF *tif , uint32 tag  , ...) ;
int TIFFVSetField(TIFF *tif , uint32 tag , va_list ap ) ;
extern int TIFFWriteDirectory(TIFF * ) ;
extern int TIFFCheckpointDirectory(TIFF * ) ;
extern int TIFFRewriteDirectory(TIFF * ) ;
extern void TIFFPrintDirectory(TIFF * , FILE * , long  ) ;
extern int TIFFReadScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) ;
extern int TIFFWriteScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) ;
extern int TIFFReadRGBAImage(TIFF * , uint32  , uint32  , uint32 * , int  ) ;
extern int TIFFReadRGBAImageOriented(TIFF * , uint32  , uint32  , uint32 * ,
                                     int  , int  ) ;
extern int TIFFReadRGBAStrip(TIFF * , uint32  , uint32 * ) ;
extern int TIFFReadRGBATile(TIFF * , uint32  , uint32  , uint32 * ) ;
extern int TIFFRGBAImageOK(TIFF * , char * ) ;
extern int TIFFRGBAImageBegin(TIFFRGBAImage * , TIFF * , int  , char * ) ;
extern int TIFFRGBAImageGet(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
extern void TIFFRGBAImageEnd(TIFFRGBAImage * ) ;
extern TIFF *TIFFOpen(char const   * , char const   * ) ;
extern TIFF *TIFFFdOpen(int  , char const   * , char const   * ) ;
extern TIFF *TIFFClientOpen(char const   * , char const   * , thandle_t  ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            uint64 (*)(thandle_t  , uint64  , int  ) ,
                            int (*)(thandle_t  ) , uint64 (*)(thandle_t  ) ,
                            int (*)(thandle_t  , void **base , toff_t *size ) ,
                            void (*)(thandle_t  , void *base , toff_t size ) ) ;
extern char const   *TIFFFileName(TIFF * ) ;
extern char const   *TIFFSetFileName(TIFF * , char const   * ) ;
extern void TIFFError(char const   * , char const   *  , ...) ;
extern void TIFFErrorExt(thandle_t  , char const   * , char const   *  , ...) ;
extern void TIFFWarning(char const   * , char const   *  , ...) ;
extern void TIFFWarningExt(thandle_t  , char const   * , char const   *  , ...) ;
extern TIFFErrorHandler TIFFSetErrorHandler(void (*)(char const   * ,
                                                     char const   * , va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetErrorHandlerExt(void (*)(thandle_t  ,
                                                           char const   * ,
                                                           char const   * ,
                                                           va_list  ) ) ;
extern TIFFErrorHandler TIFFSetWarningHandler(void (*)(char const   * ,
                                                       char const   * ,
                                                       va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetWarningHandlerExt(void (*)(thandle_t  ,
                                                             char const   * ,
                                                             char const   * ,
                                                             va_list  ) ) ;
TIFFExtendProc TIFFSetTagExtender(void (*extender)(TIFF * ) ) ;
extern uint32 TIFFComputeTile(TIFF *tif , uint32 x , uint32 y , uint32 z ,
                              uint16 s ) ;
extern int TIFFCheckTile(TIFF *tif , uint32 x , uint32 y , uint32 z , uint16 s ) ;
extern uint32 TIFFNumberOfTiles(TIFF * ) ;
extern tmsize_t TIFFReadTile(TIFF *tif , void *buf , uint32 x , uint32 y ,
                             uint32 z , uint16 s ) ;
extern tmsize_t TIFFWriteTile(TIFF *tif , void *buf , uint32 x , uint32 y ,
                              uint32 z , uint16 s ) ;
extern uint32 TIFFComputeStrip(TIFF * , uint32  , uint16  ) ;
extern uint32 TIFFNumberOfStrips(TIFF * ) ;
extern tmsize_t TIFFReadEncodedStrip(TIFF *tif , uint32 strip , void *buf ,
                                     tmsize_t size ) ;
extern tmsize_t TIFFReadRawStrip(TIFF *tif , uint32 strip , void *buf ,
                                 tmsize_t size ) ;
extern tmsize_t TIFFReadEncodedTile(TIFF *tif , uint32 tile , void *buf ,
                                    tmsize_t size ) ;
extern tmsize_t TIFFReadRawTile(TIFF *tif , uint32 tile , void *buf ,
                                tmsize_t size ) ;
extern tmsize_t TIFFWriteEncodedStrip(TIFF *tif , uint32 strip , void *data ,
                                      tmsize_t cc ) ;
extern tmsize_t TIFFWriteRawStrip(TIFF *tif , uint32 strip , void *data ,
                                  tmsize_t cc ) ;
extern tmsize_t TIFFWriteEncodedTile(TIFF *tif , uint32 tile , void *data ,
                                     tmsize_t cc ) ;
extern tmsize_t TIFFWriteRawTile(TIFF *tif , uint32 tile , void *data ,
                                 tmsize_t cc ) ;
extern int TIFFDataWidth(TIFFDataType  ) ;
extern void TIFFSetWriteOffset(TIFF *tif , uint64 off ) ;
extern void TIFFSwabShort(uint16 * ) ;
extern void TIFFSwabLong(uint32 * ) ;
extern void TIFFSwabLong8(uint64 * ) ;
extern void TIFFSwabFloat(float * ) ;
extern void TIFFSwabDouble(double * ) ;
extern void TIFFSwabArrayOfShort(uint16 *wp , tmsize_t n ) ;
extern void TIFFSwabArrayOfTriples(uint8 *tp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong(uint32 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong8(uint64 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfFloat(float *fp , tmsize_t n ) ;
extern void TIFFSwabArrayOfDouble(double *dp , tmsize_t n ) ;
extern void TIFFReverseBits(uint8 *cp , tmsize_t n ) ;
extern unsigned char const   *TIFFGetBitRevTable(int  ) ;
extern double LogL16toY(int  ) ;
extern double LogL10toY(int  ) ;
extern void XYZtoRGB24(float * , uint8 * ) ;
extern int uv_decode(double * , double * , int  ) ;
extern void LogLuv24toXYZ(uint32  , float * ) ;
extern void LogLuv32toXYZ(uint32  , float * ) ;
extern int LogL16fromY(double  , int  ) ;
extern int LogL10fromY(double  , int  ) ;
extern int uv_encode(double  , double  , int  ) ;
extern uint32 LogLuv24fromXYZ(float * , int  ) ;
extern uint32 LogLuv32fromXYZ(float * , int  ) ;
extern int TIFFCIELabToRGBInit(TIFFCIELabToRGB * , TIFFDisplay * , float * ) ;
extern void TIFFCIELabToXYZ(TIFFCIELabToRGB * , uint32  , int32  , int32  ,
                            float * , float * , float * ) ;
extern void TIFFXYZToRGB(TIFFCIELabToRGB * , float  , float  , float  ,
                         uint32 * , uint32 * , uint32 * ) ;
extern int TIFFYCbCrToRGBInit(TIFFYCbCrToRGB * , float * , float * ) ;
extern void TIFFYCbCrtoRGB(TIFFYCbCrToRGB * , uint32  , int32  , int32  ,
                           uint32 * , uint32 * , uint32 * ) ;
extern int TIFFMergeFieldInfo(TIFF * , TIFFFieldInfo const   * , uint32  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfo(TIFF * , uint32  ,
                                                TIFFDataType  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfoByName(TIFF * , char const   * ,
                                                      TIFFDataType  ) ;
extern TIFFFieldArray const   *_TIFFGetFields(void) ;
extern TIFFFieldArray const   *_TIFFGetExifFields(void) ;
extern void _TIFFSetupFields(TIFF *tif , TIFFFieldArray const   *infoarray ) ;
extern void _TIFFPrintFieldInfo(TIFF * , FILE * ) ;
extern int _TIFFMergeFields(TIFF * , TIFFField const   * , uint32  ) ;
extern TIFFField const   *_TIFFFindOrRegisterField(TIFF * , uint32  ,
                                                   TIFFDataType  ) ;
extern TIFFField *_TIFFCreateAnonField(TIFF * , uint32  , TIFFDataType  ) ;
extern int _TIFFgetMode(char const   *mode , char const   *module ) ;
extern int _TIFFNoRowEncode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoStripEncode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoTileEncode(TIFF * , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoRowDecode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoStripDecode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoTileDecode(TIFF * , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern void _TIFFNoPostDecode(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern int _TIFFNoPreCode(TIFF *tif , uint16 s ) ;
extern int _TIFFNoSeek(TIFF *tif , uint32 off ) ;
extern void _TIFFSwab16BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab24BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab32BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab64BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern int TIFFFlushData1(TIFF *tif ) ;
int TIFFDefaultDirectory(TIFF *tif ) ;
extern void _TIFFSetDefaultCompressionState(TIFF *tif ) ;
extern int TIFFSetCompressionScheme(TIFF *tif , int scheme ) ;
extern int TIFFSetDefaultCompressionState(TIFF *tif ) ;
extern uint32 _TIFFDefaultStripSize(TIFF *tif , uint32 s ) ;
extern void _TIFFDefaultTileSize(TIFF *tif , uint32 *tw , uint32 *th ) ;
extern int _TIFFDataSize(TIFFDataType type ) ;
void _TIFFsetByteArray(void **vpp , void *vp , uint32 n ) ;
void _TIFFsetString(char **cpp , char *cp ) ;
void _TIFFsetShortArray(uint16 **wpp , uint16 *wp , uint32 n ) ;
void _TIFFsetLongArray(uint32 **lpp , uint32 *lp , uint32 n ) ;
void _TIFFsetFloatArray(float **fpp , float *fp , uint32 n ) ;
void _TIFFsetDoubleArray(double **dpp , double *dp , uint32 n ) ;
extern void _TIFFprintAscii(FILE * , char const   * ) ;
extern void _TIFFprintAsciiTag(FILE * , char const   * , char const   * ) ;
extern void (*_TIFFwarningHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFerrorHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFwarningHandlerExt)(thandle_t  , char const   * ,
                                      char const   * , va_list  ) ;
extern void (*_TIFFerrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  ) ;
extern void *_TIFFCheckMalloc(TIFF *tif , tmsize_t nmemb , tmsize_t elem_size ,
                              char const   *what ) ;
extern void *_TIFFCheckRealloc(TIFF *tif , void *buffer , tmsize_t nmemb ,
                               tmsize_t elem_size , char const   *what ) ;
extern double _TIFFUInt64ToDouble(uint64  ) ;
extern float _TIFFUInt64ToFloat(uint64  ) ;
extern int TIFFInitDumpMode(TIFF * , int  ) ;
extern int TIFFInitPackBits(TIFF * , int  ) ;
extern int TIFFInitCCITTRLE(TIFF * , int  ) ;
extern int TIFFInitCCITTRLEW(TIFF * , int  ) ;
extern int TIFFInitCCITTFax3(TIFF * , int  ) ;
extern int TIFFInitCCITTFax4(TIFF * , int  ) ;
extern int TIFFInitThunderScan(TIFF * , int  ) ;
extern int TIFFInitNeXT(TIFF * , int  ) ;
extern int TIFFInitLZW(TIFF * , int  ) ;
extern int TIFFInitZIP(TIFF * , int  ) ;
extern int TIFFInitPixarLog(TIFF * , int  ) ;
extern int TIFFInitSGILog(TIFF * , int  ) ;
extern TIFFCodec _TIFFBuiltinCODECS[] ;
static void setByteArray(void **vpp , void *vp , size_t nmemb ,
                         size_t elem_size ) 
{ tmsize_t bytes ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "228\n");
  fflush(_coverage_fout);
  if (*vpp) {
    fprintf(_coverage_fout, "214\n");
    fflush(_coverage_fout);
    _TIFFfree(*vpp);
    fprintf(_coverage_fout, "215\n");
    fflush(_coverage_fout);
    *vpp = (void *)0;
  } else {
    fprintf(_coverage_fout, "216\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "229\n");
  fflush(_coverage_fout);
  if (vp) {
    fprintf(_coverage_fout, "224\n");
    fflush(_coverage_fout);
    bytes = (long )(nmemb * elem_size);
    fprintf(_coverage_fout, "225\n");
    fflush(_coverage_fout);
    if (elem_size) {
      fprintf(_coverage_fout, "220\n");
      fflush(_coverage_fout);
      if ((unsigned long )bytes / (unsigned long )elem_size == (unsigned long )nmemb) {
        fprintf(_coverage_fout, "217\n");
        fflush(_coverage_fout);
        tmp = _TIFFmalloc(bytes);
        fprintf(_coverage_fout, "218\n");
        fflush(_coverage_fout);
        *vpp = tmp;
      } else {
        fprintf(_coverage_fout, "219\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "221\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "226\n");
    fflush(_coverage_fout);
    if (*vpp) {
      fprintf(_coverage_fout, "222\n");
      fflush(_coverage_fout);
      _TIFFmemcpy(*vpp, (void const   *)vp, bytes);
    } else {
      fprintf(_coverage_fout, "223\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "227\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "230\n");
  fflush(_coverage_fout);
  return;
}
}
void _TIFFsetByteArray(void **vpp , void *vp , uint32 n ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "231\n");
  fflush(_coverage_fout);
  setByteArray(vpp, vp, n, 1U);
  fprintf(_coverage_fout, "232\n");
  fflush(_coverage_fout);
  return;
}
}
void _TIFFsetString(char **cpp , char *cp ) 
{ size_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "233\n");
  fflush(_coverage_fout);
  tmp = strlen((char const   *)cp);
  fprintf(_coverage_fout, "234\n");
  fflush(_coverage_fout);
  setByteArray((void **)cpp, (void *)cp, tmp + 1U, 1U);
  fprintf(_coverage_fout, "235\n");
  fflush(_coverage_fout);
  return;
}
}
void _TIFFsetNString(char **cpp , char *cp , uint32 n ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "236\n");
  fflush(_coverage_fout);
  setByteArray((void **)cpp, (void *)cp, n, 1U);
  fprintf(_coverage_fout, "237\n");
  fflush(_coverage_fout);
  return;
}
}
void _TIFFsetShortArray(uint16 **wpp , uint16 *wp , uint32 n ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "238\n");
  fflush(_coverage_fout);
  setByteArray((void **)wpp, (void *)wp, n, sizeof(uint16 ));
  fprintf(_coverage_fout, "239\n");
  fflush(_coverage_fout);
  return;
}
}
void _TIFFsetLongArray(uint32 **lpp , uint32 *lp , uint32 n ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "240\n");
  fflush(_coverage_fout);
  setByteArray((void **)lpp, (void *)lp, n, sizeof(uint32 ));
  fprintf(_coverage_fout, "241\n");
  fflush(_coverage_fout);
  return;
}
}
void _TIFFsetLong8Array(uint64 **lpp , uint64 *lp , uint32 n ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "242\n");
  fflush(_coverage_fout);
  setByteArray((void **)lpp, (void *)lp, n, sizeof(uint64 ));
  fprintf(_coverage_fout, "243\n");
  fflush(_coverage_fout);
  return;
}
}
void _TIFFsetFloatArray(float **fpp , float *fp , uint32 n ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "244\n");
  fflush(_coverage_fout);
  setByteArray((void **)fpp, (void *)fp, n, sizeof(float ));
  fprintf(_coverage_fout, "245\n");
  fflush(_coverage_fout);
  return;
}
}
void _TIFFsetDoubleArray(double **dpp , double *dp , uint32 n ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "246\n");
  fflush(_coverage_fout);
  setByteArray((void **)dpp, (void *)dp, n, sizeof(double ));
  fprintf(_coverage_fout, "247\n");
  fflush(_coverage_fout);
  return;
}
}
static int setExtraSamples(TIFFDirectory *td , va_list ap , uint32 *v ) 
{ uint16 *va ;
  uint32 i ;
  uint16_vap tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "262\n");
  fflush(_coverage_fout);
  tmp = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "263\n");
  fflush(_coverage_fout);
  *v = (unsigned int )((unsigned short )tmp);
  fprintf(_coverage_fout, "264\n");
  fflush(_coverage_fout);
  if ((int )((unsigned short )*v) > (int )td->td_samplesperpixel) {
    fprintf(_coverage_fout, "248\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "249\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "265\n");
  fflush(_coverage_fout);
  va = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "266\n");
  fflush(_coverage_fout);
  if (*v > 0U) {
    fprintf(_coverage_fout, "252\n");
    fflush(_coverage_fout);
    if ((unsigned int )va == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "250\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "251\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "253\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "267\n");
  fflush(_coverage_fout);
  i = 0U;
  fprintf(_coverage_fout, "268\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "259\n");
    fflush(_coverage_fout);
    if (i < *v) {
      fprintf(_coverage_fout, "254\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "260\n");
    fflush(_coverage_fout);
    if ((int )*(va + i) > 2) {
      fprintf(_coverage_fout, "257\n");
      fflush(_coverage_fout);
      if ((int )*(va + i) == 999) {
        fprintf(_coverage_fout, "255\n");
        fflush(_coverage_fout);
        *(va + i) = (unsigned short)2;
      } else {
        fprintf(_coverage_fout, "256\n");
        fflush(_coverage_fout);
        return (0);
      }
    } else {
      fprintf(_coverage_fout, "258\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "261\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "269\n");
  fflush(_coverage_fout);
  td->td_extrasamples = (unsigned short )*v;
  fprintf(_coverage_fout, "270\n");
  fflush(_coverage_fout);
  _TIFFsetShortArray(& td->td_sampleinfo, va, (unsigned int )td->td_extrasamples);
  fprintf(_coverage_fout, "271\n");
  fflush(_coverage_fout);
  return (1);
}
}
static uint32 checkInkNamesString(TIFF *tif , uint32 slen , char const   *s ) 
{ TIFFDirectory *td ;
  uint16 i ;
  char const   *ep ;
  char const   *cp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "287\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "288\n");
  fflush(_coverage_fout);
  i = td->td_samplesperpixel;
  fprintf(_coverage_fout, "289\n");
  fflush(_coverage_fout);
  if (slen > 0U) {
    fprintf(_coverage_fout, "282\n");
    fflush(_coverage_fout);
    ep = s + slen;
    fprintf(_coverage_fout, "283\n");
    fflush(_coverage_fout);
    cp = s;
    fprintf(_coverage_fout, "284\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "278\n");
      fflush(_coverage_fout);
      if ((int )i > 0) {
        fprintf(_coverage_fout, "272\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "279\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "275\n");
        fflush(_coverage_fout);
        if ((int const   )*cp != 0) {
          fprintf(_coverage_fout, "273\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "276\n");
        fflush(_coverage_fout);
        if ((unsigned int )cp >= (unsigned int )ep) {
          goto bad;
        } else {
          fprintf(_coverage_fout, "274\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "277\n");
        fflush(_coverage_fout);
        cp ++;
      }
      fprintf(_coverage_fout, "280\n");
      fflush(_coverage_fout);
      cp ++;
      fprintf(_coverage_fout, "281\n");
      fflush(_coverage_fout);
      i = (uint16 )((int )i - 1);
    }
    fprintf(_coverage_fout, "285\n");
    fflush(_coverage_fout);
    return ((unsigned int )(cp - s));
  } else {
    fprintf(_coverage_fout, "286\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "290\n");
  fflush(_coverage_fout);
  bad: 
  TIFFErrorExt(tif->tif_clientdata, "TIFFSetField",
               "%s: Invalid InkNames value; expecting %d names, found %d",
               tif->tif_name, td->td_samplesperpixel,
               (int )td->td_samplesperpixel - (int )i);
  fprintf(_coverage_fout, "291\n");
  fflush(_coverage_fout);
  return (0U);
}
}
static int _TIFFVSetField(TIFF *tif , uint32 tag , va_list ap ) ;
static char const   module[15]  = 
  {      (char const   )'_',      (char const   )'T',      (char const   )'I',      (char const   )'F', 
        (char const   )'F',      (char const   )'V',      (char const   )'S',      (char const   )'e', 
        (char const   )'t',      (char const   )'F',      (char const   )'i',      (char const   )'e', 
        (char const   )'l',      (char const   )'d',      (char const   )'\000'};
static int _TIFFVSetField(TIFF *tif , uint32 tag , va_list ap ) 
{ TIFFDirectory *td ;
  int status ;
  uint32 v32 ;
  uint32 i ;
  uint32 v ;
  char *s ;
  uint32 tmp ;
  uint32 tmp___0 ;
  uint32 tmp___1 ;
  uint16_vap tmp___2 ;
  uint16_vap tmp___3 ;
  uint16_vap tmp___4 ;
  uint16_vap tmp___5 ;
  uint16_vap tmp___6 ;
  uint16_vap tmp___7 ;
  uint16_vap tmp___8 ;
  uint32 tmp___9 ;
  uint16_vap tmp___10 ;
  uint16_vap tmp___11 ;
  double tmp___12 ;
  double tmp___13 ;
  double tmp___14 ;
  double tmp___15 ;
  uint16_vap tmp___16 ;
  double tmp___17 ;
  double tmp___18 ;
  uint16_vap tmp___19 ;
  uint16_vap tmp___20 ;
  uint16_vap tmp___21 ;
  uint16_vap tmp___22 ;
  uint16_vap tmp___23 ;
  uint16 *tmp___24 ;
  uint16 *tmp___25 ;
  uint16 *tmp___26 ;
  int tmp___27 ;
  uint16_vap tmp___28 ;
  uint16 sv ;
  uint32 tmp___29 ;
  uint32 tmp___30 ;
  uint32 tmp___31 ;
  uint16_vap tmp___32 ;
  uint16_vap tmp___33 ;
  uint32 tmp___34 ;
  uint16_vap tmp___35 ;
  uint64 *tmp___36 ;
  uint16_vap tmp___37 ;
  uint16_vap tmp___38 ;
  uint16_vap tmp___39 ;
  uint16 *tmp___40 ;
  uint16_vap tmp___41 ;
  TIFFTagValue *tv ;
  int tv_size ;
  int iCustom ;
  TIFFField const   *fip ;
  TIFFField const   *tmp___42 ;
  char const   *tmp___43 ;
  char const   *tmp___44 ;
  TIFFTagValue *new_customValues ;
  void *tmp___45 ;
  uint32 ma ;
  char *mb ;
  uint32 tmp___46 ;
  char *tmp___47 ;
  char *tmp___48 ;
  size_t tmp___49 ;
  uint32 tmp___50 ;
  int tmp___51 ;
  void *tmp___52 ;
  int i___0 ;
  char *val ;
  uint8 v___0 ;
  int tmp___53 ;
  int8 v___1 ;
  int tmp___54 ;
  uint16 v___2 ;
  int tmp___55 ;
  int16 v___3 ;
  int tmp___56 ;
  uint32 v___4 ;
  uint32 tmp___57 ;
  int32 v___5 ;
  int32 tmp___58 ;
  uint64 v___6 ;
  uint64 tmp___59 ;
  int64 v___7 ;
  int64 tmp___60 ;
  float v___8 ;
  double tmp___61 ;
  double v___9 ;
  double tmp___62 ;
  TIFFField const   *tmp___63 ;
  TIFFField const   *tmp___64 ;
  TIFFField const   *tmp___65 ;
  TIFFField const   *tmp___66 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "623\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "624\n");
  fflush(_coverage_fout);
  status = 1;
  switch ((int )tag) {
  fprintf(_coverage_fout, "490\n");
  fflush(_coverage_fout);
  case 254: 
  tmp = __builtin_va_arg(ap, uint32 );
  fprintf(_coverage_fout, "491\n");
  fflush(_coverage_fout);
  td->td_subfiletype = tmp;
  break;
  fprintf(_coverage_fout, "492\n");
  fflush(_coverage_fout);
  case 256: 
  tmp___0 = __builtin_va_arg(ap, uint32 );
  fprintf(_coverage_fout, "493\n");
  fflush(_coverage_fout);
  td->td_imagewidth = tmp___0;
  break;
  fprintf(_coverage_fout, "494\n");
  fflush(_coverage_fout);
  case 257: 
  tmp___1 = __builtin_va_arg(ap, uint32 );
  fprintf(_coverage_fout, "495\n");
  fflush(_coverage_fout);
  td->td_imagelength = tmp___1;
  break;
  fprintf(_coverage_fout, "496\n");
  fflush(_coverage_fout);
  case 258: 
  tmp___2 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "497\n");
  fflush(_coverage_fout);
  td->td_bitspersample = (unsigned short )tmp___2;
  fprintf(_coverage_fout, "498\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "302\n");
    fflush(_coverage_fout);
    if ((int )td->td_bitspersample == 16) {
      fprintf(_coverage_fout, "292\n");
      fflush(_coverage_fout);
      tif->tif_postdecode = & _TIFFSwab16BitData;
    } else {
      fprintf(_coverage_fout, "301\n");
      fflush(_coverage_fout);
      if ((int )td->td_bitspersample == 24) {
        fprintf(_coverage_fout, "293\n");
        fflush(_coverage_fout);
        tif->tif_postdecode = & _TIFFSwab24BitData;
      } else {
        fprintf(_coverage_fout, "300\n");
        fflush(_coverage_fout);
        if ((int )td->td_bitspersample == 32) {
          fprintf(_coverage_fout, "294\n");
          fflush(_coverage_fout);
          tif->tif_postdecode = & _TIFFSwab32BitData;
        } else {
          fprintf(_coverage_fout, "299\n");
          fflush(_coverage_fout);
          if ((int )td->td_bitspersample == 64) {
            fprintf(_coverage_fout, "295\n");
            fflush(_coverage_fout);
            tif->tif_postdecode = & _TIFFSwab64BitData;
          } else {
            fprintf(_coverage_fout, "298\n");
            fflush(_coverage_fout);
            if ((int )td->td_bitspersample == 128) {
              fprintf(_coverage_fout, "296\n");
              fflush(_coverage_fout);
              tif->tif_postdecode = & _TIFFSwab64BitData;
            } else {
              fprintf(_coverage_fout, "297\n");
              fflush(_coverage_fout);

            }
          }
        }
      }
    }
  } else {
    fprintf(_coverage_fout, "303\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "499\n");
  fflush(_coverage_fout);
  case 259: 
  tmp___3 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "500\n");
  fflush(_coverage_fout);
  v = (unsigned int )((unsigned short )tmp___3);
  fprintf(_coverage_fout, "501\n");
  fflush(_coverage_fout);
  if (tif->tif_dir.td_fieldsset[0] & (1UL << 7)) {
    fprintf(_coverage_fout, "305\n");
    fflush(_coverage_fout);
    if ((unsigned int )td->td_compression == v) {
      break;
    } else {
      fprintf(_coverage_fout, "304\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "306\n");
    fflush(_coverage_fout);
    (*(tif->tif_cleanup))(tif);
    fprintf(_coverage_fout, "307\n");
    fflush(_coverage_fout);
    tif->tif_flags &= 4294967263U;
  } else {
    fprintf(_coverage_fout, "308\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "502\n");
  fflush(_coverage_fout);
  status = TIFFSetCompressionScheme(tif, (int )v);
  fprintf(_coverage_fout, "503\n");
  fflush(_coverage_fout);
  if (status != 0) {
    fprintf(_coverage_fout, "309\n");
    fflush(_coverage_fout);
    td->td_compression = (unsigned short )v;
  } else {
    fprintf(_coverage_fout, "310\n");
    fflush(_coverage_fout);
    status = 0;
  }
  break;
  fprintf(_coverage_fout, "504\n");
  fflush(_coverage_fout);
  case 262: 
  tmp___4 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "505\n");
  fflush(_coverage_fout);
  td->td_photometric = (unsigned short )tmp___4;
  break;
  fprintf(_coverage_fout, "506\n");
  fflush(_coverage_fout);
  case 263: 
  tmp___5 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "507\n");
  fflush(_coverage_fout);
  td->td_threshholding = (unsigned short )tmp___5;
  break;
  fprintf(_coverage_fout, "508\n");
  fflush(_coverage_fout);
  case 266: 
  tmp___6 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "509\n");
  fflush(_coverage_fout);
  v = (unsigned int )((unsigned short )tmp___6);
  fprintf(_coverage_fout, "510\n");
  fflush(_coverage_fout);
  if (v != 2U) {
    fprintf(_coverage_fout, "312\n");
    fflush(_coverage_fout);
    if (v != 1U) {
      goto badvalue;
    } else {
      fprintf(_coverage_fout, "311\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "313\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "511\n");
  fflush(_coverage_fout);
  td->td_fillorder = (unsigned short )v;
  break;
  fprintf(_coverage_fout, "512\n");
  fflush(_coverage_fout);
  case 274: 
  tmp___7 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "513\n");
  fflush(_coverage_fout);
  v = (unsigned int )((unsigned short )tmp___7);
  fprintf(_coverage_fout, "514\n");
  fflush(_coverage_fout);
  if (v < 1U) {
    goto badvalue;
  } else {
    fprintf(_coverage_fout, "315\n");
    fflush(_coverage_fout);
    if (8U < v) {
      goto badvalue;
    } else {
      fprintf(_coverage_fout, "314\n");
      fflush(_coverage_fout);
      td->td_orientation = (unsigned short )v;
    }
  }
  break;
  fprintf(_coverage_fout, "515\n");
  fflush(_coverage_fout);
  case 277: 
  tmp___8 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "516\n");
  fflush(_coverage_fout);
  v = (unsigned int )((unsigned short )tmp___8);
  fprintf(_coverage_fout, "517\n");
  fflush(_coverage_fout);
  if (v == 0U) {
    goto badvalue;
  } else {
    fprintf(_coverage_fout, "316\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "518\n");
  fflush(_coverage_fout);
  td->td_samplesperpixel = (unsigned short )v;
  break;
  fprintf(_coverage_fout, "519\n");
  fflush(_coverage_fout);
  case 278: 
  tmp___9 = __builtin_va_arg(ap, uint32 );
  fprintf(_coverage_fout, "520\n");
  fflush(_coverage_fout);
  v32 = tmp___9;
  fprintf(_coverage_fout, "521\n");
  fflush(_coverage_fout);
  if (v32 == 0U) {
    goto badvalue32;
  } else {
    fprintf(_coverage_fout, "317\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "522\n");
  fflush(_coverage_fout);
  td->td_rowsperstrip = v32;
  fprintf(_coverage_fout, "523\n");
  fflush(_coverage_fout);
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 2))) {
    fprintf(_coverage_fout, "318\n");
    fflush(_coverage_fout);
    td->td_tilelength = v32;
    fprintf(_coverage_fout, "319\n");
    fflush(_coverage_fout);
    td->td_tilewidth = td->td_imagewidth;
  } else {
    fprintf(_coverage_fout, "320\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "524\n");
  fflush(_coverage_fout);
  case 280: 
  tmp___10 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "525\n");
  fflush(_coverage_fout);
  td->td_minsamplevalue = (unsigned short )tmp___10;
  break;
  fprintf(_coverage_fout, "526\n");
  fflush(_coverage_fout);
  case 281: 
  tmp___11 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "527\n");
  fflush(_coverage_fout);
  td->td_maxsamplevalue = (unsigned short )tmp___11;
  break;
  fprintf(_coverage_fout, "528\n");
  fflush(_coverage_fout);
  case 340: 
  tmp___12 = __builtin_va_arg(ap, double );
  fprintf(_coverage_fout, "529\n");
  fflush(_coverage_fout);
  td->td_sminsamplevalue = tmp___12;
  break;
  fprintf(_coverage_fout, "530\n");
  fflush(_coverage_fout);
  case 341: 
  tmp___13 = __builtin_va_arg(ap, double );
  fprintf(_coverage_fout, "531\n");
  fflush(_coverage_fout);
  td->td_smaxsamplevalue = tmp___13;
  break;
  fprintf(_coverage_fout, "532\n");
  fflush(_coverage_fout);
  case 282: 
  tmp___14 = __builtin_va_arg(ap, double );
  fprintf(_coverage_fout, "533\n");
  fflush(_coverage_fout);
  td->td_xresolution = (float )tmp___14;
  break;
  fprintf(_coverage_fout, "534\n");
  fflush(_coverage_fout);
  case 283: 
  tmp___15 = __builtin_va_arg(ap, double );
  fprintf(_coverage_fout, "535\n");
  fflush(_coverage_fout);
  td->td_yresolution = (float )tmp___15;
  break;
  fprintf(_coverage_fout, "536\n");
  fflush(_coverage_fout);
  case 284: 
  tmp___16 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "537\n");
  fflush(_coverage_fout);
  v = (unsigned int )((unsigned short )tmp___16);
  fprintf(_coverage_fout, "538\n");
  fflush(_coverage_fout);
  if (v != 1U) {
    fprintf(_coverage_fout, "322\n");
    fflush(_coverage_fout);
    if (v != 2U) {
      goto badvalue;
    } else {
      fprintf(_coverage_fout, "321\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "323\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "539\n");
  fflush(_coverage_fout);
  td->td_planarconfig = (unsigned short )v;
  break;
  fprintf(_coverage_fout, "540\n");
  fflush(_coverage_fout);
  case 286: 
  tmp___17 = __builtin_va_arg(ap, double );
  fprintf(_coverage_fout, "541\n");
  fflush(_coverage_fout);
  td->td_xposition = (float )tmp___17;
  break;
  fprintf(_coverage_fout, "542\n");
  fflush(_coverage_fout);
  case 287: 
  tmp___18 = __builtin_va_arg(ap, double );
  fprintf(_coverage_fout, "543\n");
  fflush(_coverage_fout);
  td->td_yposition = (float )tmp___18;
  break;
  fprintf(_coverage_fout, "544\n");
  fflush(_coverage_fout);
  case 296: 
  tmp___19 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "545\n");
  fflush(_coverage_fout);
  v = (unsigned int )((unsigned short )tmp___19);
  fprintf(_coverage_fout, "546\n");
  fflush(_coverage_fout);
  if (v < 1U) {
    goto badvalue;
  } else {
    fprintf(_coverage_fout, "325\n");
    fflush(_coverage_fout);
    if (3U < v) {
      goto badvalue;
    } else {
      fprintf(_coverage_fout, "324\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "547\n");
  fflush(_coverage_fout);
  td->td_resolutionunit = (unsigned short )v;
  break;
  fprintf(_coverage_fout, "548\n");
  fflush(_coverage_fout);
  case 297: 
  tmp___20 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "549\n");
  fflush(_coverage_fout);
  td->td_pagenumber[0] = (unsigned short )tmp___20;
  fprintf(_coverage_fout, "550\n");
  fflush(_coverage_fout);
  tmp___21 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "551\n");
  fflush(_coverage_fout);
  td->td_pagenumber[1] = (unsigned short )tmp___21;
  break;
  fprintf(_coverage_fout, "552\n");
  fflush(_coverage_fout);
  case 321: 
  tmp___22 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "553\n");
  fflush(_coverage_fout);
  td->td_halftonehints[0] = (unsigned short )tmp___22;
  fprintf(_coverage_fout, "554\n");
  fflush(_coverage_fout);
  tmp___23 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "555\n");
  fflush(_coverage_fout);
  td->td_halftonehints[1] = (unsigned short )tmp___23;
  break;
  fprintf(_coverage_fout, "556\n");
  fflush(_coverage_fout);
  case 320: 
  v32 = (unsigned int )(1L << (int )td->td_bitspersample);
  fprintf(_coverage_fout, "557\n");
  fflush(_coverage_fout);
  tmp___24 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "558\n");
  fflush(_coverage_fout);
  _TIFFsetShortArray(& td->td_colormap[0], tmp___24, v32);
  fprintf(_coverage_fout, "559\n");
  fflush(_coverage_fout);
  tmp___25 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "560\n");
  fflush(_coverage_fout);
  _TIFFsetShortArray(& td->td_colormap[1], tmp___25, v32);
  fprintf(_coverage_fout, "561\n");
  fflush(_coverage_fout);
  tmp___26 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "562\n");
  fflush(_coverage_fout);
  _TIFFsetShortArray(& td->td_colormap[2], tmp___26, v32);
  break;
  fprintf(_coverage_fout, "563\n");
  fflush(_coverage_fout);
  case 338: 
  tmp___27 = setExtraSamples(td, ap, & v);
  fprintf(_coverage_fout, "564\n");
  fflush(_coverage_fout);
  if (tmp___27) {
    fprintf(_coverage_fout, "326\n");
    fflush(_coverage_fout);

  } else {
    goto badvalue;
  }
  break;
  fprintf(_coverage_fout, "565\n");
  fflush(_coverage_fout);
  case 32995: 
  tmp___28 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "566\n");
  fflush(_coverage_fout);
  td->td_extrasamples = (unsigned short )((int )((unsigned short )tmp___28) != 0);
  fprintf(_coverage_fout, "567\n");
  fflush(_coverage_fout);
  if (td->td_extrasamples) {
    fprintf(_coverage_fout, "327\n");
    fflush(_coverage_fout);
    sv = (uint16 )1;
    fprintf(_coverage_fout, "328\n");
    fflush(_coverage_fout);
    _TIFFsetShortArray(& td->td_sampleinfo, & sv, 1U);
  } else {
    fprintf(_coverage_fout, "329\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "568\n");
  fflush(_coverage_fout);
  case 322: 
  tmp___29 = __builtin_va_arg(ap, uint32 );
  fprintf(_coverage_fout, "569\n");
  fflush(_coverage_fout);
  v32 = tmp___29;
  fprintf(_coverage_fout, "570\n");
  fflush(_coverage_fout);
  if (v32 % 16U) {
    fprintf(_coverage_fout, "331\n");
    fflush(_coverage_fout);
    if (tif->tif_mode != 00) {
      goto badvalue32;
    } else {
      fprintf(_coverage_fout, "330\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "332\n");
    fflush(_coverage_fout);
    TIFFWarningExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                   "Nonstandard tile width %d, convert file", v32);
  } else {
    fprintf(_coverage_fout, "333\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "571\n");
  fflush(_coverage_fout);
  td->td_tilewidth = v32;
  fprintf(_coverage_fout, "572\n");
  fflush(_coverage_fout);
  tif->tif_flags |= 1024U;
  break;
  fprintf(_coverage_fout, "573\n");
  fflush(_coverage_fout);
  case 323: 
  tmp___30 = __builtin_va_arg(ap, uint32 );
  fprintf(_coverage_fout, "574\n");
  fflush(_coverage_fout);
  v32 = tmp___30;
  fprintf(_coverage_fout, "575\n");
  fflush(_coverage_fout);
  if (v32 % 16U) {
    fprintf(_coverage_fout, "335\n");
    fflush(_coverage_fout);
    if (tif->tif_mode != 00) {
      goto badvalue32;
    } else {
      fprintf(_coverage_fout, "334\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "336\n");
    fflush(_coverage_fout);
    TIFFWarningExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                   "Nonstandard tile length %d, convert file", v32);
  } else {
    fprintf(_coverage_fout, "337\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "576\n");
  fflush(_coverage_fout);
  td->td_tilelength = v32;
  fprintf(_coverage_fout, "577\n");
  fflush(_coverage_fout);
  tif->tif_flags |= 1024U;
  break;
  fprintf(_coverage_fout, "578\n");
  fflush(_coverage_fout);
  case 32998: 
  tmp___31 = __builtin_va_arg(ap, uint32 );
  fprintf(_coverage_fout, "579\n");
  fflush(_coverage_fout);
  v32 = tmp___31;
  fprintf(_coverage_fout, "580\n");
  fflush(_coverage_fout);
  if (v32 == 0U) {
    goto badvalue32;
  } else {
    fprintf(_coverage_fout, "338\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "581\n");
  fflush(_coverage_fout);
  td->td_tiledepth = v32;
  break;
  fprintf(_coverage_fout, "582\n");
  fflush(_coverage_fout);
  case 32996: 
  tmp___32 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "583\n");
  fflush(_coverage_fout);
  v = (unsigned int )((unsigned short )tmp___32);
  switch ((int )v) {
  fprintf(_coverage_fout, "339\n");
  fflush(_coverage_fout);
  case 0: 
  v = 4U;
  break;
  fprintf(_coverage_fout, "340\n");
  fflush(_coverage_fout);
  case 1: 
  v = 2U;
  break;
  fprintf(_coverage_fout, "341\n");
  fflush(_coverage_fout);
  case 2: 
  v = 1U;
  break;
  fprintf(_coverage_fout, "342\n");
  fflush(_coverage_fout);
  case 3: 
  v = 3U;
  break;
  fprintf(_coverage_fout, "343\n");
  fflush(_coverage_fout);
  default: ;
  goto badvalue;
  }
  fprintf(_coverage_fout, "584\n");
  fflush(_coverage_fout);
  td->td_sampleformat = (unsigned short )v;
  break;
  fprintf(_coverage_fout, "585\n");
  fflush(_coverage_fout);
  case 339: 
  tmp___33 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "586\n");
  fflush(_coverage_fout);
  v = (unsigned int )((unsigned short )tmp___33);
  fprintf(_coverage_fout, "587\n");
  fflush(_coverage_fout);
  if (v < 1U) {
    goto badvalue;
  } else {
    fprintf(_coverage_fout, "345\n");
    fflush(_coverage_fout);
    if (6U < v) {
      goto badvalue;
    } else {
      fprintf(_coverage_fout, "344\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "588\n");
  fflush(_coverage_fout);
  td->td_sampleformat = (unsigned short )v;
  fprintf(_coverage_fout, "589\n");
  fflush(_coverage_fout);
  if ((int )td->td_sampleformat == 5) {
    fprintf(_coverage_fout, "348\n");
    fflush(_coverage_fout);
    if ((int )td->td_bitspersample == 32) {
      fprintf(_coverage_fout, "347\n");
      fflush(_coverage_fout);
      if ((unsigned int )tif->tif_postdecode == (unsigned int )(& _TIFFSwab32BitData)) {
        fprintf(_coverage_fout, "346\n");
        fflush(_coverage_fout);
        tif->tif_postdecode = & _TIFFSwab16BitData;
      } else {
        goto _L___1;
      }
    } else {
      goto _L___1;
    }
  } else {
    fprintf(_coverage_fout, "356\n");
    fflush(_coverage_fout);
    _L___1: /* CIL Label */ 
    _L___0: /* CIL Label */ 
    if ((int )td->td_sampleformat == 5) {
      goto _L;
    } else {
      fprintf(_coverage_fout, "355\n");
      fflush(_coverage_fout);
      if ((int )td->td_sampleformat == 6) {
        fprintf(_coverage_fout, "353\n");
        fflush(_coverage_fout);
        _L: /* CIL Label */ 
        if ((int )td->td_bitspersample == 64) {
          fprintf(_coverage_fout, "351\n");
          fflush(_coverage_fout);
          if ((unsigned int )tif->tif_postdecode == (unsigned int )(& _TIFFSwab64BitData)) {
            fprintf(_coverage_fout, "349\n");
            fflush(_coverage_fout);
            tif->tif_postdecode = & _TIFFSwab32BitData;
          } else {
            fprintf(_coverage_fout, "350\n");
            fflush(_coverage_fout);

          }
        } else {
          fprintf(_coverage_fout, "352\n");
          fflush(_coverage_fout);

        }
      } else {
        fprintf(_coverage_fout, "354\n");
        fflush(_coverage_fout);

      }
    }
  }
  break;
  fprintf(_coverage_fout, "590\n");
  fflush(_coverage_fout);
  case 32997: 
  tmp___34 = __builtin_va_arg(ap, uint32 );
  fprintf(_coverage_fout, "591\n");
  fflush(_coverage_fout);
  td->td_imagedepth = tmp___34;
  break;
  fprintf(_coverage_fout, "592\n");
  fflush(_coverage_fout);
  case 330: 
  if ((tif->tif_flags & 8192U) == 0U) {
    fprintf(_coverage_fout, "357\n");
    fflush(_coverage_fout);
    tmp___35 = __builtin_va_arg(ap, uint16_vap );
    fprintf(_coverage_fout, "358\n");
    fflush(_coverage_fout);
    td->td_nsubifd = (unsigned short )tmp___35;
    fprintf(_coverage_fout, "359\n");
    fflush(_coverage_fout);
    tmp___36 = __builtin_va_arg(ap, uint64 *);
    fprintf(_coverage_fout, "360\n");
    fflush(_coverage_fout);
    _TIFFsetLong8Array(& td->td_subifd, tmp___36,
                       (unsigned int )((long )td->td_nsubifd));
  } else {
    fprintf(_coverage_fout, "361\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module, "%s: Sorry, cannot nest SubIFDs",
                 tif->tif_name);
    fprintf(_coverage_fout, "362\n");
    fflush(_coverage_fout);
    status = 0;
  }
  break;
  fprintf(_coverage_fout, "593\n");
  fflush(_coverage_fout);
  case 531: 
  tmp___37 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "594\n");
  fflush(_coverage_fout);
  td->td_ycbcrpositioning = (unsigned short )tmp___37;
  break;
  fprintf(_coverage_fout, "595\n");
  fflush(_coverage_fout);
  case 530: 
  tmp___38 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "596\n");
  fflush(_coverage_fout);
  td->td_ycbcrsubsampling[0] = (unsigned short )tmp___38;
  fprintf(_coverage_fout, "597\n");
  fflush(_coverage_fout);
  tmp___39 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "598\n");
  fflush(_coverage_fout);
  td->td_ycbcrsubsampling[1] = (unsigned short )tmp___39;
  break;
  fprintf(_coverage_fout, "599\n");
  fflush(_coverage_fout);
  case 301: 
  if ((int )td->td_samplesperpixel - (int )td->td_extrasamples > 1) {
    fprintf(_coverage_fout, "363\n");
    fflush(_coverage_fout);
    v = 3U;
  } else {
    fprintf(_coverage_fout, "364\n");
    fflush(_coverage_fout);
    v = 1U;
  }
  fprintf(_coverage_fout, "600\n");
  fflush(_coverage_fout);
  i = 0U;
  fprintf(_coverage_fout, "601\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "366\n");
    fflush(_coverage_fout);
    if (i < v) {
      fprintf(_coverage_fout, "365\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "367\n");
    fflush(_coverage_fout);
    tmp___40 = __builtin_va_arg(ap, uint16 *);
    fprintf(_coverage_fout, "368\n");
    fflush(_coverage_fout);
    _TIFFsetShortArray(& td->td_transferfunction[i], tmp___40,
                       (unsigned int )(1L << (int )td->td_bitspersample));
    fprintf(_coverage_fout, "369\n");
    fflush(_coverage_fout);
    i ++;
  }
  break;
  fprintf(_coverage_fout, "602\n");
  fflush(_coverage_fout);
  case 333: 
  tmp___41 = __builtin_va_arg(ap, uint16_vap );
  fprintf(_coverage_fout, "603\n");
  fflush(_coverage_fout);
  v = (unsigned int )((unsigned short )tmp___41);
  fprintf(_coverage_fout, "604\n");
  fflush(_coverage_fout);
  s = __builtin_va_arg(ap, char *);
  fprintf(_coverage_fout, "605\n");
  fflush(_coverage_fout);
  v = checkInkNamesString(tif, v, (char const   *)s);
  fprintf(_coverage_fout, "606\n");
  fflush(_coverage_fout);
  status = v > 0U;
  fprintf(_coverage_fout, "607\n");
  fflush(_coverage_fout);
  if (v > 0U) {
    fprintf(_coverage_fout, "370\n");
    fflush(_coverage_fout);
    _TIFFsetNString(& td->td_inknames, s, v);
    fprintf(_coverage_fout, "371\n");
    fflush(_coverage_fout);
    td->td_inknameslen = (int )v;
  } else {
    fprintf(_coverage_fout, "372\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "608\n");
  fflush(_coverage_fout);
  default: 
  tmp___42 = TIFFFindField(tif, tag, (enum __anonenum_TIFFDataType_21 )0);
  fprintf(_coverage_fout, "609\n");
  fflush(_coverage_fout);
  fip = tmp___42;
  fprintf(_coverage_fout, "610\n");
  fflush(_coverage_fout);
  if ((unsigned int )fip == (unsigned int )((void *)0)) {
    goto _L___2;
  } else {
    fprintf(_coverage_fout, "382\n");
    fflush(_coverage_fout);
    if ((int const   )fip->field_bit != 65) {
      fprintf(_coverage_fout, "377\n");
      fflush(_coverage_fout);
      _L___2: /* CIL Label */ 
      if (fip) {
        fprintf(_coverage_fout, "373\n");
        fflush(_coverage_fout);
        tmp___43 = (char const   */* const  */)fip->field_name;
      } else {
        fprintf(_coverage_fout, "374\n");
        fflush(_coverage_fout);
        tmp___43 = (char const   */* const  */)"Unknown";
      }
      fprintf(_coverage_fout, "378\n");
      fflush(_coverage_fout);
      if (tag > 65535U) {
        fprintf(_coverage_fout, "375\n");
        fflush(_coverage_fout);
        tmp___44 = "pseudo-";
      } else {
        fprintf(_coverage_fout, "376\n");
        fflush(_coverage_fout);
        tmp___44 = "";
      }
      fprintf(_coverage_fout, "379\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module,
                   "%s: Invalid %stag \"%s\" (not supported by codec)",
                   tif->tif_name, tmp___44, tmp___43);
      fprintf(_coverage_fout, "380\n");
      fflush(_coverage_fout);
      status = 0;
      break;
    } else {
      fprintf(_coverage_fout, "381\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "611\n");
  fflush(_coverage_fout);
  tv = (TIFFTagValue *)((void *)0);
  fprintf(_coverage_fout, "612\n");
  fflush(_coverage_fout);
  iCustom = 0;
  fprintf(_coverage_fout, "613\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "390\n");
    fflush(_coverage_fout);
    if (iCustom < td->td_customValueCount) {
      fprintf(_coverage_fout, "383\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "391\n");
    fflush(_coverage_fout);
    if (((td->td_customValues + iCustom)->info)->field_tag == (uint32 const   )tag) {
      fprintf(_coverage_fout, "387\n");
      fflush(_coverage_fout);
      tv = td->td_customValues + iCustom;
      fprintf(_coverage_fout, "388\n");
      fflush(_coverage_fout);
      if ((unsigned int )tv->value != (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "384\n");
        fflush(_coverage_fout);
        _TIFFfree(tv->value);
        fprintf(_coverage_fout, "385\n");
        fflush(_coverage_fout);
        tv->value = (void *)0;
      } else {
        fprintf(_coverage_fout, "386\n");
        fflush(_coverage_fout);

      }
      break;
    } else {
      fprintf(_coverage_fout, "389\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "392\n");
    fflush(_coverage_fout);
    iCustom ++;
  }
  fprintf(_coverage_fout, "614\n");
  fflush(_coverage_fout);
  if ((unsigned int )tv == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "396\n");
    fflush(_coverage_fout);
    (td->td_customValueCount) ++;
    fprintf(_coverage_fout, "397\n");
    fflush(_coverage_fout);
    tmp___45 = _TIFFrealloc((void *)td->td_customValues,
                            (long )(sizeof(TIFFTagValue ) * (unsigned int )td->td_customValueCount));
    fprintf(_coverage_fout, "398\n");
    fflush(_coverage_fout);
    new_customValues = (TIFFTagValue *)tmp___45;
    fprintf(_coverage_fout, "399\n");
    fflush(_coverage_fout);
    if (! new_customValues) {
      fprintf(_coverage_fout, "393\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module,
                   "%s: Failed to allocate space for list of custom values",
                   tif->tif_name);
      fprintf(_coverage_fout, "394\n");
      fflush(_coverage_fout);
      status = 0;
      goto end;
    } else {
      fprintf(_coverage_fout, "395\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "400\n");
    fflush(_coverage_fout);
    td->td_customValues = new_customValues;
    fprintf(_coverage_fout, "401\n");
    fflush(_coverage_fout);
    tv = td->td_customValues + (td->td_customValueCount - 1);
    fprintf(_coverage_fout, "402\n");
    fflush(_coverage_fout);
    tv->info = fip;
    fprintf(_coverage_fout, "403\n");
    fflush(_coverage_fout);
    tv->value = (void *)0;
    fprintf(_coverage_fout, "404\n");
    fflush(_coverage_fout);
    tv->count = 0;
  } else {
    fprintf(_coverage_fout, "405\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "615\n");
  fflush(_coverage_fout);
  tv_size = _TIFFDataSize((enum __anonenum_TIFFDataType_21 )fip->field_type);
  fprintf(_coverage_fout, "616\n");
  fflush(_coverage_fout);
  if (tv_size == 0) {
    fprintf(_coverage_fout, "406\n");
    fflush(_coverage_fout);
    status = 0;
    fprintf(_coverage_fout, "407\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module,
                 "%s: Bad field type %d for \"%s\"", tif->tif_name,
                 fip->field_type, fip->field_name);
    goto end;
  } else {
    fprintf(_coverage_fout, "408\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "617\n");
  fflush(_coverage_fout);
  if ((unsigned int const   )fip->field_type == 2U) {
    fprintf(_coverage_fout, "420\n");
    fflush(_coverage_fout);
    if (fip->field_passcount) {
      fprintf(_coverage_fout, "411\n");
      fflush(_coverage_fout);
      if ((int const   )fip->field_writecount == -3) {
        fprintf(_coverage_fout, "409\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "410\n");
        fflush(_coverage_fout);
        __assert_fail("fip->field_writecount==-3", "tif_dir.c", 474U,
                      "_TIFFVSetField");
      }
      fprintf(_coverage_fout, "412\n");
      fflush(_coverage_fout);
      tmp___46 = __builtin_va_arg(ap, uint32 );
      fprintf(_coverage_fout, "413\n");
      fflush(_coverage_fout);
      ma = tmp___46;
      fprintf(_coverage_fout, "414\n");
      fflush(_coverage_fout);
      tmp___47 = __builtin_va_arg(ap, char *);
      fprintf(_coverage_fout, "415\n");
      fflush(_coverage_fout);
      mb = tmp___47;
    } else {
      fprintf(_coverage_fout, "416\n");
      fflush(_coverage_fout);
      tmp___48 = __builtin_va_arg(ap, char *);
      fprintf(_coverage_fout, "417\n");
      fflush(_coverage_fout);
      mb = tmp___48;
      fprintf(_coverage_fout, "418\n");
      fflush(_coverage_fout);
      tmp___49 = strlen((char const   *)mb);
      fprintf(_coverage_fout, "419\n");
      fflush(_coverage_fout);
      ma = tmp___49 + 1U;
    }
    fprintf(_coverage_fout, "421\n");
    fflush(_coverage_fout);
    tv->count = (int )ma;
    fprintf(_coverage_fout, "422\n");
    fflush(_coverage_fout);
    setByteArray(& tv->value, (void *)mb, ma, 1U);
  } else {
    fprintf(_coverage_fout, "486\n");
    fflush(_coverage_fout);
    if (fip->field_passcount) {
      fprintf(_coverage_fout, "427\n");
      fflush(_coverage_fout);
      if ((int const   )fip->field_writecount == -3) {
        fprintf(_coverage_fout, "423\n");
        fflush(_coverage_fout);
        tmp___50 = __builtin_va_arg(ap, uint32 );
        fprintf(_coverage_fout, "424\n");
        fflush(_coverage_fout);
        tv->count = (int )tmp___50;
      } else {
        fprintf(_coverage_fout, "425\n");
        fflush(_coverage_fout);
        tmp___51 = __builtin_va_arg(ap, int );
        fprintf(_coverage_fout, "426\n");
        fflush(_coverage_fout);
        tv->count = tmp___51;
      }
    } else {
      fprintf(_coverage_fout, "434\n");
      fflush(_coverage_fout);
      if ((int const   )fip->field_writecount == -1) {
        fprintf(_coverage_fout, "428\n");
        fflush(_coverage_fout);
        tv->count = 1;
      } else {
        fprintf(_coverage_fout, "433\n");
        fflush(_coverage_fout);
        if ((int const   )fip->field_writecount == -3) {
          fprintf(_coverage_fout, "429\n");
          fflush(_coverage_fout);
          tv->count = 1;
        } else {
          fprintf(_coverage_fout, "432\n");
          fflush(_coverage_fout);
          if ((int const   )fip->field_writecount == -2) {
            fprintf(_coverage_fout, "430\n");
            fflush(_coverage_fout);
            tv->count = (int )td->td_samplesperpixel;
          } else {
            fprintf(_coverage_fout, "431\n");
            fflush(_coverage_fout);
            tv->count = (int )fip->field_writecount;
          }
        }
      }
    }
    fprintf(_coverage_fout, "487\n");
    fflush(_coverage_fout);
    tv->value = _TIFFCheckMalloc(tif, (long )tv_size, (long )tv->count,
                                 "Tag Value");
    fprintf(_coverage_fout, "488\n");
    fflush(_coverage_fout);
    if (! tv->value) {
      fprintf(_coverage_fout, "435\n");
      fflush(_coverage_fout);
      status = 0;
      goto end;
    } else {
      fprintf(_coverage_fout, "436\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "489\n");
    fflush(_coverage_fout);
    if (fip->field_passcount) {
      goto _L___7;
    } else {
      fprintf(_coverage_fout, "485\n");
      fflush(_coverage_fout);
      if ((int const   )fip->field_writecount == -1) {
        goto _L___7;
      } else {
        fprintf(_coverage_fout, "484\n");
        fflush(_coverage_fout);
        if ((int const   )fip->field_writecount == -3) {
          goto _L___7;
        } else {
          fprintf(_coverage_fout, "483\n");
          fflush(_coverage_fout);
          if ((int const   )fip->field_writecount == -2) {
            goto _L___7;
          } else {
            fprintf(_coverage_fout, "482\n");
            fflush(_coverage_fout);
            if (tv->count > 1) {
              fprintf(_coverage_fout, "442\n");
              fflush(_coverage_fout);
              _L___7: /* CIL Label */ 
              if (fip->field_tag != 297U) {
                fprintf(_coverage_fout, "441\n");
                fflush(_coverage_fout);
                if (fip->field_tag != 321U) {
                  fprintf(_coverage_fout, "440\n");
                  fflush(_coverage_fout);
                  if (fip->field_tag != 530U) {
                    fprintf(_coverage_fout, "439\n");
                    fflush(_coverage_fout);
                    if (fip->field_tag != 336U) {
                      fprintf(_coverage_fout, "437\n");
                      fflush(_coverage_fout);
                      tmp___52 = __builtin_va_arg(ap, void *);
                      fprintf(_coverage_fout, "438\n");
                      fflush(_coverage_fout);
                      _TIFFmemcpy(tv->value, (void const   *)tmp___52,
                                  (long )(tv->count * tv_size));
                    } else {
                      goto _L___6;
                    }
                  } else {
                    goto _L___6;
                  }
                } else {
                  goto _L___6;
                }
              } else {
                goto _L___6;
              }
            } else {
              fprintf(_coverage_fout, "479\n");
              fflush(_coverage_fout);
              _L___6: /* CIL Label */ 
              _L___5: /* CIL Label */ 
              _L___4: /* CIL Label */ 
              _L___3: /* CIL Label */ 
              val = (char *)tv->value;
              fprintf(_coverage_fout, "480\n");
              fflush(_coverage_fout);
              i___0 = 0;
              fprintf(_coverage_fout, "481\n");
              fflush(_coverage_fout);
              while (1) {
                fprintf(_coverage_fout, "476\n");
                fflush(_coverage_fout);
                if (i___0 < tv->count) {
                  fprintf(_coverage_fout, "443\n");
                  fflush(_coverage_fout);

                } else {
                  break;
                }
                switch ((int )fip->field_type) {
                fprintf(_coverage_fout, "444\n");
                fflush(_coverage_fout);
                case 1: 
                case 7: 
                tmp___53 = __builtin_va_arg(ap, int );
                fprintf(_coverage_fout, "445\n");
                fflush(_coverage_fout);
                v___0 = (unsigned char )tmp___53;
                fprintf(_coverage_fout, "446\n");
                fflush(_coverage_fout);
                _TIFFmemcpy((void *)val, (void const   *)(& v___0),
                            (long )tv_size);
                break;
                fprintf(_coverage_fout, "447\n");
                fflush(_coverage_fout);
                case 6: 
                tmp___54 = __builtin_va_arg(ap, int );
                fprintf(_coverage_fout, "448\n");
                fflush(_coverage_fout);
                v___1 = (signed char )tmp___54;
                fprintf(_coverage_fout, "449\n");
                fflush(_coverage_fout);
                _TIFFmemcpy((void *)val, (void const   *)(& v___1),
                            (long )tv_size);
                break;
                fprintf(_coverage_fout, "450\n");
                fflush(_coverage_fout);
                case 3: 
                tmp___55 = __builtin_va_arg(ap, int );
                fprintf(_coverage_fout, "451\n");
                fflush(_coverage_fout);
                v___2 = (unsigned short )tmp___55;
                fprintf(_coverage_fout, "452\n");
                fflush(_coverage_fout);
                _TIFFmemcpy((void *)val, (void const   *)(& v___2),
                            (long )tv_size);
                break;
                fprintf(_coverage_fout, "453\n");
                fflush(_coverage_fout);
                case 8: 
                tmp___56 = __builtin_va_arg(ap, int );
                fprintf(_coverage_fout, "454\n");
                fflush(_coverage_fout);
                v___3 = (short )tmp___56;
                fprintf(_coverage_fout, "455\n");
                fflush(_coverage_fout);
                _TIFFmemcpy((void *)val, (void const   *)(& v___3),
                            (long )tv_size);
                break;
                fprintf(_coverage_fout, "456\n");
                fflush(_coverage_fout);
                case 4: 
                case 13: 
                tmp___57 = __builtin_va_arg(ap, uint32 );
                fprintf(_coverage_fout, "457\n");
                fflush(_coverage_fout);
                v___4 = tmp___57;
                fprintf(_coverage_fout, "458\n");
                fflush(_coverage_fout);
                _TIFFmemcpy((void *)val, (void const   *)(& v___4),
                            (long )tv_size);
                break;
                fprintf(_coverage_fout, "459\n");
                fflush(_coverage_fout);
                case 9: 
                tmp___58 = __builtin_va_arg(ap, int32 );
                fprintf(_coverage_fout, "460\n");
                fflush(_coverage_fout);
                v___5 = tmp___58;
                fprintf(_coverage_fout, "461\n");
                fflush(_coverage_fout);
                _TIFFmemcpy((void *)val, (void const   *)(& v___5),
                            (long )tv_size);
                break;
                fprintf(_coverage_fout, "462\n");
                fflush(_coverage_fout);
                case 16: 
                case 18: 
                tmp___59 = __builtin_va_arg(ap, uint64 );
                fprintf(_coverage_fout, "463\n");
                fflush(_coverage_fout);
                v___6 = tmp___59;
                fprintf(_coverage_fout, "464\n");
                fflush(_coverage_fout);
                _TIFFmemcpy((void *)val, (void const   *)(& v___6),
                            (long )tv_size);
                break;
                fprintf(_coverage_fout, "465\n");
                fflush(_coverage_fout);
                case 17: 
                tmp___60 = __builtin_va_arg(ap, int64 );
                fprintf(_coverage_fout, "466\n");
                fflush(_coverage_fout);
                v___7 = tmp___60;
                fprintf(_coverage_fout, "467\n");
                fflush(_coverage_fout);
                _TIFFmemcpy((void *)val, (void const   *)(& v___7),
                            (long )tv_size);
                break;
                fprintf(_coverage_fout, "468\n");
                fflush(_coverage_fout);
                case 5: 
                case 10: 
                case 11: 
                tmp___61 = __builtin_va_arg(ap, double );
                fprintf(_coverage_fout, "469\n");
                fflush(_coverage_fout);
                v___8 = (float )tmp___61;
                fprintf(_coverage_fout, "470\n");
                fflush(_coverage_fout);
                _TIFFmemcpy((void *)val, (void const   *)(& v___8),
                            (long )tv_size);
                break;
                fprintf(_coverage_fout, "471\n");
                fflush(_coverage_fout);
                case 12: 
                tmp___62 = __builtin_va_arg(ap, double );
                fprintf(_coverage_fout, "472\n");
                fflush(_coverage_fout);
                v___9 = tmp___62;
                fprintf(_coverage_fout, "473\n");
                fflush(_coverage_fout);
                _TIFFmemcpy((void *)val, (void const   *)(& v___9),
                            (long )tv_size);
                break;
                fprintf(_coverage_fout, "474\n");
                fflush(_coverage_fout);
                default: 
                _TIFFmemset((void *)val, 0, (long )tv_size);
                fprintf(_coverage_fout, "475\n");
                fflush(_coverage_fout);
                status = 0;
                break;
                }
                fprintf(_coverage_fout, "477\n");
                fflush(_coverage_fout);
                i___0 ++;
                fprintf(_coverage_fout, "478\n");
                fflush(_coverage_fout);
                val += tv_size;
              }
            }
          }
        }
      }
    }
  }
  }
  fprintf(_coverage_fout, "625\n");
  fflush(_coverage_fout);
  if (status) {
    fprintf(_coverage_fout, "618\n");
    fflush(_coverage_fout);
    tmp___63 = TIFFFieldWithTag(tif, tag);
    fprintf(_coverage_fout, "619\n");
    fflush(_coverage_fout);
    tmp___64 = TIFFFieldWithTag(tif, tag);
    fprintf(_coverage_fout, "620\n");
    fflush(_coverage_fout);
    tif->tif_dir.td_fieldsset[(int const   )tmp___63->field_bit / 32] |= 1UL << ((int const   )tmp___64->field_bit & 31);
    fprintf(_coverage_fout, "621\n");
    fflush(_coverage_fout);
    tif->tif_flags |= 8U;
  } else {
    fprintf(_coverage_fout, "622\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "626\n");
  fflush(_coverage_fout);
  end: 
  __builtin_va_end(ap);
  fprintf(_coverage_fout, "627\n");
  fflush(_coverage_fout);
  return (status);
  fprintf(_coverage_fout, "628\n");
  fflush(_coverage_fout);
  badvalue: 
  tmp___65 = TIFFFieldWithTag(tif, tag);
  fprintf(_coverage_fout, "629\n");
  fflush(_coverage_fout);
  TIFFErrorExt(tif->tif_clientdata, module, "%s: Bad value %d for \"%s\" tag",
               tif->tif_name, v, tmp___65->field_name);
  fprintf(_coverage_fout, "630\n");
  fflush(_coverage_fout);
  __builtin_va_end(ap);
  fprintf(_coverage_fout, "631\n");
  fflush(_coverage_fout);
  return (0);
  fprintf(_coverage_fout, "632\n");
  fflush(_coverage_fout);
  badvalue32: 
  tmp___66 = TIFFFieldWithTag(tif, tag);
  fprintf(_coverage_fout, "633\n");
  fflush(_coverage_fout);
  TIFFErrorExt(tif->tif_clientdata, module, "%s: Bad value %ld for \"%s\" tag",
               tif->tif_name, v32, tmp___66->field_name);
  fprintf(_coverage_fout, "634\n");
  fflush(_coverage_fout);
  __builtin_va_end(ap);
  fprintf(_coverage_fout, "635\n");
  fflush(_coverage_fout);
  return (0);
}
}
static int OkToChangeTag(TIFF *tif , uint32 tag ) 
{ TIFFField const   *fip ;
  TIFFField const   *tmp ;
  char const   *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "649\n");
  fflush(_coverage_fout);
  tmp = TIFFFindField(tif, tag, (enum __anonenum_TIFFDataType_21 )0);
  fprintf(_coverage_fout, "650\n");
  fflush(_coverage_fout);
  fip = tmp;
  fprintf(_coverage_fout, "651\n");
  fflush(_coverage_fout);
  if (! fip) {
    fprintf(_coverage_fout, "638\n");
    fflush(_coverage_fout);
    if (tag > 65535U) {
      fprintf(_coverage_fout, "636\n");
      fflush(_coverage_fout);
      tmp___0 = "pseudo-";
    } else {
      fprintf(_coverage_fout, "637\n");
      fflush(_coverage_fout);
      tmp___0 = "";
    }
    fprintf(_coverage_fout, "639\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, "TIFFSetField", "%s: Unknown %stag %u",
                 tif->tif_name, tmp___0, tag);
    fprintf(_coverage_fout, "640\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "641\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "652\n");
  fflush(_coverage_fout);
  if (tag != 257U) {
    fprintf(_coverage_fout, "647\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 64U) {
      fprintf(_coverage_fout, "645\n");
      fflush(_coverage_fout);
      if (! fip->field_oktochange) {
        fprintf(_coverage_fout, "642\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, "TIFFSetField",
                     "%s: Cannot modify tag \"%s\" while writing",
                     tif->tif_name, fip->field_name);
        fprintf(_coverage_fout, "643\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "644\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "646\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "648\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "653\n");
  fflush(_coverage_fout);
  return (1);
}
}
int TIFFSetField(TIFF *tif , uint32 tag  , ...) 
{ va_list ap ;
  int status ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "654\n");
  fflush(_coverage_fout);
  __builtin_va_start(ap, tag);
  fprintf(_coverage_fout, "655\n");
  fflush(_coverage_fout);
  status = TIFFVSetField(tif, tag, ap);
  fprintf(_coverage_fout, "656\n");
  fflush(_coverage_fout);
  __builtin_va_end(ap);
  fprintf(_coverage_fout, "657\n");
  fflush(_coverage_fout);
  return (status);
}
}
int TIFFVSetField(TIFF *tif , uint32 tag , va_list ap ) 
{ int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "661\n");
  fflush(_coverage_fout);
  tmp___2 = OkToChangeTag(tif, tag);
  fprintf(_coverage_fout, "662\n");
  fflush(_coverage_fout);
  if (tmp___2) {
    fprintf(_coverage_fout, "658\n");
    fflush(_coverage_fout);
    tmp___0 = (*(tif->tif_tagmethods.vsetfield))(tif, tag, ap);
    fprintf(_coverage_fout, "659\n");
    fflush(_coverage_fout);
    tmp___1 = tmp___0;
  } else {
    fprintf(_coverage_fout, "660\n");
    fflush(_coverage_fout);
    tmp___1 = 0;
  }
  fprintf(_coverage_fout, "663\n");
  fflush(_coverage_fout);
  return (tmp___1);
}
}
static int _TIFFVGetField(TIFF *tif , uint32 tag , va_list ap ) 
{ TIFFDirectory *td ;
  int ret_val ;
  uint32 *tmp ;
  uint32 *tmp___0 ;
  uint32 *tmp___1 ;
  uint16 *tmp___2 ;
  uint16 *tmp___3 ;
  uint16 *tmp___4 ;
  uint16 *tmp___5 ;
  uint16 *tmp___6 ;
  uint16 *tmp___7 ;
  uint16 *tmp___8 ;
  uint32 *tmp___9 ;
  uint16 *tmp___10 ;
  uint16 *tmp___11 ;
  double *tmp___12 ;
  double *tmp___13 ;
  float *tmp___14 ;
  float *tmp___15 ;
  uint16 *tmp___16 ;
  float *tmp___17 ;
  float *tmp___18 ;
  uint16 *tmp___19 ;
  uint16 *tmp___20 ;
  uint16 *tmp___21 ;
  uint16 *tmp___22 ;
  uint16 *tmp___23 ;
  uint16 **tmp___24 ;
  uint16 **tmp___25 ;
  uint16 **tmp___26 ;
  uint64 **tmp___27 ;
  uint64 **tmp___28 ;
  uint16 *tmp___29 ;
  int tmp___30 ;
  uint16 *tmp___31 ;
  uint16 **tmp___32 ;
  uint32 *tmp___33 ;
  uint32 *tmp___34 ;
  uint32 *tmp___35 ;
  uint16 *tmp___36 ;
  uint16 *tmp___37 ;
  uint16 *tmp___38 ;
  uint16 *tmp___39 ;
  uint16 *tmp___40 ;
  uint32 *tmp___41 ;
  uint16 *tmp___42 ;
  uint64 **tmp___43 ;
  uint16 *tmp___44 ;
  uint16 *tmp___45 ;
  uint16 *tmp___46 ;
  uint16 **tmp___47 ;
  uint16 **tmp___48 ;
  uint16 **tmp___49 ;
  char **tmp___50 ;
  TIFFField const   *fip ;
  TIFFField const   *tmp___51 ;
  int i ;
  char const   *tmp___52 ;
  char const   *tmp___53 ;
  TIFFTagValue *tv ;
  uint32 *tmp___54 ;
  uint16 *tmp___55 ;
  void **tmp___56 ;
  void **tmp___57 ;
  int j ;
  char *val ;
  int tmp___58 ;
  uint8 *tmp___59 ;
  int8 *tmp___60 ;
  uint16 *tmp___61 ;
  int16 *tmp___62 ;
  uint32 *tmp___63 ;
  int32 *tmp___64 ;
  uint64 *tmp___65 ;
  int64 *tmp___66 ;
  float *tmp___67 ;
  double *tmp___68 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "855\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "856\n");
  fflush(_coverage_fout);
  ret_val = 1;
  switch ((int )tag) {
  fprintf(_coverage_fout, "757\n");
  fflush(_coverage_fout);
  case 254: 
  tmp = __builtin_va_arg(ap, uint32 *);
  fprintf(_coverage_fout, "758\n");
  fflush(_coverage_fout);
  *tmp = td->td_subfiletype;
  break;
  fprintf(_coverage_fout, "759\n");
  fflush(_coverage_fout);
  case 256: 
  tmp___0 = __builtin_va_arg(ap, uint32 *);
  fprintf(_coverage_fout, "760\n");
  fflush(_coverage_fout);
  *tmp___0 = td->td_imagewidth;
  break;
  fprintf(_coverage_fout, "761\n");
  fflush(_coverage_fout);
  case 257: 
  tmp___1 = __builtin_va_arg(ap, uint32 *);
  fprintf(_coverage_fout, "762\n");
  fflush(_coverage_fout);
  *tmp___1 = td->td_imagelength;
  break;
  fprintf(_coverage_fout, "763\n");
  fflush(_coverage_fout);
  case 258: 
  tmp___2 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "764\n");
  fflush(_coverage_fout);
  *tmp___2 = td->td_bitspersample;
  break;
  fprintf(_coverage_fout, "765\n");
  fflush(_coverage_fout);
  case 259: 
  tmp___3 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "766\n");
  fflush(_coverage_fout);
  *tmp___3 = td->td_compression;
  break;
  fprintf(_coverage_fout, "767\n");
  fflush(_coverage_fout);
  case 262: 
  tmp___4 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "768\n");
  fflush(_coverage_fout);
  *tmp___4 = td->td_photometric;
  break;
  fprintf(_coverage_fout, "769\n");
  fflush(_coverage_fout);
  case 263: 
  tmp___5 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "770\n");
  fflush(_coverage_fout);
  *tmp___5 = td->td_threshholding;
  break;
  fprintf(_coverage_fout, "771\n");
  fflush(_coverage_fout);
  case 266: 
  tmp___6 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "772\n");
  fflush(_coverage_fout);
  *tmp___6 = td->td_fillorder;
  break;
  fprintf(_coverage_fout, "773\n");
  fflush(_coverage_fout);
  case 274: 
  tmp___7 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "774\n");
  fflush(_coverage_fout);
  *tmp___7 = td->td_orientation;
  break;
  fprintf(_coverage_fout, "775\n");
  fflush(_coverage_fout);
  case 277: 
  tmp___8 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "776\n");
  fflush(_coverage_fout);
  *tmp___8 = td->td_samplesperpixel;
  break;
  fprintf(_coverage_fout, "777\n");
  fflush(_coverage_fout);
  case 278: 
  tmp___9 = __builtin_va_arg(ap, uint32 *);
  fprintf(_coverage_fout, "778\n");
  fflush(_coverage_fout);
  *tmp___9 = td->td_rowsperstrip;
  break;
  fprintf(_coverage_fout, "779\n");
  fflush(_coverage_fout);
  case 280: 
  tmp___10 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "780\n");
  fflush(_coverage_fout);
  *tmp___10 = td->td_minsamplevalue;
  break;
  fprintf(_coverage_fout, "781\n");
  fflush(_coverage_fout);
  case 281: 
  tmp___11 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "782\n");
  fflush(_coverage_fout);
  *tmp___11 = td->td_maxsamplevalue;
  break;
  fprintf(_coverage_fout, "783\n");
  fflush(_coverage_fout);
  case 340: 
  tmp___12 = __builtin_va_arg(ap, double *);
  fprintf(_coverage_fout, "784\n");
  fflush(_coverage_fout);
  *tmp___12 = td->td_sminsamplevalue;
  break;
  fprintf(_coverage_fout, "785\n");
  fflush(_coverage_fout);
  case 341: 
  tmp___13 = __builtin_va_arg(ap, double *);
  fprintf(_coverage_fout, "786\n");
  fflush(_coverage_fout);
  *tmp___13 = td->td_smaxsamplevalue;
  break;
  fprintf(_coverage_fout, "787\n");
  fflush(_coverage_fout);
  case 282: 
  tmp___14 = __builtin_va_arg(ap, float *);
  fprintf(_coverage_fout, "788\n");
  fflush(_coverage_fout);
  *tmp___14 = td->td_xresolution;
  break;
  fprintf(_coverage_fout, "789\n");
  fflush(_coverage_fout);
  case 283: 
  tmp___15 = __builtin_va_arg(ap, float *);
  fprintf(_coverage_fout, "790\n");
  fflush(_coverage_fout);
  *tmp___15 = td->td_yresolution;
  break;
  fprintf(_coverage_fout, "791\n");
  fflush(_coverage_fout);
  case 284: 
  tmp___16 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "792\n");
  fflush(_coverage_fout);
  *tmp___16 = td->td_planarconfig;
  break;
  fprintf(_coverage_fout, "793\n");
  fflush(_coverage_fout);
  case 286: 
  tmp___17 = __builtin_va_arg(ap, float *);
  fprintf(_coverage_fout, "794\n");
  fflush(_coverage_fout);
  *tmp___17 = td->td_xposition;
  break;
  fprintf(_coverage_fout, "795\n");
  fflush(_coverage_fout);
  case 287: 
  tmp___18 = __builtin_va_arg(ap, float *);
  fprintf(_coverage_fout, "796\n");
  fflush(_coverage_fout);
  *tmp___18 = td->td_yposition;
  break;
  fprintf(_coverage_fout, "797\n");
  fflush(_coverage_fout);
  case 296: 
  tmp___19 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "798\n");
  fflush(_coverage_fout);
  *tmp___19 = td->td_resolutionunit;
  break;
  fprintf(_coverage_fout, "799\n");
  fflush(_coverage_fout);
  case 297: 
  tmp___20 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "800\n");
  fflush(_coverage_fout);
  *tmp___20 = td->td_pagenumber[0];
  fprintf(_coverage_fout, "801\n");
  fflush(_coverage_fout);
  tmp___21 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "802\n");
  fflush(_coverage_fout);
  *tmp___21 = td->td_pagenumber[1];
  break;
  fprintf(_coverage_fout, "803\n");
  fflush(_coverage_fout);
  case 321: 
  tmp___22 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "804\n");
  fflush(_coverage_fout);
  *tmp___22 = td->td_halftonehints[0];
  fprintf(_coverage_fout, "805\n");
  fflush(_coverage_fout);
  tmp___23 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "806\n");
  fflush(_coverage_fout);
  *tmp___23 = td->td_halftonehints[1];
  break;
  fprintf(_coverage_fout, "807\n");
  fflush(_coverage_fout);
  case 320: 
  tmp___24 = __builtin_va_arg(ap, uint16 **);
  fprintf(_coverage_fout, "808\n");
  fflush(_coverage_fout);
  *tmp___24 = td->td_colormap[0];
  fprintf(_coverage_fout, "809\n");
  fflush(_coverage_fout);
  tmp___25 = __builtin_va_arg(ap, uint16 **);
  fprintf(_coverage_fout, "810\n");
  fflush(_coverage_fout);
  *tmp___25 = td->td_colormap[1];
  fprintf(_coverage_fout, "811\n");
  fflush(_coverage_fout);
  tmp___26 = __builtin_va_arg(ap, uint16 **);
  fprintf(_coverage_fout, "812\n");
  fflush(_coverage_fout);
  *tmp___26 = td->td_colormap[2];
  break;
  fprintf(_coverage_fout, "813\n");
  fflush(_coverage_fout);
  case 273: 
  case 324: 
  tmp___27 = __builtin_va_arg(ap, uint64 **);
  fprintf(_coverage_fout, "814\n");
  fflush(_coverage_fout);
  *tmp___27 = td->td_stripoffset;
  break;
  fprintf(_coverage_fout, "815\n");
  fflush(_coverage_fout);
  case 279: 
  case 325: 
  tmp___28 = __builtin_va_arg(ap, uint64 **);
  fprintf(_coverage_fout, "816\n");
  fflush(_coverage_fout);
  *tmp___28 = td->td_stripbytecount;
  break;
  fprintf(_coverage_fout, "817\n");
  fflush(_coverage_fout);
  case 32995: 
  tmp___29 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "818\n");
  fflush(_coverage_fout);
  if ((int )td->td_extrasamples == 1) {
    fprintf(_coverage_fout, "666\n");
    fflush(_coverage_fout);
    if ((int )*(td->td_sampleinfo + 0) == 1) {
      fprintf(_coverage_fout, "664\n");
      fflush(_coverage_fout);
      tmp___30 = 1;
    } else {
      fprintf(_coverage_fout, "665\n");
      fflush(_coverage_fout);
      tmp___30 = 0;
    }
  } else {
    fprintf(_coverage_fout, "667\n");
    fflush(_coverage_fout);
    tmp___30 = 0;
  }
  fprintf(_coverage_fout, "819\n");
  fflush(_coverage_fout);
  *tmp___29 = (unsigned short )tmp___30;
  break;
  fprintf(_coverage_fout, "820\n");
  fflush(_coverage_fout);
  case 338: 
  tmp___31 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "821\n");
  fflush(_coverage_fout);
  *tmp___31 = td->td_extrasamples;
  fprintf(_coverage_fout, "822\n");
  fflush(_coverage_fout);
  tmp___32 = __builtin_va_arg(ap, uint16 **);
  fprintf(_coverage_fout, "823\n");
  fflush(_coverage_fout);
  *tmp___32 = td->td_sampleinfo;
  break;
  fprintf(_coverage_fout, "824\n");
  fflush(_coverage_fout);
  case 322: 
  tmp___33 = __builtin_va_arg(ap, uint32 *);
  fprintf(_coverage_fout, "825\n");
  fflush(_coverage_fout);
  *tmp___33 = td->td_tilewidth;
  break;
  fprintf(_coverage_fout, "826\n");
  fflush(_coverage_fout);
  case 323: 
  tmp___34 = __builtin_va_arg(ap, uint32 *);
  fprintf(_coverage_fout, "827\n");
  fflush(_coverage_fout);
  *tmp___34 = td->td_tilelength;
  break;
  fprintf(_coverage_fout, "828\n");
  fflush(_coverage_fout);
  case 32998: 
  tmp___35 = __builtin_va_arg(ap, uint32 *);
  fprintf(_coverage_fout, "829\n");
  fflush(_coverage_fout);
  *tmp___35 = td->td_tiledepth;
  break;
  case 32996: 
  switch ((int )td->td_sampleformat) {
  fprintf(_coverage_fout, "668\n");
  fflush(_coverage_fout);
  case 1: 
  tmp___36 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "669\n");
  fflush(_coverage_fout);
  *tmp___36 = (unsigned short)2;
  break;
  fprintf(_coverage_fout, "670\n");
  fflush(_coverage_fout);
  case 2: 
  tmp___37 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "671\n");
  fflush(_coverage_fout);
  *tmp___37 = (unsigned short)1;
  break;
  fprintf(_coverage_fout, "672\n");
  fflush(_coverage_fout);
  case 3: 
  tmp___38 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "673\n");
  fflush(_coverage_fout);
  *tmp___38 = (unsigned short)3;
  break;
  fprintf(_coverage_fout, "674\n");
  fflush(_coverage_fout);
  case 4: 
  tmp___39 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "675\n");
  fflush(_coverage_fout);
  *tmp___39 = (unsigned short)0;
  break;
  }
  break;
  fprintf(_coverage_fout, "830\n");
  fflush(_coverage_fout);
  case 339: 
  tmp___40 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "831\n");
  fflush(_coverage_fout);
  *tmp___40 = td->td_sampleformat;
  break;
  fprintf(_coverage_fout, "832\n");
  fflush(_coverage_fout);
  case 32997: 
  tmp___41 = __builtin_va_arg(ap, uint32 *);
  fprintf(_coverage_fout, "833\n");
  fflush(_coverage_fout);
  *tmp___41 = td->td_imagedepth;
  break;
  fprintf(_coverage_fout, "834\n");
  fflush(_coverage_fout);
  case 330: 
  tmp___42 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "835\n");
  fflush(_coverage_fout);
  *tmp___42 = td->td_nsubifd;
  fprintf(_coverage_fout, "836\n");
  fflush(_coverage_fout);
  tmp___43 = __builtin_va_arg(ap, uint64 **);
  fprintf(_coverage_fout, "837\n");
  fflush(_coverage_fout);
  *tmp___43 = td->td_subifd;
  break;
  fprintf(_coverage_fout, "838\n");
  fflush(_coverage_fout);
  case 531: 
  tmp___44 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "839\n");
  fflush(_coverage_fout);
  *tmp___44 = td->td_ycbcrpositioning;
  break;
  fprintf(_coverage_fout, "840\n");
  fflush(_coverage_fout);
  case 530: 
  tmp___45 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "841\n");
  fflush(_coverage_fout);
  *tmp___45 = td->td_ycbcrsubsampling[0];
  fprintf(_coverage_fout, "842\n");
  fflush(_coverage_fout);
  tmp___46 = __builtin_va_arg(ap, uint16 *);
  fprintf(_coverage_fout, "843\n");
  fflush(_coverage_fout);
  *tmp___46 = td->td_ycbcrsubsampling[1];
  break;
  fprintf(_coverage_fout, "844\n");
  fflush(_coverage_fout);
  case 301: 
  tmp___47 = __builtin_va_arg(ap, uint16 **);
  fprintf(_coverage_fout, "845\n");
  fflush(_coverage_fout);
  *tmp___47 = td->td_transferfunction[0];
  fprintf(_coverage_fout, "846\n");
  fflush(_coverage_fout);
  if ((int )td->td_samplesperpixel - (int )td->td_extrasamples > 1) {
    fprintf(_coverage_fout, "676\n");
    fflush(_coverage_fout);
    tmp___48 = __builtin_va_arg(ap, uint16 **);
    fprintf(_coverage_fout, "677\n");
    fflush(_coverage_fout);
    *tmp___48 = td->td_transferfunction[1];
    fprintf(_coverage_fout, "678\n");
    fflush(_coverage_fout);
    tmp___49 = __builtin_va_arg(ap, uint16 **);
    fprintf(_coverage_fout, "679\n");
    fflush(_coverage_fout);
    *tmp___49 = td->td_transferfunction[2];
  } else {
    fprintf(_coverage_fout, "680\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "847\n");
  fflush(_coverage_fout);
  case 333: 
  tmp___50 = __builtin_va_arg(ap, char **);
  fprintf(_coverage_fout, "848\n");
  fflush(_coverage_fout);
  *tmp___50 = td->td_inknames;
  break;
  fprintf(_coverage_fout, "849\n");
  fflush(_coverage_fout);
  default: 
  tmp___51 = TIFFFindField(tif, tag, (enum __anonenum_TIFFDataType_21 )0);
  fprintf(_coverage_fout, "850\n");
  fflush(_coverage_fout);
  fip = tmp___51;
  fprintf(_coverage_fout, "851\n");
  fflush(_coverage_fout);
  if ((unsigned int )fip == (unsigned int )((void *)0)) {
    goto _L;
  } else {
    fprintf(_coverage_fout, "690\n");
    fflush(_coverage_fout);
    if ((int const   )fip->field_bit != 65) {
      fprintf(_coverage_fout, "685\n");
      fflush(_coverage_fout);
      _L: /* CIL Label */ 
      if (fip) {
        fprintf(_coverage_fout, "681\n");
        fflush(_coverage_fout);
        tmp___52 = (char const   */* const  */)fip->field_name;
      } else {
        fprintf(_coverage_fout, "682\n");
        fflush(_coverage_fout);
        tmp___52 = (char const   */* const  */)"Unknown";
      }
      fprintf(_coverage_fout, "686\n");
      fflush(_coverage_fout);
      if (tag > 65535U) {
        fprintf(_coverage_fout, "683\n");
        fflush(_coverage_fout);
        tmp___53 = "pseudo-";
      } else {
        fprintf(_coverage_fout, "684\n");
        fflush(_coverage_fout);
        tmp___53 = "";
      }
      fprintf(_coverage_fout, "687\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, "_TIFFVGetField",
                   "%s: Invalid %stag \"%s\" (not supported by codec)",
                   tif->tif_name, tmp___53, tmp___52);
      fprintf(_coverage_fout, "688\n");
      fflush(_coverage_fout);
      ret_val = 0;
      break;
    } else {
      fprintf(_coverage_fout, "689\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "852\n");
  fflush(_coverage_fout);
  ret_val = 0;
  fprintf(_coverage_fout, "853\n");
  fflush(_coverage_fout);
  i = 0;
  fprintf(_coverage_fout, "854\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "752\n");
    fflush(_coverage_fout);
    if (i < td->td_customValueCount) {
      fprintf(_coverage_fout, "691\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "753\n");
    fflush(_coverage_fout);
    tv = td->td_customValues + i;
    fprintf(_coverage_fout, "754\n");
    fflush(_coverage_fout);
    if ((tv->info)->field_tag != (uint32 const   )tag) {
      goto __Cont;
    } else {
      fprintf(_coverage_fout, "692\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "755\n");
    fflush(_coverage_fout);
    if (fip->field_passcount) {
      fprintf(_coverage_fout, "697\n");
      fflush(_coverage_fout);
      if ((int const   )fip->field_readcount == -3) {
        fprintf(_coverage_fout, "693\n");
        fflush(_coverage_fout);
        tmp___54 = __builtin_va_arg(ap, uint32 *);
        fprintf(_coverage_fout, "694\n");
        fflush(_coverage_fout);
        *tmp___54 = (unsigned int )tv->count;
      } else {
        fprintf(_coverage_fout, "695\n");
        fflush(_coverage_fout);
        tmp___55 = __builtin_va_arg(ap, uint16 *);
        fprintf(_coverage_fout, "696\n");
        fflush(_coverage_fout);
        *tmp___55 = (unsigned short )tv->count;
      }
      fprintf(_coverage_fout, "698\n");
      fflush(_coverage_fout);
      tmp___56 = __builtin_va_arg(ap, void **);
      fprintf(_coverage_fout, "699\n");
      fflush(_coverage_fout);
      *tmp___56 = tv->value;
      fprintf(_coverage_fout, "700\n");
      fflush(_coverage_fout);
      ret_val = 1;
    } else {
      fprintf(_coverage_fout, "751\n");
      fflush(_coverage_fout);
      if ((unsigned int const   )fip->field_type == 2U) {
        goto _L___4;
      } else {
        fprintf(_coverage_fout, "750\n");
        fflush(_coverage_fout);
        if ((int const   )fip->field_readcount == -1) {
          goto _L___4;
        } else {
          fprintf(_coverage_fout, "749\n");
          fflush(_coverage_fout);
          if ((int const   )fip->field_readcount == -3) {
            goto _L___4;
          } else {
            fprintf(_coverage_fout, "748\n");
            fflush(_coverage_fout);
            if ((int const   )fip->field_readcount == -2) {
              goto _L___4;
            } else {
              fprintf(_coverage_fout, "747\n");
              fflush(_coverage_fout);
              if (tv->count > 1) {
                fprintf(_coverage_fout, "707\n");
                fflush(_coverage_fout);
                _L___4: /* CIL Label */ 
                if (fip->field_tag != 297U) {
                  fprintf(_coverage_fout, "706\n");
                  fflush(_coverage_fout);
                  if (fip->field_tag != 321U) {
                    fprintf(_coverage_fout, "705\n");
                    fflush(_coverage_fout);
                    if (fip->field_tag != 530U) {
                      fprintf(_coverage_fout, "704\n");
                      fflush(_coverage_fout);
                      if (fip->field_tag != 336U) {
                        fprintf(_coverage_fout, "701\n");
                        fflush(_coverage_fout);
                        tmp___57 = __builtin_va_arg(ap, void **);
                        fprintf(_coverage_fout, "702\n");
                        fflush(_coverage_fout);
                        *tmp___57 = tv->value;
                        fprintf(_coverage_fout, "703\n");
                        fflush(_coverage_fout);
                        ret_val = 1;
                      } else {
                        goto _L___3;
                      }
                    } else {
                      goto _L___3;
                    }
                  } else {
                    goto _L___3;
                  }
                } else {
                  goto _L___3;
                }
              } else {
                fprintf(_coverage_fout, "744\n");
                fflush(_coverage_fout);
                _L___3: /* CIL Label */ 
                _L___2: /* CIL Label */ 
                _L___1: /* CIL Label */ 
                _L___0: /* CIL Label */ 
                val = (char *)tv->value;
                fprintf(_coverage_fout, "745\n");
                fflush(_coverage_fout);
                j = 0;
                fprintf(_coverage_fout, "746\n");
                fflush(_coverage_fout);
                while (1) {
                  fprintf(_coverage_fout, "740\n");
                  fflush(_coverage_fout);
                  if (j < tv->count) {
                    fprintf(_coverage_fout, "708\n");
                    fflush(_coverage_fout);

                  } else {
                    break;
                  }
                  switch ((int )fip->field_type) {
                  fprintf(_coverage_fout, "709\n");
                  fflush(_coverage_fout);
                  case 1: 
                  case 7: 
                  tmp___59 = __builtin_va_arg(ap, uint8 *);
                  fprintf(_coverage_fout, "710\n");
                  fflush(_coverage_fout);
                  *tmp___59 = *((uint8 *)val);
                  fprintf(_coverage_fout, "711\n");
                  fflush(_coverage_fout);
                  ret_val = 1;
                  break;
                  fprintf(_coverage_fout, "712\n");
                  fflush(_coverage_fout);
                  case 6: 
                  tmp___60 = __builtin_va_arg(ap, int8 *);
                  fprintf(_coverage_fout, "713\n");
                  fflush(_coverage_fout);
                  *tmp___60 = *((int8 *)val);
                  fprintf(_coverage_fout, "714\n");
                  fflush(_coverage_fout);
                  ret_val = 1;
                  break;
                  fprintf(_coverage_fout, "715\n");
                  fflush(_coverage_fout);
                  case 3: 
                  tmp___61 = __builtin_va_arg(ap, uint16 *);
                  fprintf(_coverage_fout, "716\n");
                  fflush(_coverage_fout);
                  *tmp___61 = *((uint16 *)val);
                  fprintf(_coverage_fout, "717\n");
                  fflush(_coverage_fout);
                  ret_val = 1;
                  break;
                  fprintf(_coverage_fout, "718\n");
                  fflush(_coverage_fout);
                  case 8: 
                  tmp___62 = __builtin_va_arg(ap, int16 *);
                  fprintf(_coverage_fout, "719\n");
                  fflush(_coverage_fout);
                  *tmp___62 = *((int16 *)val);
                  fprintf(_coverage_fout, "720\n");
                  fflush(_coverage_fout);
                  ret_val = 1;
                  break;
                  fprintf(_coverage_fout, "721\n");
                  fflush(_coverage_fout);
                  case 4: 
                  case 13: 
                  tmp___63 = __builtin_va_arg(ap, uint32 *);
                  fprintf(_coverage_fout, "722\n");
                  fflush(_coverage_fout);
                  *tmp___63 = *((uint32 *)val);
                  fprintf(_coverage_fout, "723\n");
                  fflush(_coverage_fout);
                  ret_val = 1;
                  break;
                  fprintf(_coverage_fout, "724\n");
                  fflush(_coverage_fout);
                  case 9: 
                  tmp___64 = __builtin_va_arg(ap, int32 *);
                  fprintf(_coverage_fout, "725\n");
                  fflush(_coverage_fout);
                  *tmp___64 = *((int32 *)val);
                  fprintf(_coverage_fout, "726\n");
                  fflush(_coverage_fout);
                  ret_val = 1;
                  break;
                  fprintf(_coverage_fout, "727\n");
                  fflush(_coverage_fout);
                  case 16: 
                  case 18: 
                  tmp___65 = __builtin_va_arg(ap, uint64 *);
                  fprintf(_coverage_fout, "728\n");
                  fflush(_coverage_fout);
                  *tmp___65 = *((uint64 *)val);
                  fprintf(_coverage_fout, "729\n");
                  fflush(_coverage_fout);
                  ret_val = 1;
                  break;
                  fprintf(_coverage_fout, "730\n");
                  fflush(_coverage_fout);
                  case 17: 
                  tmp___66 = __builtin_va_arg(ap, int64 *);
                  fprintf(_coverage_fout, "731\n");
                  fflush(_coverage_fout);
                  *tmp___66 = *((int64 *)val);
                  fprintf(_coverage_fout, "732\n");
                  fflush(_coverage_fout);
                  ret_val = 1;
                  break;
                  fprintf(_coverage_fout, "733\n");
                  fflush(_coverage_fout);
                  case 5: 
                  case 10: 
                  case 11: 
                  tmp___67 = __builtin_va_arg(ap, float *);
                  fprintf(_coverage_fout, "734\n");
                  fflush(_coverage_fout);
                  *tmp___67 = *((float *)val);
                  fprintf(_coverage_fout, "735\n");
                  fflush(_coverage_fout);
                  ret_val = 1;
                  break;
                  fprintf(_coverage_fout, "736\n");
                  fflush(_coverage_fout);
                  case 12: 
                  tmp___68 = __builtin_va_arg(ap, double *);
                  fprintf(_coverage_fout, "737\n");
                  fflush(_coverage_fout);
                  *tmp___68 = *((double *)val);
                  fprintf(_coverage_fout, "738\n");
                  fflush(_coverage_fout);
                  ret_val = 1;
                  break;
                  fprintf(_coverage_fout, "739\n");
                  fflush(_coverage_fout);
                  default: 
                  ret_val = 0;
                  break;
                  }
                  fprintf(_coverage_fout, "741\n");
                  fflush(_coverage_fout);
                  j ++;
                  fprintf(_coverage_fout, "742\n");
                  fflush(_coverage_fout);
                  tmp___58 = _TIFFDataSize((enum __anonenum_TIFFDataType_21 )(tv->info)->field_type);
                  fprintf(_coverage_fout, "743\n");
                  fflush(_coverage_fout);
                  val += tmp___58;
                }
              }
            }
          }
        }
      }
    }
    break;
    fprintf(_coverage_fout, "756\n");
    fflush(_coverage_fout);
    __Cont: /* CIL Label */ 
    i ++;
  }
  }
  fprintf(_coverage_fout, "857\n");
  fflush(_coverage_fout);
  return (ret_val);
}
}
int TIFFGetField(TIFF *tif , uint32 tag  , ...) 
{ int status ;
  va_list ap ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "858\n");
  fflush(_coverage_fout);
  __builtin_va_start(ap, tag);
  fprintf(_coverage_fout, "859\n");
  fflush(_coverage_fout);
  status = TIFFVGetField(tif, tag, ap);
  fprintf(_coverage_fout, "860\n");
  fflush(_coverage_fout);
  __builtin_va_end(ap);
  fprintf(_coverage_fout, "861\n");
  fflush(_coverage_fout);
  return (status);
}
}
int TIFFVGetField(TIFF *tif , uint32 tag , va_list ap ) 
{ TIFFField const   *fip ;
  TIFFField const   *tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "870\n");
  fflush(_coverage_fout);
  tmp = TIFFFindField(tif, tag, (enum __anonenum_TIFFDataType_21 )0);
  fprintf(_coverage_fout, "871\n");
  fflush(_coverage_fout);
  fip = tmp;
  fprintf(_coverage_fout, "872\n");
  fflush(_coverage_fout);
  if (fip) {
    fprintf(_coverage_fout, "868\n");
    fflush(_coverage_fout);
    if (tag > 65535U) {
      fprintf(_coverage_fout, "862\n");
      fflush(_coverage_fout);
      tmp___0 = (*(tif->tif_tagmethods.vgetfield))(tif, tag, ap);
      fprintf(_coverage_fout, "863\n");
      fflush(_coverage_fout);
      tmp___1 = tmp___0;
    } else {
      fprintf(_coverage_fout, "867\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[(int const   )fip->field_bit / 32] & (1UL << ((int const   )fip->field_bit & 31))) {
        fprintf(_coverage_fout, "864\n");
        fflush(_coverage_fout);
        tmp___0 = (*(tif->tif_tagmethods.vgetfield))(tif, tag, ap);
        fprintf(_coverage_fout, "865\n");
        fflush(_coverage_fout);
        tmp___1 = tmp___0;
      } else {
        fprintf(_coverage_fout, "866\n");
        fflush(_coverage_fout);
        tmp___1 = 0;
      }
    }
  } else {
    fprintf(_coverage_fout, "869\n");
    fflush(_coverage_fout);
    tmp___1 = 0;
  }
  fprintf(_coverage_fout, "873\n");
  fflush(_coverage_fout);
  return (tmp___1);
}
}
void TIFFFreeDirectory(TIFF *tif ) 
{ TIFFDirectory *td ;
  int i ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "916\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "917\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)(td->td_fieldsset), 0, 4L);
  fprintf(_coverage_fout, "918\n");
  fflush(_coverage_fout);
  if (td->td_colormap[0]) {
    fprintf(_coverage_fout, "874\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)td->td_colormap[0]);
    fprintf(_coverage_fout, "875\n");
    fflush(_coverage_fout);
    td->td_colormap[0] = (uint16 *)0;
  } else {
    fprintf(_coverage_fout, "876\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "919\n");
  fflush(_coverage_fout);
  if (td->td_colormap[1]) {
    fprintf(_coverage_fout, "877\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)td->td_colormap[1]);
    fprintf(_coverage_fout, "878\n");
    fflush(_coverage_fout);
    td->td_colormap[1] = (uint16 *)0;
  } else {
    fprintf(_coverage_fout, "879\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "920\n");
  fflush(_coverage_fout);
  if (td->td_colormap[2]) {
    fprintf(_coverage_fout, "880\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)td->td_colormap[2]);
    fprintf(_coverage_fout, "881\n");
    fflush(_coverage_fout);
    td->td_colormap[2] = (uint16 *)0;
  } else {
    fprintf(_coverage_fout, "882\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "921\n");
  fflush(_coverage_fout);
  if (td->td_sampleinfo) {
    fprintf(_coverage_fout, "883\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)td->td_sampleinfo);
    fprintf(_coverage_fout, "884\n");
    fflush(_coverage_fout);
    td->td_sampleinfo = (uint16 *)0;
  } else {
    fprintf(_coverage_fout, "885\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "922\n");
  fflush(_coverage_fout);
  if (td->td_subifd) {
    fprintf(_coverage_fout, "886\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)td->td_subifd);
    fprintf(_coverage_fout, "887\n");
    fflush(_coverage_fout);
    td->td_subifd = (uint64 *)0;
  } else {
    fprintf(_coverage_fout, "888\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "923\n");
  fflush(_coverage_fout);
  if (td->td_inknames) {
    fprintf(_coverage_fout, "889\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)td->td_inknames);
    fprintf(_coverage_fout, "890\n");
    fflush(_coverage_fout);
    td->td_inknames = (char *)0;
  } else {
    fprintf(_coverage_fout, "891\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "924\n");
  fflush(_coverage_fout);
  if (td->td_transferfunction[0]) {
    fprintf(_coverage_fout, "892\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)td->td_transferfunction[0]);
    fprintf(_coverage_fout, "893\n");
    fflush(_coverage_fout);
    td->td_transferfunction[0] = (uint16 *)0;
  } else {
    fprintf(_coverage_fout, "894\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "925\n");
  fflush(_coverage_fout);
  if (td->td_transferfunction[1]) {
    fprintf(_coverage_fout, "895\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)td->td_transferfunction[1]);
    fprintf(_coverage_fout, "896\n");
    fflush(_coverage_fout);
    td->td_transferfunction[1] = (uint16 *)0;
  } else {
    fprintf(_coverage_fout, "897\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "926\n");
  fflush(_coverage_fout);
  if (td->td_transferfunction[2]) {
    fprintf(_coverage_fout, "898\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)td->td_transferfunction[2]);
    fprintf(_coverage_fout, "899\n");
    fflush(_coverage_fout);
    td->td_transferfunction[2] = (uint16 *)0;
  } else {
    fprintf(_coverage_fout, "900\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "927\n");
  fflush(_coverage_fout);
  if (td->td_stripoffset) {
    fprintf(_coverage_fout, "901\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)td->td_stripoffset);
    fprintf(_coverage_fout, "902\n");
    fflush(_coverage_fout);
    td->td_stripoffset = (uint64 *)0;
  } else {
    fprintf(_coverage_fout, "903\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "928\n");
  fflush(_coverage_fout);
  if (td->td_stripbytecount) {
    fprintf(_coverage_fout, "904\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)td->td_stripbytecount);
    fprintf(_coverage_fout, "905\n");
    fflush(_coverage_fout);
    td->td_stripbytecount = (uint64 *)0;
  } else {
    fprintf(_coverage_fout, "906\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "929\n");
  fflush(_coverage_fout);
  tif->tif_dir.td_fieldsset[1] &= ~ (1UL << 7);
  fprintf(_coverage_fout, "930\n");
  fflush(_coverage_fout);
  tif->tif_dir.td_fieldsset[1] &= ~ (1UL << 8);
  fprintf(_coverage_fout, "931\n");
  fflush(_coverage_fout);
  i = 0;
  fprintf(_coverage_fout, "932\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "910\n");
    fflush(_coverage_fout);
    if (i < td->td_customValueCount) {
      fprintf(_coverage_fout, "907\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "911\n");
    fflush(_coverage_fout);
    if ((td->td_customValues + i)->value) {
      fprintf(_coverage_fout, "908\n");
      fflush(_coverage_fout);
      _TIFFfree((td->td_customValues + i)->value);
    } else {
      fprintf(_coverage_fout, "909\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "912\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "933\n");
  fflush(_coverage_fout);
  td->td_customValueCount = 0;
  fprintf(_coverage_fout, "934\n");
  fflush(_coverage_fout);
  if (td->td_customValues) {
    fprintf(_coverage_fout, "913\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)td->td_customValues);
    fprintf(_coverage_fout, "914\n");
    fflush(_coverage_fout);
    td->td_customValues = (TIFFTagValue *)0;
  } else {
    fprintf(_coverage_fout, "915\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "935\n");
  fflush(_coverage_fout);
  return;
}
}
static void (*_TIFFextender)(TIFF * )  =    (void (*)(TIFF * ))((void *)0);
TIFFExtendProc TIFFSetTagExtender(void (*extender)(TIFF * ) ) 
{ void (*prev)(TIFF * ) ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "936\n");
  fflush(_coverage_fout);
  prev = _TIFFextender;
  fprintf(_coverage_fout, "937\n");
  fflush(_coverage_fout);
  _TIFFextender = extender;
  fprintf(_coverage_fout, "938\n");
  fflush(_coverage_fout);
  return (prev);
}
}
int TIFFCreateDirectory(TIFF *tif ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "939\n");
  fflush(_coverage_fout);
  TIFFDefaultDirectory(tif);
  fprintf(_coverage_fout, "940\n");
  fflush(_coverage_fout);
  tif->tif_diroff = 0ULL;
  fprintf(_coverage_fout, "941\n");
  fflush(_coverage_fout);
  tif->tif_nextdiroff = 0ULL;
  fprintf(_coverage_fout, "942\n");
  fflush(_coverage_fout);
  tif->tif_curoff = 0ULL;
  fprintf(_coverage_fout, "943\n");
  fflush(_coverage_fout);
  tif->tif_row = 4294967295U;
  fprintf(_coverage_fout, "944\n");
  fflush(_coverage_fout);
  tif->tif_curstrip = 4294967295U;
  fprintf(_coverage_fout, "945\n");
  fflush(_coverage_fout);
  return (0);
}
}
int TIFFDefaultDirectory(TIFF *tif ) 
{ register TIFFDirectory *td ;
  TIFFFieldArray const   *tiffFieldArray ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "948\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "949\n");
  fflush(_coverage_fout);
  tiffFieldArray = _TIFFGetFields();
  fprintf(_coverage_fout, "950\n");
  fflush(_coverage_fout);
  _TIFFSetupFields(tif, tiffFieldArray);
  fprintf(_coverage_fout, "951\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)td, 0, (long )sizeof(*td));
  fprintf(_coverage_fout, "952\n");
  fflush(_coverage_fout);
  td->td_fillorder = (unsigned short)1;
  fprintf(_coverage_fout, "953\n");
  fflush(_coverage_fout);
  td->td_bitspersample = (unsigned short)1;
  fprintf(_coverage_fout, "954\n");
  fflush(_coverage_fout);
  td->td_threshholding = (unsigned short)1;
  fprintf(_coverage_fout, "955\n");
  fflush(_coverage_fout);
  td->td_orientation = (unsigned short)1;
  fprintf(_coverage_fout, "956\n");
  fflush(_coverage_fout);
  td->td_samplesperpixel = (unsigned short)1;
  fprintf(_coverage_fout, "957\n");
  fflush(_coverage_fout);
  td->td_rowsperstrip = 4294967295U;
  fprintf(_coverage_fout, "958\n");
  fflush(_coverage_fout);
  td->td_tilewidth = 0U;
  fprintf(_coverage_fout, "959\n");
  fflush(_coverage_fout);
  td->td_tilelength = 0U;
  fprintf(_coverage_fout, "960\n");
  fflush(_coverage_fout);
  td->td_tiledepth = 1U;
  fprintf(_coverage_fout, "961\n");
  fflush(_coverage_fout);
  td->td_stripbytecountsorted = 1;
  fprintf(_coverage_fout, "962\n");
  fflush(_coverage_fout);
  td->td_resolutionunit = (unsigned short)2;
  fprintf(_coverage_fout, "963\n");
  fflush(_coverage_fout);
  td->td_sampleformat = (unsigned short)1;
  fprintf(_coverage_fout, "964\n");
  fflush(_coverage_fout);
  td->td_imagedepth = 1U;
  fprintf(_coverage_fout, "965\n");
  fflush(_coverage_fout);
  td->td_ycbcrsubsampling[0] = (unsigned short)2;
  fprintf(_coverage_fout, "966\n");
  fflush(_coverage_fout);
  td->td_ycbcrsubsampling[1] = (unsigned short)2;
  fprintf(_coverage_fout, "967\n");
  fflush(_coverage_fout);
  td->td_ycbcrpositioning = (unsigned short)1;
  fprintf(_coverage_fout, "968\n");
  fflush(_coverage_fout);
  tif->tif_postdecode = & _TIFFNoPostDecode;
  fprintf(_coverage_fout, "969\n");
  fflush(_coverage_fout);
  tif->tif_foundfield = (TIFFField const   *)((void *)0);
  fprintf(_coverage_fout, "970\n");
  fflush(_coverage_fout);
  tif->tif_tagmethods.vsetfield = & _TIFFVSetField;
  fprintf(_coverage_fout, "971\n");
  fflush(_coverage_fout);
  tif->tif_tagmethods.vgetfield = & _TIFFVGetField;
  fprintf(_coverage_fout, "972\n");
  fflush(_coverage_fout);
  tif->tif_tagmethods.printdir = (void (*)(TIFF * , FILE * , long  ))((void *)0);
  fprintf(_coverage_fout, "973\n");
  fflush(_coverage_fout);
  if (_TIFFextender) {
    fprintf(_coverage_fout, "946\n");
    fflush(_coverage_fout);
    (*_TIFFextender)(tif);
  } else {
    fprintf(_coverage_fout, "947\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "974\n");
  fflush(_coverage_fout);
  TIFFSetField(tif, 259U, 1);
  fprintf(_coverage_fout, "975\n");
  fflush(_coverage_fout);
  tif->tif_flags &= 4294967287U;
  fprintf(_coverage_fout, "976\n");
  fflush(_coverage_fout);
  tif->tif_flags &= 4294966271U;
  fprintf(_coverage_fout, "977\n");
  fflush(_coverage_fout);
  return (1);
}
}
static int TIFFAdvanceDirectory(TIFF *tif , uint64 *nextdir , uint64 *off ) ;
static char const   module___0[21]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'A',      (char const   )'d',      (char const   )'v',      (char const   )'a', 
        (char const   )'n',      (char const   )'c',      (char const   )'e',      (char const   )'D', 
        (char const   )'i',      (char const   )'r',      (char const   )'e',      (char const   )'c', 
        (char const   )'t',      (char const   )'o',      (char const   )'r',      (char const   )'y', 
        (char const   )'\000'};
static int TIFFAdvanceDirectory(TIFF *tif , uint64 *nextdir , uint64 *off ) 
{ uint64 poff ;
  tmsize_t poffa ;
  tmsize_t poffb ;
  tmsize_t poffc ;
  tmsize_t poffd ;
  uint16 dircount ;
  uint32 nextdir32 ;
  tmsize_t poffa___0 ;
  tmsize_t poffb___0 ;
  tmsize_t poffc___0 ;
  tmsize_t poffd___0 ;
  uint64 dircount64 ;
  uint16 dircount16 ;
  uint16 dircount___0 ;
  uint32 nextdir32___0 ;
  uint64 tmp ;
  tmsize_t tmp___0 ;
  tmsize_t tmp___1 ;
  uint64 dircount64___0 ;
  uint16 dircount16___0 ;
  uint64 tmp___2 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1129\n");
  fflush(_coverage_fout);
  if ((tif->tif_flags & 2048U) != 0U) {
    fprintf(_coverage_fout, "1072\n");
    fflush(_coverage_fout);
    poff = *nextdir;
    fprintf(_coverage_fout, "1073\n");
    fflush(_coverage_fout);
    if (! (tif->tif_flags & 524288U)) {
      fprintf(_coverage_fout, "1011\n");
      fflush(_coverage_fout);
      poffa = (long )poff;
      fprintf(_coverage_fout, "1012\n");
      fflush(_coverage_fout);
      poffb = (long )((unsigned long )poffa + (unsigned long )sizeof(uint16 ));
      fprintf(_coverage_fout, "1013\n");
      fflush(_coverage_fout);
      if ((unsigned long long )poffa != poff) {
        fprintf(_coverage_fout, "978\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___0,
                     "Error fetching directory count");
        fprintf(_coverage_fout, "979\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "989\n");
        fflush(_coverage_fout);
        if (poffb < poffa) {
          fprintf(_coverage_fout, "980\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___0,
                       "Error fetching directory count");
          fprintf(_coverage_fout, "981\n");
          fflush(_coverage_fout);
          return (0);
        } else {
          fprintf(_coverage_fout, "988\n");
          fflush(_coverage_fout);
          if (poffb < (long )sizeof(uint16 )) {
            fprintf(_coverage_fout, "982\n");
            fflush(_coverage_fout);
            TIFFErrorExt(tif->tif_clientdata, module___0,
                         "Error fetching directory count");
            fprintf(_coverage_fout, "983\n");
            fflush(_coverage_fout);
            return (0);
          } else {
            fprintf(_coverage_fout, "987\n");
            fflush(_coverage_fout);
            if (poffb > tif->tif_size) {
              fprintf(_coverage_fout, "984\n");
              fflush(_coverage_fout);
              TIFFErrorExt(tif->tif_clientdata, module___0,
                           "Error fetching directory count");
              fprintf(_coverage_fout, "985\n");
              fflush(_coverage_fout);
              return (0);
            } else {
              fprintf(_coverage_fout, "986\n");
              fflush(_coverage_fout);

            }
          }
        }
      }
      fprintf(_coverage_fout, "1014\n");
      fflush(_coverage_fout);
      _TIFFmemcpy((void *)(& dircount), (void const   *)(tif->tif_base + poffa),
                  (long )sizeof(uint16 ));
      fprintf(_coverage_fout, "1015\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "990\n");
        fflush(_coverage_fout);
        TIFFSwabShort(& dircount);
      } else {
        fprintf(_coverage_fout, "991\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1016\n");
      fflush(_coverage_fout);
      poffc = poffb + (tmsize_t )((int )dircount * 12);
      fprintf(_coverage_fout, "1017\n");
      fflush(_coverage_fout);
      poffd = (long )((unsigned long )poffc + (unsigned long )sizeof(uint32 ));
      fprintf(_coverage_fout, "1018\n");
      fflush(_coverage_fout);
      if (poffc < poffb) {
        fprintf(_coverage_fout, "992\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___0,
                     "Error fetching directory link");
        fprintf(_coverage_fout, "993\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "1006\n");
        fflush(_coverage_fout);
        if (poffc < (tmsize_t )((int )dircount * 12)) {
          fprintf(_coverage_fout, "994\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___0,
                       "Error fetching directory link");
          fprintf(_coverage_fout, "995\n");
          fflush(_coverage_fout);
          return (0);
        } else {
          fprintf(_coverage_fout, "1005\n");
          fflush(_coverage_fout);
          if (poffd < poffc) {
            fprintf(_coverage_fout, "996\n");
            fflush(_coverage_fout);
            TIFFErrorExt(tif->tif_clientdata, module___0,
                         "Error fetching directory link");
            fprintf(_coverage_fout, "997\n");
            fflush(_coverage_fout);
            return (0);
          } else {
            fprintf(_coverage_fout, "1004\n");
            fflush(_coverage_fout);
            if (poffd < (long )sizeof(uint32 )) {
              fprintf(_coverage_fout, "998\n");
              fflush(_coverage_fout);
              TIFFErrorExt(tif->tif_clientdata, module___0,
                           "Error fetching directory link");
              fprintf(_coverage_fout, "999\n");
              fflush(_coverage_fout);
              return (0);
            } else {
              fprintf(_coverage_fout, "1003\n");
              fflush(_coverage_fout);
              if (poffd > tif->tif_size) {
                fprintf(_coverage_fout, "1000\n");
                fflush(_coverage_fout);
                TIFFErrorExt(tif->tif_clientdata, module___0,
                             "Error fetching directory link");
                fprintf(_coverage_fout, "1001\n");
                fflush(_coverage_fout);
                return (0);
              } else {
                fprintf(_coverage_fout, "1002\n");
                fflush(_coverage_fout);

              }
            }
          }
        }
      }
      fprintf(_coverage_fout, "1019\n");
      fflush(_coverage_fout);
      if ((unsigned int )off != (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "1007\n");
        fflush(_coverage_fout);
        *off = (unsigned long long )poffc;
      } else {
        fprintf(_coverage_fout, "1008\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1020\n");
      fflush(_coverage_fout);
      _TIFFmemcpy((void *)(& nextdir32),
                  (void const   *)(tif->tif_base + poffc),
                  (long )sizeof(uint32 ));
      fprintf(_coverage_fout, "1021\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "1009\n");
        fflush(_coverage_fout);
        TIFFSwabLong(& nextdir32);
      } else {
        fprintf(_coverage_fout, "1010\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1022\n");
      fflush(_coverage_fout);
      *nextdir = (unsigned long long )nextdir32;
    } else {
      fprintf(_coverage_fout, "1059\n");
      fflush(_coverage_fout);
      poffa___0 = (long )poff;
      fprintf(_coverage_fout, "1060\n");
      fflush(_coverage_fout);
      poffb___0 = (long )((unsigned long )poffa___0 + (unsigned long )sizeof(uint64 ));
      fprintf(_coverage_fout, "1061\n");
      fflush(_coverage_fout);
      if ((unsigned long long )poffa___0 != poff) {
        fprintf(_coverage_fout, "1023\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___0,
                     "Error fetching directory count");
        fprintf(_coverage_fout, "1024\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "1034\n");
        fflush(_coverage_fout);
        if (poffb___0 < poffa___0) {
          fprintf(_coverage_fout, "1025\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___0,
                       "Error fetching directory count");
          fprintf(_coverage_fout, "1026\n");
          fflush(_coverage_fout);
          return (0);
        } else {
          fprintf(_coverage_fout, "1033\n");
          fflush(_coverage_fout);
          if (poffb___0 < (long )sizeof(uint64 )) {
            fprintf(_coverage_fout, "1027\n");
            fflush(_coverage_fout);
            TIFFErrorExt(tif->tif_clientdata, module___0,
                         "Error fetching directory count");
            fprintf(_coverage_fout, "1028\n");
            fflush(_coverage_fout);
            return (0);
          } else {
            fprintf(_coverage_fout, "1032\n");
            fflush(_coverage_fout);
            if (poffb___0 > tif->tif_size) {
              fprintf(_coverage_fout, "1029\n");
              fflush(_coverage_fout);
              TIFFErrorExt(tif->tif_clientdata, module___0,
                           "Error fetching directory count");
              fprintf(_coverage_fout, "1030\n");
              fflush(_coverage_fout);
              return (0);
            } else {
              fprintf(_coverage_fout, "1031\n");
              fflush(_coverage_fout);

            }
          }
        }
      }
      fprintf(_coverage_fout, "1062\n");
      fflush(_coverage_fout);
      _TIFFmemcpy((void *)(& dircount64),
                  (void const   *)(tif->tif_base + poffa___0),
                  (long )sizeof(uint64 ));
      fprintf(_coverage_fout, "1063\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "1035\n");
        fflush(_coverage_fout);
        TIFFSwabLong8(& dircount64);
      } else {
        fprintf(_coverage_fout, "1036\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1064\n");
      fflush(_coverage_fout);
      if (dircount64 > 65535ULL) {
        fprintf(_coverage_fout, "1037\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___0,
                     "Sanity check on directory count failed");
        fprintf(_coverage_fout, "1038\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "1039\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1065\n");
      fflush(_coverage_fout);
      dircount16 = (unsigned short )dircount64;
      fprintf(_coverage_fout, "1066\n");
      fflush(_coverage_fout);
      poffc___0 = poffb___0 + (tmsize_t )((int )dircount16 * 20);
      fprintf(_coverage_fout, "1067\n");
      fflush(_coverage_fout);
      poffd___0 = (long )((unsigned long )poffc___0 + (unsigned long )sizeof(uint64 ));
      fprintf(_coverage_fout, "1068\n");
      fflush(_coverage_fout);
      if (poffc___0 < poffb___0) {
        fprintf(_coverage_fout, "1040\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___0,
                     "Error fetching directory link");
        fprintf(_coverage_fout, "1041\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "1054\n");
        fflush(_coverage_fout);
        if (poffc___0 < (tmsize_t )((int )dircount16 * 20)) {
          fprintf(_coverage_fout, "1042\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___0,
                       "Error fetching directory link");
          fprintf(_coverage_fout, "1043\n");
          fflush(_coverage_fout);
          return (0);
        } else {
          fprintf(_coverage_fout, "1053\n");
          fflush(_coverage_fout);
          if (poffd___0 < poffc___0) {
            fprintf(_coverage_fout, "1044\n");
            fflush(_coverage_fout);
            TIFFErrorExt(tif->tif_clientdata, module___0,
                         "Error fetching directory link");
            fprintf(_coverage_fout, "1045\n");
            fflush(_coverage_fout);
            return (0);
          } else {
            fprintf(_coverage_fout, "1052\n");
            fflush(_coverage_fout);
            if (poffd___0 < (long )sizeof(uint64 )) {
              fprintf(_coverage_fout, "1046\n");
              fflush(_coverage_fout);
              TIFFErrorExt(tif->tif_clientdata, module___0,
                           "Error fetching directory link");
              fprintf(_coverage_fout, "1047\n");
              fflush(_coverage_fout);
              return (0);
            } else {
              fprintf(_coverage_fout, "1051\n");
              fflush(_coverage_fout);
              if (poffd___0 > tif->tif_size) {
                fprintf(_coverage_fout, "1048\n");
                fflush(_coverage_fout);
                TIFFErrorExt(tif->tif_clientdata, module___0,
                             "Error fetching directory link");
                fprintf(_coverage_fout, "1049\n");
                fflush(_coverage_fout);
                return (0);
              } else {
                fprintf(_coverage_fout, "1050\n");
                fflush(_coverage_fout);

              }
            }
          }
        }
      }
      fprintf(_coverage_fout, "1069\n");
      fflush(_coverage_fout);
      if ((unsigned int )off != (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "1055\n");
        fflush(_coverage_fout);
        *off = (unsigned long long )poffc___0;
      } else {
        fprintf(_coverage_fout, "1056\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1070\n");
      fflush(_coverage_fout);
      _TIFFmemcpy((void *)nextdir, (void const   *)(tif->tif_base + poffc___0),
                  (long )sizeof(uint64 ));
      fprintf(_coverage_fout, "1071\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "1057\n");
        fflush(_coverage_fout);
        TIFFSwabLong8(nextdir);
      } else {
        fprintf(_coverage_fout, "1058\n");
        fflush(_coverage_fout);

      }
    }
    fprintf(_coverage_fout, "1074\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1127\n");
    fflush(_coverage_fout);
    if (! (tif->tif_flags & 524288U)) {
      fprintf(_coverage_fout, "1091\n");
      fflush(_coverage_fout);
      tmp = (*(tif->tif_seekproc))(tif->tif_clientdata, *nextdir, 0);
      fprintf(_coverage_fout, "1092\n");
      fflush(_coverage_fout);
      if (tmp == *nextdir) {
        fprintf(_coverage_fout, "1078\n");
        fflush(_coverage_fout);
        tmp___0 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                         (void *)(& dircount___0),
                                         (long )sizeof(uint16 ));
        fprintf(_coverage_fout, "1079\n");
        fflush(_coverage_fout);
        if ((unsigned long )tmp___0 == (unsigned long )sizeof(uint16 )) {
          fprintf(_coverage_fout, "1075\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "1076\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___0,
                       "%s: Error fetching directory count", tif->tif_name);
          fprintf(_coverage_fout, "1077\n");
          fflush(_coverage_fout);
          return (0);
        }
      } else {
        fprintf(_coverage_fout, "1080\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___0,
                     "%s: Error fetching directory count", tif->tif_name);
        fprintf(_coverage_fout, "1081\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "1093\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "1082\n");
        fflush(_coverage_fout);
        TIFFSwabShort(& dircount___0);
      } else {
        fprintf(_coverage_fout, "1083\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1094\n");
      fflush(_coverage_fout);
      if ((unsigned int )off != (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "1084\n");
        fflush(_coverage_fout);
        *off = (*(tif->tif_seekproc))(tif->tif_clientdata,
                                      (unsigned long long )((int )dircount___0 * 12),
                                      1);
      } else {
        fprintf(_coverage_fout, "1085\n");
        fflush(_coverage_fout);
        (*(tif->tif_seekproc))(tif->tif_clientdata,
                               (unsigned long long )((int )dircount___0 * 12), 1);
      }
      fprintf(_coverage_fout, "1095\n");
      fflush(_coverage_fout);
      tmp___1 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                       (void *)(& nextdir32___0),
                                       (long )sizeof(uint32 ));
      fprintf(_coverage_fout, "1096\n");
      fflush(_coverage_fout);
      if ((unsigned long )tmp___1 == (unsigned long )sizeof(uint32 )) {
        fprintf(_coverage_fout, "1086\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "1087\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___0,
                     "%s: Error fetching directory link", tif->tif_name);
        fprintf(_coverage_fout, "1088\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "1097\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "1089\n");
        fflush(_coverage_fout);
        TIFFSwabLong(& nextdir32___0);
      } else {
        fprintf(_coverage_fout, "1090\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1098\n");
      fflush(_coverage_fout);
      *nextdir = (unsigned long long )nextdir32___0;
    } else {
      fprintf(_coverage_fout, "1118\n");
      fflush(_coverage_fout);
      tmp___2 = (*(tif->tif_seekproc))(tif->tif_clientdata, *nextdir, 0);
      fprintf(_coverage_fout, "1119\n");
      fflush(_coverage_fout);
      if (tmp___2 == *nextdir) {
        fprintf(_coverage_fout, "1102\n");
        fflush(_coverage_fout);
        tmp___3 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                         (void *)(& dircount64___0),
                                         (long )sizeof(uint64 ));
        fprintf(_coverage_fout, "1103\n");
        fflush(_coverage_fout);
        if ((unsigned long )tmp___3 == (unsigned long )sizeof(uint64 )) {
          fprintf(_coverage_fout, "1099\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "1100\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___0,
                       "%s: Error fetching directory count", tif->tif_name);
          fprintf(_coverage_fout, "1101\n");
          fflush(_coverage_fout);
          return (0);
        }
      } else {
        fprintf(_coverage_fout, "1104\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___0,
                     "%s: Error fetching directory count", tif->tif_name);
        fprintf(_coverage_fout, "1105\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "1120\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "1106\n");
        fflush(_coverage_fout);
        TIFFSwabLong8(& dircount64___0);
      } else {
        fprintf(_coverage_fout, "1107\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1121\n");
      fflush(_coverage_fout);
      if (dircount64___0 > 65535ULL) {
        fprintf(_coverage_fout, "1108\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___0,
                     "Error fetching directory count");
        fprintf(_coverage_fout, "1109\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "1110\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1122\n");
      fflush(_coverage_fout);
      dircount16___0 = (unsigned short )dircount64___0;
      fprintf(_coverage_fout, "1123\n");
      fflush(_coverage_fout);
      if ((unsigned int )off != (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "1111\n");
        fflush(_coverage_fout);
        *off = (*(tif->tif_seekproc))(tif->tif_clientdata,
                                      (unsigned long long )((int )dircount16___0 * 20),
                                      1);
      } else {
        fprintf(_coverage_fout, "1112\n");
        fflush(_coverage_fout);
        (*(tif->tif_seekproc))(tif->tif_clientdata,
                               (unsigned long long )((int )dircount16___0 * 20),
                               1);
      }
      fprintf(_coverage_fout, "1124\n");
      fflush(_coverage_fout);
      tmp___4 = (*(tif->tif_readproc))(tif->tif_clientdata, (void *)nextdir,
                                       (long )sizeof(uint64 ));
      fprintf(_coverage_fout, "1125\n");
      fflush(_coverage_fout);
      if ((unsigned long )tmp___4 == (unsigned long )sizeof(uint64 )) {
        fprintf(_coverage_fout, "1113\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "1114\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___0,
                     "%s: Error fetching directory link", tif->tif_name);
        fprintf(_coverage_fout, "1115\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "1126\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "1116\n");
        fflush(_coverage_fout);
        TIFFSwabLong8(nextdir);
      } else {
        fprintf(_coverage_fout, "1117\n");
        fflush(_coverage_fout);

      }
    }
    fprintf(_coverage_fout, "1128\n");
    fflush(_coverage_fout);
    return (1);
  }
}
}
uint16 TIFFNumberOfDirectories(TIFF *tif ) 
{ uint64 nextdir ;
  uint16 n ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1137\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "1130\n");
    fflush(_coverage_fout);
    nextdir = (unsigned long long )tif->tif_header.classic.tiff_diroff;
  } else {
    fprintf(_coverage_fout, "1131\n");
    fflush(_coverage_fout);
    nextdir = tif->tif_header.big.tiff_diroff;
  }
  fprintf(_coverage_fout, "1138\n");
  fflush(_coverage_fout);
  n = (unsigned short)0;
  fprintf(_coverage_fout, "1139\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1135\n");
    fflush(_coverage_fout);
    if (nextdir != 0ULL) {
      fprintf(_coverage_fout, "1133\n");
      fflush(_coverage_fout);
      tmp = TIFFAdvanceDirectory(tif, & nextdir, (uint64 *)((void *)0));
      fprintf(_coverage_fout, "1134\n");
      fflush(_coverage_fout);
      if (tmp) {
        fprintf(_coverage_fout, "1132\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "1136\n");
    fflush(_coverage_fout);
    n = (uint16 )((int )n + 1);
  }
  fprintf(_coverage_fout, "1140\n");
  fflush(_coverage_fout);
  return (n);
}
}
int TIFFSetDirectory(TIFF *tif , uint16 dirn ) 
{ uint64 nextdir ;
  uint16 n ;
  int tmp ;
  int tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1151\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "1141\n");
    fflush(_coverage_fout);
    nextdir = (unsigned long long )tif->tif_header.classic.tiff_diroff;
  } else {
    fprintf(_coverage_fout, "1142\n");
    fflush(_coverage_fout);
    nextdir = tif->tif_header.big.tiff_diroff;
  }
  fprintf(_coverage_fout, "1152\n");
  fflush(_coverage_fout);
  n = dirn;
  fprintf(_coverage_fout, "1153\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1147\n");
    fflush(_coverage_fout);
    if ((int )n > 0) {
      fprintf(_coverage_fout, "1144\n");
      fflush(_coverage_fout);
      if (nextdir != 0ULL) {
        fprintf(_coverage_fout, "1143\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "1148\n");
    fflush(_coverage_fout);
    tmp = TIFFAdvanceDirectory(tif, & nextdir, (uint64 *)((void *)0));
    fprintf(_coverage_fout, "1149\n");
    fflush(_coverage_fout);
    if (tmp) {
      fprintf(_coverage_fout, "1145\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "1146\n");
      fflush(_coverage_fout);
      return (0);
    }
    fprintf(_coverage_fout, "1150\n");
    fflush(_coverage_fout);
    n = (uint16 )((int )n - 1);
  }
  fprintf(_coverage_fout, "1154\n");
  fflush(_coverage_fout);
  tif->tif_nextdiroff = nextdir;
  fprintf(_coverage_fout, "1155\n");
  fflush(_coverage_fout);
  tif->tif_curdir = (unsigned short )(((int )dirn - (int )n) - 1);
  fprintf(_coverage_fout, "1156\n");
  fflush(_coverage_fout);
  tif->tif_dirnumber = (unsigned short)0;
  fprintf(_coverage_fout, "1157\n");
  fflush(_coverage_fout);
  tmp___0 = TIFFReadDirectory(tif);
  fprintf(_coverage_fout, "1158\n");
  fflush(_coverage_fout);
  return (tmp___0);
}
}
int TIFFSetSubDirectory(TIFF *tif , uint64 diroff ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1159\n");
  fflush(_coverage_fout);
  tif->tif_nextdiroff = diroff;
  fprintf(_coverage_fout, "1160\n");
  fflush(_coverage_fout);
  tif->tif_dirnumber = (unsigned short)0;
  fprintf(_coverage_fout, "1161\n");
  fflush(_coverage_fout);
  tmp = TIFFReadDirectory(tif);
  fprintf(_coverage_fout, "1162\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
uint64 TIFFCurrentDirOffset(TIFF *tif ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1163\n");
  fflush(_coverage_fout);
  return (tif->tif_diroff);
}
}
int TIFFLastDirectory(TIFF *tif ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1164\n");
  fflush(_coverage_fout);
  return (tif->tif_nextdiroff == 0ULL);
}
}
int TIFFUnlinkDirectory(TIFF *tif , uint16 dirn ) ;
static char const   module___1[20]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'U',      (char const   )'n',      (char const   )'l',      (char const   )'i', 
        (char const   )'n',      (char const   )'k',      (char const   )'D',      (char const   )'i', 
        (char const   )'r',      (char const   )'e',      (char const   )'c',      (char const   )'t', 
        (char const   )'o',      (char const   )'r',      (char const   )'y',      (char const   )'\000'};
int TIFFUnlinkDirectory(TIFF *tif , uint16 dirn ) 
{ uint64 nextdir ;
  uint64 off ;
  uint16 n ;
  int tmp ;
  int tmp___0 ;
  uint32 nextdir32 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1211\n");
  fflush(_coverage_fout);
  if (tif->tif_mode == 00) {
    fprintf(_coverage_fout, "1165\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___1,
                 "Can not unlink directory in read-only file");
    fprintf(_coverage_fout, "1166\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "1167\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1212\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "1168\n");
    fflush(_coverage_fout);
    nextdir = (unsigned long long )tif->tif_header.classic.tiff_diroff;
    fprintf(_coverage_fout, "1169\n");
    fflush(_coverage_fout);
    off = 4ULL;
  } else {
    fprintf(_coverage_fout, "1170\n");
    fflush(_coverage_fout);
    nextdir = tif->tif_header.big.tiff_diroff;
    fprintf(_coverage_fout, "1171\n");
    fflush(_coverage_fout);
    off = 8ULL;
  }
  fprintf(_coverage_fout, "1213\n");
  fflush(_coverage_fout);
  n = (unsigned short )((int )dirn - 1);
  fprintf(_coverage_fout, "1214\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1178\n");
    fflush(_coverage_fout);
    if ((int )n > 0) {
      fprintf(_coverage_fout, "1172\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1179\n");
    fflush(_coverage_fout);
    if (nextdir == 0ULL) {
      fprintf(_coverage_fout, "1173\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___1,
                   "Directory %d does not exist", dirn);
      fprintf(_coverage_fout, "1174\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "1175\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1180\n");
    fflush(_coverage_fout);
    tmp = TIFFAdvanceDirectory(tif, & nextdir, & off);
    fprintf(_coverage_fout, "1181\n");
    fflush(_coverage_fout);
    if (tmp) {
      fprintf(_coverage_fout, "1176\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "1177\n");
      fflush(_coverage_fout);
      return (0);
    }
    fprintf(_coverage_fout, "1182\n");
    fflush(_coverage_fout);
    n = (uint16 )((int )n - 1);
  }
  fprintf(_coverage_fout, "1215\n");
  fflush(_coverage_fout);
  tmp___0 = TIFFAdvanceDirectory(tif, & nextdir, (uint64 *)((void *)0));
  fprintf(_coverage_fout, "1216\n");
  fflush(_coverage_fout);
  if (tmp___0) {
    fprintf(_coverage_fout, "1183\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1184\n");
    fflush(_coverage_fout);
    return (0);
  }
  fprintf(_coverage_fout, "1217\n");
  fflush(_coverage_fout);
  (*(tif->tif_seekproc))(tif->tif_clientdata, off, 0);
  fprintf(_coverage_fout, "1218\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "1192\n");
    fflush(_coverage_fout);
    nextdir32 = (unsigned int )nextdir;
    fprintf(_coverage_fout, "1193\n");
    fflush(_coverage_fout);
    if ((unsigned long long )nextdir32 == nextdir) {
      fprintf(_coverage_fout, "1185\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "1186\n");
      fflush(_coverage_fout);
      __assert_fail("(uint64)nextdir32==nextdir", "tif_dir.c", 1429U,
                    "TIFFUnlinkDirectory");
    }
    fprintf(_coverage_fout, "1194\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "1187\n");
      fflush(_coverage_fout);
      TIFFSwabLong(& nextdir32);
    } else {
      fprintf(_coverage_fout, "1188\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1195\n");
    fflush(_coverage_fout);
    tmp___1 = (*(tif->tif_writeproc))(tif->tif_clientdata,
                                      (void *)(& nextdir32),
                                      (long )sizeof(uint32 ));
    fprintf(_coverage_fout, "1196\n");
    fflush(_coverage_fout);
    if ((unsigned long )tmp___1 == (unsigned long )sizeof(uint32 )) {
      fprintf(_coverage_fout, "1189\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "1190\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___1,
                   "Error writing directory link");
      fprintf(_coverage_fout, "1191\n");
      fflush(_coverage_fout);
      return (0);
    }
  } else {
    fprintf(_coverage_fout, "1202\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "1197\n");
      fflush(_coverage_fout);
      TIFFSwabLong8(& nextdir);
    } else {
      fprintf(_coverage_fout, "1198\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1203\n");
    fflush(_coverage_fout);
    tmp___2 = (*(tif->tif_writeproc))(tif->tif_clientdata, (void *)(& nextdir),
                                      (long )sizeof(uint64 ));
    fprintf(_coverage_fout, "1204\n");
    fflush(_coverage_fout);
    if ((unsigned long )tmp___2 == (unsigned long )sizeof(uint64 )) {
      fprintf(_coverage_fout, "1199\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "1200\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___1,
                   "Error writing directory link");
      fprintf(_coverage_fout, "1201\n");
      fflush(_coverage_fout);
      return (0);
    }
  }
  fprintf(_coverage_fout, "1219\n");
  fflush(_coverage_fout);
  (*(tif->tif_cleanup))(tif);
  fprintf(_coverage_fout, "1220\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 512U) {
    fprintf(_coverage_fout, "1209\n");
    fflush(_coverage_fout);
    if (tif->tif_rawdata) {
      fprintf(_coverage_fout, "1205\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)tif->tif_rawdata);
      fprintf(_coverage_fout, "1206\n");
      fflush(_coverage_fout);
      tif->tif_rawdata = (uint8 *)((void *)0);
      fprintf(_coverage_fout, "1207\n");
      fflush(_coverage_fout);
      tif->tif_rawcc = 0L;
    } else {
      fprintf(_coverage_fout, "1208\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "1210\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1221\n");
  fflush(_coverage_fout);
  tif->tif_flags &= 4294963119U;
  fprintf(_coverage_fout, "1222\n");
  fflush(_coverage_fout);
  TIFFFreeDirectory(tif);
  fprintf(_coverage_fout, "1223\n");
  fflush(_coverage_fout);
  TIFFDefaultDirectory(tif);
  fprintf(_coverage_fout, "1224\n");
  fflush(_coverage_fout);
  tif->tif_diroff = 0ULL;
  fprintf(_coverage_fout, "1225\n");
  fflush(_coverage_fout);
  tif->tif_nextdiroff = 0ULL;
  fprintf(_coverage_fout, "1226\n");
  fflush(_coverage_fout);
  tif->tif_curoff = 0ULL;
  fprintf(_coverage_fout, "1227\n");
  fflush(_coverage_fout);
  tif->tif_row = 4294967295U;
  fprintf(_coverage_fout, "1228\n");
  fflush(_coverage_fout);
  tif->tif_curstrip = 4294967295U;
  fprintf(_coverage_fout, "1229\n");
  fflush(_coverage_fout);
  return (1);
}
}
