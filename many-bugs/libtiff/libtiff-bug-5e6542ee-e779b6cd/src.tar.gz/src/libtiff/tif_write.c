extern void *_coverage_fout ;
typedef unsigned char __u_char;
typedef unsigned short __u_short;
typedef unsigned int __u_int;
typedef unsigned long __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;
typedef long long __quad_t;
typedef unsigned long long __u_quad_t;
typedef __u_quad_t __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef __u_quad_t __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long __off_t;
typedef __quad_t __off64_t;
typedef int __pid_t;
struct __anonstruct___fsid_t_1 {
   int __val[2] ;
};
typedef struct __anonstruct___fsid_t_1 __fsid_t;
typedef long __clock_t;
typedef unsigned long __rlim_t;
typedef __u_quad_t __rlim64_t;
typedef unsigned int __id_t;
typedef long __time_t;
typedef unsigned int __useconds_t;
typedef long __suseconds_t;
typedef int __daddr_t;
typedef long __swblk_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void *__timer_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef __quad_t __blkcnt64_t;
typedef unsigned long __fsblkcnt_t;
typedef __u_quad_t __fsblkcnt64_t;
typedef unsigned long __fsfilcnt_t;
typedef __u_quad_t __fsfilcnt64_t;
typedef int __ssize_t;
typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;
typedef int __intptr_t;
typedef unsigned int __socklen_t;
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;
typedef __loff_t loff_t;
typedef __ino64_t ino_t;
typedef __dev_t dev_t;
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __nlink_t nlink_t;
typedef __uid_t uid_t;
typedef __off64_t off_t;
typedef __pid_t pid_t;
typedef __id_t id_t;
typedef __ssize_t ssize_t;
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;
typedef __key_t key_t;
typedef __clock_t clock_t;
typedef __time_t time_t;
typedef __clockid_t clockid_t;
typedef __timer_t timer_t;
typedef unsigned int size_t;
typedef unsigned long ulong;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char u_int8_t;
typedef unsigned short u_int16_t;
typedef unsigned int u_int32_t;
typedef unsigned long long u_int64_t;
typedef int register_t;
typedef int __sig_atomic_t;
struct __anonstruct___sigset_t_2 {
   unsigned long __val[1024U / (8U * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_2 __sigset_t;
typedef __sigset_t sigset_t;
struct timespec {
   __time_t tv_sec ;
   long tv_nsec ;
};
struct timeval {
   __time_t tv_sec ;
   __suseconds_t tv_usec ;
};
typedef __suseconds_t suseconds_t;
typedef long __fd_mask;
struct __anonstruct_fd_set_3 {
   __fd_mask __fds_bits[1024 / (8 * (int )sizeof(__fd_mask ))] ;
};
typedef struct __anonstruct_fd_set_3 fd_set;
typedef __fd_mask fd_mask;
typedef __blksize_t blksize_t;
typedef __blkcnt64_t blkcnt_t;
typedef __fsblkcnt64_t fsblkcnt_t;
typedef __fsfilcnt64_t fsfilcnt_t;
typedef unsigned long pthread_t;
union __anonunion_pthread_attr_t_4 {
   char __size[36] ;
   long __align ;
};
typedef union __anonunion_pthread_attr_t_4 pthread_attr_t;
struct __pthread_internal_slist {
   struct __pthread_internal_slist *__next ;
};
typedef struct __pthread_internal_slist __pthread_slist_t;
union __anonunion____missing_field_name_6 {
   int __spins ;
   __pthread_slist_t __list ;
};
struct __pthread_mutex_s {
   int __lock ;
   unsigned int __count ;
   int __owner ;
   int __kind ;
   unsigned int __nusers ;
   union __anonunion____missing_field_name_6 __annonCompField1 ;
};
union __anonunion_pthread_mutex_t_5 {
   struct __pthread_mutex_s __data ;
   char __size[24] ;
   long __align ;
};
typedef union __anonunion_pthread_mutex_t_5 pthread_mutex_t;
union __anonunion_pthread_mutexattr_t_7 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_mutexattr_t_7 pthread_mutexattr_t;
struct __anonstruct___data_9 {
   int __lock ;
   unsigned int __futex ;
   unsigned long long __total_seq ;
   unsigned long long __wakeup_seq ;
   unsigned long long __woken_seq ;
   void *__mutex ;
   unsigned int __nwaiters ;
   unsigned int __broadcast_seq ;
};
union __anonunion_pthread_cond_t_8 {
   struct __anonstruct___data_9 __data ;
   char __size[48] ;
   long long __align ;
};
typedef union __anonunion_pthread_cond_t_8 pthread_cond_t;
union __anonunion_pthread_condattr_t_10 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_condattr_t_10 pthread_condattr_t;
typedef unsigned int pthread_key_t;
typedef int pthread_once_t;
struct __anonstruct___data_12 {
   int __lock ;
   unsigned int __nr_readers ;
   unsigned int __readers_wakeup ;
   unsigned int __writer_wakeup ;
   unsigned int __nr_readers_queued ;
   unsigned int __nr_writers_queued ;
   unsigned char __flags ;
   unsigned char __shared ;
   unsigned char __pad1 ;
   unsigned char __pad2 ;
   int __writer ;
};
union __anonunion_pthread_rwlock_t_11 {
   struct __anonstruct___data_12 __data ;
   char __size[32] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlock_t_11 pthread_rwlock_t;
union __anonunion_pthread_rwlockattr_t_13 {
   char __size[8] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlockattr_t_13 pthread_rwlockattr_t;
typedef int volatile   pthread_spinlock_t;
union __anonunion_pthread_barrier_t_14 {
   char __size[20] ;
   long __align ;
};
typedef union __anonunion_pthread_barrier_t_14 pthread_barrier_t;
union __anonunion_pthread_barrierattr_t_15 {
   char __size[4] ;
   int __align ;
};
typedef union __anonunion_pthread_barrierattr_t_15 pthread_barrierattr_t;
struct flock {
   short l_type ;
   short l_whence ;
   __off64_t l_start ;
   __off64_t l_len ;
   __pid_t l_pid ;
};
struct stat {
   __dev_t st_dev ;
   unsigned short __pad1 ;
   __ino_t __st_ino ;
   __mode_t st_mode ;
   __nlink_t st_nlink ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   __dev_t st_rdev ;
   unsigned short __pad2 ;
   __off64_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt64_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __ino64_t st_ino ;
};
struct __locale_data;
struct __locale_struct {
   struct __locale_data *__locales[13] ;
   unsigned short const   *__ctype_b ;
   int const   *__ctype_tolower ;
   int const   *__ctype_toupper ;
   char const   *__names[13] ;
};
typedef struct __locale_struct *__locale_t;
typedef __locale_t locale_t;
typedef int (*__compar_fn_t)(void const   * , void const   * );
enum __anonenum_ACTION_16 {
    FIND = 0,
    ENTER = 1
} ;
typedef enum __anonenum_ACTION_16 ACTION;
struct entry {
   char *key ;
   void *data ;
};
typedef struct entry ENTRY;
struct _ENTRY;
struct _ENTRY;
enum __anonenum_VISIT_17 {
    preorder = 0,
    postorder = 1,
    endorder = 2,
    leaf = 3
} ;
typedef enum __anonenum_VISIT_17 VISIT;
typedef void (*__action_fn_t)(void const   *__nodep , VISIT __value ,
                              int __level );
typedef signed char int8;
typedef unsigned char uint8;
typedef short int16;
typedef unsigned short uint16;
typedef int int32;
typedef unsigned int uint32;
typedef long long int64;
typedef unsigned long long uint64;
typedef int uint16_vap;
struct __anonstruct_TIFFHeaderCommon_18 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
};
typedef struct __anonstruct_TIFFHeaderCommon_18 TIFFHeaderCommon;
struct __anonstruct_TIFFHeaderClassic_19 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint32 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderClassic_19 TIFFHeaderClassic;
struct __anonstruct_TIFFHeaderBig_20 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint16 tiff_offsetsize ;
   uint16 tiff_unused ;
   uint64 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderBig_20 TIFFHeaderBig;
enum __anonenum_TIFFDataType_21 {
    TIFF_NOTYPE = 0,
    TIFF_BYTE = 1,
    TIFF_ASCII = 2,
    TIFF_SHORT = 3,
    TIFF_LONG = 4,
    TIFF_RATIONAL = 5,
    TIFF_SBYTE = 6,
    TIFF_UNDEFINED = 7,
    TIFF_SSHORT = 8,
    TIFF_SLONG = 9,
    TIFF_SRATIONAL = 10,
    TIFF_FLOAT = 11,
    TIFF_DOUBLE = 12,
    TIFF_IFD = 13,
    TIFF_LONG8 = 16,
    TIFF_SLONG8 = 17,
    TIFF_IFD8 = 18
} ;
typedef enum __anonenum_TIFFDataType_21 TIFFDataType;
struct tiff;
typedef struct tiff TIFF;
typedef long tmsize_t;
typedef uint32 ttag_t;
typedef uint16 tdir_t;
typedef uint16 tsample_t;
typedef uint32 tstrile_t;
typedef tstrile_t tstrip_t;
typedef tstrile_t ttile_t;
typedef tmsize_t tsize_t;
typedef void *tdata_t;
typedef uint64 toff_t;
typedef void *thandle_t;
typedef unsigned char TIFFRGBValue;
struct __anonstruct_TIFFDisplay_22 {
   float d_mat[3][3] ;
   float d_YCR ;
   float d_YCG ;
   float d_YCB ;
   uint32 d_Vrwr ;
   uint32 d_Vrwg ;
   uint32 d_Vrwb ;
   float d_Y0R ;
   float d_Y0G ;
   float d_Y0B ;
   float d_gammaR ;
   float d_gammaG ;
   float d_gammaB ;
};
typedef struct __anonstruct_TIFFDisplay_22 TIFFDisplay;
struct __anonstruct_TIFFYCbCrToRGB_23 {
   TIFFRGBValue *clamptab ;
   int *Cr_r_tab ;
   int *Cb_b_tab ;
   int32 *Cr_g_tab ;
   int32 *Cb_g_tab ;
   int32 *Y_tab ;
};
typedef struct __anonstruct_TIFFYCbCrToRGB_23 TIFFYCbCrToRGB;
struct __anonstruct_TIFFCIELabToRGB_24 {
   int range ;
   float rstep ;
   float gstep ;
   float bstep ;
   float X0 ;
   float Y0 ;
   float Z0 ;
   TIFFDisplay display ;
   float Yr2r[1501] ;
   float Yg2g[1501] ;
   float Yb2b[1501] ;
};
typedef struct __anonstruct_TIFFCIELabToRGB_24 TIFFCIELabToRGB;
struct _TIFFRGBAImage;
typedef struct _TIFFRGBAImage TIFFRGBAImage;
typedef void (*tileContigRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                  uint32  , uint32  , uint32  , int32  ,
                                  int32  , unsigned char * );
typedef void (*tileSeparateRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                    uint32  , uint32  , uint32  , int32  ,
                                    int32  , unsigned char * , unsigned char * ,
                                    unsigned char * , unsigned char * );
union __anonunion_put_25 {
   void (*any)(TIFFRGBAImage * ) ;
   void (*contig)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                  uint32  , int32  , int32  , unsigned char * ) ;
   void (*separate)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                    uint32  , int32  , int32  , unsigned char * ,
                    unsigned char * , unsigned char * , unsigned char * ) ;
};
struct _TIFFRGBAImage {
   TIFF *tif ;
   int stoponerr ;
   int isContig ;
   int alpha ;
   uint32 width ;
   uint32 height ;
   uint16 bitspersample ;
   uint16 samplesperpixel ;
   uint16 orientation ;
   uint16 req_orientation ;
   uint16 photometric ;
   uint16 *redcmap ;
   uint16 *greencmap ;
   uint16 *bluecmap ;
   int (*get)(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
   union __anonunion_put_25 put ;
   TIFFRGBValue *Map ;
   uint32 **BWmap ;
   uint32 **PALmap ;
   TIFFYCbCrToRGB *ycbcr ;
   TIFFCIELabToRGB *cielab ;
   uint8 *UaToAa ;
   uint8 *Bitdepth16To8 ;
   int row_offset ;
   int col_offset ;
};
typedef int (*TIFFInitMethod)(TIFF * , int  );
struct __anonstruct_TIFFCodec_26 {
   char *name ;
   uint16 scheme ;
   int (*init)(TIFF * , int  ) ;
};
typedef struct __anonstruct_TIFFCodec_26 TIFFCodec;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_28 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_27 {
   int __count ;
   union __anonunion___value_28 __value ;
};
typedef struct __anonstruct___mbstate_t_27 __mbstate_t;
struct __anonstruct__G_fpos_t_29 {
   __off_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos_t_29 _G_fpos_t;
struct __anonstruct__G_fpos64_t_30 {
   __off64_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos64_t_30 _G_fpos64_t;
typedef short _G_int16_t;
typedef int _G_int32_t;
typedef unsigned short _G_uint16_t;
typedef unsigned int _G_uint32_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_jump_t;
struct _IO_jump_t;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
enum __codecvt_result {
    __codecvt_ok = 0,
    __codecvt_partial = 1,
    __codecvt_error = 2,
    __codecvt_noconv = 3
} ;
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15U * sizeof(int ) - 4U * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
struct _IO_FILE_plus;
struct _IO_FILE_plus;
typedef __ssize_t __io_read_fn(void *__cookie , char *__buf , size_t __nbytes );
typedef __ssize_t __io_write_fn(void *__cookie , char const   *__buf ,
                                size_t __n );
typedef int __io_seek_fn(void *__cookie , __off64_t *__pos , int __w );
typedef int __io_close_fn(void *__cookie );
typedef __gnuc_va_list va_list;
typedef _G_fpos64_t fpos_t;
typedef void (*TIFFErrorHandler)(char const   * , char const   * , va_list  );
typedef void (*TIFFErrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  );
typedef tmsize_t (*TIFFReadWriteProc)(thandle_t  , void * , tmsize_t  );
typedef uint64 (*TIFFSeekProc)(thandle_t  , uint64  , int  );
typedef int (*TIFFCloseProc)(thandle_t  );
typedef uint64 (*TIFFSizeProc)(thandle_t  );
typedef int (*TIFFMapFileProc)(thandle_t  , void **base , toff_t *size );
typedef void (*TIFFUnmapFileProc)(thandle_t  , void *base , toff_t size );
typedef void (*TIFFExtendProc)(TIFF * );
struct _TIFFField;
typedef struct _TIFFField TIFFField;
struct _TIFFFieldArray;
typedef struct _TIFFFieldArray TIFFFieldArray;
typedef int (*TIFFVSetMethod)(TIFF * , uint32  , va_list  );
typedef int (*TIFFVGetMethod)(TIFF * , uint32  , va_list  );
typedef void (*TIFFPrintMethod)(TIFF * , FILE * , long  );
struct __anonstruct_TIFFTagMethods_31 {
   int (*vsetfield)(TIFF * , uint32  , va_list  ) ;
   int (*vgetfield)(TIFF * , uint32  , va_list  ) ;
   void (*printdir)(TIFF * , FILE * , long  ) ;
};
typedef struct __anonstruct_TIFFTagMethods_31 TIFFTagMethods;
struct __anonstruct_TIFFFieldInfo_32 {
   ttag_t field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
};
typedef struct __anonstruct_TIFFFieldInfo_32 TIFFFieldInfo;
struct __anonstruct_TIFFTagValue_33 {
   TIFFField const   *info ;
   int count ;
   void *value ;
};
typedef struct __anonstruct_TIFFTagValue_33 TIFFTagValue;
struct __anonstruct_TIFFDirectory_34 {
   unsigned long td_fieldsset[4] ;
   uint32 td_imagewidth ;
   uint32 td_imagelength ;
   uint32 td_imagedepth ;
   uint32 td_tilewidth ;
   uint32 td_tilelength ;
   uint32 td_tiledepth ;
   uint32 td_subfiletype ;
   uint16 td_bitspersample ;
   uint16 td_sampleformat ;
   uint16 td_compression ;
   uint16 td_photometric ;
   uint16 td_threshholding ;
   uint16 td_fillorder ;
   uint16 td_orientation ;
   uint16 td_samplesperpixel ;
   uint32 td_rowsperstrip ;
   uint16 td_minsamplevalue ;
   uint16 td_maxsamplevalue ;
   double td_sminsamplevalue ;
   double td_smaxsamplevalue ;
   float td_xresolution ;
   float td_yresolution ;
   uint16 td_resolutionunit ;
   uint16 td_planarconfig ;
   float td_xposition ;
   float td_yposition ;
   uint16 td_pagenumber[2] ;
   uint16 *td_colormap[3] ;
   uint16 td_halftonehints[2] ;
   uint16 td_extrasamples ;
   uint16 *td_sampleinfo ;
   uint32 td_stripsperimage ;
   uint32 td_nstrips ;
   uint64 *td_stripoffset ;
   uint64 *td_stripbytecount ;
   int td_stripbytecountsorted ;
   uint16 td_nsubifd ;
   uint64 *td_subifd ;
   uint16 td_ycbcrsubsampling[2] ;
   uint16 td_ycbcrpositioning ;
   uint16 *td_transferfunction[3] ;
   int td_inknameslen ;
   char *td_inknames ;
   int td_customValueCount ;
   TIFFTagValue *td_customValues ;
};
typedef struct __anonstruct_TIFFDirectory_34 TIFFDirectory;
enum __anonenum_TIFFSetGetFieldType_35 {
    TIFF_SETGET_UNDEFINED = 0,
    TIFF_SETGET_ASCII = 1,
    TIFF_SETGET_UINT8 = 2,
    TIFF_SETGET_SINT8 = 3,
    TIFF_SETGET_UINT16 = 4,
    TIFF_SETGET_SINT16 = 5,
    TIFF_SETGET_UINT32 = 6,
    TIFF_SETGET_SINT32 = 7,
    TIFF_SETGET_UINT64 = 8,
    TIFF_SETGET_SINT64 = 9,
    TIFF_SETGET_FLOAT = 10,
    TIFF_SETGET_DOUBLE = 11,
    TIFF_SETGET_IFD8 = 12,
    TIFF_SETGET_INT = 13,
    TIFF_SETGET_UINT16_PAIR = 14,
    TIFF_SETGET_C0_ASCII = 15,
    TIFF_SETGET_C0_UINT8 = 16,
    TIFF_SETGET_C0_SINT8 = 17,
    TIFF_SETGET_C0_UINT16 = 18,
    TIFF_SETGET_C0_SINT16 = 19,
    TIFF_SETGET_C0_UINT32 = 20,
    TIFF_SETGET_C0_SINT32 = 21,
    TIFF_SETGET_C0_UINT64 = 22,
    TIFF_SETGET_C0_SINT64 = 23,
    TIFF_SETGET_C0_FLOAT = 24,
    TIFF_SETGET_C0_DOUBLE = 25,
    TIFF_SETGET_C0_IFD8 = 26,
    TIFF_SETGET_C16_ASCII = 27,
    TIFF_SETGET_C16_UINT8 = 28,
    TIFF_SETGET_C16_SINT8 = 29,
    TIFF_SETGET_C16_UINT16 = 30,
    TIFF_SETGET_C16_SINT16 = 31,
    TIFF_SETGET_C16_UINT32 = 32,
    TIFF_SETGET_C16_SINT32 = 33,
    TIFF_SETGET_C16_UINT64 = 34,
    TIFF_SETGET_C16_SINT64 = 35,
    TIFF_SETGET_C16_FLOAT = 36,
    TIFF_SETGET_C16_DOUBLE = 37,
    TIFF_SETGET_C16_IFD8 = 38,
    TIFF_SETGET_C32_ASCII = 39,
    TIFF_SETGET_C32_UINT8 = 40,
    TIFF_SETGET_C32_SINT8 = 41,
    TIFF_SETGET_C32_UINT16 = 42,
    TIFF_SETGET_C32_SINT16 = 43,
    TIFF_SETGET_C32_UINT32 = 44,
    TIFF_SETGET_C32_SINT32 = 45,
    TIFF_SETGET_C32_UINT64 = 46,
    TIFF_SETGET_C32_SINT64 = 47,
    TIFF_SETGET_C32_FLOAT = 48,
    TIFF_SETGET_C32_DOUBLE = 49,
    TIFF_SETGET_C32_IFD8 = 50,
    TIFF_SETGET_OTHER = 51
} ;
typedef enum __anonenum_TIFFSetGetFieldType_35 TIFFSetGetFieldType;
enum __anonenum_TIFFFieldArrayType_36 {
    tfiatImage = 0,
    tfiatExif = 1,
    tfiatOther = 2
} ;
typedef enum __anonenum_TIFFFieldArrayType_36 TIFFFieldArrayType;
struct _TIFFFieldArray {
   TIFFFieldArrayType type ;
   uint32 allocated_size ;
   uint32 count ;
   TIFFField *fields ;
};
struct _TIFFField {
   uint32 field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   uint32 reserved ;
   TIFFSetGetFieldType set_field_type ;
   TIFFSetGetFieldType get_field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
   TIFFFieldArray *field_subfields ;
};
struct __anonstruct_TIFFDirEntry_37 {
   uint16 tdir_tag ;
   uint16 tdir_type ;
   uint64 tdir_count ;
   uint64 tdir_offset ;
};
typedef struct __anonstruct_TIFFDirEntry_37 TIFFDirEntry;
struct client_info {
   struct client_info *next ;
   void *data ;
   char *name ;
};
typedef struct client_info TIFFClientInfoLink;
typedef unsigned char tidataval_t;
typedef tidataval_t *tidata_t;
typedef void (*TIFFVoidMethod)(TIFF * );
typedef int (*TIFFBoolMethod)(TIFF * );
typedef int (*TIFFPreMethod)(TIFF * , uint16  );
typedef int (*TIFFCodeMethod)(TIFF *tif , uint8 *buf , tmsize_t size ,
                              uint16 sample );
typedef int (*TIFFSeekMethod)(TIFF * , uint32  );
typedef void (*TIFFPostMethod)(TIFF *tif , uint8 *buf , tmsize_t size );
typedef uint32 (*TIFFStripMethod)(TIFF * , uint32  );
typedef void (*TIFFTileMethod)(TIFF * , uint32 * , uint32 * );
union __anonunion_tif_header_38 {
   TIFFHeaderCommon common ;
   TIFFHeaderClassic classic ;
   TIFFHeaderBig big ;
};
struct tiff {
   char *tif_name ;
   int tif_fd ;
   int tif_mode ;
   uint32 tif_flags ;
   uint64 tif_diroff ;
   uint64 tif_nextdiroff ;
   uint64 *tif_dirlist ;
   uint16 tif_dirlistsize ;
   uint16 tif_dirnumber ;
   TIFFDirectory tif_dir ;
   TIFFDirectory tif_customdir ;
   union __anonunion_tif_header_38 tif_header ;
   uint16 tif_header_size ;
   uint32 tif_row ;
   uint16 tif_curdir ;
   uint32 tif_curstrip ;
   uint64 tif_curoff ;
   uint64 tif_dataoff ;
   uint16 tif_nsubifd ;
   uint64 tif_subifdoff ;
   uint32 tif_col ;
   uint32 tif_curtile ;
   tmsize_t tif_tilesize ;
   int tif_decodestatus ;
   int (*tif_fixuptags)(TIFF * ) ;
   int (*tif_setupdecode)(TIFF * ) ;
   int (*tif_predecode)(TIFF * , uint16  ) ;
   int (*tif_setupencode)(TIFF * ) ;
   int tif_encodestatus ;
   int (*tif_preencode)(TIFF * , uint16  ) ;
   int (*tif_postencode)(TIFF * ) ;
   int (*tif_decoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_decodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_encodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_decodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   void (*tif_close)(TIFF * ) ;
   int (*tif_seek)(TIFF * , uint32  ) ;
   void (*tif_cleanup)(TIFF * ) ;
   uint32 (*tif_defstripsize)(TIFF * , uint32  ) ;
   void (*tif_deftilesize)(TIFF * , uint32 * , uint32 * ) ;
   uint8 *tif_data ;
   tmsize_t tif_scanlinesize ;
   tmsize_t tif_scanlineskew ;
   uint8 *tif_rawdata ;
   tmsize_t tif_rawdatasize ;
   uint8 *tif_rawcp ;
   tmsize_t tif_rawcc ;
   uint8 *tif_base ;
   tmsize_t tif_size ;
   int (*tif_mapproc)(thandle_t  , void **base , toff_t *size ) ;
   void (*tif_unmapproc)(thandle_t  , void *base , toff_t size ) ;
   thandle_t tif_clientdata ;
   tmsize_t (*tif_readproc)(thandle_t  , void * , tmsize_t  ) ;
   tmsize_t (*tif_writeproc)(thandle_t  , void * , tmsize_t  ) ;
   uint64 (*tif_seekproc)(thandle_t  , uint64  , int  ) ;
   int (*tif_closeproc)(thandle_t  ) ;
   uint64 (*tif_sizeproc)(thandle_t  ) ;
   void (*tif_postdecode)(TIFF *tif , uint8 *buf , tmsize_t size ) ;
   TIFFField **tif_fields ;
   uint32 tif_nfields ;
   TIFFField const   *tif_foundfield ;
   TIFFTagMethods tif_tagmethods ;
   TIFFClientInfoLink *tif_clientinfo ;
   TIFFFieldArray *tif_fieldscompat ;
   uint32 tif_nfieldscompat ;
};
extern int select(int __nfds , fd_set * __restrict  __readfds ,
                  fd_set * __restrict  __writefds ,
                  fd_set * __restrict  __exceptfds ,
                  struct timeval * __restrict  __timeout ) ;
extern int pselect(int __nfds , fd_set * __restrict  __readfds ,
                   fd_set * __restrict  __writefds ,
                   fd_set * __restrict  __exceptfds ,
                   struct timespec  const  * __restrict  __timeout ,
                   __sigset_t const   * __restrict  __sigmask ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_major(unsigned long long __dev ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7763\n");
  fflush(_coverage_fout);
  return ((unsigned int )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_minor(unsigned long long __dev ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7764\n");
  fflush(_coverage_fout);
  return ((unsigned int )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                   unsigned int __minor ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7765\n");
  fflush(_coverage_fout);
  return (((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32));
}
}
extern int fcntl(int __fd , int __cmd  , ...) ;
extern int open(char const   *__file , int __oflag  , ...)  __asm__("open64") __attribute__((__nonnull__(1))) ;
extern int openat(int __fd , char const   *__file , int __oflag  , ...)  __asm__("openat64") __attribute__((__nonnull__(2))) ;
extern int creat(char const   *__file , __mode_t __mode )  __asm__("creat64") __attribute__((__nonnull__(1))) ;
extern int lockf(int __fd , int __cmd , __off64_t __len )  __asm__("lockf64")  ;
extern  __attribute__((__nothrow__)) int posix_fadvise(int __fd ,
                                                       __off64_t __offset ,
                                                       __off64_t __len ,
                                                       int __advise )  __asm__("posix_fadvise64")  ;
extern int posix_fallocate(int __fd , __off64_t __offset , __off64_t __len )  __asm__("posix_fallocate64")  ;
extern  __attribute__((__nothrow__)) void *memcpy(void * __restrict  __dest ,
                                                  void const   * __restrict  __src ,
                                                  size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memmove(void *__dest ,
                                                   void const   *__src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memccpy(void * __restrict  __dest ,
                                                   void const   * __restrict  __src ,
                                                   int __c , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memset(void *__s , int __c ,
                                                  size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int memcmp(void const   *__s1 ,
                                                void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memchr(void const   *__s , int __c ,
                                                  size_t __n )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strcat(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncat(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcmp(char const   *__s1 ,
                                                char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncmp(char const   *__s1 ,
                                                 char const   *__s2 ,
                                                 size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcoll(char const   *__s1 ,
                                                 char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm(char * __restrict  __dest ,
                                                    char const   * __restrict  __src ,
                                                    size_t __n )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int strcoll_l(char const   *__s1 ,
                                                   char const   *__s2 ,
                                                   __locale_t __l )  __attribute__((__pure__,
__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm_l(char *__dest ,
                                                      char const   *__src ,
                                                      size_t __n ,
                                                      __locale_t __l )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) char *strdup(char const   *__s )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strndup(char const   *__string ,
                                                   size_t __n )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strrchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strcspn(char const   *__s ,
                                                    char const   *__reject )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strspn(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strpbrk(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strstr(char const   *__haystack ,
                                                  char const   *__needle )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strtok(char * __restrict  __s ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *__strtok_r(char * __restrict  __s ,
                                                      char const   * __restrict  __delim ,
                                                      char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) char *strtok_r(char * __restrict  __s ,
                                                    char const   * __restrict  __delim ,
                                                    char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) size_t strlen(char const   *__s )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strnlen(char const   *__string ,
                                                    size_t __maxlen )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strerror(int __errnum ) ;
extern  __attribute__((__nothrow__)) int strerror_r(int __errnum , char *__buf ,
                                                    size_t __buflen )  __asm__("__xpg_strerror_r") __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *strerror_l(int __errnum ,
                                                      __locale_t __l ) ;
extern  __attribute__((__nothrow__)) void __bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void bcopy(void const   *__src ,
                                                void *__dest , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int bcmp(void const   *__s1 ,
                                              void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *index(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *rindex(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int ffs(int __i )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int strcasecmp(char const   *__s1 ,
                                                    char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncasecmp(char const   *__s1 ,
                                                     char const   *__s2 ,
                                                     size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsep(char ** __restrict  __stringp ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsignal(int __sig ) ;
extern  __attribute__((__nothrow__)) char *__stpcpy(char * __restrict  __dest ,
                                                    char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *__stpncpy(char * __restrict  __dest ,
                                                     char const   * __restrict  __src ,
                                                     size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern void *__rawmemchr(void const   *__s , int __c ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7770\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "7771\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7768\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "7767\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject) {
        fprintf(_coverage_fout, "7766\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "7769\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "7772\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) ;
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7778\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "7779\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7776\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "7775\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        fprintf(_coverage_fout, "7774\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          fprintf(_coverage_fout, "7773\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "7777\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "7780\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) ;
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7787\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "7788\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7785\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "7784\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        fprintf(_coverage_fout, "7783\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          fprintf(_coverage_fout, "7782\n");
          fflush(_coverage_fout);
          if ((int const   )*(__s + __result) != (int const   )__reject3) {
            fprintf(_coverage_fout, "7781\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "7786\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "7789\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) ;
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7793\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "7794\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7791\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept) {
      fprintf(_coverage_fout, "7790\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "7792\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "7795\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7801\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "7802\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7799\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      fprintf(_coverage_fout, "7796\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "7798\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        fprintf(_coverage_fout, "7797\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    }
    fprintf(_coverage_fout, "7800\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "7803\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7811\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "7812\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7809\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      fprintf(_coverage_fout, "7804\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "7808\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        fprintf(_coverage_fout, "7805\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "7807\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) == (int const   )__accept3) {
          fprintf(_coverage_fout, "7806\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      }
    }
    fprintf(_coverage_fout, "7810\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "7813\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7821\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7817\n");
    fflush(_coverage_fout);
    if ((int const   )*__s != 0) {
      fprintf(_coverage_fout, "7816\n");
      fflush(_coverage_fout);
      if ((int const   )*__s != (int const   )__accept1) {
        fprintf(_coverage_fout, "7815\n");
        fflush(_coverage_fout);
        if ((int const   )*__s != (int const   )__accept2) {
          fprintf(_coverage_fout, "7814\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "7818\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "7822\n");
  fflush(_coverage_fout);
  if ((int const   )*__s == 0) {
    fprintf(_coverage_fout, "7819\n");
    fflush(_coverage_fout);
    tmp = (char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "7820\n");
    fflush(_coverage_fout);
    tmp = (char *)((unsigned int )__s);
  }
  fprintf(_coverage_fout, "7823\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7832\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7828\n");
    fflush(_coverage_fout);
    if ((int const   )*__s != 0) {
      fprintf(_coverage_fout, "7827\n");
      fflush(_coverage_fout);
      if ((int const   )*__s != (int const   )__accept1) {
        fprintf(_coverage_fout, "7826\n");
        fflush(_coverage_fout);
        if ((int const   )*__s != (int const   )__accept2) {
          fprintf(_coverage_fout, "7825\n");
          fflush(_coverage_fout);
          if ((int const   )*__s != (int const   )__accept3) {
            fprintf(_coverage_fout, "7824\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "7829\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "7833\n");
  fflush(_coverage_fout);
  if ((int const   )*__s == 0) {
    fprintf(_coverage_fout, "7830\n");
    fflush(_coverage_fout);
    tmp = (char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "7831\n");
    fflush(_coverage_fout);
    tmp = (char *)((unsigned int )__s);
  }
  fprintf(_coverage_fout, "7834\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) ;
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) 
{ char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7852\n");
  fflush(_coverage_fout);
  if ((unsigned int )__s == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "7835\n");
    fflush(_coverage_fout);
    __s = *__nextp;
  } else {
    fprintf(_coverage_fout, "7836\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7853\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7838\n");
    fflush(_coverage_fout);
    if ((int )*__s == (int )__sep) {
      fprintf(_coverage_fout, "7837\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "7839\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "7854\n");
  fflush(_coverage_fout);
  __result = (char *)((void *)0);
  fprintf(_coverage_fout, "7855\n");
  fflush(_coverage_fout);
  if ((int )*__s != 0) {
    fprintf(_coverage_fout, "7847\n");
    fflush(_coverage_fout);
    tmp = __s;
    fprintf(_coverage_fout, "7848\n");
    fflush(_coverage_fout);
    __s ++;
    fprintf(_coverage_fout, "7849\n");
    fflush(_coverage_fout);
    __result = tmp;
    fprintf(_coverage_fout, "7850\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "7843\n");
      fflush(_coverage_fout);
      if ((int )*__s != 0) {
        fprintf(_coverage_fout, "7840\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "7844\n");
      fflush(_coverage_fout);
      tmp___0 = __s;
      fprintf(_coverage_fout, "7845\n");
      fflush(_coverage_fout);
      __s ++;
      fprintf(_coverage_fout, "7846\n");
      fflush(_coverage_fout);
      if ((int )*tmp___0 == (int )__sep) {
        fprintf(_coverage_fout, "7841\n");
        fflush(_coverage_fout);
        *(__s + -1) = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "7842\n");
        fflush(_coverage_fout);

      }
    }
  } else {
    fprintf(_coverage_fout, "7851\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7856\n");
  fflush(_coverage_fout);
  *__nextp = __s;
  fprintf(_coverage_fout, "7857\n");
  fflush(_coverage_fout);
  return (__result);
}
}
extern char *__strsep_g(char **__stringp , char const   *__delim ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) 
{ register char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  void *tmp___1 ;
  char *tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7867\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "7868\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "7862\n");
    fflush(_coverage_fout);
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    fprintf(_coverage_fout, "7863\n");
    fflush(_coverage_fout);
    tmp___0 = tmp___2;
    fprintf(_coverage_fout, "7864\n");
    fflush(_coverage_fout);
    *__s = tmp___0;
    fprintf(_coverage_fout, "7865\n");
    fflush(_coverage_fout);
    if ((unsigned int )tmp___0 != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "7858\n");
      fflush(_coverage_fout);
      tmp = *__s;
      fprintf(_coverage_fout, "7859\n");
      fflush(_coverage_fout);
      (*__s) ++;
      fprintf(_coverage_fout, "7860\n");
      fflush(_coverage_fout);
      *tmp = (char )'\000';
    } else {
      fprintf(_coverage_fout, "7861\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "7866\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7869\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) ;
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7887\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "7888\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "7883\n");
    fflush(_coverage_fout);
    __cp = __retval;
    fprintf(_coverage_fout, "7884\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "7880\n");
      fflush(_coverage_fout);
      if ((int )*__cp == 0) {
        fprintf(_coverage_fout, "7870\n");
        fflush(_coverage_fout);
        __cp = (char *)((void *)0);
        break;
      } else {
        fprintf(_coverage_fout, "7871\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "7881\n");
      fflush(_coverage_fout);
      if ((int )*__cp == (int )__reject1) {
        fprintf(_coverage_fout, "7872\n");
        fflush(_coverage_fout);
        tmp = __cp;
        fprintf(_coverage_fout, "7873\n");
        fflush(_coverage_fout);
        __cp ++;
        fprintf(_coverage_fout, "7874\n");
        fflush(_coverage_fout);
        *tmp = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "7879\n");
        fflush(_coverage_fout);
        if ((int )*__cp == (int )__reject2) {
          fprintf(_coverage_fout, "7875\n");
          fflush(_coverage_fout);
          tmp = __cp;
          fprintf(_coverage_fout, "7876\n");
          fflush(_coverage_fout);
          __cp ++;
          fprintf(_coverage_fout, "7877\n");
          fflush(_coverage_fout);
          *tmp = (char )'\000';
          break;
        } else {
          fprintf(_coverage_fout, "7878\n");
          fflush(_coverage_fout);

        }
      }
      fprintf(_coverage_fout, "7882\n");
      fflush(_coverage_fout);
      __cp ++;
    }
    fprintf(_coverage_fout, "7885\n");
    fflush(_coverage_fout);
    *__s = __cp;
  } else {
    fprintf(_coverage_fout, "7886\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7889\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) ;
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7911\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "7912\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "7907\n");
    fflush(_coverage_fout);
    __cp = __retval;
    fprintf(_coverage_fout, "7908\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "7904\n");
      fflush(_coverage_fout);
      if ((int )*__cp == 0) {
        fprintf(_coverage_fout, "7890\n");
        fflush(_coverage_fout);
        __cp = (char *)((void *)0);
        break;
      } else {
        fprintf(_coverage_fout, "7891\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "7905\n");
      fflush(_coverage_fout);
      if ((int )*__cp == (int )__reject1) {
        fprintf(_coverage_fout, "7892\n");
        fflush(_coverage_fout);
        tmp = __cp;
        fprintf(_coverage_fout, "7893\n");
        fflush(_coverage_fout);
        __cp ++;
        fprintf(_coverage_fout, "7894\n");
        fflush(_coverage_fout);
        *tmp = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "7903\n");
        fflush(_coverage_fout);
        if ((int )*__cp == (int )__reject2) {
          fprintf(_coverage_fout, "7895\n");
          fflush(_coverage_fout);
          tmp = __cp;
          fprintf(_coverage_fout, "7896\n");
          fflush(_coverage_fout);
          __cp ++;
          fprintf(_coverage_fout, "7897\n");
          fflush(_coverage_fout);
          *tmp = (char )'\000';
          break;
        } else {
          fprintf(_coverage_fout, "7902\n");
          fflush(_coverage_fout);
          if ((int )*__cp == (int )__reject3) {
            fprintf(_coverage_fout, "7898\n");
            fflush(_coverage_fout);
            tmp = __cp;
            fprintf(_coverage_fout, "7899\n");
            fflush(_coverage_fout);
            __cp ++;
            fprintf(_coverage_fout, "7900\n");
            fflush(_coverage_fout);
            *tmp = (char )'\000';
            break;
          } else {
            fprintf(_coverage_fout, "7901\n");
            fflush(_coverage_fout);

          }
        }
      }
      fprintf(_coverage_fout, "7906\n");
      fflush(_coverage_fout);
      __cp ++;
    }
    fprintf(_coverage_fout, "7909\n");
    fflush(_coverage_fout);
    *__s = __cp;
  } else {
    fprintf(_coverage_fout, "7910\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7913\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
extern  __attribute__((__nothrow__)) void *malloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *calloc(size_t __nmemb ,
                                                  size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strdup(char const   *__string )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strndup(char const   *__string ,
                                                     size_t __n )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_fail(char const   *__assertion ,
                                  char const   *__file , unsigned int __line ,
                                  char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_perror_fail(int __errnum , char const   *__file ,
                                         unsigned int __line ,
                                         char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert(char const   *__assertion , char const   *__file ,
                             int __line ) ;
extern  __attribute__((__nothrow__)) void insque(void *__elem , void *__prev ) ;
extern  __attribute__((__nothrow__)) void remque(void *__elem ) ;
extern  __attribute__((__nothrow__)) ENTRY *hsearch(ENTRY __item ,
                                                    ACTION __action ) ;
extern  __attribute__((__nothrow__)) int hcreate(size_t __nel ) ;
extern  __attribute__((__nothrow__)) void hdestroy(void) ;
extern void *tsearch(void const   *__key , void **__rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void *tfind(void const   *__key , void * const  *__rootp ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *tdelete(void const   * __restrict  __key ,
                     void ** __restrict  __rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void twalk(void const   *__root ,
                  void (*__action)(void const   *__nodep , VISIT __value ,
                                   int __level ) ) ;
extern void *lfind(void const   *__key , void const   *__base ,
                   size_t *__nmemb , size_t __size ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *lsearch(void const   *__key , void *__base , size_t *__nmemb ,
                     size_t __size , int (*__compar)(void const   * ,
                                                     void const   * ) ) ;
extern struct _IO_FILE_plus _IO_2_1_stdin_ ;
extern struct _IO_FILE_plus _IO_2_1_stdout_ ;
extern struct _IO_FILE_plus _IO_2_1_stderr_ ;
extern int __underflow(_IO_FILE * ) ;
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_feof(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_ferror(_IO_FILE *__fp ) ;
extern int _IO_peekc_locked(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) void _IO_flockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) void _IO_funlockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) int _IO_ftrylockfile(_IO_FILE * ) ;
extern int _IO_vfscanf(_IO_FILE * __restrict   , char const   * __restrict   ,
                       __gnuc_va_list  , int * __restrict   ) ;
extern int _IO_vfprintf(_IO_FILE * __restrict   , char const   * __restrict   ,
                        __gnuc_va_list  ) ;
extern __ssize_t _IO_padn(_IO_FILE * , int  , __ssize_t  ) ;
extern size_t _IO_sgetn(_IO_FILE * , void * , size_t  ) ;
extern __off64_t _IO_seekoff(_IO_FILE * , __off64_t  , int  , int  ) ;
extern __off64_t _IO_seekpos(_IO_FILE * , __off64_t  , int  ) ;
extern  __attribute__((__nothrow__)) void _IO_free_backup_area(_IO_FILE * ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
extern  __attribute__((__nothrow__)) int remove(char const   *__filename ) ;
extern  __attribute__((__nothrow__)) int rename(char const   *__old ,
                                                char const   *__new ) ;
extern  __attribute__((__nothrow__)) int renameat(int __oldfd ,
                                                  char const   *__old ,
                                                  int __newfd ,
                                                  char const   *__new ) ;
extern FILE *tmpfile(void)  __asm__("tmpfile64")  ;
extern  __attribute__((__nothrow__)) char *tmpnam(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tmpnam_r(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tempnam(char const   *__dir ,
                                                   char const   *__pfx )  __attribute__((__malloc__)) ;
extern int fclose(FILE *__stream ) ;
extern int fflush(FILE *__stream ) ;
extern int fflush_unlocked(FILE *__stream ) ;
extern FILE *freopen(char const   * __restrict  __filename ,
                     char const   * __restrict  __modes ,
                     FILE * __restrict  __stream )  __asm__("freopen64")  ;
extern  __attribute__((__nothrow__)) FILE *fdopen(int __fd ,
                                                  char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *fmemopen(void *__s , size_t __len ,
                                                    char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *open_memstream(char **__bufloc ,
                                                          size_t *__sizeloc ) ;
extern  __attribute__((__nothrow__)) void setbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) int setvbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ,
                                                 int __modes , size_t __n ) ;
extern  __attribute__((__nothrow__)) void setbuffer(FILE * __restrict  __stream ,
                                                    char * __restrict  __buf ,
                                                    size_t __size ) ;
extern  __attribute__((__nothrow__)) void setlinebuf(FILE *__stream ) ;
extern int fprintf(FILE * __restrict  __stream ,
                   char const   * __restrict  __format  , ...) ;
extern int printf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sprintf(char * __restrict  __s ,
                                                 char const   * __restrict  __format 
                                                 , ...) ;
extern int vfprintf(FILE * __restrict  __s ,
                    char const   * __restrict  __format , __gnuc_va_list __arg ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vsprintf(char * __restrict  __s ,
                                                  char const   * __restrict  __format ,
                                                  __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  snprintf)(char * __restrict  __s ,
                                                                             size_t __maxlen ,
                                                                             char const   * __restrict  __format 
                                                                             , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsnprintf)(char * __restrict  __s ,
                                                                              size_t __maxlen ,
                                                                              char const   * __restrict  __format ,
                                                                              __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  vdprintf)(int __fd ,
                                               char const   * __restrict  __fmt ,
                                               __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  dprintf)(int __fd ,
                                              char const   * __restrict  __fmt 
                                              , ...) ;
extern int fscanf(FILE * __restrict  __stream ,
                  char const   * __restrict  __format  , ...)  __asm__("__isoc99_fscanf")  ;
extern int scanf(char const   * __restrict  __format  , ...)  __asm__("__isoc99_scanf")  ;
extern  __attribute__((__nothrow__)) int sscanf(char const   * __restrict  __s ,
                                                char const   * __restrict  __format 
                                                , ...)  __asm__("__isoc99_sscanf")  ;
extern int ( /* format attribute */  vfscanf)(FILE * __restrict  __s ,
                                              char const   * __restrict  __format ,
                                              __gnuc_va_list __arg )  __asm__("__isoc99_vfscanf")  ;
extern int ( /* format attribute */  vscanf)(char const   * __restrict  __format ,
                                             __gnuc_va_list __arg )  __asm__("__isoc99_vscanf")  ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsscanf)(char const   * __restrict  __s ,
                                                                            char const   * __restrict  __format ,
                                                                            __gnuc_va_list __arg )  __asm__("__isoc99_vsscanf")  ;
extern int fgetc(FILE *__stream ) ;
extern int getc(FILE *__stream ) ;
__inline extern int getchar(void) ;
__inline extern int getc_unlocked(FILE *__fp ) ;
__inline extern int getchar_unlocked(void) ;
__inline extern int fgetc_unlocked(FILE *__fp ) ;
extern int fputc(int __c , FILE *__stream ) ;
extern int putc(int __c , FILE *__stream ) ;
__inline extern int putchar(int __c ) ;
__inline extern int fputc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putchar_unlocked(int __c ) ;
extern int getw(FILE *__stream ) ;
extern int putw(int __w , FILE *__stream ) ;
extern char *fgets(char * __restrict  __s , int __n ,
                   FILE * __restrict  __stream ) ;
extern char *gets(char *__s ) ;
extern __ssize_t __getdelim(char ** __restrict  __lineptr ,
                            size_t * __restrict  __n , int __delimiter ,
                            FILE * __restrict  __stream ) ;
extern __ssize_t getdelim(char ** __restrict  __lineptr ,
                          size_t * __restrict  __n , int __delimiter ,
                          FILE * __restrict  __stream ) ;
extern __ssize_t getline(char ** __restrict  __lineptr ,
                         size_t * __restrict  __n , FILE * __restrict  __stream ) ;
extern int fputs(char const   * __restrict  __s , FILE * __restrict  __stream ) ;
extern int puts(char const   *__s ) ;
extern int ungetc(int __c , FILE *__stream ) ;
extern size_t fread(void * __restrict  __ptr , size_t __size , size_t __n ,
                    FILE * __restrict  __stream ) ;
extern size_t fwrite(void const   * __restrict  __ptr , size_t __size ,
                     size_t __n , FILE * __restrict  __s ) ;
extern size_t fread_unlocked(void * __restrict  __ptr , size_t __size ,
                             size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite_unlocked(void const   * __restrict  __ptr , size_t __size ,
                              size_t __n , FILE * __restrict  __stream ) ;
extern int fseek(FILE *__stream , long __off , int __whence ) ;
extern long ftell(FILE *__stream ) ;
extern void rewind(FILE *__stream ) ;
extern int fseeko(FILE *__stream , __off64_t __off , int __whence )  __asm__("fseeko64")  ;
extern __off64_t ftello(FILE *__stream )  __asm__("ftello64")  ;
extern int fgetpos(FILE * __restrict  __stream , fpos_t * __restrict  __pos )  __asm__("fgetpos64")  ;
extern int fsetpos(FILE *__stream , fpos_t const   *__pos )  __asm__("fsetpos64")  ;
extern  __attribute__((__nothrow__)) void clearerr(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int feof(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ferror(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void clearerr_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
extern void perror(char const   *__s ) ;
extern int sys_nerr ;
extern char const   * const  sys_errlist[] ;
extern  __attribute__((__nothrow__)) int fileno(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int fileno_unlocked(FILE *__stream ) ;
extern FILE *popen(char const   *__command , char const   *__modes ) ;
extern int pclose(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) char *ctermid(char *__s ) ;
extern  __attribute__((__nothrow__)) void flockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ftrylockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void funlockfile(FILE *__stream ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7914\n");
  fflush(_coverage_fout);
  tmp = vfprintf((FILE */* __restrict  */)stdout, __fmt, __arg);
  fprintf(_coverage_fout, "7915\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int getchar(void) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7916\n");
  fflush(_coverage_fout);
  tmp = _IO_getc(stdin);
  fprintf(_coverage_fout, "7917\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int fgetc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7923\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "7924\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "7918\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "7919\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "7920\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "7921\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "7922\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "7925\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int getc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7931\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "7932\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "7926\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "7927\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "7928\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "7929\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "7930\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "7933\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int getchar_unlocked(void) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7939\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )stdin->_IO_read_ptr >= (unsigned int )stdin->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "7940\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "7934\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(stdin);
    fprintf(_coverage_fout, "7935\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "7936\n");
    fflush(_coverage_fout);
    tmp___1 = stdin->_IO_read_ptr;
    fprintf(_coverage_fout, "7937\n");
    fflush(_coverage_fout);
    (stdin->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "7938\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "7941\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int putchar(int __c ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7942\n");
  fflush(_coverage_fout);
  tmp = _IO_putc(__c, stdout);
  fprintf(_coverage_fout, "7943\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int fputc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7951\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "7952\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "7944\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "7945\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "7946\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "7947\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "7948\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "7949\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "7950\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "7953\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern int putc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7961\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "7962\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "7954\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "7955\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "7956\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "7957\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "7958\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "7959\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "7960\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "7963\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern int putchar_unlocked(int __c ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7971\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )stdout->_IO_write_ptr >= (unsigned int )stdout->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "7972\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "7964\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "7965\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "7966\n");
    fflush(_coverage_fout);
    tmp___1 = stdout->_IO_write_ptr;
    fprintf(_coverage_fout, "7967\n");
    fflush(_coverage_fout);
    (stdout->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "7968\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "7969\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "7970\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "7973\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern int feof_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7974\n");
  fflush(_coverage_fout);
  return ((__stream->_flags & 0x10) != 0);
}
}
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
__inline extern int ferror_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7975\n");
  fflush(_coverage_fout);
  return ((__stream->_flags & 0x20) != 0);
}
}
extern char const   *TIFFGetVersion(void) ;
extern TIFFCodec const   *TIFFFindCODEC(uint16  ) ;
extern TIFFCodec *TIFFRegisterCODEC(uint16  , char const   * ,
                                    int (*)(TIFF * , int  ) ) ;
extern void TIFFUnRegisterCODEC(TIFFCodec * ) ;
extern int TIFFIsCODECConfigured(uint16  ) ;
extern TIFFCodec *TIFFGetConfiguredCODECs(void) ;
extern void *_TIFFmalloc(tmsize_t s ) ;
extern void *_TIFFrealloc(void *p , tmsize_t s ) ;
extern void _TIFFmemset(void *p , int v , tmsize_t c ) ;
extern void _TIFFmemcpy(void *d , void const   *s , tmsize_t c ) ;
extern int _TIFFmemcmp(void const   *p1 , void const   *p2 , tmsize_t c ) ;
extern void _TIFFfree(void *p ) ;
extern int TIFFGetTagListCount(TIFF * ) ;
extern uint32 TIFFGetTagListEntry(TIFF * , int tag_index ) ;
extern TIFFField const   *TIFFFindField(TIFF * , uint32  , TIFFDataType  ) ;
extern TIFFField const   *TIFFFieldWithTag(TIFF * , uint32  ) ;
extern TIFFField const   *TIFFFieldWithName(TIFF * , char const   * ) ;
extern TIFFTagMethods *TIFFAccessTagMethods(TIFF * ) ;
extern void *TIFFGetClientInfo(TIFF * , char const   * ) ;
extern void TIFFSetClientInfo(TIFF * , void * , char const   * ) ;
extern void TIFFCleanup(TIFF *tif ) ;
extern void TIFFClose(TIFF *tif ) ;
extern int TIFFFlush(TIFF *tif ) ;
extern int TIFFFlushData(TIFF *tif ) ;
extern int TIFFGetField(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFVGetField(TIFF *tif , uint32 tag , va_list ap ) ;
extern int TIFFGetFieldDefaulted(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFVGetFieldDefaulted(TIFF *tif , uint32 tag , va_list ap ) ;
extern int TIFFReadDirectory(TIFF *tif ) ;
extern int TIFFReadCustomDirectory(TIFF *tif , uint64 diroff ,
                                   TIFFFieldArray const   *infoarray ) ;
extern int TIFFReadEXIFDirectory(TIFF *tif , uint64 diroff ) ;
extern uint64 TIFFScanlineSize64(TIFF *tif ) ;
extern tmsize_t TIFFScanlineSize(TIFF *tif ) ;
extern uint64 TIFFRasterScanlineSize64(TIFF *tif ) ;
extern tmsize_t TIFFRasterScanlineSize(TIFF *tif ) ;
extern uint64 TIFFStripSize64(TIFF *tif ) ;
extern tmsize_t TIFFStripSize(TIFF *tif ) ;
extern uint64 TIFFRawStripSize64(TIFF *tif , uint32 strip ) ;
extern tmsize_t TIFFRawStripSize(TIFF *tif , uint32 strip ) ;
extern uint64 TIFFVStripSize64(TIFF *tif , uint32 nrows ) ;
extern tmsize_t TIFFVStripSize(TIFF *tif , uint32 nrows ) ;
extern uint64 TIFFTileRowSize64(TIFF *tif ) ;
extern tmsize_t TIFFTileRowSize(TIFF *tif ) ;
extern uint64 TIFFTileSize64(TIFF *tif ) ;
extern tmsize_t TIFFTileSize(TIFF *tif ) ;
extern uint64 TIFFVTileSize64(TIFF *tif , uint32 nrows ) ;
extern tmsize_t TIFFVTileSize(TIFF *tif , uint32 nrows ) ;
extern uint32 TIFFDefaultStripSize(TIFF *tif , uint32 request ) ;
extern void TIFFDefaultTileSize(TIFF * , uint32 * , uint32 * ) ;
extern int TIFFFileno(TIFF * ) ;
extern int TIFFSetFileno(TIFF * , int  ) ;
extern thandle_t TIFFClientdata(TIFF * ) ;
extern thandle_t TIFFSetClientdata(TIFF * , thandle_t  ) ;
extern int TIFFGetMode(TIFF * ) ;
extern int TIFFSetMode(TIFF * , int  ) ;
extern int TIFFIsTiled(TIFF * ) ;
extern int TIFFIsByteSwapped(TIFF * ) ;
extern int TIFFIsUpSampled(TIFF * ) ;
extern int TIFFIsMSB2LSB(TIFF * ) ;
extern int TIFFIsBigEndian(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetReadProc(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetWriteProc(TIFF * ) ;
extern TIFFSeekProc TIFFGetSeekProc(TIFF * ) ;
extern TIFFCloseProc TIFFGetCloseProc(TIFF * ) ;
extern TIFFSizeProc TIFFGetSizeProc(TIFF * ) ;
extern TIFFMapFileProc TIFFGetMapFileProc(TIFF * ) ;
extern TIFFUnmapFileProc TIFFGetUnmapFileProc(TIFF * ) ;
extern uint32 TIFFCurrentRow(TIFF * ) ;
extern uint16 TIFFCurrentDirectory(TIFF * ) ;
extern uint16 TIFFNumberOfDirectories(TIFF * ) ;
extern uint64 TIFFCurrentDirOffset(TIFF * ) ;
extern uint32 TIFFCurrentStrip(TIFF * ) ;
extern uint32 TIFFCurrentTile(TIFF *tif ) ;
extern int TIFFReadBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
int TIFFWriteBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
int TIFFSetupStrips(TIFF *tif ) ;
int TIFFWriteCheck(TIFF *tif , int tiles , char const   *module___4 ) ;
extern void TIFFFreeDirectory(TIFF * ) ;
extern int TIFFCreateDirectory(TIFF * ) ;
extern int TIFFLastDirectory(TIFF * ) ;
extern int TIFFSetDirectory(TIFF * , uint16  ) ;
extern int TIFFSetSubDirectory(TIFF * , uint64  ) ;
extern int TIFFUnlinkDirectory(TIFF * , uint16  ) ;
extern int TIFFSetField(TIFF * , uint32   , ...) ;
extern int TIFFVSetField(TIFF * , uint32  , va_list  ) ;
extern int TIFFWriteDirectory(TIFF * ) ;
extern int TIFFCheckpointDirectory(TIFF * ) ;
extern int TIFFRewriteDirectory(TIFF * ) ;
extern void TIFFPrintDirectory(TIFF * , FILE * , long  ) ;
extern int TIFFReadScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) ;
int TIFFWriteScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) ;
extern int TIFFReadRGBAImage(TIFF * , uint32  , uint32  , uint32 * , int  ) ;
extern int TIFFReadRGBAImageOriented(TIFF * , uint32  , uint32  , uint32 * ,
                                     int  , int  ) ;
extern int TIFFReadRGBAStrip(TIFF * , uint32  , uint32 * ) ;
extern int TIFFReadRGBATile(TIFF * , uint32  , uint32  , uint32 * ) ;
extern int TIFFRGBAImageOK(TIFF * , char * ) ;
extern int TIFFRGBAImageBegin(TIFFRGBAImage * , TIFF * , int  , char * ) ;
extern int TIFFRGBAImageGet(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
extern void TIFFRGBAImageEnd(TIFFRGBAImage * ) ;
extern TIFF *TIFFOpen(char const   * , char const   * ) ;
extern TIFF *TIFFFdOpen(int  , char const   * , char const   * ) ;
extern TIFF *TIFFClientOpen(char const   * , char const   * , thandle_t  ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            uint64 (*)(thandle_t  , uint64  , int  ) ,
                            int (*)(thandle_t  ) , uint64 (*)(thandle_t  ) ,
                            int (*)(thandle_t  , void **base , toff_t *size ) ,
                            void (*)(thandle_t  , void *base , toff_t size ) ) ;
extern char const   *TIFFFileName(TIFF * ) ;
extern char const   *TIFFSetFileName(TIFF * , char const   * ) ;
extern void TIFFError(char const   * , char const   *  , ...) ;
extern void TIFFErrorExt(thandle_t  , char const   * , char const   *  , ...) ;
extern void TIFFWarning(char const   * , char const   *  , ...) ;
extern void TIFFWarningExt(thandle_t  , char const   * , char const   *  , ...) ;
extern TIFFErrorHandler TIFFSetErrorHandler(void (*)(char const   * ,
                                                     char const   * , va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetErrorHandlerExt(void (*)(thandle_t  ,
                                                           char const   * ,
                                                           char const   * ,
                                                           va_list  ) ) ;
extern TIFFErrorHandler TIFFSetWarningHandler(void (*)(char const   * ,
                                                       char const   * ,
                                                       va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetWarningHandlerExt(void (*)(thandle_t  ,
                                                             char const   * ,
                                                             char const   * ,
                                                             va_list  ) ) ;
extern TIFFExtendProc TIFFSetTagExtender(void (*)(TIFF * ) ) ;
extern uint32 TIFFComputeTile(TIFF *tif , uint32 x , uint32 y , uint32 z ,
                              uint16 s ) ;
extern int TIFFCheckTile(TIFF *tif , uint32 x , uint32 y , uint32 z , uint16 s ) ;
extern uint32 TIFFNumberOfTiles(TIFF * ) ;
extern tmsize_t TIFFReadTile(TIFF *tif , void *buf , uint32 x , uint32 y ,
                             uint32 z , uint16 s ) ;
tmsize_t TIFFWriteTile(TIFF *tif , void *buf , uint32 x , uint32 y , uint32 z ,
                       uint16 s ) ;
extern uint32 TIFFComputeStrip(TIFF * , uint32  , uint16  ) ;
extern uint32 TIFFNumberOfStrips(TIFF * ) ;
extern tmsize_t TIFFReadEncodedStrip(TIFF *tif , uint32 strip , void *buf ,
                                     tmsize_t size ) ;
extern tmsize_t TIFFReadRawStrip(TIFF *tif , uint32 strip , void *buf ,
                                 tmsize_t size ) ;
extern tmsize_t TIFFReadEncodedTile(TIFF *tif , uint32 tile , void *buf ,
                                    tmsize_t size ) ;
extern tmsize_t TIFFReadRawTile(TIFF *tif , uint32 tile , void *buf ,
                                tmsize_t size ) ;
tmsize_t TIFFWriteEncodedStrip(TIFF *tif , uint32 strip , void *data ,
                               tmsize_t cc ) ;
tmsize_t TIFFWriteRawStrip(TIFF *tif , uint32 strip , void *data , tmsize_t cc ) ;
tmsize_t TIFFWriteEncodedTile(TIFF *tif , uint32 tile , void *data ,
                              tmsize_t cc ) ;
tmsize_t TIFFWriteRawTile(TIFF *tif , uint32 tile , void *data , tmsize_t cc ) ;
extern int TIFFDataWidth(TIFFDataType  ) ;
void TIFFSetWriteOffset(TIFF *tif , uint64 off ) ;
extern void TIFFSwabShort(uint16 * ) ;
extern void TIFFSwabLong(uint32 * ) ;
extern void TIFFSwabLong8(uint64 * ) ;
extern void TIFFSwabFloat(float * ) ;
extern void TIFFSwabDouble(double * ) ;
extern void TIFFSwabArrayOfShort(uint16 *wp , tmsize_t n ) ;
extern void TIFFSwabArrayOfTriples(uint8 *tp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong(uint32 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong8(uint64 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfFloat(float *fp , tmsize_t n ) ;
extern void TIFFSwabArrayOfDouble(double *dp , tmsize_t n ) ;
extern void TIFFReverseBits(uint8 *cp , tmsize_t n ) ;
extern unsigned char const   *TIFFGetBitRevTable(int  ) ;
extern double LogL16toY(int  ) ;
extern double LogL10toY(int  ) ;
extern void XYZtoRGB24(float * , uint8 * ) ;
extern int uv_decode(double * , double * , int  ) ;
extern void LogLuv24toXYZ(uint32  , float * ) ;
extern void LogLuv32toXYZ(uint32  , float * ) ;
extern int LogL16fromY(double  , int  ) ;
extern int LogL10fromY(double  , int  ) ;
extern int uv_encode(double  , double  , int  ) ;
extern uint32 LogLuv24fromXYZ(float * , int  ) ;
extern uint32 LogLuv32fromXYZ(float * , int  ) ;
extern int TIFFCIELabToRGBInit(TIFFCIELabToRGB * , TIFFDisplay * , float * ) ;
extern void TIFFCIELabToXYZ(TIFFCIELabToRGB * , uint32  , int32  , int32  ,
                            float * , float * , float * ) ;
extern void TIFFXYZToRGB(TIFFCIELabToRGB * , float  , float  , float  ,
                         uint32 * , uint32 * , uint32 * ) ;
extern int TIFFYCbCrToRGBInit(TIFFYCbCrToRGB * , float * , float * ) ;
extern void TIFFYCbCrtoRGB(TIFFYCbCrToRGB * , uint32  , int32  , int32  ,
                           uint32 * , uint32 * , uint32 * ) ;
extern int TIFFMergeFieldInfo(TIFF * , TIFFFieldInfo const   * , uint32  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfo(TIFF * , uint32  ,
                                                TIFFDataType  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfoByName(TIFF * , char const   * ,
                                                      TIFFDataType  ) ;
extern TIFFFieldArray const   *_TIFFGetFields(void) ;
extern TIFFFieldArray const   *_TIFFGetExifFields(void) ;
extern void _TIFFSetupFields(TIFF *tif , TIFFFieldArray const   *infoarray ) ;
extern void _TIFFPrintFieldInfo(TIFF * , FILE * ) ;
extern int _TIFFMergeFields(TIFF * , TIFFField const   * , uint32  ) ;
extern TIFFField const   *_TIFFFindOrRegisterField(TIFF * , uint32  ,
                                                   TIFFDataType  ) ;
extern TIFFField *_TIFFCreateAnonField(TIFF * , uint32  , TIFFDataType  ) ;
extern int _TIFFgetMode(char const   *mode , char const   *module ) ;
extern int _TIFFNoRowEncode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoStripEncode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoTileEncode(TIFF * , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoRowDecode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoStripDecode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoTileDecode(TIFF * , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern void _TIFFNoPostDecode(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern int _TIFFNoPreCode(TIFF *tif , uint16 s ) ;
extern int _TIFFNoSeek(TIFF *tif , uint32 off ) ;
extern void _TIFFSwab16BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab24BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab32BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab64BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
int TIFFFlushData1(TIFF *tif ) ;
extern int TIFFDefaultDirectory(TIFF *tif ) ;
extern void _TIFFSetDefaultCompressionState(TIFF *tif ) ;
extern int TIFFSetCompressionScheme(TIFF *tif , int scheme ) ;
extern int TIFFSetDefaultCompressionState(TIFF *tif ) ;
extern uint32 _TIFFDefaultStripSize(TIFF *tif , uint32 s ) ;
extern void _TIFFDefaultTileSize(TIFF *tif , uint32 *tw , uint32 *th ) ;
extern int _TIFFDataSize(TIFFDataType type ) ;
extern void _TIFFsetByteArray(void ** , void * , uint32  ) ;
extern void _TIFFsetString(char ** , char * ) ;
extern void _TIFFsetShortArray(uint16 ** , uint16 * , uint32  ) ;
extern void _TIFFsetLongArray(uint32 ** , uint32 * , uint32  ) ;
extern void _TIFFsetFloatArray(float ** , float * , uint32  ) ;
extern void _TIFFsetDoubleArray(double ** , double * , uint32  ) ;
extern void _TIFFprintAscii(FILE * , char const   * ) ;
extern void _TIFFprintAsciiTag(FILE * , char const   * , char const   * ) ;
extern void (*_TIFFwarningHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFerrorHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFwarningHandlerExt)(thandle_t  , char const   * ,
                                      char const   * , va_list  ) ;
extern void (*_TIFFerrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  ) ;
extern void *_TIFFCheckMalloc(TIFF *tif , tmsize_t nmemb , tmsize_t elem_size ,
                              char const   *what ) ;
extern void *_TIFFCheckRealloc(TIFF *tif , void *buffer , tmsize_t nmemb ,
                               tmsize_t elem_size , char const   *what ) ;
extern double _TIFFUInt64ToDouble(uint64  ) ;
extern float _TIFFUInt64ToFloat(uint64  ) ;
extern int TIFFInitDumpMode(TIFF * , int  ) ;
extern int TIFFInitPackBits(TIFF * , int  ) ;
extern int TIFFInitCCITTRLE(TIFF * , int  ) ;
extern int TIFFInitCCITTRLEW(TIFF * , int  ) ;
extern int TIFFInitCCITTFax3(TIFF * , int  ) ;
extern int TIFFInitCCITTFax4(TIFF * , int  ) ;
extern int TIFFInitThunderScan(TIFF * , int  ) ;
extern int TIFFInitNeXT(TIFF * , int  ) ;
extern int TIFFInitLZW(TIFF * , int  ) ;
extern int TIFFInitZIP(TIFF * , int  ) ;
extern int TIFFInitPixarLog(TIFF * , int  ) ;
extern int TIFFInitSGILog(TIFF * , int  ) ;
extern TIFFCodec _TIFFBuiltinCODECS[] ;
static int TIFFGrowStrips(TIFF *tif , uint32 delta , char const   *module___5 ) ;
static int TIFFAppendToStrip(TIFF *tif , uint32 strip , uint8 *data ,
                             tmsize_t cc ) ;
int TIFFWriteScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) ;
static char const   module[18]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'S',      (char const   )'c',      (char const   )'a', 
        (char const   )'n',      (char const   )'l',      (char const   )'i',      (char const   )'n', 
        (char const   )'e',      (char const   )'\000'};
int TIFFWriteScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) 
{ register TIFFDirectory *td ;
  int status ;
  int imagegrew ;
  uint32 strip ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "8045\n");
  fflush(_coverage_fout);
  imagegrew = 0;
  fprintf(_coverage_fout, "8046\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 64U) {
    fprintf(_coverage_fout, "7976\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "7979\n");
    fflush(_coverage_fout);
    tmp = TIFFWriteCheck(tif, 0, module);
    fprintf(_coverage_fout, "7980\n");
    fflush(_coverage_fout);
    if (tmp) {
      fprintf(_coverage_fout, "7977\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "7978\n");
      fflush(_coverage_fout);
      return (-1);
    }
  }
  fprintf(_coverage_fout, "8047\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 16U) {
    fprintf(_coverage_fout, "7982\n");
    fflush(_coverage_fout);
    if (tif->tif_rawdata) {
      fprintf(_coverage_fout, "7981\n");
      fflush(_coverage_fout);

    } else {
      goto _L;
    }
  } else {
    fprintf(_coverage_fout, "7985\n");
    fflush(_coverage_fout);
    _L: /* CIL Label */ 
    tmp___0 = TIFFWriteBufferSetup(tif, (void *)0, -1L);
    fprintf(_coverage_fout, "7986\n");
    fflush(_coverage_fout);
    if (tmp___0) {
      fprintf(_coverage_fout, "7983\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "7984\n");
      fflush(_coverage_fout);
      return (-1);
    }
  }
  fprintf(_coverage_fout, "8048\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "8049\n");
  fflush(_coverage_fout);
  if (row >= td->td_imagelength) {
    fprintf(_coverage_fout, "7990\n");
    fflush(_coverage_fout);
    if ((int )td->td_planarconfig == 2) {
      fprintf(_coverage_fout, "7987\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module,
                   "Can not change \"ImageLength\" when using separate planes");
      fprintf(_coverage_fout, "7988\n");
      fflush(_coverage_fout);
      return (-1);
    } else {
      fprintf(_coverage_fout, "7989\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "7991\n");
    fflush(_coverage_fout);
    td->td_imagelength = row + 1U;
    fprintf(_coverage_fout, "7992\n");
    fflush(_coverage_fout);
    imagegrew = 1;
  } else {
    fprintf(_coverage_fout, "7993\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8050\n");
  fflush(_coverage_fout);
  if ((int )td->td_planarconfig == 2) {
    fprintf(_coverage_fout, "7997\n");
    fflush(_coverage_fout);
    if ((int )sample >= (int )td->td_samplesperpixel) {
      fprintf(_coverage_fout, "7994\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module,
                   "%lu: Sample out of range, max %lu", (unsigned long )sample,
                   (unsigned long )td->td_samplesperpixel);
      fprintf(_coverage_fout, "7995\n");
      fflush(_coverage_fout);
      return (-1);
    } else {
      fprintf(_coverage_fout, "7996\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "7998\n");
    fflush(_coverage_fout);
    strip = (uint32 )sample * td->td_stripsperimage + row / td->td_rowsperstrip;
  } else {
    fprintf(_coverage_fout, "7999\n");
    fflush(_coverage_fout);
    strip = row / td->td_rowsperstrip;
  }
  fprintf(_coverage_fout, "8051\n");
  fflush(_coverage_fout);
  if (strip >= td->td_nstrips) {
    fprintf(_coverage_fout, "8002\n");
    fflush(_coverage_fout);
    tmp___1 = TIFFGrowStrips(tif, 1U, module);
    fprintf(_coverage_fout, "8003\n");
    fflush(_coverage_fout);
    if (tmp___1) {
      fprintf(_coverage_fout, "8000\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8001\n");
      fflush(_coverage_fout);
      return (-1);
    }
  } else {
    fprintf(_coverage_fout, "8004\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8052\n");
  fflush(_coverage_fout);
  if (strip != tif->tif_curstrip) {
    fprintf(_coverage_fout, "8022\n");
    fflush(_coverage_fout);
    tmp___2 = TIFFFlushData(tif);
    fprintf(_coverage_fout, "8023\n");
    fflush(_coverage_fout);
    if (tmp___2) {
      fprintf(_coverage_fout, "8005\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8006\n");
      fflush(_coverage_fout);
      return (-1);
    }
    fprintf(_coverage_fout, "8024\n");
    fflush(_coverage_fout);
    tif->tif_curstrip = strip;
    fprintf(_coverage_fout, "8025\n");
    fflush(_coverage_fout);
    if (strip >= td->td_stripsperimage) {
      fprintf(_coverage_fout, "8009\n");
      fflush(_coverage_fout);
      if (imagegrew) {
        fprintf(_coverage_fout, "8007\n");
        fflush(_coverage_fout);
        td->td_stripsperimage = (td->td_imagelength + (td->td_rowsperstrip - 1U)) / td->td_rowsperstrip;
      } else {
        fprintf(_coverage_fout, "8008\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "8010\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "8026\n");
    fflush(_coverage_fout);
    tif->tif_row = (strip % td->td_stripsperimage) * td->td_rowsperstrip;
    fprintf(_coverage_fout, "8027\n");
    fflush(_coverage_fout);
    if ((tif->tif_flags & 32U) == 0U) {
      fprintf(_coverage_fout, "8013\n");
      fflush(_coverage_fout);
      tmp___3 = (*(tif->tif_setupencode))(tif);
      fprintf(_coverage_fout, "8014\n");
      fflush(_coverage_fout);
      if (tmp___3) {
        fprintf(_coverage_fout, "8011\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "8012\n");
        fflush(_coverage_fout);
        return (-1);
      }
      fprintf(_coverage_fout, "8015\n");
      fflush(_coverage_fout);
      tif->tif_flags |= 32U;
    } else {
      fprintf(_coverage_fout, "8016\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "8028\n");
    fflush(_coverage_fout);
    tif->tif_rawcc = 0L;
    fprintf(_coverage_fout, "8029\n");
    fflush(_coverage_fout);
    tif->tif_rawcp = tif->tif_rawdata;
    fprintf(_coverage_fout, "8030\n");
    fflush(_coverage_fout);
    if (*(td->td_stripbytecount + strip) > 0ULL) {
      fprintf(_coverage_fout, "8017\n");
      fflush(_coverage_fout);
      *(td->td_stripbytecount + strip) = 0ULL;
      fprintf(_coverage_fout, "8018\n");
      fflush(_coverage_fout);
      tif->tif_curoff = 0ULL;
    } else {
      fprintf(_coverage_fout, "8019\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "8031\n");
    fflush(_coverage_fout);
    tmp___4 = (*(tif->tif_preencode))(tif, sample);
    fprintf(_coverage_fout, "8032\n");
    fflush(_coverage_fout);
    if (tmp___4) {
      fprintf(_coverage_fout, "8020\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8021\n");
      fflush(_coverage_fout);
      return (-1);
    }
    fprintf(_coverage_fout, "8033\n");
    fflush(_coverage_fout);
    tif->tif_flags |= 4096U;
  } else {
    fprintf(_coverage_fout, "8034\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8053\n");
  fflush(_coverage_fout);
  if (row != tif->tif_row) {
    fprintf(_coverage_fout, "8040\n");
    fflush(_coverage_fout);
    if (row < tif->tif_row) {
      fprintf(_coverage_fout, "8035\n");
      fflush(_coverage_fout);
      tif->tif_row = (strip % td->td_stripsperimage) * td->td_rowsperstrip;
      fprintf(_coverage_fout, "8036\n");
      fflush(_coverage_fout);
      tif->tif_rawcp = tif->tif_rawdata;
    } else {
      fprintf(_coverage_fout, "8037\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "8041\n");
    fflush(_coverage_fout);
    tmp___5 = (*(tif->tif_seek))(tif, row - tif->tif_row);
    fprintf(_coverage_fout, "8042\n");
    fflush(_coverage_fout);
    if (tmp___5) {
      fprintf(_coverage_fout, "8038\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8039\n");
      fflush(_coverage_fout);
      return (-1);
    }
    fprintf(_coverage_fout, "8043\n");
    fflush(_coverage_fout);
    tif->tif_row = row;
  } else {
    fprintf(_coverage_fout, "8044\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8054\n");
  fflush(_coverage_fout);
  (*(tif->tif_postdecode))(tif, (uint8 *)buf, tif->tif_scanlinesize);
  fprintf(_coverage_fout, "8055\n");
  fflush(_coverage_fout);
  status = (*(tif->tif_encoderow))(tif, (uint8 *)buf, tif->tif_scanlinesize,
                                   sample);
  fprintf(_coverage_fout, "8056\n");
  fflush(_coverage_fout);
  tif->tif_row = row + 1U;
  fprintf(_coverage_fout, "8057\n");
  fflush(_coverage_fout);
  return (status);
}
}
tmsize_t TIFFWriteEncodedStrip(TIFF *tif , uint32 strip , void *data ,
                               tmsize_t cc ) ;
static char const   module___0[22]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'E',      (char const   )'n',      (char const   )'c', 
        (char const   )'o',      (char const   )'d',      (char const   )'e',      (char const   )'d', 
        (char const   )'S',      (char const   )'t',      (char const   )'r',      (char const   )'i', 
        (char const   )'p',      (char const   )'\000'};
tmsize_t TIFFWriteEncodedStrip(TIFF *tif , uint32 strip , void *data ,
                               tmsize_t cc ) 
{ TIFFDirectory *td ;
  uint16 sample ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "8102\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "8103\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 64U) {
    fprintf(_coverage_fout, "8058\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "8061\n");
    fflush(_coverage_fout);
    tmp = TIFFWriteCheck(tif, 0, module___0);
    fprintf(_coverage_fout, "8062\n");
    fflush(_coverage_fout);
    if (tmp) {
      fprintf(_coverage_fout, "8059\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8060\n");
      fflush(_coverage_fout);
      return (-1L);
    }
  }
  fprintf(_coverage_fout, "8104\n");
  fflush(_coverage_fout);
  if (strip >= td->td_nstrips) {
    fprintf(_coverage_fout, "8068\n");
    fflush(_coverage_fout);
    if ((int )td->td_planarconfig == 2) {
      fprintf(_coverage_fout, "8063\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "Can not grow image by strips when using separate planes");
      fprintf(_coverage_fout, "8064\n");
      fflush(_coverage_fout);
      return (-1L);
    } else {
      fprintf(_coverage_fout, "8065\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "8069\n");
    fflush(_coverage_fout);
    tmp___0 = TIFFGrowStrips(tif, 1U, module___0);
    fprintf(_coverage_fout, "8070\n");
    fflush(_coverage_fout);
    if (tmp___0) {
      fprintf(_coverage_fout, "8066\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8067\n");
      fflush(_coverage_fout);
      return (-1L);
    }
    fprintf(_coverage_fout, "8071\n");
    fflush(_coverage_fout);
    td->td_stripsperimage = (td->td_imagelength + (td->td_rowsperstrip - 1U)) / td->td_rowsperstrip;
  } else {
    fprintf(_coverage_fout, "8072\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8105\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 16U) {
    fprintf(_coverage_fout, "8074\n");
    fflush(_coverage_fout);
    if (tif->tif_rawdata) {
      fprintf(_coverage_fout, "8073\n");
      fflush(_coverage_fout);

    } else {
      goto _L;
    }
  } else {
    fprintf(_coverage_fout, "8077\n");
    fflush(_coverage_fout);
    _L: /* CIL Label */ 
    tmp___1 = TIFFWriteBufferSetup(tif, (void *)0, -1L);
    fprintf(_coverage_fout, "8078\n");
    fflush(_coverage_fout);
    if (tmp___1) {
      fprintf(_coverage_fout, "8075\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8076\n");
      fflush(_coverage_fout);
      return (-1L);
    }
  }
  fprintf(_coverage_fout, "8106\n");
  fflush(_coverage_fout);
  tif->tif_curstrip = strip;
  fprintf(_coverage_fout, "8107\n");
  fflush(_coverage_fout);
  tif->tif_row = (strip % td->td_stripsperimage) * td->td_rowsperstrip;
  fprintf(_coverage_fout, "8108\n");
  fflush(_coverage_fout);
  if ((tif->tif_flags & 32U) == 0U) {
    fprintf(_coverage_fout, "8081\n");
    fflush(_coverage_fout);
    tmp___2 = (*(tif->tif_setupencode))(tif);
    fprintf(_coverage_fout, "8082\n");
    fflush(_coverage_fout);
    if (tmp___2) {
      fprintf(_coverage_fout, "8079\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8080\n");
      fflush(_coverage_fout);
      return (-1L);
    }
    fprintf(_coverage_fout, "8083\n");
    fflush(_coverage_fout);
    tif->tif_flags |= 32U;
  } else {
    fprintf(_coverage_fout, "8084\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8109\n");
  fflush(_coverage_fout);
  tif->tif_rawcc = 0L;
  fprintf(_coverage_fout, "8110\n");
  fflush(_coverage_fout);
  tif->tif_rawcp = tif->tif_rawdata;
  fprintf(_coverage_fout, "8111\n");
  fflush(_coverage_fout);
  if (*(td->td_stripbytecount + strip) > 0ULL) {
    fprintf(_coverage_fout, "8085\n");
    fflush(_coverage_fout);
    tif->tif_curoff = 0ULL;
  } else {
    fprintf(_coverage_fout, "8086\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8112\n");
  fflush(_coverage_fout);
  tif->tif_flags &= 4294963199U;
  fprintf(_coverage_fout, "8113\n");
  fflush(_coverage_fout);
  sample = (unsigned short )(strip / td->td_stripsperimage);
  fprintf(_coverage_fout, "8114\n");
  fflush(_coverage_fout);
  tmp___3 = (*(tif->tif_preencode))(tif, sample);
  fprintf(_coverage_fout, "8115\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "8087\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "8088\n");
    fflush(_coverage_fout);
    return (-1L);
  }
  fprintf(_coverage_fout, "8116\n");
  fflush(_coverage_fout);
  (*(tif->tif_postdecode))(tif, (uint8 *)data, cc);
  fprintf(_coverage_fout, "8117\n");
  fflush(_coverage_fout);
  tmp___4 = (*(tif->tif_encodestrip))(tif, (uint8 *)data, cc, sample);
  fprintf(_coverage_fout, "8118\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "8089\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "8090\n");
    fflush(_coverage_fout);
    return (0L);
  }
  fprintf(_coverage_fout, "8119\n");
  fflush(_coverage_fout);
  tmp___5 = (*(tif->tif_postencode))(tif);
  fprintf(_coverage_fout, "8120\n");
  fflush(_coverage_fout);
  if (tmp___5) {
    fprintf(_coverage_fout, "8091\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "8092\n");
    fflush(_coverage_fout);
    return (-1L);
  }
  fprintf(_coverage_fout, "8121\n");
  fflush(_coverage_fout);
  if (! ((tif->tif_flags & (unsigned int )td->td_fillorder) != 0U)) {
    fprintf(_coverage_fout, "8095\n");
    fflush(_coverage_fout);
    if ((tif->tif_flags & 256U) == 0U) {
      fprintf(_coverage_fout, "8093\n");
      fflush(_coverage_fout);
      TIFFReverseBits(tif->tif_rawdata, tif->tif_rawcc);
    } else {
      fprintf(_coverage_fout, "8094\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "8096\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8122\n");
  fflush(_coverage_fout);
  if (tif->tif_rawcc > 0L) {
    fprintf(_coverage_fout, "8099\n");
    fflush(_coverage_fout);
    tmp___6 = TIFFAppendToStrip(tif, strip, tif->tif_rawdata, tif->tif_rawcc);
    fprintf(_coverage_fout, "8100\n");
    fflush(_coverage_fout);
    if (tmp___6) {
      fprintf(_coverage_fout, "8097\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8098\n");
      fflush(_coverage_fout);
      return (-1L);
    }
  } else {
    fprintf(_coverage_fout, "8101\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8123\n");
  fflush(_coverage_fout);
  tif->tif_rawcc = 0L;
  fprintf(_coverage_fout, "8124\n");
  fflush(_coverage_fout);
  tif->tif_rawcp = tif->tif_rawdata;
  fprintf(_coverage_fout, "8125\n");
  fflush(_coverage_fout);
  return (cc);
}
}
tmsize_t TIFFWriteRawStrip(TIFF *tif , uint32 strip , void *data , tmsize_t cc ) ;
static char const   module___1[18]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'R',      (char const   )'a',      (char const   )'w', 
        (char const   )'S',      (char const   )'t',      (char const   )'r',      (char const   )'i', 
        (char const   )'p',      (char const   )'\000'};
tmsize_t TIFFWriteRawStrip(TIFF *tif , uint32 strip , void *data , tmsize_t cc ) 
{ TIFFDirectory *td ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  tmsize_t tmp___2 ;
  int tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "8145\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "8146\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 64U) {
    fprintf(_coverage_fout, "8126\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "8129\n");
    fflush(_coverage_fout);
    tmp = TIFFWriteCheck(tif, 0, module___1);
    fprintf(_coverage_fout, "8130\n");
    fflush(_coverage_fout);
    if (tmp) {
      fprintf(_coverage_fout, "8127\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8128\n");
      fflush(_coverage_fout);
      return (-1L);
    }
  }
  fprintf(_coverage_fout, "8147\n");
  fflush(_coverage_fout);
  if (strip >= td->td_nstrips) {
    fprintf(_coverage_fout, "8138\n");
    fflush(_coverage_fout);
    if ((int )td->td_planarconfig == 2) {
      fprintf(_coverage_fout, "8131\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___1,
                   "Can not grow image by strips when using separate planes");
      fprintf(_coverage_fout, "8132\n");
      fflush(_coverage_fout);
      return (-1L);
    } else {
      fprintf(_coverage_fout, "8133\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "8139\n");
    fflush(_coverage_fout);
    if (strip >= td->td_stripsperimage) {
      fprintf(_coverage_fout, "8134\n");
      fflush(_coverage_fout);
      td->td_stripsperimage = (td->td_imagelength + (td->td_rowsperstrip - 1U)) / td->td_rowsperstrip;
    } else {
      fprintf(_coverage_fout, "8135\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "8140\n");
    fflush(_coverage_fout);
    tmp___0 = TIFFGrowStrips(tif, 1U, module___1);
    fprintf(_coverage_fout, "8141\n");
    fflush(_coverage_fout);
    if (tmp___0) {
      fprintf(_coverage_fout, "8136\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8137\n");
      fflush(_coverage_fout);
      return (-1L);
    }
  } else {
    fprintf(_coverage_fout, "8142\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8148\n");
  fflush(_coverage_fout);
  tif->tif_curstrip = strip;
  fprintf(_coverage_fout, "8149\n");
  fflush(_coverage_fout);
  tif->tif_row = (strip % td->td_stripsperimage) * td->td_rowsperstrip;
  fprintf(_coverage_fout, "8150\n");
  fflush(_coverage_fout);
  tmp___3 = TIFFAppendToStrip(tif, strip, (uint8 *)data, cc);
  fprintf(_coverage_fout, "8151\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "8143\n");
    fflush(_coverage_fout);
    tmp___2 = cc;
  } else {
    fprintf(_coverage_fout, "8144\n");
    fflush(_coverage_fout);
    tmp___2 = -1L;
  }
  fprintf(_coverage_fout, "8152\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
tmsize_t TIFFWriteTile(TIFF *tif , void *buf , uint32 x , uint32 y , uint32 z ,
                       uint16 s ) 
{ int tmp ;
  uint32 tmp___0 ;
  tmsize_t tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "8155\n");
  fflush(_coverage_fout);
  tmp = TIFFCheckTile(tif, x, y, z, s);
  fprintf(_coverage_fout, "8156\n");
  fflush(_coverage_fout);
  if (tmp) {
    fprintf(_coverage_fout, "8153\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "8154\n");
    fflush(_coverage_fout);
    return (-1L);
  }
  fprintf(_coverage_fout, "8157\n");
  fflush(_coverage_fout);
  tmp___0 = TIFFComputeTile(tif, x, y, z, s);
  fprintf(_coverage_fout, "8158\n");
  fflush(_coverage_fout);
  tmp___1 = TIFFWriteEncodedTile(tif, tmp___0, buf, -1L);
  fprintf(_coverage_fout, "8159\n");
  fflush(_coverage_fout);
  return (tmp___1);
}
}
tmsize_t TIFFWriteEncodedTile(TIFF *tif , uint32 tile , void *data ,
                              tmsize_t cc ) ;
static char const   module___2[21]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'E',      (char const   )'n',      (char const   )'c', 
        (char const   )'o',      (char const   )'d',      (char const   )'e',      (char const   )'d', 
        (char const   )'T',      (char const   )'i',      (char const   )'l',      (char const   )'e', 
        (char const   )'\000'};
tmsize_t TIFFWriteEncodedTile(TIFF *tif , uint32 tile , void *data ,
                              tmsize_t cc ) 
{ TIFFDirectory *td ;
  uint16 sample ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "8201\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 64U) {
    fprintf(_coverage_fout, "8160\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "8163\n");
    fflush(_coverage_fout);
    tmp = TIFFWriteCheck(tif, 1, module___2);
    fprintf(_coverage_fout, "8164\n");
    fflush(_coverage_fout);
    if (tmp) {
      fprintf(_coverage_fout, "8161\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8162\n");
      fflush(_coverage_fout);
      return (-1L);
    }
  }
  fprintf(_coverage_fout, "8202\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "8203\n");
  fflush(_coverage_fout);
  if (tile >= td->td_nstrips) {
    fprintf(_coverage_fout, "8165\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___2,
                 "Tile %lu out of range, max %lu", (unsigned long )tile,
                 (unsigned long )td->td_nstrips);
    fprintf(_coverage_fout, "8166\n");
    fflush(_coverage_fout);
    return (-1L);
  } else {
    fprintf(_coverage_fout, "8167\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8204\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 16U) {
    fprintf(_coverage_fout, "8169\n");
    fflush(_coverage_fout);
    if (tif->tif_rawdata) {
      fprintf(_coverage_fout, "8168\n");
      fflush(_coverage_fout);

    } else {
      goto _L;
    }
  } else {
    fprintf(_coverage_fout, "8172\n");
    fflush(_coverage_fout);
    _L: /* CIL Label */ 
    tmp___0 = TIFFWriteBufferSetup(tif, (void *)0, -1L);
    fprintf(_coverage_fout, "8173\n");
    fflush(_coverage_fout);
    if (tmp___0) {
      fprintf(_coverage_fout, "8170\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8171\n");
      fflush(_coverage_fout);
      return (-1L);
    }
  }
  fprintf(_coverage_fout, "8205\n");
  fflush(_coverage_fout);
  tif->tif_curtile = tile;
  fprintf(_coverage_fout, "8206\n");
  fflush(_coverage_fout);
  tif->tif_rawcc = 0L;
  fprintf(_coverage_fout, "8207\n");
  fflush(_coverage_fout);
  tif->tif_rawcp = tif->tif_rawdata;
  fprintf(_coverage_fout, "8208\n");
  fflush(_coverage_fout);
  if (*(td->td_stripbytecount + tile) > 0ULL) {
    fprintf(_coverage_fout, "8174\n");
    fflush(_coverage_fout);
    tif->tif_curoff = 0ULL;
  } else {
    fprintf(_coverage_fout, "8175\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8209\n");
  fflush(_coverage_fout);
  tif->tif_row = (tile % ((td->td_imagelength + (td->td_tilelength - 1U)) / td->td_tilelength)) * td->td_tilelength;
  fprintf(_coverage_fout, "8210\n");
  fflush(_coverage_fout);
  tif->tif_col = (tile % ((td->td_imagewidth + (td->td_tilewidth - 1U)) / td->td_tilewidth)) * td->td_tilewidth;
  fprintf(_coverage_fout, "8211\n");
  fflush(_coverage_fout);
  if ((tif->tif_flags & 32U) == 0U) {
    fprintf(_coverage_fout, "8178\n");
    fflush(_coverage_fout);
    tmp___1 = (*(tif->tif_setupencode))(tif);
    fprintf(_coverage_fout, "8179\n");
    fflush(_coverage_fout);
    if (tmp___1) {
      fprintf(_coverage_fout, "8176\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8177\n");
      fflush(_coverage_fout);
      return (-1L);
    }
    fprintf(_coverage_fout, "8180\n");
    fflush(_coverage_fout);
    tif->tif_flags |= 32U;
  } else {
    fprintf(_coverage_fout, "8181\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8212\n");
  fflush(_coverage_fout);
  tif->tif_flags &= 4294963199U;
  fprintf(_coverage_fout, "8213\n");
  fflush(_coverage_fout);
  sample = (unsigned short )(tile / td->td_stripsperimage);
  fprintf(_coverage_fout, "8214\n");
  fflush(_coverage_fout);
  tmp___2 = (*(tif->tif_preencode))(tif, sample);
  fprintf(_coverage_fout, "8215\n");
  fflush(_coverage_fout);
  if (tmp___2) {
    fprintf(_coverage_fout, "8182\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "8183\n");
    fflush(_coverage_fout);
    return (-1L);
  }
  fprintf(_coverage_fout, "8216\n");
  fflush(_coverage_fout);
  if (cc < 1L) {
    fprintf(_coverage_fout, "8184\n");
    fflush(_coverage_fout);
    cc = tif->tif_tilesize;
  } else {
    fprintf(_coverage_fout, "8187\n");
    fflush(_coverage_fout);
    if (cc > tif->tif_tilesize) {
      fprintf(_coverage_fout, "8185\n");
      fflush(_coverage_fout);
      cc = tif->tif_tilesize;
    } else {
      fprintf(_coverage_fout, "8186\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "8217\n");
  fflush(_coverage_fout);
  (*(tif->tif_postdecode))(tif, (uint8 *)data, cc);
  fprintf(_coverage_fout, "8218\n");
  fflush(_coverage_fout);
  tmp___3 = (*(tif->tif_encodetile))(tif, (uint8 *)data, cc, sample);
  fprintf(_coverage_fout, "8219\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "8188\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "8189\n");
    fflush(_coverage_fout);
    return (0L);
  }
  fprintf(_coverage_fout, "8220\n");
  fflush(_coverage_fout);
  tmp___4 = (*(tif->tif_postencode))(tif);
  fprintf(_coverage_fout, "8221\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "8190\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "8191\n");
    fflush(_coverage_fout);
    return (-1L);
  }
  fprintf(_coverage_fout, "8222\n");
  fflush(_coverage_fout);
  if (! ((tif->tif_flags & (unsigned int )td->td_fillorder) != 0U)) {
    fprintf(_coverage_fout, "8194\n");
    fflush(_coverage_fout);
    if ((tif->tif_flags & 256U) == 0U) {
      fprintf(_coverage_fout, "8192\n");
      fflush(_coverage_fout);
      TIFFReverseBits(tif->tif_rawdata, tif->tif_rawcc);
    } else {
      fprintf(_coverage_fout, "8193\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "8195\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8223\n");
  fflush(_coverage_fout);
  if (tif->tif_rawcc > 0L) {
    fprintf(_coverage_fout, "8198\n");
    fflush(_coverage_fout);
    tmp___5 = TIFFAppendToStrip(tif, tile, tif->tif_rawdata, tif->tif_rawcc);
    fprintf(_coverage_fout, "8199\n");
    fflush(_coverage_fout);
    if (tmp___5) {
      fprintf(_coverage_fout, "8196\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8197\n");
      fflush(_coverage_fout);
      return (-1L);
    }
  } else {
    fprintf(_coverage_fout, "8200\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8224\n");
  fflush(_coverage_fout);
  tif->tif_rawcc = 0L;
  fprintf(_coverage_fout, "8225\n");
  fflush(_coverage_fout);
  tif->tif_rawcp = tif->tif_rawdata;
  fprintf(_coverage_fout, "8226\n");
  fflush(_coverage_fout);
  return (cc);
}
}
tmsize_t TIFFWriteRawTile(TIFF *tif , uint32 tile , void *data , tmsize_t cc ) ;
static char const   module___3[17]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'R',      (char const   )'a',      (char const   )'w', 
        (char const   )'T',      (char const   )'i',      (char const   )'l',      (char const   )'e', 
        (char const   )'\000'};
tmsize_t TIFFWriteRawTile(TIFF *tif , uint32 tile , void *data , tmsize_t cc ) 
{ int tmp ;
  int tmp___0 ;
  tmsize_t tmp___1 ;
  int tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "8237\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 64U) {
    fprintf(_coverage_fout, "8227\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "8230\n");
    fflush(_coverage_fout);
    tmp = TIFFWriteCheck(tif, 1, module___3);
    fprintf(_coverage_fout, "8231\n");
    fflush(_coverage_fout);
    if (tmp) {
      fprintf(_coverage_fout, "8228\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8229\n");
      fflush(_coverage_fout);
      return (-1L);
    }
  }
  fprintf(_coverage_fout, "8238\n");
  fflush(_coverage_fout);
  if (tile >= tif->tif_dir.td_nstrips) {
    fprintf(_coverage_fout, "8232\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___3,
                 "Tile %lu out of range, max %lu", (unsigned long )tile,
                 (unsigned long )tif->tif_dir.td_nstrips);
    fprintf(_coverage_fout, "8233\n");
    fflush(_coverage_fout);
    return (-1L);
  } else {
    fprintf(_coverage_fout, "8234\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8239\n");
  fflush(_coverage_fout);
  tmp___2 = TIFFAppendToStrip(tif, tile, (uint8 *)data, cc);
  fprintf(_coverage_fout, "8240\n");
  fflush(_coverage_fout);
  if (tmp___2) {
    fprintf(_coverage_fout, "8235\n");
    fflush(_coverage_fout);
    tmp___1 = cc;
  } else {
    fprintf(_coverage_fout, "8236\n");
    fflush(_coverage_fout);
    tmp___1 = -1L;
  }
  fprintf(_coverage_fout, "8241\n");
  fflush(_coverage_fout);
  return (tmp___1);
}
}
int TIFFSetupStrips(TIFF *tif ) 
{ TIFFDirectory *td ;
  uint32 tmp ;
  uint32 tmp___0 ;
  void *tmp___1 ;
  void *tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "8262\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "8263\n");
  fflush(_coverage_fout);
  if ((tif->tif_flags & 1024U) != 0U) {
    fprintf(_coverage_fout, "8248\n");
    fflush(_coverage_fout);
    if (tif->tif_dir.td_fieldsset[0] & (1UL << 2)) {
      fprintf(_coverage_fout, "8245\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_imagelength == 0U) {
        fprintf(_coverage_fout, "8242\n");
        fflush(_coverage_fout);
        td->td_stripsperimage = (unsigned int )td->td_samplesperpixel;
      } else {
        fprintf(_coverage_fout, "8243\n");
        fflush(_coverage_fout);
        tmp = TIFFNumberOfTiles(tif);
        fprintf(_coverage_fout, "8244\n");
        fflush(_coverage_fout);
        td->td_stripsperimage = tmp;
      }
    } else {
      fprintf(_coverage_fout, "8246\n");
      fflush(_coverage_fout);
      tmp = TIFFNumberOfTiles(tif);
      fprintf(_coverage_fout, "8247\n");
      fflush(_coverage_fout);
      td->td_stripsperimage = tmp;
    }
  } else {
    fprintf(_coverage_fout, "8255\n");
    fflush(_coverage_fout);
    if (tif->tif_dir.td_fieldsset[0] & (1UL << 17)) {
      fprintf(_coverage_fout, "8252\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_imagelength == 0U) {
        fprintf(_coverage_fout, "8249\n");
        fflush(_coverage_fout);
        td->td_stripsperimage = (unsigned int )td->td_samplesperpixel;
      } else {
        fprintf(_coverage_fout, "8250\n");
        fflush(_coverage_fout);
        tmp___0 = TIFFNumberOfStrips(tif);
        fprintf(_coverage_fout, "8251\n");
        fflush(_coverage_fout);
        td->td_stripsperimage = tmp___0;
      }
    } else {
      fprintf(_coverage_fout, "8253\n");
      fflush(_coverage_fout);
      tmp___0 = TIFFNumberOfStrips(tif);
      fprintf(_coverage_fout, "8254\n");
      fflush(_coverage_fout);
      td->td_stripsperimage = tmp___0;
    }
  }
  fprintf(_coverage_fout, "8264\n");
  fflush(_coverage_fout);
  td->td_nstrips = td->td_stripsperimage;
  fprintf(_coverage_fout, "8265\n");
  fflush(_coverage_fout);
  if ((int )td->td_planarconfig == 2) {
    fprintf(_coverage_fout, "8256\n");
    fflush(_coverage_fout);
    td->td_stripsperimage /= (uint32 )td->td_samplesperpixel;
  } else {
    fprintf(_coverage_fout, "8257\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8266\n");
  fflush(_coverage_fout);
  tmp___1 = _TIFFmalloc((long )(td->td_nstrips * sizeof(uint64 )));
  fprintf(_coverage_fout, "8267\n");
  fflush(_coverage_fout);
  td->td_stripoffset = (uint64 *)tmp___1;
  fprintf(_coverage_fout, "8268\n");
  fflush(_coverage_fout);
  tmp___2 = _TIFFmalloc((long )(td->td_nstrips * sizeof(uint64 )));
  fprintf(_coverage_fout, "8269\n");
  fflush(_coverage_fout);
  td->td_stripbytecount = (uint64 *)tmp___2;
  fprintf(_coverage_fout, "8270\n");
  fflush(_coverage_fout);
  if ((unsigned int )td->td_stripoffset == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "8258\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "8261\n");
    fflush(_coverage_fout);
    if ((unsigned int )td->td_stripbytecount == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "8259\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "8260\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "8271\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)td->td_stripoffset, 0,
              (long )(td->td_nstrips * sizeof(uint64 )));
  fprintf(_coverage_fout, "8272\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)td->td_stripbytecount, 0,
              (long )(td->td_nstrips * sizeof(uint64 )));
  fprintf(_coverage_fout, "8273\n");
  fflush(_coverage_fout);
  tif->tif_dir.td_fieldsset[0] |= 1UL << 25;
  fprintf(_coverage_fout, "8274\n");
  fflush(_coverage_fout);
  tif->tif_dir.td_fieldsset[0] |= 1UL << 24;
  fprintf(_coverage_fout, "8275\n");
  fflush(_coverage_fout);
  return (1);
}
}
int TIFFWriteCheck(TIFF *tif , int tiles , char const   *module___4 ) 
{ char const   *tmp ;
  char const   *tmp___0 ;
  int tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "8310\n");
  fflush(_coverage_fout);
  if (tif->tif_mode == 00) {
    fprintf(_coverage_fout, "8276\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___4, "File not open for writing");
    fprintf(_coverage_fout, "8277\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "8278\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8311\n");
  fflush(_coverage_fout);
  if (tiles ^ ((tif->tif_flags & 1024U) != 0U)) {
    fprintf(_coverage_fout, "8281\n");
    fflush(_coverage_fout);
    if (tiles) {
      fprintf(_coverage_fout, "8279\n");
      fflush(_coverage_fout);
      tmp = "Can not write tiles to a stripped image";
    } else {
      fprintf(_coverage_fout, "8280\n");
      fflush(_coverage_fout);
      tmp = "Can not write scanlines to a tiled image";
    }
    fprintf(_coverage_fout, "8282\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___4, tmp);
    fprintf(_coverage_fout, "8283\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "8284\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8312\n");
  fflush(_coverage_fout);
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 1))) {
    fprintf(_coverage_fout, "8285\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___4,
                 "Must set \"ImageWidth\" before writing data");
    fprintf(_coverage_fout, "8286\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "8287\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8313\n");
  fflush(_coverage_fout);
  if ((int )tif->tif_dir.td_samplesperpixel == 1) {
    fprintf(_coverage_fout, "8288\n");
    fflush(_coverage_fout);
    tif->tif_dir.td_planarconfig = (unsigned short)1;
  } else {
    fprintf(_coverage_fout, "8292\n");
    fflush(_coverage_fout);
    if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 20))) {
      fprintf(_coverage_fout, "8289\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___4,
                   "Must set \"PlanarConfiguration\" before writing data");
      fprintf(_coverage_fout, "8290\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "8291\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "8314\n");
  fflush(_coverage_fout);
  if ((unsigned int )tif->tif_dir.td_stripoffset == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "8300\n");
    fflush(_coverage_fout);
    tmp___1 = TIFFSetupStrips(tif);
    fprintf(_coverage_fout, "8301\n");
    fflush(_coverage_fout);
    if (tmp___1) {
      fprintf(_coverage_fout, "8293\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8296\n");
      fflush(_coverage_fout);
      tif->tif_dir.td_nstrips = 0U;
      fprintf(_coverage_fout, "8297\n");
      fflush(_coverage_fout);
      if ((tif->tif_flags & 1024U) != 0U) {
        fprintf(_coverage_fout, "8294\n");
        fflush(_coverage_fout);
        tmp___0 = "tile";
      } else {
        fprintf(_coverage_fout, "8295\n");
        fflush(_coverage_fout);
        tmp___0 = "strip";
      }
      fprintf(_coverage_fout, "8298\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___4, "No space for %s arrays",
                   tmp___0);
      fprintf(_coverage_fout, "8299\n");
      fflush(_coverage_fout);
      return (0);
    }
  } else {
    fprintf(_coverage_fout, "8302\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8315\n");
  fflush(_coverage_fout);
  if ((tif->tif_flags & 1024U) != 0U) {
    fprintf(_coverage_fout, "8305\n");
    fflush(_coverage_fout);
    tif->tif_tilesize = TIFFTileSize(tif);
    fprintf(_coverage_fout, "8306\n");
    fflush(_coverage_fout);
    if (tif->tif_tilesize == 0L) {
      fprintf(_coverage_fout, "8303\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "8304\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "8307\n");
    fflush(_coverage_fout);
    tif->tif_tilesize = -1L;
  }
  fprintf(_coverage_fout, "8316\n");
  fflush(_coverage_fout);
  tif->tif_scanlinesize = TIFFScanlineSize(tif);
  fprintf(_coverage_fout, "8317\n");
  fflush(_coverage_fout);
  if (tif->tif_scanlinesize == 0L) {
    fprintf(_coverage_fout, "8308\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "8309\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8318\n");
  fflush(_coverage_fout);
  tif->tif_flags |= 64U;
  fprintf(_coverage_fout, "8319\n");
  fflush(_coverage_fout);
  return (1);
}
}
int TIFFWriteBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
static char const   module___4[21]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'B',      (char const   )'u',      (char const   )'f', 
        (char const   )'f',      (char const   )'e',      (char const   )'r',      (char const   )'S', 
        (char const   )'e',      (char const   )'t',      (char const   )'u',      (char const   )'p', 
        (char const   )'\000'};
int TIFFWriteBufferSetup(TIFF *tif , void *bp , tmsize_t size ) 
{ tmsize_t tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "8342\n");
  fflush(_coverage_fout);
  if (tif->tif_rawdata) {
    fprintf(_coverage_fout, "8323\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 512U) {
      fprintf(_coverage_fout, "8320\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)tif->tif_rawdata);
      fprintf(_coverage_fout, "8321\n");
      fflush(_coverage_fout);
      tif->tif_flags &= 4294966783U;
    } else {
      fprintf(_coverage_fout, "8322\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "8324\n");
    fflush(_coverage_fout);
    tif->tif_rawdata = (uint8 *)((void *)0);
  } else {
    fprintf(_coverage_fout, "8325\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8343\n");
  fflush(_coverage_fout);
  if (size == -1L) {
    fprintf(_coverage_fout, "8331\n");
    fflush(_coverage_fout);
    if ((tif->tif_flags & 1024U) != 0U) {
      fprintf(_coverage_fout, "8326\n");
      fflush(_coverage_fout);
      size = tif->tif_tilesize;
    } else {
      fprintf(_coverage_fout, "8327\n");
      fflush(_coverage_fout);
      tmp = TIFFStripSize(tif);
      fprintf(_coverage_fout, "8328\n");
      fflush(_coverage_fout);
      size = tmp;
    }
    fprintf(_coverage_fout, "8332\n");
    fflush(_coverage_fout);
    if (size < 8192L) {
      fprintf(_coverage_fout, "8329\n");
      fflush(_coverage_fout);
      size = 8192L;
    } else {
      fprintf(_coverage_fout, "8330\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "8333\n");
    fflush(_coverage_fout);
    bp = (void *)0;
  } else {
    fprintf(_coverage_fout, "8334\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8344\n");
  fflush(_coverage_fout);
  if ((unsigned int )bp == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "8338\n");
    fflush(_coverage_fout);
    bp = _TIFFmalloc(size);
    fprintf(_coverage_fout, "8339\n");
    fflush(_coverage_fout);
    if ((unsigned int )bp == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "8335\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___4, "No space for output buffer");
      fprintf(_coverage_fout, "8336\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "8337\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "8340\n");
    fflush(_coverage_fout);
    tif->tif_flags |= 512U;
  } else {
    fprintf(_coverage_fout, "8341\n");
    fflush(_coverage_fout);
    tif->tif_flags &= 4294966783U;
  }
  fprintf(_coverage_fout, "8345\n");
  fflush(_coverage_fout);
  tif->tif_rawdata = (uint8 *)bp;
  fprintf(_coverage_fout, "8346\n");
  fflush(_coverage_fout);
  tif->tif_rawdatasize = size;
  fprintf(_coverage_fout, "8347\n");
  fflush(_coverage_fout);
  tif->tif_rawcc = 0L;
  fprintf(_coverage_fout, "8348\n");
  fflush(_coverage_fout);
  tif->tif_rawcp = tif->tif_rawdata;
  fprintf(_coverage_fout, "8349\n");
  fflush(_coverage_fout);
  tif->tif_flags |= 16U;
  fprintf(_coverage_fout, "8350\n");
  fflush(_coverage_fout);
  return (1);
}
}
static int TIFFGrowStrips(TIFF *tif , uint32 delta , char const   *module___5 ) 
{ TIFFDirectory *td ;
  uint64 *new_stripoffset ;
  uint64 *new_stripbytecount ;
  void *tmp ;
  void *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "8364\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "8365\n");
  fflush(_coverage_fout);
  if ((int )td->td_planarconfig == 1) {
    fprintf(_coverage_fout, "8351\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "8352\n");
    fflush(_coverage_fout);
    __assert_fail("td->td_planarconfig == 1", "tif_write.c", 598U,
                  "TIFFGrowStrips");
  }
  fprintf(_coverage_fout, "8366\n");
  fflush(_coverage_fout);
  tmp = _TIFFrealloc((void *)td->td_stripoffset,
                     (long )((td->td_nstrips + delta) * sizeof(uint64 )));
  fprintf(_coverage_fout, "8367\n");
  fflush(_coverage_fout);
  new_stripoffset = (uint64 *)tmp;
  fprintf(_coverage_fout, "8368\n");
  fflush(_coverage_fout);
  tmp___0 = _TIFFrealloc((void *)td->td_stripbytecount,
                         (long )((td->td_nstrips + delta) * sizeof(uint64 )));
  fprintf(_coverage_fout, "8369\n");
  fflush(_coverage_fout);
  new_stripbytecount = (uint64 *)tmp___0;
  fprintf(_coverage_fout, "8370\n");
  fflush(_coverage_fout);
  if ((unsigned int )new_stripoffset == (unsigned int )((void *)0)) {
    goto _L;
  } else {
    fprintf(_coverage_fout, "8363\n");
    fflush(_coverage_fout);
    if ((unsigned int )new_stripbytecount == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "8357\n");
      fflush(_coverage_fout);
      _L: /* CIL Label */ 
      if (new_stripoffset) {
        fprintf(_coverage_fout, "8353\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)new_stripoffset);
      } else {
        fprintf(_coverage_fout, "8354\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "8358\n");
      fflush(_coverage_fout);
      if (new_stripbytecount) {
        fprintf(_coverage_fout, "8355\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)new_stripbytecount);
      } else {
        fprintf(_coverage_fout, "8356\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "8359\n");
      fflush(_coverage_fout);
      td->td_nstrips = 0U;
      fprintf(_coverage_fout, "8360\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___5,
                   "No space to expand strip arrays");
      fprintf(_coverage_fout, "8361\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "8362\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "8371\n");
  fflush(_coverage_fout);
  td->td_stripoffset = new_stripoffset;
  fprintf(_coverage_fout, "8372\n");
  fflush(_coverage_fout);
  td->td_stripbytecount = new_stripbytecount;
  fprintf(_coverage_fout, "8373\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)(td->td_stripoffset + td->td_nstrips), 0,
              (long )(delta * sizeof(uint64 )));
  fprintf(_coverage_fout, "8374\n");
  fflush(_coverage_fout);
  _TIFFmemset((void *)(td->td_stripbytecount + td->td_nstrips), 0,
              (long )(delta * sizeof(uint64 )));
  fprintf(_coverage_fout, "8375\n");
  fflush(_coverage_fout);
  td->td_nstrips += delta;
  fprintf(_coverage_fout, "8376\n");
  fflush(_coverage_fout);
  return (1);
}
}
static int TIFFAppendToStrip(TIFF *tif , uint32 strip , uint8 *data ,
                             tmsize_t cc ) ;
static char const   module___5[18]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'A',      (char const   )'p',      (char const   )'p',      (char const   )'e', 
        (char const   )'n',      (char const   )'d',      (char const   )'T',      (char const   )'o', 
        (char const   )'S',      (char const   )'t',      (char const   )'r',      (char const   )'i', 
        (char const   )'p',      (char const   )'\000'};
static int TIFFAppendToStrip(TIFF *tif , uint32 strip , uint8 *data ,
                             tmsize_t cc ) 
{ TIFFDirectory *td ;
  uint64 m ;
  uint64 tmp ;
  tmsize_t tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "8406\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "8407\n");
  fflush(_coverage_fout);
  if (*(td->td_stripoffset + strip) == 0ULL) {
    goto _L;
  } else {
    fprintf(_coverage_fout, "8394\n");
    fflush(_coverage_fout);
    if (tif->tif_curoff == 0ULL) {
      fprintf(_coverage_fout, "8389\n");
      fflush(_coverage_fout);
      _L: /* CIL Label */ 
      if (td->td_nstrips > 0U) {
        fprintf(_coverage_fout, "8377\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "8378\n");
        fflush(_coverage_fout);
        __assert_fail("td->td_nstrips > 0", "tif_write.c", 633U,
                      "TIFFAppendToStrip");
      }
      fprintf(_coverage_fout, "8390\n");
      fflush(_coverage_fout);
      if (*(td->td_stripbytecount + strip) != 0ULL) {
        fprintf(_coverage_fout, "8387\n");
        fflush(_coverage_fout);
        if (*(td->td_stripoffset + strip) != 0ULL) {
          fprintf(_coverage_fout, "8385\n");
          fflush(_coverage_fout);
          if (*(td->td_stripbytecount + strip) >= (unsigned long long )cc) {
            fprintf(_coverage_fout, "8382\n");
            fflush(_coverage_fout);
            tmp = (*(tif->tif_seekproc))(tif->tif_clientdata,
                                         *(td->td_stripoffset + strip), 0);
            fprintf(_coverage_fout, "8383\n");
            fflush(_coverage_fout);
            if (tmp == *(td->td_stripoffset + strip)) {
              fprintf(_coverage_fout, "8379\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "8380\n");
              fflush(_coverage_fout);
              TIFFErrorExt(tif->tif_clientdata, module___5,
                           "Seek error at scanline %lu",
                           (unsigned long )tif->tif_row);
              fprintf(_coverage_fout, "8381\n");
              fflush(_coverage_fout);
              return (0);
            }
          } else {
            fprintf(_coverage_fout, "8384\n");
            fflush(_coverage_fout);
            *(td->td_stripoffset + strip) = (*(tif->tif_seekproc))(tif->tif_clientdata,
                                                                   0ULL, 2);
          }
        } else {
          fprintf(_coverage_fout, "8386\n");
          fflush(_coverage_fout);
          *(td->td_stripoffset + strip) = (*(tif->tif_seekproc))(tif->tif_clientdata,
                                                                 0ULL, 2);
        }
      } else {
        fprintf(_coverage_fout, "8388\n");
        fflush(_coverage_fout);
        *(td->td_stripoffset + strip) = (*(tif->tif_seekproc))(tif->tif_clientdata,
                                                               0ULL, 2);
      }
      fprintf(_coverage_fout, "8391\n");
      fflush(_coverage_fout);
      tif->tif_curoff = *(td->td_stripoffset + strip);
      fprintf(_coverage_fout, "8392\n");
      fflush(_coverage_fout);
      *(td->td_stripbytecount + strip) = 0ULL;
    } else {
      fprintf(_coverage_fout, "8393\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "8408\n");
  fflush(_coverage_fout);
  m = tif->tif_curoff + (uint64 )cc;
  fprintf(_coverage_fout, "8409\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "8395\n");
    fflush(_coverage_fout);
    m = (unsigned long long )((unsigned int )m);
  } else {
    fprintf(_coverage_fout, "8396\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8410\n");
  fflush(_coverage_fout);
  if (m < tif->tif_curoff) {
    fprintf(_coverage_fout, "8397\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___5,
                 "Maximum TIFF file size exceeded");
    fprintf(_coverage_fout, "8398\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "8402\n");
    fflush(_coverage_fout);
    if (m < (unsigned long long )cc) {
      fprintf(_coverage_fout, "8399\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___5,
                   "Maximum TIFF file size exceeded");
      fprintf(_coverage_fout, "8400\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "8401\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "8411\n");
  fflush(_coverage_fout);
  tmp___0 = (*(tif->tif_writeproc))(tif->tif_clientdata, (void *)data, cc);
  fprintf(_coverage_fout, "8412\n");
  fflush(_coverage_fout);
  if (tmp___0 == cc) {
    fprintf(_coverage_fout, "8403\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "8404\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___5, "Write error at scanline %lu",
                 (unsigned long )tif->tif_row);
    fprintf(_coverage_fout, "8405\n");
    fflush(_coverage_fout);
    return (0);
  }
  fprintf(_coverage_fout, "8413\n");
  fflush(_coverage_fout);
  tif->tif_curoff = m;
  fprintf(_coverage_fout, "8414\n");
  fflush(_coverage_fout);
  *(td->td_stripbytecount + strip) += (uint64 )cc;
  fprintf(_coverage_fout, "8415\n");
  fflush(_coverage_fout);
  return (1);
}
}
int TIFFFlushData1(TIFF *tif ) 
{ uint32 tmp ;
  int tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "8431\n");
  fflush(_coverage_fout);
  if (tif->tif_rawcc > 0L) {
    fprintf(_coverage_fout, "8424\n");
    fflush(_coverage_fout);
    if (! ((tif->tif_flags & (unsigned int )tif->tif_dir.td_fillorder) != 0U)) {
      fprintf(_coverage_fout, "8418\n");
      fflush(_coverage_fout);
      if ((tif->tif_flags & 256U) == 0U) {
        fprintf(_coverage_fout, "8416\n");
        fflush(_coverage_fout);
        TIFFReverseBits(tif->tif_rawdata, tif->tif_rawcc);
      } else {
        fprintf(_coverage_fout, "8417\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "8419\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "8425\n");
    fflush(_coverage_fout);
    if ((tif->tif_flags & 1024U) != 0U) {
      fprintf(_coverage_fout, "8420\n");
      fflush(_coverage_fout);
      tmp = tif->tif_curtile;
    } else {
      fprintf(_coverage_fout, "8421\n");
      fflush(_coverage_fout);
      tmp = tif->tif_curstrip;
    }
    fprintf(_coverage_fout, "8426\n");
    fflush(_coverage_fout);
    tmp___0 = TIFFAppendToStrip(tif, tmp, tif->tif_rawdata, tif->tif_rawcc);
    fprintf(_coverage_fout, "8427\n");
    fflush(_coverage_fout);
    if (tmp___0) {
      fprintf(_coverage_fout, "8422\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "8423\n");
      fflush(_coverage_fout);
      return (0);
    }
    fprintf(_coverage_fout, "8428\n");
    fflush(_coverage_fout);
    tif->tif_rawcc = 0L;
    fprintf(_coverage_fout, "8429\n");
    fflush(_coverage_fout);
    tif->tif_rawcp = tif->tif_rawdata;
  } else {
    fprintf(_coverage_fout, "8430\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "8432\n");
  fflush(_coverage_fout);
  return (1);
}
}
void TIFFSetWriteOffset(TIFF *tif , uint64 off ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "8433\n");
  fflush(_coverage_fout);
  tif->tif_curoff = off;
  fprintf(_coverage_fout, "8434\n");
  fflush(_coverage_fout);
  return;
}
}
