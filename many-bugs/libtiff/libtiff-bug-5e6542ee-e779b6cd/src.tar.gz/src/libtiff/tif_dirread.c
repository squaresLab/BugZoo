extern void *_coverage_fout ;
typedef unsigned char __u_char;
typedef unsigned short __u_short;
typedef unsigned int __u_int;
typedef unsigned long __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;
typedef long long __quad_t;
typedef unsigned long long __u_quad_t;
typedef __u_quad_t __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef __u_quad_t __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long __off_t;
typedef __quad_t __off64_t;
typedef int __pid_t;
struct __anonstruct___fsid_t_1 {
   int __val[2] ;
};
typedef struct __anonstruct___fsid_t_1 __fsid_t;
typedef long __clock_t;
typedef unsigned long __rlim_t;
typedef __u_quad_t __rlim64_t;
typedef unsigned int __id_t;
typedef long __time_t;
typedef unsigned int __useconds_t;
typedef long __suseconds_t;
typedef int __daddr_t;
typedef long __swblk_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void *__timer_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef __quad_t __blkcnt64_t;
typedef unsigned long __fsblkcnt_t;
typedef __u_quad_t __fsblkcnt64_t;
typedef unsigned long __fsfilcnt_t;
typedef __u_quad_t __fsfilcnt64_t;
typedef int __ssize_t;
typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;
typedef int __intptr_t;
typedef unsigned int __socklen_t;
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;
typedef __loff_t loff_t;
typedef __ino64_t ino_t;
typedef __dev_t dev_t;
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __nlink_t nlink_t;
typedef __uid_t uid_t;
typedef __off64_t off_t;
typedef __pid_t pid_t;
typedef __id_t id_t;
typedef __ssize_t ssize_t;
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;
typedef __key_t key_t;
typedef __clock_t clock_t;
typedef __time_t time_t;
typedef __clockid_t clockid_t;
typedef __timer_t timer_t;
typedef unsigned int size_t;
typedef unsigned long ulong;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char u_int8_t;
typedef unsigned short u_int16_t;
typedef unsigned int u_int32_t;
typedef unsigned long long u_int64_t;
typedef int register_t;
typedef int __sig_atomic_t;
struct __anonstruct___sigset_t_2 {
   unsigned long __val[1024U / (8U * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_2 __sigset_t;
typedef __sigset_t sigset_t;
struct timespec {
   __time_t tv_sec ;
   long tv_nsec ;
};
struct timeval {
   __time_t tv_sec ;
   __suseconds_t tv_usec ;
};
typedef __suseconds_t suseconds_t;
typedef long __fd_mask;
struct __anonstruct_fd_set_3 {
   __fd_mask __fds_bits[1024 / (8 * (int )sizeof(__fd_mask ))] ;
};
typedef struct __anonstruct_fd_set_3 fd_set;
typedef __fd_mask fd_mask;
typedef __blksize_t blksize_t;
typedef __blkcnt64_t blkcnt_t;
typedef __fsblkcnt64_t fsblkcnt_t;
typedef __fsfilcnt64_t fsfilcnt_t;
typedef unsigned long pthread_t;
union __anonunion_pthread_attr_t_4 {
   char __size[36] ;
   long __align ;
};
typedef union __anonunion_pthread_attr_t_4 pthread_attr_t;
struct __pthread_internal_slist {
   struct __pthread_internal_slist *__next ;
};
typedef struct __pthread_internal_slist __pthread_slist_t;
union __anonunion____missing_field_name_6 {
   int __spins ;
   __pthread_slist_t __list ;
};
struct __pthread_mutex_s {
   int __lock ;
   unsigned int __count ;
   int __owner ;
   int __kind ;
   unsigned int __nusers ;
   union __anonunion____missing_field_name_6 __annonCompField1 ;
};
union __anonunion_pthread_mutex_t_5 {
   struct __pthread_mutex_s __data ;
   char __size[24] ;
   long __align ;
};
typedef union __anonunion_pthread_mutex_t_5 pthread_mutex_t;
union __anonunion_pthread_mutexattr_t_7 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_mutexattr_t_7 pthread_mutexattr_t;
struct __anonstruct___data_9 {
   int __lock ;
   unsigned int __futex ;
   unsigned long long __total_seq ;
   unsigned long long __wakeup_seq ;
   unsigned long long __woken_seq ;
   void *__mutex ;
   unsigned int __nwaiters ;
   unsigned int __broadcast_seq ;
};
union __anonunion_pthread_cond_t_8 {
   struct __anonstruct___data_9 __data ;
   char __size[48] ;
   long long __align ;
};
typedef union __anonunion_pthread_cond_t_8 pthread_cond_t;
union __anonunion_pthread_condattr_t_10 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_condattr_t_10 pthread_condattr_t;
typedef unsigned int pthread_key_t;
typedef int pthread_once_t;
struct __anonstruct___data_12 {
   int __lock ;
   unsigned int __nr_readers ;
   unsigned int __readers_wakeup ;
   unsigned int __writer_wakeup ;
   unsigned int __nr_readers_queued ;
   unsigned int __nr_writers_queued ;
   unsigned char __flags ;
   unsigned char __shared ;
   unsigned char __pad1 ;
   unsigned char __pad2 ;
   int __writer ;
};
union __anonunion_pthread_rwlock_t_11 {
   struct __anonstruct___data_12 __data ;
   char __size[32] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlock_t_11 pthread_rwlock_t;
union __anonunion_pthread_rwlockattr_t_13 {
   char __size[8] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlockattr_t_13 pthread_rwlockattr_t;
typedef int volatile   pthread_spinlock_t;
union __anonunion_pthread_barrier_t_14 {
   char __size[20] ;
   long __align ;
};
typedef union __anonunion_pthread_barrier_t_14 pthread_barrier_t;
union __anonunion_pthread_barrierattr_t_15 {
   char __size[4] ;
   int __align ;
};
typedef union __anonunion_pthread_barrierattr_t_15 pthread_barrierattr_t;
struct flock {
   short l_type ;
   short l_whence ;
   __off64_t l_start ;
   __off64_t l_len ;
   __pid_t l_pid ;
};
struct stat {
   __dev_t st_dev ;
   unsigned short __pad1 ;
   __ino_t __st_ino ;
   __mode_t st_mode ;
   __nlink_t st_nlink ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   __dev_t st_rdev ;
   unsigned short __pad2 ;
   __off64_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt64_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __ino64_t st_ino ;
};
struct __locale_data;
struct __locale_struct {
   struct __locale_data *__locales[13] ;
   unsigned short const   *__ctype_b ;
   int const   *__ctype_tolower ;
   int const   *__ctype_toupper ;
   char const   *__names[13] ;
};
typedef struct __locale_struct *__locale_t;
typedef __locale_t locale_t;
typedef int (*__compar_fn_t)(void const   * , void const   * );
enum __anonenum_ACTION_16 {
    FIND = 0,
    ENTER = 1
} ;
typedef enum __anonenum_ACTION_16 ACTION;
struct entry {
   char *key ;
   void *data ;
};
typedef struct entry ENTRY;
struct _ENTRY;
struct _ENTRY;
enum __anonenum_VISIT_17 {
    preorder = 0,
    postorder = 1,
    endorder = 2,
    leaf = 3
} ;
typedef enum __anonenum_VISIT_17 VISIT;
typedef void (*__action_fn_t)(void const   *__nodep , VISIT __value ,
                              int __level );
typedef signed char int8;
typedef unsigned char uint8;
typedef short int16;
typedef unsigned short uint16;
typedef int int32;
typedef unsigned int uint32;
typedef long long int64;
typedef unsigned long long uint64;
typedef int uint16_vap;
struct __anonstruct_TIFFHeaderCommon_18 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
};
typedef struct __anonstruct_TIFFHeaderCommon_18 TIFFHeaderCommon;
struct __anonstruct_TIFFHeaderClassic_19 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint32 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderClassic_19 TIFFHeaderClassic;
struct __anonstruct_TIFFHeaderBig_20 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint16 tiff_offsetsize ;
   uint16 tiff_unused ;
   uint64 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderBig_20 TIFFHeaderBig;
enum __anonenum_TIFFDataType_21 {
    TIFF_NOTYPE = 0,
    TIFF_BYTE = 1,
    TIFF_ASCII = 2,
    TIFF_SHORT = 3,
    TIFF_LONG = 4,
    TIFF_RATIONAL = 5,
    TIFF_SBYTE = 6,
    TIFF_UNDEFINED = 7,
    TIFF_SSHORT = 8,
    TIFF_SLONG = 9,
    TIFF_SRATIONAL = 10,
    TIFF_FLOAT = 11,
    TIFF_DOUBLE = 12,
    TIFF_IFD = 13,
    TIFF_LONG8 = 16,
    TIFF_SLONG8 = 17,
    TIFF_IFD8 = 18
} ;
typedef enum __anonenum_TIFFDataType_21 TIFFDataType;
struct tiff;
typedef struct tiff TIFF;
typedef long tmsize_t;
typedef uint32 ttag_t;
typedef uint16 tdir_t;
typedef uint16 tsample_t;
typedef uint32 tstrile_t;
typedef tstrile_t tstrip_t;
typedef tstrile_t ttile_t;
typedef tmsize_t tsize_t;
typedef void *tdata_t;
typedef uint64 toff_t;
typedef void *thandle_t;
typedef unsigned char TIFFRGBValue;
struct __anonstruct_TIFFDisplay_22 {
   float d_mat[3][3] ;
   float d_YCR ;
   float d_YCG ;
   float d_YCB ;
   uint32 d_Vrwr ;
   uint32 d_Vrwg ;
   uint32 d_Vrwb ;
   float d_Y0R ;
   float d_Y0G ;
   float d_Y0B ;
   float d_gammaR ;
   float d_gammaG ;
   float d_gammaB ;
};
typedef struct __anonstruct_TIFFDisplay_22 TIFFDisplay;
struct __anonstruct_TIFFYCbCrToRGB_23 {
   TIFFRGBValue *clamptab ;
   int *Cr_r_tab ;
   int *Cb_b_tab ;
   int32 *Cr_g_tab ;
   int32 *Cb_g_tab ;
   int32 *Y_tab ;
};
typedef struct __anonstruct_TIFFYCbCrToRGB_23 TIFFYCbCrToRGB;
struct __anonstruct_TIFFCIELabToRGB_24 {
   int range ;
   float rstep ;
   float gstep ;
   float bstep ;
   float X0 ;
   float Y0 ;
   float Z0 ;
   TIFFDisplay display ;
   float Yr2r[1501] ;
   float Yg2g[1501] ;
   float Yb2b[1501] ;
};
typedef struct __anonstruct_TIFFCIELabToRGB_24 TIFFCIELabToRGB;
struct _TIFFRGBAImage;
typedef struct _TIFFRGBAImage TIFFRGBAImage;
typedef void (*tileContigRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                  uint32  , uint32  , uint32  , int32  ,
                                  int32  , unsigned char * );
typedef void (*tileSeparateRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                    uint32  , uint32  , uint32  , int32  ,
                                    int32  , unsigned char * , unsigned char * ,
                                    unsigned char * , unsigned char * );
union __anonunion_put_25 {
   void (*any)(TIFFRGBAImage * ) ;
   void (*contig)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                  uint32  , int32  , int32  , unsigned char * ) ;
   void (*separate)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                    uint32  , int32  , int32  , unsigned char * ,
                    unsigned char * , unsigned char * , unsigned char * ) ;
};
struct _TIFFRGBAImage {
   TIFF *tif ;
   int stoponerr ;
   int isContig ;
   int alpha ;
   uint32 width ;
   uint32 height ;
   uint16 bitspersample ;
   uint16 samplesperpixel ;
   uint16 orientation ;
   uint16 req_orientation ;
   uint16 photometric ;
   uint16 *redcmap ;
   uint16 *greencmap ;
   uint16 *bluecmap ;
   int (*get)(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
   union __anonunion_put_25 put ;
   TIFFRGBValue *Map ;
   uint32 **BWmap ;
   uint32 **PALmap ;
   TIFFYCbCrToRGB *ycbcr ;
   TIFFCIELabToRGB *cielab ;
   uint8 *UaToAa ;
   uint8 *Bitdepth16To8 ;
   int row_offset ;
   int col_offset ;
};
typedef int (*TIFFInitMethod)(TIFF * , int  );
struct __anonstruct_TIFFCodec_26 {
   char *name ;
   uint16 scheme ;
   int (*init)(TIFF * , int  ) ;
};
typedef struct __anonstruct_TIFFCodec_26 TIFFCodec;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_28 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_27 {
   int __count ;
   union __anonunion___value_28 __value ;
};
typedef struct __anonstruct___mbstate_t_27 __mbstate_t;
struct __anonstruct__G_fpos_t_29 {
   __off_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos_t_29 _G_fpos_t;
struct __anonstruct__G_fpos64_t_30 {
   __off64_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos64_t_30 _G_fpos64_t;
typedef short _G_int16_t;
typedef int _G_int32_t;
typedef unsigned short _G_uint16_t;
typedef unsigned int _G_uint32_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_jump_t;
struct _IO_jump_t;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
enum __codecvt_result {
    __codecvt_ok = 0,
    __codecvt_partial = 1,
    __codecvt_error = 2,
    __codecvt_noconv = 3
} ;
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15U * sizeof(int ) - 4U * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
struct _IO_FILE_plus;
struct _IO_FILE_plus;
typedef __ssize_t __io_read_fn(void *__cookie , char *__buf , size_t __nbytes );
typedef __ssize_t __io_write_fn(void *__cookie , char const   *__buf ,
                                size_t __n );
typedef int __io_seek_fn(void *__cookie , __off64_t *__pos , int __w );
typedef int __io_close_fn(void *__cookie );
typedef __gnuc_va_list va_list;
typedef _G_fpos64_t fpos_t;
typedef void (*TIFFErrorHandler)(char const   * , char const   * , va_list  );
typedef void (*TIFFErrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  );
typedef tmsize_t (*TIFFReadWriteProc)(thandle_t  , void * , tmsize_t  );
typedef uint64 (*TIFFSeekProc)(thandle_t  , uint64  , int  );
typedef int (*TIFFCloseProc)(thandle_t  );
typedef uint64 (*TIFFSizeProc)(thandle_t  );
typedef int (*TIFFMapFileProc)(thandle_t  , void **base , toff_t *size );
typedef void (*TIFFUnmapFileProc)(thandle_t  , void *base , toff_t size );
typedef void (*TIFFExtendProc)(TIFF * );
struct _TIFFField;
typedef struct _TIFFField TIFFField;
struct _TIFFFieldArray;
typedef struct _TIFFFieldArray TIFFFieldArray;
typedef int (*TIFFVSetMethod)(TIFF * , uint32  , va_list  );
typedef int (*TIFFVGetMethod)(TIFF * , uint32  , va_list  );
typedef void (*TIFFPrintMethod)(TIFF * , FILE * , long  );
struct __anonstruct_TIFFTagMethods_31 {
   int (*vsetfield)(TIFF * , uint32  , va_list  ) ;
   int (*vgetfield)(TIFF * , uint32  , va_list  ) ;
   void (*printdir)(TIFF * , FILE * , long  ) ;
};
typedef struct __anonstruct_TIFFTagMethods_31 TIFFTagMethods;
struct __anonstruct_TIFFFieldInfo_32 {
   ttag_t field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
};
typedef struct __anonstruct_TIFFFieldInfo_32 TIFFFieldInfo;
struct __anonstruct_TIFFTagValue_33 {
   TIFFField const   *info ;
   int count ;
   void *value ;
};
typedef struct __anonstruct_TIFFTagValue_33 TIFFTagValue;
struct __anonstruct_TIFFDirectory_34 {
   unsigned long td_fieldsset[4] ;
   uint32 td_imagewidth ;
   uint32 td_imagelength ;
   uint32 td_imagedepth ;
   uint32 td_tilewidth ;
   uint32 td_tilelength ;
   uint32 td_tiledepth ;
   uint32 td_subfiletype ;
   uint16 td_bitspersample ;
   uint16 td_sampleformat ;
   uint16 td_compression ;
   uint16 td_photometric ;
   uint16 td_threshholding ;
   uint16 td_fillorder ;
   uint16 td_orientation ;
   uint16 td_samplesperpixel ;
   uint32 td_rowsperstrip ;
   uint16 td_minsamplevalue ;
   uint16 td_maxsamplevalue ;
   double td_sminsamplevalue ;
   double td_smaxsamplevalue ;
   float td_xresolution ;
   float td_yresolution ;
   uint16 td_resolutionunit ;
   uint16 td_planarconfig ;
   float td_xposition ;
   float td_yposition ;
   uint16 td_pagenumber[2] ;
   uint16 *td_colormap[3] ;
   uint16 td_halftonehints[2] ;
   uint16 td_extrasamples ;
   uint16 *td_sampleinfo ;
   uint32 td_stripsperimage ;
   uint32 td_nstrips ;
   uint64 *td_stripoffset ;
   uint64 *td_stripbytecount ;
   int td_stripbytecountsorted ;
   uint16 td_nsubifd ;
   uint64 *td_subifd ;
   uint16 td_ycbcrsubsampling[2] ;
   uint16 td_ycbcrpositioning ;
   uint16 *td_transferfunction[3] ;
   int td_inknameslen ;
   char *td_inknames ;
   int td_customValueCount ;
   TIFFTagValue *td_customValues ;
};
typedef struct __anonstruct_TIFFDirectory_34 TIFFDirectory;
enum __anonenum_TIFFSetGetFieldType_35 {
    TIFF_SETGET_UNDEFINED = 0,
    TIFF_SETGET_ASCII = 1,
    TIFF_SETGET_UINT8 = 2,
    TIFF_SETGET_SINT8 = 3,
    TIFF_SETGET_UINT16 = 4,
    TIFF_SETGET_SINT16 = 5,
    TIFF_SETGET_UINT32 = 6,
    TIFF_SETGET_SINT32 = 7,
    TIFF_SETGET_UINT64 = 8,
    TIFF_SETGET_SINT64 = 9,
    TIFF_SETGET_FLOAT = 10,
    TIFF_SETGET_DOUBLE = 11,
    TIFF_SETGET_IFD8 = 12,
    TIFF_SETGET_INT = 13,
    TIFF_SETGET_UINT16_PAIR = 14,
    TIFF_SETGET_C0_ASCII = 15,
    TIFF_SETGET_C0_UINT8 = 16,
    TIFF_SETGET_C0_SINT8 = 17,
    TIFF_SETGET_C0_UINT16 = 18,
    TIFF_SETGET_C0_SINT16 = 19,
    TIFF_SETGET_C0_UINT32 = 20,
    TIFF_SETGET_C0_SINT32 = 21,
    TIFF_SETGET_C0_UINT64 = 22,
    TIFF_SETGET_C0_SINT64 = 23,
    TIFF_SETGET_C0_FLOAT = 24,
    TIFF_SETGET_C0_DOUBLE = 25,
    TIFF_SETGET_C0_IFD8 = 26,
    TIFF_SETGET_C16_ASCII = 27,
    TIFF_SETGET_C16_UINT8 = 28,
    TIFF_SETGET_C16_SINT8 = 29,
    TIFF_SETGET_C16_UINT16 = 30,
    TIFF_SETGET_C16_SINT16 = 31,
    TIFF_SETGET_C16_UINT32 = 32,
    TIFF_SETGET_C16_SINT32 = 33,
    TIFF_SETGET_C16_UINT64 = 34,
    TIFF_SETGET_C16_SINT64 = 35,
    TIFF_SETGET_C16_FLOAT = 36,
    TIFF_SETGET_C16_DOUBLE = 37,
    TIFF_SETGET_C16_IFD8 = 38,
    TIFF_SETGET_C32_ASCII = 39,
    TIFF_SETGET_C32_UINT8 = 40,
    TIFF_SETGET_C32_SINT8 = 41,
    TIFF_SETGET_C32_UINT16 = 42,
    TIFF_SETGET_C32_SINT16 = 43,
    TIFF_SETGET_C32_UINT32 = 44,
    TIFF_SETGET_C32_SINT32 = 45,
    TIFF_SETGET_C32_UINT64 = 46,
    TIFF_SETGET_C32_SINT64 = 47,
    TIFF_SETGET_C32_FLOAT = 48,
    TIFF_SETGET_C32_DOUBLE = 49,
    TIFF_SETGET_C32_IFD8 = 50,
    TIFF_SETGET_OTHER = 51
} ;
typedef enum __anonenum_TIFFSetGetFieldType_35 TIFFSetGetFieldType;
enum __anonenum_TIFFFieldArrayType_36 {
    tfiatImage = 0,
    tfiatExif = 1,
    tfiatOther = 2
} ;
typedef enum __anonenum_TIFFFieldArrayType_36 TIFFFieldArrayType;
struct _TIFFFieldArray {
   TIFFFieldArrayType type ;
   uint32 allocated_size ;
   uint32 count ;
   TIFFField *fields ;
};
struct _TIFFField {
   uint32 field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   uint32 reserved ;
   TIFFSetGetFieldType set_field_type ;
   TIFFSetGetFieldType get_field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
   TIFFFieldArray *field_subfields ;
};
struct __anonstruct_TIFFDirEntry_37 {
   uint16 tdir_tag ;
   uint16 tdir_type ;
   uint64 tdir_count ;
   uint64 tdir_offset ;
};
typedef struct __anonstruct_TIFFDirEntry_37 TIFFDirEntry;
struct client_info {
   struct client_info *next ;
   void *data ;
   char *name ;
};
typedef struct client_info TIFFClientInfoLink;
typedef unsigned char tidataval_t;
typedef tidataval_t *tidata_t;
typedef void (*TIFFVoidMethod)(TIFF * );
typedef int (*TIFFBoolMethod)(TIFF * );
typedef int (*TIFFPreMethod)(TIFF * , uint16  );
typedef int (*TIFFCodeMethod)(TIFF *tif , uint8 *buf , tmsize_t size ,
                              uint16 sample );
typedef int (*TIFFSeekMethod)(TIFF * , uint32  );
typedef void (*TIFFPostMethod)(TIFF *tif , uint8 *buf , tmsize_t size );
typedef uint32 (*TIFFStripMethod)(TIFF * , uint32  );
typedef void (*TIFFTileMethod)(TIFF * , uint32 * , uint32 * );
union __anonunion_tif_header_38 {
   TIFFHeaderCommon common ;
   TIFFHeaderClassic classic ;
   TIFFHeaderBig big ;
};
struct tiff {
   char *tif_name ;
   int tif_fd ;
   int tif_mode ;
   uint32 tif_flags ;
   uint64 tif_diroff ;
   uint64 tif_nextdiroff ;
   uint64 *tif_dirlist ;
   uint16 tif_dirlistsize ;
   uint16 tif_dirnumber ;
   TIFFDirectory tif_dir ;
   TIFFDirectory tif_customdir ;
   union __anonunion_tif_header_38 tif_header ;
   uint16 tif_header_size ;
   uint32 tif_row ;
   uint16 tif_curdir ;
   uint32 tif_curstrip ;
   uint64 tif_curoff ;
   uint64 tif_dataoff ;
   uint16 tif_nsubifd ;
   uint64 tif_subifdoff ;
   uint32 tif_col ;
   uint32 tif_curtile ;
   tmsize_t tif_tilesize ;
   int tif_decodestatus ;
   int (*tif_fixuptags)(TIFF * ) ;
   int (*tif_setupdecode)(TIFF * ) ;
   int (*tif_predecode)(TIFF * , uint16  ) ;
   int (*tif_setupencode)(TIFF * ) ;
   int tif_encodestatus ;
   int (*tif_preencode)(TIFF * , uint16  ) ;
   int (*tif_postencode)(TIFF * ) ;
   int (*tif_decoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_decodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_encodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_decodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   void (*tif_close)(TIFF * ) ;
   int (*tif_seek)(TIFF * , uint32  ) ;
   void (*tif_cleanup)(TIFF * ) ;
   uint32 (*tif_defstripsize)(TIFF * , uint32  ) ;
   void (*tif_deftilesize)(TIFF * , uint32 * , uint32 * ) ;
   uint8 *tif_data ;
   tmsize_t tif_scanlinesize ;
   tmsize_t tif_scanlineskew ;
   uint8 *tif_rawdata ;
   tmsize_t tif_rawdatasize ;
   uint8 *tif_rawcp ;
   tmsize_t tif_rawcc ;
   uint8 *tif_base ;
   tmsize_t tif_size ;
   int (*tif_mapproc)(thandle_t  , void **base , toff_t *size ) ;
   void (*tif_unmapproc)(thandle_t  , void *base , toff_t size ) ;
   thandle_t tif_clientdata ;
   tmsize_t (*tif_readproc)(thandle_t  , void * , tmsize_t  ) ;
   tmsize_t (*tif_writeproc)(thandle_t  , void * , tmsize_t  ) ;
   uint64 (*tif_seekproc)(thandle_t  , uint64  , int  ) ;
   int (*tif_closeproc)(thandle_t  ) ;
   uint64 (*tif_sizeproc)(thandle_t  ) ;
   void (*tif_postdecode)(TIFF *tif , uint8 *buf , tmsize_t size ) ;
   TIFFField **tif_fields ;
   uint32 tif_nfields ;
   TIFFField const   *tif_foundfield ;
   TIFFTagMethods tif_tagmethods ;
   TIFFClientInfoLink *tif_clientinfo ;
   TIFFFieldArray *tif_fieldscompat ;
   uint32 tif_nfieldscompat ;
};
enum TIFFReadDirEntryErr {
    TIFFReadDirEntryErrOk = 0,
    TIFFReadDirEntryErrCount = 1,
    TIFFReadDirEntryErrType = 2,
    TIFFReadDirEntryErrIo = 3,
    TIFFReadDirEntryErrRange = 4,
    TIFFReadDirEntryErrPsdif = 5,
    TIFFReadDirEntryErrSizesan = 6,
    TIFFReadDirEntryErrAlloc = 7
} ;
extern int select(int __nfds , fd_set * __restrict  __readfds ,
                  fd_set * __restrict  __writefds ,
                  fd_set * __restrict  __exceptfds ,
                  struct timeval * __restrict  __timeout ) ;
extern int pselect(int __nfds , fd_set * __restrict  __readfds ,
                   fd_set * __restrict  __writefds ,
                   fd_set * __restrict  __exceptfds ,
                   struct timespec  const  * __restrict  __timeout ,
                   __sigset_t const   * __restrict  __sigmask ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_major(unsigned long long __dev ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1230\n");
  fflush(_coverage_fout);
  return ((unsigned int )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_minor(unsigned long long __dev ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1231\n");
  fflush(_coverage_fout);
  return ((unsigned int )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                   unsigned int __minor ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1232\n");
  fflush(_coverage_fout);
  return (((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32));
}
}
extern int fcntl(int __fd , int __cmd  , ...) ;
extern int open(char const   *__file , int __oflag  , ...)  __asm__("open64") __attribute__((__nonnull__(1))) ;
extern int openat(int __fd , char const   *__file , int __oflag  , ...)  __asm__("openat64") __attribute__((__nonnull__(2))) ;
extern int creat(char const   *__file , __mode_t __mode )  __asm__("creat64") __attribute__((__nonnull__(1))) ;
extern int lockf(int __fd , int __cmd , __off64_t __len )  __asm__("lockf64")  ;
extern  __attribute__((__nothrow__)) int posix_fadvise(int __fd ,
                                                       __off64_t __offset ,
                                                       __off64_t __len ,
                                                       int __advise )  __asm__("posix_fadvise64")  ;
extern int posix_fallocate(int __fd , __off64_t __offset , __off64_t __len )  __asm__("posix_fallocate64")  ;
extern  __attribute__((__nothrow__)) void *memcpy(void * __restrict  __dest ,
                                                  void const   * __restrict  __src ,
                                                  size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memmove(void *__dest ,
                                                   void const   *__src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memccpy(void * __restrict  __dest ,
                                                   void const   * __restrict  __src ,
                                                   int __c , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memset(void *__s , int __c ,
                                                  size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int memcmp(void const   *__s1 ,
                                                void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memchr(void const   *__s , int __c ,
                                                  size_t __n )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strcat(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncat(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcmp(char const   *__s1 ,
                                                char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncmp(char const   *__s1 ,
                                                 char const   *__s2 ,
                                                 size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcoll(char const   *__s1 ,
                                                 char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm(char * __restrict  __dest ,
                                                    char const   * __restrict  __src ,
                                                    size_t __n )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int strcoll_l(char const   *__s1 ,
                                                   char const   *__s2 ,
                                                   __locale_t __l )  __attribute__((__pure__,
__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm_l(char *__dest ,
                                                      char const   *__src ,
                                                      size_t __n ,
                                                      __locale_t __l )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) char *strdup(char const   *__s )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strndup(char const   *__string ,
                                                   size_t __n )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strrchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strcspn(char const   *__s ,
                                                    char const   *__reject )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strspn(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strpbrk(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strstr(char const   *__haystack ,
                                                  char const   *__needle )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strtok(char * __restrict  __s ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *__strtok_r(char * __restrict  __s ,
                                                      char const   * __restrict  __delim ,
                                                      char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) char *strtok_r(char * __restrict  __s ,
                                                    char const   * __restrict  __delim ,
                                                    char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) size_t strlen(char const   *__s )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strnlen(char const   *__string ,
                                                    size_t __maxlen )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strerror(int __errnum ) ;
extern  __attribute__((__nothrow__)) int strerror_r(int __errnum , char *__buf ,
                                                    size_t __buflen )  __asm__("__xpg_strerror_r") __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *strerror_l(int __errnum ,
                                                      __locale_t __l ) ;
extern  __attribute__((__nothrow__)) void __bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void bcopy(void const   *__src ,
                                                void *__dest , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int bcmp(void const   *__s1 ,
                                              void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *index(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *rindex(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int ffs(int __i )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int strcasecmp(char const   *__s1 ,
                                                    char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncasecmp(char const   *__s1 ,
                                                     char const   *__s2 ,
                                                     size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsep(char ** __restrict  __stringp ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsignal(int __sig ) ;
extern  __attribute__((__nothrow__)) char *__stpcpy(char * __restrict  __dest ,
                                                    char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *__stpncpy(char * __restrict  __dest ,
                                                     char const   * __restrict  __src ,
                                                     size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern void *__rawmemchr(void const   *__s , int __c ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1237\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "1238\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1235\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "1234\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject) {
        fprintf(_coverage_fout, "1233\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "1236\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "1239\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) ;
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1245\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "1246\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1243\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "1242\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        fprintf(_coverage_fout, "1241\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          fprintf(_coverage_fout, "1240\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "1244\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "1247\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) ;
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1254\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "1255\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1252\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "1251\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        fprintf(_coverage_fout, "1250\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          fprintf(_coverage_fout, "1249\n");
          fflush(_coverage_fout);
          if ((int const   )*(__s + __result) != (int const   )__reject3) {
            fprintf(_coverage_fout, "1248\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "1253\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "1256\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) ;
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1260\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "1261\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1258\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept) {
      fprintf(_coverage_fout, "1257\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1259\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "1262\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1268\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "1269\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1266\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      fprintf(_coverage_fout, "1263\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "1265\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        fprintf(_coverage_fout, "1264\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    }
    fprintf(_coverage_fout, "1267\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "1270\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1278\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "1279\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1276\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      fprintf(_coverage_fout, "1271\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "1275\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        fprintf(_coverage_fout, "1272\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "1274\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) == (int const   )__accept3) {
          fprintf(_coverage_fout, "1273\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      }
    }
    fprintf(_coverage_fout, "1277\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "1280\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1288\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1284\n");
    fflush(_coverage_fout);
    if ((int const   )*__s != 0) {
      fprintf(_coverage_fout, "1283\n");
      fflush(_coverage_fout);
      if ((int const   )*__s != (int const   )__accept1) {
        fprintf(_coverage_fout, "1282\n");
        fflush(_coverage_fout);
        if ((int const   )*__s != (int const   )__accept2) {
          fprintf(_coverage_fout, "1281\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "1285\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "1289\n");
  fflush(_coverage_fout);
  if ((int const   )*__s == 0) {
    fprintf(_coverage_fout, "1286\n");
    fflush(_coverage_fout);
    tmp = (char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "1287\n");
    fflush(_coverage_fout);
    tmp = (char *)((unsigned int )__s);
  }
  fprintf(_coverage_fout, "1290\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1299\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1295\n");
    fflush(_coverage_fout);
    if ((int const   )*__s != 0) {
      fprintf(_coverage_fout, "1294\n");
      fflush(_coverage_fout);
      if ((int const   )*__s != (int const   )__accept1) {
        fprintf(_coverage_fout, "1293\n");
        fflush(_coverage_fout);
        if ((int const   )*__s != (int const   )__accept2) {
          fprintf(_coverage_fout, "1292\n");
          fflush(_coverage_fout);
          if ((int const   )*__s != (int const   )__accept3) {
            fprintf(_coverage_fout, "1291\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "1296\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "1300\n");
  fflush(_coverage_fout);
  if ((int const   )*__s == 0) {
    fprintf(_coverage_fout, "1297\n");
    fflush(_coverage_fout);
    tmp = (char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "1298\n");
    fflush(_coverage_fout);
    tmp = (char *)((unsigned int )__s);
  }
  fprintf(_coverage_fout, "1301\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) ;
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) 
{ char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1319\n");
  fflush(_coverage_fout);
  if ((unsigned int )__s == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1302\n");
    fflush(_coverage_fout);
    __s = *__nextp;
  } else {
    fprintf(_coverage_fout, "1303\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1320\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1305\n");
    fflush(_coverage_fout);
    if ((int )*__s == (int )__sep) {
      fprintf(_coverage_fout, "1304\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1306\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "1321\n");
  fflush(_coverage_fout);
  __result = (char *)((void *)0);
  fprintf(_coverage_fout, "1322\n");
  fflush(_coverage_fout);
  if ((int )*__s != 0) {
    fprintf(_coverage_fout, "1314\n");
    fflush(_coverage_fout);
    tmp = __s;
    fprintf(_coverage_fout, "1315\n");
    fflush(_coverage_fout);
    __s ++;
    fprintf(_coverage_fout, "1316\n");
    fflush(_coverage_fout);
    __result = tmp;
    fprintf(_coverage_fout, "1317\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "1310\n");
      fflush(_coverage_fout);
      if ((int )*__s != 0) {
        fprintf(_coverage_fout, "1307\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "1311\n");
      fflush(_coverage_fout);
      tmp___0 = __s;
      fprintf(_coverage_fout, "1312\n");
      fflush(_coverage_fout);
      __s ++;
      fprintf(_coverage_fout, "1313\n");
      fflush(_coverage_fout);
      if ((int )*tmp___0 == (int )__sep) {
        fprintf(_coverage_fout, "1308\n");
        fflush(_coverage_fout);
        *(__s + -1) = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "1309\n");
        fflush(_coverage_fout);

      }
    }
  } else {
    fprintf(_coverage_fout, "1318\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1323\n");
  fflush(_coverage_fout);
  *__nextp = __s;
  fprintf(_coverage_fout, "1324\n");
  fflush(_coverage_fout);
  return (__result);
}
}
extern char *__strsep_g(char **__stringp , char const   *__delim ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) 
{ register char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  void *tmp___1 ;
  char *tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1334\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "1335\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1329\n");
    fflush(_coverage_fout);
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    fprintf(_coverage_fout, "1330\n");
    fflush(_coverage_fout);
    tmp___0 = tmp___2;
    fprintf(_coverage_fout, "1331\n");
    fflush(_coverage_fout);
    *__s = tmp___0;
    fprintf(_coverage_fout, "1332\n");
    fflush(_coverage_fout);
    if ((unsigned int )tmp___0 != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "1325\n");
      fflush(_coverage_fout);
      tmp = *__s;
      fprintf(_coverage_fout, "1326\n");
      fflush(_coverage_fout);
      (*__s) ++;
      fprintf(_coverage_fout, "1327\n");
      fflush(_coverage_fout);
      *tmp = (char )'\000';
    } else {
      fprintf(_coverage_fout, "1328\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "1333\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1336\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) ;
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1354\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "1355\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1350\n");
    fflush(_coverage_fout);
    __cp = __retval;
    fprintf(_coverage_fout, "1351\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "1347\n");
      fflush(_coverage_fout);
      if ((int )*__cp == 0) {
        fprintf(_coverage_fout, "1337\n");
        fflush(_coverage_fout);
        __cp = (char *)((void *)0);
        break;
      } else {
        fprintf(_coverage_fout, "1338\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1348\n");
      fflush(_coverage_fout);
      if ((int )*__cp == (int )__reject1) {
        fprintf(_coverage_fout, "1339\n");
        fflush(_coverage_fout);
        tmp = __cp;
        fprintf(_coverage_fout, "1340\n");
        fflush(_coverage_fout);
        __cp ++;
        fprintf(_coverage_fout, "1341\n");
        fflush(_coverage_fout);
        *tmp = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "1346\n");
        fflush(_coverage_fout);
        if ((int )*__cp == (int )__reject2) {
          fprintf(_coverage_fout, "1342\n");
          fflush(_coverage_fout);
          tmp = __cp;
          fprintf(_coverage_fout, "1343\n");
          fflush(_coverage_fout);
          __cp ++;
          fprintf(_coverage_fout, "1344\n");
          fflush(_coverage_fout);
          *tmp = (char )'\000';
          break;
        } else {
          fprintf(_coverage_fout, "1345\n");
          fflush(_coverage_fout);

        }
      }
      fprintf(_coverage_fout, "1349\n");
      fflush(_coverage_fout);
      __cp ++;
    }
    fprintf(_coverage_fout, "1352\n");
    fflush(_coverage_fout);
    *__s = __cp;
  } else {
    fprintf(_coverage_fout, "1353\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1356\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) ;
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1378\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "1379\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1374\n");
    fflush(_coverage_fout);
    __cp = __retval;
    fprintf(_coverage_fout, "1375\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "1371\n");
      fflush(_coverage_fout);
      if ((int )*__cp == 0) {
        fprintf(_coverage_fout, "1357\n");
        fflush(_coverage_fout);
        __cp = (char *)((void *)0);
        break;
      } else {
        fprintf(_coverage_fout, "1358\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1372\n");
      fflush(_coverage_fout);
      if ((int )*__cp == (int )__reject1) {
        fprintf(_coverage_fout, "1359\n");
        fflush(_coverage_fout);
        tmp = __cp;
        fprintf(_coverage_fout, "1360\n");
        fflush(_coverage_fout);
        __cp ++;
        fprintf(_coverage_fout, "1361\n");
        fflush(_coverage_fout);
        *tmp = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "1370\n");
        fflush(_coverage_fout);
        if ((int )*__cp == (int )__reject2) {
          fprintf(_coverage_fout, "1362\n");
          fflush(_coverage_fout);
          tmp = __cp;
          fprintf(_coverage_fout, "1363\n");
          fflush(_coverage_fout);
          __cp ++;
          fprintf(_coverage_fout, "1364\n");
          fflush(_coverage_fout);
          *tmp = (char )'\000';
          break;
        } else {
          fprintf(_coverage_fout, "1369\n");
          fflush(_coverage_fout);
          if ((int )*__cp == (int )__reject3) {
            fprintf(_coverage_fout, "1365\n");
            fflush(_coverage_fout);
            tmp = __cp;
            fprintf(_coverage_fout, "1366\n");
            fflush(_coverage_fout);
            __cp ++;
            fprintf(_coverage_fout, "1367\n");
            fflush(_coverage_fout);
            *tmp = (char )'\000';
            break;
          } else {
            fprintf(_coverage_fout, "1368\n");
            fflush(_coverage_fout);

          }
        }
      }
      fprintf(_coverage_fout, "1373\n");
      fflush(_coverage_fout);
      __cp ++;
    }
    fprintf(_coverage_fout, "1376\n");
    fflush(_coverage_fout);
    *__s = __cp;
  } else {
    fprintf(_coverage_fout, "1377\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1380\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
extern  __attribute__((__nothrow__)) void *malloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *calloc(size_t __nmemb ,
                                                  size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strdup(char const   *__string )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strndup(char const   *__string ,
                                                     size_t __n )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_fail(char const   *__assertion ,
                                  char const   *__file , unsigned int __line ,
                                  char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_perror_fail(int __errnum , char const   *__file ,
                                         unsigned int __line ,
                                         char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert(char const   *__assertion , char const   *__file ,
                             int __line ) ;
extern  __attribute__((__nothrow__)) void insque(void *__elem , void *__prev ) ;
extern  __attribute__((__nothrow__)) void remque(void *__elem ) ;
extern  __attribute__((__nothrow__)) ENTRY *hsearch(ENTRY __item ,
                                                    ACTION __action ) ;
extern  __attribute__((__nothrow__)) int hcreate(size_t __nel ) ;
extern  __attribute__((__nothrow__)) void hdestroy(void) ;
extern void *tsearch(void const   *__key , void **__rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void *tfind(void const   *__key , void * const  *__rootp ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *tdelete(void const   * __restrict  __key ,
                     void ** __restrict  __rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void twalk(void const   *__root ,
                  void (*__action)(void const   *__nodep , VISIT __value ,
                                   int __level ) ) ;
extern void *lfind(void const   *__key , void const   *__base ,
                   size_t *__nmemb , size_t __size ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *lsearch(void const   *__key , void *__base , size_t *__nmemb ,
                     size_t __size , int (*__compar)(void const   * ,
                                                     void const   * ) ) ;
extern struct _IO_FILE_plus _IO_2_1_stdin_ ;
extern struct _IO_FILE_plus _IO_2_1_stdout_ ;
extern struct _IO_FILE_plus _IO_2_1_stderr_ ;
extern int __underflow(_IO_FILE * ) ;
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_feof(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_ferror(_IO_FILE *__fp ) ;
extern int _IO_peekc_locked(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) void _IO_flockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) void _IO_funlockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) int _IO_ftrylockfile(_IO_FILE * ) ;
extern int _IO_vfscanf(_IO_FILE * __restrict   , char const   * __restrict   ,
                       __gnuc_va_list  , int * __restrict   ) ;
extern int _IO_vfprintf(_IO_FILE * __restrict   , char const   * __restrict   ,
                        __gnuc_va_list  ) ;
extern __ssize_t _IO_padn(_IO_FILE * , int  , __ssize_t  ) ;
extern size_t _IO_sgetn(_IO_FILE * , void * , size_t  ) ;
extern __off64_t _IO_seekoff(_IO_FILE * , __off64_t  , int  , int  ) ;
extern __off64_t _IO_seekpos(_IO_FILE * , __off64_t  , int  ) ;
extern  __attribute__((__nothrow__)) void _IO_free_backup_area(_IO_FILE * ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
extern  __attribute__((__nothrow__)) int remove(char const   *__filename ) ;
extern  __attribute__((__nothrow__)) int rename(char const   *__old ,
                                                char const   *__new ) ;
extern  __attribute__((__nothrow__)) int renameat(int __oldfd ,
                                                  char const   *__old ,
                                                  int __newfd ,
                                                  char const   *__new ) ;
extern FILE *tmpfile(void)  __asm__("tmpfile64")  ;
extern  __attribute__((__nothrow__)) char *tmpnam(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tmpnam_r(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tempnam(char const   *__dir ,
                                                   char const   *__pfx )  __attribute__((__malloc__)) ;
extern int fclose(FILE *__stream ) ;
extern int fflush(FILE *__stream ) ;
extern int fflush_unlocked(FILE *__stream ) ;
extern FILE *freopen(char const   * __restrict  __filename ,
                     char const   * __restrict  __modes ,
                     FILE * __restrict  __stream )  __asm__("freopen64")  ;
extern  __attribute__((__nothrow__)) FILE *fdopen(int __fd ,
                                                  char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *fmemopen(void *__s , size_t __len ,
                                                    char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *open_memstream(char **__bufloc ,
                                                          size_t *__sizeloc ) ;
extern  __attribute__((__nothrow__)) void setbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) int setvbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ,
                                                 int __modes , size_t __n ) ;
extern  __attribute__((__nothrow__)) void setbuffer(FILE * __restrict  __stream ,
                                                    char * __restrict  __buf ,
                                                    size_t __size ) ;
extern  __attribute__((__nothrow__)) void setlinebuf(FILE *__stream ) ;
extern int fprintf(FILE * __restrict  __stream ,
                   char const   * __restrict  __format  , ...) ;
extern int printf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sprintf(char * __restrict  __s ,
                                                 char const   * __restrict  __format 
                                                 , ...) ;
extern int vfprintf(FILE * __restrict  __s ,
                    char const   * __restrict  __format , __gnuc_va_list __arg ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vsprintf(char * __restrict  __s ,
                                                  char const   * __restrict  __format ,
                                                  __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  snprintf)(char * __restrict  __s ,
                                                                             size_t __maxlen ,
                                                                             char const   * __restrict  __format 
                                                                             , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsnprintf)(char * __restrict  __s ,
                                                                              size_t __maxlen ,
                                                                              char const   * __restrict  __format ,
                                                                              __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  vdprintf)(int __fd ,
                                               char const   * __restrict  __fmt ,
                                               __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  dprintf)(int __fd ,
                                              char const   * __restrict  __fmt 
                                              , ...) ;
extern int fscanf(FILE * __restrict  __stream ,
                  char const   * __restrict  __format  , ...)  __asm__("__isoc99_fscanf")  ;
extern int scanf(char const   * __restrict  __format  , ...)  __asm__("__isoc99_scanf")  ;
extern  __attribute__((__nothrow__)) int sscanf(char const   * __restrict  __s ,
                                                char const   * __restrict  __format 
                                                , ...)  __asm__("__isoc99_sscanf")  ;
extern int ( /* format attribute */  vfscanf)(FILE * __restrict  __s ,
                                              char const   * __restrict  __format ,
                                              __gnuc_va_list __arg )  __asm__("__isoc99_vfscanf")  ;
extern int ( /* format attribute */  vscanf)(char const   * __restrict  __format ,
                                             __gnuc_va_list __arg )  __asm__("__isoc99_vscanf")  ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsscanf)(char const   * __restrict  __s ,
                                                                            char const   * __restrict  __format ,
                                                                            __gnuc_va_list __arg )  __asm__("__isoc99_vsscanf")  ;
extern int fgetc(FILE *__stream ) ;
extern int getc(FILE *__stream ) ;
__inline extern int getchar(void) ;
__inline extern int getc_unlocked(FILE *__fp ) ;
__inline extern int getchar_unlocked(void) ;
__inline extern int fgetc_unlocked(FILE *__fp ) ;
extern int fputc(int __c , FILE *__stream ) ;
extern int putc(int __c , FILE *__stream ) ;
__inline extern int putchar(int __c ) ;
__inline extern int fputc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putchar_unlocked(int __c ) ;
extern int getw(FILE *__stream ) ;
extern int putw(int __w , FILE *__stream ) ;
extern char *fgets(char * __restrict  __s , int __n ,
                   FILE * __restrict  __stream ) ;
extern char *gets(char *__s ) ;
extern __ssize_t __getdelim(char ** __restrict  __lineptr ,
                            size_t * __restrict  __n , int __delimiter ,
                            FILE * __restrict  __stream ) ;
extern __ssize_t getdelim(char ** __restrict  __lineptr ,
                          size_t * __restrict  __n , int __delimiter ,
                          FILE * __restrict  __stream ) ;
extern __ssize_t getline(char ** __restrict  __lineptr ,
                         size_t * __restrict  __n , FILE * __restrict  __stream ) ;
extern int fputs(char const   * __restrict  __s , FILE * __restrict  __stream ) ;
extern int puts(char const   *__s ) ;
extern int ungetc(int __c , FILE *__stream ) ;
extern size_t fread(void * __restrict  __ptr , size_t __size , size_t __n ,
                    FILE * __restrict  __stream ) ;
extern size_t fwrite(void const   * __restrict  __ptr , size_t __size ,
                     size_t __n , FILE * __restrict  __s ) ;
extern size_t fread_unlocked(void * __restrict  __ptr , size_t __size ,
                             size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite_unlocked(void const   * __restrict  __ptr , size_t __size ,
                              size_t __n , FILE * __restrict  __stream ) ;
extern int fseek(FILE *__stream , long __off , int __whence ) ;
extern long ftell(FILE *__stream ) ;
extern void rewind(FILE *__stream ) ;
extern int fseeko(FILE *__stream , __off64_t __off , int __whence )  __asm__("fseeko64")  ;
extern __off64_t ftello(FILE *__stream )  __asm__("ftello64")  ;
extern int fgetpos(FILE * __restrict  __stream , fpos_t * __restrict  __pos )  __asm__("fgetpos64")  ;
extern int fsetpos(FILE *__stream , fpos_t const   *__pos )  __asm__("fsetpos64")  ;
extern  __attribute__((__nothrow__)) void clearerr(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int feof(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ferror(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void clearerr_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
extern void perror(char const   *__s ) ;
extern int sys_nerr ;
extern char const   * const  sys_errlist[] ;
extern  __attribute__((__nothrow__)) int fileno(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int fileno_unlocked(FILE *__stream ) ;
extern FILE *popen(char const   *__command , char const   *__modes ) ;
extern int pclose(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) char *ctermid(char *__s ) ;
extern  __attribute__((__nothrow__)) void flockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ftrylockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void funlockfile(FILE *__stream ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1381\n");
  fflush(_coverage_fout);
  tmp = vfprintf((FILE */* __restrict  */)stdout, __fmt, __arg);
  fprintf(_coverage_fout, "1382\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int getchar(void) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1383\n");
  fflush(_coverage_fout);
  tmp = _IO_getc(stdin);
  fprintf(_coverage_fout, "1384\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int fgetc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1390\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "1391\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "1385\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "1386\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "1387\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "1388\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "1389\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "1392\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int getc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1398\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "1399\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "1393\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "1394\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "1395\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "1396\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "1397\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "1400\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int getchar_unlocked(void) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1406\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )stdin->_IO_read_ptr >= (unsigned int )stdin->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "1407\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "1401\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(stdin);
    fprintf(_coverage_fout, "1402\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "1403\n");
    fflush(_coverage_fout);
    tmp___1 = stdin->_IO_read_ptr;
    fprintf(_coverage_fout, "1404\n");
    fflush(_coverage_fout);
    (stdin->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "1405\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "1408\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int putchar(int __c ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1409\n");
  fflush(_coverage_fout);
  tmp = _IO_putc(__c, stdout);
  fprintf(_coverage_fout, "1410\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int fputc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1418\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "1419\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "1411\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "1412\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "1413\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "1414\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "1415\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "1416\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "1417\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "1420\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern int putc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1428\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "1429\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "1421\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "1422\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "1423\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "1424\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "1425\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "1426\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "1427\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "1430\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern int putchar_unlocked(int __c ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1438\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )stdout->_IO_write_ptr >= (unsigned int )stdout->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "1439\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "1431\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "1432\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "1433\n");
    fflush(_coverage_fout);
    tmp___1 = stdout->_IO_write_ptr;
    fprintf(_coverage_fout, "1434\n");
    fflush(_coverage_fout);
    (stdout->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "1435\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "1436\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "1437\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "1440\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern int feof_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1441\n");
  fflush(_coverage_fout);
  return ((__stream->_flags & 0x10) != 0);
}
}
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
__inline extern int ferror_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1442\n");
  fflush(_coverage_fout);
  return ((__stream->_flags & 0x20) != 0);
}
}
extern char const   *TIFFGetVersion(void) ;
extern TIFFCodec const   *TIFFFindCODEC(uint16  ) ;
extern TIFFCodec *TIFFRegisterCODEC(uint16  , char const   * ,
                                    int (*)(TIFF * , int  ) ) ;
extern void TIFFUnRegisterCODEC(TIFFCodec * ) ;
extern int TIFFIsCODECConfigured(uint16  ) ;
extern TIFFCodec *TIFFGetConfiguredCODECs(void) ;
extern void *_TIFFmalloc(tmsize_t s ) ;
extern void *_TIFFrealloc(void *p , tmsize_t s ) ;
extern void _TIFFmemset(void *p , int v , tmsize_t c ) ;
extern void _TIFFmemcpy(void *d , void const   *s , tmsize_t c ) ;
extern int _TIFFmemcmp(void const   *p1 , void const   *p2 , tmsize_t c ) ;
extern void _TIFFfree(void *p ) ;
extern int TIFFGetTagListCount(TIFF * ) ;
extern uint32 TIFFGetTagListEntry(TIFF * , int tag_index ) ;
extern TIFFField const   *TIFFFindField(TIFF * , uint32  , TIFFDataType  ) ;
extern TIFFField const   *TIFFFieldWithTag(TIFF * , uint32  ) ;
extern TIFFField const   *TIFFFieldWithName(TIFF * , char const   * ) ;
extern TIFFTagMethods *TIFFAccessTagMethods(TIFF * ) ;
extern void *TIFFGetClientInfo(TIFF * , char const   * ) ;
extern void TIFFSetClientInfo(TIFF * , void * , char const   * ) ;
extern void TIFFCleanup(TIFF *tif ) ;
extern void TIFFClose(TIFF *tif ) ;
extern int TIFFFlush(TIFF *tif ) ;
extern int TIFFFlushData(TIFF *tif ) ;
extern int TIFFGetField(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFVGetField(TIFF *tif , uint32 tag , va_list ap ) ;
extern int TIFFGetFieldDefaulted(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFVGetFieldDefaulted(TIFF *tif , uint32 tag , va_list ap ) ;
int TIFFReadDirectory(TIFF *tif ) ;
int TIFFReadCustomDirectory(TIFF *tif , uint64 diroff ,
                            TIFFFieldArray const   *infoarray ) ;
int TIFFReadEXIFDirectory(TIFF *tif , uint64 diroff ) ;
extern uint64 TIFFScanlineSize64(TIFF *tif ) ;
extern tmsize_t TIFFScanlineSize(TIFF *tif ) ;
extern uint64 TIFFRasterScanlineSize64(TIFF *tif ) ;
extern tmsize_t TIFFRasterScanlineSize(TIFF *tif ) ;
extern uint64 TIFFStripSize64(TIFF *tif ) ;
extern tmsize_t TIFFStripSize(TIFF *tif ) ;
extern uint64 TIFFRawStripSize64(TIFF *tif , uint32 strip ) ;
extern tmsize_t TIFFRawStripSize(TIFF *tif , uint32 strip ) ;
extern uint64 TIFFVStripSize64(TIFF *tif , uint32 nrows ) ;
extern tmsize_t TIFFVStripSize(TIFF *tif , uint32 nrows ) ;
extern uint64 TIFFTileRowSize64(TIFF *tif ) ;
extern tmsize_t TIFFTileRowSize(TIFF *tif ) ;
extern uint64 TIFFTileSize64(TIFF *tif ) ;
extern tmsize_t TIFFTileSize(TIFF *tif ) ;
extern uint64 TIFFVTileSize64(TIFF *tif , uint32 nrows ) ;
extern tmsize_t TIFFVTileSize(TIFF *tif , uint32 nrows ) ;
extern uint32 TIFFDefaultStripSize(TIFF *tif , uint32 request ) ;
extern void TIFFDefaultTileSize(TIFF * , uint32 * , uint32 * ) ;
extern int TIFFFileno(TIFF * ) ;
extern int TIFFSetFileno(TIFF * , int  ) ;
extern thandle_t TIFFClientdata(TIFF * ) ;
extern thandle_t TIFFSetClientdata(TIFF * , thandle_t  ) ;
extern int TIFFGetMode(TIFF * ) ;
extern int TIFFSetMode(TIFF * , int  ) ;
extern int TIFFIsTiled(TIFF * ) ;
extern int TIFFIsByteSwapped(TIFF * ) ;
extern int TIFFIsUpSampled(TIFF * ) ;
extern int TIFFIsMSB2LSB(TIFF * ) ;
extern int TIFFIsBigEndian(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetReadProc(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetWriteProc(TIFF * ) ;
extern TIFFSeekProc TIFFGetSeekProc(TIFF * ) ;
extern TIFFCloseProc TIFFGetCloseProc(TIFF * ) ;
extern TIFFSizeProc TIFFGetSizeProc(TIFF * ) ;
extern TIFFMapFileProc TIFFGetMapFileProc(TIFF * ) ;
extern TIFFUnmapFileProc TIFFGetUnmapFileProc(TIFF * ) ;
extern uint32 TIFFCurrentRow(TIFF * ) ;
extern uint16 TIFFCurrentDirectory(TIFF * ) ;
extern uint16 TIFFNumberOfDirectories(TIFF * ) ;
extern uint64 TIFFCurrentDirOffset(TIFF * ) ;
extern uint32 TIFFCurrentStrip(TIFF * ) ;
extern uint32 TIFFCurrentTile(TIFF *tif ) ;
extern int TIFFReadBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
extern int TIFFWriteBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
extern int TIFFSetupStrips(TIFF * ) ;
extern int TIFFWriteCheck(TIFF * , int  , char const   * ) ;
extern void TIFFFreeDirectory(TIFF * ) ;
extern int TIFFCreateDirectory(TIFF * ) ;
extern int TIFFLastDirectory(TIFF * ) ;
extern int TIFFSetDirectory(TIFF * , uint16  ) ;
extern int TIFFSetSubDirectory(TIFF * , uint64  ) ;
extern int TIFFUnlinkDirectory(TIFF * , uint16  ) ;
extern int TIFFSetField(TIFF * , uint32   , ...) ;
extern int TIFFVSetField(TIFF * , uint32  , va_list  ) ;
extern int TIFFWriteDirectory(TIFF * ) ;
extern int TIFFCheckpointDirectory(TIFF * ) ;
extern int TIFFRewriteDirectory(TIFF * ) ;
extern void TIFFPrintDirectory(TIFF * , FILE * , long  ) ;
extern int TIFFReadScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) ;
extern int TIFFWriteScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) ;
extern int TIFFReadRGBAImage(TIFF * , uint32  , uint32  , uint32 * , int  ) ;
extern int TIFFReadRGBAImageOriented(TIFF * , uint32  , uint32  , uint32 * ,
                                     int  , int  ) ;
extern int TIFFReadRGBAStrip(TIFF * , uint32  , uint32 * ) ;
extern int TIFFReadRGBATile(TIFF * , uint32  , uint32  , uint32 * ) ;
extern int TIFFRGBAImageOK(TIFF * , char * ) ;
extern int TIFFRGBAImageBegin(TIFFRGBAImage * , TIFF * , int  , char * ) ;
extern int TIFFRGBAImageGet(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
extern void TIFFRGBAImageEnd(TIFFRGBAImage * ) ;
extern TIFF *TIFFOpen(char const   * , char const   * ) ;
extern TIFF *TIFFFdOpen(int  , char const   * , char const   * ) ;
extern TIFF *TIFFClientOpen(char const   * , char const   * , thandle_t  ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            uint64 (*)(thandle_t  , uint64  , int  ) ,
                            int (*)(thandle_t  ) , uint64 (*)(thandle_t  ) ,
                            int (*)(thandle_t  , void **base , toff_t *size ) ,
                            void (*)(thandle_t  , void *base , toff_t size ) ) ;
extern char const   *TIFFFileName(TIFF * ) ;
extern char const   *TIFFSetFileName(TIFF * , char const   * ) ;
extern void TIFFError(char const   * , char const   *  , ...) ;
extern void TIFFErrorExt(thandle_t  , char const   * , char const   *  , ...) ;
extern void TIFFWarning(char const   * , char const   *  , ...) ;
extern void TIFFWarningExt(thandle_t  , char const   * , char const   *  , ...) ;
extern TIFFErrorHandler TIFFSetErrorHandler(void (*)(char const   * ,
                                                     char const   * , va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetErrorHandlerExt(void (*)(thandle_t  ,
                                                           char const   * ,
                                                           char const   * ,
                                                           va_list  ) ) ;
extern TIFFErrorHandler TIFFSetWarningHandler(void (*)(char const   * ,
                                                       char const   * ,
                                                       va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetWarningHandlerExt(void (*)(thandle_t  ,
                                                             char const   * ,
                                                             char const   * ,
                                                             va_list  ) ) ;
extern TIFFExtendProc TIFFSetTagExtender(void (*)(TIFF * ) ) ;
extern uint32 TIFFComputeTile(TIFF *tif , uint32 x , uint32 y , uint32 z ,
                              uint16 s ) ;
extern int TIFFCheckTile(TIFF *tif , uint32 x , uint32 y , uint32 z , uint16 s ) ;
extern uint32 TIFFNumberOfTiles(TIFF * ) ;
extern tmsize_t TIFFReadTile(TIFF *tif , void *buf , uint32 x , uint32 y ,
                             uint32 z , uint16 s ) ;
extern tmsize_t TIFFWriteTile(TIFF *tif , void *buf , uint32 x , uint32 y ,
                              uint32 z , uint16 s ) ;
extern uint32 TIFFComputeStrip(TIFF * , uint32  , uint16  ) ;
extern uint32 TIFFNumberOfStrips(TIFF * ) ;
extern tmsize_t TIFFReadEncodedStrip(TIFF *tif , uint32 strip , void *buf ,
                                     tmsize_t size ) ;
extern tmsize_t TIFFReadRawStrip(TIFF *tif , uint32 strip , void *buf ,
                                 tmsize_t size ) ;
extern tmsize_t TIFFReadEncodedTile(TIFF *tif , uint32 tile , void *buf ,
                                    tmsize_t size ) ;
extern tmsize_t TIFFReadRawTile(TIFF *tif , uint32 tile , void *buf ,
                                tmsize_t size ) ;
extern tmsize_t TIFFWriteEncodedStrip(TIFF *tif , uint32 strip , void *data ,
                                      tmsize_t cc ) ;
extern tmsize_t TIFFWriteRawStrip(TIFF *tif , uint32 strip , void *data ,
                                  tmsize_t cc ) ;
extern tmsize_t TIFFWriteEncodedTile(TIFF *tif , uint32 tile , void *data ,
                                     tmsize_t cc ) ;
extern tmsize_t TIFFWriteRawTile(TIFF *tif , uint32 tile , void *data ,
                                 tmsize_t cc ) ;
extern int TIFFDataWidth(TIFFDataType  ) ;
extern void TIFFSetWriteOffset(TIFF *tif , uint64 off ) ;
extern void TIFFSwabShort(uint16 * ) ;
extern void TIFFSwabLong(uint32 * ) ;
extern void TIFFSwabLong8(uint64 * ) ;
extern void TIFFSwabFloat(float * ) ;
extern void TIFFSwabDouble(double * ) ;
extern void TIFFSwabArrayOfShort(uint16 *wp , tmsize_t n ) ;
extern void TIFFSwabArrayOfTriples(uint8 *tp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong(uint32 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong8(uint64 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfFloat(float *fp , tmsize_t n ) ;
extern void TIFFSwabArrayOfDouble(double *dp , tmsize_t n ) ;
extern void TIFFReverseBits(uint8 *cp , tmsize_t n ) ;
extern unsigned char const   *TIFFGetBitRevTable(int  ) ;
extern double LogL16toY(int  ) ;
extern double LogL10toY(int  ) ;
extern void XYZtoRGB24(float * , uint8 * ) ;
extern int uv_decode(double * , double * , int  ) ;
extern void LogLuv24toXYZ(uint32  , float * ) ;
extern void LogLuv32toXYZ(uint32  , float * ) ;
extern int LogL16fromY(double  , int  ) ;
extern int LogL10fromY(double  , int  ) ;
extern int uv_encode(double  , double  , int  ) ;
extern uint32 LogLuv24fromXYZ(float * , int  ) ;
extern uint32 LogLuv32fromXYZ(float * , int  ) ;
extern int TIFFCIELabToRGBInit(TIFFCIELabToRGB * , TIFFDisplay * , float * ) ;
extern void TIFFCIELabToXYZ(TIFFCIELabToRGB * , uint32  , int32  , int32  ,
                            float * , float * , float * ) ;
extern void TIFFXYZToRGB(TIFFCIELabToRGB * , float  , float  , float  ,
                         uint32 * , uint32 * , uint32 * ) ;
extern int TIFFYCbCrToRGBInit(TIFFYCbCrToRGB * , float * , float * ) ;
extern void TIFFYCbCrtoRGB(TIFFYCbCrToRGB * , uint32  , int32  , int32  ,
                           uint32 * , uint32 * , uint32 * ) ;
extern int TIFFMergeFieldInfo(TIFF * , TIFFFieldInfo const   * , uint32  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfo(TIFF * , uint32  ,
                                                TIFFDataType  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfoByName(TIFF * , char const   * ,
                                                      TIFFDataType  ) ;
extern TIFFFieldArray const   *_TIFFGetFields(void) ;
extern TIFFFieldArray const   *_TIFFGetExifFields(void) ;
extern void _TIFFSetupFields(TIFF *tif , TIFFFieldArray const   *infoarray ) ;
extern void _TIFFPrintFieldInfo(TIFF * , FILE * ) ;
extern int _TIFFMergeFields(TIFF * , TIFFField const   * , uint32  ) ;
extern TIFFField const   *_TIFFFindOrRegisterField(TIFF * , uint32  ,
                                                   TIFFDataType  ) ;
extern TIFFField *_TIFFCreateAnonField(TIFF * , uint32  , TIFFDataType  ) ;
extern int _TIFFgetMode(char const   *mode , char const   *module ) ;
extern int _TIFFNoRowEncode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoStripEncode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoTileEncode(TIFF * , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoRowDecode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoStripDecode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoTileDecode(TIFF * , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern void _TIFFNoPostDecode(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern int _TIFFNoPreCode(TIFF *tif , uint16 s ) ;
extern int _TIFFNoSeek(TIFF *tif , uint32 off ) ;
extern void _TIFFSwab16BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab24BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab32BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab64BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern int TIFFFlushData1(TIFF *tif ) ;
extern int TIFFDefaultDirectory(TIFF *tif ) ;
extern void _TIFFSetDefaultCompressionState(TIFF *tif ) ;
extern int TIFFSetCompressionScheme(TIFF *tif , int scheme ) ;
extern int TIFFSetDefaultCompressionState(TIFF *tif ) ;
extern uint32 _TIFFDefaultStripSize(TIFF *tif , uint32 s ) ;
extern void _TIFFDefaultTileSize(TIFF *tif , uint32 *tw , uint32 *th ) ;
extern int _TIFFDataSize(TIFFDataType type ) ;
extern void _TIFFsetByteArray(void ** , void * , uint32  ) ;
extern void _TIFFsetString(char ** , char * ) ;
extern void _TIFFsetShortArray(uint16 ** , uint16 * , uint32  ) ;
extern void _TIFFsetLongArray(uint32 ** , uint32 * , uint32  ) ;
extern void _TIFFsetFloatArray(float ** , float * , uint32  ) ;
extern void _TIFFsetDoubleArray(double ** , double * , uint32  ) ;
extern void _TIFFprintAscii(FILE * , char const   * ) ;
extern void _TIFFprintAsciiTag(FILE * , char const   * , char const   * ) ;
extern void (*_TIFFwarningHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFerrorHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFwarningHandlerExt)(thandle_t  , char const   * ,
                                      char const   * , va_list  ) ;
extern void (*_TIFFerrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  ) ;
extern void *_TIFFCheckMalloc(TIFF *tif , tmsize_t nmemb , tmsize_t elem_size ,
                              char const   *what ) ;
extern void *_TIFFCheckRealloc(TIFF *tif , void *buffer , tmsize_t nmemb ,
                               tmsize_t elem_size , char const   *what ) ;
extern double _TIFFUInt64ToDouble(uint64  ) ;
extern float _TIFFUInt64ToFloat(uint64  ) ;
extern int TIFFInitDumpMode(TIFF * , int  ) ;
extern int TIFFInitPackBits(TIFF * , int  ) ;
extern int TIFFInitCCITTRLE(TIFF * , int  ) ;
extern int TIFFInitCCITTRLEW(TIFF * , int  ) ;
extern int TIFFInitCCITTFax3(TIFF * , int  ) ;
extern int TIFFInitCCITTFax4(TIFF * , int  ) ;
extern int TIFFInitThunderScan(TIFF * , int  ) ;
extern int TIFFInitNeXT(TIFF * , int  ) ;
extern int TIFFInitLZW(TIFF * , int  ) ;
extern int TIFFInitZIP(TIFF * , int  ) ;
extern int TIFFInitPixarLog(TIFF * , int  ) ;
extern int TIFFInitSGILog(TIFF * , int  ) ;
extern TIFFCodec _TIFFBuiltinCODECS[] ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryByte(TIFF *tif ,
                                                     TIFFDirEntry *direntry ,
                                                     uint8 *value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryShort(TIFF *tif ,
                                                      TIFFDirEntry *direntry ,
                                                      uint16 *value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryLong(TIFF *tif ,
                                                     TIFFDirEntry *direntry ,
                                                     uint32 *value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryLong8(TIFF *tif ,
                                                      TIFFDirEntry *direntry ,
                                                      uint64 *value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryFloat(TIFF *tif ,
                                                      TIFFDirEntry *direntry ,
                                                      float *value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryDouble(TIFF *tif ,
                                                       TIFFDirEntry *direntry ,
                                                       double *value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryIfd8(TIFF *tif ,
                                                     TIFFDirEntry *direntry ,
                                                     uint64 *value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryArray(TIFF *tif ,
                                                      TIFFDirEntry *direntry ,
                                                      uint32 *count ,
                                                      uint32 desttypesize ,
                                                      void **value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryByteArray(TIFF *tif ,
                                                          TIFFDirEntry *direntry ,
                                                          uint8 **value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntrySbyteArray(TIFF *tif ,
                                                           TIFFDirEntry *direntry ,
                                                           int8 **value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryShortArray(TIFF *tif ,
                                                           TIFFDirEntry *direntry ,
                                                           uint16 **value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntrySshortArray(TIFF *tif ,
                                                            TIFFDirEntry *direntry ,
                                                            int16 **value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryLongArray(TIFF *tif ,
                                                          TIFFDirEntry *direntry ,
                                                          uint32 **value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntrySlongArray(TIFF *tif ,
                                                           TIFFDirEntry *direntry ,
                                                           int32 **value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryLong8Array(TIFF *tif ,
                                                           TIFFDirEntry *direntry ,
                                                           uint64 **value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntrySlong8Array(TIFF *tif ,
                                                            TIFFDirEntry *direntry ,
                                                            int64 **value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryFloatArray(TIFF *tif ,
                                                           TIFFDirEntry *direntry ,
                                                           float **value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryDoubleArray(TIFF *tif ,
                                                            TIFFDirEntry *direntry ,
                                                            double **value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryIfd8Array(TIFF *tif ,
                                                          TIFFDirEntry *direntry ,
                                                          uint64 **value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryPersampleShort(TIFF *tif ,
                                                               TIFFDirEntry *direntry ,
                                                               uint16 *value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryPersampleDouble(TIFF *tif ,
                                                                TIFFDirEntry *direntry ,
                                                                double *value ) ;
static void TIFFReadDirEntryCheckedByte(TIFF *tif , TIFFDirEntry *direntry ,
                                        uint8 *value ) ;
static void TIFFReadDirEntryCheckedSbyte(TIFF *tif , TIFFDirEntry *direntry ,
                                         int8 *value ) ;
static void TIFFReadDirEntryCheckedShort(TIFF *tif , TIFFDirEntry *direntry ,
                                         uint16 *value ) ;
static void TIFFReadDirEntryCheckedSshort(TIFF *tif , TIFFDirEntry *direntry ,
                                          int16 *value ) ;
static void TIFFReadDirEntryCheckedLong(TIFF *tif , TIFFDirEntry *direntry ,
                                        uint32 *value ) ;
static void TIFFReadDirEntryCheckedSlong(TIFF *tif , TIFFDirEntry *direntry ,
                                         int32 *value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckedLong8(TIFF *tif ,
                                                             TIFFDirEntry *direntry ,
                                                             uint64 *value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckedSlong8(TIFF *tif ,
                                                              TIFFDirEntry *direntry ,
                                                              int64 *value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckedRational(TIFF *tif ,
                                                                TIFFDirEntry *direntry ,
                                                                double *value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckedSrational(TIFF *tif ,
                                                                 TIFFDirEntry *direntry ,
                                                                 double *value ) ;
static void TIFFReadDirEntryCheckedFloat(TIFF *tif , TIFFDirEntry *direntry ,
                                         float *value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckedDouble(TIFF *tif ,
                                                              TIFFDirEntry *direntry ,
                                                              double *value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeByteSbyte(int8 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeByteShort(uint16 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeByteSshort(int16 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeByteLong(uint32 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeByteSlong(int32 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeByteLong8(uint64 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeByteSlong8(int64 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSbyteByte(uint8 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSbyteShort(uint16 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSbyteSshort(int16 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSbyteLong(uint32 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSbyteSlong(int32 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSbyteLong8(uint64 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSbyteSlong8(int64 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeShortSbyte(int8 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeShortSshort(int16 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeShortLong(uint32 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeShortSlong(int32 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeShortLong8(uint64 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeShortSlong8(int64 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSshortShort(uint16 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSshortLong(uint32 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSshortSlong(int32 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSshortLong8(uint64 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSshortSlong8(int64 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLongSbyte(int8 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLongSshort(int16 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLongSlong(int32 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLongLong8(uint64 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLongSlong8(int64 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSlongLong(uint32 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSlongLong8(uint64 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSlongSlong8(int64 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLong8Sbyte(int8 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLong8Sshort(int16 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLong8Slong(int32 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLong8Slong8(int64 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSlong8Long8(uint64 value ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryData(TIFF *tif , uint64 offset ,
                                                     tmsize_t size , void *dest ) ;
static void TIFFReadDirEntryOutputErr(TIFF *tif , enum TIFFReadDirEntryErr err ,
                                      char const   *module ,
                                      char const   *tagname , int recover ) ;
static void TIFFReadDirectoryCheckOrder(TIFF *tif , TIFFDirEntry *dir ,
                                        uint16 dircount ) ;
static TIFFDirEntry *TIFFReadDirectoryFindEntry(TIFF *tif , TIFFDirEntry *dir ,
                                                uint16 dircount , uint16 tagid ) ;
static void TIFFReadDirectoryFindFieldInfo(TIFF *tif , uint16 tagid ,
                                           uint32 *fii ) ;
static int EstimateStripByteCounts(TIFF *tif , TIFFDirEntry *dir ,
                                   uint16 dircount ) ;
static void MissingRequired(TIFF *tif , char const   *tagname ) ;
static int TIFFCheckDirOffset(TIFF *tif , uint64 diroff ) ;
static int CheckDirCount(TIFF *tif , TIFFDirEntry *dir , uint32 count ) ;
static uint16 TIFFFetchDirectory(TIFF *tif , uint64 diroff ,
                                 TIFFDirEntry **pdir , uint64 *nextdiroff ) ;
static int TIFFFetchNormalTag(TIFF *tif , TIFFDirEntry *dp , int recover ) ;
static int TIFFFetchStripThing(TIFF *tif , TIFFDirEntry *dir , uint32 nstrips ,
                               uint64 **lpp ) ;
static int TIFFFetchSubjectDistance(TIFF *tif , TIFFDirEntry *dir ) ;
static void ChopUpSingleUncompressedStrip(TIFF *tif ) ;
static enum TIFFReadDirEntryErr TIFFReadDirEntryByte(TIFF *tif ,
                                                     TIFFDirEntry *direntry ,
                                                     uint8 *value ) 
{ enum TIFFReadDirEntryErr err ;
  int8 m ;
  uint16 m___0 ;
  int16 m___1 ;
  uint32 m___2 ;
  int32 m___3 ;
  uint64 m___4 ;
  int64 m___5 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1504\n");
  fflush(_coverage_fout);
  if (direntry->tdir_count != 1ULL) {
    fprintf(_coverage_fout, "1443\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )1);
  } else {
    fprintf(_coverage_fout, "1444\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "1463\n");
  fflush(_coverage_fout);
  case 1: 
  TIFFReadDirEntryCheckedByte(tif, direntry, value);
  fprintf(_coverage_fout, "1464\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1465\n");
  fflush(_coverage_fout);
  case 6: 
  TIFFReadDirEntryCheckedSbyte(tif, direntry, & m);
  fprintf(_coverage_fout, "1466\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeByteSbyte(m);
  fprintf(_coverage_fout, "1467\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1445\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1446\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1468\n");
  fflush(_coverage_fout);
  *value = (unsigned char )m;
  fprintf(_coverage_fout, "1469\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1470\n");
  fflush(_coverage_fout);
  case 3: 
  TIFFReadDirEntryCheckedShort(tif, direntry, & m___0);
  fprintf(_coverage_fout, "1471\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeByteShort(m___0);
  fprintf(_coverage_fout, "1472\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1447\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1448\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1473\n");
  fflush(_coverage_fout);
  *value = (unsigned char )m___0;
  fprintf(_coverage_fout, "1474\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1475\n");
  fflush(_coverage_fout);
  case 8: 
  TIFFReadDirEntryCheckedSshort(tif, direntry, & m___1);
  fprintf(_coverage_fout, "1476\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeByteSshort(m___1);
  fprintf(_coverage_fout, "1477\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1449\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1450\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1478\n");
  fflush(_coverage_fout);
  *value = (unsigned char )m___1;
  fprintf(_coverage_fout, "1479\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1480\n");
  fflush(_coverage_fout);
  case 4: 
  TIFFReadDirEntryCheckedLong(tif, direntry, & m___2);
  fprintf(_coverage_fout, "1481\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeByteLong(m___2);
  fprintf(_coverage_fout, "1482\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1451\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1452\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1483\n");
  fflush(_coverage_fout);
  *value = (unsigned char )m___2;
  fprintf(_coverage_fout, "1484\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1485\n");
  fflush(_coverage_fout);
  case 9: 
  TIFFReadDirEntryCheckedSlong(tif, direntry, & m___3);
  fprintf(_coverage_fout, "1486\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeByteSlong(m___3);
  fprintf(_coverage_fout, "1487\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1453\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1454\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1488\n");
  fflush(_coverage_fout);
  *value = (unsigned char )m___3;
  fprintf(_coverage_fout, "1489\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1490\n");
  fflush(_coverage_fout);
  case 16: 
  err = TIFFReadDirEntryCheckedLong8(tif, direntry, & m___4);
  fprintf(_coverage_fout, "1491\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1455\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1456\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1492\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeByteLong8(m___4);
  fprintf(_coverage_fout, "1493\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1457\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1458\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1494\n");
  fflush(_coverage_fout);
  *value = (unsigned char )m___4;
  fprintf(_coverage_fout, "1495\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1496\n");
  fflush(_coverage_fout);
  case 17: 
  err = TIFFReadDirEntryCheckedSlong8(tif, direntry, & m___5);
  fprintf(_coverage_fout, "1497\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1459\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1460\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1498\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeByteSlong8(m___5);
  fprintf(_coverage_fout, "1499\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1461\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1462\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1500\n");
  fflush(_coverage_fout);
  *value = (unsigned char )m___5;
  fprintf(_coverage_fout, "1501\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1502\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "1503\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryShort(TIFF *tif ,
                                                      TIFFDirEntry *direntry ,
                                                      uint16 *value ) 
{ enum TIFFReadDirEntryErr err ;
  uint8 m ;
  int8 m___0 ;
  int16 m___1 ;
  uint32 m___2 ;
  int32 m___3 ;
  uint64 m___4 ;
  int64 m___5 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1562\n");
  fflush(_coverage_fout);
  if (direntry->tdir_count != 1ULL) {
    fprintf(_coverage_fout, "1505\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )1);
  } else {
    fprintf(_coverage_fout, "1506\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "1523\n");
  fflush(_coverage_fout);
  case 1: 
  TIFFReadDirEntryCheckedByte(tif, direntry, & m);
  fprintf(_coverage_fout, "1524\n");
  fflush(_coverage_fout);
  *value = (unsigned short )m;
  fprintf(_coverage_fout, "1525\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1526\n");
  fflush(_coverage_fout);
  case 6: 
  TIFFReadDirEntryCheckedSbyte(tif, direntry, & m___0);
  fprintf(_coverage_fout, "1527\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeShortSbyte(m___0);
  fprintf(_coverage_fout, "1528\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1507\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1508\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1529\n");
  fflush(_coverage_fout);
  *value = (unsigned short )m___0;
  fprintf(_coverage_fout, "1530\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1531\n");
  fflush(_coverage_fout);
  case 3: 
  TIFFReadDirEntryCheckedShort(tif, direntry, value);
  fprintf(_coverage_fout, "1532\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1533\n");
  fflush(_coverage_fout);
  case 8: 
  TIFFReadDirEntryCheckedSshort(tif, direntry, & m___1);
  fprintf(_coverage_fout, "1534\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeShortSshort(m___1);
  fprintf(_coverage_fout, "1535\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1509\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1510\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1536\n");
  fflush(_coverage_fout);
  *value = (unsigned short )m___1;
  fprintf(_coverage_fout, "1537\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1538\n");
  fflush(_coverage_fout);
  case 4: 
  TIFFReadDirEntryCheckedLong(tif, direntry, & m___2);
  fprintf(_coverage_fout, "1539\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeShortLong(m___2);
  fprintf(_coverage_fout, "1540\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1511\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1512\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1541\n");
  fflush(_coverage_fout);
  *value = (unsigned short )m___2;
  fprintf(_coverage_fout, "1542\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1543\n");
  fflush(_coverage_fout);
  case 9: 
  TIFFReadDirEntryCheckedSlong(tif, direntry, & m___3);
  fprintf(_coverage_fout, "1544\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeShortSlong(m___3);
  fprintf(_coverage_fout, "1545\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1513\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1514\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1546\n");
  fflush(_coverage_fout);
  *value = (unsigned short )m___3;
  fprintf(_coverage_fout, "1547\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1548\n");
  fflush(_coverage_fout);
  case 16: 
  err = TIFFReadDirEntryCheckedLong8(tif, direntry, & m___4);
  fprintf(_coverage_fout, "1549\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1515\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1516\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1550\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeShortLong8(m___4);
  fprintf(_coverage_fout, "1551\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1517\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1518\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1552\n");
  fflush(_coverage_fout);
  *value = (unsigned short )m___4;
  fprintf(_coverage_fout, "1553\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1554\n");
  fflush(_coverage_fout);
  case 17: 
  err = TIFFReadDirEntryCheckedSlong8(tif, direntry, & m___5);
  fprintf(_coverage_fout, "1555\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1519\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1520\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1556\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeShortSlong8(m___5);
  fprintf(_coverage_fout, "1557\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1521\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1522\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1558\n");
  fflush(_coverage_fout);
  *value = (unsigned short )m___5;
  fprintf(_coverage_fout, "1559\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1560\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "1561\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryLong(TIFF *tif ,
                                                     TIFFDirEntry *direntry ,
                                                     uint32 *value ) 
{ enum TIFFReadDirEntryErr err ;
  uint8 m ;
  int8 m___0 ;
  uint16 m___1 ;
  int16 m___2 ;
  int32 m___3 ;
  uint64 m___4 ;
  int64 m___5 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1616\n");
  fflush(_coverage_fout);
  if (direntry->tdir_count != 1ULL) {
    fprintf(_coverage_fout, "1563\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )1);
  } else {
    fprintf(_coverage_fout, "1564\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "1579\n");
  fflush(_coverage_fout);
  case 1: 
  TIFFReadDirEntryCheckedByte(tif, direntry, & m);
  fprintf(_coverage_fout, "1580\n");
  fflush(_coverage_fout);
  *value = (unsigned int )m;
  fprintf(_coverage_fout, "1581\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1582\n");
  fflush(_coverage_fout);
  case 6: 
  TIFFReadDirEntryCheckedSbyte(tif, direntry, & m___0);
  fprintf(_coverage_fout, "1583\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeLongSbyte(m___0);
  fprintf(_coverage_fout, "1584\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1565\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1566\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1585\n");
  fflush(_coverage_fout);
  *value = (unsigned int )m___0;
  fprintf(_coverage_fout, "1586\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1587\n");
  fflush(_coverage_fout);
  case 3: 
  TIFFReadDirEntryCheckedShort(tif, direntry, & m___1);
  fprintf(_coverage_fout, "1588\n");
  fflush(_coverage_fout);
  *value = (unsigned int )m___1;
  fprintf(_coverage_fout, "1589\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1590\n");
  fflush(_coverage_fout);
  case 8: 
  TIFFReadDirEntryCheckedSshort(tif, direntry, & m___2);
  fprintf(_coverage_fout, "1591\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeLongSshort(m___2);
  fprintf(_coverage_fout, "1592\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1567\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1568\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1593\n");
  fflush(_coverage_fout);
  *value = (unsigned int )m___2;
  fprintf(_coverage_fout, "1594\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1595\n");
  fflush(_coverage_fout);
  case 4: 
  TIFFReadDirEntryCheckedLong(tif, direntry, value);
  fprintf(_coverage_fout, "1596\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1597\n");
  fflush(_coverage_fout);
  case 9: 
  TIFFReadDirEntryCheckedSlong(tif, direntry, & m___3);
  fprintf(_coverage_fout, "1598\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeLongSlong(m___3);
  fprintf(_coverage_fout, "1599\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1569\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1570\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1600\n");
  fflush(_coverage_fout);
  *value = (unsigned int )m___3;
  fprintf(_coverage_fout, "1601\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1602\n");
  fflush(_coverage_fout);
  case 16: 
  err = TIFFReadDirEntryCheckedLong8(tif, direntry, & m___4);
  fprintf(_coverage_fout, "1603\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1571\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1572\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1604\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeLongLong8(m___4);
  fprintf(_coverage_fout, "1605\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1573\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1574\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1606\n");
  fflush(_coverage_fout);
  *value = (unsigned int )m___4;
  fprintf(_coverage_fout, "1607\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1608\n");
  fflush(_coverage_fout);
  case 17: 
  err = TIFFReadDirEntryCheckedSlong8(tif, direntry, & m___5);
  fprintf(_coverage_fout, "1609\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1575\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1576\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1610\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeLongSlong8(m___5);
  fprintf(_coverage_fout, "1611\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1577\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1578\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1612\n");
  fflush(_coverage_fout);
  *value = (unsigned int )m___5;
  fprintf(_coverage_fout, "1613\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1614\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "1615\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryLong8(TIFF *tif ,
                                                      TIFFDirEntry *direntry ,
                                                      uint64 *value ) 
{ enum TIFFReadDirEntryErr err ;
  uint8 m ;
  int8 m___0 ;
  uint16 m___1 ;
  int16 m___2 ;
  uint32 m___3 ;
  int32 m___4 ;
  int64 m___5 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1663\n");
  fflush(_coverage_fout);
  if (direntry->tdir_count != 1ULL) {
    fprintf(_coverage_fout, "1617\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )1);
  } else {
    fprintf(_coverage_fout, "1618\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "1629\n");
  fflush(_coverage_fout);
  case 1: 
  TIFFReadDirEntryCheckedByte(tif, direntry, & m);
  fprintf(_coverage_fout, "1630\n");
  fflush(_coverage_fout);
  *value = (unsigned long long )m;
  fprintf(_coverage_fout, "1631\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1632\n");
  fflush(_coverage_fout);
  case 6: 
  TIFFReadDirEntryCheckedSbyte(tif, direntry, & m___0);
  fprintf(_coverage_fout, "1633\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeLong8Sbyte(m___0);
  fprintf(_coverage_fout, "1634\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1619\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1620\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1635\n");
  fflush(_coverage_fout);
  *value = (unsigned long long )m___0;
  fprintf(_coverage_fout, "1636\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1637\n");
  fflush(_coverage_fout);
  case 3: 
  TIFFReadDirEntryCheckedShort(tif, direntry, & m___1);
  fprintf(_coverage_fout, "1638\n");
  fflush(_coverage_fout);
  *value = (unsigned long long )m___1;
  fprintf(_coverage_fout, "1639\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1640\n");
  fflush(_coverage_fout);
  case 8: 
  TIFFReadDirEntryCheckedSshort(tif, direntry, & m___2);
  fprintf(_coverage_fout, "1641\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeLong8Sshort(m___2);
  fprintf(_coverage_fout, "1642\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1621\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1622\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1643\n");
  fflush(_coverage_fout);
  *value = (unsigned long long )m___2;
  fprintf(_coverage_fout, "1644\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1645\n");
  fflush(_coverage_fout);
  case 4: 
  TIFFReadDirEntryCheckedLong(tif, direntry, & m___3);
  fprintf(_coverage_fout, "1646\n");
  fflush(_coverage_fout);
  *value = (unsigned long long )m___3;
  fprintf(_coverage_fout, "1647\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1648\n");
  fflush(_coverage_fout);
  case 9: 
  TIFFReadDirEntryCheckedSlong(tif, direntry, & m___4);
  fprintf(_coverage_fout, "1649\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeLong8Slong(m___4);
  fprintf(_coverage_fout, "1650\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1623\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1624\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1651\n");
  fflush(_coverage_fout);
  *value = (unsigned long long )m___4;
  fprintf(_coverage_fout, "1652\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1653\n");
  fflush(_coverage_fout);
  case 16: 
  err = TIFFReadDirEntryCheckedLong8(tif, direntry, value);
  fprintf(_coverage_fout, "1654\n");
  fflush(_coverage_fout);
  return (err);
  fprintf(_coverage_fout, "1655\n");
  fflush(_coverage_fout);
  case 17: 
  err = TIFFReadDirEntryCheckedSlong8(tif, direntry, & m___5);
  fprintf(_coverage_fout, "1656\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1625\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1626\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1657\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryCheckRangeLong8Slong8(m___5);
  fprintf(_coverage_fout, "1658\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1627\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1628\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1659\n");
  fflush(_coverage_fout);
  *value = (unsigned long long )m___5;
  fprintf(_coverage_fout, "1660\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1661\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "1662\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryFloat(TIFF *tif ,
                                                      TIFFDirEntry *direntry ,
                                                      float *value ) 
{ enum TIFFReadDirEntryErr err ;
  uint8 m ;
  int8 m___0 ;
  uint16 m___1 ;
  int16 m___2 ;
  uint32 m___3 ;
  int32 m___4 ;
  uint64 m___5 ;
  int64 m___6 ;
  double m___7 ;
  double m___8 ;
  double m___9 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1718\n");
  fflush(_coverage_fout);
  if (direntry->tdir_count != 1ULL) {
    fprintf(_coverage_fout, "1664\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )1);
  } else {
    fprintf(_coverage_fout, "1665\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "1676\n");
  fflush(_coverage_fout);
  case 1: 
  TIFFReadDirEntryCheckedByte(tif, direntry, & m);
  fprintf(_coverage_fout, "1677\n");
  fflush(_coverage_fout);
  *value = (float )m;
  fprintf(_coverage_fout, "1678\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1679\n");
  fflush(_coverage_fout);
  case 6: 
  TIFFReadDirEntryCheckedSbyte(tif, direntry, & m___0);
  fprintf(_coverage_fout, "1680\n");
  fflush(_coverage_fout);
  *value = (float )m___0;
  fprintf(_coverage_fout, "1681\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1682\n");
  fflush(_coverage_fout);
  case 3: 
  TIFFReadDirEntryCheckedShort(tif, direntry, & m___1);
  fprintf(_coverage_fout, "1683\n");
  fflush(_coverage_fout);
  *value = (float )m___1;
  fprintf(_coverage_fout, "1684\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1685\n");
  fflush(_coverage_fout);
  case 8: 
  TIFFReadDirEntryCheckedSshort(tif, direntry, & m___2);
  fprintf(_coverage_fout, "1686\n");
  fflush(_coverage_fout);
  *value = (float )m___2;
  fprintf(_coverage_fout, "1687\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1688\n");
  fflush(_coverage_fout);
  case 4: 
  TIFFReadDirEntryCheckedLong(tif, direntry, & m___3);
  fprintf(_coverage_fout, "1689\n");
  fflush(_coverage_fout);
  *value = (float )m___3;
  fprintf(_coverage_fout, "1690\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1691\n");
  fflush(_coverage_fout);
  case 9: 
  TIFFReadDirEntryCheckedSlong(tif, direntry, & m___4);
  fprintf(_coverage_fout, "1692\n");
  fflush(_coverage_fout);
  *value = (float )m___4;
  fprintf(_coverage_fout, "1693\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1694\n");
  fflush(_coverage_fout);
  case 16: 
  err = TIFFReadDirEntryCheckedLong8(tif, direntry, & m___5);
  fprintf(_coverage_fout, "1695\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1666\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1667\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1696\n");
  fflush(_coverage_fout);
  *value = (float )m___5;
  fprintf(_coverage_fout, "1697\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1698\n");
  fflush(_coverage_fout);
  case 17: 
  err = TIFFReadDirEntryCheckedSlong8(tif, direntry, & m___6);
  fprintf(_coverage_fout, "1699\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1668\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1669\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1700\n");
  fflush(_coverage_fout);
  *value = (float )m___6;
  fprintf(_coverage_fout, "1701\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1702\n");
  fflush(_coverage_fout);
  case 5: 
  err = TIFFReadDirEntryCheckedRational(tif, direntry, & m___7);
  fprintf(_coverage_fout, "1703\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1670\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1671\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1704\n");
  fflush(_coverage_fout);
  *value = (float )m___7;
  fprintf(_coverage_fout, "1705\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1706\n");
  fflush(_coverage_fout);
  case 10: 
  err = TIFFReadDirEntryCheckedSrational(tif, direntry, & m___8);
  fprintf(_coverage_fout, "1707\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1672\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1673\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1708\n");
  fflush(_coverage_fout);
  *value = (float )m___8;
  fprintf(_coverage_fout, "1709\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1710\n");
  fflush(_coverage_fout);
  case 11: 
  TIFFReadDirEntryCheckedFloat(tif, direntry, value);
  fprintf(_coverage_fout, "1711\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1712\n");
  fflush(_coverage_fout);
  case 12: 
  err = TIFFReadDirEntryCheckedDouble(tif, direntry, & m___9);
  fprintf(_coverage_fout, "1713\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1674\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1675\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1714\n");
  fflush(_coverage_fout);
  *value = (float )m___9;
  fprintf(_coverage_fout, "1715\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1716\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "1717\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryDouble(TIFF *tif ,
                                                       TIFFDirEntry *direntry ,
                                                       double *value ) 
{ enum TIFFReadDirEntryErr err ;
  uint8 m ;
  int8 m___0 ;
  uint16 m___1 ;
  int16 m___2 ;
  uint32 m___3 ;
  int32 m___4 ;
  uint64 m___5 ;
  int64 m___6 ;
  float m___7 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1762\n");
  fflush(_coverage_fout);
  if (direntry->tdir_count != 1ULL) {
    fprintf(_coverage_fout, "1719\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )1);
  } else {
    fprintf(_coverage_fout, "1720\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "1725\n");
  fflush(_coverage_fout);
  case 1: 
  TIFFReadDirEntryCheckedByte(tif, direntry, & m);
  fprintf(_coverage_fout, "1726\n");
  fflush(_coverage_fout);
  *value = (double )m;
  fprintf(_coverage_fout, "1727\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1728\n");
  fflush(_coverage_fout);
  case 6: 
  TIFFReadDirEntryCheckedSbyte(tif, direntry, & m___0);
  fprintf(_coverage_fout, "1729\n");
  fflush(_coverage_fout);
  *value = (double )m___0;
  fprintf(_coverage_fout, "1730\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1731\n");
  fflush(_coverage_fout);
  case 3: 
  TIFFReadDirEntryCheckedShort(tif, direntry, & m___1);
  fprintf(_coverage_fout, "1732\n");
  fflush(_coverage_fout);
  *value = (double )m___1;
  fprintf(_coverage_fout, "1733\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1734\n");
  fflush(_coverage_fout);
  case 8: 
  TIFFReadDirEntryCheckedSshort(tif, direntry, & m___2);
  fprintf(_coverage_fout, "1735\n");
  fflush(_coverage_fout);
  *value = (double )m___2;
  fprintf(_coverage_fout, "1736\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1737\n");
  fflush(_coverage_fout);
  case 4: 
  TIFFReadDirEntryCheckedLong(tif, direntry, & m___3);
  fprintf(_coverage_fout, "1738\n");
  fflush(_coverage_fout);
  *value = (double )m___3;
  fprintf(_coverage_fout, "1739\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1740\n");
  fflush(_coverage_fout);
  case 9: 
  TIFFReadDirEntryCheckedSlong(tif, direntry, & m___4);
  fprintf(_coverage_fout, "1741\n");
  fflush(_coverage_fout);
  *value = (double )m___4;
  fprintf(_coverage_fout, "1742\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1743\n");
  fflush(_coverage_fout);
  case 16: 
  err = TIFFReadDirEntryCheckedLong8(tif, direntry, & m___5);
  fprintf(_coverage_fout, "1744\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1721\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1722\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1745\n");
  fflush(_coverage_fout);
  *value = (double )m___5;
  fprintf(_coverage_fout, "1746\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1747\n");
  fflush(_coverage_fout);
  case 17: 
  err = TIFFReadDirEntryCheckedSlong8(tif, direntry, & m___6);
  fprintf(_coverage_fout, "1748\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1723\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1724\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1749\n");
  fflush(_coverage_fout);
  *value = (double )m___6;
  fprintf(_coverage_fout, "1750\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1751\n");
  fflush(_coverage_fout);
  case 5: 
  err = TIFFReadDirEntryCheckedRational(tif, direntry, value);
  fprintf(_coverage_fout, "1752\n");
  fflush(_coverage_fout);
  return (err);
  fprintf(_coverage_fout, "1753\n");
  fflush(_coverage_fout);
  case 10: 
  err = TIFFReadDirEntryCheckedSrational(tif, direntry, value);
  fprintf(_coverage_fout, "1754\n");
  fflush(_coverage_fout);
  return (err);
  fprintf(_coverage_fout, "1755\n");
  fflush(_coverage_fout);
  case 11: 
  TIFFReadDirEntryCheckedFloat(tif, direntry, & m___7);
  fprintf(_coverage_fout, "1756\n");
  fflush(_coverage_fout);
  *value = (double )m___7;
  fprintf(_coverage_fout, "1757\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1758\n");
  fflush(_coverage_fout);
  case 12: 
  err = TIFFReadDirEntryCheckedDouble(tif, direntry, value);
  fprintf(_coverage_fout, "1759\n");
  fflush(_coverage_fout);
  return (err);
  fprintf(_coverage_fout, "1760\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "1761\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryIfd8(TIFF *tif ,
                                                     TIFFDirEntry *direntry ,
                                                     uint64 *value ) 
{ enum TIFFReadDirEntryErr err ;
  uint32 m ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1772\n");
  fflush(_coverage_fout);
  if (direntry->tdir_count != 1ULL) {
    fprintf(_coverage_fout, "1763\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )1);
  } else {
    fprintf(_coverage_fout, "1764\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "1765\n");
  fflush(_coverage_fout);
  case 4: 
  case 13: 
  TIFFReadDirEntryCheckedLong(tif, direntry, & m);
  fprintf(_coverage_fout, "1766\n");
  fflush(_coverage_fout);
  *value = (unsigned long long )m;
  fprintf(_coverage_fout, "1767\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1768\n");
  fflush(_coverage_fout);
  case 16: 
  case 18: 
  err = TIFFReadDirEntryCheckedLong8(tif, direntry, value);
  fprintf(_coverage_fout, "1769\n");
  fflush(_coverage_fout);
  return (err);
  fprintf(_coverage_fout, "1770\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "1771\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryArray(TIFF *tif ,
                                                      TIFFDirEntry *direntry ,
                                                      uint32 *count ,
                                                      uint32 desttypesize ,
                                                      void **value ) 
{ int typesize ;
  uint32 datasize ;
  void *data ;
  enum TIFFReadDirEntryErr err ;
  uint32 offset ;
  enum TIFFReadDirEntryErr err___0 ;
  uint64 offset___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1809\n");
  fflush(_coverage_fout);
  typesize = TIFFDataWidth((enum __anonenum_TIFFDataType_21 )direntry->tdir_type);
  fprintf(_coverage_fout, "1810\n");
  fflush(_coverage_fout);
  if (direntry->tdir_count == 0ULL) {
    fprintf(_coverage_fout, "1773\n");
    fflush(_coverage_fout);
    *value = (void *)0;
    fprintf(_coverage_fout, "1774\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  } else {
    fprintf(_coverage_fout, "1778\n");
    fflush(_coverage_fout);
    if (typesize == 0) {
      fprintf(_coverage_fout, "1775\n");
      fflush(_coverage_fout);
      *value = (void *)0;
      fprintf(_coverage_fout, "1776\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )0);
    } else {
      fprintf(_coverage_fout, "1777\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "1811\n");
  fflush(_coverage_fout);
  if ((unsigned long long )(4194304 / typesize) < direntry->tdir_count) {
    fprintf(_coverage_fout, "1779\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )6);
  } else {
    fprintf(_coverage_fout, "1780\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1812\n");
  fflush(_coverage_fout);
  if ((unsigned long long )(4194304U / desttypesize) < direntry->tdir_count) {
    fprintf(_coverage_fout, "1781\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )6);
  } else {
    fprintf(_coverage_fout, "1782\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1813\n");
  fflush(_coverage_fout);
  *count = (unsigned int )direntry->tdir_count;
  fprintf(_coverage_fout, "1814\n");
  fflush(_coverage_fout);
  datasize = *count * (uint32 )typesize;
  fprintf(_coverage_fout, "1815\n");
  fflush(_coverage_fout);
  if ((long )datasize > 0L) {
    fprintf(_coverage_fout, "1783\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1784\n");
    fflush(_coverage_fout);
    __assert_fail("(tmsize_t)datasize>0", "tif_dirread.c", 732U,
                  "TIFFReadDirEntryArray");
  }
  fprintf(_coverage_fout, "1816\n");
  fflush(_coverage_fout);
  data = _TIFFmalloc((long )datasize);
  fprintf(_coverage_fout, "1817\n");
  fflush(_coverage_fout);
  if ((unsigned int )data == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1785\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )7);
  } else {
    fprintf(_coverage_fout, "1786\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1818\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "1797\n");
    fflush(_coverage_fout);
    if (datasize <= 4U) {
      fprintf(_coverage_fout, "1787\n");
      fflush(_coverage_fout);
      _TIFFmemcpy(data, (void const   *)(& direntry->tdir_offset),
                  (long )datasize);
    } else {
      fprintf(_coverage_fout, "1793\n");
      fflush(_coverage_fout);
      offset = *((uint32 *)(& direntry->tdir_offset));
      fprintf(_coverage_fout, "1794\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "1788\n");
        fflush(_coverage_fout);
        TIFFSwabLong(& offset);
      } else {
        fprintf(_coverage_fout, "1789\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1795\n");
      fflush(_coverage_fout);
      err = TIFFReadDirEntryData(tif, (unsigned long long )offset,
                                 (long )datasize, data);
      fprintf(_coverage_fout, "1796\n");
      fflush(_coverage_fout);
      if ((unsigned int )err != 0U) {
        fprintf(_coverage_fout, "1790\n");
        fflush(_coverage_fout);
        _TIFFfree(data);
        fprintf(_coverage_fout, "1791\n");
        fflush(_coverage_fout);
        return (err);
      } else {
        fprintf(_coverage_fout, "1792\n");
        fflush(_coverage_fout);

      }
    }
  } else {
    fprintf(_coverage_fout, "1808\n");
    fflush(_coverage_fout);
    if (datasize <= 8U) {
      fprintf(_coverage_fout, "1798\n");
      fflush(_coverage_fout);
      _TIFFmemcpy(data, (void const   *)(& direntry->tdir_offset),
                  (long )datasize);
    } else {
      fprintf(_coverage_fout, "1804\n");
      fflush(_coverage_fout);
      offset___0 = direntry->tdir_offset;
      fprintf(_coverage_fout, "1805\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "1799\n");
        fflush(_coverage_fout);
        TIFFSwabLong8(& offset___0);
      } else {
        fprintf(_coverage_fout, "1800\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1806\n");
      fflush(_coverage_fout);
      err___0 = TIFFReadDirEntryData(tif, offset___0, (long )datasize, data);
      fprintf(_coverage_fout, "1807\n");
      fflush(_coverage_fout);
      if ((unsigned int )err___0 != 0U) {
        fprintf(_coverage_fout, "1801\n");
        fflush(_coverage_fout);
        _TIFFfree(data);
        fprintf(_coverage_fout, "1802\n");
        fflush(_coverage_fout);
        return (err___0);
      } else {
        fprintf(_coverage_fout, "1803\n");
        fflush(_coverage_fout);

      }
    }
  }
  fprintf(_coverage_fout, "1819\n");
  fflush(_coverage_fout);
  *value = data;
  fprintf(_coverage_fout, "1820\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryByteArray(TIFF *tif ,
                                                          TIFFDirEntry *direntry ,
                                                          uint8 **value ) 
{ enum TIFFReadDirEntryErr err ;
  uint32 count ;
  void *origdata ;
  uint8 *data ;
  int8 *m ;
  uint32 n ;
  void *tmp ;
  uint16 *ma ;
  uint8 *mb ;
  uint32 n___0 ;
  uint8 *tmp___0 ;
  uint16 *tmp___1 ;
  int16 *ma___0 ;
  uint8 *mb___0 ;
  uint32 n___1 ;
  uint8 *tmp___2 ;
  int16 *tmp___3 ;
  uint32 *ma___1 ;
  uint8 *mb___1 ;
  uint32 n___2 ;
  uint8 *tmp___4 ;
  uint32 *tmp___5 ;
  int32 *ma___2 ;
  uint8 *mb___2 ;
  uint32 n___3 ;
  uint8 *tmp___6 ;
  int32 *tmp___7 ;
  uint64 *ma___3 ;
  uint8 *mb___3 ;
  uint32 n___4 ;
  uint8 *tmp___8 ;
  uint64 *tmp___9 ;
  int64 *ma___4 ;
  uint8 *mb___4 ;
  uint32 n___5 ;
  uint8 *tmp___10 ;
  int64 *tmp___11 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  switch ((int )direntry->tdir_type) {
  case 2: 
  case 7: 
  case 1: 
  case 6: 
  case 3: 
  case 8: 
  case 4: 
  case 9: 
  case 16: 
  case 17: 
  break;
  fprintf(_coverage_fout, "1821\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "1822\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
  fprintf(_coverage_fout, "1959\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryArray(tif, direntry, & count, 1U, & origdata);
  fprintf(_coverage_fout, "1960\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1823\n");
    fflush(_coverage_fout);
    *value = (uint8 *)0;
    fprintf(_coverage_fout, "1824\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1828\n");
    fflush(_coverage_fout);
    if ((unsigned int )origdata == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "1825\n");
      fflush(_coverage_fout);
      *value = (uint8 *)0;
      fprintf(_coverage_fout, "1826\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "1827\n");
      fflush(_coverage_fout);

    }
  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "1838\n");
  fflush(_coverage_fout);
  case 2: 
  case 7: 
  case 1: 
  *value = (uint8 *)origdata;
  fprintf(_coverage_fout, "1839\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1840\n");
  fflush(_coverage_fout);
  case 6: 
  m = (int8 *)origdata;
  fprintf(_coverage_fout, "1841\n");
  fflush(_coverage_fout);
  n = 0U;
  fprintf(_coverage_fout, "1842\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1833\n");
    fflush(_coverage_fout);
    if (n < count) {
      fprintf(_coverage_fout, "1829\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1834\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeByteSbyte(*m);
    fprintf(_coverage_fout, "1835\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      fprintf(_coverage_fout, "1830\n");
      fflush(_coverage_fout);
      _TIFFfree(origdata);
      fprintf(_coverage_fout, "1831\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "1832\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1836\n");
    fflush(_coverage_fout);
    m ++;
    fprintf(_coverage_fout, "1837\n");
    fflush(_coverage_fout);
    n ++;
  }
  fprintf(_coverage_fout, "1843\n");
  fflush(_coverage_fout);
  *value = (uint8 *)origdata;
  fprintf(_coverage_fout, "1844\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  }
  fprintf(_coverage_fout, "1961\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )count);
  fprintf(_coverage_fout, "1962\n");
  fflush(_coverage_fout);
  data = (uint8 *)tmp;
  fprintf(_coverage_fout, "1963\n");
  fflush(_coverage_fout);
  if ((unsigned int )data == (unsigned int )((uint8 *)0)) {
    fprintf(_coverage_fout, "1845\n");
    fflush(_coverage_fout);
    _TIFFfree(origdata);
    fprintf(_coverage_fout, "1846\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )7);
  } else {
    fprintf(_coverage_fout, "1847\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "1932\n");
  fflush(_coverage_fout);
  case 3: 
  ma = (uint16 *)origdata;
  fprintf(_coverage_fout, "1933\n");
  fflush(_coverage_fout);
  mb = data;
  fprintf(_coverage_fout, "1934\n");
  fflush(_coverage_fout);
  n___0 = 0U;
  fprintf(_coverage_fout, "1935\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1852\n");
    fflush(_coverage_fout);
    if (n___0 < count) {
      fprintf(_coverage_fout, "1848\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1853\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "1849\n");
      fflush(_coverage_fout);
      TIFFSwabShort(ma);
    } else {
      fprintf(_coverage_fout, "1850\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1854\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeByteShort(*ma);
    fprintf(_coverage_fout, "1855\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "1851\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1856\n");
    fflush(_coverage_fout);
    tmp___0 = mb;
    fprintf(_coverage_fout, "1857\n");
    fflush(_coverage_fout);
    mb ++;
    fprintf(_coverage_fout, "1858\n");
    fflush(_coverage_fout);
    tmp___1 = ma;
    fprintf(_coverage_fout, "1859\n");
    fflush(_coverage_fout);
    ma ++;
    fprintf(_coverage_fout, "1860\n");
    fflush(_coverage_fout);
    *tmp___0 = (unsigned char )*tmp___1;
    fprintf(_coverage_fout, "1861\n");
    fflush(_coverage_fout);
    n___0 ++;
  }
  break;
  fprintf(_coverage_fout, "1936\n");
  fflush(_coverage_fout);
  case 8: 
  ma___0 = (int16 *)origdata;
  fprintf(_coverage_fout, "1937\n");
  fflush(_coverage_fout);
  mb___0 = data;
  fprintf(_coverage_fout, "1938\n");
  fflush(_coverage_fout);
  n___1 = 0U;
  fprintf(_coverage_fout, "1939\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1866\n");
    fflush(_coverage_fout);
    if (n___1 < count) {
      fprintf(_coverage_fout, "1862\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1867\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "1863\n");
      fflush(_coverage_fout);
      TIFFSwabShort((uint16 *)ma___0);
    } else {
      fprintf(_coverage_fout, "1864\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1868\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeByteSshort(*ma___0);
    fprintf(_coverage_fout, "1869\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "1865\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1870\n");
    fflush(_coverage_fout);
    tmp___2 = mb___0;
    fprintf(_coverage_fout, "1871\n");
    fflush(_coverage_fout);
    mb___0 ++;
    fprintf(_coverage_fout, "1872\n");
    fflush(_coverage_fout);
    tmp___3 = ma___0;
    fprintf(_coverage_fout, "1873\n");
    fflush(_coverage_fout);
    ma___0 ++;
    fprintf(_coverage_fout, "1874\n");
    fflush(_coverage_fout);
    *tmp___2 = (unsigned char )*tmp___3;
    fprintf(_coverage_fout, "1875\n");
    fflush(_coverage_fout);
    n___1 ++;
  }
  break;
  fprintf(_coverage_fout, "1940\n");
  fflush(_coverage_fout);
  case 4: 
  ma___1 = (uint32 *)origdata;
  fprintf(_coverage_fout, "1941\n");
  fflush(_coverage_fout);
  mb___1 = data;
  fprintf(_coverage_fout, "1942\n");
  fflush(_coverage_fout);
  n___2 = 0U;
  fprintf(_coverage_fout, "1943\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1880\n");
    fflush(_coverage_fout);
    if (n___2 < count) {
      fprintf(_coverage_fout, "1876\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1881\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "1877\n");
      fflush(_coverage_fout);
      TIFFSwabLong(ma___1);
    } else {
      fprintf(_coverage_fout, "1878\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1882\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeByteLong(*ma___1);
    fprintf(_coverage_fout, "1883\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "1879\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1884\n");
    fflush(_coverage_fout);
    tmp___4 = mb___1;
    fprintf(_coverage_fout, "1885\n");
    fflush(_coverage_fout);
    mb___1 ++;
    fprintf(_coverage_fout, "1886\n");
    fflush(_coverage_fout);
    tmp___5 = ma___1;
    fprintf(_coverage_fout, "1887\n");
    fflush(_coverage_fout);
    ma___1 ++;
    fprintf(_coverage_fout, "1888\n");
    fflush(_coverage_fout);
    *tmp___4 = (unsigned char )*tmp___5;
    fprintf(_coverage_fout, "1889\n");
    fflush(_coverage_fout);
    n___2 ++;
  }
  break;
  fprintf(_coverage_fout, "1944\n");
  fflush(_coverage_fout);
  case 9: 
  ma___2 = (int32 *)origdata;
  fprintf(_coverage_fout, "1945\n");
  fflush(_coverage_fout);
  mb___2 = data;
  fprintf(_coverage_fout, "1946\n");
  fflush(_coverage_fout);
  n___3 = 0U;
  fprintf(_coverage_fout, "1947\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1894\n");
    fflush(_coverage_fout);
    if (n___3 < count) {
      fprintf(_coverage_fout, "1890\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1895\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "1891\n");
      fflush(_coverage_fout);
      TIFFSwabLong((uint32 *)ma___2);
    } else {
      fprintf(_coverage_fout, "1892\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1896\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeByteSlong(*ma___2);
    fprintf(_coverage_fout, "1897\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "1893\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1898\n");
    fflush(_coverage_fout);
    tmp___6 = mb___2;
    fprintf(_coverage_fout, "1899\n");
    fflush(_coverage_fout);
    mb___2 ++;
    fprintf(_coverage_fout, "1900\n");
    fflush(_coverage_fout);
    tmp___7 = ma___2;
    fprintf(_coverage_fout, "1901\n");
    fflush(_coverage_fout);
    ma___2 ++;
    fprintf(_coverage_fout, "1902\n");
    fflush(_coverage_fout);
    *tmp___6 = (unsigned char )*tmp___7;
    fprintf(_coverage_fout, "1903\n");
    fflush(_coverage_fout);
    n___3 ++;
  }
  break;
  fprintf(_coverage_fout, "1948\n");
  fflush(_coverage_fout);
  case 16: 
  ma___3 = (uint64 *)origdata;
  fprintf(_coverage_fout, "1949\n");
  fflush(_coverage_fout);
  mb___3 = data;
  fprintf(_coverage_fout, "1950\n");
  fflush(_coverage_fout);
  n___4 = 0U;
  fprintf(_coverage_fout, "1951\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1908\n");
    fflush(_coverage_fout);
    if (n___4 < count) {
      fprintf(_coverage_fout, "1904\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1909\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "1905\n");
      fflush(_coverage_fout);
      TIFFSwabLong8(ma___3);
    } else {
      fprintf(_coverage_fout, "1906\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1910\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeByteLong8(*ma___3);
    fprintf(_coverage_fout, "1911\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "1907\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1912\n");
    fflush(_coverage_fout);
    tmp___8 = mb___3;
    fprintf(_coverage_fout, "1913\n");
    fflush(_coverage_fout);
    mb___3 ++;
    fprintf(_coverage_fout, "1914\n");
    fflush(_coverage_fout);
    tmp___9 = ma___3;
    fprintf(_coverage_fout, "1915\n");
    fflush(_coverage_fout);
    ma___3 ++;
    fprintf(_coverage_fout, "1916\n");
    fflush(_coverage_fout);
    *tmp___8 = (unsigned char )*tmp___9;
    fprintf(_coverage_fout, "1917\n");
    fflush(_coverage_fout);
    n___4 ++;
  }
  break;
  fprintf(_coverage_fout, "1952\n");
  fflush(_coverage_fout);
  case 17: 
  ma___4 = (int64 *)origdata;
  fprintf(_coverage_fout, "1953\n");
  fflush(_coverage_fout);
  mb___4 = data;
  fprintf(_coverage_fout, "1954\n");
  fflush(_coverage_fout);
  n___5 = 0U;
  fprintf(_coverage_fout, "1955\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1922\n");
    fflush(_coverage_fout);
    if (n___5 < count) {
      fprintf(_coverage_fout, "1918\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1923\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "1919\n");
      fflush(_coverage_fout);
      TIFFSwabLong8((uint64 *)ma___4);
    } else {
      fprintf(_coverage_fout, "1920\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1924\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeByteSlong8(*ma___4);
    fprintf(_coverage_fout, "1925\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "1921\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1926\n");
    fflush(_coverage_fout);
    tmp___10 = mb___4;
    fprintf(_coverage_fout, "1927\n");
    fflush(_coverage_fout);
    mb___4 ++;
    fprintf(_coverage_fout, "1928\n");
    fflush(_coverage_fout);
    tmp___11 = ma___4;
    fprintf(_coverage_fout, "1929\n");
    fflush(_coverage_fout);
    ma___4 ++;
    fprintf(_coverage_fout, "1930\n");
    fflush(_coverage_fout);
    *tmp___10 = (unsigned char )*tmp___11;
    fprintf(_coverage_fout, "1931\n");
    fflush(_coverage_fout);
    n___5 ++;
  }
  break;
  }
  fprintf(_coverage_fout, "1964\n");
  fflush(_coverage_fout);
  _TIFFfree(origdata);
  fprintf(_coverage_fout, "1965\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1956\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)data);
    fprintf(_coverage_fout, "1957\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1958\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1966\n");
  fflush(_coverage_fout);
  *value = data;
  fprintf(_coverage_fout, "1967\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntrySbyteArray(TIFF *tif ,
                                                           TIFFDirEntry *direntry ,
                                                           int8 **value ) 
{ enum TIFFReadDirEntryErr err ;
  uint32 count ;
  void *origdata ;
  int8 *data ;
  uint8 *m ;
  uint32 n ;
  void *tmp ;
  uint16 *ma ;
  int8 *mb ;
  uint32 n___0 ;
  int8 *tmp___0 ;
  uint16 *tmp___1 ;
  int16 *ma___0 ;
  int8 *mb___0 ;
  uint32 n___1 ;
  int8 *tmp___2 ;
  int16 *tmp___3 ;
  uint32 *ma___1 ;
  int8 *mb___1 ;
  uint32 n___2 ;
  int8 *tmp___4 ;
  uint32 *tmp___5 ;
  int32 *ma___2 ;
  int8 *mb___2 ;
  uint32 n___3 ;
  int8 *tmp___6 ;
  int32 *tmp___7 ;
  uint64 *ma___3 ;
  int8 *mb___3 ;
  uint32 n___4 ;
  int8 *tmp___8 ;
  uint64 *tmp___9 ;
  int64 *ma___4 ;
  int8 *mb___4 ;
  uint32 n___5 ;
  int8 *tmp___10 ;
  int64 *tmp___11 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  switch ((int )direntry->tdir_type) {
  case 7: 
  case 1: 
  case 6: 
  case 3: 
  case 8: 
  case 4: 
  case 9: 
  case 16: 
  case 17: 
  break;
  fprintf(_coverage_fout, "1968\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "1969\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
  fprintf(_coverage_fout, "2106\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryArray(tif, direntry, & count, 1U, & origdata);
  fprintf(_coverage_fout, "2107\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "1970\n");
    fflush(_coverage_fout);
    *value = (int8 *)0;
    fprintf(_coverage_fout, "1971\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "1975\n");
    fflush(_coverage_fout);
    if ((unsigned int )origdata == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "1972\n");
      fflush(_coverage_fout);
      *value = (int8 *)0;
      fprintf(_coverage_fout, "1973\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "1974\n");
      fflush(_coverage_fout);

    }
  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "1985\n");
  fflush(_coverage_fout);
  case 7: 
  case 1: 
  m = (uint8 *)origdata;
  fprintf(_coverage_fout, "1986\n");
  fflush(_coverage_fout);
  n = 0U;
  fprintf(_coverage_fout, "1987\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1980\n");
    fflush(_coverage_fout);
    if (n < count) {
      fprintf(_coverage_fout, "1976\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1981\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeSbyteByte(*m);
    fprintf(_coverage_fout, "1982\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      fprintf(_coverage_fout, "1977\n");
      fflush(_coverage_fout);
      _TIFFfree(origdata);
      fprintf(_coverage_fout, "1978\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "1979\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1983\n");
    fflush(_coverage_fout);
    m ++;
    fprintf(_coverage_fout, "1984\n");
    fflush(_coverage_fout);
    n ++;
  }
  fprintf(_coverage_fout, "1988\n");
  fflush(_coverage_fout);
  *value = (int8 *)origdata;
  fprintf(_coverage_fout, "1989\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "1990\n");
  fflush(_coverage_fout);
  case 6: 
  *value = (int8 *)origdata;
  fprintf(_coverage_fout, "1991\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  }
  fprintf(_coverage_fout, "2108\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )count);
  fprintf(_coverage_fout, "2109\n");
  fflush(_coverage_fout);
  data = (int8 *)tmp;
  fprintf(_coverage_fout, "2110\n");
  fflush(_coverage_fout);
  if ((unsigned int )data == (unsigned int )((int8 *)0)) {
    fprintf(_coverage_fout, "1992\n");
    fflush(_coverage_fout);
    _TIFFfree(origdata);
    fprintf(_coverage_fout, "1993\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )7);
  } else {
    fprintf(_coverage_fout, "1994\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "2079\n");
  fflush(_coverage_fout);
  case 3: 
  ma = (uint16 *)origdata;
  fprintf(_coverage_fout, "2080\n");
  fflush(_coverage_fout);
  mb = data;
  fprintf(_coverage_fout, "2081\n");
  fflush(_coverage_fout);
  n___0 = 0U;
  fprintf(_coverage_fout, "2082\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1999\n");
    fflush(_coverage_fout);
    if (n___0 < count) {
      fprintf(_coverage_fout, "1995\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2000\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "1996\n");
      fflush(_coverage_fout);
      TIFFSwabShort(ma);
    } else {
      fprintf(_coverage_fout, "1997\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2001\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeSbyteShort(*ma);
    fprintf(_coverage_fout, "2002\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "1998\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2003\n");
    fflush(_coverage_fout);
    tmp___0 = mb;
    fprintf(_coverage_fout, "2004\n");
    fflush(_coverage_fout);
    mb ++;
    fprintf(_coverage_fout, "2005\n");
    fflush(_coverage_fout);
    tmp___1 = ma;
    fprintf(_coverage_fout, "2006\n");
    fflush(_coverage_fout);
    ma ++;
    fprintf(_coverage_fout, "2007\n");
    fflush(_coverage_fout);
    *tmp___0 = (signed char )*tmp___1;
    fprintf(_coverage_fout, "2008\n");
    fflush(_coverage_fout);
    n___0 ++;
  }
  break;
  fprintf(_coverage_fout, "2083\n");
  fflush(_coverage_fout);
  case 8: 
  ma___0 = (int16 *)origdata;
  fprintf(_coverage_fout, "2084\n");
  fflush(_coverage_fout);
  mb___0 = data;
  fprintf(_coverage_fout, "2085\n");
  fflush(_coverage_fout);
  n___1 = 0U;
  fprintf(_coverage_fout, "2086\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2013\n");
    fflush(_coverage_fout);
    if (n___1 < count) {
      fprintf(_coverage_fout, "2009\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2014\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2010\n");
      fflush(_coverage_fout);
      TIFFSwabShort((uint16 *)ma___0);
    } else {
      fprintf(_coverage_fout, "2011\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2015\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeSbyteSshort(*ma___0);
    fprintf(_coverage_fout, "2016\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2012\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2017\n");
    fflush(_coverage_fout);
    tmp___2 = mb___0;
    fprintf(_coverage_fout, "2018\n");
    fflush(_coverage_fout);
    mb___0 ++;
    fprintf(_coverage_fout, "2019\n");
    fflush(_coverage_fout);
    tmp___3 = ma___0;
    fprintf(_coverage_fout, "2020\n");
    fflush(_coverage_fout);
    ma___0 ++;
    fprintf(_coverage_fout, "2021\n");
    fflush(_coverage_fout);
    *tmp___2 = (signed char )*tmp___3;
    fprintf(_coverage_fout, "2022\n");
    fflush(_coverage_fout);
    n___1 ++;
  }
  break;
  fprintf(_coverage_fout, "2087\n");
  fflush(_coverage_fout);
  case 4: 
  ma___1 = (uint32 *)origdata;
  fprintf(_coverage_fout, "2088\n");
  fflush(_coverage_fout);
  mb___1 = data;
  fprintf(_coverage_fout, "2089\n");
  fflush(_coverage_fout);
  n___2 = 0U;
  fprintf(_coverage_fout, "2090\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2027\n");
    fflush(_coverage_fout);
    if (n___2 < count) {
      fprintf(_coverage_fout, "2023\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2028\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2024\n");
      fflush(_coverage_fout);
      TIFFSwabLong(ma___1);
    } else {
      fprintf(_coverage_fout, "2025\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2029\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeSbyteLong(*ma___1);
    fprintf(_coverage_fout, "2030\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2026\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2031\n");
    fflush(_coverage_fout);
    tmp___4 = mb___1;
    fprintf(_coverage_fout, "2032\n");
    fflush(_coverage_fout);
    mb___1 ++;
    fprintf(_coverage_fout, "2033\n");
    fflush(_coverage_fout);
    tmp___5 = ma___1;
    fprintf(_coverage_fout, "2034\n");
    fflush(_coverage_fout);
    ma___1 ++;
    fprintf(_coverage_fout, "2035\n");
    fflush(_coverage_fout);
    *tmp___4 = (signed char )*tmp___5;
    fprintf(_coverage_fout, "2036\n");
    fflush(_coverage_fout);
    n___2 ++;
  }
  break;
  fprintf(_coverage_fout, "2091\n");
  fflush(_coverage_fout);
  case 9: 
  ma___2 = (int32 *)origdata;
  fprintf(_coverage_fout, "2092\n");
  fflush(_coverage_fout);
  mb___2 = data;
  fprintf(_coverage_fout, "2093\n");
  fflush(_coverage_fout);
  n___3 = 0U;
  fprintf(_coverage_fout, "2094\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2041\n");
    fflush(_coverage_fout);
    if (n___3 < count) {
      fprintf(_coverage_fout, "2037\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2042\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2038\n");
      fflush(_coverage_fout);
      TIFFSwabLong((uint32 *)ma___2);
    } else {
      fprintf(_coverage_fout, "2039\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2043\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeSbyteSlong(*ma___2);
    fprintf(_coverage_fout, "2044\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2040\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2045\n");
    fflush(_coverage_fout);
    tmp___6 = mb___2;
    fprintf(_coverage_fout, "2046\n");
    fflush(_coverage_fout);
    mb___2 ++;
    fprintf(_coverage_fout, "2047\n");
    fflush(_coverage_fout);
    tmp___7 = ma___2;
    fprintf(_coverage_fout, "2048\n");
    fflush(_coverage_fout);
    ma___2 ++;
    fprintf(_coverage_fout, "2049\n");
    fflush(_coverage_fout);
    *tmp___6 = (signed char )*tmp___7;
    fprintf(_coverage_fout, "2050\n");
    fflush(_coverage_fout);
    n___3 ++;
  }
  break;
  fprintf(_coverage_fout, "2095\n");
  fflush(_coverage_fout);
  case 16: 
  ma___3 = (uint64 *)origdata;
  fprintf(_coverage_fout, "2096\n");
  fflush(_coverage_fout);
  mb___3 = data;
  fprintf(_coverage_fout, "2097\n");
  fflush(_coverage_fout);
  n___4 = 0U;
  fprintf(_coverage_fout, "2098\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2055\n");
    fflush(_coverage_fout);
    if (n___4 < count) {
      fprintf(_coverage_fout, "2051\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2056\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2052\n");
      fflush(_coverage_fout);
      TIFFSwabLong8(ma___3);
    } else {
      fprintf(_coverage_fout, "2053\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2057\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeSbyteLong8(*ma___3);
    fprintf(_coverage_fout, "2058\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2054\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2059\n");
    fflush(_coverage_fout);
    tmp___8 = mb___3;
    fprintf(_coverage_fout, "2060\n");
    fflush(_coverage_fout);
    mb___3 ++;
    fprintf(_coverage_fout, "2061\n");
    fflush(_coverage_fout);
    tmp___9 = ma___3;
    fprintf(_coverage_fout, "2062\n");
    fflush(_coverage_fout);
    ma___3 ++;
    fprintf(_coverage_fout, "2063\n");
    fflush(_coverage_fout);
    *tmp___8 = (signed char )*tmp___9;
    fprintf(_coverage_fout, "2064\n");
    fflush(_coverage_fout);
    n___4 ++;
  }
  break;
  fprintf(_coverage_fout, "2099\n");
  fflush(_coverage_fout);
  case 17: 
  ma___4 = (int64 *)origdata;
  fprintf(_coverage_fout, "2100\n");
  fflush(_coverage_fout);
  mb___4 = data;
  fprintf(_coverage_fout, "2101\n");
  fflush(_coverage_fout);
  n___5 = 0U;
  fprintf(_coverage_fout, "2102\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2069\n");
    fflush(_coverage_fout);
    if (n___5 < count) {
      fprintf(_coverage_fout, "2065\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2070\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2066\n");
      fflush(_coverage_fout);
      TIFFSwabLong8((uint64 *)ma___4);
    } else {
      fprintf(_coverage_fout, "2067\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2071\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeSbyteSlong8(*ma___4);
    fprintf(_coverage_fout, "2072\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2068\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2073\n");
    fflush(_coverage_fout);
    tmp___10 = mb___4;
    fprintf(_coverage_fout, "2074\n");
    fflush(_coverage_fout);
    mb___4 ++;
    fprintf(_coverage_fout, "2075\n");
    fflush(_coverage_fout);
    tmp___11 = ma___4;
    fprintf(_coverage_fout, "2076\n");
    fflush(_coverage_fout);
    ma___4 ++;
    fprintf(_coverage_fout, "2077\n");
    fflush(_coverage_fout);
    *tmp___10 = (signed char )*tmp___11;
    fprintf(_coverage_fout, "2078\n");
    fflush(_coverage_fout);
    n___5 ++;
  }
  break;
  }
  fprintf(_coverage_fout, "2111\n");
  fflush(_coverage_fout);
  _TIFFfree(origdata);
  fprintf(_coverage_fout, "2112\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "2103\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)data);
    fprintf(_coverage_fout, "2104\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "2105\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2113\n");
  fflush(_coverage_fout);
  *value = data;
  fprintf(_coverage_fout, "2114\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryShortArray(TIFF *tif ,
                                                           TIFFDirEntry *direntry ,
                                                           uint16 **value ) 
{ enum TIFFReadDirEntryErr err ;
  uint32 count ;
  void *origdata ;
  uint16 *data ;
  int16 *m ;
  uint32 n ;
  void *tmp ;
  uint8 *ma ;
  uint16 *mb ;
  uint32 n___0 ;
  uint16 *tmp___0 ;
  uint8 *tmp___1 ;
  int8 *ma___0 ;
  uint16 *mb___0 ;
  uint32 n___1 ;
  uint16 *tmp___2 ;
  int8 *tmp___3 ;
  uint32 *ma___1 ;
  uint16 *mb___1 ;
  uint32 n___2 ;
  uint16 *tmp___4 ;
  uint32 *tmp___5 ;
  int32 *ma___2 ;
  uint16 *mb___2 ;
  uint32 n___3 ;
  uint16 *tmp___6 ;
  int32 *tmp___7 ;
  uint64 *ma___3 ;
  uint16 *mb___3 ;
  uint32 n___4 ;
  uint16 *tmp___8 ;
  uint64 *tmp___9 ;
  int64 *ma___4 ;
  uint16 *mb___4 ;
  uint32 n___5 ;
  uint16 *tmp___10 ;
  int64 *tmp___11 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  switch ((int )direntry->tdir_type) {
  case 1: 
  case 6: 
  case 3: 
  case 8: 
  case 4: 
  case 9: 
  case 16: 
  case 17: 
  break;
  fprintf(_coverage_fout, "2115\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "2116\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
  fprintf(_coverage_fout, "2250\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryArray(tif, direntry, & count, 2U, & origdata);
  fprintf(_coverage_fout, "2251\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "2117\n");
    fflush(_coverage_fout);
    *value = (uint16 *)0;
    fprintf(_coverage_fout, "2118\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "2122\n");
    fflush(_coverage_fout);
    if ((unsigned int )origdata == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "2119\n");
      fflush(_coverage_fout);
      *value = (uint16 *)0;
      fprintf(_coverage_fout, "2120\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "2121\n");
      fflush(_coverage_fout);

    }
  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "2137\n");
  fflush(_coverage_fout);
  case 3: 
  *value = (uint16 *)origdata;
  fprintf(_coverage_fout, "2138\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "2123\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfShort(*value, (long )count);
  } else {
    fprintf(_coverage_fout, "2124\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2139\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "2140\n");
  fflush(_coverage_fout);
  case 8: 
  m = (int16 *)origdata;
  fprintf(_coverage_fout, "2141\n");
  fflush(_coverage_fout);
  n = 0U;
  fprintf(_coverage_fout, "2142\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2131\n");
    fflush(_coverage_fout);
    if (n < count) {
      fprintf(_coverage_fout, "2125\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2132\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2126\n");
      fflush(_coverage_fout);
      TIFFSwabShort((uint16 *)m);
    } else {
      fprintf(_coverage_fout, "2127\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2133\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeShortSshort(*m);
    fprintf(_coverage_fout, "2134\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      fprintf(_coverage_fout, "2128\n");
      fflush(_coverage_fout);
      _TIFFfree(origdata);
      fprintf(_coverage_fout, "2129\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "2130\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2135\n");
    fflush(_coverage_fout);
    m ++;
    fprintf(_coverage_fout, "2136\n");
    fflush(_coverage_fout);
    n ++;
  }
  fprintf(_coverage_fout, "2143\n");
  fflush(_coverage_fout);
  *value = (uint16 *)origdata;
  fprintf(_coverage_fout, "2144\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  }
  fprintf(_coverage_fout, "2252\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )(count * 2U));
  fprintf(_coverage_fout, "2253\n");
  fflush(_coverage_fout);
  data = (uint16 *)tmp;
  fprintf(_coverage_fout, "2254\n");
  fflush(_coverage_fout);
  if ((unsigned int )data == (unsigned int )((uint16 *)0)) {
    fprintf(_coverage_fout, "2145\n");
    fflush(_coverage_fout);
    _TIFFfree(origdata);
    fprintf(_coverage_fout, "2146\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )7);
  } else {
    fprintf(_coverage_fout, "2147\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "2223\n");
  fflush(_coverage_fout);
  case 1: 
  ma = (uint8 *)origdata;
  fprintf(_coverage_fout, "2224\n");
  fflush(_coverage_fout);
  mb = data;
  fprintf(_coverage_fout, "2225\n");
  fflush(_coverage_fout);
  n___0 = 0U;
  fprintf(_coverage_fout, "2226\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2149\n");
    fflush(_coverage_fout);
    if (n___0 < count) {
      fprintf(_coverage_fout, "2148\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2150\n");
    fflush(_coverage_fout);
    tmp___0 = mb;
    fprintf(_coverage_fout, "2151\n");
    fflush(_coverage_fout);
    mb ++;
    fprintf(_coverage_fout, "2152\n");
    fflush(_coverage_fout);
    tmp___1 = ma;
    fprintf(_coverage_fout, "2153\n");
    fflush(_coverage_fout);
    ma ++;
    fprintf(_coverage_fout, "2154\n");
    fflush(_coverage_fout);
    *tmp___0 = (unsigned short )*tmp___1;
    fprintf(_coverage_fout, "2155\n");
    fflush(_coverage_fout);
    n___0 ++;
  }
  break;
  fprintf(_coverage_fout, "2227\n");
  fflush(_coverage_fout);
  case 6: 
  ma___0 = (int8 *)origdata;
  fprintf(_coverage_fout, "2228\n");
  fflush(_coverage_fout);
  mb___0 = data;
  fprintf(_coverage_fout, "2229\n");
  fflush(_coverage_fout);
  n___1 = 0U;
  fprintf(_coverage_fout, "2230\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2158\n");
    fflush(_coverage_fout);
    if (n___1 < count) {
      fprintf(_coverage_fout, "2156\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2159\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeShortSbyte(*ma___0);
    fprintf(_coverage_fout, "2160\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2157\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2161\n");
    fflush(_coverage_fout);
    tmp___2 = mb___0;
    fprintf(_coverage_fout, "2162\n");
    fflush(_coverage_fout);
    mb___0 ++;
    fprintf(_coverage_fout, "2163\n");
    fflush(_coverage_fout);
    tmp___3 = ma___0;
    fprintf(_coverage_fout, "2164\n");
    fflush(_coverage_fout);
    ma___0 ++;
    fprintf(_coverage_fout, "2165\n");
    fflush(_coverage_fout);
    *tmp___2 = (unsigned short )*tmp___3;
    fprintf(_coverage_fout, "2166\n");
    fflush(_coverage_fout);
    n___1 ++;
  }
  break;
  fprintf(_coverage_fout, "2231\n");
  fflush(_coverage_fout);
  case 4: 
  ma___1 = (uint32 *)origdata;
  fprintf(_coverage_fout, "2232\n");
  fflush(_coverage_fout);
  mb___1 = data;
  fprintf(_coverage_fout, "2233\n");
  fflush(_coverage_fout);
  n___2 = 0U;
  fprintf(_coverage_fout, "2234\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2171\n");
    fflush(_coverage_fout);
    if (n___2 < count) {
      fprintf(_coverage_fout, "2167\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2172\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2168\n");
      fflush(_coverage_fout);
      TIFFSwabLong(ma___1);
    } else {
      fprintf(_coverage_fout, "2169\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2173\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeShortLong(*ma___1);
    fprintf(_coverage_fout, "2174\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2170\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2175\n");
    fflush(_coverage_fout);
    tmp___4 = mb___1;
    fprintf(_coverage_fout, "2176\n");
    fflush(_coverage_fout);
    mb___1 ++;
    fprintf(_coverage_fout, "2177\n");
    fflush(_coverage_fout);
    tmp___5 = ma___1;
    fprintf(_coverage_fout, "2178\n");
    fflush(_coverage_fout);
    ma___1 ++;
    fprintf(_coverage_fout, "2179\n");
    fflush(_coverage_fout);
    *tmp___4 = (unsigned short )*tmp___5;
    fprintf(_coverage_fout, "2180\n");
    fflush(_coverage_fout);
    n___2 ++;
  }
  break;
  fprintf(_coverage_fout, "2235\n");
  fflush(_coverage_fout);
  case 9: 
  ma___2 = (int32 *)origdata;
  fprintf(_coverage_fout, "2236\n");
  fflush(_coverage_fout);
  mb___2 = data;
  fprintf(_coverage_fout, "2237\n");
  fflush(_coverage_fout);
  n___3 = 0U;
  fprintf(_coverage_fout, "2238\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2185\n");
    fflush(_coverage_fout);
    if (n___3 < count) {
      fprintf(_coverage_fout, "2181\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2186\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2182\n");
      fflush(_coverage_fout);
      TIFFSwabLong((uint32 *)ma___2);
    } else {
      fprintf(_coverage_fout, "2183\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2187\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeShortSlong(*ma___2);
    fprintf(_coverage_fout, "2188\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2184\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2189\n");
    fflush(_coverage_fout);
    tmp___6 = mb___2;
    fprintf(_coverage_fout, "2190\n");
    fflush(_coverage_fout);
    mb___2 ++;
    fprintf(_coverage_fout, "2191\n");
    fflush(_coverage_fout);
    tmp___7 = ma___2;
    fprintf(_coverage_fout, "2192\n");
    fflush(_coverage_fout);
    ma___2 ++;
    fprintf(_coverage_fout, "2193\n");
    fflush(_coverage_fout);
    *tmp___6 = (unsigned short )*tmp___7;
    fprintf(_coverage_fout, "2194\n");
    fflush(_coverage_fout);
    n___3 ++;
  }
  break;
  fprintf(_coverage_fout, "2239\n");
  fflush(_coverage_fout);
  case 16: 
  ma___3 = (uint64 *)origdata;
  fprintf(_coverage_fout, "2240\n");
  fflush(_coverage_fout);
  mb___3 = data;
  fprintf(_coverage_fout, "2241\n");
  fflush(_coverage_fout);
  n___4 = 0U;
  fprintf(_coverage_fout, "2242\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2199\n");
    fflush(_coverage_fout);
    if (n___4 < count) {
      fprintf(_coverage_fout, "2195\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2200\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2196\n");
      fflush(_coverage_fout);
      TIFFSwabLong8(ma___3);
    } else {
      fprintf(_coverage_fout, "2197\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2201\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeShortLong8(*ma___3);
    fprintf(_coverage_fout, "2202\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2198\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2203\n");
    fflush(_coverage_fout);
    tmp___8 = mb___3;
    fprintf(_coverage_fout, "2204\n");
    fflush(_coverage_fout);
    mb___3 ++;
    fprintf(_coverage_fout, "2205\n");
    fflush(_coverage_fout);
    tmp___9 = ma___3;
    fprintf(_coverage_fout, "2206\n");
    fflush(_coverage_fout);
    ma___3 ++;
    fprintf(_coverage_fout, "2207\n");
    fflush(_coverage_fout);
    *tmp___8 = (unsigned short )*tmp___9;
    fprintf(_coverage_fout, "2208\n");
    fflush(_coverage_fout);
    n___4 ++;
  }
  break;
  fprintf(_coverage_fout, "2243\n");
  fflush(_coverage_fout);
  case 17: 
  ma___4 = (int64 *)origdata;
  fprintf(_coverage_fout, "2244\n");
  fflush(_coverage_fout);
  mb___4 = data;
  fprintf(_coverage_fout, "2245\n");
  fflush(_coverage_fout);
  n___5 = 0U;
  fprintf(_coverage_fout, "2246\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2213\n");
    fflush(_coverage_fout);
    if (n___5 < count) {
      fprintf(_coverage_fout, "2209\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2214\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2210\n");
      fflush(_coverage_fout);
      TIFFSwabLong8((uint64 *)ma___4);
    } else {
      fprintf(_coverage_fout, "2211\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2215\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeShortSlong8(*ma___4);
    fprintf(_coverage_fout, "2216\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2212\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2217\n");
    fflush(_coverage_fout);
    tmp___10 = mb___4;
    fprintf(_coverage_fout, "2218\n");
    fflush(_coverage_fout);
    mb___4 ++;
    fprintf(_coverage_fout, "2219\n");
    fflush(_coverage_fout);
    tmp___11 = ma___4;
    fprintf(_coverage_fout, "2220\n");
    fflush(_coverage_fout);
    ma___4 ++;
    fprintf(_coverage_fout, "2221\n");
    fflush(_coverage_fout);
    *tmp___10 = (unsigned short )*tmp___11;
    fprintf(_coverage_fout, "2222\n");
    fflush(_coverage_fout);
    n___5 ++;
  }
  break;
  }
  fprintf(_coverage_fout, "2255\n");
  fflush(_coverage_fout);
  _TIFFfree(origdata);
  fprintf(_coverage_fout, "2256\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "2247\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)data);
    fprintf(_coverage_fout, "2248\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "2249\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2257\n");
  fflush(_coverage_fout);
  *value = data;
  fprintf(_coverage_fout, "2258\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntrySshortArray(TIFF *tif ,
                                                            TIFFDirEntry *direntry ,
                                                            int16 **value ) 
{ enum TIFFReadDirEntryErr err ;
  uint32 count ;
  void *origdata ;
  int16 *data ;
  uint16 *m ;
  uint32 n ;
  void *tmp ;
  uint8 *ma ;
  int16 *mb ;
  uint32 n___0 ;
  int16 *tmp___0 ;
  uint8 *tmp___1 ;
  int8 *ma___0 ;
  int16 *mb___0 ;
  uint32 n___1 ;
  int16 *tmp___2 ;
  int8 *tmp___3 ;
  uint32 *ma___1 ;
  int16 *mb___1 ;
  uint32 n___2 ;
  int16 *tmp___4 ;
  uint32 *tmp___5 ;
  int32 *ma___2 ;
  int16 *mb___2 ;
  uint32 n___3 ;
  int16 *tmp___6 ;
  int32 *tmp___7 ;
  uint64 *ma___3 ;
  int16 *mb___3 ;
  uint32 n___4 ;
  int16 *tmp___8 ;
  uint64 *tmp___9 ;
  int64 *ma___4 ;
  int16 *mb___4 ;
  uint32 n___5 ;
  int16 *tmp___10 ;
  int64 *tmp___11 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  switch ((int )direntry->tdir_type) {
  case 1: 
  case 6: 
  case 3: 
  case 8: 
  case 4: 
  case 9: 
  case 16: 
  case 17: 
  break;
  fprintf(_coverage_fout, "2259\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "2260\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
  fprintf(_coverage_fout, "2391\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryArray(tif, direntry, & count, 2U, & origdata);
  fprintf(_coverage_fout, "2392\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "2261\n");
    fflush(_coverage_fout);
    *value = (int16 *)0;
    fprintf(_coverage_fout, "2262\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "2266\n");
    fflush(_coverage_fout);
    if ((unsigned int )origdata == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "2263\n");
      fflush(_coverage_fout);
      *value = (int16 *)0;
      fprintf(_coverage_fout, "2264\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "2265\n");
      fflush(_coverage_fout);

    }
  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "2281\n");
  fflush(_coverage_fout);
  case 3: 
  m = (uint16 *)origdata;
  fprintf(_coverage_fout, "2282\n");
  fflush(_coverage_fout);
  n = 0U;
  fprintf(_coverage_fout, "2283\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2273\n");
    fflush(_coverage_fout);
    if (n < count) {
      fprintf(_coverage_fout, "2267\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2274\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2268\n");
      fflush(_coverage_fout);
      TIFFSwabShort(m);
    } else {
      fprintf(_coverage_fout, "2269\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2275\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeSshortShort(*m);
    fprintf(_coverage_fout, "2276\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      fprintf(_coverage_fout, "2270\n");
      fflush(_coverage_fout);
      _TIFFfree(origdata);
      fprintf(_coverage_fout, "2271\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "2272\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2277\n");
    fflush(_coverage_fout);
    m ++;
    fprintf(_coverage_fout, "2278\n");
    fflush(_coverage_fout);
    n ++;
  }
  fprintf(_coverage_fout, "2284\n");
  fflush(_coverage_fout);
  *value = (int16 *)origdata;
  fprintf(_coverage_fout, "2285\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "2286\n");
  fflush(_coverage_fout);
  case 8: 
  *value = (int16 *)origdata;
  fprintf(_coverage_fout, "2287\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "2279\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfShort((uint16 *)*value, (long )count);
  } else {
    fprintf(_coverage_fout, "2280\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2288\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  }
  fprintf(_coverage_fout, "2393\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )(count * 2U));
  fprintf(_coverage_fout, "2394\n");
  fflush(_coverage_fout);
  data = (int16 *)tmp;
  fprintf(_coverage_fout, "2395\n");
  fflush(_coverage_fout);
  if ((unsigned int )data == (unsigned int )((int16 *)0)) {
    fprintf(_coverage_fout, "2289\n");
    fflush(_coverage_fout);
    _TIFFfree(origdata);
    fprintf(_coverage_fout, "2290\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )7);
  } else {
    fprintf(_coverage_fout, "2291\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "2364\n");
  fflush(_coverage_fout);
  case 1: 
  ma = (uint8 *)origdata;
  fprintf(_coverage_fout, "2365\n");
  fflush(_coverage_fout);
  mb = data;
  fprintf(_coverage_fout, "2366\n");
  fflush(_coverage_fout);
  n___0 = 0U;
  fprintf(_coverage_fout, "2367\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2293\n");
    fflush(_coverage_fout);
    if (n___0 < count) {
      fprintf(_coverage_fout, "2292\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2294\n");
    fflush(_coverage_fout);
    tmp___0 = mb;
    fprintf(_coverage_fout, "2295\n");
    fflush(_coverage_fout);
    mb ++;
    fprintf(_coverage_fout, "2296\n");
    fflush(_coverage_fout);
    tmp___1 = ma;
    fprintf(_coverage_fout, "2297\n");
    fflush(_coverage_fout);
    ma ++;
    fprintf(_coverage_fout, "2298\n");
    fflush(_coverage_fout);
    *tmp___0 = (short )*tmp___1;
    fprintf(_coverage_fout, "2299\n");
    fflush(_coverage_fout);
    n___0 ++;
  }
  break;
  fprintf(_coverage_fout, "2368\n");
  fflush(_coverage_fout);
  case 6: 
  ma___0 = (int8 *)origdata;
  fprintf(_coverage_fout, "2369\n");
  fflush(_coverage_fout);
  mb___0 = data;
  fprintf(_coverage_fout, "2370\n");
  fflush(_coverage_fout);
  n___1 = 0U;
  fprintf(_coverage_fout, "2371\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2301\n");
    fflush(_coverage_fout);
    if (n___1 < count) {
      fprintf(_coverage_fout, "2300\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2302\n");
    fflush(_coverage_fout);
    tmp___2 = mb___0;
    fprintf(_coverage_fout, "2303\n");
    fflush(_coverage_fout);
    mb___0 ++;
    fprintf(_coverage_fout, "2304\n");
    fflush(_coverage_fout);
    tmp___3 = ma___0;
    fprintf(_coverage_fout, "2305\n");
    fflush(_coverage_fout);
    ma___0 ++;
    fprintf(_coverage_fout, "2306\n");
    fflush(_coverage_fout);
    *tmp___2 = (short )*tmp___3;
    fprintf(_coverage_fout, "2307\n");
    fflush(_coverage_fout);
    n___1 ++;
  }
  break;
  fprintf(_coverage_fout, "2372\n");
  fflush(_coverage_fout);
  case 4: 
  ma___1 = (uint32 *)origdata;
  fprintf(_coverage_fout, "2373\n");
  fflush(_coverage_fout);
  mb___1 = data;
  fprintf(_coverage_fout, "2374\n");
  fflush(_coverage_fout);
  n___2 = 0U;
  fprintf(_coverage_fout, "2375\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2312\n");
    fflush(_coverage_fout);
    if (n___2 < count) {
      fprintf(_coverage_fout, "2308\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2313\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2309\n");
      fflush(_coverage_fout);
      TIFFSwabLong(ma___1);
    } else {
      fprintf(_coverage_fout, "2310\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2314\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeSshortLong(*ma___1);
    fprintf(_coverage_fout, "2315\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2311\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2316\n");
    fflush(_coverage_fout);
    tmp___4 = mb___1;
    fprintf(_coverage_fout, "2317\n");
    fflush(_coverage_fout);
    mb___1 ++;
    fprintf(_coverage_fout, "2318\n");
    fflush(_coverage_fout);
    tmp___5 = ma___1;
    fprintf(_coverage_fout, "2319\n");
    fflush(_coverage_fout);
    ma___1 ++;
    fprintf(_coverage_fout, "2320\n");
    fflush(_coverage_fout);
    *tmp___4 = (short )*tmp___5;
    fprintf(_coverage_fout, "2321\n");
    fflush(_coverage_fout);
    n___2 ++;
  }
  break;
  fprintf(_coverage_fout, "2376\n");
  fflush(_coverage_fout);
  case 9: 
  ma___2 = (int32 *)origdata;
  fprintf(_coverage_fout, "2377\n");
  fflush(_coverage_fout);
  mb___2 = data;
  fprintf(_coverage_fout, "2378\n");
  fflush(_coverage_fout);
  n___3 = 0U;
  fprintf(_coverage_fout, "2379\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2326\n");
    fflush(_coverage_fout);
    if (n___3 < count) {
      fprintf(_coverage_fout, "2322\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2327\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2323\n");
      fflush(_coverage_fout);
      TIFFSwabLong((uint32 *)ma___2);
    } else {
      fprintf(_coverage_fout, "2324\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2328\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeSshortSlong(*ma___2);
    fprintf(_coverage_fout, "2329\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2325\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2330\n");
    fflush(_coverage_fout);
    tmp___6 = mb___2;
    fprintf(_coverage_fout, "2331\n");
    fflush(_coverage_fout);
    mb___2 ++;
    fprintf(_coverage_fout, "2332\n");
    fflush(_coverage_fout);
    tmp___7 = ma___2;
    fprintf(_coverage_fout, "2333\n");
    fflush(_coverage_fout);
    ma___2 ++;
    fprintf(_coverage_fout, "2334\n");
    fflush(_coverage_fout);
    *tmp___6 = (short )*tmp___7;
    fprintf(_coverage_fout, "2335\n");
    fflush(_coverage_fout);
    n___3 ++;
  }
  break;
  fprintf(_coverage_fout, "2380\n");
  fflush(_coverage_fout);
  case 16: 
  ma___3 = (uint64 *)origdata;
  fprintf(_coverage_fout, "2381\n");
  fflush(_coverage_fout);
  mb___3 = data;
  fprintf(_coverage_fout, "2382\n");
  fflush(_coverage_fout);
  n___4 = 0U;
  fprintf(_coverage_fout, "2383\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2340\n");
    fflush(_coverage_fout);
    if (n___4 < count) {
      fprintf(_coverage_fout, "2336\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2341\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2337\n");
      fflush(_coverage_fout);
      TIFFSwabLong8(ma___3);
    } else {
      fprintf(_coverage_fout, "2338\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2342\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeSshortLong8(*ma___3);
    fprintf(_coverage_fout, "2343\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2339\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2344\n");
    fflush(_coverage_fout);
    tmp___8 = mb___3;
    fprintf(_coverage_fout, "2345\n");
    fflush(_coverage_fout);
    mb___3 ++;
    fprintf(_coverage_fout, "2346\n");
    fflush(_coverage_fout);
    tmp___9 = ma___3;
    fprintf(_coverage_fout, "2347\n");
    fflush(_coverage_fout);
    ma___3 ++;
    fprintf(_coverage_fout, "2348\n");
    fflush(_coverage_fout);
    *tmp___8 = (short )*tmp___9;
    fprintf(_coverage_fout, "2349\n");
    fflush(_coverage_fout);
    n___4 ++;
  }
  break;
  fprintf(_coverage_fout, "2384\n");
  fflush(_coverage_fout);
  case 17: 
  ma___4 = (int64 *)origdata;
  fprintf(_coverage_fout, "2385\n");
  fflush(_coverage_fout);
  mb___4 = data;
  fprintf(_coverage_fout, "2386\n");
  fflush(_coverage_fout);
  n___5 = 0U;
  fprintf(_coverage_fout, "2387\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2354\n");
    fflush(_coverage_fout);
    if (n___5 < count) {
      fprintf(_coverage_fout, "2350\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2355\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2351\n");
      fflush(_coverage_fout);
      TIFFSwabLong8((uint64 *)ma___4);
    } else {
      fprintf(_coverage_fout, "2352\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2356\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeSshortSlong8(*ma___4);
    fprintf(_coverage_fout, "2357\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2353\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2358\n");
    fflush(_coverage_fout);
    tmp___10 = mb___4;
    fprintf(_coverage_fout, "2359\n");
    fflush(_coverage_fout);
    mb___4 ++;
    fprintf(_coverage_fout, "2360\n");
    fflush(_coverage_fout);
    tmp___11 = ma___4;
    fprintf(_coverage_fout, "2361\n");
    fflush(_coverage_fout);
    ma___4 ++;
    fprintf(_coverage_fout, "2362\n");
    fflush(_coverage_fout);
    *tmp___10 = (short )*tmp___11;
    fprintf(_coverage_fout, "2363\n");
    fflush(_coverage_fout);
    n___5 ++;
  }
  break;
  }
  fprintf(_coverage_fout, "2396\n");
  fflush(_coverage_fout);
  _TIFFfree(origdata);
  fprintf(_coverage_fout, "2397\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "2388\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)data);
    fprintf(_coverage_fout, "2389\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "2390\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2398\n");
  fflush(_coverage_fout);
  *value = data;
  fprintf(_coverage_fout, "2399\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryLongArray(TIFF *tif ,
                                                          TIFFDirEntry *direntry ,
                                                          uint32 **value ) 
{ enum TIFFReadDirEntryErr err ;
  uint32 count ;
  void *origdata ;
  uint32 *data ;
  int32 *m ;
  uint32 n ;
  void *tmp ;
  uint8 *ma ;
  uint32 *mb ;
  uint32 n___0 ;
  uint32 *tmp___0 ;
  uint8 *tmp___1 ;
  int8 *ma___0 ;
  uint32 *mb___0 ;
  uint32 n___1 ;
  uint32 *tmp___2 ;
  int8 *tmp___3 ;
  uint16 *ma___1 ;
  uint32 *mb___1 ;
  uint32 n___2 ;
  uint32 *tmp___4 ;
  uint16 *tmp___5 ;
  int16 *ma___2 ;
  uint32 *mb___2 ;
  uint32 n___3 ;
  uint32 *tmp___6 ;
  int16 *tmp___7 ;
  uint64 *ma___3 ;
  uint32 *mb___3 ;
  uint32 n___4 ;
  uint32 *tmp___8 ;
  uint64 *tmp___9 ;
  int64 *ma___4 ;
  uint32 *mb___4 ;
  uint32 n___5 ;
  uint32 *tmp___10 ;
  int64 *tmp___11 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  switch ((int )direntry->tdir_type) {
  case 1: 
  case 6: 
  case 3: 
  case 8: 
  case 4: 
  case 9: 
  case 16: 
  case 17: 
  break;
  fprintf(_coverage_fout, "2400\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "2401\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
  fprintf(_coverage_fout, "2532\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryArray(tif, direntry, & count, 4U, & origdata);
  fprintf(_coverage_fout, "2533\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "2402\n");
    fflush(_coverage_fout);
    *value = (uint32 *)0;
    fprintf(_coverage_fout, "2403\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "2407\n");
    fflush(_coverage_fout);
    if ((unsigned int )origdata == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "2404\n");
      fflush(_coverage_fout);
      *value = (uint32 *)0;
      fprintf(_coverage_fout, "2405\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "2406\n");
      fflush(_coverage_fout);

    }
  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "2422\n");
  fflush(_coverage_fout);
  case 4: 
  *value = (uint32 *)origdata;
  fprintf(_coverage_fout, "2423\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "2408\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong(*value, (long )count);
  } else {
    fprintf(_coverage_fout, "2409\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2424\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "2425\n");
  fflush(_coverage_fout);
  case 9: 
  m = (int32 *)origdata;
  fprintf(_coverage_fout, "2426\n");
  fflush(_coverage_fout);
  n = 0U;
  fprintf(_coverage_fout, "2427\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2416\n");
    fflush(_coverage_fout);
    if (n < count) {
      fprintf(_coverage_fout, "2410\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2417\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2411\n");
      fflush(_coverage_fout);
      TIFFSwabLong((uint32 *)m);
    } else {
      fprintf(_coverage_fout, "2412\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2418\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeLongSlong(*m);
    fprintf(_coverage_fout, "2419\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      fprintf(_coverage_fout, "2413\n");
      fflush(_coverage_fout);
      _TIFFfree(origdata);
      fprintf(_coverage_fout, "2414\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "2415\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2420\n");
    fflush(_coverage_fout);
    m ++;
    fprintf(_coverage_fout, "2421\n");
    fflush(_coverage_fout);
    n ++;
  }
  fprintf(_coverage_fout, "2428\n");
  fflush(_coverage_fout);
  *value = (uint32 *)origdata;
  fprintf(_coverage_fout, "2429\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  }
  fprintf(_coverage_fout, "2534\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )(count * 4U));
  fprintf(_coverage_fout, "2535\n");
  fflush(_coverage_fout);
  data = (uint32 *)tmp;
  fprintf(_coverage_fout, "2536\n");
  fflush(_coverage_fout);
  if ((unsigned int )data == (unsigned int )((uint32 *)0)) {
    fprintf(_coverage_fout, "2430\n");
    fflush(_coverage_fout);
    _TIFFfree(origdata);
    fprintf(_coverage_fout, "2431\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )7);
  } else {
    fprintf(_coverage_fout, "2432\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "2505\n");
  fflush(_coverage_fout);
  case 1: 
  ma = (uint8 *)origdata;
  fprintf(_coverage_fout, "2506\n");
  fflush(_coverage_fout);
  mb = data;
  fprintf(_coverage_fout, "2507\n");
  fflush(_coverage_fout);
  n___0 = 0U;
  fprintf(_coverage_fout, "2508\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2434\n");
    fflush(_coverage_fout);
    if (n___0 < count) {
      fprintf(_coverage_fout, "2433\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2435\n");
    fflush(_coverage_fout);
    tmp___0 = mb;
    fprintf(_coverage_fout, "2436\n");
    fflush(_coverage_fout);
    mb ++;
    fprintf(_coverage_fout, "2437\n");
    fflush(_coverage_fout);
    tmp___1 = ma;
    fprintf(_coverage_fout, "2438\n");
    fflush(_coverage_fout);
    ma ++;
    fprintf(_coverage_fout, "2439\n");
    fflush(_coverage_fout);
    *tmp___0 = (unsigned int )*tmp___1;
    fprintf(_coverage_fout, "2440\n");
    fflush(_coverage_fout);
    n___0 ++;
  }
  break;
  fprintf(_coverage_fout, "2509\n");
  fflush(_coverage_fout);
  case 6: 
  ma___0 = (int8 *)origdata;
  fprintf(_coverage_fout, "2510\n");
  fflush(_coverage_fout);
  mb___0 = data;
  fprintf(_coverage_fout, "2511\n");
  fflush(_coverage_fout);
  n___1 = 0U;
  fprintf(_coverage_fout, "2512\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2443\n");
    fflush(_coverage_fout);
    if (n___1 < count) {
      fprintf(_coverage_fout, "2441\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2444\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeLongSbyte(*ma___0);
    fprintf(_coverage_fout, "2445\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2442\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2446\n");
    fflush(_coverage_fout);
    tmp___2 = mb___0;
    fprintf(_coverage_fout, "2447\n");
    fflush(_coverage_fout);
    mb___0 ++;
    fprintf(_coverage_fout, "2448\n");
    fflush(_coverage_fout);
    tmp___3 = ma___0;
    fprintf(_coverage_fout, "2449\n");
    fflush(_coverage_fout);
    ma___0 ++;
    fprintf(_coverage_fout, "2450\n");
    fflush(_coverage_fout);
    *tmp___2 = (unsigned int )*tmp___3;
    fprintf(_coverage_fout, "2451\n");
    fflush(_coverage_fout);
    n___1 ++;
  }
  break;
  fprintf(_coverage_fout, "2513\n");
  fflush(_coverage_fout);
  case 3: 
  ma___1 = (uint16 *)origdata;
  fprintf(_coverage_fout, "2514\n");
  fflush(_coverage_fout);
  mb___1 = data;
  fprintf(_coverage_fout, "2515\n");
  fflush(_coverage_fout);
  n___2 = 0U;
  fprintf(_coverage_fout, "2516\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2455\n");
    fflush(_coverage_fout);
    if (n___2 < count) {
      fprintf(_coverage_fout, "2452\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2456\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2453\n");
      fflush(_coverage_fout);
      TIFFSwabShort(ma___1);
    } else {
      fprintf(_coverage_fout, "2454\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2457\n");
    fflush(_coverage_fout);
    tmp___4 = mb___1;
    fprintf(_coverage_fout, "2458\n");
    fflush(_coverage_fout);
    mb___1 ++;
    fprintf(_coverage_fout, "2459\n");
    fflush(_coverage_fout);
    tmp___5 = ma___1;
    fprintf(_coverage_fout, "2460\n");
    fflush(_coverage_fout);
    ma___1 ++;
    fprintf(_coverage_fout, "2461\n");
    fflush(_coverage_fout);
    *tmp___4 = (unsigned int )*tmp___5;
    fprintf(_coverage_fout, "2462\n");
    fflush(_coverage_fout);
    n___2 ++;
  }
  break;
  fprintf(_coverage_fout, "2517\n");
  fflush(_coverage_fout);
  case 8: 
  ma___2 = (int16 *)origdata;
  fprintf(_coverage_fout, "2518\n");
  fflush(_coverage_fout);
  mb___2 = data;
  fprintf(_coverage_fout, "2519\n");
  fflush(_coverage_fout);
  n___3 = 0U;
  fprintf(_coverage_fout, "2520\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2467\n");
    fflush(_coverage_fout);
    if (n___3 < count) {
      fprintf(_coverage_fout, "2463\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2468\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2464\n");
      fflush(_coverage_fout);
      TIFFSwabShort((uint16 *)ma___2);
    } else {
      fprintf(_coverage_fout, "2465\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2469\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeLongSshort(*ma___2);
    fprintf(_coverage_fout, "2470\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2466\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2471\n");
    fflush(_coverage_fout);
    tmp___6 = mb___2;
    fprintf(_coverage_fout, "2472\n");
    fflush(_coverage_fout);
    mb___2 ++;
    fprintf(_coverage_fout, "2473\n");
    fflush(_coverage_fout);
    tmp___7 = ma___2;
    fprintf(_coverage_fout, "2474\n");
    fflush(_coverage_fout);
    ma___2 ++;
    fprintf(_coverage_fout, "2475\n");
    fflush(_coverage_fout);
    *tmp___6 = (unsigned int )*tmp___7;
    fprintf(_coverage_fout, "2476\n");
    fflush(_coverage_fout);
    n___3 ++;
  }
  break;
  fprintf(_coverage_fout, "2521\n");
  fflush(_coverage_fout);
  case 16: 
  ma___3 = (uint64 *)origdata;
  fprintf(_coverage_fout, "2522\n");
  fflush(_coverage_fout);
  mb___3 = data;
  fprintf(_coverage_fout, "2523\n");
  fflush(_coverage_fout);
  n___4 = 0U;
  fprintf(_coverage_fout, "2524\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2481\n");
    fflush(_coverage_fout);
    if (n___4 < count) {
      fprintf(_coverage_fout, "2477\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2482\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2478\n");
      fflush(_coverage_fout);
      TIFFSwabLong8(ma___3);
    } else {
      fprintf(_coverage_fout, "2479\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2483\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeLongLong8(*ma___3);
    fprintf(_coverage_fout, "2484\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2480\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2485\n");
    fflush(_coverage_fout);
    tmp___8 = mb___3;
    fprintf(_coverage_fout, "2486\n");
    fflush(_coverage_fout);
    mb___3 ++;
    fprintf(_coverage_fout, "2487\n");
    fflush(_coverage_fout);
    tmp___9 = ma___3;
    fprintf(_coverage_fout, "2488\n");
    fflush(_coverage_fout);
    ma___3 ++;
    fprintf(_coverage_fout, "2489\n");
    fflush(_coverage_fout);
    *tmp___8 = (unsigned int )*tmp___9;
    fprintf(_coverage_fout, "2490\n");
    fflush(_coverage_fout);
    n___4 ++;
  }
  break;
  fprintf(_coverage_fout, "2525\n");
  fflush(_coverage_fout);
  case 17: 
  ma___4 = (int64 *)origdata;
  fprintf(_coverage_fout, "2526\n");
  fflush(_coverage_fout);
  mb___4 = data;
  fprintf(_coverage_fout, "2527\n");
  fflush(_coverage_fout);
  n___5 = 0U;
  fprintf(_coverage_fout, "2528\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2495\n");
    fflush(_coverage_fout);
    if (n___5 < count) {
      fprintf(_coverage_fout, "2491\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2496\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2492\n");
      fflush(_coverage_fout);
      TIFFSwabLong8((uint64 *)ma___4);
    } else {
      fprintf(_coverage_fout, "2493\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2497\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeLongSlong8(*ma___4);
    fprintf(_coverage_fout, "2498\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2494\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2499\n");
    fflush(_coverage_fout);
    tmp___10 = mb___4;
    fprintf(_coverage_fout, "2500\n");
    fflush(_coverage_fout);
    mb___4 ++;
    fprintf(_coverage_fout, "2501\n");
    fflush(_coverage_fout);
    tmp___11 = ma___4;
    fprintf(_coverage_fout, "2502\n");
    fflush(_coverage_fout);
    ma___4 ++;
    fprintf(_coverage_fout, "2503\n");
    fflush(_coverage_fout);
    *tmp___10 = (unsigned int )*tmp___11;
    fprintf(_coverage_fout, "2504\n");
    fflush(_coverage_fout);
    n___5 ++;
  }
  break;
  }
  fprintf(_coverage_fout, "2537\n");
  fflush(_coverage_fout);
  _TIFFfree(origdata);
  fprintf(_coverage_fout, "2538\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "2529\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)data);
    fprintf(_coverage_fout, "2530\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "2531\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2539\n");
  fflush(_coverage_fout);
  *value = data;
  fprintf(_coverage_fout, "2540\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntrySlongArray(TIFF *tif ,
                                                           TIFFDirEntry *direntry ,
                                                           int32 **value ) 
{ enum TIFFReadDirEntryErr err ;
  uint32 count ;
  void *origdata ;
  int32 *data ;
  uint32 *m ;
  uint32 n ;
  void *tmp ;
  uint8 *ma ;
  int32 *mb ;
  uint32 n___0 ;
  int32 *tmp___0 ;
  uint8 *tmp___1 ;
  int8 *ma___0 ;
  int32 *mb___0 ;
  uint32 n___1 ;
  int32 *tmp___2 ;
  int8 *tmp___3 ;
  uint16 *ma___1 ;
  int32 *mb___1 ;
  uint32 n___2 ;
  int32 *tmp___4 ;
  uint16 *tmp___5 ;
  int16 *ma___2 ;
  int32 *mb___2 ;
  uint32 n___3 ;
  int32 *tmp___6 ;
  int16 *tmp___7 ;
  uint64 *ma___3 ;
  int32 *mb___3 ;
  uint32 n___4 ;
  int32 *tmp___8 ;
  uint64 *tmp___9 ;
  int64 *ma___4 ;
  int32 *mb___4 ;
  uint32 n___5 ;
  int32 *tmp___10 ;
  int64 *tmp___11 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  switch ((int )direntry->tdir_type) {
  case 1: 
  case 6: 
  case 3: 
  case 8: 
  case 4: 
  case 9: 
  case 16: 
  case 17: 
  break;
  fprintf(_coverage_fout, "2541\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "2542\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
  fprintf(_coverage_fout, "2667\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryArray(tif, direntry, & count, 4U, & origdata);
  fprintf(_coverage_fout, "2668\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "2543\n");
    fflush(_coverage_fout);
    *value = (int32 *)0;
    fprintf(_coverage_fout, "2544\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "2548\n");
    fflush(_coverage_fout);
    if ((unsigned int )origdata == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "2545\n");
      fflush(_coverage_fout);
      *value = (int32 *)0;
      fprintf(_coverage_fout, "2546\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "2547\n");
      fflush(_coverage_fout);

    }
  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "2563\n");
  fflush(_coverage_fout);
  case 4: 
  m = (uint32 *)origdata;
  fprintf(_coverage_fout, "2564\n");
  fflush(_coverage_fout);
  n = 0U;
  fprintf(_coverage_fout, "2565\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2555\n");
    fflush(_coverage_fout);
    if (n < count) {
      fprintf(_coverage_fout, "2549\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2556\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2550\n");
      fflush(_coverage_fout);
      TIFFSwabLong(m);
    } else {
      fprintf(_coverage_fout, "2551\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2557\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeSlongLong(*m);
    fprintf(_coverage_fout, "2558\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      fprintf(_coverage_fout, "2552\n");
      fflush(_coverage_fout);
      _TIFFfree(origdata);
      fprintf(_coverage_fout, "2553\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "2554\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2559\n");
    fflush(_coverage_fout);
    m ++;
    fprintf(_coverage_fout, "2560\n");
    fflush(_coverage_fout);
    n ++;
  }
  fprintf(_coverage_fout, "2566\n");
  fflush(_coverage_fout);
  *value = (int32 *)origdata;
  fprintf(_coverage_fout, "2567\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "2568\n");
  fflush(_coverage_fout);
  case 9: 
  *value = (int32 *)origdata;
  fprintf(_coverage_fout, "2569\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "2561\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong((uint32 *)*value, (long )count);
  } else {
    fprintf(_coverage_fout, "2562\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2570\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  }
  fprintf(_coverage_fout, "2669\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )(count * 4U));
  fprintf(_coverage_fout, "2670\n");
  fflush(_coverage_fout);
  data = (int32 *)tmp;
  fprintf(_coverage_fout, "2671\n");
  fflush(_coverage_fout);
  if ((unsigned int )data == (unsigned int )((int32 *)0)) {
    fprintf(_coverage_fout, "2571\n");
    fflush(_coverage_fout);
    _TIFFfree(origdata);
    fprintf(_coverage_fout, "2572\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )7);
  } else {
    fprintf(_coverage_fout, "2573\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "2640\n");
  fflush(_coverage_fout);
  case 1: 
  ma = (uint8 *)origdata;
  fprintf(_coverage_fout, "2641\n");
  fflush(_coverage_fout);
  mb = data;
  fprintf(_coverage_fout, "2642\n");
  fflush(_coverage_fout);
  n___0 = 0U;
  fprintf(_coverage_fout, "2643\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2575\n");
    fflush(_coverage_fout);
    if (n___0 < count) {
      fprintf(_coverage_fout, "2574\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2576\n");
    fflush(_coverage_fout);
    tmp___0 = mb;
    fprintf(_coverage_fout, "2577\n");
    fflush(_coverage_fout);
    mb ++;
    fprintf(_coverage_fout, "2578\n");
    fflush(_coverage_fout);
    tmp___1 = ma;
    fprintf(_coverage_fout, "2579\n");
    fflush(_coverage_fout);
    ma ++;
    fprintf(_coverage_fout, "2580\n");
    fflush(_coverage_fout);
    *tmp___0 = (int )*tmp___1;
    fprintf(_coverage_fout, "2581\n");
    fflush(_coverage_fout);
    n___0 ++;
  }
  break;
  fprintf(_coverage_fout, "2644\n");
  fflush(_coverage_fout);
  case 6: 
  ma___0 = (int8 *)origdata;
  fprintf(_coverage_fout, "2645\n");
  fflush(_coverage_fout);
  mb___0 = data;
  fprintf(_coverage_fout, "2646\n");
  fflush(_coverage_fout);
  n___1 = 0U;
  fprintf(_coverage_fout, "2647\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2583\n");
    fflush(_coverage_fout);
    if (n___1 < count) {
      fprintf(_coverage_fout, "2582\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2584\n");
    fflush(_coverage_fout);
    tmp___2 = mb___0;
    fprintf(_coverage_fout, "2585\n");
    fflush(_coverage_fout);
    mb___0 ++;
    fprintf(_coverage_fout, "2586\n");
    fflush(_coverage_fout);
    tmp___3 = ma___0;
    fprintf(_coverage_fout, "2587\n");
    fflush(_coverage_fout);
    ma___0 ++;
    fprintf(_coverage_fout, "2588\n");
    fflush(_coverage_fout);
    *tmp___2 = (int )*tmp___3;
    fprintf(_coverage_fout, "2589\n");
    fflush(_coverage_fout);
    n___1 ++;
  }
  break;
  fprintf(_coverage_fout, "2648\n");
  fflush(_coverage_fout);
  case 3: 
  ma___1 = (uint16 *)origdata;
  fprintf(_coverage_fout, "2649\n");
  fflush(_coverage_fout);
  mb___1 = data;
  fprintf(_coverage_fout, "2650\n");
  fflush(_coverage_fout);
  n___2 = 0U;
  fprintf(_coverage_fout, "2651\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2593\n");
    fflush(_coverage_fout);
    if (n___2 < count) {
      fprintf(_coverage_fout, "2590\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2594\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2591\n");
      fflush(_coverage_fout);
      TIFFSwabShort(ma___1);
    } else {
      fprintf(_coverage_fout, "2592\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2595\n");
    fflush(_coverage_fout);
    tmp___4 = mb___1;
    fprintf(_coverage_fout, "2596\n");
    fflush(_coverage_fout);
    mb___1 ++;
    fprintf(_coverage_fout, "2597\n");
    fflush(_coverage_fout);
    tmp___5 = ma___1;
    fprintf(_coverage_fout, "2598\n");
    fflush(_coverage_fout);
    ma___1 ++;
    fprintf(_coverage_fout, "2599\n");
    fflush(_coverage_fout);
    *tmp___4 = (int )*tmp___5;
    fprintf(_coverage_fout, "2600\n");
    fflush(_coverage_fout);
    n___2 ++;
  }
  break;
  fprintf(_coverage_fout, "2652\n");
  fflush(_coverage_fout);
  case 8: 
  ma___2 = (int16 *)origdata;
  fprintf(_coverage_fout, "2653\n");
  fflush(_coverage_fout);
  mb___2 = data;
  fprintf(_coverage_fout, "2654\n");
  fflush(_coverage_fout);
  n___3 = 0U;
  fprintf(_coverage_fout, "2655\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2604\n");
    fflush(_coverage_fout);
    if (n___3 < count) {
      fprintf(_coverage_fout, "2601\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2605\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2602\n");
      fflush(_coverage_fout);
      TIFFSwabShort((uint16 *)ma___2);
    } else {
      fprintf(_coverage_fout, "2603\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2606\n");
    fflush(_coverage_fout);
    tmp___6 = mb___2;
    fprintf(_coverage_fout, "2607\n");
    fflush(_coverage_fout);
    mb___2 ++;
    fprintf(_coverage_fout, "2608\n");
    fflush(_coverage_fout);
    tmp___7 = ma___2;
    fprintf(_coverage_fout, "2609\n");
    fflush(_coverage_fout);
    ma___2 ++;
    fprintf(_coverage_fout, "2610\n");
    fflush(_coverage_fout);
    *tmp___6 = (int )*tmp___7;
    fprintf(_coverage_fout, "2611\n");
    fflush(_coverage_fout);
    n___3 ++;
  }
  break;
  fprintf(_coverage_fout, "2656\n");
  fflush(_coverage_fout);
  case 16: 
  ma___3 = (uint64 *)origdata;
  fprintf(_coverage_fout, "2657\n");
  fflush(_coverage_fout);
  mb___3 = data;
  fprintf(_coverage_fout, "2658\n");
  fflush(_coverage_fout);
  n___4 = 0U;
  fprintf(_coverage_fout, "2659\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2616\n");
    fflush(_coverage_fout);
    if (n___4 < count) {
      fprintf(_coverage_fout, "2612\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2617\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2613\n");
      fflush(_coverage_fout);
      TIFFSwabLong8(ma___3);
    } else {
      fprintf(_coverage_fout, "2614\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2618\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeSlongLong8(*ma___3);
    fprintf(_coverage_fout, "2619\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2615\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2620\n");
    fflush(_coverage_fout);
    tmp___8 = mb___3;
    fprintf(_coverage_fout, "2621\n");
    fflush(_coverage_fout);
    mb___3 ++;
    fprintf(_coverage_fout, "2622\n");
    fflush(_coverage_fout);
    tmp___9 = ma___3;
    fprintf(_coverage_fout, "2623\n");
    fflush(_coverage_fout);
    ma___3 ++;
    fprintf(_coverage_fout, "2624\n");
    fflush(_coverage_fout);
    *tmp___8 = (int )*tmp___9;
    fprintf(_coverage_fout, "2625\n");
    fflush(_coverage_fout);
    n___4 ++;
  }
  break;
  fprintf(_coverage_fout, "2660\n");
  fflush(_coverage_fout);
  case 17: 
  ma___4 = (int64 *)origdata;
  fprintf(_coverage_fout, "2661\n");
  fflush(_coverage_fout);
  mb___4 = data;
  fprintf(_coverage_fout, "2662\n");
  fflush(_coverage_fout);
  n___5 = 0U;
  fprintf(_coverage_fout, "2663\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2630\n");
    fflush(_coverage_fout);
    if (n___5 < count) {
      fprintf(_coverage_fout, "2626\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2631\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2627\n");
      fflush(_coverage_fout);
      TIFFSwabLong8((uint64 *)ma___4);
    } else {
      fprintf(_coverage_fout, "2628\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2632\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeSlongSlong8(*ma___4);
    fprintf(_coverage_fout, "2633\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2629\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2634\n");
    fflush(_coverage_fout);
    tmp___10 = mb___4;
    fprintf(_coverage_fout, "2635\n");
    fflush(_coverage_fout);
    mb___4 ++;
    fprintf(_coverage_fout, "2636\n");
    fflush(_coverage_fout);
    tmp___11 = ma___4;
    fprintf(_coverage_fout, "2637\n");
    fflush(_coverage_fout);
    ma___4 ++;
    fprintf(_coverage_fout, "2638\n");
    fflush(_coverage_fout);
    *tmp___10 = (int )*tmp___11;
    fprintf(_coverage_fout, "2639\n");
    fflush(_coverage_fout);
    n___5 ++;
  }
  break;
  }
  fprintf(_coverage_fout, "2672\n");
  fflush(_coverage_fout);
  _TIFFfree(origdata);
  fprintf(_coverage_fout, "2673\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "2664\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)data);
    fprintf(_coverage_fout, "2665\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "2666\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2674\n");
  fflush(_coverage_fout);
  *value = data;
  fprintf(_coverage_fout, "2675\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryLong8Array(TIFF *tif ,
                                                           TIFFDirEntry *direntry ,
                                                           uint64 **value ) 
{ enum TIFFReadDirEntryErr err ;
  uint32 count ;
  void *origdata ;
  uint64 *data ;
  int64 *m ;
  uint32 n ;
  void *tmp ;
  uint8 *ma ;
  uint64 *mb ;
  uint32 n___0 ;
  uint64 *tmp___0 ;
  uint8 *tmp___1 ;
  int8 *ma___0 ;
  uint64 *mb___0 ;
  uint32 n___1 ;
  uint64 *tmp___2 ;
  int8 *tmp___3 ;
  uint16 *ma___1 ;
  uint64 *mb___1 ;
  uint32 n___2 ;
  uint64 *tmp___4 ;
  uint16 *tmp___5 ;
  int16 *ma___2 ;
  uint64 *mb___2 ;
  uint32 n___3 ;
  uint64 *tmp___6 ;
  int16 *tmp___7 ;
  uint32 *ma___3 ;
  uint64 *mb___3 ;
  uint32 n___4 ;
  uint64 *tmp___8 ;
  uint32 *tmp___9 ;
  int32 *ma___4 ;
  uint64 *mb___4 ;
  uint32 n___5 ;
  uint64 *tmp___10 ;
  int32 *tmp___11 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  switch ((int )direntry->tdir_type) {
  case 1: 
  case 6: 
  case 3: 
  case 8: 
  case 4: 
  case 9: 
  case 16: 
  case 17: 
  break;
  fprintf(_coverage_fout, "2676\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "2677\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
  fprintf(_coverage_fout, "2805\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryArray(tif, direntry, & count, 8U, & origdata);
  fprintf(_coverage_fout, "2806\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "2678\n");
    fflush(_coverage_fout);
    *value = (uint64 *)0;
    fprintf(_coverage_fout, "2679\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "2683\n");
    fflush(_coverage_fout);
    if ((unsigned int )origdata == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "2680\n");
      fflush(_coverage_fout);
      *value = (uint64 *)0;
      fprintf(_coverage_fout, "2681\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "2682\n");
      fflush(_coverage_fout);

    }
  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "2698\n");
  fflush(_coverage_fout);
  case 16: 
  *value = (uint64 *)origdata;
  fprintf(_coverage_fout, "2699\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "2684\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong8(*value, (long )count);
  } else {
    fprintf(_coverage_fout, "2685\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2700\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "2701\n");
  fflush(_coverage_fout);
  case 17: 
  m = (int64 *)origdata;
  fprintf(_coverage_fout, "2702\n");
  fflush(_coverage_fout);
  n = 0U;
  fprintf(_coverage_fout, "2703\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2692\n");
    fflush(_coverage_fout);
    if (n < count) {
      fprintf(_coverage_fout, "2686\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2693\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2687\n");
      fflush(_coverage_fout);
      TIFFSwabLong8((uint64 *)m);
    } else {
      fprintf(_coverage_fout, "2688\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2694\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeLong8Slong8(*m);
    fprintf(_coverage_fout, "2695\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      fprintf(_coverage_fout, "2689\n");
      fflush(_coverage_fout);
      _TIFFfree(origdata);
      fprintf(_coverage_fout, "2690\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "2691\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2696\n");
    fflush(_coverage_fout);
    m ++;
    fprintf(_coverage_fout, "2697\n");
    fflush(_coverage_fout);
    n ++;
  }
  fprintf(_coverage_fout, "2704\n");
  fflush(_coverage_fout);
  *value = (uint64 *)origdata;
  fprintf(_coverage_fout, "2705\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  }
  fprintf(_coverage_fout, "2807\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )(count * 8U));
  fprintf(_coverage_fout, "2808\n");
  fflush(_coverage_fout);
  data = (uint64 *)tmp;
  fprintf(_coverage_fout, "2809\n");
  fflush(_coverage_fout);
  if ((unsigned int )data == (unsigned int )((uint64 *)0)) {
    fprintf(_coverage_fout, "2706\n");
    fflush(_coverage_fout);
    _TIFFfree(origdata);
    fprintf(_coverage_fout, "2707\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )7);
  } else {
    fprintf(_coverage_fout, "2708\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "2778\n");
  fflush(_coverage_fout);
  case 1: 
  ma = (uint8 *)origdata;
  fprintf(_coverage_fout, "2779\n");
  fflush(_coverage_fout);
  mb = data;
  fprintf(_coverage_fout, "2780\n");
  fflush(_coverage_fout);
  n___0 = 0U;
  fprintf(_coverage_fout, "2781\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2710\n");
    fflush(_coverage_fout);
    if (n___0 < count) {
      fprintf(_coverage_fout, "2709\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2711\n");
    fflush(_coverage_fout);
    tmp___0 = mb;
    fprintf(_coverage_fout, "2712\n");
    fflush(_coverage_fout);
    mb ++;
    fprintf(_coverage_fout, "2713\n");
    fflush(_coverage_fout);
    tmp___1 = ma;
    fprintf(_coverage_fout, "2714\n");
    fflush(_coverage_fout);
    ma ++;
    fprintf(_coverage_fout, "2715\n");
    fflush(_coverage_fout);
    *tmp___0 = (unsigned long long )*tmp___1;
    fprintf(_coverage_fout, "2716\n");
    fflush(_coverage_fout);
    n___0 ++;
  }
  break;
  fprintf(_coverage_fout, "2782\n");
  fflush(_coverage_fout);
  case 6: 
  ma___0 = (int8 *)origdata;
  fprintf(_coverage_fout, "2783\n");
  fflush(_coverage_fout);
  mb___0 = data;
  fprintf(_coverage_fout, "2784\n");
  fflush(_coverage_fout);
  n___1 = 0U;
  fprintf(_coverage_fout, "2785\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2719\n");
    fflush(_coverage_fout);
    if (n___1 < count) {
      fprintf(_coverage_fout, "2717\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2720\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeLong8Sbyte(*ma___0);
    fprintf(_coverage_fout, "2721\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2718\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2722\n");
    fflush(_coverage_fout);
    tmp___2 = mb___0;
    fprintf(_coverage_fout, "2723\n");
    fflush(_coverage_fout);
    mb___0 ++;
    fprintf(_coverage_fout, "2724\n");
    fflush(_coverage_fout);
    tmp___3 = ma___0;
    fprintf(_coverage_fout, "2725\n");
    fflush(_coverage_fout);
    ma___0 ++;
    fprintf(_coverage_fout, "2726\n");
    fflush(_coverage_fout);
    *tmp___2 = (unsigned long long )*tmp___3;
    fprintf(_coverage_fout, "2727\n");
    fflush(_coverage_fout);
    n___1 ++;
  }
  break;
  fprintf(_coverage_fout, "2786\n");
  fflush(_coverage_fout);
  case 3: 
  ma___1 = (uint16 *)origdata;
  fprintf(_coverage_fout, "2787\n");
  fflush(_coverage_fout);
  mb___1 = data;
  fprintf(_coverage_fout, "2788\n");
  fflush(_coverage_fout);
  n___2 = 0U;
  fprintf(_coverage_fout, "2789\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2731\n");
    fflush(_coverage_fout);
    if (n___2 < count) {
      fprintf(_coverage_fout, "2728\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2732\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2729\n");
      fflush(_coverage_fout);
      TIFFSwabShort(ma___1);
    } else {
      fprintf(_coverage_fout, "2730\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2733\n");
    fflush(_coverage_fout);
    tmp___4 = mb___1;
    fprintf(_coverage_fout, "2734\n");
    fflush(_coverage_fout);
    mb___1 ++;
    fprintf(_coverage_fout, "2735\n");
    fflush(_coverage_fout);
    tmp___5 = ma___1;
    fprintf(_coverage_fout, "2736\n");
    fflush(_coverage_fout);
    ma___1 ++;
    fprintf(_coverage_fout, "2737\n");
    fflush(_coverage_fout);
    *tmp___4 = (unsigned long long )*tmp___5;
    fprintf(_coverage_fout, "2738\n");
    fflush(_coverage_fout);
    n___2 ++;
  }
  break;
  fprintf(_coverage_fout, "2790\n");
  fflush(_coverage_fout);
  case 8: 
  ma___2 = (int16 *)origdata;
  fprintf(_coverage_fout, "2791\n");
  fflush(_coverage_fout);
  mb___2 = data;
  fprintf(_coverage_fout, "2792\n");
  fflush(_coverage_fout);
  n___3 = 0U;
  fprintf(_coverage_fout, "2793\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2743\n");
    fflush(_coverage_fout);
    if (n___3 < count) {
      fprintf(_coverage_fout, "2739\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2744\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2740\n");
      fflush(_coverage_fout);
      TIFFSwabShort((uint16 *)ma___2);
    } else {
      fprintf(_coverage_fout, "2741\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2745\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeLong8Sshort(*ma___2);
    fprintf(_coverage_fout, "2746\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2742\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2747\n");
    fflush(_coverage_fout);
    tmp___6 = mb___2;
    fprintf(_coverage_fout, "2748\n");
    fflush(_coverage_fout);
    mb___2 ++;
    fprintf(_coverage_fout, "2749\n");
    fflush(_coverage_fout);
    tmp___7 = ma___2;
    fprintf(_coverage_fout, "2750\n");
    fflush(_coverage_fout);
    ma___2 ++;
    fprintf(_coverage_fout, "2751\n");
    fflush(_coverage_fout);
    *tmp___6 = (unsigned long long )*tmp___7;
    fprintf(_coverage_fout, "2752\n");
    fflush(_coverage_fout);
    n___3 ++;
  }
  break;
  fprintf(_coverage_fout, "2794\n");
  fflush(_coverage_fout);
  case 4: 
  ma___3 = (uint32 *)origdata;
  fprintf(_coverage_fout, "2795\n");
  fflush(_coverage_fout);
  mb___3 = data;
  fprintf(_coverage_fout, "2796\n");
  fflush(_coverage_fout);
  n___4 = 0U;
  fprintf(_coverage_fout, "2797\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2756\n");
    fflush(_coverage_fout);
    if (n___4 < count) {
      fprintf(_coverage_fout, "2753\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2757\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2754\n");
      fflush(_coverage_fout);
      TIFFSwabLong(ma___3);
    } else {
      fprintf(_coverage_fout, "2755\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2758\n");
    fflush(_coverage_fout);
    tmp___8 = mb___3;
    fprintf(_coverage_fout, "2759\n");
    fflush(_coverage_fout);
    mb___3 ++;
    fprintf(_coverage_fout, "2760\n");
    fflush(_coverage_fout);
    tmp___9 = ma___3;
    fprintf(_coverage_fout, "2761\n");
    fflush(_coverage_fout);
    ma___3 ++;
    fprintf(_coverage_fout, "2762\n");
    fflush(_coverage_fout);
    *tmp___8 = (unsigned long long )*tmp___9;
    fprintf(_coverage_fout, "2763\n");
    fflush(_coverage_fout);
    n___4 ++;
  }
  break;
  fprintf(_coverage_fout, "2798\n");
  fflush(_coverage_fout);
  case 9: 
  ma___4 = (int32 *)origdata;
  fprintf(_coverage_fout, "2799\n");
  fflush(_coverage_fout);
  mb___4 = data;
  fprintf(_coverage_fout, "2800\n");
  fflush(_coverage_fout);
  n___5 = 0U;
  fprintf(_coverage_fout, "2801\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2768\n");
    fflush(_coverage_fout);
    if (n___5 < count) {
      fprintf(_coverage_fout, "2764\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2769\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2765\n");
      fflush(_coverage_fout);
      TIFFSwabLong((uint32 *)ma___4);
    } else {
      fprintf(_coverage_fout, "2766\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2770\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeLong8Slong(*ma___4);
    fprintf(_coverage_fout, "2771\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      break;
    } else {
      fprintf(_coverage_fout, "2767\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2772\n");
    fflush(_coverage_fout);
    tmp___10 = mb___4;
    fprintf(_coverage_fout, "2773\n");
    fflush(_coverage_fout);
    mb___4 ++;
    fprintf(_coverage_fout, "2774\n");
    fflush(_coverage_fout);
    tmp___11 = ma___4;
    fprintf(_coverage_fout, "2775\n");
    fflush(_coverage_fout);
    ma___4 ++;
    fprintf(_coverage_fout, "2776\n");
    fflush(_coverage_fout);
    *tmp___10 = (unsigned long long )*tmp___11;
    fprintf(_coverage_fout, "2777\n");
    fflush(_coverage_fout);
    n___5 ++;
  }
  break;
  }
  fprintf(_coverage_fout, "2810\n");
  fflush(_coverage_fout);
  _TIFFfree(origdata);
  fprintf(_coverage_fout, "2811\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "2802\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)data);
    fprintf(_coverage_fout, "2803\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "2804\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2812\n");
  fflush(_coverage_fout);
  *value = data;
  fprintf(_coverage_fout, "2813\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntrySlong8Array(TIFF *tif ,
                                                            TIFFDirEntry *direntry ,
                                                            int64 **value ) 
{ enum TIFFReadDirEntryErr err ;
  uint32 count ;
  void *origdata ;
  int64 *data ;
  uint64 *m ;
  uint32 n ;
  void *tmp ;
  uint8 *ma ;
  int64 *mb ;
  uint32 n___0 ;
  int64 *tmp___0 ;
  uint8 *tmp___1 ;
  int8 *ma___0 ;
  int64 *mb___0 ;
  uint32 n___1 ;
  int64 *tmp___2 ;
  int8 *tmp___3 ;
  uint16 *ma___1 ;
  int64 *mb___1 ;
  uint32 n___2 ;
  int64 *tmp___4 ;
  uint16 *tmp___5 ;
  int16 *ma___2 ;
  int64 *mb___2 ;
  uint32 n___3 ;
  int64 *tmp___6 ;
  int16 *tmp___7 ;
  uint32 *ma___3 ;
  int64 *mb___3 ;
  uint32 n___4 ;
  int64 *tmp___8 ;
  uint32 *tmp___9 ;
  int32 *ma___4 ;
  int64 *mb___4 ;
  uint32 n___5 ;
  int64 *tmp___10 ;
  int32 *tmp___11 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  switch ((int )direntry->tdir_type) {
  case 1: 
  case 6: 
  case 3: 
  case 8: 
  case 4: 
  case 9: 
  case 16: 
  case 17: 
  break;
  fprintf(_coverage_fout, "2814\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "2815\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
  fprintf(_coverage_fout, "2934\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryArray(tif, direntry, & count, 8U, & origdata);
  fprintf(_coverage_fout, "2935\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "2816\n");
    fflush(_coverage_fout);
    *value = (int64 *)0;
    fprintf(_coverage_fout, "2817\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "2821\n");
    fflush(_coverage_fout);
    if ((unsigned int )origdata == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "2818\n");
      fflush(_coverage_fout);
      *value = (int64 *)0;
      fprintf(_coverage_fout, "2819\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "2820\n");
      fflush(_coverage_fout);

    }
  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "2836\n");
  fflush(_coverage_fout);
  case 16: 
  m = (uint64 *)origdata;
  fprintf(_coverage_fout, "2837\n");
  fflush(_coverage_fout);
  n = 0U;
  fprintf(_coverage_fout, "2838\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2828\n");
    fflush(_coverage_fout);
    if (n < count) {
      fprintf(_coverage_fout, "2822\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2829\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2823\n");
      fflush(_coverage_fout);
      TIFFSwabLong8(m);
    } else {
      fprintf(_coverage_fout, "2824\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2830\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryCheckRangeSlong8Long8(*m);
    fprintf(_coverage_fout, "2831\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      fprintf(_coverage_fout, "2825\n");
      fflush(_coverage_fout);
      _TIFFfree(origdata);
      fprintf(_coverage_fout, "2826\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "2827\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2832\n");
    fflush(_coverage_fout);
    m ++;
    fprintf(_coverage_fout, "2833\n");
    fflush(_coverage_fout);
    n ++;
  }
  fprintf(_coverage_fout, "2839\n");
  fflush(_coverage_fout);
  *value = (int64 *)origdata;
  fprintf(_coverage_fout, "2840\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  fprintf(_coverage_fout, "2841\n");
  fflush(_coverage_fout);
  case 17: 
  *value = (int64 *)origdata;
  fprintf(_coverage_fout, "2842\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "2834\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong8((uint64 *)*value, (long )count);
  } else {
    fprintf(_coverage_fout, "2835\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2843\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  }
  fprintf(_coverage_fout, "2936\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )(count * 8U));
  fprintf(_coverage_fout, "2937\n");
  fflush(_coverage_fout);
  data = (int64 *)tmp;
  fprintf(_coverage_fout, "2938\n");
  fflush(_coverage_fout);
  if ((unsigned int )data == (unsigned int )((int64 *)0)) {
    fprintf(_coverage_fout, "2844\n");
    fflush(_coverage_fout);
    _TIFFfree(origdata);
    fprintf(_coverage_fout, "2845\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )7);
  } else {
    fprintf(_coverage_fout, "2846\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "2907\n");
  fflush(_coverage_fout);
  case 1: 
  ma = (uint8 *)origdata;
  fprintf(_coverage_fout, "2908\n");
  fflush(_coverage_fout);
  mb = data;
  fprintf(_coverage_fout, "2909\n");
  fflush(_coverage_fout);
  n___0 = 0U;
  fprintf(_coverage_fout, "2910\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2848\n");
    fflush(_coverage_fout);
    if (n___0 < count) {
      fprintf(_coverage_fout, "2847\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2849\n");
    fflush(_coverage_fout);
    tmp___0 = mb;
    fprintf(_coverage_fout, "2850\n");
    fflush(_coverage_fout);
    mb ++;
    fprintf(_coverage_fout, "2851\n");
    fflush(_coverage_fout);
    tmp___1 = ma;
    fprintf(_coverage_fout, "2852\n");
    fflush(_coverage_fout);
    ma ++;
    fprintf(_coverage_fout, "2853\n");
    fflush(_coverage_fout);
    *tmp___0 = (long long )*tmp___1;
    fprintf(_coverage_fout, "2854\n");
    fflush(_coverage_fout);
    n___0 ++;
  }
  break;
  fprintf(_coverage_fout, "2911\n");
  fflush(_coverage_fout);
  case 6: 
  ma___0 = (int8 *)origdata;
  fprintf(_coverage_fout, "2912\n");
  fflush(_coverage_fout);
  mb___0 = data;
  fprintf(_coverage_fout, "2913\n");
  fflush(_coverage_fout);
  n___1 = 0U;
  fprintf(_coverage_fout, "2914\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2856\n");
    fflush(_coverage_fout);
    if (n___1 < count) {
      fprintf(_coverage_fout, "2855\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2857\n");
    fflush(_coverage_fout);
    tmp___2 = mb___0;
    fprintf(_coverage_fout, "2858\n");
    fflush(_coverage_fout);
    mb___0 ++;
    fprintf(_coverage_fout, "2859\n");
    fflush(_coverage_fout);
    tmp___3 = ma___0;
    fprintf(_coverage_fout, "2860\n");
    fflush(_coverage_fout);
    ma___0 ++;
    fprintf(_coverage_fout, "2861\n");
    fflush(_coverage_fout);
    *tmp___2 = (long long )*tmp___3;
    fprintf(_coverage_fout, "2862\n");
    fflush(_coverage_fout);
    n___1 ++;
  }
  break;
  fprintf(_coverage_fout, "2915\n");
  fflush(_coverage_fout);
  case 3: 
  ma___1 = (uint16 *)origdata;
  fprintf(_coverage_fout, "2916\n");
  fflush(_coverage_fout);
  mb___1 = data;
  fprintf(_coverage_fout, "2917\n");
  fflush(_coverage_fout);
  n___2 = 0U;
  fprintf(_coverage_fout, "2918\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2866\n");
    fflush(_coverage_fout);
    if (n___2 < count) {
      fprintf(_coverage_fout, "2863\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2867\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2864\n");
      fflush(_coverage_fout);
      TIFFSwabShort(ma___1);
    } else {
      fprintf(_coverage_fout, "2865\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2868\n");
    fflush(_coverage_fout);
    tmp___4 = mb___1;
    fprintf(_coverage_fout, "2869\n");
    fflush(_coverage_fout);
    mb___1 ++;
    fprintf(_coverage_fout, "2870\n");
    fflush(_coverage_fout);
    tmp___5 = ma___1;
    fprintf(_coverage_fout, "2871\n");
    fflush(_coverage_fout);
    ma___1 ++;
    fprintf(_coverage_fout, "2872\n");
    fflush(_coverage_fout);
    *tmp___4 = (long long )*tmp___5;
    fprintf(_coverage_fout, "2873\n");
    fflush(_coverage_fout);
    n___2 ++;
  }
  break;
  fprintf(_coverage_fout, "2919\n");
  fflush(_coverage_fout);
  case 8: 
  ma___2 = (int16 *)origdata;
  fprintf(_coverage_fout, "2920\n");
  fflush(_coverage_fout);
  mb___2 = data;
  fprintf(_coverage_fout, "2921\n");
  fflush(_coverage_fout);
  n___3 = 0U;
  fprintf(_coverage_fout, "2922\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2877\n");
    fflush(_coverage_fout);
    if (n___3 < count) {
      fprintf(_coverage_fout, "2874\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2878\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2875\n");
      fflush(_coverage_fout);
      TIFFSwabShort((uint16 *)ma___2);
    } else {
      fprintf(_coverage_fout, "2876\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2879\n");
    fflush(_coverage_fout);
    tmp___6 = mb___2;
    fprintf(_coverage_fout, "2880\n");
    fflush(_coverage_fout);
    mb___2 ++;
    fprintf(_coverage_fout, "2881\n");
    fflush(_coverage_fout);
    tmp___7 = ma___2;
    fprintf(_coverage_fout, "2882\n");
    fflush(_coverage_fout);
    ma___2 ++;
    fprintf(_coverage_fout, "2883\n");
    fflush(_coverage_fout);
    *tmp___6 = (long long )*tmp___7;
    fprintf(_coverage_fout, "2884\n");
    fflush(_coverage_fout);
    n___3 ++;
  }
  break;
  fprintf(_coverage_fout, "2923\n");
  fflush(_coverage_fout);
  case 4: 
  ma___3 = (uint32 *)origdata;
  fprintf(_coverage_fout, "2924\n");
  fflush(_coverage_fout);
  mb___3 = data;
  fprintf(_coverage_fout, "2925\n");
  fflush(_coverage_fout);
  n___4 = 0U;
  fprintf(_coverage_fout, "2926\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2888\n");
    fflush(_coverage_fout);
    if (n___4 < count) {
      fprintf(_coverage_fout, "2885\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2889\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2886\n");
      fflush(_coverage_fout);
      TIFFSwabLong(ma___3);
    } else {
      fprintf(_coverage_fout, "2887\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2890\n");
    fflush(_coverage_fout);
    tmp___8 = mb___3;
    fprintf(_coverage_fout, "2891\n");
    fflush(_coverage_fout);
    mb___3 ++;
    fprintf(_coverage_fout, "2892\n");
    fflush(_coverage_fout);
    tmp___9 = ma___3;
    fprintf(_coverage_fout, "2893\n");
    fflush(_coverage_fout);
    ma___3 ++;
    fprintf(_coverage_fout, "2894\n");
    fflush(_coverage_fout);
    *tmp___8 = (long long )*tmp___9;
    fprintf(_coverage_fout, "2895\n");
    fflush(_coverage_fout);
    n___4 ++;
  }
  break;
  fprintf(_coverage_fout, "2927\n");
  fflush(_coverage_fout);
  case 9: 
  ma___4 = (int32 *)origdata;
  fprintf(_coverage_fout, "2928\n");
  fflush(_coverage_fout);
  mb___4 = data;
  fprintf(_coverage_fout, "2929\n");
  fflush(_coverage_fout);
  n___5 = 0U;
  fprintf(_coverage_fout, "2930\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2899\n");
    fflush(_coverage_fout);
    if (n___5 < count) {
      fprintf(_coverage_fout, "2896\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2900\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2897\n");
      fflush(_coverage_fout);
      TIFFSwabLong((uint32 *)ma___4);
    } else {
      fprintf(_coverage_fout, "2898\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2901\n");
    fflush(_coverage_fout);
    tmp___10 = mb___4;
    fprintf(_coverage_fout, "2902\n");
    fflush(_coverage_fout);
    mb___4 ++;
    fprintf(_coverage_fout, "2903\n");
    fflush(_coverage_fout);
    tmp___11 = ma___4;
    fprintf(_coverage_fout, "2904\n");
    fflush(_coverage_fout);
    ma___4 ++;
    fprintf(_coverage_fout, "2905\n");
    fflush(_coverage_fout);
    *tmp___10 = (long long )*tmp___11;
    fprintf(_coverage_fout, "2906\n");
    fflush(_coverage_fout);
    n___5 ++;
  }
  break;
  }
  fprintf(_coverage_fout, "2939\n");
  fflush(_coverage_fout);
  _TIFFfree(origdata);
  fprintf(_coverage_fout, "2940\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "2931\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)data);
    fprintf(_coverage_fout, "2932\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "2933\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2941\n");
  fflush(_coverage_fout);
  *value = data;
  fprintf(_coverage_fout, "2942\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryFloatArray(TIFF *tif ,
                                                           TIFFDirEntry *direntry ,
                                                           float **value ) 
{ enum TIFFReadDirEntryErr err ;
  uint32 count ;
  void *origdata ;
  float *data ;
  void *tmp ;
  uint8 *ma ;
  float *mb ;
  uint32 n ;
  float *tmp___0 ;
  uint8 *tmp___1 ;
  int8 *ma___0 ;
  float *mb___0 ;
  uint32 n___0 ;
  float *tmp___2 ;
  int8 *tmp___3 ;
  uint16 *ma___1 ;
  float *mb___1 ;
  uint32 n___1 ;
  float *tmp___4 ;
  uint16 *tmp___5 ;
  int16 *ma___2 ;
  float *mb___2 ;
  uint32 n___2 ;
  float *tmp___6 ;
  int16 *tmp___7 ;
  uint32 *ma___3 ;
  float *mb___3 ;
  uint32 n___3 ;
  float *tmp___8 ;
  uint32 *tmp___9 ;
  int32 *ma___4 ;
  float *mb___4 ;
  uint32 n___4 ;
  float *tmp___10 ;
  int32 *tmp___11 ;
  uint64 *ma___5 ;
  float *mb___5 ;
  uint32 n___5 ;
  float *tmp___12 ;
  uint64 *tmp___13 ;
  int64 *ma___6 ;
  float *mb___6 ;
  uint32 n___6 ;
  float *tmp___14 ;
  int64 *tmp___15 ;
  uint32 *ma___7 ;
  uint32 maa ;
  uint32 mab ;
  float *mb___7 ;
  uint32 n___7 ;
  uint32 *tmp___16 ;
  uint32 *tmp___17 ;
  float *tmp___18 ;
  float *tmp___19 ;
  uint32 *ma___8 ;
  int32 maa___0 ;
  uint32 mab___0 ;
  float *mb___8 ;
  uint32 n___8 ;
  uint32 *tmp___20 ;
  float *tmp___21 ;
  float *tmp___22 ;
  double *ma___9 ;
  float *mb___9 ;
  uint32 n___9 ;
  float *tmp___23 ;
  double *tmp___24 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  switch ((int )direntry->tdir_type) {
  case 1: 
  case 6: 
  case 3: 
  case 8: 
  case 4: 
  case 9: 
  case 16: 
  case 17: 
  case 5: 
  case 10: 
  case 11: 
  case 12: 
  break;
  fprintf(_coverage_fout, "2943\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "2944\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
  fprintf(_coverage_fout, "3142\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryArray(tif, direntry, & count, 4U, & origdata);
  fprintf(_coverage_fout, "3143\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "2945\n");
    fflush(_coverage_fout);
    *value = (float *)0;
    fprintf(_coverage_fout, "2946\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "2950\n");
    fflush(_coverage_fout);
    if ((unsigned int )origdata == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "2947\n");
      fflush(_coverage_fout);
      *value = (float *)0;
      fprintf(_coverage_fout, "2948\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "2949\n");
      fflush(_coverage_fout);

    }
  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "2953\n");
  fflush(_coverage_fout);
  case 11: 
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "2951\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong((uint32 *)origdata, (long )count);
  } else {
    fprintf(_coverage_fout, "2952\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "2954\n");
  fflush(_coverage_fout);
  *value = (float *)origdata;
  fprintf(_coverage_fout, "2955\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  }
  fprintf(_coverage_fout, "3144\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )(count * sizeof(float )));
  fprintf(_coverage_fout, "3145\n");
  fflush(_coverage_fout);
  data = (float *)tmp;
  fprintf(_coverage_fout, "3146\n");
  fflush(_coverage_fout);
  if ((unsigned int )data == (unsigned int )((float *)0)) {
    fprintf(_coverage_fout, "2956\n");
    fflush(_coverage_fout);
    _TIFFfree(origdata);
    fprintf(_coverage_fout, "2957\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )7);
  } else {
    fprintf(_coverage_fout, "2958\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "3094\n");
  fflush(_coverage_fout);
  case 1: 
  ma = (uint8 *)origdata;
  fprintf(_coverage_fout, "3095\n");
  fflush(_coverage_fout);
  mb = data;
  fprintf(_coverage_fout, "3096\n");
  fflush(_coverage_fout);
  n = 0U;
  fprintf(_coverage_fout, "3097\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2960\n");
    fflush(_coverage_fout);
    if (n < count) {
      fprintf(_coverage_fout, "2959\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2961\n");
    fflush(_coverage_fout);
    tmp___0 = mb;
    fprintf(_coverage_fout, "2962\n");
    fflush(_coverage_fout);
    mb ++;
    fprintf(_coverage_fout, "2963\n");
    fflush(_coverage_fout);
    tmp___1 = ma;
    fprintf(_coverage_fout, "2964\n");
    fflush(_coverage_fout);
    ma ++;
    fprintf(_coverage_fout, "2965\n");
    fflush(_coverage_fout);
    *tmp___0 = (float )*tmp___1;
    fprintf(_coverage_fout, "2966\n");
    fflush(_coverage_fout);
    n ++;
  }
  break;
  fprintf(_coverage_fout, "3098\n");
  fflush(_coverage_fout);
  case 6: 
  ma___0 = (int8 *)origdata;
  fprintf(_coverage_fout, "3099\n");
  fflush(_coverage_fout);
  mb___0 = data;
  fprintf(_coverage_fout, "3100\n");
  fflush(_coverage_fout);
  n___0 = 0U;
  fprintf(_coverage_fout, "3101\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2968\n");
    fflush(_coverage_fout);
    if (n___0 < count) {
      fprintf(_coverage_fout, "2967\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2969\n");
    fflush(_coverage_fout);
    tmp___2 = mb___0;
    fprintf(_coverage_fout, "2970\n");
    fflush(_coverage_fout);
    mb___0 ++;
    fprintf(_coverage_fout, "2971\n");
    fflush(_coverage_fout);
    tmp___3 = ma___0;
    fprintf(_coverage_fout, "2972\n");
    fflush(_coverage_fout);
    ma___0 ++;
    fprintf(_coverage_fout, "2973\n");
    fflush(_coverage_fout);
    *tmp___2 = (float )*tmp___3;
    fprintf(_coverage_fout, "2974\n");
    fflush(_coverage_fout);
    n___0 ++;
  }
  break;
  fprintf(_coverage_fout, "3102\n");
  fflush(_coverage_fout);
  case 3: 
  ma___1 = (uint16 *)origdata;
  fprintf(_coverage_fout, "3103\n");
  fflush(_coverage_fout);
  mb___1 = data;
  fprintf(_coverage_fout, "3104\n");
  fflush(_coverage_fout);
  n___1 = 0U;
  fprintf(_coverage_fout, "3105\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2978\n");
    fflush(_coverage_fout);
    if (n___1 < count) {
      fprintf(_coverage_fout, "2975\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2979\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2976\n");
      fflush(_coverage_fout);
      TIFFSwabShort(ma___1);
    } else {
      fprintf(_coverage_fout, "2977\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2980\n");
    fflush(_coverage_fout);
    tmp___4 = mb___1;
    fprintf(_coverage_fout, "2981\n");
    fflush(_coverage_fout);
    mb___1 ++;
    fprintf(_coverage_fout, "2982\n");
    fflush(_coverage_fout);
    tmp___5 = ma___1;
    fprintf(_coverage_fout, "2983\n");
    fflush(_coverage_fout);
    ma___1 ++;
    fprintf(_coverage_fout, "2984\n");
    fflush(_coverage_fout);
    *tmp___4 = (float )*tmp___5;
    fprintf(_coverage_fout, "2985\n");
    fflush(_coverage_fout);
    n___1 ++;
  }
  break;
  fprintf(_coverage_fout, "3106\n");
  fflush(_coverage_fout);
  case 8: 
  ma___2 = (int16 *)origdata;
  fprintf(_coverage_fout, "3107\n");
  fflush(_coverage_fout);
  mb___2 = data;
  fprintf(_coverage_fout, "3108\n");
  fflush(_coverage_fout);
  n___2 = 0U;
  fprintf(_coverage_fout, "3109\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "2989\n");
    fflush(_coverage_fout);
    if (n___2 < count) {
      fprintf(_coverage_fout, "2986\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "2990\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2987\n");
      fflush(_coverage_fout);
      TIFFSwabShort((uint16 *)ma___2);
    } else {
      fprintf(_coverage_fout, "2988\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "2991\n");
    fflush(_coverage_fout);
    tmp___6 = mb___2;
    fprintf(_coverage_fout, "2992\n");
    fflush(_coverage_fout);
    mb___2 ++;
    fprintf(_coverage_fout, "2993\n");
    fflush(_coverage_fout);
    tmp___7 = ma___2;
    fprintf(_coverage_fout, "2994\n");
    fflush(_coverage_fout);
    ma___2 ++;
    fprintf(_coverage_fout, "2995\n");
    fflush(_coverage_fout);
    *tmp___6 = (float )*tmp___7;
    fprintf(_coverage_fout, "2996\n");
    fflush(_coverage_fout);
    n___2 ++;
  }
  break;
  fprintf(_coverage_fout, "3110\n");
  fflush(_coverage_fout);
  case 4: 
  ma___3 = (uint32 *)origdata;
  fprintf(_coverage_fout, "3111\n");
  fflush(_coverage_fout);
  mb___3 = data;
  fprintf(_coverage_fout, "3112\n");
  fflush(_coverage_fout);
  n___3 = 0U;
  fprintf(_coverage_fout, "3113\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3000\n");
    fflush(_coverage_fout);
    if (n___3 < count) {
      fprintf(_coverage_fout, "2997\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3001\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "2998\n");
      fflush(_coverage_fout);
      TIFFSwabLong(ma___3);
    } else {
      fprintf(_coverage_fout, "2999\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3002\n");
    fflush(_coverage_fout);
    tmp___8 = mb___3;
    fprintf(_coverage_fout, "3003\n");
    fflush(_coverage_fout);
    mb___3 ++;
    fprintf(_coverage_fout, "3004\n");
    fflush(_coverage_fout);
    tmp___9 = ma___3;
    fprintf(_coverage_fout, "3005\n");
    fflush(_coverage_fout);
    ma___3 ++;
    fprintf(_coverage_fout, "3006\n");
    fflush(_coverage_fout);
    *tmp___8 = (float )*tmp___9;
    fprintf(_coverage_fout, "3007\n");
    fflush(_coverage_fout);
    n___3 ++;
  }
  break;
  fprintf(_coverage_fout, "3114\n");
  fflush(_coverage_fout);
  case 9: 
  ma___4 = (int32 *)origdata;
  fprintf(_coverage_fout, "3115\n");
  fflush(_coverage_fout);
  mb___4 = data;
  fprintf(_coverage_fout, "3116\n");
  fflush(_coverage_fout);
  n___4 = 0U;
  fprintf(_coverage_fout, "3117\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3011\n");
    fflush(_coverage_fout);
    if (n___4 < count) {
      fprintf(_coverage_fout, "3008\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3012\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3009\n");
      fflush(_coverage_fout);
      TIFFSwabLong((uint32 *)ma___4);
    } else {
      fprintf(_coverage_fout, "3010\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3013\n");
    fflush(_coverage_fout);
    tmp___10 = mb___4;
    fprintf(_coverage_fout, "3014\n");
    fflush(_coverage_fout);
    mb___4 ++;
    fprintf(_coverage_fout, "3015\n");
    fflush(_coverage_fout);
    tmp___11 = ma___4;
    fprintf(_coverage_fout, "3016\n");
    fflush(_coverage_fout);
    ma___4 ++;
    fprintf(_coverage_fout, "3017\n");
    fflush(_coverage_fout);
    *tmp___10 = (float )*tmp___11;
    fprintf(_coverage_fout, "3018\n");
    fflush(_coverage_fout);
    n___4 ++;
  }
  break;
  fprintf(_coverage_fout, "3118\n");
  fflush(_coverage_fout);
  case 16: 
  ma___5 = (uint64 *)origdata;
  fprintf(_coverage_fout, "3119\n");
  fflush(_coverage_fout);
  mb___5 = data;
  fprintf(_coverage_fout, "3120\n");
  fflush(_coverage_fout);
  n___5 = 0U;
  fprintf(_coverage_fout, "3121\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3022\n");
    fflush(_coverage_fout);
    if (n___5 < count) {
      fprintf(_coverage_fout, "3019\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3023\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3020\n");
      fflush(_coverage_fout);
      TIFFSwabLong8(ma___5);
    } else {
      fprintf(_coverage_fout, "3021\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3024\n");
    fflush(_coverage_fout);
    tmp___12 = mb___5;
    fprintf(_coverage_fout, "3025\n");
    fflush(_coverage_fout);
    mb___5 ++;
    fprintf(_coverage_fout, "3026\n");
    fflush(_coverage_fout);
    tmp___13 = ma___5;
    fprintf(_coverage_fout, "3027\n");
    fflush(_coverage_fout);
    ma___5 ++;
    fprintf(_coverage_fout, "3028\n");
    fflush(_coverage_fout);
    *tmp___12 = (float )*tmp___13;
    fprintf(_coverage_fout, "3029\n");
    fflush(_coverage_fout);
    n___5 ++;
  }
  break;
  fprintf(_coverage_fout, "3122\n");
  fflush(_coverage_fout);
  case 17: 
  ma___6 = (int64 *)origdata;
  fprintf(_coverage_fout, "3123\n");
  fflush(_coverage_fout);
  mb___6 = data;
  fprintf(_coverage_fout, "3124\n");
  fflush(_coverage_fout);
  n___6 = 0U;
  fprintf(_coverage_fout, "3125\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3033\n");
    fflush(_coverage_fout);
    if (n___6 < count) {
      fprintf(_coverage_fout, "3030\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3034\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3031\n");
      fflush(_coverage_fout);
      TIFFSwabLong8((uint64 *)ma___6);
    } else {
      fprintf(_coverage_fout, "3032\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3035\n");
    fflush(_coverage_fout);
    tmp___14 = mb___6;
    fprintf(_coverage_fout, "3036\n");
    fflush(_coverage_fout);
    mb___6 ++;
    fprintf(_coverage_fout, "3037\n");
    fflush(_coverage_fout);
    tmp___15 = ma___6;
    fprintf(_coverage_fout, "3038\n");
    fflush(_coverage_fout);
    ma___6 ++;
    fprintf(_coverage_fout, "3039\n");
    fflush(_coverage_fout);
    *tmp___14 = (float )*tmp___15;
    fprintf(_coverage_fout, "3040\n");
    fflush(_coverage_fout);
    n___6 ++;
  }
  break;
  fprintf(_coverage_fout, "3126\n");
  fflush(_coverage_fout);
  case 5: 
  ma___7 = (uint32 *)origdata;
  fprintf(_coverage_fout, "3127\n");
  fflush(_coverage_fout);
  mb___7 = data;
  fprintf(_coverage_fout, "3128\n");
  fflush(_coverage_fout);
  n___7 = 0U;
  fprintf(_coverage_fout, "3129\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3052\n");
    fflush(_coverage_fout);
    if (n___7 < count) {
      fprintf(_coverage_fout, "3041\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3053\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3042\n");
      fflush(_coverage_fout);
      TIFFSwabLong(ma___7);
    } else {
      fprintf(_coverage_fout, "3043\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3054\n");
    fflush(_coverage_fout);
    tmp___16 = ma___7;
    fprintf(_coverage_fout, "3055\n");
    fflush(_coverage_fout);
    ma___7 ++;
    fprintf(_coverage_fout, "3056\n");
    fflush(_coverage_fout);
    maa = *tmp___16;
    fprintf(_coverage_fout, "3057\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3044\n");
      fflush(_coverage_fout);
      TIFFSwabLong(ma___7);
    } else {
      fprintf(_coverage_fout, "3045\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3058\n");
    fflush(_coverage_fout);
    tmp___17 = ma___7;
    fprintf(_coverage_fout, "3059\n");
    fflush(_coverage_fout);
    ma___7 ++;
    fprintf(_coverage_fout, "3060\n");
    fflush(_coverage_fout);
    mab = *tmp___17;
    fprintf(_coverage_fout, "3061\n");
    fflush(_coverage_fout);
    if (mab == 0U) {
      fprintf(_coverage_fout, "3046\n");
      fflush(_coverage_fout);
      tmp___18 = mb___7;
      fprintf(_coverage_fout, "3047\n");
      fflush(_coverage_fout);
      mb___7 ++;
      fprintf(_coverage_fout, "3048\n");
      fflush(_coverage_fout);
      *tmp___18 = (float )0.0;
    } else {
      fprintf(_coverage_fout, "3049\n");
      fflush(_coverage_fout);
      tmp___19 = mb___7;
      fprintf(_coverage_fout, "3050\n");
      fflush(_coverage_fout);
      mb___7 ++;
      fprintf(_coverage_fout, "3051\n");
      fflush(_coverage_fout);
      *tmp___19 = (float )maa / (float )mab;
    }
    fprintf(_coverage_fout, "3062\n");
    fflush(_coverage_fout);
    n___7 ++;
  }
  break;
  fprintf(_coverage_fout, "3130\n");
  fflush(_coverage_fout);
  case 10: 
  ma___8 = (uint32 *)origdata;
  fprintf(_coverage_fout, "3131\n");
  fflush(_coverage_fout);
  mb___8 = data;
  fprintf(_coverage_fout, "3132\n");
  fflush(_coverage_fout);
  n___8 = 0U;
  fprintf(_coverage_fout, "3133\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3074\n");
    fflush(_coverage_fout);
    if (n___8 < count) {
      fprintf(_coverage_fout, "3063\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3075\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3064\n");
      fflush(_coverage_fout);
      TIFFSwabLong(ma___8);
    } else {
      fprintf(_coverage_fout, "3065\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3076\n");
    fflush(_coverage_fout);
    maa___0 = *((int32 *)ma___8);
    fprintf(_coverage_fout, "3077\n");
    fflush(_coverage_fout);
    ma___8 ++;
    fprintf(_coverage_fout, "3078\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3066\n");
      fflush(_coverage_fout);
      TIFFSwabLong(ma___8);
    } else {
      fprintf(_coverage_fout, "3067\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3079\n");
    fflush(_coverage_fout);
    tmp___20 = ma___8;
    fprintf(_coverage_fout, "3080\n");
    fflush(_coverage_fout);
    ma___8 ++;
    fprintf(_coverage_fout, "3081\n");
    fflush(_coverage_fout);
    mab___0 = *tmp___20;
    fprintf(_coverage_fout, "3082\n");
    fflush(_coverage_fout);
    if (mab___0 == 0U) {
      fprintf(_coverage_fout, "3068\n");
      fflush(_coverage_fout);
      tmp___21 = mb___8;
      fprintf(_coverage_fout, "3069\n");
      fflush(_coverage_fout);
      mb___8 ++;
      fprintf(_coverage_fout, "3070\n");
      fflush(_coverage_fout);
      *tmp___21 = (float )0.0;
    } else {
      fprintf(_coverage_fout, "3071\n");
      fflush(_coverage_fout);
      tmp___22 = mb___8;
      fprintf(_coverage_fout, "3072\n");
      fflush(_coverage_fout);
      mb___8 ++;
      fprintf(_coverage_fout, "3073\n");
      fflush(_coverage_fout);
      *tmp___22 = (float )maa___0 / (float )mab___0;
    }
    fprintf(_coverage_fout, "3083\n");
    fflush(_coverage_fout);
    n___8 ++;
  }
  break;
  fprintf(_coverage_fout, "3134\n");
  fflush(_coverage_fout);
  case 12: 
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "3084\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong8((uint64 *)origdata, (long )count);
  } else {
    fprintf(_coverage_fout, "3085\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3135\n");
  fflush(_coverage_fout);
  ma___9 = (double *)origdata;
  fprintf(_coverage_fout, "3136\n");
  fflush(_coverage_fout);
  mb___9 = data;
  fprintf(_coverage_fout, "3137\n");
  fflush(_coverage_fout);
  n___9 = 0U;
  fprintf(_coverage_fout, "3138\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3087\n");
    fflush(_coverage_fout);
    if (n___9 < count) {
      fprintf(_coverage_fout, "3086\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3088\n");
    fflush(_coverage_fout);
    tmp___23 = mb___9;
    fprintf(_coverage_fout, "3089\n");
    fflush(_coverage_fout);
    mb___9 ++;
    fprintf(_coverage_fout, "3090\n");
    fflush(_coverage_fout);
    tmp___24 = ma___9;
    fprintf(_coverage_fout, "3091\n");
    fflush(_coverage_fout);
    ma___9 ++;
    fprintf(_coverage_fout, "3092\n");
    fflush(_coverage_fout);
    *tmp___23 = (float )*tmp___24;
    fprintf(_coverage_fout, "3093\n");
    fflush(_coverage_fout);
    n___9 ++;
  }
  break;
  }
  fprintf(_coverage_fout, "3147\n");
  fflush(_coverage_fout);
  _TIFFfree(origdata);
  fprintf(_coverage_fout, "3148\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "3139\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)data);
    fprintf(_coverage_fout, "3140\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "3141\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3149\n");
  fflush(_coverage_fout);
  *value = data;
  fprintf(_coverage_fout, "3150\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryDoubleArray(TIFF *tif ,
                                                            TIFFDirEntry *direntry ,
                                                            double **value ) 
{ enum TIFFReadDirEntryErr err ;
  uint32 count ;
  void *origdata ;
  double *data ;
  void *tmp ;
  uint8 *ma ;
  double *mb ;
  uint32 n ;
  double *tmp___0 ;
  uint8 *tmp___1 ;
  int8 *ma___0 ;
  double *mb___0 ;
  uint32 n___0 ;
  double *tmp___2 ;
  int8 *tmp___3 ;
  uint16 *ma___1 ;
  double *mb___1 ;
  uint32 n___1 ;
  double *tmp___4 ;
  uint16 *tmp___5 ;
  int16 *ma___2 ;
  double *mb___2 ;
  uint32 n___2 ;
  double *tmp___6 ;
  int16 *tmp___7 ;
  uint32 *ma___3 ;
  double *mb___3 ;
  uint32 n___3 ;
  double *tmp___8 ;
  uint32 *tmp___9 ;
  int32 *ma___4 ;
  double *mb___4 ;
  uint32 n___4 ;
  double *tmp___10 ;
  int32 *tmp___11 ;
  uint64 *ma___5 ;
  double *mb___5 ;
  uint32 n___5 ;
  double *tmp___12 ;
  uint64 *tmp___13 ;
  int64 *ma___6 ;
  double *mb___6 ;
  uint32 n___6 ;
  double *tmp___14 ;
  int64 *tmp___15 ;
  uint32 *ma___7 ;
  uint32 maa ;
  uint32 mab ;
  double *mb___7 ;
  uint32 n___7 ;
  uint32 *tmp___16 ;
  uint32 *tmp___17 ;
  double *tmp___18 ;
  double *tmp___19 ;
  uint32 *ma___8 ;
  int32 maa___0 ;
  uint32 mab___0 ;
  double *mb___8 ;
  uint32 n___8 ;
  uint32 *tmp___20 ;
  double *tmp___21 ;
  double *tmp___22 ;
  float *ma___9 ;
  double *mb___9 ;
  uint32 n___9 ;
  double *tmp___23 ;
  float *tmp___24 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  switch ((int )direntry->tdir_type) {
  case 1: 
  case 6: 
  case 3: 
  case 8: 
  case 4: 
  case 9: 
  case 16: 
  case 17: 
  case 5: 
  case 10: 
  case 11: 
  case 12: 
  break;
  fprintf(_coverage_fout, "3151\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "3152\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
  fprintf(_coverage_fout, "3350\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryArray(tif, direntry, & count, 8U, & origdata);
  fprintf(_coverage_fout, "3351\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "3153\n");
    fflush(_coverage_fout);
    *value = (double *)0;
    fprintf(_coverage_fout, "3154\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "3158\n");
    fflush(_coverage_fout);
    if ((unsigned int )origdata == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "3155\n");
      fflush(_coverage_fout);
      *value = (double *)0;
      fprintf(_coverage_fout, "3156\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "3157\n");
      fflush(_coverage_fout);

    }
  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "3161\n");
  fflush(_coverage_fout);
  case 12: 
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "3159\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong8((uint64 *)origdata, (long )count);
  } else {
    fprintf(_coverage_fout, "3160\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3162\n");
  fflush(_coverage_fout);
  *value = (double *)origdata;
  fprintf(_coverage_fout, "3163\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  }
  fprintf(_coverage_fout, "3352\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )(count * sizeof(double )));
  fprintf(_coverage_fout, "3353\n");
  fflush(_coverage_fout);
  data = (double *)tmp;
  fprintf(_coverage_fout, "3354\n");
  fflush(_coverage_fout);
  if ((unsigned int )data == (unsigned int )((double *)0)) {
    fprintf(_coverage_fout, "3164\n");
    fflush(_coverage_fout);
    _TIFFfree(origdata);
    fprintf(_coverage_fout, "3165\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )7);
  } else {
    fprintf(_coverage_fout, "3166\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "3302\n");
  fflush(_coverage_fout);
  case 1: 
  ma = (uint8 *)origdata;
  fprintf(_coverage_fout, "3303\n");
  fflush(_coverage_fout);
  mb = data;
  fprintf(_coverage_fout, "3304\n");
  fflush(_coverage_fout);
  n = 0U;
  fprintf(_coverage_fout, "3305\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3168\n");
    fflush(_coverage_fout);
    if (n < count) {
      fprintf(_coverage_fout, "3167\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3169\n");
    fflush(_coverage_fout);
    tmp___0 = mb;
    fprintf(_coverage_fout, "3170\n");
    fflush(_coverage_fout);
    mb ++;
    fprintf(_coverage_fout, "3171\n");
    fflush(_coverage_fout);
    tmp___1 = ma;
    fprintf(_coverage_fout, "3172\n");
    fflush(_coverage_fout);
    ma ++;
    fprintf(_coverage_fout, "3173\n");
    fflush(_coverage_fout);
    *tmp___0 = (double )*tmp___1;
    fprintf(_coverage_fout, "3174\n");
    fflush(_coverage_fout);
    n ++;
  }
  break;
  fprintf(_coverage_fout, "3306\n");
  fflush(_coverage_fout);
  case 6: 
  ma___0 = (int8 *)origdata;
  fprintf(_coverage_fout, "3307\n");
  fflush(_coverage_fout);
  mb___0 = data;
  fprintf(_coverage_fout, "3308\n");
  fflush(_coverage_fout);
  n___0 = 0U;
  fprintf(_coverage_fout, "3309\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3176\n");
    fflush(_coverage_fout);
    if (n___0 < count) {
      fprintf(_coverage_fout, "3175\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3177\n");
    fflush(_coverage_fout);
    tmp___2 = mb___0;
    fprintf(_coverage_fout, "3178\n");
    fflush(_coverage_fout);
    mb___0 ++;
    fprintf(_coverage_fout, "3179\n");
    fflush(_coverage_fout);
    tmp___3 = ma___0;
    fprintf(_coverage_fout, "3180\n");
    fflush(_coverage_fout);
    ma___0 ++;
    fprintf(_coverage_fout, "3181\n");
    fflush(_coverage_fout);
    *tmp___2 = (double )*tmp___3;
    fprintf(_coverage_fout, "3182\n");
    fflush(_coverage_fout);
    n___0 ++;
  }
  break;
  fprintf(_coverage_fout, "3310\n");
  fflush(_coverage_fout);
  case 3: 
  ma___1 = (uint16 *)origdata;
  fprintf(_coverage_fout, "3311\n");
  fflush(_coverage_fout);
  mb___1 = data;
  fprintf(_coverage_fout, "3312\n");
  fflush(_coverage_fout);
  n___1 = 0U;
  fprintf(_coverage_fout, "3313\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3186\n");
    fflush(_coverage_fout);
    if (n___1 < count) {
      fprintf(_coverage_fout, "3183\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3187\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3184\n");
      fflush(_coverage_fout);
      TIFFSwabShort(ma___1);
    } else {
      fprintf(_coverage_fout, "3185\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3188\n");
    fflush(_coverage_fout);
    tmp___4 = mb___1;
    fprintf(_coverage_fout, "3189\n");
    fflush(_coverage_fout);
    mb___1 ++;
    fprintf(_coverage_fout, "3190\n");
    fflush(_coverage_fout);
    tmp___5 = ma___1;
    fprintf(_coverage_fout, "3191\n");
    fflush(_coverage_fout);
    ma___1 ++;
    fprintf(_coverage_fout, "3192\n");
    fflush(_coverage_fout);
    *tmp___4 = (double )*tmp___5;
    fprintf(_coverage_fout, "3193\n");
    fflush(_coverage_fout);
    n___1 ++;
  }
  break;
  fprintf(_coverage_fout, "3314\n");
  fflush(_coverage_fout);
  case 8: 
  ma___2 = (int16 *)origdata;
  fprintf(_coverage_fout, "3315\n");
  fflush(_coverage_fout);
  mb___2 = data;
  fprintf(_coverage_fout, "3316\n");
  fflush(_coverage_fout);
  n___2 = 0U;
  fprintf(_coverage_fout, "3317\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3197\n");
    fflush(_coverage_fout);
    if (n___2 < count) {
      fprintf(_coverage_fout, "3194\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3198\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3195\n");
      fflush(_coverage_fout);
      TIFFSwabShort((uint16 *)ma___2);
    } else {
      fprintf(_coverage_fout, "3196\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3199\n");
    fflush(_coverage_fout);
    tmp___6 = mb___2;
    fprintf(_coverage_fout, "3200\n");
    fflush(_coverage_fout);
    mb___2 ++;
    fprintf(_coverage_fout, "3201\n");
    fflush(_coverage_fout);
    tmp___7 = ma___2;
    fprintf(_coverage_fout, "3202\n");
    fflush(_coverage_fout);
    ma___2 ++;
    fprintf(_coverage_fout, "3203\n");
    fflush(_coverage_fout);
    *tmp___6 = (double )*tmp___7;
    fprintf(_coverage_fout, "3204\n");
    fflush(_coverage_fout);
    n___2 ++;
  }
  break;
  fprintf(_coverage_fout, "3318\n");
  fflush(_coverage_fout);
  case 4: 
  ma___3 = (uint32 *)origdata;
  fprintf(_coverage_fout, "3319\n");
  fflush(_coverage_fout);
  mb___3 = data;
  fprintf(_coverage_fout, "3320\n");
  fflush(_coverage_fout);
  n___3 = 0U;
  fprintf(_coverage_fout, "3321\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3208\n");
    fflush(_coverage_fout);
    if (n___3 < count) {
      fprintf(_coverage_fout, "3205\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3209\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3206\n");
      fflush(_coverage_fout);
      TIFFSwabLong(ma___3);
    } else {
      fprintf(_coverage_fout, "3207\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3210\n");
    fflush(_coverage_fout);
    tmp___8 = mb___3;
    fprintf(_coverage_fout, "3211\n");
    fflush(_coverage_fout);
    mb___3 ++;
    fprintf(_coverage_fout, "3212\n");
    fflush(_coverage_fout);
    tmp___9 = ma___3;
    fprintf(_coverage_fout, "3213\n");
    fflush(_coverage_fout);
    ma___3 ++;
    fprintf(_coverage_fout, "3214\n");
    fflush(_coverage_fout);
    *tmp___8 = (double )*tmp___9;
    fprintf(_coverage_fout, "3215\n");
    fflush(_coverage_fout);
    n___3 ++;
  }
  break;
  fprintf(_coverage_fout, "3322\n");
  fflush(_coverage_fout);
  case 9: 
  ma___4 = (int32 *)origdata;
  fprintf(_coverage_fout, "3323\n");
  fflush(_coverage_fout);
  mb___4 = data;
  fprintf(_coverage_fout, "3324\n");
  fflush(_coverage_fout);
  n___4 = 0U;
  fprintf(_coverage_fout, "3325\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3219\n");
    fflush(_coverage_fout);
    if (n___4 < count) {
      fprintf(_coverage_fout, "3216\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3220\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3217\n");
      fflush(_coverage_fout);
      TIFFSwabLong((uint32 *)ma___4);
    } else {
      fprintf(_coverage_fout, "3218\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3221\n");
    fflush(_coverage_fout);
    tmp___10 = mb___4;
    fprintf(_coverage_fout, "3222\n");
    fflush(_coverage_fout);
    mb___4 ++;
    fprintf(_coverage_fout, "3223\n");
    fflush(_coverage_fout);
    tmp___11 = ma___4;
    fprintf(_coverage_fout, "3224\n");
    fflush(_coverage_fout);
    ma___4 ++;
    fprintf(_coverage_fout, "3225\n");
    fflush(_coverage_fout);
    *tmp___10 = (double )*tmp___11;
    fprintf(_coverage_fout, "3226\n");
    fflush(_coverage_fout);
    n___4 ++;
  }
  break;
  fprintf(_coverage_fout, "3326\n");
  fflush(_coverage_fout);
  case 16: 
  ma___5 = (uint64 *)origdata;
  fprintf(_coverage_fout, "3327\n");
  fflush(_coverage_fout);
  mb___5 = data;
  fprintf(_coverage_fout, "3328\n");
  fflush(_coverage_fout);
  n___5 = 0U;
  fprintf(_coverage_fout, "3329\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3230\n");
    fflush(_coverage_fout);
    if (n___5 < count) {
      fprintf(_coverage_fout, "3227\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3231\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3228\n");
      fflush(_coverage_fout);
      TIFFSwabLong8(ma___5);
    } else {
      fprintf(_coverage_fout, "3229\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3232\n");
    fflush(_coverage_fout);
    tmp___12 = mb___5;
    fprintf(_coverage_fout, "3233\n");
    fflush(_coverage_fout);
    mb___5 ++;
    fprintf(_coverage_fout, "3234\n");
    fflush(_coverage_fout);
    tmp___13 = ma___5;
    fprintf(_coverage_fout, "3235\n");
    fflush(_coverage_fout);
    ma___5 ++;
    fprintf(_coverage_fout, "3236\n");
    fflush(_coverage_fout);
    *tmp___12 = (double )*tmp___13;
    fprintf(_coverage_fout, "3237\n");
    fflush(_coverage_fout);
    n___5 ++;
  }
  break;
  fprintf(_coverage_fout, "3330\n");
  fflush(_coverage_fout);
  case 17: 
  ma___6 = (int64 *)origdata;
  fprintf(_coverage_fout, "3331\n");
  fflush(_coverage_fout);
  mb___6 = data;
  fprintf(_coverage_fout, "3332\n");
  fflush(_coverage_fout);
  n___6 = 0U;
  fprintf(_coverage_fout, "3333\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3241\n");
    fflush(_coverage_fout);
    if (n___6 < count) {
      fprintf(_coverage_fout, "3238\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3242\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3239\n");
      fflush(_coverage_fout);
      TIFFSwabLong8((uint64 *)ma___6);
    } else {
      fprintf(_coverage_fout, "3240\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3243\n");
    fflush(_coverage_fout);
    tmp___14 = mb___6;
    fprintf(_coverage_fout, "3244\n");
    fflush(_coverage_fout);
    mb___6 ++;
    fprintf(_coverage_fout, "3245\n");
    fflush(_coverage_fout);
    tmp___15 = ma___6;
    fprintf(_coverage_fout, "3246\n");
    fflush(_coverage_fout);
    ma___6 ++;
    fprintf(_coverage_fout, "3247\n");
    fflush(_coverage_fout);
    *tmp___14 = (double )*tmp___15;
    fprintf(_coverage_fout, "3248\n");
    fflush(_coverage_fout);
    n___6 ++;
  }
  break;
  fprintf(_coverage_fout, "3334\n");
  fflush(_coverage_fout);
  case 5: 
  ma___7 = (uint32 *)origdata;
  fprintf(_coverage_fout, "3335\n");
  fflush(_coverage_fout);
  mb___7 = data;
  fprintf(_coverage_fout, "3336\n");
  fflush(_coverage_fout);
  n___7 = 0U;
  fprintf(_coverage_fout, "3337\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3260\n");
    fflush(_coverage_fout);
    if (n___7 < count) {
      fprintf(_coverage_fout, "3249\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3261\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3250\n");
      fflush(_coverage_fout);
      TIFFSwabLong(ma___7);
    } else {
      fprintf(_coverage_fout, "3251\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3262\n");
    fflush(_coverage_fout);
    tmp___16 = ma___7;
    fprintf(_coverage_fout, "3263\n");
    fflush(_coverage_fout);
    ma___7 ++;
    fprintf(_coverage_fout, "3264\n");
    fflush(_coverage_fout);
    maa = *tmp___16;
    fprintf(_coverage_fout, "3265\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3252\n");
      fflush(_coverage_fout);
      TIFFSwabLong(ma___7);
    } else {
      fprintf(_coverage_fout, "3253\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3266\n");
    fflush(_coverage_fout);
    tmp___17 = ma___7;
    fprintf(_coverage_fout, "3267\n");
    fflush(_coverage_fout);
    ma___7 ++;
    fprintf(_coverage_fout, "3268\n");
    fflush(_coverage_fout);
    mab = *tmp___17;
    fprintf(_coverage_fout, "3269\n");
    fflush(_coverage_fout);
    if (mab == 0U) {
      fprintf(_coverage_fout, "3254\n");
      fflush(_coverage_fout);
      tmp___18 = mb___7;
      fprintf(_coverage_fout, "3255\n");
      fflush(_coverage_fout);
      mb___7 ++;
      fprintf(_coverage_fout, "3256\n");
      fflush(_coverage_fout);
      *tmp___18 = 0.0;
    } else {
      fprintf(_coverage_fout, "3257\n");
      fflush(_coverage_fout);
      tmp___19 = mb___7;
      fprintf(_coverage_fout, "3258\n");
      fflush(_coverage_fout);
      mb___7 ++;
      fprintf(_coverage_fout, "3259\n");
      fflush(_coverage_fout);
      *tmp___19 = (double )maa / (double )mab;
    }
    fprintf(_coverage_fout, "3270\n");
    fflush(_coverage_fout);
    n___7 ++;
  }
  break;
  fprintf(_coverage_fout, "3338\n");
  fflush(_coverage_fout);
  case 10: 
  ma___8 = (uint32 *)origdata;
  fprintf(_coverage_fout, "3339\n");
  fflush(_coverage_fout);
  mb___8 = data;
  fprintf(_coverage_fout, "3340\n");
  fflush(_coverage_fout);
  n___8 = 0U;
  fprintf(_coverage_fout, "3341\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3282\n");
    fflush(_coverage_fout);
    if (n___8 < count) {
      fprintf(_coverage_fout, "3271\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3283\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3272\n");
      fflush(_coverage_fout);
      TIFFSwabLong(ma___8);
    } else {
      fprintf(_coverage_fout, "3273\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3284\n");
    fflush(_coverage_fout);
    maa___0 = *((int32 *)ma___8);
    fprintf(_coverage_fout, "3285\n");
    fflush(_coverage_fout);
    ma___8 ++;
    fprintf(_coverage_fout, "3286\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3274\n");
      fflush(_coverage_fout);
      TIFFSwabLong(ma___8);
    } else {
      fprintf(_coverage_fout, "3275\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3287\n");
    fflush(_coverage_fout);
    tmp___20 = ma___8;
    fprintf(_coverage_fout, "3288\n");
    fflush(_coverage_fout);
    ma___8 ++;
    fprintf(_coverage_fout, "3289\n");
    fflush(_coverage_fout);
    mab___0 = *tmp___20;
    fprintf(_coverage_fout, "3290\n");
    fflush(_coverage_fout);
    if (mab___0 == 0U) {
      fprintf(_coverage_fout, "3276\n");
      fflush(_coverage_fout);
      tmp___21 = mb___8;
      fprintf(_coverage_fout, "3277\n");
      fflush(_coverage_fout);
      mb___8 ++;
      fprintf(_coverage_fout, "3278\n");
      fflush(_coverage_fout);
      *tmp___21 = 0.0;
    } else {
      fprintf(_coverage_fout, "3279\n");
      fflush(_coverage_fout);
      tmp___22 = mb___8;
      fprintf(_coverage_fout, "3280\n");
      fflush(_coverage_fout);
      mb___8 ++;
      fprintf(_coverage_fout, "3281\n");
      fflush(_coverage_fout);
      *tmp___22 = (double )maa___0 / (double )mab___0;
    }
    fprintf(_coverage_fout, "3291\n");
    fflush(_coverage_fout);
    n___8 ++;
  }
  break;
  fprintf(_coverage_fout, "3342\n");
  fflush(_coverage_fout);
  case 11: 
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "3292\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong((uint32 *)origdata, (long )count);
  } else {
    fprintf(_coverage_fout, "3293\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3343\n");
  fflush(_coverage_fout);
  ma___9 = (float *)origdata;
  fprintf(_coverage_fout, "3344\n");
  fflush(_coverage_fout);
  mb___9 = data;
  fprintf(_coverage_fout, "3345\n");
  fflush(_coverage_fout);
  n___9 = 0U;
  fprintf(_coverage_fout, "3346\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3295\n");
    fflush(_coverage_fout);
    if (n___9 < count) {
      fprintf(_coverage_fout, "3294\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3296\n");
    fflush(_coverage_fout);
    tmp___23 = mb___9;
    fprintf(_coverage_fout, "3297\n");
    fflush(_coverage_fout);
    mb___9 ++;
    fprintf(_coverage_fout, "3298\n");
    fflush(_coverage_fout);
    tmp___24 = ma___9;
    fprintf(_coverage_fout, "3299\n");
    fflush(_coverage_fout);
    ma___9 ++;
    fprintf(_coverage_fout, "3300\n");
    fflush(_coverage_fout);
    *tmp___23 = (double )*tmp___24;
    fprintf(_coverage_fout, "3301\n");
    fflush(_coverage_fout);
    n___9 ++;
  }
  break;
  }
  fprintf(_coverage_fout, "3355\n");
  fflush(_coverage_fout);
  _TIFFfree(origdata);
  fprintf(_coverage_fout, "3356\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "3347\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)data);
    fprintf(_coverage_fout, "3348\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "3349\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3357\n");
  fflush(_coverage_fout);
  *value = data;
  fprintf(_coverage_fout, "3358\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryIfd8Array(TIFF *tif ,
                                                          TIFFDirEntry *direntry ,
                                                          uint64 **value ) 
{ enum TIFFReadDirEntryErr err ;
  uint32 count ;
  void *origdata ;
  uint64 *data ;
  void *tmp ;
  uint32 *ma ;
  uint64 *mb ;
  uint32 n ;
  uint64 *tmp___0 ;
  uint32 *tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  switch ((int )direntry->tdir_type) {
  case 4: 
  case 16: 
  case 13: 
  case 18: 
  break;
  fprintf(_coverage_fout, "3359\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "3360\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )2);
  }
  fprintf(_coverage_fout, "3393\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryArray(tif, direntry, & count, 8U, & origdata);
  fprintf(_coverage_fout, "3394\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "3361\n");
    fflush(_coverage_fout);
    *value = (uint64 *)0;
    fprintf(_coverage_fout, "3362\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "3366\n");
    fflush(_coverage_fout);
    if ((unsigned int )origdata == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "3363\n");
      fflush(_coverage_fout);
      *value = (uint64 *)0;
      fprintf(_coverage_fout, "3364\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "3365\n");
      fflush(_coverage_fout);

    }
  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "3369\n");
  fflush(_coverage_fout);
  case 16: 
  case 18: 
  *value = (uint64 *)origdata;
  fprintf(_coverage_fout, "3370\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "3367\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong8(*value, (long )count);
  } else {
    fprintf(_coverage_fout, "3368\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3371\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
  }
  fprintf(_coverage_fout, "3395\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )(count * 8U));
  fprintf(_coverage_fout, "3396\n");
  fflush(_coverage_fout);
  data = (uint64 *)tmp;
  fprintf(_coverage_fout, "3397\n");
  fflush(_coverage_fout);
  if ((unsigned int )data == (unsigned int )((uint64 *)0)) {
    fprintf(_coverage_fout, "3372\n");
    fflush(_coverage_fout);
    _TIFFfree(origdata);
    fprintf(_coverage_fout, "3373\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )7);
  } else {
    fprintf(_coverage_fout, "3374\n");
    fflush(_coverage_fout);

  }
  switch ((int )direntry->tdir_type) {
  fprintf(_coverage_fout, "3386\n");
  fflush(_coverage_fout);
  case 4: 
  case 13: 
  ma = (uint32 *)origdata;
  fprintf(_coverage_fout, "3387\n");
  fflush(_coverage_fout);
  mb = data;
  fprintf(_coverage_fout, "3388\n");
  fflush(_coverage_fout);
  n = 0U;
  fprintf(_coverage_fout, "3389\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3378\n");
    fflush(_coverage_fout);
    if (n < count) {
      fprintf(_coverage_fout, "3375\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3379\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3376\n");
      fflush(_coverage_fout);
      TIFFSwabLong(ma);
    } else {
      fprintf(_coverage_fout, "3377\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3380\n");
    fflush(_coverage_fout);
    tmp___0 = mb;
    fprintf(_coverage_fout, "3381\n");
    fflush(_coverage_fout);
    mb ++;
    fprintf(_coverage_fout, "3382\n");
    fflush(_coverage_fout);
    tmp___1 = ma;
    fprintf(_coverage_fout, "3383\n");
    fflush(_coverage_fout);
    ma ++;
    fprintf(_coverage_fout, "3384\n");
    fflush(_coverage_fout);
    *tmp___0 = (unsigned long long )*tmp___1;
    fprintf(_coverage_fout, "3385\n");
    fflush(_coverage_fout);
    n ++;
  }
  break;
  }
  fprintf(_coverage_fout, "3398\n");
  fflush(_coverage_fout);
  _TIFFfree(origdata);
  fprintf(_coverage_fout, "3399\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "3390\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)data);
    fprintf(_coverage_fout, "3391\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "3392\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3400\n");
  fflush(_coverage_fout);
  *value = data;
  fprintf(_coverage_fout, "3401\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryPersampleShort(TIFF *tif ,
                                                               TIFFDirEntry *direntry ,
                                                               uint16 *value ) 
{ enum TIFFReadDirEntryErr err ;
  uint16 *m ;
  uint16 *na ;
  uint16 nb ;
  uint16 *tmp ;
  uint16 *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3414\n");
  fflush(_coverage_fout);
  if (direntry->tdir_count != (unsigned long long )tif->tif_dir.td_samplesperpixel) {
    fprintf(_coverage_fout, "3402\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )1);
  } else {
    fprintf(_coverage_fout, "3403\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3415\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryShortArray(tif, direntry, & m);
  fprintf(_coverage_fout, "3416\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "3404\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "3405\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3417\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "3418\n");
  fflush(_coverage_fout);
  nb = tif->tif_dir.td_samplesperpixel;
  fprintf(_coverage_fout, "3419\n");
  fflush(_coverage_fout);
  tmp = na;
  fprintf(_coverage_fout, "3420\n");
  fflush(_coverage_fout);
  na ++;
  fprintf(_coverage_fout, "3421\n");
  fflush(_coverage_fout);
  *value = *tmp;
  fprintf(_coverage_fout, "3422\n");
  fflush(_coverage_fout);
  nb = (uint16 )((int )nb - 1);
  fprintf(_coverage_fout, "3423\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3409\n");
    fflush(_coverage_fout);
    if ((int )nb > 0) {
      fprintf(_coverage_fout, "3406\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3410\n");
    fflush(_coverage_fout);
    tmp___0 = na;
    fprintf(_coverage_fout, "3411\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "3412\n");
    fflush(_coverage_fout);
    if ((int )*tmp___0 != (int )*value) {
      fprintf(_coverage_fout, "3407\n");
      fflush(_coverage_fout);
      err = (enum TIFFReadDirEntryErr )5;
      break;
    } else {
      fprintf(_coverage_fout, "3408\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3413\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb - 1);
  }
  fprintf(_coverage_fout, "3424\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "3425\n");
  fflush(_coverage_fout);
  return (err);
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryPersampleDouble(TIFF *tif ,
                                                                TIFFDirEntry *direntry ,
                                                                double *value ) 
{ enum TIFFReadDirEntryErr err ;
  double *m ;
  double *na ;
  uint16 nb ;
  double *tmp ;
  double *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3438\n");
  fflush(_coverage_fout);
  if (direntry->tdir_count != (unsigned long long )tif->tif_dir.td_samplesperpixel) {
    fprintf(_coverage_fout, "3426\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )1);
  } else {
    fprintf(_coverage_fout, "3427\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3439\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryDoubleArray(tif, direntry, & m);
  fprintf(_coverage_fout, "3440\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "3428\n");
    fflush(_coverage_fout);
    return (err);
  } else {
    fprintf(_coverage_fout, "3429\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3441\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "3442\n");
  fflush(_coverage_fout);
  nb = tif->tif_dir.td_samplesperpixel;
  fprintf(_coverage_fout, "3443\n");
  fflush(_coverage_fout);
  tmp = na;
  fprintf(_coverage_fout, "3444\n");
  fflush(_coverage_fout);
  na ++;
  fprintf(_coverage_fout, "3445\n");
  fflush(_coverage_fout);
  *value = *tmp;
  fprintf(_coverage_fout, "3446\n");
  fflush(_coverage_fout);
  nb = (uint16 )((int )nb - 1);
  fprintf(_coverage_fout, "3447\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3433\n");
    fflush(_coverage_fout);
    if ((int )nb > 0) {
      fprintf(_coverage_fout, "3430\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3434\n");
    fflush(_coverage_fout);
    tmp___0 = na;
    fprintf(_coverage_fout, "3435\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "3436\n");
    fflush(_coverage_fout);
    if (*tmp___0 != *value) {
      fprintf(_coverage_fout, "3431\n");
      fflush(_coverage_fout);
      err = (enum TIFFReadDirEntryErr )5;
      break;
    } else {
      fprintf(_coverage_fout, "3432\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3437\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb - 1);
  }
  fprintf(_coverage_fout, "3448\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "3449\n");
  fflush(_coverage_fout);
  return (err);
}
}
static void TIFFReadDirEntryCheckedByte(TIFF *tif , TIFFDirEntry *direntry ,
                                        uint8 *value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3450\n");
  fflush(_coverage_fout);
  *value = *((uint8 *)(& direntry->tdir_offset));
  fprintf(_coverage_fout, "3451\n");
  fflush(_coverage_fout);
  return;
}
}
static void TIFFReadDirEntryCheckedSbyte(TIFF *tif , TIFFDirEntry *direntry ,
                                         int8 *value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3452\n");
  fflush(_coverage_fout);
  *value = *((int8 *)(& direntry->tdir_offset));
  fprintf(_coverage_fout, "3453\n");
  fflush(_coverage_fout);
  return;
}
}
static void TIFFReadDirEntryCheckedShort(TIFF *tif , TIFFDirEntry *direntry ,
                                         uint16 *value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3456\n");
  fflush(_coverage_fout);
  *value = *((uint16 *)(& direntry->tdir_offset));
  fprintf(_coverage_fout, "3457\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "3454\n");
    fflush(_coverage_fout);
    TIFFSwabShort(value);
  } else {
    fprintf(_coverage_fout, "3455\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3458\n");
  fflush(_coverage_fout);
  return;
}
}
static void TIFFReadDirEntryCheckedSshort(TIFF *tif , TIFFDirEntry *direntry ,
                                          int16 *value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3461\n");
  fflush(_coverage_fout);
  *value = *((int16 *)(& direntry->tdir_offset));
  fprintf(_coverage_fout, "3462\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "3459\n");
    fflush(_coverage_fout);
    TIFFSwabShort((uint16 *)value);
  } else {
    fprintf(_coverage_fout, "3460\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3463\n");
  fflush(_coverage_fout);
  return;
}
}
static void TIFFReadDirEntryCheckedLong(TIFF *tif , TIFFDirEntry *direntry ,
                                        uint32 *value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3466\n");
  fflush(_coverage_fout);
  *value = *((uint32 *)(& direntry->tdir_offset));
  fprintf(_coverage_fout, "3467\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "3464\n");
    fflush(_coverage_fout);
    TIFFSwabLong(value);
  } else {
    fprintf(_coverage_fout, "3465\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3468\n");
  fflush(_coverage_fout);
  return;
}
}
static void TIFFReadDirEntryCheckedSlong(TIFF *tif , TIFFDirEntry *direntry ,
                                         int32 *value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3471\n");
  fflush(_coverage_fout);
  *value = *((int32 *)(& direntry->tdir_offset));
  fprintf(_coverage_fout, "3472\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "3469\n");
    fflush(_coverage_fout);
    TIFFSwabLong((uint32 *)value);
  } else {
    fprintf(_coverage_fout, "3470\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3473\n");
  fflush(_coverage_fout);
  return;
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckedLong8(TIFF *tif ,
                                                             TIFFDirEntry *direntry ,
                                                             uint64 *value ) 
{ enum TIFFReadDirEntryErr err ;
  uint32 offset ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3485\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "3478\n");
    fflush(_coverage_fout);
    offset = *((uint32 *)(& direntry->tdir_offset));
    fprintf(_coverage_fout, "3479\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3474\n");
      fflush(_coverage_fout);
      TIFFSwabLong(& offset);
    } else {
      fprintf(_coverage_fout, "3475\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3480\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryData(tif, (unsigned long long )offset, 8L,
                               (void *)value);
    fprintf(_coverage_fout, "3481\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      fprintf(_coverage_fout, "3476\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "3477\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "3482\n");
    fflush(_coverage_fout);
    *value = direntry->tdir_offset;
  }
  fprintf(_coverage_fout, "3486\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "3483\n");
    fflush(_coverage_fout);
    TIFFSwabLong8(value);
  } else {
    fprintf(_coverage_fout, "3484\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3487\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckedSlong8(TIFF *tif ,
                                                              TIFFDirEntry *direntry ,
                                                              int64 *value ) 
{ enum TIFFReadDirEntryErr err ;
  uint32 offset ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3499\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "3492\n");
    fflush(_coverage_fout);
    offset = *((uint32 *)(& direntry->tdir_offset));
    fprintf(_coverage_fout, "3493\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3488\n");
      fflush(_coverage_fout);
      TIFFSwabLong(& offset);
    } else {
      fprintf(_coverage_fout, "3489\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3494\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryData(tif, (unsigned long long )offset, 8L,
                               (void *)value);
    fprintf(_coverage_fout, "3495\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      fprintf(_coverage_fout, "3490\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "3491\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "3496\n");
    fflush(_coverage_fout);
    *value = *((int64 *)(& direntry->tdir_offset));
  }
  fprintf(_coverage_fout, "3500\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "3497\n");
    fflush(_coverage_fout);
    TIFFSwabLong8((uint64 *)value);
  } else {
    fprintf(_coverage_fout, "3498\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3501\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckedRational(TIFF *tif ,
                                                                TIFFDirEntry *direntry ,
                                                                double *value ) 
{ uint32 m[2] ;
  enum TIFFReadDirEntryErr err ;
  uint32 offset ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3521\n");
  fflush(_coverage_fout);
  if (sizeof(double ) == 8U) {
    fprintf(_coverage_fout, "3502\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "3503\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(double)==8", "tif_dirread.c", 2800U,
                  "TIFFReadDirEntryCheckedRational");
  }
  fprintf(_coverage_fout, "3522\n");
  fflush(_coverage_fout);
  if (sizeof(uint64 ) == 8U) {
    fprintf(_coverage_fout, "3504\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "3505\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint64)==8", "tif_dirread.c", 2801U,
                  "TIFFReadDirEntryCheckedRational");
  }
  fprintf(_coverage_fout, "3523\n");
  fflush(_coverage_fout);
  if (sizeof(uint32 ) == 4U) {
    fprintf(_coverage_fout, "3506\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "3507\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint32)==4", "tif_dirread.c", 2802U,
                  "TIFFReadDirEntryCheckedRational");
  }
  fprintf(_coverage_fout, "3524\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "3512\n");
    fflush(_coverage_fout);
    offset = *((uint32 *)(& direntry->tdir_offset));
    fprintf(_coverage_fout, "3513\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3508\n");
      fflush(_coverage_fout);
      TIFFSwabLong(& offset);
    } else {
      fprintf(_coverage_fout, "3509\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3514\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryData(tif, (unsigned long long )offset, 8L, (void *)(m));
    fprintf(_coverage_fout, "3515\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      fprintf(_coverage_fout, "3510\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "3511\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "3516\n");
    fflush(_coverage_fout);
    *((uint64 *)(m)) = direntry->tdir_offset;
  }
  fprintf(_coverage_fout, "3525\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "3517\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong(m, 2L);
  } else {
    fprintf(_coverage_fout, "3518\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3526\n");
  fflush(_coverage_fout);
  if (m[0] == 0U) {
    fprintf(_coverage_fout, "3519\n");
    fflush(_coverage_fout);
    *value = 0.0;
  } else {
    fprintf(_coverage_fout, "3520\n");
    fflush(_coverage_fout);
    *value = (double )m[0] / (double )m[1];
  }
  fprintf(_coverage_fout, "3527\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckedSrational(TIFF *tif ,
                                                                 TIFFDirEntry *direntry ,
                                                                 double *value ) 
{ uint32 m[2] ;
  enum TIFFReadDirEntryErr err ;
  uint32 offset ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3549\n");
  fflush(_coverage_fout);
  if (sizeof(double ) == 8U) {
    fprintf(_coverage_fout, "3528\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "3529\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(double)==8", "tif_dirread.c", 2828U,
                  "TIFFReadDirEntryCheckedSrational");
  }
  fprintf(_coverage_fout, "3550\n");
  fflush(_coverage_fout);
  if (sizeof(uint64 ) == 8U) {
    fprintf(_coverage_fout, "3530\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "3531\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint64)==8", "tif_dirread.c", 2829U,
                  "TIFFReadDirEntryCheckedSrational");
  }
  fprintf(_coverage_fout, "3551\n");
  fflush(_coverage_fout);
  if (sizeof(int32 ) == 4U) {
    fprintf(_coverage_fout, "3532\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "3533\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int32)==4", "tif_dirread.c", 2830U,
                  "TIFFReadDirEntryCheckedSrational");
  }
  fprintf(_coverage_fout, "3552\n");
  fflush(_coverage_fout);
  if (sizeof(uint32 ) == 4U) {
    fprintf(_coverage_fout, "3534\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "3535\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint32)==4", "tif_dirread.c", 2831U,
                  "TIFFReadDirEntryCheckedSrational");
  }
  fprintf(_coverage_fout, "3553\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "3540\n");
    fflush(_coverage_fout);
    offset = *((uint32 *)(& direntry->tdir_offset));
    fprintf(_coverage_fout, "3541\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3536\n");
      fflush(_coverage_fout);
      TIFFSwabLong(& offset);
    } else {
      fprintf(_coverage_fout, "3537\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3542\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryData(tif, (unsigned long long )offset, 8L, (void *)(m));
    fprintf(_coverage_fout, "3543\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      fprintf(_coverage_fout, "3538\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "3539\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "3544\n");
    fflush(_coverage_fout);
    *((uint64 *)(m)) = direntry->tdir_offset;
  }
  fprintf(_coverage_fout, "3554\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "3545\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong(m, 2L);
  } else {
    fprintf(_coverage_fout, "3546\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3555\n");
  fflush(_coverage_fout);
  if ((int )m[0] == 0) {
    fprintf(_coverage_fout, "3547\n");
    fflush(_coverage_fout);
    *value = 0.0;
  } else {
    fprintf(_coverage_fout, "3548\n");
    fflush(_coverage_fout);
    *value = (double )((int )m[0]) / (double )m[1];
  }
  fprintf(_coverage_fout, "3556\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static void TIFFReadDirEntryCheckedFloat(TIFF *tif , TIFFDirEntry *direntry ,
                                         float *value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3563\n");
  fflush(_coverage_fout);
  if (sizeof(float ) == 4U) {
    fprintf(_coverage_fout, "3557\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "3558\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(float)==4", "tif_dirread.c", 2856U,
                  "TIFFReadDirEntryCheckedFloat");
  }
  fprintf(_coverage_fout, "3564\n");
  fflush(_coverage_fout);
  if (sizeof(uint32 ) == 4U) {
    fprintf(_coverage_fout, "3559\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "3560\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint32)==4", "tif_dirread.c", 2857U,
                  "TIFFReadDirEntryCheckedFloat");
  }
  fprintf(_coverage_fout, "3565\n");
  fflush(_coverage_fout);
  *((uint32 *)value) = *((uint32 *)(& direntry->tdir_offset));
  fprintf(_coverage_fout, "3566\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "3561\n");
    fflush(_coverage_fout);
    TIFFSwabLong((uint32 *)value);
  } else {
    fprintf(_coverage_fout, "3562\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3567\n");
  fflush(_coverage_fout);
  return;
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckedDouble(TIFF *tif ,
                                                              TIFFDirEntry *direntry ,
                                                              double *value ) 
{ enum TIFFReadDirEntryErr err ;
  uint32 offset ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3583\n");
  fflush(_coverage_fout);
  if (sizeof(double ) == 8U) {
    fprintf(_coverage_fout, "3568\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "3569\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(double)==8", "tif_dirread.c", 2865U,
                  "TIFFReadDirEntryCheckedDouble");
  }
  fprintf(_coverage_fout, "3584\n");
  fflush(_coverage_fout);
  if (sizeof(uint64 ) == 8U) {
    fprintf(_coverage_fout, "3570\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "3571\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint64)==8", "tif_dirread.c", 2866U,
                  "TIFFReadDirEntryCheckedDouble");
  }
  fprintf(_coverage_fout, "3585\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "3576\n");
    fflush(_coverage_fout);
    offset = *((uint32 *)(& direntry->tdir_offset));
    fprintf(_coverage_fout, "3577\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "3572\n");
      fflush(_coverage_fout);
      TIFFSwabLong(& offset);
    } else {
      fprintf(_coverage_fout, "3573\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3578\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryData(tif, (unsigned long long )offset, 8L,
                               (void *)value);
    fprintf(_coverage_fout, "3579\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      fprintf(_coverage_fout, "3574\n");
      fflush(_coverage_fout);
      return (err);
    } else {
      fprintf(_coverage_fout, "3575\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "3580\n");
    fflush(_coverage_fout);
    *((uint64 *)value) = direntry->tdir_offset;
  }
  fprintf(_coverage_fout, "3586\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "3581\n");
    fflush(_coverage_fout);
    TIFFSwabLong8((uint64 *)value);
  } else {
    fprintf(_coverage_fout, "3582\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "3587\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeByteSbyte(int8 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3590\n");
  fflush(_coverage_fout);
  if ((int )value < 0) {
    fprintf(_coverage_fout, "3588\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3589\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeByteShort(uint16 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3593\n");
  fflush(_coverage_fout);
  if ((int )value > 0xFF) {
    fprintf(_coverage_fout, "3591\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3592\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeByteSshort(int16 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3598\n");
  fflush(_coverage_fout);
  if ((int )value < 0) {
    fprintf(_coverage_fout, "3594\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3597\n");
    fflush(_coverage_fout);
    if ((int )value > 0xFF) {
      fprintf(_coverage_fout, "3595\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )4);
    } else {
      fprintf(_coverage_fout, "3596\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )0);
    }
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeByteLong(uint32 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3601\n");
  fflush(_coverage_fout);
  if (value > 255U) {
    fprintf(_coverage_fout, "3599\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3600\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeByteSlong(int32 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3606\n");
  fflush(_coverage_fout);
  if (value < 0) {
    fprintf(_coverage_fout, "3602\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3605\n");
    fflush(_coverage_fout);
    if (value > 0xFF) {
      fprintf(_coverage_fout, "3603\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )4);
    } else {
      fprintf(_coverage_fout, "3604\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )0);
    }
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeByteLong8(uint64 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3609\n");
  fflush(_coverage_fout);
  if (value > 255ULL) {
    fprintf(_coverage_fout, "3607\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3608\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeByteSlong8(int64 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3614\n");
  fflush(_coverage_fout);
  if (value < 0LL) {
    fprintf(_coverage_fout, "3610\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3613\n");
    fflush(_coverage_fout);
    if (value > 255LL) {
      fprintf(_coverage_fout, "3611\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )4);
    } else {
      fprintf(_coverage_fout, "3612\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )0);
    }
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSbyteByte(uint8 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3617\n");
  fflush(_coverage_fout);
  if ((int )value > 0x7F) {
    fprintf(_coverage_fout, "3615\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3616\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSbyteShort(uint16 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3620\n");
  fflush(_coverage_fout);
  if ((int )value > 0x7F) {
    fprintf(_coverage_fout, "3618\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3619\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSbyteSshort(int16 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3625\n");
  fflush(_coverage_fout);
  if ((int )value < -128) {
    fprintf(_coverage_fout, "3621\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3624\n");
    fflush(_coverage_fout);
    if ((int )value > 0x7F) {
      fprintf(_coverage_fout, "3622\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )4);
    } else {
      fprintf(_coverage_fout, "3623\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )0);
    }
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSbyteLong(uint32 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3628\n");
  fflush(_coverage_fout);
  if (value > 127U) {
    fprintf(_coverage_fout, "3626\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3627\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSbyteSlong(int32 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3633\n");
  fflush(_coverage_fout);
  if (value < -128) {
    fprintf(_coverage_fout, "3629\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3632\n");
    fflush(_coverage_fout);
    if (value > 0x7F) {
      fprintf(_coverage_fout, "3630\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )4);
    } else {
      fprintf(_coverage_fout, "3631\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )0);
    }
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSbyteLong8(uint64 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3636\n");
  fflush(_coverage_fout);
  if (value > 127ULL) {
    fprintf(_coverage_fout, "3634\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3635\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSbyteSlong8(int64 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3641\n");
  fflush(_coverage_fout);
  if (value < -128LL) {
    fprintf(_coverage_fout, "3637\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3640\n");
    fflush(_coverage_fout);
    if (value > 127LL) {
      fprintf(_coverage_fout, "3638\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )4);
    } else {
      fprintf(_coverage_fout, "3639\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )0);
    }
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeShortSbyte(int8 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3644\n");
  fflush(_coverage_fout);
  if ((int )value < 0) {
    fprintf(_coverage_fout, "3642\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3643\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeShortSshort(int16 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3647\n");
  fflush(_coverage_fout);
  if ((int )value < 0) {
    fprintf(_coverage_fout, "3645\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3646\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeShortLong(uint32 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3650\n");
  fflush(_coverage_fout);
  if (value > 65535U) {
    fprintf(_coverage_fout, "3648\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3649\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeShortSlong(int32 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3655\n");
  fflush(_coverage_fout);
  if (value < 0) {
    fprintf(_coverage_fout, "3651\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3654\n");
    fflush(_coverage_fout);
    if (value > 0xFFFF) {
      fprintf(_coverage_fout, "3652\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )4);
    } else {
      fprintf(_coverage_fout, "3653\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )0);
    }
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeShortLong8(uint64 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3658\n");
  fflush(_coverage_fout);
  if (value > 65535ULL) {
    fprintf(_coverage_fout, "3656\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3657\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeShortSlong8(int64 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3663\n");
  fflush(_coverage_fout);
  if (value < 0LL) {
    fprintf(_coverage_fout, "3659\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3662\n");
    fflush(_coverage_fout);
    if (value > 65535LL) {
      fprintf(_coverage_fout, "3660\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )4);
    } else {
      fprintf(_coverage_fout, "3661\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )0);
    }
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSshortShort(uint16 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3666\n");
  fflush(_coverage_fout);
  if ((int )value > 0x7FFF) {
    fprintf(_coverage_fout, "3664\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3665\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSshortLong(uint32 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3669\n");
  fflush(_coverage_fout);
  if (value > 32767U) {
    fprintf(_coverage_fout, "3667\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3668\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSshortSlong(int32 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3674\n");
  fflush(_coverage_fout);
  if (value < -32768) {
    fprintf(_coverage_fout, "3670\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3673\n");
    fflush(_coverage_fout);
    if (value > 0x7FFF) {
      fprintf(_coverage_fout, "3671\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )4);
    } else {
      fprintf(_coverage_fout, "3672\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )0);
    }
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSshortLong8(uint64 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3677\n");
  fflush(_coverage_fout);
  if (value > 32767ULL) {
    fprintf(_coverage_fout, "3675\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3676\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSshortSlong8(int64 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3682\n");
  fflush(_coverage_fout);
  if (value < -32768LL) {
    fprintf(_coverage_fout, "3678\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3681\n");
    fflush(_coverage_fout);
    if (value > 32767LL) {
      fprintf(_coverage_fout, "3679\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )4);
    } else {
      fprintf(_coverage_fout, "3680\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )0);
    }
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLongSbyte(int8 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3685\n");
  fflush(_coverage_fout);
  if ((int )value < 0) {
    fprintf(_coverage_fout, "3683\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3684\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLongSshort(int16 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3688\n");
  fflush(_coverage_fout);
  if ((int )value < 0) {
    fprintf(_coverage_fout, "3686\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3687\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLongSlong(int32 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3691\n");
  fflush(_coverage_fout);
  if (value < 0) {
    fprintf(_coverage_fout, "3689\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3690\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLongLong8(uint64 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3694\n");
  fflush(_coverage_fout);
  if (value > 4294967295ULL) {
    fprintf(_coverage_fout, "3692\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3693\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLongSlong8(int64 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3699\n");
  fflush(_coverage_fout);
  if (value < 0LL) {
    fprintf(_coverage_fout, "3695\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3698\n");
    fflush(_coverage_fout);
    if (value > 0xFFFFFFFFLL) {
      fprintf(_coverage_fout, "3696\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )4);
    } else {
      fprintf(_coverage_fout, "3697\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )0);
    }
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSlongLong(uint32 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3702\n");
  fflush(_coverage_fout);
  if ((unsigned long )value > 0x7FFFFFFFUL) {
    fprintf(_coverage_fout, "3700\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3701\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSlongLong8(uint64 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3705\n");
  fflush(_coverage_fout);
  if (value > 2147483647ULL) {
    fprintf(_coverage_fout, "3703\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3704\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSlongSlong8(int64 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3710\n");
  fflush(_coverage_fout);
  if (value < 2147483648LL) {
    fprintf(_coverage_fout, "3706\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3709\n");
    fflush(_coverage_fout);
    if (value > 2147483647LL) {
      fprintf(_coverage_fout, "3707\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )4);
    } else {
      fprintf(_coverage_fout, "3708\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )0);
    }
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLong8Sbyte(int8 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3713\n");
  fflush(_coverage_fout);
  if ((int )value < 0) {
    fprintf(_coverage_fout, "3711\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3712\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLong8Sshort(int16 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3716\n");
  fflush(_coverage_fout);
  if ((int )value < 0) {
    fprintf(_coverage_fout, "3714\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3715\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLong8Slong(int32 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3719\n");
  fflush(_coverage_fout);
  if (value < 0) {
    fprintf(_coverage_fout, "3717\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3718\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeLong8Slong8(int64 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3722\n");
  fflush(_coverage_fout);
  if (value < 0LL) {
    fprintf(_coverage_fout, "3720\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3721\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryCheckRangeSlong8Long8(uint64 value ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3725\n");
  fflush(_coverage_fout);
  if (value > 9223372036854775807ULL) {
    fprintf(_coverage_fout, "3723\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )4);
  } else {
    fprintf(_coverage_fout, "3724\n");
    fflush(_coverage_fout);
    return ((enum TIFFReadDirEntryErr )0);
  }
}
}
static enum TIFFReadDirEntryErr TIFFReadDirEntryData(TIFF *tif , uint64 offset ,
                                                     tmsize_t size , void *dest ) 
{ uint64 tmp ;
  tmsize_t tmp___0 ;
  tmsize_t ma ;
  tmsize_t mb ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3748\n");
  fflush(_coverage_fout);
  if (size > 0L) {
    fprintf(_coverage_fout, "3726\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "3727\n");
    fflush(_coverage_fout);
    __assert_fail("size>0", "tif_dirread.c", 3224U, "TIFFReadDirEntryData");
  }
  fprintf(_coverage_fout, "3749\n");
  fflush(_coverage_fout);
  if (! ((tif->tif_flags & 2048U) != 0U)) {
    fprintf(_coverage_fout, "3732\n");
    fflush(_coverage_fout);
    tmp = (*(tif->tif_seekproc))(tif->tif_clientdata, offset, 0);
    fprintf(_coverage_fout, "3733\n");
    fflush(_coverage_fout);
    if (tmp == offset) {
      fprintf(_coverage_fout, "3728\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "3729\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )3);
    }
    fprintf(_coverage_fout, "3734\n");
    fflush(_coverage_fout);
    tmp___0 = (*(tif->tif_readproc))(tif->tif_clientdata, dest, size);
    fprintf(_coverage_fout, "3735\n");
    fflush(_coverage_fout);
    if (tmp___0 == size) {
      fprintf(_coverage_fout, "3730\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "3731\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )3);
    }
  } else {
    fprintf(_coverage_fout, "3744\n");
    fflush(_coverage_fout);
    ma = (long )offset;
    fprintf(_coverage_fout, "3745\n");
    fflush(_coverage_fout);
    mb = ma + size;
    fprintf(_coverage_fout, "3746\n");
    fflush(_coverage_fout);
    if ((unsigned long long )ma != offset) {
      fprintf(_coverage_fout, "3736\n");
      fflush(_coverage_fout);
      return ((enum TIFFReadDirEntryErr )3);
    } else {
      fprintf(_coverage_fout, "3743\n");
      fflush(_coverage_fout);
      if (mb < ma) {
        fprintf(_coverage_fout, "3737\n");
        fflush(_coverage_fout);
        return ((enum TIFFReadDirEntryErr )3);
      } else {
        fprintf(_coverage_fout, "3742\n");
        fflush(_coverage_fout);
        if (mb < size) {
          fprintf(_coverage_fout, "3738\n");
          fflush(_coverage_fout);
          return ((enum TIFFReadDirEntryErr )3);
        } else {
          fprintf(_coverage_fout, "3741\n");
          fflush(_coverage_fout);
          if (mb > tif->tif_size) {
            fprintf(_coverage_fout, "3739\n");
            fflush(_coverage_fout);
            return ((enum TIFFReadDirEntryErr )3);
          } else {
            fprintf(_coverage_fout, "3740\n");
            fflush(_coverage_fout);

          }
        }
      }
    }
    fprintf(_coverage_fout, "3747\n");
    fflush(_coverage_fout);
    _TIFFmemcpy(dest, (void const   *)(tif->tif_base + ma), size);
  }
  fprintf(_coverage_fout, "3750\n");
  fflush(_coverage_fout);
  return ((enum TIFFReadDirEntryErr )0);
}
}
static void TIFFReadDirEntryOutputErr(TIFF *tif , enum TIFFReadDirEntryErr err ,
                                      char const   *module ,
                                      char const   *tagname , int recover ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3767\n");
  fflush(_coverage_fout);
  if (! recover) {
    switch ((int )err) {
    fprintf(_coverage_fout, "3751\n");
    fflush(_coverage_fout);
    case 1: 
    TIFFErrorExt(tif->tif_clientdata, module, "Incorrect count for \"%s\"",
                 tagname);
    break;
    fprintf(_coverage_fout, "3752\n");
    fflush(_coverage_fout);
    case 2: 
    TIFFErrorExt(tif->tif_clientdata, module, "Incompatible type for \"%s\"",
                 tagname);
    break;
    fprintf(_coverage_fout, "3753\n");
    fflush(_coverage_fout);
    case 3: 
    TIFFErrorExt(tif->tif_clientdata, module,
                 "IO error during reading of \"%s\"", tagname);
    break;
    fprintf(_coverage_fout, "3754\n");
    fflush(_coverage_fout);
    case 4: 
    TIFFErrorExt(tif->tif_clientdata, module, "Incorrect value for \"%s\"",
                 tagname);
    break;
    fprintf(_coverage_fout, "3755\n");
    fflush(_coverage_fout);
    case 5: 
    TIFFErrorExt(tif->tif_clientdata, module,
                 "Cannot handle different values per sample for \"%s\"", tagname);
    break;
    fprintf(_coverage_fout, "3756\n");
    fflush(_coverage_fout);
    case 6: 
    TIFFErrorExt(tif->tif_clientdata, module,
                 "Sanity check on size of \"%s\" value failed", tagname);
    break;
    fprintf(_coverage_fout, "3757\n");
    fflush(_coverage_fout);
    case 7: 
    TIFFErrorExt(tif->tif_clientdata, module, "Out of memory reading of \"%s\"",
                 tagname);
    break;
    fprintf(_coverage_fout, "3758\n");
    fflush(_coverage_fout);
    default: 
    __assert_fail("0", "tif_dirread.c", 3281U, "TIFFReadDirEntryOutputErr");
    break;
    }
  } else {
    switch ((int )err) {
    fprintf(_coverage_fout, "3759\n");
    fflush(_coverage_fout);
    case 1: 
    TIFFErrorExt(tif->tif_clientdata, module,
                 "Incorrect count for \"%s\"; tag ignored", tagname);
    break;
    fprintf(_coverage_fout, "3760\n");
    fflush(_coverage_fout);
    case 2: 
    TIFFWarningExt(tif->tif_clientdata, module,
                   "Incompatible type for \"%s\"; tag ignored", tagname);
    break;
    fprintf(_coverage_fout, "3761\n");
    fflush(_coverage_fout);
    case 3: 
    TIFFWarningExt(tif->tif_clientdata, module,
                   "IO error during reading of \"%s\"; tag ignored", tagname);
    break;
    fprintf(_coverage_fout, "3762\n");
    fflush(_coverage_fout);
    case 4: 
    TIFFWarningExt(tif->tif_clientdata, module,
                   "Incorrect value for \"%s\"; tag ignored", tagname);
    break;
    fprintf(_coverage_fout, "3763\n");
    fflush(_coverage_fout);
    case 5: 
    TIFFWarningExt(tif->tif_clientdata, module,
                   "Cannot handle different values per sample for \"%s\"; tag ignored",
                   tagname);
    break;
    fprintf(_coverage_fout, "3764\n");
    fflush(_coverage_fout);
    case 6: 
    TIFFWarningExt(tif->tif_clientdata, module,
                   "Sanity check on size of \"%s\" value failed; tag ignored",
                   tagname);
    break;
    fprintf(_coverage_fout, "3765\n");
    fflush(_coverage_fout);
    case 7: 
    TIFFWarningExt(tif->tif_clientdata, module,
                   "Out of memory reading of \"%s\"; tag ignored", tagname);
    break;
    fprintf(_coverage_fout, "3766\n");
    fflush(_coverage_fout);
    default: 
    __assert_fail("0", "tif_dirread.c", 3322U, "TIFFReadDirEntryOutputErr");
    break;
    }
  }
  fprintf(_coverage_fout, "3768\n");
  fflush(_coverage_fout);
  return;
}
}
int TIFFReadDirectory(TIFF *tif ) ;
static char const   module[18]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'R',      (char const   )'e',      (char const   )'a',      (char const   )'d', 
        (char const   )'D',      (char const   )'i',      (char const   )'r',      (char const   )'e', 
        (char const   )'c',      (char const   )'t',      (char const   )'o',      (char const   )'r', 
        (char const   )'y',      (char const   )'\000'};
int TIFFReadDirectory(TIFF *tif ) 
{ TIFFDirEntry *dir ;
  uint16 dircount ;
  TIFFDirEntry *dp ;
  uint16 di ;
  TIFFField const   *fip ;
  uint32 fii ;
  toff_t nextdiroff ;
  int tmp ;
  int tmp___0 ;
  uint16 value ;
  enum TIFFReadDirEntryErr err ;
  int tmp___1 ;
  int tmp___2 ;
  TIFFField *tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  char const   *tmp___6 ;
  char const   *tmp___7 ;
  uint16 value___0 ;
  enum TIFFReadDirEntryErr err___0 ;
  TIFFField const   *tmp___8 ;
  int tmp___9 ;
  double value___1 ;
  enum TIFFReadDirEntryErr err___1 ;
  TIFFField const   *tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  enum TIFFReadDirEntryErr err___2 ;
  uint32 countpersample ;
  uint32 countrequired ;
  uint32 incrementpersample ;
  uint16 *value___2 ;
  TIFFField const   *tmp___14 ;
  uint16 valueo ;
  uint32 value___3 ;
  enum TIFFReadDirEntryErr tmp___15 ;
  int tmp___16 ;
  int tmp___17 ;
  int tmp___18 ;
  int tmp___19 ;
  TIFFField const   *tmp___20 ;
  int tmp___21 ;
  TIFFField const   *tmp___22 ;
  int tmp___23 ;
  TIFFField const   *tmp___24 ;
  int tmp___25 ;
  uint64 tmp___26 ;
  uint64 tmp___27 ;
  uint32 strip ;
  tmsize_t tmp___28 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "4041\n");
  fflush(_coverage_fout);
  tif->tif_diroff = tif->tif_nextdiroff;
  fprintf(_coverage_fout, "4042\n");
  fflush(_coverage_fout);
  tmp = TIFFCheckDirOffset(tif, tif->tif_nextdiroff);
  fprintf(_coverage_fout, "4043\n");
  fflush(_coverage_fout);
  if (tmp) {
    fprintf(_coverage_fout, "3769\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "3770\n");
    fflush(_coverage_fout);
    return (0);
  }
  fprintf(_coverage_fout, "4044\n");
  fflush(_coverage_fout);
  (*(tif->tif_cleanup))(tif);
  fprintf(_coverage_fout, "4045\n");
  fflush(_coverage_fout);
  tif->tif_curdir = (uint16 )((int )tif->tif_curdir + 1);
  fprintf(_coverage_fout, "4046\n");
  fflush(_coverage_fout);
  nextdiroff = tif->tif_nextdiroff;
  fprintf(_coverage_fout, "4047\n");
  fflush(_coverage_fout);
  dircount = TIFFFetchDirectory(tif, nextdiroff, & dir, & tif->tif_nextdiroff);
  fprintf(_coverage_fout, "4048\n");
  fflush(_coverage_fout);
  if (! dircount) {
    fprintf(_coverage_fout, "3771\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module,
                 "Failed to read directory at offset %llu", nextdiroff);
    fprintf(_coverage_fout, "3772\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "3773\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4049\n");
  fflush(_coverage_fout);
  TIFFReadDirectoryCheckOrder(tif, dir, dircount);
  fprintf(_coverage_fout, "4050\n");
  fflush(_coverage_fout);
  tif->tif_flags &= 4294967231U;
  fprintf(_coverage_fout, "4051\n");
  fflush(_coverage_fout);
  TIFFFreeDirectory(tif);
  fprintf(_coverage_fout, "4052\n");
  fflush(_coverage_fout);
  TIFFDefaultDirectory(tif);
  fprintf(_coverage_fout, "4053\n");
  fflush(_coverage_fout);
  TIFFSetField(tif, 284U, 1);
  fprintf(_coverage_fout, "4054\n");
  fflush(_coverage_fout);
  dp = TIFFReadDirectoryFindEntry(tif, dir, dircount, (unsigned short)277);
  fprintf(_coverage_fout, "4055\n");
  fflush(_coverage_fout);
  if (dp) {
    fprintf(_coverage_fout, "3775\n");
    fflush(_coverage_fout);
    tmp___0 = TIFFFetchNormalTag(tif, dp, 0);
    fprintf(_coverage_fout, "3776\n");
    fflush(_coverage_fout);
    if (tmp___0) {
      fprintf(_coverage_fout, "3774\n");
      fflush(_coverage_fout);

    } else {
      goto bad;
    }
    fprintf(_coverage_fout, "3777\n");
    fflush(_coverage_fout);
    dp->tdir_tag = (unsigned short)0;
  } else {
    fprintf(_coverage_fout, "3778\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4056\n");
  fflush(_coverage_fout);
  dp = TIFFReadDirectoryFindEntry(tif, dir, dircount, (unsigned short)259);
  fprintf(_coverage_fout, "4057\n");
  fflush(_coverage_fout);
  if (dp) {
    fprintf(_coverage_fout, "3784\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryShort(tif, dp, & value);
    fprintf(_coverage_fout, "3785\n");
    fflush(_coverage_fout);
    if ((unsigned int )err == 1U) {
      fprintf(_coverage_fout, "3779\n");
      fflush(_coverage_fout);
      err = TIFFReadDirEntryPersampleShort(tif, dp, & value);
    } else {
      fprintf(_coverage_fout, "3780\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3786\n");
    fflush(_coverage_fout);
    if ((unsigned int )err != 0U) {
      fprintf(_coverage_fout, "3781\n");
      fflush(_coverage_fout);
      TIFFReadDirEntryOutputErr(tif, err, module, "Compression", 0);
      goto bad;
    } else {
      fprintf(_coverage_fout, "3782\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3787\n");
    fflush(_coverage_fout);
    tmp___1 = TIFFSetField(tif, 259U, value);
    fprintf(_coverage_fout, "3788\n");
    fflush(_coverage_fout);
    if (tmp___1) {
      fprintf(_coverage_fout, "3783\n");
      fflush(_coverage_fout);

    } else {
      goto bad;
    }
    fprintf(_coverage_fout, "3789\n");
    fflush(_coverage_fout);
    dp->tdir_tag = (unsigned short)0;
  } else {
    fprintf(_coverage_fout, "3791\n");
    fflush(_coverage_fout);
    tmp___2 = TIFFSetField(tif, 259U, 1);
    fprintf(_coverage_fout, "3792\n");
    fflush(_coverage_fout);
    if (tmp___2) {
      fprintf(_coverage_fout, "3790\n");
      fflush(_coverage_fout);

    } else {
      goto bad;
    }
  }
  fprintf(_coverage_fout, "4058\n");
  fflush(_coverage_fout);
  di = (unsigned short)0;
  fprintf(_coverage_fout, "4059\n");
  fflush(_coverage_fout);
  dp = dir;
  fprintf(_coverage_fout, "4060\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3817\n");
    fflush(_coverage_fout);
    if ((int )di < (int )dircount) {
      fprintf(_coverage_fout, "3793\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "3818\n");
    fflush(_coverage_fout);
    if ((int )dp->tdir_tag != 0) {
      fprintf(_coverage_fout, "3805\n");
      fflush(_coverage_fout);
      TIFFReadDirectoryFindFieldInfo(tif, dp->tdir_tag, & fii);
      fprintf(_coverage_fout, "3806\n");
      fflush(_coverage_fout);
      if (fii == 4294967295U) {
        fprintf(_coverage_fout, "3800\n");
        fflush(_coverage_fout);
        TIFFWarningExt(tif->tif_clientdata, module,
                       "Unknown field with tag %d (0x%x) encountered",
                       dp->tdir_tag, dp->tdir_tag);
        fprintf(_coverage_fout, "3801\n");
        fflush(_coverage_fout);
        tmp___3 = _TIFFCreateAnonField(tif, (unsigned int )dp->tdir_tag,
                                       (enum __anonenum_TIFFDataType_21 )dp->tdir_type);
        fprintf(_coverage_fout, "3802\n");
        fflush(_coverage_fout);
        tmp___4 = _TIFFMergeFields(tif, (TIFFField const   *)tmp___3, 1U);
        fprintf(_coverage_fout, "3803\n");
        fflush(_coverage_fout);
        if (tmp___4) {
          fprintf(_coverage_fout, "3796\n");
          fflush(_coverage_fout);
          TIFFReadDirectoryFindFieldInfo(tif, dp->tdir_tag, & fii);
          fprintf(_coverage_fout, "3797\n");
          fflush(_coverage_fout);
          if (fii != 4294967295U) {
            fprintf(_coverage_fout, "3794\n");
            fflush(_coverage_fout);

          } else {
            fprintf(_coverage_fout, "3795\n");
            fflush(_coverage_fout);
            __assert_fail("fii!=(uint32)(-1)", "tif_dirread.c", 3446U,
                          "TIFFReadDirectory");
          }
        } else {
          fprintf(_coverage_fout, "3798\n");
          fflush(_coverage_fout);
          TIFFWarningExt(tif->tif_clientdata, module,
                         "Registering anonymous field with tag %d (0x%x) failed",
                         dp->tdir_tag, dp->tdir_tag);
          fprintf(_coverage_fout, "3799\n");
          fflush(_coverage_fout);
          dp->tdir_tag = (unsigned short)0;
        }
      } else {
        fprintf(_coverage_fout, "3804\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "3807\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3819\n");
    fflush(_coverage_fout);
    if ((int )dp->tdir_tag != 0) {
      fprintf(_coverage_fout, "3814\n");
      fflush(_coverage_fout);
      fip = (TIFFField const   *)*(tif->tif_fields + fii);
      fprintf(_coverage_fout, "3815\n");
      fflush(_coverage_fout);
      if ((int const   )fip->field_bit == 0) {
        fprintf(_coverage_fout, "3808\n");
        fflush(_coverage_fout);
        dp->tdir_tag = (unsigned short)0;
      } else {
        switch ((int )dp->tdir_tag) {
        fprintf(_coverage_fout, "3810\n");
        fflush(_coverage_fout);
        case 273: 
        case 279: 
        case 324: 
        case 325: 
        tif->tif_dir.td_fieldsset[(int const   )fip->field_bit / 32] |= 1UL << ((int const   )fip->field_bit & 31);
        break;
        fprintf(_coverage_fout, "3811\n");
        fflush(_coverage_fout);
        case 256: 
        case 257: 
        case 32997: 
        case 323: 
        case 322: 
        case 32998: 
        case 284: 
        case 278: 
        case 338: 
        tmp___5 = TIFFFetchNormalTag(tif, dp, 0);
        fprintf(_coverage_fout, "3812\n");
        fflush(_coverage_fout);
        if (tmp___5) {
          fprintf(_coverage_fout, "3809\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
        fprintf(_coverage_fout, "3813\n");
        fflush(_coverage_fout);
        dp->tdir_tag = (unsigned short)0;
        break;
        }
      }
    } else {
      fprintf(_coverage_fout, "3816\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3820\n");
    fflush(_coverage_fout);
    di = (uint16 )((int )di + 1);
    fprintf(_coverage_fout, "3821\n");
    fflush(_coverage_fout);
    dp ++;
  }
  fprintf(_coverage_fout, "4061\n");
  fflush(_coverage_fout);
  if ((int )tif->tif_dir.td_compression == 6) {
    fprintf(_coverage_fout, "3835\n");
    fflush(_coverage_fout);
    if ((int )tif->tif_dir.td_planarconfig == 2) {
      fprintf(_coverage_fout, "3832\n");
      fflush(_coverage_fout);
      dp = TIFFReadDirectoryFindEntry(tif, dir, dircount, (unsigned short)273);
      fprintf(_coverage_fout, "3833\n");
      fflush(_coverage_fout);
      if ((unsigned int )dp != (unsigned int )((TIFFDirEntry *)0)) {
        fprintf(_coverage_fout, "3830\n");
        fflush(_coverage_fout);
        if (dp->tdir_count == 1ULL) {
          fprintf(_coverage_fout, "3827\n");
          fflush(_coverage_fout);
          dp = TIFFReadDirectoryFindEntry(tif, dir, dircount,
                                          (unsigned short)279);
          fprintf(_coverage_fout, "3828\n");
          fflush(_coverage_fout);
          if ((unsigned int )dp != (unsigned int )((TIFFDirEntry *)0)) {
            fprintf(_coverage_fout, "3825\n");
            fflush(_coverage_fout);
            if (dp->tdir_count == 1ULL) {
              fprintf(_coverage_fout, "3822\n");
              fflush(_coverage_fout);
              tif->tif_dir.td_planarconfig = (unsigned short)1;
              fprintf(_coverage_fout, "3823\n");
              fflush(_coverage_fout);
              TIFFWarningExt(tif->tif_clientdata, module,
                             "Planarconfig tag value assumed incorrect, assuming data is contig instead of chunky");
            } else {
              fprintf(_coverage_fout, "3824\n");
              fflush(_coverage_fout);

            }
          } else {
            fprintf(_coverage_fout, "3826\n");
            fflush(_coverage_fout);

          }
        } else {
          fprintf(_coverage_fout, "3829\n");
          fflush(_coverage_fout);

        }
      } else {
        fprintf(_coverage_fout, "3831\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "3834\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "3836\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4062\n");
  fflush(_coverage_fout);
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 1))) {
    fprintf(_coverage_fout, "3837\n");
    fflush(_coverage_fout);
    MissingRequired(tif, "ImageLength");
    goto bad;
  } else {
    fprintf(_coverage_fout, "3838\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4063\n");
  fflush(_coverage_fout);
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 2))) {
    fprintf(_coverage_fout, "3839\n");
    fflush(_coverage_fout);
    tif->tif_dir.td_nstrips = TIFFNumberOfStrips(tif);
    fprintf(_coverage_fout, "3840\n");
    fflush(_coverage_fout);
    tif->tif_dir.td_tilewidth = tif->tif_dir.td_imagewidth;
    fprintf(_coverage_fout, "3841\n");
    fflush(_coverage_fout);
    tif->tif_dir.td_tilelength = tif->tif_dir.td_rowsperstrip;
    fprintf(_coverage_fout, "3842\n");
    fflush(_coverage_fout);
    tif->tif_dir.td_tiledepth = tif->tif_dir.td_imagedepth;
    fprintf(_coverage_fout, "3843\n");
    fflush(_coverage_fout);
    tif->tif_flags &= 4294966271U;
  } else {
    fprintf(_coverage_fout, "3844\n");
    fflush(_coverage_fout);
    tif->tif_dir.td_nstrips = TIFFNumberOfTiles(tif);
    fprintf(_coverage_fout, "3845\n");
    fflush(_coverage_fout);
    tif->tif_flags |= 1024U;
  }
  fprintf(_coverage_fout, "4064\n");
  fflush(_coverage_fout);
  if (! tif->tif_dir.td_nstrips) {
    fprintf(_coverage_fout, "3848\n");
    fflush(_coverage_fout);
    if ((tif->tif_flags & 1024U) != 0U) {
      fprintf(_coverage_fout, "3846\n");
      fflush(_coverage_fout);
      tmp___6 = "tiles";
    } else {
      fprintf(_coverage_fout, "3847\n");
      fflush(_coverage_fout);
      tmp___6 = "strips";
    }
    fprintf(_coverage_fout, "3849\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module, "Cannot handle zero number of %s",
                 tmp___6);
    goto bad;
  } else {
    fprintf(_coverage_fout, "3850\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4065\n");
  fflush(_coverage_fout);
  tif->tif_dir.td_stripsperimage = tif->tif_dir.td_nstrips;
  fprintf(_coverage_fout, "4066\n");
  fflush(_coverage_fout);
  if ((int )tif->tif_dir.td_planarconfig == 2) {
    fprintf(_coverage_fout, "3851\n");
    fflush(_coverage_fout);
    tif->tif_dir.td_stripsperimage /= (uint32 )tif->tif_dir.td_samplesperpixel;
  } else {
    fprintf(_coverage_fout, "3852\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4067\n");
  fflush(_coverage_fout);
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 25))) {
    fprintf(_coverage_fout, "3860\n");
    fflush(_coverage_fout);
    if ((int )tif->tif_dir.td_compression == 6) {
      fprintf(_coverage_fout, "3855\n");
      fflush(_coverage_fout);
      if (((tif->tif_flags & 1024U) != 0U) == 0) {
        fprintf(_coverage_fout, "3854\n");
        fflush(_coverage_fout);
        if (tif->tif_dir.td_nstrips == 1U) {
          fprintf(_coverage_fout, "3853\n");
          fflush(_coverage_fout);
          tif->tif_dir.td_fieldsset[0] |= 1UL << 25;
        } else {
          goto _L___0;
        }
      } else {
        goto _L___0;
      }
    } else {
      fprintf(_coverage_fout, "3858\n");
      fflush(_coverage_fout);
      _L___0: /* CIL Label */ 
      _L: /* CIL Label */ 
      if ((tif->tif_flags & 1024U) != 0U) {
        fprintf(_coverage_fout, "3856\n");
        fflush(_coverage_fout);
        tmp___7 = "TileOffsets";
      } else {
        fprintf(_coverage_fout, "3857\n");
        fflush(_coverage_fout);
        tmp___7 = "StripOffsets";
      }
      fprintf(_coverage_fout, "3859\n");
      fflush(_coverage_fout);
      MissingRequired(tif, tmp___7);
      goto bad;
    }
  } else {
    fprintf(_coverage_fout, "3861\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4068\n");
  fflush(_coverage_fout);
  di = (unsigned short)0;
  fprintf(_coverage_fout, "4069\n");
  fflush(_coverage_fout);
  dp = dir;
  fprintf(_coverage_fout, "4070\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "3915\n");
    fflush(_coverage_fout);
    if ((int )di < (int )dircount) {
      fprintf(_coverage_fout, "3862\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    switch ((int )dp->tdir_tag) {
    case 0: 
    break;
    fprintf(_coverage_fout, "3895\n");
    fflush(_coverage_fout);
    case 280: 
    case 281: 
    case 258: 
    case 32996: 
    case 339: 
    err___0 = TIFFReadDirEntryShort(tif, dp, & value___0);
    fprintf(_coverage_fout, "3896\n");
    fflush(_coverage_fout);
    if ((unsigned int )err___0 == 1U) {
      fprintf(_coverage_fout, "3863\n");
      fflush(_coverage_fout);
      err___0 = TIFFReadDirEntryPersampleShort(tif, dp, & value___0);
    } else {
      fprintf(_coverage_fout, "3864\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3897\n");
    fflush(_coverage_fout);
    if ((unsigned int )err___0 != 0U) {
      fprintf(_coverage_fout, "3865\n");
      fflush(_coverage_fout);
      tmp___8 = TIFFFieldWithTag(tif, (unsigned int )dp->tdir_tag);
      fprintf(_coverage_fout, "3866\n");
      fflush(_coverage_fout);
      TIFFReadDirEntryOutputErr(tif, err___0, module,
                                (char const   *)tmp___8->field_name, 0);
      goto bad;
    } else {
      fprintf(_coverage_fout, "3867\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3898\n");
    fflush(_coverage_fout);
    tmp___9 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, value___0);
    fprintf(_coverage_fout, "3899\n");
    fflush(_coverage_fout);
    if (tmp___9) {
      fprintf(_coverage_fout, "3868\n");
      fflush(_coverage_fout);

    } else {
      goto bad;
    }
    break;
    fprintf(_coverage_fout, "3900\n");
    fflush(_coverage_fout);
    case 340: 
    case 341: 
    err___1 = TIFFReadDirEntryPersampleDouble(tif, dp, & value___1);
    fprintf(_coverage_fout, "3901\n");
    fflush(_coverage_fout);
    if ((unsigned int )err___1 != 0U) {
      fprintf(_coverage_fout, "3869\n");
      fflush(_coverage_fout);
      tmp___10 = TIFFFieldWithTag(tif, (unsigned int )dp->tdir_tag);
      fprintf(_coverage_fout, "3870\n");
      fflush(_coverage_fout);
      TIFFReadDirEntryOutputErr(tif, err___1, module,
                                (char const   *)tmp___10->field_name, 0);
      goto bad;
    } else {
      fprintf(_coverage_fout, "3871\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3902\n");
    fflush(_coverage_fout);
    tmp___11 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, value___1);
    fprintf(_coverage_fout, "3903\n");
    fflush(_coverage_fout);
    if (tmp___11) {
      fprintf(_coverage_fout, "3872\n");
      fflush(_coverage_fout);

    } else {
      goto bad;
    }
    break;
    fprintf(_coverage_fout, "3904\n");
    fflush(_coverage_fout);
    case 273: 
    case 324: 
    tmp___12 = TIFFFetchStripThing(tif, dp, tif->tif_dir.td_nstrips,
                                   & tif->tif_dir.td_stripoffset);
    fprintf(_coverage_fout, "3905\n");
    fflush(_coverage_fout);
    if (tmp___12) {
      fprintf(_coverage_fout, "3873\n");
      fflush(_coverage_fout);

    } else {
      goto bad;
    }
    break;
    fprintf(_coverage_fout, "3906\n");
    fflush(_coverage_fout);
    case 279: 
    case 325: 
    tmp___13 = TIFFFetchStripThing(tif, dp, tif->tif_dir.td_nstrips,
                                   & tif->tif_dir.td_stripbytecount);
    fprintf(_coverage_fout, "3907\n");
    fflush(_coverage_fout);
    if (tmp___13) {
      fprintf(_coverage_fout, "3874\n");
      fflush(_coverage_fout);

    } else {
      goto bad;
    }
    break;
    fprintf(_coverage_fout, "3908\n");
    fflush(_coverage_fout);
    case 320: 
    case 301: 
    countpersample = (unsigned int )(1L << (int )tif->tif_dir.td_bitspersample);
    fprintf(_coverage_fout, "3909\n");
    fflush(_coverage_fout);
    if ((int )dp->tdir_tag == 301) {
      fprintf(_coverage_fout, "3879\n");
      fflush(_coverage_fout);
      if (dp->tdir_count == (unsigned long long )countpersample) {
        fprintf(_coverage_fout, "3875\n");
        fflush(_coverage_fout);
        countrequired = countpersample;
        fprintf(_coverage_fout, "3876\n");
        fflush(_coverage_fout);
        incrementpersample = 0U;
      } else {
        fprintf(_coverage_fout, "3877\n");
        fflush(_coverage_fout);
        countrequired = 3U * countpersample;
        fprintf(_coverage_fout, "3878\n");
        fflush(_coverage_fout);
        incrementpersample = countpersample;
      }
    } else {
      fprintf(_coverage_fout, "3880\n");
      fflush(_coverage_fout);
      countrequired = 3U * countpersample;
      fprintf(_coverage_fout, "3881\n");
      fflush(_coverage_fout);
      incrementpersample = countpersample;
    }
    fprintf(_coverage_fout, "3910\n");
    fflush(_coverage_fout);
    if (dp->tdir_count != (unsigned long long )countrequired) {
      fprintf(_coverage_fout, "3882\n");
      fflush(_coverage_fout);
      err___2 = (enum TIFFReadDirEntryErr )1;
    } else {
      fprintf(_coverage_fout, "3883\n");
      fflush(_coverage_fout);
      err___2 = TIFFReadDirEntryShortArray(tif, dp, & value___2);
    }
    fprintf(_coverage_fout, "3911\n");
    fflush(_coverage_fout);
    if ((unsigned int )err___2 != 0U) {
      fprintf(_coverage_fout, "3884\n");
      fflush(_coverage_fout);
      tmp___14 = TIFFFieldWithTag(tif, (unsigned int )dp->tdir_tag);
      fprintf(_coverage_fout, "3885\n");
      fflush(_coverage_fout);
      TIFFReadDirEntryOutputErr(tif, err___2, module,
                                (char const   *)tmp___14->field_name, 1);
    } else {
      fprintf(_coverage_fout, "3886\n");
      fflush(_coverage_fout);
      TIFFSetField(tif, (unsigned int )dp->tdir_tag, value___2,
                   value___2 + incrementpersample,
                   value___2 + 2U * incrementpersample);
      fprintf(_coverage_fout, "3887\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)value___2);
    }
    break;
    fprintf(_coverage_fout, "3912\n");
    fflush(_coverage_fout);
    case 255: 
    tmp___15 = TIFFReadDirEntryShort(tif, dp, & valueo);
    fprintf(_coverage_fout, "3913\n");
    fflush(_coverage_fout);
    if ((unsigned int )tmp___15 == 0U) {
      switch ((int )valueo) {
      fprintf(_coverage_fout, "3888\n");
      fflush(_coverage_fout);
      case 2: 
      value___3 = 1U;
      break;
      fprintf(_coverage_fout, "3889\n");
      fflush(_coverage_fout);
      case 3: 
      value___3 = 2U;
      break;
      fprintf(_coverage_fout, "3890\n");
      fflush(_coverage_fout);
      default: 
      value___3 = 0U;
      break;
      }
      fprintf(_coverage_fout, "3893\n");
      fflush(_coverage_fout);
      if (value___3 != 0U) {
        fprintf(_coverage_fout, "3891\n");
        fflush(_coverage_fout);
        TIFFSetField(tif, 254U, value___3);
      } else {
        fprintf(_coverage_fout, "3892\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "3894\n");
      fflush(_coverage_fout);

    }
    break;
    fprintf(_coverage_fout, "3914\n");
    fflush(_coverage_fout);
    default: 
    TIFFFetchNormalTag(tif, dp, 1);
    break;
    }
    fprintf(_coverage_fout, "3916\n");
    fflush(_coverage_fout);
    di = (uint16 )((int )di + 1);
    fprintf(_coverage_fout, "3917\n");
    fflush(_coverage_fout);
    dp ++;
  }
  fprintf(_coverage_fout, "4071\n");
  fflush(_coverage_fout);
  if ((int )tif->tif_dir.td_compression == 6) {
    fprintf(_coverage_fout, "3945\n");
    fflush(_coverage_fout);
    if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 8))) {
      fprintf(_coverage_fout, "3919\n");
      fflush(_coverage_fout);
      TIFFWarningExt(tif->tif_clientdata, module,
                     "Photometric tag is missing, assuming data is YCbCr");
      fprintf(_coverage_fout, "3920\n");
      fflush(_coverage_fout);
      tmp___16 = TIFFSetField(tif, 262U, 6);
      fprintf(_coverage_fout, "3921\n");
      fflush(_coverage_fout);
      if (tmp___16) {
        fprintf(_coverage_fout, "3918\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
    } else {
      fprintf(_coverage_fout, "3925\n");
      fflush(_coverage_fout);
      if ((int )tif->tif_dir.td_photometric == 2) {
        fprintf(_coverage_fout, "3922\n");
        fflush(_coverage_fout);
        tif->tif_dir.td_photometric = (unsigned short)6;
        fprintf(_coverage_fout, "3923\n");
        fflush(_coverage_fout);
        TIFFWarningExt(tif->tif_clientdata, module,
                       "Photometric tag value assumed incorrect, assuming data is YCbCr instead of RGB");
      } else {
        fprintf(_coverage_fout, "3924\n");
        fflush(_coverage_fout);

      }
    }
    fprintf(_coverage_fout, "3946\n");
    fflush(_coverage_fout);
    if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 6))) {
      fprintf(_coverage_fout, "3927\n");
      fflush(_coverage_fout);
      TIFFWarningExt(tif->tif_clientdata, module,
                     "BitsPerSample tag is missing, assuming 8 bits per sample");
      fprintf(_coverage_fout, "3928\n");
      fflush(_coverage_fout);
      tmp___17 = TIFFSetField(tif, 258U, 8);
      fprintf(_coverage_fout, "3929\n");
      fflush(_coverage_fout);
      if (tmp___17) {
        fprintf(_coverage_fout, "3926\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
    } else {
      fprintf(_coverage_fout, "3930\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "3947\n");
    fflush(_coverage_fout);
    if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 16))) {
      fprintf(_coverage_fout, "3943\n");
      fflush(_coverage_fout);
      if ((int )tif->tif_dir.td_photometric == 2) {
        goto _L___2;
      } else {
        fprintf(_coverage_fout, "3942\n");
        fflush(_coverage_fout);
        if ((int )tif->tif_dir.td_photometric == 6) {
          fprintf(_coverage_fout, "3932\n");
          fflush(_coverage_fout);
          _L___2: /* CIL Label */ 
          TIFFWarningExt(tif->tif_clientdata, module,
                         "SamplesPerPixel tag is missing, assuming correct SamplesPerPixel value is 3");
          fprintf(_coverage_fout, "3933\n");
          fflush(_coverage_fout);
          tmp___18 = TIFFSetField(tif, 277U, 3);
          fprintf(_coverage_fout, "3934\n");
          fflush(_coverage_fout);
          if (tmp___18) {
            fprintf(_coverage_fout, "3931\n");
            fflush(_coverage_fout);

          } else {
            goto bad;
          }
        } else {
          fprintf(_coverage_fout, "3941\n");
          fflush(_coverage_fout);
          if ((int )tif->tif_dir.td_photometric == 0) {
            goto _L___1;
          } else {
            fprintf(_coverage_fout, "3940\n");
            fflush(_coverage_fout);
            if ((int )tif->tif_dir.td_photometric == 1) {
              fprintf(_coverage_fout, "3936\n");
              fflush(_coverage_fout);
              _L___1: /* CIL Label */ 
              TIFFWarningExt(tif->tif_clientdata, module,
                             "SamplesPerPixel tag is missing, assuming correct SamplesPerPixel value is 1");
              fprintf(_coverage_fout, "3937\n");
              fflush(_coverage_fout);
              tmp___19 = TIFFSetField(tif, 277U, 1);
              fprintf(_coverage_fout, "3938\n");
              fflush(_coverage_fout);
              if (tmp___19) {
                fprintf(_coverage_fout, "3935\n");
                fflush(_coverage_fout);

              } else {
                goto bad;
              }
            } else {
              fprintf(_coverage_fout, "3939\n");
              fflush(_coverage_fout);

            }
          }
        }
      }
    } else {
      fprintf(_coverage_fout, "3944\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "3948\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4072\n");
  fflush(_coverage_fout);
  if ((int )tif->tif_dir.td_photometric == 3) {
    fprintf(_coverage_fout, "3951\n");
    fflush(_coverage_fout);
    if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 26))) {
      fprintf(_coverage_fout, "3949\n");
      fflush(_coverage_fout);
      MissingRequired(tif, "Colormap");
      goto bad;
    } else {
      fprintf(_coverage_fout, "3950\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "3952\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4073\n");
  fflush(_coverage_fout);
  if ((int )tif->tif_dir.td_compression != 6) {
    fprintf(_coverage_fout, "3999\n");
    fflush(_coverage_fout);
    if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 24))) {
      fprintf(_coverage_fout, "3961\n");
      fflush(_coverage_fout);
      if ((int )tif->tif_dir.td_planarconfig == 1) {
        fprintf(_coverage_fout, "3954\n");
        fflush(_coverage_fout);
        if (tif->tif_dir.td_nstrips > 1U) {
          fprintf(_coverage_fout, "3953\n");
          fflush(_coverage_fout);
          MissingRequired(tif, "StripByteCounts");
          goto bad;
        } else {
          goto _L___3;
        }
      } else {
        fprintf(_coverage_fout, "3959\n");
        fflush(_coverage_fout);
        _L___3: /* CIL Label */ 
        if ((int )tif->tif_dir.td_planarconfig == 2) {
          fprintf(_coverage_fout, "3957\n");
          fflush(_coverage_fout);
          if (tif->tif_dir.td_nstrips != (unsigned int )tif->tif_dir.td_samplesperpixel) {
            fprintf(_coverage_fout, "3955\n");
            fflush(_coverage_fout);
            MissingRequired(tif, "StripByteCounts");
            goto bad;
          } else {
            fprintf(_coverage_fout, "3956\n");
            fflush(_coverage_fout);

          }
        } else {
          fprintf(_coverage_fout, "3958\n");
          fflush(_coverage_fout);

        }
      }
      fprintf(_coverage_fout, "3962\n");
      fflush(_coverage_fout);
      tmp___20 = TIFFFieldWithTag(tif, 279U);
      fprintf(_coverage_fout, "3963\n");
      fflush(_coverage_fout);
      TIFFWarningExt(tif->tif_clientdata, module,
                     "TIFF directory is missing required \"%s\" field, calculating from imagelength",
                     tmp___20->field_name);
      fprintf(_coverage_fout, "3964\n");
      fflush(_coverage_fout);
      tmp___21 = EstimateStripByteCounts(tif, dir, dircount);
      fprintf(_coverage_fout, "3965\n");
      fflush(_coverage_fout);
      if (tmp___21 < 0) {
        goto bad;
      } else {
        fprintf(_coverage_fout, "3960\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "3998\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_nstrips == 1U) {
        fprintf(_coverage_fout, "3980\n");
        fflush(_coverage_fout);
        if (*(tif->tif_dir.td_stripoffset + 0) != 0ULL) {
          fprintf(_coverage_fout, "3979\n");
          fflush(_coverage_fout);
          if (*(tif->tif_dir.td_stripbytecount + 0) == 0ULL) {
            fprintf(_coverage_fout, "3966\n");
            fflush(_coverage_fout);
            if (*(tif->tif_dir.td_stripoffset + 0) != 0ULL) {
              goto _L___5;
            } else {
              goto _L___7;
            }
          } else {
            fprintf(_coverage_fout, "3978\n");
            fflush(_coverage_fout);
            _L___7: /* CIL Label */ 
            if ((int )tif->tif_dir.td_compression == 1) {
              fprintf(_coverage_fout, "3967\n");
              fflush(_coverage_fout);
              tmp___26 = (*(tif->tif_sizeproc))(tif->tif_clientdata);
              fprintf(_coverage_fout, "3968\n");
              fflush(_coverage_fout);
              if (*(tif->tif_dir.td_stripbytecount + 0) > tmp___26 - *(tif->tif_dir.td_stripoffset + 0)) {
                goto _L___5;
              } else {
                goto _L___6;
              }
            } else {
              fprintf(_coverage_fout, "3977\n");
              fflush(_coverage_fout);
              _L___6: /* CIL Label */ 
              if (tif->tif_mode == 00) {
                fprintf(_coverage_fout, "3976\n");
                fflush(_coverage_fout);
                if ((int )tif->tif_dir.td_compression == 1) {
                  fprintf(_coverage_fout, "3974\n");
                  fflush(_coverage_fout);
                  tmp___27 = TIFFScanlineSize64(tif);
                  fprintf(_coverage_fout, "3975\n");
                  fflush(_coverage_fout);
                  if (*(tif->tif_dir.td_stripbytecount + 0) < tmp___27 * (uint64 )tif->tif_dir.td_imagelength) {
                    fprintf(_coverage_fout, "3970\n");
                    fflush(_coverage_fout);
                    _L___5: /* CIL Label */ 
                    tmp___22 = TIFFFieldWithTag(tif, 279U);
                    fprintf(_coverage_fout, "3971\n");
                    fflush(_coverage_fout);
                    TIFFWarningExt(tif->tif_clientdata, module,
                                   "Bogus \"%s\" field, ignoring and calculating from imagelength",
                                   tmp___22->field_name);
                    fprintf(_coverage_fout, "3972\n");
                    fflush(_coverage_fout);
                    tmp___23 = EstimateStripByteCounts(tif, dir, dircount);
                    fprintf(_coverage_fout, "3973\n");
                    fflush(_coverage_fout);
                    if (tmp___23 < 0) {
                      goto bad;
                    } else {
                      fprintf(_coverage_fout, "3969\n");
                      fflush(_coverage_fout);

                    }
                  } else {
                    goto _L___8;
                  }
                } else {
                  goto _L___8;
                }
              } else {
                goto _L___8;
              }
            }
          }
        } else {
          goto _L___8;
        }
      } else {
        fprintf(_coverage_fout, "3997\n");
        fflush(_coverage_fout);
        _L___8: /* CIL Label */ 
        _L___4: /* CIL Label */ 
        if ((int )tif->tif_dir.td_planarconfig == 1) {
          fprintf(_coverage_fout, "3995\n");
          fflush(_coverage_fout);
          if (tif->tif_dir.td_nstrips > 2U) {
            fprintf(_coverage_fout, "3993\n");
            fflush(_coverage_fout);
            if ((int )tif->tif_dir.td_compression == 1) {
              fprintf(_coverage_fout, "3991\n");
              fflush(_coverage_fout);
              if (*(tif->tif_dir.td_stripbytecount + 0) != *(tif->tif_dir.td_stripbytecount + 1)) {
                fprintf(_coverage_fout, "3989\n");
                fflush(_coverage_fout);
                if (*(tif->tif_dir.td_stripbytecount + 0) != 0ULL) {
                  fprintf(_coverage_fout, "3987\n");
                  fflush(_coverage_fout);
                  if (*(tif->tif_dir.td_stripbytecount + 1) != 0ULL) {
                    fprintf(_coverage_fout, "3982\n");
                    fflush(_coverage_fout);
                    tmp___24 = TIFFFieldWithTag(tif, 279U);
                    fprintf(_coverage_fout, "3983\n");
                    fflush(_coverage_fout);
                    TIFFWarningExt(tif->tif_clientdata, module,
                                   "Wrong \"%s\" field, ignoring and calculating from imagelength",
                                   tmp___24->field_name);
                    fprintf(_coverage_fout, "3984\n");
                    fflush(_coverage_fout);
                    tmp___25 = EstimateStripByteCounts(tif, dir, dircount);
                    fprintf(_coverage_fout, "3985\n");
                    fflush(_coverage_fout);
                    if (tmp___25 < 0) {
                      goto bad;
                    } else {
                      fprintf(_coverage_fout, "3981\n");
                      fflush(_coverage_fout);

                    }
                  } else {
                    fprintf(_coverage_fout, "3986\n");
                    fflush(_coverage_fout);

                  }
                } else {
                  fprintf(_coverage_fout, "3988\n");
                  fflush(_coverage_fout);

                }
              } else {
                fprintf(_coverage_fout, "3990\n");
                fflush(_coverage_fout);

              }
            } else {
              fprintf(_coverage_fout, "3992\n");
              fflush(_coverage_fout);

            }
          } else {
            fprintf(_coverage_fout, "3994\n");
            fflush(_coverage_fout);

          }
        } else {
          fprintf(_coverage_fout, "3996\n");
          fflush(_coverage_fout);

        }
      }
    }
  } else {
    fprintf(_coverage_fout, "4000\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4074\n");
  fflush(_coverage_fout);
  if (dir) {
    fprintf(_coverage_fout, "4001\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)dir);
    fprintf(_coverage_fout, "4002\n");
    fflush(_coverage_fout);
    dir = (TIFFDirEntry *)((void *)0);
  } else {
    fprintf(_coverage_fout, "4003\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4075\n");
  fflush(_coverage_fout);
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 19))) {
    fprintf(_coverage_fout, "4006\n");
    fflush(_coverage_fout);
    if ((int )tif->tif_dir.td_bitspersample >= 16) {
      fprintf(_coverage_fout, "4004\n");
      fflush(_coverage_fout);
      tif->tif_dir.td_maxsamplevalue = (unsigned short)65535;
    } else {
      fprintf(_coverage_fout, "4005\n");
      fflush(_coverage_fout);
      tif->tif_dir.td_maxsamplevalue = (unsigned short )((1L << (int )tif->tif_dir.td_bitspersample) - 1L);
    }
  } else {
    fprintf(_coverage_fout, "4007\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4076\n");
  fflush(_coverage_fout);
  if (tif->tif_dir.td_nstrips > 1U) {
    fprintf(_coverage_fout, "4014\n");
    fflush(_coverage_fout);
    tif->tif_dir.td_stripbytecountsorted = 1;
    fprintf(_coverage_fout, "4015\n");
    fflush(_coverage_fout);
    strip = 1U;
    fprintf(_coverage_fout, "4016\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "4011\n");
      fflush(_coverage_fout);
      if (strip < tif->tif_dir.td_nstrips) {
        fprintf(_coverage_fout, "4008\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "4012\n");
      fflush(_coverage_fout);
      if (*(tif->tif_dir.td_stripoffset + (strip - 1U)) > *(tif->tif_dir.td_stripoffset + strip)) {
        fprintf(_coverage_fout, "4009\n");
        fflush(_coverage_fout);
        tif->tif_dir.td_stripbytecountsorted = 0;
        break;
      } else {
        fprintf(_coverage_fout, "4010\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4013\n");
      fflush(_coverage_fout);
      strip ++;
    }
  } else {
    fprintf(_coverage_fout, "4017\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4077\n");
  fflush(_coverage_fout);
  (*(tif->tif_fixuptags))(tif);
  fprintf(_coverage_fout, "4078\n");
  fflush(_coverage_fout);
  if ((int )tif->tif_dir.td_planarconfig == 1) {
    fprintf(_coverage_fout, "4024\n");
    fflush(_coverage_fout);
    if (tif->tif_dir.td_nstrips == 1U) {
      fprintf(_coverage_fout, "4022\n");
      fflush(_coverage_fout);
      if ((int )tif->tif_dir.td_compression == 1) {
        fprintf(_coverage_fout, "4020\n");
        fflush(_coverage_fout);
        if ((tif->tif_flags & 33792U) == 32768U) {
          fprintf(_coverage_fout, "4018\n");
          fflush(_coverage_fout);
          ChopUpSingleUncompressedStrip(tif);
        } else {
          fprintf(_coverage_fout, "4019\n");
          fflush(_coverage_fout);

        }
      } else {
        fprintf(_coverage_fout, "4021\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "4023\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "4025\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4079\n");
  fflush(_coverage_fout);
  tif->tif_row = 4294967295U;
  fprintf(_coverage_fout, "4080\n");
  fflush(_coverage_fout);
  tif->tif_curstrip = 4294967295U;
  fprintf(_coverage_fout, "4081\n");
  fflush(_coverage_fout);
  tif->tif_col = 4294967295U;
  fprintf(_coverage_fout, "4082\n");
  fflush(_coverage_fout);
  tif->tif_curtile = 4294967295U;
  fprintf(_coverage_fout, "4083\n");
  fflush(_coverage_fout);
  tif->tif_tilesize = -1L;
  fprintf(_coverage_fout, "4084\n");
  fflush(_coverage_fout);
  tif->tif_scanlinesize = TIFFScanlineSize(tif);
  fprintf(_coverage_fout, "4085\n");
  fflush(_coverage_fout);
  if (! tif->tif_scanlinesize) {
    fprintf(_coverage_fout, "4026\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module, "Cannot handle zero scanline size");
    fprintf(_coverage_fout, "4027\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "4028\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4086\n");
  fflush(_coverage_fout);
  if ((tif->tif_flags & 1024U) != 0U) {
    fprintf(_coverage_fout, "4032\n");
    fflush(_coverage_fout);
    tif->tif_tilesize = TIFFTileSize(tif);
    fprintf(_coverage_fout, "4033\n");
    fflush(_coverage_fout);
    if (! tif->tif_tilesize) {
      fprintf(_coverage_fout, "4029\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module, "Cannot handle zero tile size");
      fprintf(_coverage_fout, "4030\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "4031\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "4037\n");
    fflush(_coverage_fout);
    tmp___28 = TIFFStripSize(tif);
    fprintf(_coverage_fout, "4038\n");
    fflush(_coverage_fout);
    if (tmp___28) {
      fprintf(_coverage_fout, "4034\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "4035\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module, "Cannot handle zero strip size");
      fprintf(_coverage_fout, "4036\n");
      fflush(_coverage_fout);
      return (0);
    }
  }
  fprintf(_coverage_fout, "4087\n");
  fflush(_coverage_fout);
  return (1);
  fprintf(_coverage_fout, "4088\n");
  fflush(_coverage_fout);
  bad: 
  if (dir) {
    fprintf(_coverage_fout, "4039\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)dir);
  } else {
    fprintf(_coverage_fout, "4040\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4089\n");
  fflush(_coverage_fout);
  return (0);
}
}
static void TIFFReadDirectoryCheckOrder(TIFF *tif , TIFFDirEntry *dir ,
                                        uint16 dircount ) ;
static char const   module___0[28]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'R',      (char const   )'e',      (char const   )'a',      (char const   )'d', 
        (char const   )'D',      (char const   )'i',      (char const   )'r',      (char const   )'e', 
        (char const   )'c',      (char const   )'t',      (char const   )'o',      (char const   )'r', 
        (char const   )'y',      (char const   )'C',      (char const   )'h',      (char const   )'e', 
        (char const   )'c',      (char const   )'k',      (char const   )'O',      (char const   )'r', 
        (char const   )'d',      (char const   )'e',      (char const   )'r',      (char const   )'\000'};
static void TIFFReadDirectoryCheckOrder(TIFF *tif , TIFFDirEntry *dir ,
                                        uint16 dircount ) 
{ uint16 m ;
  uint16 n ;
  TIFFDirEntry *o ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "4098\n");
  fflush(_coverage_fout);
  m = (unsigned short)0;
  fprintf(_coverage_fout, "4099\n");
  fflush(_coverage_fout);
  n = (unsigned short)0;
  fprintf(_coverage_fout, "4100\n");
  fflush(_coverage_fout);
  o = dir;
  fprintf(_coverage_fout, "4101\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "4093\n");
    fflush(_coverage_fout);
    if ((int )n < (int )dircount) {
      fprintf(_coverage_fout, "4090\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "4094\n");
    fflush(_coverage_fout);
    if ((int )o->tdir_tag < (int )m) {
      fprintf(_coverage_fout, "4091\n");
      fflush(_coverage_fout);
      TIFFWarningExt(tif->tif_clientdata, module___0,
                     "Invalid TIFF directory; tags are not sorted in ascending order");
      break;
    } else {
      fprintf(_coverage_fout, "4092\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4095\n");
    fflush(_coverage_fout);
    m = (unsigned short )((int )o->tdir_tag + 1);
    fprintf(_coverage_fout, "4096\n");
    fflush(_coverage_fout);
    n = (uint16 )((int )n + 1);
    fprintf(_coverage_fout, "4097\n");
    fflush(_coverage_fout);
    o ++;
  }
  fprintf(_coverage_fout, "4102\n");
  fflush(_coverage_fout);
  return;
}
}
static TIFFDirEntry *TIFFReadDirectoryFindEntry(TIFF *tif , TIFFDirEntry *dir ,
                                                uint16 dircount , uint16 tagid ) 
{ TIFFDirEntry *m ;
  uint16 n ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "4110\n");
  fflush(_coverage_fout);
  m = dir;
  fprintf(_coverage_fout, "4111\n");
  fflush(_coverage_fout);
  n = (unsigned short)0;
  fprintf(_coverage_fout, "4112\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "4106\n");
    fflush(_coverage_fout);
    if ((int )n < (int )dircount) {
      fprintf(_coverage_fout, "4103\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "4107\n");
    fflush(_coverage_fout);
    if ((int )m->tdir_tag == (int )tagid) {
      fprintf(_coverage_fout, "4104\n");
      fflush(_coverage_fout);
      return (m);
    } else {
      fprintf(_coverage_fout, "4105\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4108\n");
    fflush(_coverage_fout);
    m ++;
    fprintf(_coverage_fout, "4109\n");
    fflush(_coverage_fout);
    n = (uint16 )((int )n + 1);
  }
  fprintf(_coverage_fout, "4113\n");
  fflush(_coverage_fout);
  return ((TIFFDirEntry *)0);
}
}
static void TIFFReadDirectoryFindFieldInfo(TIFF *tif , uint16 tagid ,
                                           uint32 *fii ) 
{ int32 ma ;
  int32 mb ;
  int32 mc ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "4129\n");
  fflush(_coverage_fout);
  ma = -1;
  fprintf(_coverage_fout, "4130\n");
  fflush(_coverage_fout);
  mc = (int )tif->tif_nfields;
  fprintf(_coverage_fout, "4131\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "4120\n");
    fflush(_coverage_fout);
    if (ma + 1 == mc) {
      fprintf(_coverage_fout, "4114\n");
      fflush(_coverage_fout);
      *fii = 4294967295U;
      fprintf(_coverage_fout, "4115\n");
      fflush(_coverage_fout);
      return;
    } else {
      fprintf(_coverage_fout, "4116\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4121\n");
    fflush(_coverage_fout);
    mb = (ma + mc) / 2;
    fprintf(_coverage_fout, "4122\n");
    fflush(_coverage_fout);
    if ((*(tif->tif_fields + mb))->field_tag == (unsigned int )tagid) {
      break;
    } else {
      fprintf(_coverage_fout, "4117\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4123\n");
    fflush(_coverage_fout);
    if ((*(tif->tif_fields + mb))->field_tag < (unsigned int )tagid) {
      fprintf(_coverage_fout, "4118\n");
      fflush(_coverage_fout);
      ma = mb;
    } else {
      fprintf(_coverage_fout, "4119\n");
      fflush(_coverage_fout);
      mc = mb;
    }
  }
  fprintf(_coverage_fout, "4132\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "4126\n");
    fflush(_coverage_fout);
    if (mb == 0) {
      break;
    } else {
      fprintf(_coverage_fout, "4124\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4127\n");
    fflush(_coverage_fout);
    if ((*(tif->tif_fields + (mb - 1)))->field_tag != (unsigned int )tagid) {
      break;
    } else {
      fprintf(_coverage_fout, "4125\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4128\n");
    fflush(_coverage_fout);
    mb --;
  }
  fprintf(_coverage_fout, "4133\n");
  fflush(_coverage_fout);
  *fii = (unsigned int )mb;
  fprintf(_coverage_fout, "4134\n");
  fflush(_coverage_fout);
  return;
}
}
int TIFFReadCustomDirectory(TIFF *tif , uint64 diroff ,
                            TIFFFieldArray const   *infoarray ) ;
static char const   module___1[24]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'R',      (char const   )'e',      (char const   )'a',      (char const   )'d', 
        (char const   )'C',      (char const   )'u',      (char const   )'s',      (char const   )'t', 
        (char const   )'o',      (char const   )'m',      (char const   )'D',      (char const   )'i', 
        (char const   )'r',      (char const   )'e',      (char const   )'c',      (char const   )'t', 
        (char const   )'o',      (char const   )'r',      (char const   )'y',      (char const   )'\000'};
int TIFFReadCustomDirectory(TIFF *tif , uint64 diroff ,
                            TIFFFieldArray const   *infoarray ) 
{ TIFFDirEntry *dir ;
  uint16 dircount ;
  TIFFDirEntry *dp ;
  uint16 di ;
  TIFFField const   *fip ;
  uint32 fii ;
  TIFFField *tmp ;
  int tmp___0 ;
  uint32 expected ;
  int tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "4189\n");
  fflush(_coverage_fout);
  _TIFFSetupFields(tif, infoarray);
  fprintf(_coverage_fout, "4190\n");
  fflush(_coverage_fout);
  dircount = TIFFFetchDirectory(tif, diroff, & dir, (uint64 *)((void *)0));
  fprintf(_coverage_fout, "4191\n");
  fflush(_coverage_fout);
  if (! dircount) {
    fprintf(_coverage_fout, "4135\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___1,
                 "Failed to read custom directory at offset %llu", diroff);
    fprintf(_coverage_fout, "4136\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "4137\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4192\n");
  fflush(_coverage_fout);
  TIFFFreeDirectory(tif);
  fprintf(_coverage_fout, "4193\n");
  fflush(_coverage_fout);
  TIFFReadDirectoryCheckOrder(tif, dir, dircount);
  fprintf(_coverage_fout, "4194\n");
  fflush(_coverage_fout);
  di = (unsigned short)0;
  fprintf(_coverage_fout, "4195\n");
  fflush(_coverage_fout);
  dp = dir;
  fprintf(_coverage_fout, "4196\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "4181\n");
    fflush(_coverage_fout);
    if ((int )di < (int )dircount) {
      fprintf(_coverage_fout, "4138\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "4182\n");
    fflush(_coverage_fout);
    TIFFReadDirectoryFindFieldInfo(tif, dp->tdir_tag, & fii);
    fprintf(_coverage_fout, "4183\n");
    fflush(_coverage_fout);
    if (fii == 65535U) {
      fprintf(_coverage_fout, "4145\n");
      fflush(_coverage_fout);
      TIFFWarningExt(tif->tif_clientdata, module___1,
                     "Unknown field with tag %d (0x%x) encountered",
                     dp->tdir_tag, dp->tdir_tag);
      fprintf(_coverage_fout, "4146\n");
      fflush(_coverage_fout);
      tmp = _TIFFCreateAnonField(tif, (unsigned int )dp->tdir_tag,
                                 (enum __anonenum_TIFFDataType_21 )dp->tdir_type);
      fprintf(_coverage_fout, "4147\n");
      fflush(_coverage_fout);
      tmp___0 = _TIFFMergeFields(tif, (TIFFField const   *)tmp, 1U);
      fprintf(_coverage_fout, "4148\n");
      fflush(_coverage_fout);
      if (tmp___0) {
        fprintf(_coverage_fout, "4141\n");
        fflush(_coverage_fout);
        TIFFReadDirectoryFindFieldInfo(tif, dp->tdir_tag, & fii);
        fprintf(_coverage_fout, "4142\n");
        fflush(_coverage_fout);
        if (fii != 65535U) {
          fprintf(_coverage_fout, "4139\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "4140\n");
          fflush(_coverage_fout);
          __assert_fail("fii!=0xFFFF", "tif_dirread.c", 4023U,
                        "TIFFReadCustomDirectory");
        }
      } else {
        fprintf(_coverage_fout, "4143\n");
        fflush(_coverage_fout);
        TIFFWarningExt(tif->tif_clientdata, module___1,
                       "Registering anonymous field with tag %d (0x%x) failed",
                       dp->tdir_tag, dp->tdir_tag);
        fprintf(_coverage_fout, "4144\n");
        fflush(_coverage_fout);
        dp->tdir_tag = (unsigned short)0;
      }
    } else {
      fprintf(_coverage_fout, "4149\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4184\n");
    fflush(_coverage_fout);
    if ((int )dp->tdir_tag != 0) {
      fprintf(_coverage_fout, "4178\n");
      fflush(_coverage_fout);
      fip = (TIFFField const   *)*(tif->tif_fields + fii);
      fprintf(_coverage_fout, "4179\n");
      fflush(_coverage_fout);
      if ((int const   )fip->field_bit == 0) {
        fprintf(_coverage_fout, "4150\n");
        fflush(_coverage_fout);
        dp->tdir_tag = (unsigned short)0;
      } else {
        fprintf(_coverage_fout, "4174\n");
        fflush(_coverage_fout);
        while (1) {
          fprintf(_coverage_fout, "4157\n");
          fflush(_coverage_fout);
          if ((unsigned int const   )fip->field_type != 0U) {
            fprintf(_coverage_fout, "4152\n");
            fflush(_coverage_fout);
            if ((unsigned int const   )fip->field_type != (unsigned int const   )dp->tdir_type) {
              fprintf(_coverage_fout, "4151\n");
              fflush(_coverage_fout);

            } else {
              break;
            }
          } else {
            break;
          }
          fprintf(_coverage_fout, "4158\n");
          fflush(_coverage_fout);
          fii ++;
          fprintf(_coverage_fout, "4159\n");
          fflush(_coverage_fout);
          if (fii == tif->tif_nfields) {
            fprintf(_coverage_fout, "4153\n");
            fflush(_coverage_fout);
            fii = 65535U;
            break;
          } else {
            fprintf(_coverage_fout, "4156\n");
            fflush(_coverage_fout);
            if ((*(tif->tif_fields + fii))->field_tag != (unsigned int )dp->tdir_tag) {
              fprintf(_coverage_fout, "4154\n");
              fflush(_coverage_fout);
              fii = 65535U;
              break;
            } else {
              fprintf(_coverage_fout, "4155\n");
              fflush(_coverage_fout);

            }
          }
          fprintf(_coverage_fout, "4160\n");
          fflush(_coverage_fout);
          fip = (TIFFField const   *)*(tif->tif_fields + fii);
        }
        fprintf(_coverage_fout, "4175\n");
        fflush(_coverage_fout);
        if (fii == 65535U) {
          fprintf(_coverage_fout, "4161\n");
          fflush(_coverage_fout);
          TIFFWarningExt(tif->tif_clientdata, module___1,
                         "Wrong data type %d for \"%s\"; tag ignored",
                         dp->tdir_type, fip->field_name);
          fprintf(_coverage_fout, "4162\n");
          fflush(_coverage_fout);
          dp->tdir_tag = (unsigned short)0;
        } else {
          fprintf(_coverage_fout, "4173\n");
          fflush(_coverage_fout);
          if ((int const   )fip->field_readcount != -1) {
            fprintf(_coverage_fout, "4171\n");
            fflush(_coverage_fout);
            if ((int const   )fip->field_readcount != -3) {
              fprintf(_coverage_fout, "4167\n");
              fflush(_coverage_fout);
              if ((int const   )fip->field_readcount == -2) {
                fprintf(_coverage_fout, "4163\n");
                fflush(_coverage_fout);
                expected = (unsigned int )tif->tif_dir.td_samplesperpixel;
              } else {
                fprintf(_coverage_fout, "4164\n");
                fflush(_coverage_fout);
                expected = (unsigned int )fip->field_readcount;
              }
              fprintf(_coverage_fout, "4168\n");
              fflush(_coverage_fout);
              tmp___1 = CheckDirCount(tif, dp, expected);
              fprintf(_coverage_fout, "4169\n");
              fflush(_coverage_fout);
              if (tmp___1) {
                fprintf(_coverage_fout, "4165\n");
                fflush(_coverage_fout);

              } else {
                fprintf(_coverage_fout, "4166\n");
                fflush(_coverage_fout);
                dp->tdir_tag = (unsigned short)0;
              }
            } else {
              fprintf(_coverage_fout, "4170\n");
              fflush(_coverage_fout);

            }
          } else {
            fprintf(_coverage_fout, "4172\n");
            fflush(_coverage_fout);

          }
        }
      }
      switch ((int )dp->tdir_tag) {
      fprintf(_coverage_fout, "4176\n");
      fflush(_coverage_fout);
      case 37382: 
      TIFFFetchSubjectDistance(tif, dp);
      break;
      fprintf(_coverage_fout, "4177\n");
      fflush(_coverage_fout);
      default: 
      TIFFFetchNormalTag(tif, dp, 1);
      break;
      }
    } else {
      fprintf(_coverage_fout, "4180\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4185\n");
    fflush(_coverage_fout);
    di = (uint16 )((int )di + 1);
    fprintf(_coverage_fout, "4186\n");
    fflush(_coverage_fout);
    dp ++;
  }
  fprintf(_coverage_fout, "4197\n");
  fflush(_coverage_fout);
  if (dir) {
    fprintf(_coverage_fout, "4187\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)dir);
  } else {
    fprintf(_coverage_fout, "4188\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4198\n");
  fflush(_coverage_fout);
  return (1);
}
}
int TIFFReadEXIFDirectory(TIFF *tif , uint64 diroff ) 
{ TIFFFieldArray const   *exifFieldArray ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "4199\n");
  fflush(_coverage_fout);
  exifFieldArray = _TIFFGetExifFields();
  fprintf(_coverage_fout, "4200\n");
  fflush(_coverage_fout);
  tmp = TIFFReadCustomDirectory(tif, diroff, exifFieldArray);
  fprintf(_coverage_fout, "4201\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int EstimateStripByteCounts(TIFF *tif , TIFFDirEntry *dir ,
                                   uint16 dircount ) ;
static char const   module___2[24]  = 
  {      (char const   )'E',      (char const   )'s',      (char const   )'t',      (char const   )'i', 
        (char const   )'m',      (char const   )'a',      (char const   )'t',      (char const   )'e', 
        (char const   )'S',      (char const   )'t',      (char const   )'r',      (char const   )'i', 
        (char const   )'p',      (char const   )'B',      (char const   )'y',      (char const   )'t', 
        (char const   )'e',      (char const   )'C',      (char const   )'o',      (char const   )'u', 
        (char const   )'n',      (char const   )'t',      (char const   )'s',      (char const   )'\000'};
static int EstimateStripByteCounts(TIFF *tif , TIFFDirEntry *dir ,
                                   uint16 dircount ) 
{ TIFFDirEntry *dp ;
  TIFFDirectory *td ;
  uint32 strip ;
  void *tmp ;
  uint64 space ;
  uint64 filesize ;
  uint16 n ;
  uint32 typewidth ;
  int tmp___0 ;
  uint64 datasize ;
  int tmp___1 ;
  uint64 bytespertile ;
  uint64 tmp___2 ;
  uint64 rowbytes ;
  uint64 tmp___3 ;
  uint32 rowsperstrip ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "4266\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "4267\n");
  fflush(_coverage_fout);
  if (td->td_stripbytecount) {
    fprintf(_coverage_fout, "4202\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)td->td_stripbytecount);
  } else {
    fprintf(_coverage_fout, "4203\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4268\n");
  fflush(_coverage_fout);
  tmp = _TIFFCheckMalloc(tif, (long )td->td_nstrips, (long )sizeof(uint64 ),
                         "for \"StripByteCounts\" array");
  fprintf(_coverage_fout, "4269\n");
  fflush(_coverage_fout);
  td->td_stripbytecount = (uint64 *)tmp;
  fprintf(_coverage_fout, "4270\n");
  fflush(_coverage_fout);
  if ((int )td->td_compression != 1) {
    fprintf(_coverage_fout, "4235\n");
    fflush(_coverage_fout);
    filesize = (*(tif->tif_sizeproc))(tif->tif_clientdata);
    fprintf(_coverage_fout, "4236\n");
    fflush(_coverage_fout);
    if (! (tif->tif_flags & 524288U)) {
      fprintf(_coverage_fout, "4204\n");
      fflush(_coverage_fout);
      space = (unsigned long long )(((sizeof(TIFFHeaderClassic ) + 2U) + (unsigned int )((int )dircount * 12)) + 4U);
    } else {
      fprintf(_coverage_fout, "4205\n");
      fflush(_coverage_fout);
      space = (unsigned long long )(((sizeof(TIFFHeaderBig ) + 8U) + (unsigned int )((int )dircount * 20)) + 8U);
    }
    fprintf(_coverage_fout, "4237\n");
    fflush(_coverage_fout);
    dp = dir;
    fprintf(_coverage_fout, "4238\n");
    fflush(_coverage_fout);
    n = dircount;
    fprintf(_coverage_fout, "4239\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "4216\n");
      fflush(_coverage_fout);
      if ((int )n > 0) {
        fprintf(_coverage_fout, "4206\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "4217\n");
      fflush(_coverage_fout);
      tmp___0 = TIFFDataWidth((enum __anonenum_TIFFDataType_21 )dp->tdir_type);
      fprintf(_coverage_fout, "4218\n");
      fflush(_coverage_fout);
      typewidth = (uint32 )tmp___0;
      fprintf(_coverage_fout, "4219\n");
      fflush(_coverage_fout);
      tmp___1 = TIFFDataWidth((enum __anonenum_TIFFDataType_21 )dp->tdir_type);
      fprintf(_coverage_fout, "4220\n");
      fflush(_coverage_fout);
      typewidth = (unsigned int )tmp___1;
      fprintf(_coverage_fout, "4221\n");
      fflush(_coverage_fout);
      if (typewidth == 0U) {
        fprintf(_coverage_fout, "4207\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___2,
                     "Cannot determine size of unknown tag type %d",
                     dp->tdir_type);
        fprintf(_coverage_fout, "4208\n");
        fflush(_coverage_fout);
        return (-1);
      } else {
        fprintf(_coverage_fout, "4209\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4222\n");
      fflush(_coverage_fout);
      datasize = (unsigned long long )typewidth * dp->tdir_count;
      fprintf(_coverage_fout, "4223\n");
      fflush(_coverage_fout);
      if (! (tif->tif_flags & 524288U)) {
        fprintf(_coverage_fout, "4212\n");
        fflush(_coverage_fout);
        if (datasize <= 4ULL) {
          fprintf(_coverage_fout, "4210\n");
          fflush(_coverage_fout);
          datasize = 0ULL;
        } else {
          fprintf(_coverage_fout, "4211\n");
          fflush(_coverage_fout);

        }
      } else {
        fprintf(_coverage_fout, "4215\n");
        fflush(_coverage_fout);
        if (datasize <= 8ULL) {
          fprintf(_coverage_fout, "4213\n");
          fflush(_coverage_fout);
          datasize = 0ULL;
        } else {
          fprintf(_coverage_fout, "4214\n");
          fflush(_coverage_fout);

        }
      }
      fprintf(_coverage_fout, "4224\n");
      fflush(_coverage_fout);
      space += datasize;
      fprintf(_coverage_fout, "4225\n");
      fflush(_coverage_fout);
      n = (uint16 )((int )n - 1);
      fprintf(_coverage_fout, "4226\n");
      fflush(_coverage_fout);
      dp ++;
    }
    fprintf(_coverage_fout, "4240\n");
    fflush(_coverage_fout);
    space = filesize - space;
    fprintf(_coverage_fout, "4241\n");
    fflush(_coverage_fout);
    if ((int )td->td_planarconfig == 2) {
      fprintf(_coverage_fout, "4227\n");
      fflush(_coverage_fout);
      space /= (uint64 )td->td_samplesperpixel;
    } else {
      fprintf(_coverage_fout, "4228\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4242\n");
    fflush(_coverage_fout);
    strip = 0U;
    fprintf(_coverage_fout, "4243\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "4230\n");
      fflush(_coverage_fout);
      if (strip < td->td_nstrips) {
        fprintf(_coverage_fout, "4229\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "4231\n");
      fflush(_coverage_fout);
      *(td->td_stripbytecount + strip) = space;
      fprintf(_coverage_fout, "4232\n");
      fflush(_coverage_fout);
      strip ++;
    }
    fprintf(_coverage_fout, "4244\n");
    fflush(_coverage_fout);
    strip --;
    fprintf(_coverage_fout, "4245\n");
    fflush(_coverage_fout);
    if (*(td->td_stripoffset + strip) + *(td->td_stripbytecount + strip) > filesize) {
      fprintf(_coverage_fout, "4233\n");
      fflush(_coverage_fout);
      *(td->td_stripbytecount + strip) = filesize - *(td->td_stripoffset + strip);
    } else {
      fprintf(_coverage_fout, "4234\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "4263\n");
    fflush(_coverage_fout);
    if ((tif->tif_flags & 1024U) != 0U) {
      fprintf(_coverage_fout, "4250\n");
      fflush(_coverage_fout);
      tmp___2 = TIFFTileSize64(tif);
      fprintf(_coverage_fout, "4251\n");
      fflush(_coverage_fout);
      bytespertile = tmp___2;
      fprintf(_coverage_fout, "4252\n");
      fflush(_coverage_fout);
      strip = 0U;
      fprintf(_coverage_fout, "4253\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "4247\n");
        fflush(_coverage_fout);
        if (strip < td->td_nstrips) {
          fprintf(_coverage_fout, "4246\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "4248\n");
        fflush(_coverage_fout);
        *(td->td_stripbytecount + strip) = bytespertile;
        fprintf(_coverage_fout, "4249\n");
        fflush(_coverage_fout);
        strip ++;
      }
    } else {
      fprintf(_coverage_fout, "4258\n");
      fflush(_coverage_fout);
      tmp___3 = TIFFScanlineSize64(tif);
      fprintf(_coverage_fout, "4259\n");
      fflush(_coverage_fout);
      rowbytes = tmp___3;
      fprintf(_coverage_fout, "4260\n");
      fflush(_coverage_fout);
      rowsperstrip = td->td_imagelength / td->td_stripsperimage;
      fprintf(_coverage_fout, "4261\n");
      fflush(_coverage_fout);
      strip = 0U;
      fprintf(_coverage_fout, "4262\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "4255\n");
        fflush(_coverage_fout);
        if (strip < td->td_nstrips) {
          fprintf(_coverage_fout, "4254\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "4256\n");
        fflush(_coverage_fout);
        *(td->td_stripbytecount + strip) = rowbytes * (uint64 )rowsperstrip;
        fprintf(_coverage_fout, "4257\n");
        fflush(_coverage_fout);
        strip ++;
      }
    }
  }
  fprintf(_coverage_fout, "4271\n");
  fflush(_coverage_fout);
  tif->tif_dir.td_fieldsset[0] |= 1UL << 24;
  fprintf(_coverage_fout, "4272\n");
  fflush(_coverage_fout);
  if (! (tif->tif_dir.td_fieldsset[0] & (1UL << 17))) {
    fprintf(_coverage_fout, "4264\n");
    fflush(_coverage_fout);
    td->td_rowsperstrip = td->td_imagelength;
  } else {
    fprintf(_coverage_fout, "4265\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4273\n");
  fflush(_coverage_fout);
  return (1);
}
}
static void MissingRequired(TIFF *tif , char const   *tagname ) ;
static char const   module___3[16]  = 
  {      (char const   )'M',      (char const   )'i',      (char const   )'s',      (char const   )'s', 
        (char const   )'i',      (char const   )'n',      (char const   )'g',      (char const   )'R', 
        (char const   )'e',      (char const   )'q',      (char const   )'u',      (char const   )'i', 
        (char const   )'r',      (char const   )'e',      (char const   )'d',      (char const   )'\000'};
static void MissingRequired(TIFF *tif , char const   *tagname ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "4274\n");
  fflush(_coverage_fout);
  TIFFErrorExt(tif->tif_clientdata, module___3,
               "TIFF directory is missing required \"%s\" field", tagname);
  fprintf(_coverage_fout, "4275\n");
  fflush(_coverage_fout);
  return;
}
}
static int TIFFCheckDirOffset(TIFF *tif , uint64 diroff ) 
{ uint16 n ;
  uint64 *new_dirlist ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "4293\n");
  fflush(_coverage_fout);
  if (diroff == 0ULL) {
    fprintf(_coverage_fout, "4276\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "4277\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4294\n");
  fflush(_coverage_fout);
  n = (unsigned short)0;
  fprintf(_coverage_fout, "4295\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "4282\n");
    fflush(_coverage_fout);
    if ((int )n < (int )tif->tif_dirnumber) {
      fprintf(_coverage_fout, "4279\n");
      fflush(_coverage_fout);
      if (tif->tif_dirlist) {
        fprintf(_coverage_fout, "4278\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "4283\n");
    fflush(_coverage_fout);
    if (*(tif->tif_dirlist + n) == diroff) {
      fprintf(_coverage_fout, "4280\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "4281\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4284\n");
    fflush(_coverage_fout);
    n = (uint16 )((int )n + 1);
  }
  fprintf(_coverage_fout, "4296\n");
  fflush(_coverage_fout);
  tif->tif_dirnumber = (uint16 )((int )tif->tif_dirnumber + 1);
  fprintf(_coverage_fout, "4297\n");
  fflush(_coverage_fout);
  if ((int )tif->tif_dirnumber > (int )tif->tif_dirlistsize) {
    fprintf(_coverage_fout, "4287\n");
    fflush(_coverage_fout);
    tmp = _TIFFCheckRealloc(tif, (void *)tif->tif_dirlist,
                            (long )tif->tif_dirnumber,
                            (long )(2U * sizeof(uint64 )), "for IFD list");
    fprintf(_coverage_fout, "4288\n");
    fflush(_coverage_fout);
    new_dirlist = (uint64 *)tmp;
    fprintf(_coverage_fout, "4289\n");
    fflush(_coverage_fout);
    if (! new_dirlist) {
      fprintf(_coverage_fout, "4285\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "4286\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4290\n");
    fflush(_coverage_fout);
    tif->tif_dirlistsize = (unsigned short )(2 * (int )tif->tif_dirnumber);
    fprintf(_coverage_fout, "4291\n");
    fflush(_coverage_fout);
    tif->tif_dirlist = new_dirlist;
  } else {
    fprintf(_coverage_fout, "4292\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4298\n");
  fflush(_coverage_fout);
  *(tif->tif_dirlist + ((int )tif->tif_dirnumber - 1)) = diroff;
  fprintf(_coverage_fout, "4299\n");
  fflush(_coverage_fout);
  return (1);
}
}
static int CheckDirCount(TIFF *tif , TIFFDirEntry *dir , uint32 count ) 
{ TIFFField const   *tmp ;
  TIFFField const   *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "4308\n");
  fflush(_coverage_fout);
  if ((unsigned long long )count > dir->tdir_count) {
    fprintf(_coverage_fout, "4300\n");
    fflush(_coverage_fout);
    tmp = TIFFFieldWithTag(tif, (unsigned int )dir->tdir_tag);
    fprintf(_coverage_fout, "4301\n");
    fflush(_coverage_fout);
    TIFFWarningExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                   "incorrect count for field \"%s\" (%llu, expecting %lu); tag ignored",
                   tmp->field_name, dir->tdir_count, count);
    fprintf(_coverage_fout, "4302\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "4307\n");
    fflush(_coverage_fout);
    if ((unsigned long long )count < dir->tdir_count) {
      fprintf(_coverage_fout, "4303\n");
      fflush(_coverage_fout);
      tmp___0 = TIFFFieldWithTag(tif, (unsigned int )dir->tdir_tag);
      fprintf(_coverage_fout, "4304\n");
      fflush(_coverage_fout);
      TIFFWarningExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                     "incorrect count for field \"%s\" (%llu, expecting %lu); tag trimmed",
                     tmp___0->field_name, dir->tdir_count, count);
      fprintf(_coverage_fout, "4305\n");
      fflush(_coverage_fout);
      return (1);
    } else {
      fprintf(_coverage_fout, "4306\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "4309\n");
  fflush(_coverage_fout);
  return (1);
}
}
static uint16 TIFFFetchDirectory(TIFF *tif , uint64 diroff ,
                                 TIFFDirEntry **pdir , uint64 *nextdiroff ) ;
static char const   module___4[19]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'F',      (char const   )'e',      (char const   )'t',      (char const   )'c', 
        (char const   )'h',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'\000'};
static uint16 TIFFFetchDirectory(TIFF *tif , uint64 diroff ,
                                 TIFFDirEntry **pdir , uint64 *nextdiroff ) 
{ void *origdir ;
  uint16 dircount16 ;
  uint32 dirsize ;
  TIFFDirEntry *dir ;
  uint8 *ma ;
  TIFFDirEntry *mb ;
  uint16 n ;
  uint64 tmp ;
  tmsize_t tmp___0 ;
  uint64 dircount64 ;
  tmsize_t tmp___1 ;
  tmsize_t tmp___2 ;
  uint32 nextdiroff32 ;
  tmsize_t tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t m ;
  tmsize_t off ;
  tmsize_t m___0 ;
  uint64 dircount64___0 ;
  uint32 nextdiroff32___0 ;
  void *tmp___5 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "4499\n");
  fflush(_coverage_fout);
  if (pdir) {
    fprintf(_coverage_fout, "4310\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4311\n");
    fflush(_coverage_fout);
    __assert_fail("pdir", "tif_dirread.c", 4269U, "TIFFFetchDirectory");
  }
  fprintf(_coverage_fout, "4500\n");
  fflush(_coverage_fout);
  tif->tif_diroff = diroff;
  fprintf(_coverage_fout, "4501\n");
  fflush(_coverage_fout);
  if (nextdiroff) {
    fprintf(_coverage_fout, "4312\n");
    fflush(_coverage_fout);
    *nextdiroff = 0ULL;
  } else {
    fprintf(_coverage_fout, "4313\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4502\n");
  fflush(_coverage_fout);
  if (! ((tif->tif_flags & 2048U) != 0U)) {
    fprintf(_coverage_fout, "4367\n");
    fflush(_coverage_fout);
    tmp = (*(tif->tif_seekproc))(tif->tif_clientdata, tif->tif_diroff, 0);
    fprintf(_coverage_fout, "4368\n");
    fflush(_coverage_fout);
    if (tmp == tif->tif_diroff) {
      fprintf(_coverage_fout, "4314\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "4315\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___4,
                   "%s: Seek error accessing TIFF directory", tif->tif_name);
      fprintf(_coverage_fout, "4316\n");
      fflush(_coverage_fout);
      return ((unsigned short)0);
    }
    fprintf(_coverage_fout, "4369\n");
    fflush(_coverage_fout);
    if (! (tif->tif_flags & 524288U)) {
      fprintf(_coverage_fout, "4325\n");
      fflush(_coverage_fout);
      tmp___0 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                       (void *)(& dircount16),
                                       (long )sizeof(uint16 ));
      fprintf(_coverage_fout, "4326\n");
      fflush(_coverage_fout);
      if ((unsigned long )tmp___0 == (unsigned long )sizeof(uint16 )) {
        fprintf(_coverage_fout, "4317\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "4318\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___4,
                     "%s: Can not read TIFF directory count", tif->tif_name);
        fprintf(_coverage_fout, "4319\n");
        fflush(_coverage_fout);
        return ((unsigned short)0);
      }
      fprintf(_coverage_fout, "4327\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "4320\n");
        fflush(_coverage_fout);
        TIFFSwabShort(& dircount16);
      } else {
        fprintf(_coverage_fout, "4321\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4328\n");
      fflush(_coverage_fout);
      if ((int )dircount16 > 4096) {
        fprintf(_coverage_fout, "4322\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___4,
                     "Sanity check on directory count failed, this is probably not a valid IFD offset");
        fprintf(_coverage_fout, "4323\n");
        fflush(_coverage_fout);
        return ((unsigned short)0);
      } else {
        fprintf(_coverage_fout, "4324\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4329\n");
      fflush(_coverage_fout);
      dirsize = 12U;
    } else {
      fprintf(_coverage_fout, "4338\n");
      fflush(_coverage_fout);
      tmp___1 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                       (void *)(& dircount64),
                                       (long )sizeof(uint64 ));
      fprintf(_coverage_fout, "4339\n");
      fflush(_coverage_fout);
      if ((unsigned long )tmp___1 == (unsigned long )sizeof(uint64 )) {
        fprintf(_coverage_fout, "4330\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "4331\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___4,
                     "%s: Can not read TIFF directory count", tif->tif_name);
        fprintf(_coverage_fout, "4332\n");
        fflush(_coverage_fout);
        return ((unsigned short)0);
      }
      fprintf(_coverage_fout, "4340\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "4333\n");
        fflush(_coverage_fout);
        TIFFSwabLong8(& dircount64);
      } else {
        fprintf(_coverage_fout, "4334\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4341\n");
      fflush(_coverage_fout);
      if (dircount64 > 4096ULL) {
        fprintf(_coverage_fout, "4335\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___4,
                     "Sanity check on directory count failed, this is probably not a valid IFD offset");
        fprintf(_coverage_fout, "4336\n");
        fflush(_coverage_fout);
        return ((unsigned short)0);
      } else {
        fprintf(_coverage_fout, "4337\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4342\n");
      fflush(_coverage_fout);
      dircount16 = (unsigned short )dircount64;
      fprintf(_coverage_fout, "4343\n");
      fflush(_coverage_fout);
      dirsize = 20U;
    }
    fprintf(_coverage_fout, "4370\n");
    fflush(_coverage_fout);
    origdir = _TIFFCheckMalloc(tif, (long )dircount16, (long )dirsize,
                               "to read TIFF directory");
    fprintf(_coverage_fout, "4371\n");
    fflush(_coverage_fout);
    if ((unsigned int )origdir == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "4344\n");
      fflush(_coverage_fout);
      return ((unsigned short)0);
    } else {
      fprintf(_coverage_fout, "4345\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4372\n");
    fflush(_coverage_fout);
    tmp___2 = (*(tif->tif_readproc))(tif->tif_clientdata, origdir,
                                     (long )((uint32 )dircount16 * dirsize));
    fprintf(_coverage_fout, "4373\n");
    fflush(_coverage_fout);
    if (tmp___2 == (long )((uint32 )dircount16 * dirsize)) {
      fprintf(_coverage_fout, "4346\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "4347\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___4,
                   "%.100s: Can not read TIFF directory", tif->tif_name);
      fprintf(_coverage_fout, "4348\n");
      fflush(_coverage_fout);
      _TIFFfree(origdir);
      fprintf(_coverage_fout, "4349\n");
      fflush(_coverage_fout);
      return ((unsigned short)0);
    }
    fprintf(_coverage_fout, "4374\n");
    fflush(_coverage_fout);
    if (nextdiroff) {
      fprintf(_coverage_fout, "4365\n");
      fflush(_coverage_fout);
      if (! (tif->tif_flags & 524288U)) {
        fprintf(_coverage_fout, "4354\n");
        fflush(_coverage_fout);
        tmp___3 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                         (void *)(& nextdiroff32),
                                         (long )sizeof(uint32 ));
        fprintf(_coverage_fout, "4355\n");
        fflush(_coverage_fout);
        if ((unsigned long )tmp___3 == (unsigned long )sizeof(uint32 )) {
          fprintf(_coverage_fout, "4350\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "4351\n");
          fflush(_coverage_fout);
          nextdiroff32 = 0U;
        }
        fprintf(_coverage_fout, "4356\n");
        fflush(_coverage_fout);
        if (tif->tif_flags & 128U) {
          fprintf(_coverage_fout, "4352\n");
          fflush(_coverage_fout);
          TIFFSwabLong(& nextdiroff32);
        } else {
          fprintf(_coverage_fout, "4353\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "4357\n");
        fflush(_coverage_fout);
        *nextdiroff = (unsigned long long )nextdiroff32;
      } else {
        fprintf(_coverage_fout, "4362\n");
        fflush(_coverage_fout);
        tmp___4 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                         (void *)nextdiroff,
                                         (long )sizeof(uint64 ));
        fprintf(_coverage_fout, "4363\n");
        fflush(_coverage_fout);
        if ((unsigned long )tmp___4 == (unsigned long )sizeof(uint64 )) {
          fprintf(_coverage_fout, "4358\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "4359\n");
          fflush(_coverage_fout);
          *nextdiroff = 0ULL;
        }
        fprintf(_coverage_fout, "4364\n");
        fflush(_coverage_fout);
        if (tif->tif_flags & 128U) {
          fprintf(_coverage_fout, "4360\n");
          fflush(_coverage_fout);
          TIFFSwabLong8(nextdiroff);
        } else {
          fprintf(_coverage_fout, "4361\n");
          fflush(_coverage_fout);

        }
      }
    } else {
      fprintf(_coverage_fout, "4366\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "4459\n");
    fflush(_coverage_fout);
    off = (long )tif->tif_diroff;
    fprintf(_coverage_fout, "4460\n");
    fflush(_coverage_fout);
    if ((unsigned long long )off != tif->tif_diroff) {
      fprintf(_coverage_fout, "4375\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___4,
                   "Can not read TIFF directory count");
      fprintf(_coverage_fout, "4376\n");
      fflush(_coverage_fout);
      return ((unsigned short)0);
    } else {
      fprintf(_coverage_fout, "4377\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4461\n");
    fflush(_coverage_fout);
    if (! (tif->tif_flags & 524288U)) {
      fprintf(_coverage_fout, "4392\n");
      fflush(_coverage_fout);
      m = (long )((unsigned long )off + (unsigned long )sizeof(uint16 ));
      fprintf(_coverage_fout, "4393\n");
      fflush(_coverage_fout);
      if (m < off) {
        fprintf(_coverage_fout, "4378\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___4,
                     "Can not read TIFF directory count");
        fprintf(_coverage_fout, "4379\n");
        fflush(_coverage_fout);
        return ((unsigned short)0);
      } else {
        fprintf(_coverage_fout, "4386\n");
        fflush(_coverage_fout);
        if (m < (long )sizeof(uint16 )) {
          fprintf(_coverage_fout, "4380\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___4,
                       "Can not read TIFF directory count");
          fprintf(_coverage_fout, "4381\n");
          fflush(_coverage_fout);
          return ((unsigned short)0);
        } else {
          fprintf(_coverage_fout, "4385\n");
          fflush(_coverage_fout);
          if (m > tif->tif_size) {
            fprintf(_coverage_fout, "4382\n");
            fflush(_coverage_fout);
            TIFFErrorExt(tif->tif_clientdata, module___4,
                         "Can not read TIFF directory count");
            fprintf(_coverage_fout, "4383\n");
            fflush(_coverage_fout);
            return ((unsigned short)0);
          } else {
            fprintf(_coverage_fout, "4384\n");
            fflush(_coverage_fout);
            _TIFFmemcpy((void *)(& dircount16),
                        (void const   *)(tif->tif_base + off),
                        (long )sizeof(uint16 ));
          }
        }
      }
      fprintf(_coverage_fout, "4394\n");
      fflush(_coverage_fout);
      off = (long )((unsigned long )off + (unsigned long )sizeof(uint16 ));
      fprintf(_coverage_fout, "4395\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "4387\n");
        fflush(_coverage_fout);
        TIFFSwabShort(& dircount16);
      } else {
        fprintf(_coverage_fout, "4388\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4396\n");
      fflush(_coverage_fout);
      if ((int )dircount16 > 4096) {
        fprintf(_coverage_fout, "4389\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___4,
                     "Sanity check on directory count failed, this is probably not a valid IFD offset");
        fprintf(_coverage_fout, "4390\n");
        fflush(_coverage_fout);
        return ((unsigned short)0);
      } else {
        fprintf(_coverage_fout, "4391\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4397\n");
      fflush(_coverage_fout);
      dirsize = 12U;
    } else {
      fprintf(_coverage_fout, "4412\n");
      fflush(_coverage_fout);
      m___0 = (long )((unsigned long )off + (unsigned long )sizeof(uint64 ));
      fprintf(_coverage_fout, "4413\n");
      fflush(_coverage_fout);
      if (m___0 < off) {
        fprintf(_coverage_fout, "4398\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___4,
                     "Can not read TIFF directory count");
        fprintf(_coverage_fout, "4399\n");
        fflush(_coverage_fout);
        return ((unsigned short)0);
      } else {
        fprintf(_coverage_fout, "4406\n");
        fflush(_coverage_fout);
        if (m___0 < (long )sizeof(uint64 )) {
          fprintf(_coverage_fout, "4400\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___4,
                       "Can not read TIFF directory count");
          fprintf(_coverage_fout, "4401\n");
          fflush(_coverage_fout);
          return ((unsigned short)0);
        } else {
          fprintf(_coverage_fout, "4405\n");
          fflush(_coverage_fout);
          if (m___0 > tif->tif_size) {
            fprintf(_coverage_fout, "4402\n");
            fflush(_coverage_fout);
            TIFFErrorExt(tif->tif_clientdata, module___4,
                         "Can not read TIFF directory count");
            fprintf(_coverage_fout, "4403\n");
            fflush(_coverage_fout);
            return ((unsigned short)0);
          } else {
            fprintf(_coverage_fout, "4404\n");
            fflush(_coverage_fout);
            _TIFFmemcpy((void *)(& dircount64___0),
                        (void const   *)(tif->tif_base + off),
                        (long )sizeof(uint64 ));
          }
        }
      }
      fprintf(_coverage_fout, "4414\n");
      fflush(_coverage_fout);
      off = (long )((unsigned long )off + (unsigned long )sizeof(uint64 ));
      fprintf(_coverage_fout, "4415\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "4407\n");
        fflush(_coverage_fout);
        TIFFSwabLong8(& dircount64___0);
      } else {
        fprintf(_coverage_fout, "4408\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4416\n");
      fflush(_coverage_fout);
      if (dircount64___0 > 4096ULL) {
        fprintf(_coverage_fout, "4409\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___4,
                     "Sanity check on directory count failed, this is probably not a valid IFD offset");
        fprintf(_coverage_fout, "4410\n");
        fflush(_coverage_fout);
        return ((unsigned short)0);
      } else {
        fprintf(_coverage_fout, "4411\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4417\n");
      fflush(_coverage_fout);
      dircount16 = (unsigned short )dircount64___0;
      fprintf(_coverage_fout, "4418\n");
      fflush(_coverage_fout);
      dirsize = 20U;
    }
    fprintf(_coverage_fout, "4462\n");
    fflush(_coverage_fout);
    origdir = _TIFFCheckMalloc(tif, (long )dircount16, (long )dirsize,
                               "to read TIFF directory");
    fprintf(_coverage_fout, "4463\n");
    fflush(_coverage_fout);
    if ((unsigned int )origdir == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "4419\n");
      fflush(_coverage_fout);
      return ((unsigned short)0);
    } else {
      fprintf(_coverage_fout, "4420\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4464\n");
    fflush(_coverage_fout);
    m = (long )((unsigned long )off + (unsigned long )((uint32 )dircount16 * dirsize));
    fprintf(_coverage_fout, "4465\n");
    fflush(_coverage_fout);
    if (m < off) {
      fprintf(_coverage_fout, "4421\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___4,
                   "Can not read TIFF directory");
      fprintf(_coverage_fout, "4422\n");
      fflush(_coverage_fout);
      _TIFFfree(origdir);
      fprintf(_coverage_fout, "4423\n");
      fflush(_coverage_fout);
      return ((unsigned short)0);
    } else {
      fprintf(_coverage_fout, "4432\n");
      fflush(_coverage_fout);
      if (m < (long )((uint32 )dircount16 * dirsize)) {
        fprintf(_coverage_fout, "4424\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___4,
                     "Can not read TIFF directory");
        fprintf(_coverage_fout, "4425\n");
        fflush(_coverage_fout);
        _TIFFfree(origdir);
        fprintf(_coverage_fout, "4426\n");
        fflush(_coverage_fout);
        return ((unsigned short)0);
      } else {
        fprintf(_coverage_fout, "4431\n");
        fflush(_coverage_fout);
        if (m > tif->tif_size) {
          fprintf(_coverage_fout, "4427\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___4,
                       "Can not read TIFF directory");
          fprintf(_coverage_fout, "4428\n");
          fflush(_coverage_fout);
          _TIFFfree(origdir);
          fprintf(_coverage_fout, "4429\n");
          fflush(_coverage_fout);
          return ((unsigned short)0);
        } else {
          fprintf(_coverage_fout, "4430\n");
          fflush(_coverage_fout);
          _TIFFmemcpy(origdir, (void const   *)(tif->tif_base + off),
                      (long )((uint32 )dircount16 * dirsize));
        }
      }
    }
    fprintf(_coverage_fout, "4466\n");
    fflush(_coverage_fout);
    if (nextdiroff) {
      fprintf(_coverage_fout, "4456\n");
      fflush(_coverage_fout);
      off = (long )((unsigned long )off + (unsigned long )((uint32 )dircount16 * dirsize));
      fprintf(_coverage_fout, "4457\n");
      fflush(_coverage_fout);
      if (! (tif->tif_flags & 524288U)) {
        fprintf(_coverage_fout, "4441\n");
        fflush(_coverage_fout);
        m = (long )((unsigned long )off + (unsigned long )sizeof(uint32 ));
        fprintf(_coverage_fout, "4442\n");
        fflush(_coverage_fout);
        if (m < off) {
          fprintf(_coverage_fout, "4433\n");
          fflush(_coverage_fout);
          nextdiroff32___0 = 0U;
        } else {
          fprintf(_coverage_fout, "4438\n");
          fflush(_coverage_fout);
          if (m < (long )sizeof(uint32 )) {
            fprintf(_coverage_fout, "4434\n");
            fflush(_coverage_fout);
            nextdiroff32___0 = 0U;
          } else {
            fprintf(_coverage_fout, "4437\n");
            fflush(_coverage_fout);
            if (m > tif->tif_size) {
              fprintf(_coverage_fout, "4435\n");
              fflush(_coverage_fout);
              nextdiroff32___0 = 0U;
            } else {
              fprintf(_coverage_fout, "4436\n");
              fflush(_coverage_fout);
              _TIFFmemcpy((void *)(& nextdiroff32___0),
                          (void const   *)(tif->tif_base + off),
                          (long )sizeof(uint32 ));
            }
          }
        }
        fprintf(_coverage_fout, "4443\n");
        fflush(_coverage_fout);
        if (tif->tif_flags & 128U) {
          fprintf(_coverage_fout, "4439\n");
          fflush(_coverage_fout);
          TIFFSwabLong(& nextdiroff32___0);
        } else {
          fprintf(_coverage_fout, "4440\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "4444\n");
        fflush(_coverage_fout);
        *nextdiroff = (unsigned long long )nextdiroff32___0;
      } else {
        fprintf(_coverage_fout, "4453\n");
        fflush(_coverage_fout);
        m = (long )((unsigned long )off + (unsigned long )sizeof(uint64 ));
        fprintf(_coverage_fout, "4454\n");
        fflush(_coverage_fout);
        if (m < off) {
          fprintf(_coverage_fout, "4445\n");
          fflush(_coverage_fout);
          *nextdiroff = 0ULL;
        } else {
          fprintf(_coverage_fout, "4450\n");
          fflush(_coverage_fout);
          if (m < (long )sizeof(uint64 )) {
            fprintf(_coverage_fout, "4446\n");
            fflush(_coverage_fout);
            *nextdiroff = 0ULL;
          } else {
            fprintf(_coverage_fout, "4449\n");
            fflush(_coverage_fout);
            if (m > tif->tif_size) {
              fprintf(_coverage_fout, "4447\n");
              fflush(_coverage_fout);
              *nextdiroff = 0ULL;
            } else {
              fprintf(_coverage_fout, "4448\n");
              fflush(_coverage_fout);
              _TIFFmemcpy((void *)nextdiroff,
                          (void const   *)(tif->tif_base + off),
                          (long )sizeof(uint64 ));
            }
          }
        }
        fprintf(_coverage_fout, "4455\n");
        fflush(_coverage_fout);
        if (tif->tif_flags & 128U) {
          fprintf(_coverage_fout, "4451\n");
          fflush(_coverage_fout);
          TIFFSwabLong8(nextdiroff);
        } else {
          fprintf(_coverage_fout, "4452\n");
          fflush(_coverage_fout);

        }
      }
    } else {
      fprintf(_coverage_fout, "4458\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "4503\n");
  fflush(_coverage_fout);
  tmp___5 = _TIFFCheckMalloc(tif, (long )dircount16,
                             (long )sizeof(TIFFDirEntry ),
                             "to read TIFF directory");
  fprintf(_coverage_fout, "4504\n");
  fflush(_coverage_fout);
  dir = (TIFFDirEntry *)tmp___5;
  fprintf(_coverage_fout, "4505\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((TIFFDirEntry *)0)) {
    fprintf(_coverage_fout, "4467\n");
    fflush(_coverage_fout);
    _TIFFfree(origdir);
    fprintf(_coverage_fout, "4468\n");
    fflush(_coverage_fout);
    return ((unsigned short)0);
  } else {
    fprintf(_coverage_fout, "4469\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "4506\n");
  fflush(_coverage_fout);
  ma = (uint8 *)origdir;
  fprintf(_coverage_fout, "4507\n");
  fflush(_coverage_fout);
  mb = dir;
  fprintf(_coverage_fout, "4508\n");
  fflush(_coverage_fout);
  n = (unsigned short)0;
  fprintf(_coverage_fout, "4509\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "4489\n");
    fflush(_coverage_fout);
    if ((int )n < (int )dircount16) {
      fprintf(_coverage_fout, "4470\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "4490\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "4471\n");
      fflush(_coverage_fout);
      TIFFSwabShort((uint16 *)ma);
    } else {
      fprintf(_coverage_fout, "4472\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4491\n");
    fflush(_coverage_fout);
    mb->tdir_tag = *((uint16 *)ma);
    fprintf(_coverage_fout, "4492\n");
    fflush(_coverage_fout);
    ma += sizeof(uint16 );
    fprintf(_coverage_fout, "4493\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "4473\n");
      fflush(_coverage_fout);
      TIFFSwabShort((uint16 *)ma);
    } else {
      fprintf(_coverage_fout, "4474\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4494\n");
    fflush(_coverage_fout);
    mb->tdir_type = *((uint16 *)ma);
    fprintf(_coverage_fout, "4495\n");
    fflush(_coverage_fout);
    ma += sizeof(uint16 );
    fprintf(_coverage_fout, "4496\n");
    fflush(_coverage_fout);
    if (! (tif->tif_flags & 524288U)) {
      fprintf(_coverage_fout, "4477\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "4475\n");
        fflush(_coverage_fout);
        TIFFSwabLong((uint32 *)ma);
      } else {
        fprintf(_coverage_fout, "4476\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4478\n");
      fflush(_coverage_fout);
      mb->tdir_count = (unsigned long long )*((uint32 *)ma);
      fprintf(_coverage_fout, "4479\n");
      fflush(_coverage_fout);
      ma += sizeof(uint32 );
      fprintf(_coverage_fout, "4480\n");
      fflush(_coverage_fout);
      *((uint32 *)(& mb->tdir_offset)) = *((uint32 *)ma);
      fprintf(_coverage_fout, "4481\n");
      fflush(_coverage_fout);
      ma += sizeof(uint32 );
    } else {
      fprintf(_coverage_fout, "4484\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "4482\n");
        fflush(_coverage_fout);
        TIFFSwabLong8((uint64 *)ma);
      } else {
        fprintf(_coverage_fout, "4483\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4485\n");
      fflush(_coverage_fout);
      mb->tdir_count = *((uint64 *)ma);
      fprintf(_coverage_fout, "4486\n");
      fflush(_coverage_fout);
      ma += sizeof(uint64 );
      fprintf(_coverage_fout, "4487\n");
      fflush(_coverage_fout);
      mb->tdir_offset = *((uint64 *)ma);
      fprintf(_coverage_fout, "4488\n");
      fflush(_coverage_fout);
      ma += sizeof(uint64 );
    }
    fprintf(_coverage_fout, "4497\n");
    fflush(_coverage_fout);
    mb ++;
    fprintf(_coverage_fout, "4498\n");
    fflush(_coverage_fout);
    n = (uint16 )((int )n + 1);
  }
  fprintf(_coverage_fout, "4510\n");
  fflush(_coverage_fout);
  _TIFFfree(origdir);
  fprintf(_coverage_fout, "4511\n");
  fflush(_coverage_fout);
  *pdir = dir;
  fprintf(_coverage_fout, "4512\n");
  fflush(_coverage_fout);
  return (dircount16);
}
}
static int TIFFFetchNormalTag(TIFF *tif , TIFFDirEntry *dp , int recover ) ;
static char const   module___5[19]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'F',      (char const   )'e',      (char const   )'t',      (char const   )'c', 
        (char const   )'h',      (char const   )'N',      (char const   )'o',      (char const   )'r', 
        (char const   )'m',      (char const   )'a',      (char const   )'l',      (char const   )'T', 
        (char const   )'a',      (char const   )'g',      (char const   )'\000'};
static int TIFFFetchNormalTag(TIFF *tif , TIFFDirEntry *dp , int recover ) 
{ enum TIFFReadDirEntryErr err ;
  uint32 fii ;
  TIFFField const   *fip ;
  uint8 *data ;
  uint8 *ma ;
  uint32 mb ;
  int n ;
  uint8 *o ;
  void *tmp ;
  uint8 data___0 ;
  int tmp___0 ;
  uint16 data___1 ;
  int tmp___1 ;
  uint32 data___2 ;
  int tmp___2 ;
  uint64 data___3 ;
  int tmp___3 ;
  double data___4 ;
  int tmp___4 ;
  uint64 data___5 ;
  int tmp___5 ;
  uint16 *data___6 ;
  int m ;
  uint8 *data___7 ;
  int m___0 ;
  uint16 *data___8 ;
  int m___1 ;
  uint32 *data___9 ;
  int m___2 ;
  float *data___10 ;
  int m___3 ;
  uint8 *data___11 ;
  int m___4 ;
  uint8 *data___12 ;
  int m___5 ;
  uint16 *data___13 ;
  int m___6 ;
  uint32 *data___14 ;
  int m___7 ;
  uint64 *data___15 ;
  int m___8 ;
  float *data___16 ;
  int m___9 ;
  double *data___17 ;
  int m___10 ;
  uint64 *data___18 ;
  int m___11 ;
  uint8 *data___19 ;
  int m___12 ;
  uint8 *data___20 ;
  int m___13 ;
  int8 *data___21 ;
  int m___14 ;
  uint16 *data___22 ;
  int m___15 ;
  int16 *data___23 ;
  int m___16 ;
  uint32 *data___24 ;
  int m___17 ;
  int32 *data___25 ;
  int m___18 ;
  uint64 *data___26 ;
  int m___19 ;
  int64 *data___27 ;
  int m___20 ;
  float *data___28 ;
  int m___21 ;
  double *data___29 ;
  int m___22 ;
  uint64 *data___30 ;
  int m___23 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5071\n");
  fflush(_coverage_fout);
  TIFFReadDirectoryFindFieldInfo(tif, dp->tdir_tag, & fii);
  fprintf(_coverage_fout, "5072\n");
  fflush(_coverage_fout);
  if (fii != 0xFFFFFFFF) {
    fprintf(_coverage_fout, "4513\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4514\n");
    fflush(_coverage_fout);
    __assert_fail("fii!=0xFFFFFFFF", "tif_dirread.c", 4513U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5073\n");
  fflush(_coverage_fout);
  if (fii == 0xFFFFFFFF) {
    fprintf(_coverage_fout, "4515\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, "TIFFFetchNormalTag",
                 "No definition found for tag %d", dp->tdir_tag);
    fprintf(_coverage_fout, "4516\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "4517\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "5074\n");
  fflush(_coverage_fout);
  fip = (TIFFField const   *)*(tif->tif_fields + fii);
  fprintf(_coverage_fout, "5075\n");
  fflush(_coverage_fout);
  if ((unsigned int const   )fip->set_field_type != 51U) {
    fprintf(_coverage_fout, "4518\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4519\n");
    fflush(_coverage_fout);
    __assert_fail("fip->set_field_type!=TIFF_SETGET_OTHER", "tif_dirread.c",
                  4522U, "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5076\n");
  fflush(_coverage_fout);
  if ((unsigned int const   )fip->set_field_type != 13U) {
    fprintf(_coverage_fout, "4520\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4521\n");
    fflush(_coverage_fout);
    __assert_fail("fip->set_field_type!=TIFF_SETGET_INT", "tif_dirread.c",
                  4523U, "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5077\n");
  fflush(_coverage_fout);
  err = (enum TIFFReadDirEntryErr )0;
  switch ((int )fip->set_field_type) {
  case 0: 
  break;
  fprintf(_coverage_fout, "4953\n");
  fflush(_coverage_fout);
  case 1: 
  if ((int const   )fip->field_passcount == 0) {
    fprintf(_coverage_fout, "4522\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4523\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==0", "tif_dirread.c", 4532U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4954\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryByteArray(tif, dp, & data);
  fprintf(_coverage_fout, "4955\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4554\n");
    fflush(_coverage_fout);
    ma = data;
    fprintf(_coverage_fout, "4555\n");
    fflush(_coverage_fout);
    mb = 0U;
    fprintf(_coverage_fout, "4556\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "4526\n");
      fflush(_coverage_fout);
      if (mb < (unsigned int )dp->tdir_count) {
        fprintf(_coverage_fout, "4524\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "4527\n");
      fflush(_coverage_fout);
      if ((int )*ma == 0) {
        break;
      } else {
        fprintf(_coverage_fout, "4525\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4528\n");
      fflush(_coverage_fout);
      ma ++;
      fprintf(_coverage_fout, "4529\n");
      fflush(_coverage_fout);
      mb ++;
    }
    fprintf(_coverage_fout, "4557\n");
    fflush(_coverage_fout);
    if (mb + 1U < (unsigned int )dp->tdir_count) {
      fprintf(_coverage_fout, "4530\n");
      fflush(_coverage_fout);
      TIFFWarningExt(tif->tif_clientdata, module___5,
                     "ASCII value for tag \"%s\" contains null byte in value; value incorrectly truncated during reading due to implementation limitations",
                     fip->field_name);
    } else {
      fprintf(_coverage_fout, "4549\n");
      fflush(_coverage_fout);
      if (mb + 1U > (unsigned int )dp->tdir_count) {
        fprintf(_coverage_fout, "4541\n");
        fflush(_coverage_fout);
        TIFFWarningExt(tif->tif_clientdata, module___5,
                       "ASCII value for tag \"%s\" does not end in null byte",
                       fip->field_name);
        fprintf(_coverage_fout, "4542\n");
        fflush(_coverage_fout);
        if ((uint64 )((unsigned int )dp->tdir_count + 1U) != dp->tdir_count + 1ULL) {
          fprintf(_coverage_fout, "4531\n");
          fflush(_coverage_fout);
          o = (uint8 *)((void *)0);
        } else {
          fprintf(_coverage_fout, "4532\n");
          fflush(_coverage_fout);
          tmp = _TIFFmalloc((long )((unsigned int )dp->tdir_count + 1U));
          fprintf(_coverage_fout, "4533\n");
          fflush(_coverage_fout);
          o = (uint8 *)tmp;
        }
        fprintf(_coverage_fout, "4543\n");
        fflush(_coverage_fout);
        if ((unsigned int )o == (unsigned int )((void *)0)) {
          fprintf(_coverage_fout, "4536\n");
          fflush(_coverage_fout);
          if ((unsigned int )data != (unsigned int )((void *)0)) {
            fprintf(_coverage_fout, "4534\n");
            fflush(_coverage_fout);
            _TIFFfree((void *)data);
          } else {
            fprintf(_coverage_fout, "4535\n");
            fflush(_coverage_fout);

          }
          fprintf(_coverage_fout, "4537\n");
          fflush(_coverage_fout);
          return (0);
        } else {
          fprintf(_coverage_fout, "4538\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "4544\n");
        fflush(_coverage_fout);
        _TIFFmemcpy((void *)o, (void const   *)data,
                    (long )((unsigned int )dp->tdir_count));
        fprintf(_coverage_fout, "4545\n");
        fflush(_coverage_fout);
        *(o + (unsigned int )dp->tdir_count) = (unsigned char)0;
        fprintf(_coverage_fout, "4546\n");
        fflush(_coverage_fout);
        if ((unsigned int )data != (unsigned int )((uint8 *)0)) {
          fprintf(_coverage_fout, "4539\n");
          fflush(_coverage_fout);
          _TIFFfree((void *)data);
        } else {
          fprintf(_coverage_fout, "4540\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "4547\n");
        fflush(_coverage_fout);
        data = o;
      } else {
        fprintf(_coverage_fout, "4548\n");
        fflush(_coverage_fout);

      }
    }
    fprintf(_coverage_fout, "4558\n");
    fflush(_coverage_fout);
    n = TIFFSetField(tif, (unsigned int )dp->tdir_tag, data);
    fprintf(_coverage_fout, "4559\n");
    fflush(_coverage_fout);
    if ((unsigned int )data != (unsigned int )((uint8 *)0)) {
      fprintf(_coverage_fout, "4550\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)data);
    } else {
      fprintf(_coverage_fout, "4551\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4560\n");
    fflush(_coverage_fout);
    if (! n) {
      fprintf(_coverage_fout, "4552\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "4553\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "4561\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "4956\n");
  fflush(_coverage_fout);
  case 2: 
  if ((int const   )fip->field_readcount == 1) {
    fprintf(_coverage_fout, "4562\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4563\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==1", "tif_dirread.c", 4581U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4957\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 0) {
    fprintf(_coverage_fout, "4564\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4565\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==0", "tif_dirread.c", 4582U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4958\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryByte(tif, dp, & data___0);
  fprintf(_coverage_fout, "4959\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4568\n");
    fflush(_coverage_fout);
    tmp___0 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, data___0);
    fprintf(_coverage_fout, "4569\n");
    fflush(_coverage_fout);
    if (tmp___0) {
      fprintf(_coverage_fout, "4566\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "4567\n");
      fflush(_coverage_fout);
      return (0);
    }
  } else {
    fprintf(_coverage_fout, "4570\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "4960\n");
  fflush(_coverage_fout);
  case 4: 
  if ((int const   )fip->field_readcount == 1) {
    fprintf(_coverage_fout, "4571\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4572\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==1", "tif_dirread.c", 4594U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4961\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 0) {
    fprintf(_coverage_fout, "4573\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4574\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==0", "tif_dirread.c", 4595U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4962\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryShort(tif, dp, & data___1);
  fprintf(_coverage_fout, "4963\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4577\n");
    fflush(_coverage_fout);
    tmp___1 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, data___1);
    fprintf(_coverage_fout, "4578\n");
    fflush(_coverage_fout);
    if (tmp___1) {
      fprintf(_coverage_fout, "4575\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "4576\n");
      fflush(_coverage_fout);
      return (0);
    }
  } else {
    fprintf(_coverage_fout, "4579\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "4964\n");
  fflush(_coverage_fout);
  case 6: 
  if ((int const   )fip->field_readcount == 1) {
    fprintf(_coverage_fout, "4580\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4581\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==1", "tif_dirread.c", 4607U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4965\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 0) {
    fprintf(_coverage_fout, "4582\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4583\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==0", "tif_dirread.c", 4608U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4966\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryLong(tif, dp, & data___2);
  fprintf(_coverage_fout, "4967\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4586\n");
    fflush(_coverage_fout);
    tmp___2 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, data___2);
    fprintf(_coverage_fout, "4587\n");
    fflush(_coverage_fout);
    if (tmp___2) {
      fprintf(_coverage_fout, "4584\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "4585\n");
      fflush(_coverage_fout);
      return (0);
    }
  } else {
    fprintf(_coverage_fout, "4588\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "4968\n");
  fflush(_coverage_fout);
  case 8: 
  if ((int const   )fip->field_readcount == 1) {
    fprintf(_coverage_fout, "4589\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4590\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==1", "tif_dirread.c", 4620U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4969\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 0) {
    fprintf(_coverage_fout, "4591\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4592\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==0", "tif_dirread.c", 4621U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4970\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryLong8(tif, dp, & data___3);
  fprintf(_coverage_fout, "4971\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4595\n");
    fflush(_coverage_fout);
    tmp___3 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, data___3);
    fprintf(_coverage_fout, "4596\n");
    fflush(_coverage_fout);
    if (tmp___3) {
      fprintf(_coverage_fout, "4593\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "4594\n");
      fflush(_coverage_fout);
      return (0);
    }
  } else {
    fprintf(_coverage_fout, "4597\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "4972\n");
  fflush(_coverage_fout);
  case 11: 
  if ((int const   )fip->field_readcount == 1) {
    fprintf(_coverage_fout, "4598\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4599\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==1", "tif_dirread.c", 4633U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4973\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 0) {
    fprintf(_coverage_fout, "4600\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4601\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==0", "tif_dirread.c", 4634U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4974\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryDouble(tif, dp, & data___4);
  fprintf(_coverage_fout, "4975\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4604\n");
    fflush(_coverage_fout);
    tmp___4 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, data___4);
    fprintf(_coverage_fout, "4605\n");
    fflush(_coverage_fout);
    if (tmp___4) {
      fprintf(_coverage_fout, "4602\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "4603\n");
      fflush(_coverage_fout);
      return (0);
    }
  } else {
    fprintf(_coverage_fout, "4606\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "4976\n");
  fflush(_coverage_fout);
  case 12: 
  if ((int const   )fip->field_readcount == 1) {
    fprintf(_coverage_fout, "4607\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4608\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==1", "tif_dirread.c", 4646U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4977\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 0) {
    fprintf(_coverage_fout, "4609\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4610\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==0", "tif_dirread.c", 4647U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4978\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryIfd8(tif, dp, & data___5);
  fprintf(_coverage_fout, "4979\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4613\n");
    fflush(_coverage_fout);
    tmp___5 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, data___5);
    fprintf(_coverage_fout, "4614\n");
    fflush(_coverage_fout);
    if (tmp___5) {
      fprintf(_coverage_fout, "4611\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "4612\n");
      fflush(_coverage_fout);
      return (0);
    }
  } else {
    fprintf(_coverage_fout, "4615\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "4980\n");
  fflush(_coverage_fout);
  case 14: 
  if ((int const   )fip->field_readcount == 2) {
    fprintf(_coverage_fout, "4616\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4617\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==2", "tif_dirread.c", 4659U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4981\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 0) {
    fprintf(_coverage_fout, "4618\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4619\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==0", "tif_dirread.c", 4660U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4982\n");
  fflush(_coverage_fout);
  if (dp->tdir_count != 2ULL) {
    fprintf(_coverage_fout, "4620\n");
    fflush(_coverage_fout);
    __assert_fail("0", "tif_dirread.c", 4662U, "TIFFFetchNormalTag");
  } else {
    fprintf(_coverage_fout, "4627\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryShortArray(tif, dp, & data___6);
    fprintf(_coverage_fout, "4628\n");
    fflush(_coverage_fout);
    if ((unsigned int )err == 0U) {
      fprintf(_coverage_fout, "4623\n");
      fflush(_coverage_fout);
      m = TIFFSetField(tif, (unsigned int )dp->tdir_tag, *(data___6 + 0),
                       *(data___6 + 1));
      fprintf(_coverage_fout, "4624\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)data___6);
      fprintf(_coverage_fout, "4625\n");
      fflush(_coverage_fout);
      if (! m) {
        fprintf(_coverage_fout, "4621\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "4622\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "4626\n");
      fflush(_coverage_fout);

    }
  }
  break;
  fprintf(_coverage_fout, "4983\n");
  fflush(_coverage_fout);
  case 16: 
  if ((int const   )fip->field_readcount >= 1) {
    fprintf(_coverage_fout, "4629\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4630\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount>=1", "tif_dirread.c", 4680U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4984\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 0) {
    fprintf(_coverage_fout, "4631\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4632\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==0", "tif_dirread.c", 4681U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4985\n");
  fflush(_coverage_fout);
  if (dp->tdir_count != (unsigned long long )fip->field_readcount) {
    fprintf(_coverage_fout, "4633\n");
    fflush(_coverage_fout);
    __assert_fail("0", "tif_dirread.c", 4683U, "TIFFFetchNormalTag");
  } else {
    fprintf(_coverage_fout, "4642\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryByteArray(tif, dp, & data___7);
    fprintf(_coverage_fout, "4643\n");
    fflush(_coverage_fout);
    if ((unsigned int )err == 0U) {
      fprintf(_coverage_fout, "4638\n");
      fflush(_coverage_fout);
      m___0 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, data___7);
      fprintf(_coverage_fout, "4639\n");
      fflush(_coverage_fout);
      if ((unsigned int )data___7 != (unsigned int )((uint8 *)0)) {
        fprintf(_coverage_fout, "4634\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)data___7);
      } else {
        fprintf(_coverage_fout, "4635\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4640\n");
      fflush(_coverage_fout);
      if (! m___0) {
        fprintf(_coverage_fout, "4636\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "4637\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "4641\n");
      fflush(_coverage_fout);

    }
  }
  break;
  fprintf(_coverage_fout, "4986\n");
  fflush(_coverage_fout);
  case 18: 
  if ((int const   )fip->field_readcount >= 1) {
    fprintf(_coverage_fout, "4644\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4645\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount>=1", "tif_dirread.c", 4702U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4987\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 0) {
    fprintf(_coverage_fout, "4646\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4647\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==0", "tif_dirread.c", 4703U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4988\n");
  fflush(_coverage_fout);
  if (dp->tdir_count != (unsigned long long )fip->field_readcount) {
    fprintf(_coverage_fout, "4648\n");
    fflush(_coverage_fout);
    __assert_fail("0", "tif_dirread.c", 4705U, "TIFFFetchNormalTag");
  } else {
    fprintf(_coverage_fout, "4657\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryShortArray(tif, dp, & data___8);
    fprintf(_coverage_fout, "4658\n");
    fflush(_coverage_fout);
    if ((unsigned int )err == 0U) {
      fprintf(_coverage_fout, "4653\n");
      fflush(_coverage_fout);
      m___1 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, data___8);
      fprintf(_coverage_fout, "4654\n");
      fflush(_coverage_fout);
      if ((unsigned int )data___8 != (unsigned int )((uint16 *)0)) {
        fprintf(_coverage_fout, "4649\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)data___8);
      } else {
        fprintf(_coverage_fout, "4650\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4655\n");
      fflush(_coverage_fout);
      if (! m___1) {
        fprintf(_coverage_fout, "4651\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "4652\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "4656\n");
      fflush(_coverage_fout);

    }
  }
  break;
  fprintf(_coverage_fout, "4989\n");
  fflush(_coverage_fout);
  case 20: 
  if ((int const   )fip->field_readcount >= 1) {
    fprintf(_coverage_fout, "4659\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4660\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount>=1", "tif_dirread.c", 4724U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4990\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 0) {
    fprintf(_coverage_fout, "4661\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4662\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==0", "tif_dirread.c", 4725U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4991\n");
  fflush(_coverage_fout);
  if (dp->tdir_count != (unsigned long long )fip->field_readcount) {
    fprintf(_coverage_fout, "4663\n");
    fflush(_coverage_fout);
    __assert_fail("0", "tif_dirread.c", 4727U, "TIFFFetchNormalTag");
  } else {
    fprintf(_coverage_fout, "4672\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryLongArray(tif, dp, & data___9);
    fprintf(_coverage_fout, "4673\n");
    fflush(_coverage_fout);
    if ((unsigned int )err == 0U) {
      fprintf(_coverage_fout, "4668\n");
      fflush(_coverage_fout);
      m___2 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, data___9);
      fprintf(_coverage_fout, "4669\n");
      fflush(_coverage_fout);
      if ((unsigned int )data___9 != (unsigned int )((uint32 *)0)) {
        fprintf(_coverage_fout, "4664\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)data___9);
      } else {
        fprintf(_coverage_fout, "4665\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4670\n");
      fflush(_coverage_fout);
      if (! m___2) {
        fprintf(_coverage_fout, "4666\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "4667\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "4671\n");
      fflush(_coverage_fout);

    }
  }
  break;
  fprintf(_coverage_fout, "4992\n");
  fflush(_coverage_fout);
  case 24: 
  if ((int const   )fip->field_readcount >= 1) {
    fprintf(_coverage_fout, "4674\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4675\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount>=1", "tif_dirread.c", 4746U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4993\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 0) {
    fprintf(_coverage_fout, "4676\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4677\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==0", "tif_dirread.c", 4747U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4994\n");
  fflush(_coverage_fout);
  if (dp->tdir_count != (unsigned long long )fip->field_readcount) {
    fprintf(_coverage_fout, "4678\n");
    fflush(_coverage_fout);
    __assert_fail("0", "tif_dirread.c", 4749U, "TIFFFetchNormalTag");
  } else {
    fprintf(_coverage_fout, "4687\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryFloatArray(tif, dp, & data___10);
    fprintf(_coverage_fout, "4688\n");
    fflush(_coverage_fout);
    if ((unsigned int )err == 0U) {
      fprintf(_coverage_fout, "4683\n");
      fflush(_coverage_fout);
      m___3 = TIFFSetField(tif, (unsigned int )dp->tdir_tag, data___10);
      fprintf(_coverage_fout, "4684\n");
      fflush(_coverage_fout);
      if ((unsigned int )data___10 != (unsigned int )((float *)0)) {
        fprintf(_coverage_fout, "4679\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)data___10);
      } else {
        fprintf(_coverage_fout, "4680\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4685\n");
      fflush(_coverage_fout);
      if (! m___3) {
        fprintf(_coverage_fout, "4681\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "4682\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "4686\n");
      fflush(_coverage_fout);

    }
  }
  break;
  fprintf(_coverage_fout, "4995\n");
  fflush(_coverage_fout);
  case 27: 
  if ((int const   )fip->field_readcount == -1) {
    fprintf(_coverage_fout, "4689\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4690\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-1", "tif_dirread.c", 4768U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4996\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4691\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4692\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 4769U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4997\n");
  fflush(_coverage_fout);
  if (dp->tdir_count > 65535ULL) {
    fprintf(_coverage_fout, "4693\n");
    fflush(_coverage_fout);
    err = (enum TIFFReadDirEntryErr )1;
  } else {
    fprintf(_coverage_fout, "4702\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryByteArray(tif, dp, & data___11);
    fprintf(_coverage_fout, "4703\n");
    fflush(_coverage_fout);
    if ((unsigned int )err == 0U) {
      fprintf(_coverage_fout, "4698\n");
      fflush(_coverage_fout);
      m___4 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                           (unsigned short )dp->tdir_count, data___11);
      fprintf(_coverage_fout, "4699\n");
      fflush(_coverage_fout);
      if ((unsigned int )data___11 != (unsigned int )((uint8 *)0)) {
        fprintf(_coverage_fout, "4694\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)data___11);
      } else {
        fprintf(_coverage_fout, "4695\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4700\n");
      fflush(_coverage_fout);
      if (! m___4) {
        fprintf(_coverage_fout, "4696\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "4697\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "4701\n");
      fflush(_coverage_fout);

    }
  }
  break;
  fprintf(_coverage_fout, "4998\n");
  fflush(_coverage_fout);
  case 28: 
  if ((int const   )fip->field_readcount == -1) {
    fprintf(_coverage_fout, "4704\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4705\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-1", "tif_dirread.c", 4790U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "4999\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4706\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4707\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 4791U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5000\n");
  fflush(_coverage_fout);
  if (dp->tdir_count > 65535ULL) {
    fprintf(_coverage_fout, "4708\n");
    fflush(_coverage_fout);
    err = (enum TIFFReadDirEntryErr )1;
  } else {
    fprintf(_coverage_fout, "4717\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryByteArray(tif, dp, & data___12);
    fprintf(_coverage_fout, "4718\n");
    fflush(_coverage_fout);
    if ((unsigned int )err == 0U) {
      fprintf(_coverage_fout, "4713\n");
      fflush(_coverage_fout);
      m___5 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                           (unsigned short )dp->tdir_count, data___12);
      fprintf(_coverage_fout, "4714\n");
      fflush(_coverage_fout);
      if ((unsigned int )data___12 != (unsigned int )((uint8 *)0)) {
        fprintf(_coverage_fout, "4709\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)data___12);
      } else {
        fprintf(_coverage_fout, "4710\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4715\n");
      fflush(_coverage_fout);
      if (! m___5) {
        fprintf(_coverage_fout, "4711\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "4712\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "4716\n");
      fflush(_coverage_fout);

    }
  }
  break;
  fprintf(_coverage_fout, "5001\n");
  fflush(_coverage_fout);
  case 30: 
  if ((int const   )fip->field_readcount == -1) {
    fprintf(_coverage_fout, "4719\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4720\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-1", "tif_dirread.c", 4812U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5002\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4721\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4722\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 4813U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5003\n");
  fflush(_coverage_fout);
  if (dp->tdir_count > 65535ULL) {
    fprintf(_coverage_fout, "4723\n");
    fflush(_coverage_fout);
    err = (enum TIFFReadDirEntryErr )1;
  } else {
    fprintf(_coverage_fout, "4732\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryShortArray(tif, dp, & data___13);
    fprintf(_coverage_fout, "4733\n");
    fflush(_coverage_fout);
    if ((unsigned int )err == 0U) {
      fprintf(_coverage_fout, "4728\n");
      fflush(_coverage_fout);
      m___6 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                           (unsigned short )dp->tdir_count, data___13);
      fprintf(_coverage_fout, "4729\n");
      fflush(_coverage_fout);
      if ((unsigned int )data___13 != (unsigned int )((uint16 *)0)) {
        fprintf(_coverage_fout, "4724\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)data___13);
      } else {
        fprintf(_coverage_fout, "4725\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4730\n");
      fflush(_coverage_fout);
      if (! m___6) {
        fprintf(_coverage_fout, "4726\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "4727\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "4731\n");
      fflush(_coverage_fout);

    }
  }
  break;
  fprintf(_coverage_fout, "5004\n");
  fflush(_coverage_fout);
  case 32: 
  if ((int const   )fip->field_readcount == -1) {
    fprintf(_coverage_fout, "4734\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4735\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-1", "tif_dirread.c", 4834U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5005\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4736\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4737\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 4835U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5006\n");
  fflush(_coverage_fout);
  if (dp->tdir_count > 65535ULL) {
    fprintf(_coverage_fout, "4738\n");
    fflush(_coverage_fout);
    err = (enum TIFFReadDirEntryErr )1;
  } else {
    fprintf(_coverage_fout, "4747\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryLongArray(tif, dp, & data___14);
    fprintf(_coverage_fout, "4748\n");
    fflush(_coverage_fout);
    if ((unsigned int )err == 0U) {
      fprintf(_coverage_fout, "4743\n");
      fflush(_coverage_fout);
      m___7 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                           (unsigned short )dp->tdir_count, data___14);
      fprintf(_coverage_fout, "4744\n");
      fflush(_coverage_fout);
      if ((unsigned int )data___14 != (unsigned int )((uint32 *)0)) {
        fprintf(_coverage_fout, "4739\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)data___14);
      } else {
        fprintf(_coverage_fout, "4740\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4745\n");
      fflush(_coverage_fout);
      if (! m___7) {
        fprintf(_coverage_fout, "4741\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "4742\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "4746\n");
      fflush(_coverage_fout);

    }
  }
  break;
  fprintf(_coverage_fout, "5007\n");
  fflush(_coverage_fout);
  case 34: 
  if ((int const   )fip->field_readcount == -1) {
    fprintf(_coverage_fout, "4749\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4750\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-1", "tif_dirread.c", 4856U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5008\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4751\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4752\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 4857U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5009\n");
  fflush(_coverage_fout);
  if (dp->tdir_count > 65535ULL) {
    fprintf(_coverage_fout, "4753\n");
    fflush(_coverage_fout);
    err = (enum TIFFReadDirEntryErr )1;
  } else {
    fprintf(_coverage_fout, "4762\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryLong8Array(tif, dp, & data___15);
    fprintf(_coverage_fout, "4763\n");
    fflush(_coverage_fout);
    if ((unsigned int )err == 0U) {
      fprintf(_coverage_fout, "4758\n");
      fflush(_coverage_fout);
      m___8 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                           (unsigned short )dp->tdir_count, data___15);
      fprintf(_coverage_fout, "4759\n");
      fflush(_coverage_fout);
      if ((unsigned int )data___15 != (unsigned int )((uint64 *)0)) {
        fprintf(_coverage_fout, "4754\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)data___15);
      } else {
        fprintf(_coverage_fout, "4755\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4760\n");
      fflush(_coverage_fout);
      if (! m___8) {
        fprintf(_coverage_fout, "4756\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "4757\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "4761\n");
      fflush(_coverage_fout);

    }
  }
  break;
  fprintf(_coverage_fout, "5010\n");
  fflush(_coverage_fout);
  case 36: 
  if ((int const   )fip->field_readcount == -1) {
    fprintf(_coverage_fout, "4764\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4765\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-1", "tif_dirread.c", 4878U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5011\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4766\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4767\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 4879U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5012\n");
  fflush(_coverage_fout);
  if (dp->tdir_count > 65535ULL) {
    fprintf(_coverage_fout, "4768\n");
    fflush(_coverage_fout);
    err = (enum TIFFReadDirEntryErr )1;
  } else {
    fprintf(_coverage_fout, "4777\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryFloatArray(tif, dp, & data___16);
    fprintf(_coverage_fout, "4778\n");
    fflush(_coverage_fout);
    if ((unsigned int )err == 0U) {
      fprintf(_coverage_fout, "4773\n");
      fflush(_coverage_fout);
      m___9 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                           (unsigned short )dp->tdir_count, data___16);
      fprintf(_coverage_fout, "4774\n");
      fflush(_coverage_fout);
      if ((unsigned int )data___16 != (unsigned int )((float *)0)) {
        fprintf(_coverage_fout, "4769\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)data___16);
      } else {
        fprintf(_coverage_fout, "4770\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4775\n");
      fflush(_coverage_fout);
      if (! m___9) {
        fprintf(_coverage_fout, "4771\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "4772\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "4776\n");
      fflush(_coverage_fout);

    }
  }
  break;
  fprintf(_coverage_fout, "5013\n");
  fflush(_coverage_fout);
  case 37: 
  if ((int const   )fip->field_readcount == -1) {
    fprintf(_coverage_fout, "4779\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4780\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-1", "tif_dirread.c", 4900U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5014\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4781\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4782\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 4901U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5015\n");
  fflush(_coverage_fout);
  if (dp->tdir_count > 65535ULL) {
    fprintf(_coverage_fout, "4783\n");
    fflush(_coverage_fout);
    err = (enum TIFFReadDirEntryErr )1;
  } else {
    fprintf(_coverage_fout, "4792\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryDoubleArray(tif, dp, & data___17);
    fprintf(_coverage_fout, "4793\n");
    fflush(_coverage_fout);
    if ((unsigned int )err == 0U) {
      fprintf(_coverage_fout, "4788\n");
      fflush(_coverage_fout);
      m___10 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                            (unsigned short )dp->tdir_count, data___17);
      fprintf(_coverage_fout, "4789\n");
      fflush(_coverage_fout);
      if ((unsigned int )data___17 != (unsigned int )((double *)0)) {
        fprintf(_coverage_fout, "4784\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)data___17);
      } else {
        fprintf(_coverage_fout, "4785\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4790\n");
      fflush(_coverage_fout);
      if (! m___10) {
        fprintf(_coverage_fout, "4786\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "4787\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "4791\n");
      fflush(_coverage_fout);

    }
  }
  break;
  fprintf(_coverage_fout, "5016\n");
  fflush(_coverage_fout);
  case 38: 
  if ((int const   )fip->field_readcount == -1) {
    fprintf(_coverage_fout, "4794\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4795\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-1", "tif_dirread.c", 4922U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5017\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4796\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4797\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 4923U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5018\n");
  fflush(_coverage_fout);
  if (dp->tdir_count > 65535ULL) {
    fprintf(_coverage_fout, "4798\n");
    fflush(_coverage_fout);
    err = (enum TIFFReadDirEntryErr )1;
  } else {
    fprintf(_coverage_fout, "4807\n");
    fflush(_coverage_fout);
    err = TIFFReadDirEntryIfd8Array(tif, dp, & data___18);
    fprintf(_coverage_fout, "4808\n");
    fflush(_coverage_fout);
    if ((unsigned int )err == 0U) {
      fprintf(_coverage_fout, "4803\n");
      fflush(_coverage_fout);
      m___11 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                            (unsigned short )dp->tdir_count, data___18);
      fprintf(_coverage_fout, "4804\n");
      fflush(_coverage_fout);
      if ((unsigned int )data___18 != (unsigned int )((uint64 *)0)) {
        fprintf(_coverage_fout, "4799\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)data___18);
      } else {
        fprintf(_coverage_fout, "4800\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "4805\n");
      fflush(_coverage_fout);
      if (! m___11) {
        fprintf(_coverage_fout, "4801\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "4802\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "4806\n");
      fflush(_coverage_fout);

    }
  }
  break;
  fprintf(_coverage_fout, "5019\n");
  fflush(_coverage_fout);
  case 39: 
  if ((int const   )fip->field_readcount == -3) {
    fprintf(_coverage_fout, "4809\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4810\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-3", "tif_dirread.c", 4944U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5020\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4811\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4812\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 4945U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5021\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryByteArray(tif, dp, & data___19);
  fprintf(_coverage_fout, "5022\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4817\n");
    fflush(_coverage_fout);
    m___12 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                          (unsigned int )dp->tdir_count, data___19);
    fprintf(_coverage_fout, "4818\n");
    fflush(_coverage_fout);
    if ((unsigned int )data___19 != (unsigned int )((uint8 *)0)) {
      fprintf(_coverage_fout, "4813\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)data___19);
    } else {
      fprintf(_coverage_fout, "4814\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4819\n");
    fflush(_coverage_fout);
    if (! m___12) {
      fprintf(_coverage_fout, "4815\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "4816\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "4820\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "5023\n");
  fflush(_coverage_fout);
  case 40: 
  if ((int const   )fip->field_readcount == -3) {
    fprintf(_coverage_fout, "4821\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4822\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-3", "tif_dirread.c", 4961U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5024\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4823\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4824\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 4962U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5025\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryByteArray(tif, dp, & data___20);
  fprintf(_coverage_fout, "5026\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4829\n");
    fflush(_coverage_fout);
    m___13 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                          (unsigned int )dp->tdir_count, data___20);
    fprintf(_coverage_fout, "4830\n");
    fflush(_coverage_fout);
    if ((unsigned int )data___20 != (unsigned int )((uint8 *)0)) {
      fprintf(_coverage_fout, "4825\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)data___20);
    } else {
      fprintf(_coverage_fout, "4826\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4831\n");
    fflush(_coverage_fout);
    if (! m___13) {
      fprintf(_coverage_fout, "4827\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "4828\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "4832\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "5027\n");
  fflush(_coverage_fout);
  case 41: 
  if ((int const   )fip->field_readcount == -3) {
    fprintf(_coverage_fout, "4833\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4834\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-3", "tif_dirread.c", 4978U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5028\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4835\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4836\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 4979U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5029\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntrySbyteArray(tif, dp, & data___21);
  fprintf(_coverage_fout, "5030\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4841\n");
    fflush(_coverage_fout);
    m___14 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                          (unsigned int )dp->tdir_count, data___21);
    fprintf(_coverage_fout, "4842\n");
    fflush(_coverage_fout);
    if ((unsigned int )data___21 != (unsigned int )((int8 *)0)) {
      fprintf(_coverage_fout, "4837\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)data___21);
    } else {
      fprintf(_coverage_fout, "4838\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4843\n");
    fflush(_coverage_fout);
    if (! m___14) {
      fprintf(_coverage_fout, "4839\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "4840\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "4844\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "5031\n");
  fflush(_coverage_fout);
  case 42: 
  if ((int const   )fip->field_readcount == -3) {
    fprintf(_coverage_fout, "4845\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4846\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-3", "tif_dirread.c", 4995U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5032\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4847\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4848\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 4996U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5033\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryShortArray(tif, dp, & data___22);
  fprintf(_coverage_fout, "5034\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4853\n");
    fflush(_coverage_fout);
    m___15 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                          (unsigned int )dp->tdir_count, data___22);
    fprintf(_coverage_fout, "4854\n");
    fflush(_coverage_fout);
    if ((unsigned int )data___22 != (unsigned int )((uint16 *)0)) {
      fprintf(_coverage_fout, "4849\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)data___22);
    } else {
      fprintf(_coverage_fout, "4850\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4855\n");
    fflush(_coverage_fout);
    if (! m___15) {
      fprintf(_coverage_fout, "4851\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "4852\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "4856\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "5035\n");
  fflush(_coverage_fout);
  case 43: 
  if ((int const   )fip->field_readcount == -3) {
    fprintf(_coverage_fout, "4857\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4858\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-3", "tif_dirread.c", 5012U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5036\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4859\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4860\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 5013U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5037\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntrySshortArray(tif, dp, & data___23);
  fprintf(_coverage_fout, "5038\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4865\n");
    fflush(_coverage_fout);
    m___16 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                          (unsigned int )dp->tdir_count, data___23);
    fprintf(_coverage_fout, "4866\n");
    fflush(_coverage_fout);
    if ((unsigned int )data___23 != (unsigned int )((int16 *)0)) {
      fprintf(_coverage_fout, "4861\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)data___23);
    } else {
      fprintf(_coverage_fout, "4862\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4867\n");
    fflush(_coverage_fout);
    if (! m___16) {
      fprintf(_coverage_fout, "4863\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "4864\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "4868\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "5039\n");
  fflush(_coverage_fout);
  case 44: 
  if ((int const   )fip->field_readcount == -3) {
    fprintf(_coverage_fout, "4869\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4870\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-3", "tif_dirread.c", 5029U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5040\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4871\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4872\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 5030U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5041\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryLongArray(tif, dp, & data___24);
  fprintf(_coverage_fout, "5042\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4877\n");
    fflush(_coverage_fout);
    m___17 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                          (unsigned int )dp->tdir_count, data___24);
    fprintf(_coverage_fout, "4878\n");
    fflush(_coverage_fout);
    if ((unsigned int )data___24 != (unsigned int )((uint32 *)0)) {
      fprintf(_coverage_fout, "4873\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)data___24);
    } else {
      fprintf(_coverage_fout, "4874\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4879\n");
    fflush(_coverage_fout);
    if (! m___17) {
      fprintf(_coverage_fout, "4875\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "4876\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "4880\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "5043\n");
  fflush(_coverage_fout);
  case 45: 
  if ((int const   )fip->field_readcount == -3) {
    fprintf(_coverage_fout, "4881\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4882\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-3", "tif_dirread.c", 5046U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5044\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4883\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4884\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 5047U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5045\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntrySlongArray(tif, dp, & data___25);
  fprintf(_coverage_fout, "5046\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4889\n");
    fflush(_coverage_fout);
    m___18 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                          (unsigned int )dp->tdir_count, data___25);
    fprintf(_coverage_fout, "4890\n");
    fflush(_coverage_fout);
    if ((unsigned int )data___25 != (unsigned int )((int32 *)0)) {
      fprintf(_coverage_fout, "4885\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)data___25);
    } else {
      fprintf(_coverage_fout, "4886\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4891\n");
    fflush(_coverage_fout);
    if (! m___18) {
      fprintf(_coverage_fout, "4887\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "4888\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "4892\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "5047\n");
  fflush(_coverage_fout);
  case 46: 
  if ((int const   )fip->field_readcount == -3) {
    fprintf(_coverage_fout, "4893\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4894\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-3", "tif_dirread.c", 5063U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5048\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4895\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4896\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 5064U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5049\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryLong8Array(tif, dp, & data___26);
  fprintf(_coverage_fout, "5050\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4901\n");
    fflush(_coverage_fout);
    m___19 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                          (unsigned int )dp->tdir_count, data___26);
    fprintf(_coverage_fout, "4902\n");
    fflush(_coverage_fout);
    if ((unsigned int )data___26 != (unsigned int )((uint64 *)0)) {
      fprintf(_coverage_fout, "4897\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)data___26);
    } else {
      fprintf(_coverage_fout, "4898\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4903\n");
    fflush(_coverage_fout);
    if (! m___19) {
      fprintf(_coverage_fout, "4899\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "4900\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "4904\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "5051\n");
  fflush(_coverage_fout);
  case 47: 
  if ((int const   )fip->field_readcount == -3) {
    fprintf(_coverage_fout, "4905\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4906\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-3", "tif_dirread.c", 5080U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5052\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4907\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4908\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 5081U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5053\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntrySlong8Array(tif, dp, & data___27);
  fprintf(_coverage_fout, "5054\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4913\n");
    fflush(_coverage_fout);
    m___20 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                          (unsigned int )dp->tdir_count, data___27);
    fprintf(_coverage_fout, "4914\n");
    fflush(_coverage_fout);
    if ((unsigned int )data___27 != (unsigned int )((int64 *)0)) {
      fprintf(_coverage_fout, "4909\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)data___27);
    } else {
      fprintf(_coverage_fout, "4910\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4915\n");
    fflush(_coverage_fout);
    if (! m___20) {
      fprintf(_coverage_fout, "4911\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "4912\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "4916\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "5055\n");
  fflush(_coverage_fout);
  case 48: 
  if ((int const   )fip->field_readcount == -3) {
    fprintf(_coverage_fout, "4917\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4918\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-3", "tif_dirread.c", 5097U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5056\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4919\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4920\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 5098U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5057\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryFloatArray(tif, dp, & data___28);
  fprintf(_coverage_fout, "5058\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4925\n");
    fflush(_coverage_fout);
    m___21 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                          (unsigned int )dp->tdir_count, data___28);
    fprintf(_coverage_fout, "4926\n");
    fflush(_coverage_fout);
    if ((unsigned int )data___28 != (unsigned int )((float *)0)) {
      fprintf(_coverage_fout, "4921\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)data___28);
    } else {
      fprintf(_coverage_fout, "4922\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4927\n");
    fflush(_coverage_fout);
    if (! m___21) {
      fprintf(_coverage_fout, "4923\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "4924\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "4928\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "5059\n");
  fflush(_coverage_fout);
  case 49: 
  if ((int const   )fip->field_readcount == -3) {
    fprintf(_coverage_fout, "4929\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4930\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-3", "tif_dirread.c", 5114U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5060\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4931\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4932\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 5115U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5061\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryDoubleArray(tif, dp, & data___29);
  fprintf(_coverage_fout, "5062\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4937\n");
    fflush(_coverage_fout);
    m___22 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                          (unsigned int )dp->tdir_count, data___29);
    fprintf(_coverage_fout, "4938\n");
    fflush(_coverage_fout);
    if ((unsigned int )data___29 != (unsigned int )((double *)0)) {
      fprintf(_coverage_fout, "4933\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)data___29);
    } else {
      fprintf(_coverage_fout, "4934\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4939\n");
    fflush(_coverage_fout);
    if (! m___22) {
      fprintf(_coverage_fout, "4935\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "4936\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "4940\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "5063\n");
  fflush(_coverage_fout);
  case 50: 
  if ((int const   )fip->field_readcount == -3) {
    fprintf(_coverage_fout, "4941\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4942\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_readcount==-3", "tif_dirread.c", 5131U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5064\n");
  fflush(_coverage_fout);
  if ((int const   )fip->field_passcount == 1) {
    fprintf(_coverage_fout, "4943\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "4944\n");
    fflush(_coverage_fout);
    __assert_fail("fip->field_passcount==1", "tif_dirread.c", 5132U,
                  "TIFFFetchNormalTag");
  }
  fprintf(_coverage_fout, "5065\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryIfd8Array(tif, dp, & data___30);
  fprintf(_coverage_fout, "5066\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "4949\n");
    fflush(_coverage_fout);
    m___23 = TIFFSetField(tif, (unsigned int )dp->tdir_tag,
                          (unsigned int )dp->tdir_count, data___30);
    fprintf(_coverage_fout, "4950\n");
    fflush(_coverage_fout);
    if ((unsigned int )data___30 != (unsigned int )((uint64 *)0)) {
      fprintf(_coverage_fout, "4945\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)data___30);
    } else {
      fprintf(_coverage_fout, "4946\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "4951\n");
    fflush(_coverage_fout);
    if (! m___23) {
      fprintf(_coverage_fout, "4947\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "4948\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "4952\n");
    fflush(_coverage_fout);

  }
  break;
  fprintf(_coverage_fout, "5067\n");
  fflush(_coverage_fout);
  default: 
  __assert_fail("0", "tif_dirread.c", 5146U, "TIFFFetchNormalTag");
  break;
  }
  fprintf(_coverage_fout, "5078\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "5068\n");
    fflush(_coverage_fout);
    TIFFReadDirEntryOutputErr(tif, err, module___5,
                              (char const   *)fip->field_name, recover);
    fprintf(_coverage_fout, "5069\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "5070\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "5079\n");
  fflush(_coverage_fout);
  return (1);
}
}
static int TIFFFetchStripThing(TIFF *tif , TIFFDirEntry *dir , uint32 nstrips ,
                               uint64 **lpp ) ;
static char const   module___6[20]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'F',      (char const   )'e',      (char const   )'t',      (char const   )'c', 
        (char const   )'h',      (char const   )'S',      (char const   )'t',      (char const   )'r', 
        (char const   )'i',      (char const   )'p',      (char const   )'T',      (char const   )'h', 
        (char const   )'i',      (char const   )'n',      (char const   )'g',      (char const   )'\000'};
static int TIFFFetchStripThing(TIFF *tif , TIFFDirEntry *dir , uint32 nstrips ,
                               uint64 **lpp ) 
{ enum TIFFReadDirEntryErr err ;
  uint64 *data ;
  TIFFField const   *tmp ;
  uint64 *resizeddata ;
  void *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5096\n");
  fflush(_coverage_fout);
  err = TIFFReadDirEntryLong8Array(tif, dir, & data);
  fprintf(_coverage_fout, "5097\n");
  fflush(_coverage_fout);
  if ((unsigned int )err != 0U) {
    fprintf(_coverage_fout, "5080\n");
    fflush(_coverage_fout);
    tmp = TIFFFieldWithTag(tif, (unsigned int )dir->tdir_tag);
    fprintf(_coverage_fout, "5081\n");
    fflush(_coverage_fout);
    TIFFReadDirEntryOutputErr(tif, err, module___6,
                              (char const   *)tmp->field_name, 0);
    fprintf(_coverage_fout, "5082\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "5083\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "5098\n");
  fflush(_coverage_fout);
  if (dir->tdir_count != (unsigned long long )nstrips) {
    fprintf(_coverage_fout, "5089\n");
    fflush(_coverage_fout);
    tmp___0 = _TIFFCheckMalloc(tif, (long )nstrips, (long )sizeof(uint64 ),
                               "for strip array");
    fprintf(_coverage_fout, "5090\n");
    fflush(_coverage_fout);
    resizeddata = (uint64 *)tmp___0;
    fprintf(_coverage_fout, "5091\n");
    fflush(_coverage_fout);
    if ((unsigned int )resizeddata == (unsigned int )((uint64 *)0)) {
      fprintf(_coverage_fout, "5084\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "5085\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "5092\n");
    fflush(_coverage_fout);
    if (dir->tdir_count < (unsigned long long )nstrips) {
      fprintf(_coverage_fout, "5086\n");
      fflush(_coverage_fout);
      _TIFFmemcpy((void *)resizeddata, (void const   *)data,
                  (long )((unsigned int )dir->tdir_count * sizeof(uint64 )));
      fprintf(_coverage_fout, "5087\n");
      fflush(_coverage_fout);
      _TIFFmemset((void *)(resizeddata + (unsigned int )dir->tdir_count), 0,
                  (long )((nstrips - (unsigned int )dir->tdir_count) * sizeof(uint64 )));
    } else {
      fprintf(_coverage_fout, "5088\n");
      fflush(_coverage_fout);
      _TIFFmemcpy((void *)resizeddata, (void const   *)data,
                  (long )(nstrips * sizeof(uint64 )));
    }
    fprintf(_coverage_fout, "5093\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)data);
    fprintf(_coverage_fout, "5094\n");
    fflush(_coverage_fout);
    data = resizeddata;
  } else {
    fprintf(_coverage_fout, "5095\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "5099\n");
  fflush(_coverage_fout);
  *lpp = data;
  fprintf(_coverage_fout, "5100\n");
  fflush(_coverage_fout);
  return (1);
}
}
static int TIFFFetchSubjectDistance(TIFF *tif , TIFFDirEntry *dir ) ;
static char const   module___7[25]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'F',      (char const   )'e',      (char const   )'t',      (char const   )'c', 
        (char const   )'h',      (char const   )'S',      (char const   )'u',      (char const   )'b', 
        (char const   )'j',      (char const   )'e',      (char const   )'c',      (char const   )'t', 
        (char const   )'D',      (char const   )'i',      (char const   )'s',      (char const   )'t', 
        (char const   )'a',      (char const   )'n',      (char const   )'c',      (char const   )'e', 
        (char const   )'\000'};
static int TIFFFetchSubjectDistance(TIFF *tif , TIFFDirEntry *dir ) 
{ enum TIFFReadDirEntryErr err ;
  uint32 m[2] ;
  uint32 offset ;
  double n ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5130\n");
  fflush(_coverage_fout);
  if (sizeof(double ) == 8U) {
    fprintf(_coverage_fout, "5101\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "5102\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(double)==8", "tif_dirread.c", 5202U,
                  "TIFFFetchSubjectDistance");
  }
  fprintf(_coverage_fout, "5131\n");
  fflush(_coverage_fout);
  if (sizeof(uint64 ) == 8U) {
    fprintf(_coverage_fout, "5103\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "5104\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint64)==8", "tif_dirread.c", 5203U,
                  "TIFFFetchSubjectDistance");
  }
  fprintf(_coverage_fout, "5132\n");
  fflush(_coverage_fout);
  if (sizeof(uint32 ) == 4U) {
    fprintf(_coverage_fout, "5105\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "5106\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint32)==4", "tif_dirread.c", 5204U,
                  "TIFFFetchSubjectDistance");
  }
  fprintf(_coverage_fout, "5133\n");
  fflush(_coverage_fout);
  if (dir->tdir_count != 1ULL) {
    fprintf(_coverage_fout, "5107\n");
    fflush(_coverage_fout);
    err = (enum TIFFReadDirEntryErr )1;
  } else {
    fprintf(_coverage_fout, "5117\n");
    fflush(_coverage_fout);
    if ((int )dir->tdir_type != 5) {
      fprintf(_coverage_fout, "5108\n");
      fflush(_coverage_fout);
      err = (enum TIFFReadDirEntryErr )2;
    } else {
      fprintf(_coverage_fout, "5116\n");
      fflush(_coverage_fout);
      if (! (tif->tif_flags & 524288U)) {
        fprintf(_coverage_fout, "5111\n");
        fflush(_coverage_fout);
        offset = *((uint32 *)(& dir->tdir_offset));
        fprintf(_coverage_fout, "5112\n");
        fflush(_coverage_fout);
        if (tif->tif_flags & 128U) {
          fprintf(_coverage_fout, "5109\n");
          fflush(_coverage_fout);
          TIFFSwabLong(& offset);
        } else {
          fprintf(_coverage_fout, "5110\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "5113\n");
        fflush(_coverage_fout);
        err = TIFFReadDirEntryData(tif, (unsigned long long )offset, 8L,
                                   (void *)(m));
      } else {
        fprintf(_coverage_fout, "5114\n");
        fflush(_coverage_fout);
        *((uint64 *)(m)) = dir->tdir_offset;
        fprintf(_coverage_fout, "5115\n");
        fflush(_coverage_fout);
        err = (enum TIFFReadDirEntryErr )0;
      }
    }
  }
  fprintf(_coverage_fout, "5134\n");
  fflush(_coverage_fout);
  if ((unsigned int )err == 0U) {
    fprintf(_coverage_fout, "5124\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "5118\n");
      fflush(_coverage_fout);
      TIFFSwabArrayOfLong(m, 2L);
    } else {
      fprintf(_coverage_fout, "5119\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "5125\n");
    fflush(_coverage_fout);
    if (m[0] == 0U) {
      fprintf(_coverage_fout, "5120\n");
      fflush(_coverage_fout);
      n = 0.0;
    } else {
      fprintf(_coverage_fout, "5123\n");
      fflush(_coverage_fout);
      if (m[0] == 0xFFFFFFFF) {
        fprintf(_coverage_fout, "5121\n");
        fflush(_coverage_fout);
        n = - 1.0;
      } else {
        fprintf(_coverage_fout, "5122\n");
        fflush(_coverage_fout);
        n = (double )m[0] / (double )m[1];
      }
    }
    fprintf(_coverage_fout, "5126\n");
    fflush(_coverage_fout);
    tmp = TIFFSetField(tif, (unsigned int )dir->tdir_tag, n);
    fprintf(_coverage_fout, "5127\n");
    fflush(_coverage_fout);
    return (tmp);
  } else {
    fprintf(_coverage_fout, "5128\n");
    fflush(_coverage_fout);
    TIFFReadDirEntryOutputErr(tif, err, module___7, "SubjectDistance", 1);
    fprintf(_coverage_fout, "5129\n");
    fflush(_coverage_fout);
    return (0);
  }
}
}
static void ChopUpSingleUncompressedStrip(TIFF *tif ) 
{ register TIFFDirectory *td ;
  uint64 bytecount ;
  uint64 offset ;
  uint32 rowblock ;
  uint64 rowblockbytes ;
  uint64 stripbytes ;
  uint32 strip ;
  uint64 nstrips64 ;
  uint32 nstrips32 ;
  uint32 rowsperstrip ;
  uint64 *newcounts ;
  uint64 *newoffsets ;
  uint32 rowblocksperstrip ;
  void *tmp ;
  void *tmp___0 ;
  uint32 tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "5173\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "5174\n");
  fflush(_coverage_fout);
  bytecount = *(td->td_stripbytecount + 0);
  fprintf(_coverage_fout, "5175\n");
  fflush(_coverage_fout);
  offset = *(td->td_stripoffset + 0);
  fprintf(_coverage_fout, "5176\n");
  fflush(_coverage_fout);
  if ((int )td->td_planarconfig == 1) {
    fprintf(_coverage_fout, "5135\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "5136\n");
    fflush(_coverage_fout);
    __assert_fail("td->td_planarconfig == 1", "tif_dirread.c", 5274U,
                  "ChopUpSingleUncompressedStrip");
  }
  fprintf(_coverage_fout, "5177\n");
  fflush(_coverage_fout);
  if ((int )td->td_photometric == 6) {
    fprintf(_coverage_fout, "5139\n");
    fflush(_coverage_fout);
    if (! ((tif->tif_flags & 16384U) != 0U)) {
      fprintf(_coverage_fout, "5137\n");
      fflush(_coverage_fout);
      rowblock = (unsigned int )td->td_ycbcrsubsampling[1];
    } else {
      fprintf(_coverage_fout, "5138\n");
      fflush(_coverage_fout);
      rowblock = 1U;
    }
  } else {
    fprintf(_coverage_fout, "5140\n");
    fflush(_coverage_fout);
    rowblock = 1U;
  }
  fprintf(_coverage_fout, "5178\n");
  fflush(_coverage_fout);
  rowblockbytes = TIFFVTileSize64(tif, rowblock);
  fprintf(_coverage_fout, "5179\n");
  fflush(_coverage_fout);
  if (rowblockbytes > 8192ULL) {
    fprintf(_coverage_fout, "5141\n");
    fflush(_coverage_fout);
    stripbytes = rowblockbytes;
    fprintf(_coverage_fout, "5142\n");
    fflush(_coverage_fout);
    rowsperstrip = rowblock;
  } else {
    fprintf(_coverage_fout, "5147\n");
    fflush(_coverage_fout);
    if (rowblockbytes > 0ULL) {
      fprintf(_coverage_fout, "5143\n");
      fflush(_coverage_fout);
      rowblocksperstrip = (unsigned int )(8192ULL / rowblockbytes);
      fprintf(_coverage_fout, "5144\n");
      fflush(_coverage_fout);
      rowsperstrip = rowblocksperstrip * rowblock;
      fprintf(_coverage_fout, "5145\n");
      fflush(_coverage_fout);
      stripbytes = (uint64 )rowblocksperstrip * rowblockbytes;
    } else {
      fprintf(_coverage_fout, "5146\n");
      fflush(_coverage_fout);
      return;
    }
  }
  fprintf(_coverage_fout, "5180\n");
  fflush(_coverage_fout);
  if (rowsperstrip >= td->td_rowsperstrip) {
    fprintf(_coverage_fout, "5148\n");
    fflush(_coverage_fout);
    return;
  } else {
    fprintf(_coverage_fout, "5149\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "5181\n");
  fflush(_coverage_fout);
  nstrips64 = (bytecount + (stripbytes - 1ULL)) / stripbytes;
  fprintf(_coverage_fout, "5182\n");
  fflush(_coverage_fout);
  if (nstrips64 == 0ULL) {
    fprintf(_coverage_fout, "5150\n");
    fflush(_coverage_fout);
    return;
  } else {
    fprintf(_coverage_fout, "5153\n");
    fflush(_coverage_fout);
    if (nstrips64 > 4294967295ULL) {
      fprintf(_coverage_fout, "5151\n");
      fflush(_coverage_fout);
      return;
    } else {
      fprintf(_coverage_fout, "5152\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "5183\n");
  fflush(_coverage_fout);
  nstrips32 = (unsigned int )nstrips64;
  fprintf(_coverage_fout, "5184\n");
  fflush(_coverage_fout);
  tmp = _TIFFCheckMalloc(tif, (long )nstrips32, (long )sizeof(uint64 ),
                         "for chopped \"StripByteCounts\" array");
  fprintf(_coverage_fout, "5185\n");
  fflush(_coverage_fout);
  newcounts = (uint64 *)tmp;
  fprintf(_coverage_fout, "5186\n");
  fflush(_coverage_fout);
  tmp___0 = _TIFFCheckMalloc(tif, (long )nstrips32, (long )sizeof(uint64 ),
                             "for chopped \"StripOffsets\" array");
  fprintf(_coverage_fout, "5187\n");
  fflush(_coverage_fout);
  newoffsets = (uint64 *)tmp___0;
  fprintf(_coverage_fout, "5188\n");
  fflush(_coverage_fout);
  if ((unsigned int )newcounts == (unsigned int )((void *)0)) {
    goto _L;
  } else {
    fprintf(_coverage_fout, "5162\n");
    fflush(_coverage_fout);
    if ((unsigned int )newoffsets == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "5158\n");
      fflush(_coverage_fout);
      _L: /* CIL Label */ 
      if ((unsigned int )newcounts != (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "5154\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)newcounts);
      } else {
        fprintf(_coverage_fout, "5155\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5159\n");
      fflush(_coverage_fout);
      if ((unsigned int )newoffsets != (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "5156\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)newoffsets);
      } else {
        fprintf(_coverage_fout, "5157\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "5160\n");
      fflush(_coverage_fout);
      return;
    } else {
      fprintf(_coverage_fout, "5161\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "5189\n");
  fflush(_coverage_fout);
  strip = 0U;
  fprintf(_coverage_fout, "5190\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "5166\n");
    fflush(_coverage_fout);
    if (strip < nstrips32) {
      fprintf(_coverage_fout, "5163\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "5167\n");
    fflush(_coverage_fout);
    if (stripbytes > bytecount) {
      fprintf(_coverage_fout, "5164\n");
      fflush(_coverage_fout);
      stripbytes = bytecount;
    } else {
      fprintf(_coverage_fout, "5165\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "5168\n");
    fflush(_coverage_fout);
    *(newcounts + strip) = stripbytes;
    fprintf(_coverage_fout, "5169\n");
    fflush(_coverage_fout);
    *(newoffsets + strip) = offset;
    fprintf(_coverage_fout, "5170\n");
    fflush(_coverage_fout);
    offset += stripbytes;
    fprintf(_coverage_fout, "5171\n");
    fflush(_coverage_fout);
    bytecount -= stripbytes;
    fprintf(_coverage_fout, "5172\n");
    fflush(_coverage_fout);
    strip ++;
  }
  fprintf(_coverage_fout, "5191\n");
  fflush(_coverage_fout);
  tmp___1 = nstrips32;
  fprintf(_coverage_fout, "5192\n");
  fflush(_coverage_fout);
  td->td_nstrips = tmp___1;
  fprintf(_coverage_fout, "5193\n");
  fflush(_coverage_fout);
  td->td_stripsperimage = tmp___1;
  fprintf(_coverage_fout, "5194\n");
  fflush(_coverage_fout);
  TIFFSetField(tif, 278U, rowsperstrip);
  fprintf(_coverage_fout, "5195\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)td->td_stripbytecount);
  fprintf(_coverage_fout, "5196\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)td->td_stripoffset);
  fprintf(_coverage_fout, "5197\n");
  fflush(_coverage_fout);
  td->td_stripbytecount = newcounts;
  fprintf(_coverage_fout, "5198\n");
  fflush(_coverage_fout);
  td->td_stripoffset = newoffsets;
  fprintf(_coverage_fout, "5199\n");
  fflush(_coverage_fout);
  td->td_stripbytecountsorted = 1;
  fprintf(_coverage_fout, "5200\n");
  fflush(_coverage_fout);
  return;
}
}
