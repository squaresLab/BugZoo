extern void *_coverage_fout ;
typedef unsigned char __u_char;
typedef unsigned short __u_short;
typedef unsigned int __u_int;
typedef unsigned long __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;
typedef long long __quad_t;
typedef unsigned long long __u_quad_t;
typedef __u_quad_t __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef __u_quad_t __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long __off_t;
typedef __quad_t __off64_t;
typedef int __pid_t;
struct __anonstruct___fsid_t_1 {
   int __val[2] ;
};
typedef struct __anonstruct___fsid_t_1 __fsid_t;
typedef long __clock_t;
typedef unsigned long __rlim_t;
typedef __u_quad_t __rlim64_t;
typedef unsigned int __id_t;
typedef long __time_t;
typedef unsigned int __useconds_t;
typedef long __suseconds_t;
typedef int __daddr_t;
typedef long __swblk_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void *__timer_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef __quad_t __blkcnt64_t;
typedef unsigned long __fsblkcnt_t;
typedef __u_quad_t __fsblkcnt64_t;
typedef unsigned long __fsfilcnt_t;
typedef __u_quad_t __fsfilcnt64_t;
typedef int __ssize_t;
typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;
typedef int __intptr_t;
typedef unsigned int __socklen_t;
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;
typedef __loff_t loff_t;
typedef __ino64_t ino_t;
typedef __dev_t dev_t;
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __nlink_t nlink_t;
typedef __uid_t uid_t;
typedef __off64_t off_t;
typedef __pid_t pid_t;
typedef __id_t id_t;
typedef __ssize_t ssize_t;
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;
typedef __key_t key_t;
typedef __clock_t clock_t;
typedef __time_t time_t;
typedef __clockid_t clockid_t;
typedef __timer_t timer_t;
typedef unsigned int size_t;
typedef unsigned long ulong;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char u_int8_t;
typedef unsigned short u_int16_t;
typedef unsigned int u_int32_t;
typedef unsigned long long u_int64_t;
typedef int register_t;
typedef int __sig_atomic_t;
struct __anonstruct___sigset_t_2 {
   unsigned long __val[1024U / (8U * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_2 __sigset_t;
typedef __sigset_t sigset_t;
struct timespec {
   __time_t tv_sec ;
   long tv_nsec ;
};
struct timeval {
   __time_t tv_sec ;
   __suseconds_t tv_usec ;
};
typedef __suseconds_t suseconds_t;
typedef long __fd_mask;
struct __anonstruct_fd_set_3 {
   __fd_mask __fds_bits[1024 / (8 * (int )sizeof(__fd_mask ))] ;
};
typedef struct __anonstruct_fd_set_3 fd_set;
typedef __fd_mask fd_mask;
typedef __blksize_t blksize_t;
typedef __blkcnt64_t blkcnt_t;
typedef __fsblkcnt64_t fsblkcnt_t;
typedef __fsfilcnt64_t fsfilcnt_t;
typedef unsigned long pthread_t;
union __anonunion_pthread_attr_t_4 {
   char __size[36] ;
   long __align ;
};
typedef union __anonunion_pthread_attr_t_4 pthread_attr_t;
struct __pthread_internal_slist {
   struct __pthread_internal_slist *__next ;
};
typedef struct __pthread_internal_slist __pthread_slist_t;
union __anonunion____missing_field_name_6 {
   int __spins ;
   __pthread_slist_t __list ;
};
struct __pthread_mutex_s {
   int __lock ;
   unsigned int __count ;
   int __owner ;
   int __kind ;
   unsigned int __nusers ;
   union __anonunion____missing_field_name_6 __annonCompField1 ;
};
union __anonunion_pthread_mutex_t_5 {
   struct __pthread_mutex_s __data ;
   char __size[24] ;
   long __align ;
};
typedef union __anonunion_pthread_mutex_t_5 pthread_mutex_t;
union __anonunion_pthread_mutexattr_t_7 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_mutexattr_t_7 pthread_mutexattr_t;
struct __anonstruct___data_9 {
   int __lock ;
   unsigned int __futex ;
   unsigned long long __total_seq ;
   unsigned long long __wakeup_seq ;
   unsigned long long __woken_seq ;
   void *__mutex ;
   unsigned int __nwaiters ;
   unsigned int __broadcast_seq ;
};
union __anonunion_pthread_cond_t_8 {
   struct __anonstruct___data_9 __data ;
   char __size[48] ;
   long long __align ;
};
typedef union __anonunion_pthread_cond_t_8 pthread_cond_t;
union __anonunion_pthread_condattr_t_10 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_condattr_t_10 pthread_condattr_t;
typedef unsigned int pthread_key_t;
typedef int pthread_once_t;
struct __anonstruct___data_12 {
   int __lock ;
   unsigned int __nr_readers ;
   unsigned int __readers_wakeup ;
   unsigned int __writer_wakeup ;
   unsigned int __nr_readers_queued ;
   unsigned int __nr_writers_queued ;
   unsigned char __flags ;
   unsigned char __shared ;
   unsigned char __pad1 ;
   unsigned char __pad2 ;
   int __writer ;
};
union __anonunion_pthread_rwlock_t_11 {
   struct __anonstruct___data_12 __data ;
   char __size[32] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlock_t_11 pthread_rwlock_t;
union __anonunion_pthread_rwlockattr_t_13 {
   char __size[8] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlockattr_t_13 pthread_rwlockattr_t;
typedef int volatile   pthread_spinlock_t;
union __anonunion_pthread_barrier_t_14 {
   char __size[20] ;
   long __align ;
};
typedef union __anonunion_pthread_barrier_t_14 pthread_barrier_t;
union __anonunion_pthread_barrierattr_t_15 {
   char __size[4] ;
   int __align ;
};
typedef union __anonunion_pthread_barrierattr_t_15 pthread_barrierattr_t;
struct flock {
   short l_type ;
   short l_whence ;
   __off64_t l_start ;
   __off64_t l_len ;
   __pid_t l_pid ;
};
struct stat {
   __dev_t st_dev ;
   unsigned short __pad1 ;
   __ino_t __st_ino ;
   __mode_t st_mode ;
   __nlink_t st_nlink ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   __dev_t st_rdev ;
   unsigned short __pad2 ;
   __off64_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt64_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __ino64_t st_ino ;
};
struct __locale_data;
struct __locale_struct {
   struct __locale_data *__locales[13] ;
   unsigned short const   *__ctype_b ;
   int const   *__ctype_tolower ;
   int const   *__ctype_toupper ;
   char const   *__names[13] ;
};
typedef struct __locale_struct *__locale_t;
typedef __locale_t locale_t;
typedef int (*__compar_fn_t)(void const   * , void const   * );
enum __anonenum_ACTION_16 {
    FIND = 0,
    ENTER = 1
} ;
typedef enum __anonenum_ACTION_16 ACTION;
struct entry {
   char *key ;
   void *data ;
};
typedef struct entry ENTRY;
struct _ENTRY;
struct _ENTRY;
enum __anonenum_VISIT_17 {
    preorder = 0,
    postorder = 1,
    endorder = 2,
    leaf = 3
} ;
typedef enum __anonenum_VISIT_17 VISIT;
typedef void (*__action_fn_t)(void const   *__nodep , VISIT __value ,
                              int __level );
typedef signed char int8;
typedef unsigned char uint8;
typedef short int16;
typedef unsigned short uint16;
typedef int int32;
typedef unsigned int uint32;
typedef long long int64;
typedef unsigned long long uint64;
typedef int uint16_vap;
struct __anonstruct_TIFFHeaderCommon_18 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
};
typedef struct __anonstruct_TIFFHeaderCommon_18 TIFFHeaderCommon;
struct __anonstruct_TIFFHeaderClassic_19 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint32 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderClassic_19 TIFFHeaderClassic;
struct __anonstruct_TIFFHeaderBig_20 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint16 tiff_offsetsize ;
   uint16 tiff_unused ;
   uint64 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderBig_20 TIFFHeaderBig;
enum __anonenum_TIFFDataType_21 {
    TIFF_NOTYPE = 0,
    TIFF_BYTE = 1,
    TIFF_ASCII = 2,
    TIFF_SHORT = 3,
    TIFF_LONG = 4,
    TIFF_RATIONAL = 5,
    TIFF_SBYTE = 6,
    TIFF_UNDEFINED = 7,
    TIFF_SSHORT = 8,
    TIFF_SLONG = 9,
    TIFF_SRATIONAL = 10,
    TIFF_FLOAT = 11,
    TIFF_DOUBLE = 12,
    TIFF_IFD = 13,
    TIFF_LONG8 = 16,
    TIFF_SLONG8 = 17,
    TIFF_IFD8 = 18
} ;
typedef enum __anonenum_TIFFDataType_21 TIFFDataType;
struct tiff;
typedef struct tiff TIFF;
typedef long tmsize_t;
typedef uint32 ttag_t;
typedef uint16 tdir_t;
typedef uint16 tsample_t;
typedef uint32 tstrile_t;
typedef tstrile_t tstrip_t;
typedef tstrile_t ttile_t;
typedef tmsize_t tsize_t;
typedef void *tdata_t;
typedef uint64 toff_t;
typedef void *thandle_t;
typedef unsigned char TIFFRGBValue;
struct __anonstruct_TIFFDisplay_22 {
   float d_mat[3][3] ;
   float d_YCR ;
   float d_YCG ;
   float d_YCB ;
   uint32 d_Vrwr ;
   uint32 d_Vrwg ;
   uint32 d_Vrwb ;
   float d_Y0R ;
   float d_Y0G ;
   float d_Y0B ;
   float d_gammaR ;
   float d_gammaG ;
   float d_gammaB ;
};
typedef struct __anonstruct_TIFFDisplay_22 TIFFDisplay;
struct __anonstruct_TIFFYCbCrToRGB_23 {
   TIFFRGBValue *clamptab ;
   int *Cr_r_tab ;
   int *Cb_b_tab ;
   int32 *Cr_g_tab ;
   int32 *Cb_g_tab ;
   int32 *Y_tab ;
};
typedef struct __anonstruct_TIFFYCbCrToRGB_23 TIFFYCbCrToRGB;
struct __anonstruct_TIFFCIELabToRGB_24 {
   int range ;
   float rstep ;
   float gstep ;
   float bstep ;
   float X0 ;
   float Y0 ;
   float Z0 ;
   TIFFDisplay display ;
   float Yr2r[1501] ;
   float Yg2g[1501] ;
   float Yb2b[1501] ;
};
typedef struct __anonstruct_TIFFCIELabToRGB_24 TIFFCIELabToRGB;
struct _TIFFRGBAImage;
typedef struct _TIFFRGBAImage TIFFRGBAImage;
typedef void (*tileContigRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                  uint32  , uint32  , uint32  , int32  ,
                                  int32  , unsigned char * );
typedef void (*tileSeparateRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                    uint32  , uint32  , uint32  , int32  ,
                                    int32  , unsigned char * , unsigned char * ,
                                    unsigned char * , unsigned char * );
union __anonunion_put_25 {
   void (*any)(TIFFRGBAImage * ) ;
   void (*contig)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                  uint32  , int32  , int32  , unsigned char * ) ;
   void (*separate)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                    uint32  , int32  , int32  , unsigned char * ,
                    unsigned char * , unsigned char * , unsigned char * ) ;
};
struct _TIFFRGBAImage {
   TIFF *tif ;
   int stoponerr ;
   int isContig ;
   int alpha ;
   uint32 width ;
   uint32 height ;
   uint16 bitspersample ;
   uint16 samplesperpixel ;
   uint16 orientation ;
   uint16 req_orientation ;
   uint16 photometric ;
   uint16 *redcmap ;
   uint16 *greencmap ;
   uint16 *bluecmap ;
   int (*get)(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
   union __anonunion_put_25 put ;
   TIFFRGBValue *Map ;
   uint32 **BWmap ;
   uint32 **PALmap ;
   TIFFYCbCrToRGB *ycbcr ;
   TIFFCIELabToRGB *cielab ;
   uint8 *UaToAa ;
   uint8 *Bitdepth16To8 ;
   int row_offset ;
   int col_offset ;
};
typedef int (*TIFFInitMethod)(TIFF * , int  );
struct __anonstruct_TIFFCodec_26 {
   char *name ;
   uint16 scheme ;
   int (*init)(TIFF * , int  ) ;
};
typedef struct __anonstruct_TIFFCodec_26 TIFFCodec;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_28 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_27 {
   int __count ;
   union __anonunion___value_28 __value ;
};
typedef struct __anonstruct___mbstate_t_27 __mbstate_t;
struct __anonstruct__G_fpos_t_29 {
   __off_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos_t_29 _G_fpos_t;
struct __anonstruct__G_fpos64_t_30 {
   __off64_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos64_t_30 _G_fpos64_t;
typedef short _G_int16_t;
typedef int _G_int32_t;
typedef unsigned short _G_uint16_t;
typedef unsigned int _G_uint32_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_jump_t;
struct _IO_jump_t;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
enum __codecvt_result {
    __codecvt_ok = 0,
    __codecvt_partial = 1,
    __codecvt_error = 2,
    __codecvt_noconv = 3
} ;
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15U * sizeof(int ) - 4U * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
struct _IO_FILE_plus;
struct _IO_FILE_plus;
typedef __ssize_t __io_read_fn(void *__cookie , char *__buf , size_t __nbytes );
typedef __ssize_t __io_write_fn(void *__cookie , char const   *__buf ,
                                size_t __n );
typedef int __io_seek_fn(void *__cookie , __off64_t *__pos , int __w );
typedef int __io_close_fn(void *__cookie );
typedef __gnuc_va_list va_list;
typedef _G_fpos64_t fpos_t;
typedef void (*TIFFErrorHandler)(char const   * , char const   * , va_list  );
typedef void (*TIFFErrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  );
typedef tmsize_t (*TIFFReadWriteProc)(thandle_t  , void * , tmsize_t  );
typedef uint64 (*TIFFSeekProc)(thandle_t  , uint64  , int  );
typedef int (*TIFFCloseProc)(thandle_t  );
typedef uint64 (*TIFFSizeProc)(thandle_t  );
typedef int (*TIFFMapFileProc)(thandle_t  , void **base , toff_t *size );
typedef void (*TIFFUnmapFileProc)(thandle_t  , void *base , toff_t size );
typedef void (*TIFFExtendProc)(TIFF * );
struct _TIFFField;
typedef struct _TIFFField TIFFField;
struct _TIFFFieldArray;
typedef struct _TIFFFieldArray TIFFFieldArray;
typedef int (*TIFFVSetMethod)(TIFF * , uint32  , va_list  );
typedef int (*TIFFVGetMethod)(TIFF * , uint32  , va_list  );
typedef void (*TIFFPrintMethod)(TIFF * , FILE * , long  );
struct __anonstruct_TIFFTagMethods_31 {
   int (*vsetfield)(TIFF * , uint32  , va_list  ) ;
   int (*vgetfield)(TIFF * , uint32  , va_list  ) ;
   void (*printdir)(TIFF * , FILE * , long  ) ;
};
typedef struct __anonstruct_TIFFTagMethods_31 TIFFTagMethods;
struct __anonstruct_TIFFFieldInfo_32 {
   ttag_t field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
};
typedef struct __anonstruct_TIFFFieldInfo_32 TIFFFieldInfo;
struct __anonstruct_TIFFTagValue_33 {
   TIFFField const   *info ;
   int count ;
   void *value ;
};
typedef struct __anonstruct_TIFFTagValue_33 TIFFTagValue;
struct __anonstruct_TIFFDirectory_34 {
   unsigned long td_fieldsset[4] ;
   uint32 td_imagewidth ;
   uint32 td_imagelength ;
   uint32 td_imagedepth ;
   uint32 td_tilewidth ;
   uint32 td_tilelength ;
   uint32 td_tiledepth ;
   uint32 td_subfiletype ;
   uint16 td_bitspersample ;
   uint16 td_sampleformat ;
   uint16 td_compression ;
   uint16 td_photometric ;
   uint16 td_threshholding ;
   uint16 td_fillorder ;
   uint16 td_orientation ;
   uint16 td_samplesperpixel ;
   uint32 td_rowsperstrip ;
   uint16 td_minsamplevalue ;
   uint16 td_maxsamplevalue ;
   double td_sminsamplevalue ;
   double td_smaxsamplevalue ;
   float td_xresolution ;
   float td_yresolution ;
   uint16 td_resolutionunit ;
   uint16 td_planarconfig ;
   float td_xposition ;
   float td_yposition ;
   uint16 td_pagenumber[2] ;
   uint16 *td_colormap[3] ;
   uint16 td_halftonehints[2] ;
   uint16 td_extrasamples ;
   uint16 *td_sampleinfo ;
   uint32 td_stripsperimage ;
   uint32 td_nstrips ;
   uint64 *td_stripoffset ;
   uint64 *td_stripbytecount ;
   int td_stripbytecountsorted ;
   uint16 td_nsubifd ;
   uint64 *td_subifd ;
   uint16 td_ycbcrsubsampling[2] ;
   uint16 td_ycbcrpositioning ;
   uint16 *td_transferfunction[3] ;
   int td_inknameslen ;
   char *td_inknames ;
   int td_customValueCount ;
   TIFFTagValue *td_customValues ;
};
typedef struct __anonstruct_TIFFDirectory_34 TIFFDirectory;
enum __anonenum_TIFFSetGetFieldType_35 {
    TIFF_SETGET_UNDEFINED = 0,
    TIFF_SETGET_ASCII = 1,
    TIFF_SETGET_UINT8 = 2,
    TIFF_SETGET_SINT8 = 3,
    TIFF_SETGET_UINT16 = 4,
    TIFF_SETGET_SINT16 = 5,
    TIFF_SETGET_UINT32 = 6,
    TIFF_SETGET_SINT32 = 7,
    TIFF_SETGET_UINT64 = 8,
    TIFF_SETGET_SINT64 = 9,
    TIFF_SETGET_FLOAT = 10,
    TIFF_SETGET_DOUBLE = 11,
    TIFF_SETGET_IFD8 = 12,
    TIFF_SETGET_INT = 13,
    TIFF_SETGET_UINT16_PAIR = 14,
    TIFF_SETGET_C0_ASCII = 15,
    TIFF_SETGET_C0_UINT8 = 16,
    TIFF_SETGET_C0_SINT8 = 17,
    TIFF_SETGET_C0_UINT16 = 18,
    TIFF_SETGET_C0_SINT16 = 19,
    TIFF_SETGET_C0_UINT32 = 20,
    TIFF_SETGET_C0_SINT32 = 21,
    TIFF_SETGET_C0_UINT64 = 22,
    TIFF_SETGET_C0_SINT64 = 23,
    TIFF_SETGET_C0_FLOAT = 24,
    TIFF_SETGET_C0_DOUBLE = 25,
    TIFF_SETGET_C0_IFD8 = 26,
    TIFF_SETGET_C16_ASCII = 27,
    TIFF_SETGET_C16_UINT8 = 28,
    TIFF_SETGET_C16_SINT8 = 29,
    TIFF_SETGET_C16_UINT16 = 30,
    TIFF_SETGET_C16_SINT16 = 31,
    TIFF_SETGET_C16_UINT32 = 32,
    TIFF_SETGET_C16_SINT32 = 33,
    TIFF_SETGET_C16_UINT64 = 34,
    TIFF_SETGET_C16_SINT64 = 35,
    TIFF_SETGET_C16_FLOAT = 36,
    TIFF_SETGET_C16_DOUBLE = 37,
    TIFF_SETGET_C16_IFD8 = 38,
    TIFF_SETGET_C32_ASCII = 39,
    TIFF_SETGET_C32_UINT8 = 40,
    TIFF_SETGET_C32_SINT8 = 41,
    TIFF_SETGET_C32_UINT16 = 42,
    TIFF_SETGET_C32_SINT16 = 43,
    TIFF_SETGET_C32_UINT32 = 44,
    TIFF_SETGET_C32_SINT32 = 45,
    TIFF_SETGET_C32_UINT64 = 46,
    TIFF_SETGET_C32_SINT64 = 47,
    TIFF_SETGET_C32_FLOAT = 48,
    TIFF_SETGET_C32_DOUBLE = 49,
    TIFF_SETGET_C32_IFD8 = 50,
    TIFF_SETGET_OTHER = 51
} ;
typedef enum __anonenum_TIFFSetGetFieldType_35 TIFFSetGetFieldType;
enum __anonenum_TIFFFieldArrayType_36 {
    tfiatImage = 0,
    tfiatExif = 1,
    tfiatOther = 2
} ;
typedef enum __anonenum_TIFFFieldArrayType_36 TIFFFieldArrayType;
struct _TIFFFieldArray {
   TIFFFieldArrayType type ;
   uint32 allocated_size ;
   uint32 count ;
   TIFFField *fields ;
};
struct _TIFFField {
   uint32 field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   uint32 reserved ;
   TIFFSetGetFieldType set_field_type ;
   TIFFSetGetFieldType get_field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
   TIFFFieldArray *field_subfields ;
};
struct __anonstruct_TIFFDirEntry_37 {
   uint16 tdir_tag ;
   uint16 tdir_type ;
   uint64 tdir_count ;
   uint64 tdir_offset ;
};
typedef struct __anonstruct_TIFFDirEntry_37 TIFFDirEntry;
struct client_info {
   struct client_info *next ;
   void *data ;
   char *name ;
};
typedef struct client_info TIFFClientInfoLink;
typedef unsigned char tidataval_t;
typedef tidataval_t *tidata_t;
typedef void (*TIFFVoidMethod)(TIFF * );
typedef int (*TIFFBoolMethod)(TIFF * );
typedef int (*TIFFPreMethod)(TIFF * , uint16  );
typedef int (*TIFFCodeMethod)(TIFF *tif , uint8 *buf , tmsize_t size ,
                              uint16 sample );
typedef int (*TIFFSeekMethod)(TIFF * , uint32  );
typedef void (*TIFFPostMethod)(TIFF *tif , uint8 *buf , tmsize_t size );
typedef uint32 (*TIFFStripMethod)(TIFF * , uint32  );
typedef void (*TIFFTileMethod)(TIFF * , uint32 * , uint32 * );
union __anonunion_tif_header_38 {
   TIFFHeaderCommon common ;
   TIFFHeaderClassic classic ;
   TIFFHeaderBig big ;
};
struct tiff {
   char *tif_name ;
   int tif_fd ;
   int tif_mode ;
   uint32 tif_flags ;
   uint64 tif_diroff ;
   uint64 tif_nextdiroff ;
   uint64 *tif_dirlist ;
   uint16 tif_dirlistsize ;
   uint16 tif_dirnumber ;
   TIFFDirectory tif_dir ;
   TIFFDirectory tif_customdir ;
   union __anonunion_tif_header_38 tif_header ;
   uint16 tif_header_size ;
   uint32 tif_row ;
   uint16 tif_curdir ;
   uint32 tif_curstrip ;
   uint64 tif_curoff ;
   uint64 tif_dataoff ;
   uint16 tif_nsubifd ;
   uint64 tif_subifdoff ;
   uint32 tif_col ;
   uint32 tif_curtile ;
   tmsize_t tif_tilesize ;
   int tif_decodestatus ;
   int (*tif_fixuptags)(TIFF * ) ;
   int (*tif_setupdecode)(TIFF * ) ;
   int (*tif_predecode)(TIFF * , uint16  ) ;
   int (*tif_setupencode)(TIFF * ) ;
   int tif_encodestatus ;
   int (*tif_preencode)(TIFF * , uint16  ) ;
   int (*tif_postencode)(TIFF * ) ;
   int (*tif_decoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_decodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_encodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_decodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   void (*tif_close)(TIFF * ) ;
   int (*tif_seek)(TIFF * , uint32  ) ;
   void (*tif_cleanup)(TIFF * ) ;
   uint32 (*tif_defstripsize)(TIFF * , uint32  ) ;
   void (*tif_deftilesize)(TIFF * , uint32 * , uint32 * ) ;
   uint8 *tif_data ;
   tmsize_t tif_scanlinesize ;
   tmsize_t tif_scanlineskew ;
   uint8 *tif_rawdata ;
   tmsize_t tif_rawdatasize ;
   uint8 *tif_rawcp ;
   tmsize_t tif_rawcc ;
   uint8 *tif_base ;
   tmsize_t tif_size ;
   int (*tif_mapproc)(thandle_t  , void **base , toff_t *size ) ;
   void (*tif_unmapproc)(thandle_t  , void *base , toff_t size ) ;
   thandle_t tif_clientdata ;
   tmsize_t (*tif_readproc)(thandle_t  , void * , tmsize_t  ) ;
   tmsize_t (*tif_writeproc)(thandle_t  , void * , tmsize_t  ) ;
   uint64 (*tif_seekproc)(thandle_t  , uint64  , int  ) ;
   int (*tif_closeproc)(thandle_t  ) ;
   uint64 (*tif_sizeproc)(thandle_t  ) ;
   void (*tif_postdecode)(TIFF *tif , uint8 *buf , tmsize_t size ) ;
   TIFFField **tif_fields ;
   uint32 tif_nfields ;
   TIFFField const   *tif_foundfield ;
   TIFFTagMethods tif_tagmethods ;
   TIFFClientInfoLink *tif_clientinfo ;
   TIFFFieldArray *tif_fieldscompat ;
   uint32 tif_nfieldscompat ;
};
extern int select(int __nfds , fd_set * __restrict  __readfds ,
                  fd_set * __restrict  __writefds ,
                  fd_set * __restrict  __exceptfds ,
                  struct timeval * __restrict  __timeout ) ;
extern int pselect(int __nfds , fd_set * __restrict  __readfds ,
                   fd_set * __restrict  __writefds ,
                   fd_set * __restrict  __exceptfds ,
                   struct timespec  const  * __restrict  __timeout ,
                   __sigset_t const   * __restrict  __sigmask ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_major(unsigned long long __dev ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7105\n");
  fflush(_coverage_fout);
  return ((unsigned int )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_minor(unsigned long long __dev ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7106\n");
  fflush(_coverage_fout);
  return ((unsigned int )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                   unsigned int __minor ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7107\n");
  fflush(_coverage_fout);
  return (((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32));
}
}
extern int fcntl(int __fd , int __cmd  , ...) ;
extern int open(char const   *__file , int __oflag  , ...)  __asm__("open64") __attribute__((__nonnull__(1))) ;
extern int openat(int __fd , char const   *__file , int __oflag  , ...)  __asm__("openat64") __attribute__((__nonnull__(2))) ;
extern int creat(char const   *__file , __mode_t __mode )  __asm__("creat64") __attribute__((__nonnull__(1))) ;
extern int lockf(int __fd , int __cmd , __off64_t __len )  __asm__("lockf64")  ;
extern  __attribute__((__nothrow__)) int posix_fadvise(int __fd ,
                                                       __off64_t __offset ,
                                                       __off64_t __len ,
                                                       int __advise )  __asm__("posix_fadvise64")  ;
extern int posix_fallocate(int __fd , __off64_t __offset , __off64_t __len )  __asm__("posix_fallocate64")  ;
extern  __attribute__((__nothrow__)) void *memcpy(void * __restrict  __dest ,
                                                  void const   * __restrict  __src ,
                                                  size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memmove(void *__dest ,
                                                   void const   *__src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memccpy(void * __restrict  __dest ,
                                                   void const   * __restrict  __src ,
                                                   int __c , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memset(void *__s , int __c ,
                                                  size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int memcmp(void const   *__s1 ,
                                                void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memchr(void const   *__s , int __c ,
                                                  size_t __n )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strcat(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncat(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcmp(char const   *__s1 ,
                                                char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncmp(char const   *__s1 ,
                                                 char const   *__s2 ,
                                                 size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcoll(char const   *__s1 ,
                                                 char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm(char * __restrict  __dest ,
                                                    char const   * __restrict  __src ,
                                                    size_t __n )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int strcoll_l(char const   *__s1 ,
                                                   char const   *__s2 ,
                                                   __locale_t __l )  __attribute__((__pure__,
__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm_l(char *__dest ,
                                                      char const   *__src ,
                                                      size_t __n ,
                                                      __locale_t __l )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) char *strdup(char const   *__s )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strndup(char const   *__string ,
                                                   size_t __n )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strrchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strcspn(char const   *__s ,
                                                    char const   *__reject )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strspn(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strpbrk(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strstr(char const   *__haystack ,
                                                  char const   *__needle )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strtok(char * __restrict  __s ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *__strtok_r(char * __restrict  __s ,
                                                      char const   * __restrict  __delim ,
                                                      char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) char *strtok_r(char * __restrict  __s ,
                                                    char const   * __restrict  __delim ,
                                                    char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) size_t strlen(char const   *__s )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strnlen(char const   *__string ,
                                                    size_t __maxlen )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strerror(int __errnum ) ;
extern  __attribute__((__nothrow__)) int strerror_r(int __errnum , char *__buf ,
                                                    size_t __buflen )  __asm__("__xpg_strerror_r") __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *strerror_l(int __errnum ,
                                                      __locale_t __l ) ;
extern  __attribute__((__nothrow__)) void __bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void bcopy(void const   *__src ,
                                                void *__dest , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int bcmp(void const   *__s1 ,
                                              void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *index(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *rindex(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int ffs(int __i )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int strcasecmp(char const   *__s1 ,
                                                    char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncasecmp(char const   *__s1 ,
                                                     char const   *__s2 ,
                                                     size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsep(char ** __restrict  __stringp ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsignal(int __sig ) ;
extern  __attribute__((__nothrow__)) char *__stpcpy(char * __restrict  __dest ,
                                                    char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *__stpncpy(char * __restrict  __dest ,
                                                     char const   * __restrict  __src ,
                                                     size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern void *__rawmemchr(void const   *__s , int __c ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7112\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "7113\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7110\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "7109\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject) {
        fprintf(_coverage_fout, "7108\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "7111\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "7114\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) ;
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7120\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "7121\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7118\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "7117\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        fprintf(_coverage_fout, "7116\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          fprintf(_coverage_fout, "7115\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "7119\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "7122\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) ;
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7129\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "7130\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7127\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "7126\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        fprintf(_coverage_fout, "7125\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          fprintf(_coverage_fout, "7124\n");
          fflush(_coverage_fout);
          if ((int const   )*(__s + __result) != (int const   )__reject3) {
            fprintf(_coverage_fout, "7123\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "7128\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "7131\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) ;
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7135\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "7136\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7133\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept) {
      fprintf(_coverage_fout, "7132\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "7134\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "7137\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7143\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "7144\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7141\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      fprintf(_coverage_fout, "7138\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "7140\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        fprintf(_coverage_fout, "7139\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    }
    fprintf(_coverage_fout, "7142\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "7145\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7153\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "7154\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7151\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      fprintf(_coverage_fout, "7146\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "7150\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        fprintf(_coverage_fout, "7147\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "7149\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) == (int const   )__accept3) {
          fprintf(_coverage_fout, "7148\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      }
    }
    fprintf(_coverage_fout, "7152\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "7155\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7163\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7159\n");
    fflush(_coverage_fout);
    if ((int const   )*__s != 0) {
      fprintf(_coverage_fout, "7158\n");
      fflush(_coverage_fout);
      if ((int const   )*__s != (int const   )__accept1) {
        fprintf(_coverage_fout, "7157\n");
        fflush(_coverage_fout);
        if ((int const   )*__s != (int const   )__accept2) {
          fprintf(_coverage_fout, "7156\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "7160\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "7164\n");
  fflush(_coverage_fout);
  if ((int const   )*__s == 0) {
    fprintf(_coverage_fout, "7161\n");
    fflush(_coverage_fout);
    tmp = (char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "7162\n");
    fflush(_coverage_fout);
    tmp = (char *)((unsigned int )__s);
  }
  fprintf(_coverage_fout, "7165\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7174\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7170\n");
    fflush(_coverage_fout);
    if ((int const   )*__s != 0) {
      fprintf(_coverage_fout, "7169\n");
      fflush(_coverage_fout);
      if ((int const   )*__s != (int const   )__accept1) {
        fprintf(_coverage_fout, "7168\n");
        fflush(_coverage_fout);
        if ((int const   )*__s != (int const   )__accept2) {
          fprintf(_coverage_fout, "7167\n");
          fflush(_coverage_fout);
          if ((int const   )*__s != (int const   )__accept3) {
            fprintf(_coverage_fout, "7166\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "7171\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "7175\n");
  fflush(_coverage_fout);
  if ((int const   )*__s == 0) {
    fprintf(_coverage_fout, "7172\n");
    fflush(_coverage_fout);
    tmp = (char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "7173\n");
    fflush(_coverage_fout);
    tmp = (char *)((unsigned int )__s);
  }
  fprintf(_coverage_fout, "7176\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) ;
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) 
{ char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7194\n");
  fflush(_coverage_fout);
  if ((unsigned int )__s == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "7177\n");
    fflush(_coverage_fout);
    __s = *__nextp;
  } else {
    fprintf(_coverage_fout, "7178\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7195\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "7180\n");
    fflush(_coverage_fout);
    if ((int )*__s == (int )__sep) {
      fprintf(_coverage_fout, "7179\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "7181\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "7196\n");
  fflush(_coverage_fout);
  __result = (char *)((void *)0);
  fprintf(_coverage_fout, "7197\n");
  fflush(_coverage_fout);
  if ((int )*__s != 0) {
    fprintf(_coverage_fout, "7189\n");
    fflush(_coverage_fout);
    tmp = __s;
    fprintf(_coverage_fout, "7190\n");
    fflush(_coverage_fout);
    __s ++;
    fprintf(_coverage_fout, "7191\n");
    fflush(_coverage_fout);
    __result = tmp;
    fprintf(_coverage_fout, "7192\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "7185\n");
      fflush(_coverage_fout);
      if ((int )*__s != 0) {
        fprintf(_coverage_fout, "7182\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "7186\n");
      fflush(_coverage_fout);
      tmp___0 = __s;
      fprintf(_coverage_fout, "7187\n");
      fflush(_coverage_fout);
      __s ++;
      fprintf(_coverage_fout, "7188\n");
      fflush(_coverage_fout);
      if ((int )*tmp___0 == (int )__sep) {
        fprintf(_coverage_fout, "7183\n");
        fflush(_coverage_fout);
        *(__s + -1) = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "7184\n");
        fflush(_coverage_fout);

      }
    }
  } else {
    fprintf(_coverage_fout, "7193\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7198\n");
  fflush(_coverage_fout);
  *__nextp = __s;
  fprintf(_coverage_fout, "7199\n");
  fflush(_coverage_fout);
  return (__result);
}
}
extern char *__strsep_g(char **__stringp , char const   *__delim ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) 
{ register char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  void *tmp___1 ;
  char *tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7209\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "7210\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "7204\n");
    fflush(_coverage_fout);
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    fprintf(_coverage_fout, "7205\n");
    fflush(_coverage_fout);
    tmp___0 = tmp___2;
    fprintf(_coverage_fout, "7206\n");
    fflush(_coverage_fout);
    *__s = tmp___0;
    fprintf(_coverage_fout, "7207\n");
    fflush(_coverage_fout);
    if ((unsigned int )tmp___0 != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "7200\n");
      fflush(_coverage_fout);
      tmp = *__s;
      fprintf(_coverage_fout, "7201\n");
      fflush(_coverage_fout);
      (*__s) ++;
      fprintf(_coverage_fout, "7202\n");
      fflush(_coverage_fout);
      *tmp = (char )'\000';
    } else {
      fprintf(_coverage_fout, "7203\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "7208\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7211\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) ;
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7229\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "7230\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "7225\n");
    fflush(_coverage_fout);
    __cp = __retval;
    fprintf(_coverage_fout, "7226\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "7222\n");
      fflush(_coverage_fout);
      if ((int )*__cp == 0) {
        fprintf(_coverage_fout, "7212\n");
        fflush(_coverage_fout);
        __cp = (char *)((void *)0);
        break;
      } else {
        fprintf(_coverage_fout, "7213\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "7223\n");
      fflush(_coverage_fout);
      if ((int )*__cp == (int )__reject1) {
        fprintf(_coverage_fout, "7214\n");
        fflush(_coverage_fout);
        tmp = __cp;
        fprintf(_coverage_fout, "7215\n");
        fflush(_coverage_fout);
        __cp ++;
        fprintf(_coverage_fout, "7216\n");
        fflush(_coverage_fout);
        *tmp = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "7221\n");
        fflush(_coverage_fout);
        if ((int )*__cp == (int )__reject2) {
          fprintf(_coverage_fout, "7217\n");
          fflush(_coverage_fout);
          tmp = __cp;
          fprintf(_coverage_fout, "7218\n");
          fflush(_coverage_fout);
          __cp ++;
          fprintf(_coverage_fout, "7219\n");
          fflush(_coverage_fout);
          *tmp = (char )'\000';
          break;
        } else {
          fprintf(_coverage_fout, "7220\n");
          fflush(_coverage_fout);

        }
      }
      fprintf(_coverage_fout, "7224\n");
      fflush(_coverage_fout);
      __cp ++;
    }
    fprintf(_coverage_fout, "7227\n");
    fflush(_coverage_fout);
    *__s = __cp;
  } else {
    fprintf(_coverage_fout, "7228\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7231\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) ;
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7253\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "7254\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "7249\n");
    fflush(_coverage_fout);
    __cp = __retval;
    fprintf(_coverage_fout, "7250\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "7246\n");
      fflush(_coverage_fout);
      if ((int )*__cp == 0) {
        fprintf(_coverage_fout, "7232\n");
        fflush(_coverage_fout);
        __cp = (char *)((void *)0);
        break;
      } else {
        fprintf(_coverage_fout, "7233\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "7247\n");
      fflush(_coverage_fout);
      if ((int )*__cp == (int )__reject1) {
        fprintf(_coverage_fout, "7234\n");
        fflush(_coverage_fout);
        tmp = __cp;
        fprintf(_coverage_fout, "7235\n");
        fflush(_coverage_fout);
        __cp ++;
        fprintf(_coverage_fout, "7236\n");
        fflush(_coverage_fout);
        *tmp = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "7245\n");
        fflush(_coverage_fout);
        if ((int )*__cp == (int )__reject2) {
          fprintf(_coverage_fout, "7237\n");
          fflush(_coverage_fout);
          tmp = __cp;
          fprintf(_coverage_fout, "7238\n");
          fflush(_coverage_fout);
          __cp ++;
          fprintf(_coverage_fout, "7239\n");
          fflush(_coverage_fout);
          *tmp = (char )'\000';
          break;
        } else {
          fprintf(_coverage_fout, "7244\n");
          fflush(_coverage_fout);
          if ((int )*__cp == (int )__reject3) {
            fprintf(_coverage_fout, "7240\n");
            fflush(_coverage_fout);
            tmp = __cp;
            fprintf(_coverage_fout, "7241\n");
            fflush(_coverage_fout);
            __cp ++;
            fprintf(_coverage_fout, "7242\n");
            fflush(_coverage_fout);
            *tmp = (char )'\000';
            break;
          } else {
            fprintf(_coverage_fout, "7243\n");
            fflush(_coverage_fout);

          }
        }
      }
      fprintf(_coverage_fout, "7248\n");
      fflush(_coverage_fout);
      __cp ++;
    }
    fprintf(_coverage_fout, "7251\n");
    fflush(_coverage_fout);
    *__s = __cp;
  } else {
    fprintf(_coverage_fout, "7252\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7255\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
extern  __attribute__((__nothrow__)) void *malloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *calloc(size_t __nmemb ,
                                                  size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strdup(char const   *__string )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strndup(char const   *__string ,
                                                     size_t __n )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_fail(char const   *__assertion ,
                                  char const   *__file , unsigned int __line ,
                                  char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_perror_fail(int __errnum , char const   *__file ,
                                         unsigned int __line ,
                                         char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert(char const   *__assertion , char const   *__file ,
                             int __line ) ;
extern  __attribute__((__nothrow__)) void insque(void *__elem , void *__prev ) ;
extern  __attribute__((__nothrow__)) void remque(void *__elem ) ;
extern  __attribute__((__nothrow__)) ENTRY *hsearch(ENTRY __item ,
                                                    ACTION __action ) ;
extern  __attribute__((__nothrow__)) int hcreate(size_t __nel ) ;
extern  __attribute__((__nothrow__)) void hdestroy(void) ;
extern void *tsearch(void const   *__key , void **__rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void *tfind(void const   *__key , void * const  *__rootp ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *tdelete(void const   * __restrict  __key ,
                     void ** __restrict  __rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void twalk(void const   *__root ,
                  void (*__action)(void const   *__nodep , VISIT __value ,
                                   int __level ) ) ;
extern void *lfind(void const   *__key , void const   *__base ,
                   size_t *__nmemb , size_t __size ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *lsearch(void const   *__key , void *__base , size_t *__nmemb ,
                     size_t __size , int (*__compar)(void const   * ,
                                                     void const   * ) ) ;
extern struct _IO_FILE_plus _IO_2_1_stdin_ ;
extern struct _IO_FILE_plus _IO_2_1_stdout_ ;
extern struct _IO_FILE_plus _IO_2_1_stderr_ ;
extern int __underflow(_IO_FILE * ) ;
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_feof(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_ferror(_IO_FILE *__fp ) ;
extern int _IO_peekc_locked(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) void _IO_flockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) void _IO_funlockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) int _IO_ftrylockfile(_IO_FILE * ) ;
extern int _IO_vfscanf(_IO_FILE * __restrict   , char const   * __restrict   ,
                       __gnuc_va_list  , int * __restrict   ) ;
extern int _IO_vfprintf(_IO_FILE * __restrict   , char const   * __restrict   ,
                        __gnuc_va_list  ) ;
extern __ssize_t _IO_padn(_IO_FILE * , int  , __ssize_t  ) ;
extern size_t _IO_sgetn(_IO_FILE * , void * , size_t  ) ;
extern __off64_t _IO_seekoff(_IO_FILE * , __off64_t  , int  , int  ) ;
extern __off64_t _IO_seekpos(_IO_FILE * , __off64_t  , int  ) ;
extern  __attribute__((__nothrow__)) void _IO_free_backup_area(_IO_FILE * ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
extern  __attribute__((__nothrow__)) int remove(char const   *__filename ) ;
extern  __attribute__((__nothrow__)) int rename(char const   *__old ,
                                                char const   *__new ) ;
extern  __attribute__((__nothrow__)) int renameat(int __oldfd ,
                                                  char const   *__old ,
                                                  int __newfd ,
                                                  char const   *__new ) ;
extern FILE *tmpfile(void)  __asm__("tmpfile64")  ;
extern  __attribute__((__nothrow__)) char *tmpnam(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tmpnam_r(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tempnam(char const   *__dir ,
                                                   char const   *__pfx )  __attribute__((__malloc__)) ;
extern int fclose(FILE *__stream ) ;
extern int fflush(FILE *__stream ) ;
extern int fflush_unlocked(FILE *__stream ) ;
extern FILE *freopen(char const   * __restrict  __filename ,
                     char const   * __restrict  __modes ,
                     FILE * __restrict  __stream )  __asm__("freopen64")  ;
extern  __attribute__((__nothrow__)) FILE *fdopen(int __fd ,
                                                  char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *fmemopen(void *__s , size_t __len ,
                                                    char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *open_memstream(char **__bufloc ,
                                                          size_t *__sizeloc ) ;
extern  __attribute__((__nothrow__)) void setbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) int setvbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ,
                                                 int __modes , size_t __n ) ;
extern  __attribute__((__nothrow__)) void setbuffer(FILE * __restrict  __stream ,
                                                    char * __restrict  __buf ,
                                                    size_t __size ) ;
extern  __attribute__((__nothrow__)) void setlinebuf(FILE *__stream ) ;
extern int fprintf(FILE * __restrict  __stream ,
                   char const   * __restrict  __format  , ...) ;
extern int printf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sprintf(char * __restrict  __s ,
                                                 char const   * __restrict  __format 
                                                 , ...) ;
extern int vfprintf(FILE * __restrict  __s ,
                    char const   * __restrict  __format , __gnuc_va_list __arg ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vsprintf(char * __restrict  __s ,
                                                  char const   * __restrict  __format ,
                                                  __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  snprintf)(char * __restrict  __s ,
                                                                             size_t __maxlen ,
                                                                             char const   * __restrict  __format 
                                                                             , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsnprintf)(char * __restrict  __s ,
                                                                              size_t __maxlen ,
                                                                              char const   * __restrict  __format ,
                                                                              __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  vdprintf)(int __fd ,
                                               char const   * __restrict  __fmt ,
                                               __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  dprintf)(int __fd ,
                                              char const   * __restrict  __fmt 
                                              , ...) ;
extern int fscanf(FILE * __restrict  __stream ,
                  char const   * __restrict  __format  , ...)  __asm__("__isoc99_fscanf")  ;
extern int scanf(char const   * __restrict  __format  , ...)  __asm__("__isoc99_scanf")  ;
extern  __attribute__((__nothrow__)) int sscanf(char const   * __restrict  __s ,
                                                char const   * __restrict  __format 
                                                , ...)  __asm__("__isoc99_sscanf")  ;
extern int ( /* format attribute */  vfscanf)(FILE * __restrict  __s ,
                                              char const   * __restrict  __format ,
                                              __gnuc_va_list __arg )  __asm__("__isoc99_vfscanf")  ;
extern int ( /* format attribute */  vscanf)(char const   * __restrict  __format ,
                                             __gnuc_va_list __arg )  __asm__("__isoc99_vscanf")  ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsscanf)(char const   * __restrict  __s ,
                                                                            char const   * __restrict  __format ,
                                                                            __gnuc_va_list __arg )  __asm__("__isoc99_vsscanf")  ;
extern int fgetc(FILE *__stream ) ;
extern int getc(FILE *__stream ) ;
__inline extern int getchar(void) ;
__inline extern int getc_unlocked(FILE *__fp ) ;
__inline extern int getchar_unlocked(void) ;
__inline extern int fgetc_unlocked(FILE *__fp ) ;
extern int fputc(int __c , FILE *__stream ) ;
extern int putc(int __c , FILE *__stream ) ;
__inline extern int putchar(int __c ) ;
__inline extern int fputc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putchar_unlocked(int __c ) ;
extern int getw(FILE *__stream ) ;
extern int putw(int __w , FILE *__stream ) ;
extern char *fgets(char * __restrict  __s , int __n ,
                   FILE * __restrict  __stream ) ;
extern char *gets(char *__s ) ;
extern __ssize_t __getdelim(char ** __restrict  __lineptr ,
                            size_t * __restrict  __n , int __delimiter ,
                            FILE * __restrict  __stream ) ;
extern __ssize_t getdelim(char ** __restrict  __lineptr ,
                          size_t * __restrict  __n , int __delimiter ,
                          FILE * __restrict  __stream ) ;
extern __ssize_t getline(char ** __restrict  __lineptr ,
                         size_t * __restrict  __n , FILE * __restrict  __stream ) ;
extern int fputs(char const   * __restrict  __s , FILE * __restrict  __stream ) ;
extern int puts(char const   *__s ) ;
extern int ungetc(int __c , FILE *__stream ) ;
extern size_t fread(void * __restrict  __ptr , size_t __size , size_t __n ,
                    FILE * __restrict  __stream ) ;
extern size_t fwrite(void const   * __restrict  __ptr , size_t __size ,
                     size_t __n , FILE * __restrict  __s ) ;
extern size_t fread_unlocked(void * __restrict  __ptr , size_t __size ,
                             size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite_unlocked(void const   * __restrict  __ptr , size_t __size ,
                              size_t __n , FILE * __restrict  __stream ) ;
extern int fseek(FILE *__stream , long __off , int __whence ) ;
extern long ftell(FILE *__stream ) ;
extern void rewind(FILE *__stream ) ;
extern int fseeko(FILE *__stream , __off64_t __off , int __whence )  __asm__("fseeko64")  ;
extern __off64_t ftello(FILE *__stream )  __asm__("ftello64")  ;
extern int fgetpos(FILE * __restrict  __stream , fpos_t * __restrict  __pos )  __asm__("fgetpos64")  ;
extern int fsetpos(FILE *__stream , fpos_t const   *__pos )  __asm__("fsetpos64")  ;
extern  __attribute__((__nothrow__)) void clearerr(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int feof(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ferror(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void clearerr_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
extern void perror(char const   *__s ) ;
extern int sys_nerr ;
extern char const   * const  sys_errlist[] ;
extern  __attribute__((__nothrow__)) int fileno(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int fileno_unlocked(FILE *__stream ) ;
extern FILE *popen(char const   *__command , char const   *__modes ) ;
extern int pclose(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) char *ctermid(char *__s ) ;
extern  __attribute__((__nothrow__)) void flockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ftrylockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void funlockfile(FILE *__stream ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7256\n");
  fflush(_coverage_fout);
  tmp = vfprintf((FILE */* __restrict  */)stdout, __fmt, __arg);
  fprintf(_coverage_fout, "7257\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int getchar(void) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7258\n");
  fflush(_coverage_fout);
  tmp = _IO_getc(stdin);
  fprintf(_coverage_fout, "7259\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int fgetc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7265\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "7266\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "7260\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "7261\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "7262\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "7263\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "7264\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "7267\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int getc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7273\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "7274\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "7268\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "7269\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "7270\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "7271\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "7272\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "7275\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int getchar_unlocked(void) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7281\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )stdin->_IO_read_ptr >= (unsigned int )stdin->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "7282\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "7276\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(stdin);
    fprintf(_coverage_fout, "7277\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "7278\n");
    fflush(_coverage_fout);
    tmp___1 = stdin->_IO_read_ptr;
    fprintf(_coverage_fout, "7279\n");
    fflush(_coverage_fout);
    (stdin->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "7280\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "7283\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int putchar(int __c ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7284\n");
  fflush(_coverage_fout);
  tmp = _IO_putc(__c, stdout);
  fprintf(_coverage_fout, "7285\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int fputc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7293\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "7294\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "7286\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "7287\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "7288\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "7289\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "7290\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "7291\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "7292\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "7295\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern int putc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7303\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "7304\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "7296\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "7297\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "7298\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "7299\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "7300\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "7301\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "7302\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "7305\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern int putchar_unlocked(int __c ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7313\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )stdout->_IO_write_ptr >= (unsigned int )stdout->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "7314\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "7306\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "7307\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "7308\n");
    fflush(_coverage_fout);
    tmp___1 = stdout->_IO_write_ptr;
    fprintf(_coverage_fout, "7309\n");
    fflush(_coverage_fout);
    (stdout->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "7310\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "7311\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "7312\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "7315\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern int feof_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7316\n");
  fflush(_coverage_fout);
  return ((__stream->_flags & 0x10) != 0);
}
}
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
__inline extern int ferror_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7317\n");
  fflush(_coverage_fout);
  return ((__stream->_flags & 0x20) != 0);
}
}
extern char const   *TIFFGetVersion(void) ;
extern TIFFCodec const   *TIFFFindCODEC(uint16  ) ;
extern TIFFCodec *TIFFRegisterCODEC(uint16  , char const   * ,
                                    int (*)(TIFF * , int  ) ) ;
extern void TIFFUnRegisterCODEC(TIFFCodec * ) ;
extern int TIFFIsCODECConfigured(uint16  ) ;
extern TIFFCodec *TIFFGetConfiguredCODECs(void) ;
extern void *_TIFFmalloc(tmsize_t s ) ;
extern void *_TIFFrealloc(void *p , tmsize_t s ) ;
extern void _TIFFmemset(void *p , int v , tmsize_t c ) ;
extern void _TIFFmemcpy(void *d , void const   *s , tmsize_t c ) ;
extern int _TIFFmemcmp(void const   *p1 , void const   *p2 , tmsize_t c ) ;
extern void _TIFFfree(void *p ) ;
extern int TIFFGetTagListCount(TIFF * ) ;
extern uint32 TIFFGetTagListEntry(TIFF * , int tag_index ) ;
extern TIFFField const   *TIFFFindField(TIFF * , uint32  , TIFFDataType  ) ;
extern TIFFField const   *TIFFFieldWithTag(TIFF * , uint32  ) ;
extern TIFFField const   *TIFFFieldWithName(TIFF * , char const   * ) ;
extern TIFFTagMethods *TIFFAccessTagMethods(TIFF * ) ;
extern void *TIFFGetClientInfo(TIFF * , char const   * ) ;
extern void TIFFSetClientInfo(TIFF * , void * , char const   * ) ;
extern void TIFFCleanup(TIFF *tif ) ;
extern void TIFFClose(TIFF *tif ) ;
extern int TIFFFlush(TIFF *tif ) ;
extern int TIFFFlushData(TIFF *tif ) ;
extern int TIFFGetField(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFVGetField(TIFF *tif , uint32 tag , va_list ap ) ;
extern int TIFFGetFieldDefaulted(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFVGetFieldDefaulted(TIFF *tif , uint32 tag , va_list ap ) ;
extern int TIFFReadDirectory(TIFF *tif ) ;
extern int TIFFReadCustomDirectory(TIFF *tif , uint64 diroff ,
                                   TIFFFieldArray const   *infoarray ) ;
extern int TIFFReadEXIFDirectory(TIFF *tif , uint64 diroff ) ;
extern uint64 TIFFScanlineSize64(TIFF *tif ) ;
extern tmsize_t TIFFScanlineSize(TIFF *tif ) ;
extern uint64 TIFFRasterScanlineSize64(TIFF *tif ) ;
extern tmsize_t TIFFRasterScanlineSize(TIFF *tif ) ;
extern uint64 TIFFStripSize64(TIFF *tif ) ;
extern tmsize_t TIFFStripSize(TIFF *tif ) ;
extern uint64 TIFFRawStripSize64(TIFF *tif , uint32 strip ) ;
extern tmsize_t TIFFRawStripSize(TIFF *tif , uint32 strip ) ;
extern uint64 TIFFVStripSize64(TIFF *tif , uint32 nrows ) ;
extern tmsize_t TIFFVStripSize(TIFF *tif , uint32 nrows ) ;
extern uint64 TIFFTileRowSize64(TIFF *tif ) ;
extern tmsize_t TIFFTileRowSize(TIFF *tif ) ;
extern uint64 TIFFTileSize64(TIFF *tif ) ;
extern tmsize_t TIFFTileSize(TIFF *tif ) ;
extern uint64 TIFFVTileSize64(TIFF *tif , uint32 nrows ) ;
extern tmsize_t TIFFVTileSize(TIFF *tif , uint32 nrows ) ;
extern uint32 TIFFDefaultStripSize(TIFF *tif , uint32 request ) ;
extern void TIFFDefaultTileSize(TIFF * , uint32 * , uint32 * ) ;
extern int TIFFFileno(TIFF * ) ;
extern int TIFFSetFileno(TIFF * , int  ) ;
extern thandle_t TIFFClientdata(TIFF * ) ;
extern thandle_t TIFFSetClientdata(TIFF * , thandle_t  ) ;
extern int TIFFGetMode(TIFF * ) ;
extern int TIFFSetMode(TIFF * , int  ) ;
extern int TIFFIsTiled(TIFF * ) ;
extern int TIFFIsByteSwapped(TIFF * ) ;
extern int TIFFIsUpSampled(TIFF * ) ;
extern int TIFFIsMSB2LSB(TIFF * ) ;
extern int TIFFIsBigEndian(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetReadProc(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetWriteProc(TIFF * ) ;
extern TIFFSeekProc TIFFGetSeekProc(TIFF * ) ;
extern TIFFCloseProc TIFFGetCloseProc(TIFF * ) ;
extern TIFFSizeProc TIFFGetSizeProc(TIFF * ) ;
extern TIFFMapFileProc TIFFGetMapFileProc(TIFF * ) ;
extern TIFFUnmapFileProc TIFFGetUnmapFileProc(TIFF * ) ;
extern uint32 TIFFCurrentRow(TIFF * ) ;
extern uint16 TIFFCurrentDirectory(TIFF * ) ;
extern uint16 TIFFNumberOfDirectories(TIFF * ) ;
extern uint64 TIFFCurrentDirOffset(TIFF * ) ;
extern uint32 TIFFCurrentStrip(TIFF * ) ;
extern uint32 TIFFCurrentTile(TIFF *tif ) ;
int TIFFReadBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
extern int TIFFWriteBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
extern int TIFFSetupStrips(TIFF * ) ;
extern int TIFFWriteCheck(TIFF * , int  , char const   * ) ;
extern void TIFFFreeDirectory(TIFF * ) ;
extern int TIFFCreateDirectory(TIFF * ) ;
extern int TIFFLastDirectory(TIFF * ) ;
extern int TIFFSetDirectory(TIFF * , uint16  ) ;
extern int TIFFSetSubDirectory(TIFF * , uint64  ) ;
extern int TIFFUnlinkDirectory(TIFF * , uint16  ) ;
extern int TIFFSetField(TIFF * , uint32   , ...) ;
extern int TIFFVSetField(TIFF * , uint32  , va_list  ) ;
extern int TIFFWriteDirectory(TIFF * ) ;
extern int TIFFCheckpointDirectory(TIFF * ) ;
extern int TIFFRewriteDirectory(TIFF * ) ;
extern void TIFFPrintDirectory(TIFF * , FILE * , long  ) ;
int TIFFReadScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) ;
extern int TIFFWriteScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) ;
extern int TIFFReadRGBAImage(TIFF * , uint32  , uint32  , uint32 * , int  ) ;
extern int TIFFReadRGBAImageOriented(TIFF * , uint32  , uint32  , uint32 * ,
                                     int  , int  ) ;
extern int TIFFReadRGBAStrip(TIFF * , uint32  , uint32 * ) ;
extern int TIFFReadRGBATile(TIFF * , uint32  , uint32  , uint32 * ) ;
extern int TIFFRGBAImageOK(TIFF * , char * ) ;
extern int TIFFRGBAImageBegin(TIFFRGBAImage * , TIFF * , int  , char * ) ;
extern int TIFFRGBAImageGet(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
extern void TIFFRGBAImageEnd(TIFFRGBAImage * ) ;
extern TIFF *TIFFOpen(char const   * , char const   * ) ;
extern TIFF *TIFFFdOpen(int  , char const   * , char const   * ) ;
extern TIFF *TIFFClientOpen(char const   * , char const   * , thandle_t  ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            uint64 (*)(thandle_t  , uint64  , int  ) ,
                            int (*)(thandle_t  ) , uint64 (*)(thandle_t  ) ,
                            int (*)(thandle_t  , void **base , toff_t *size ) ,
                            void (*)(thandle_t  , void *base , toff_t size ) ) ;
extern char const   *TIFFFileName(TIFF * ) ;
extern char const   *TIFFSetFileName(TIFF * , char const   * ) ;
extern void TIFFError(char const   * , char const   *  , ...) ;
extern void TIFFErrorExt(thandle_t  , char const   * , char const   *  , ...) ;
extern void TIFFWarning(char const   * , char const   *  , ...) ;
extern void TIFFWarningExt(thandle_t  , char const   * , char const   *  , ...) ;
extern TIFFErrorHandler TIFFSetErrorHandler(void (*)(char const   * ,
                                                     char const   * , va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetErrorHandlerExt(void (*)(thandle_t  ,
                                                           char const   * ,
                                                           char const   * ,
                                                           va_list  ) ) ;
extern TIFFErrorHandler TIFFSetWarningHandler(void (*)(char const   * ,
                                                       char const   * ,
                                                       va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetWarningHandlerExt(void (*)(thandle_t  ,
                                                             char const   * ,
                                                             char const   * ,
                                                             va_list  ) ) ;
extern TIFFExtendProc TIFFSetTagExtender(void (*)(TIFF * ) ) ;
extern uint32 TIFFComputeTile(TIFF *tif , uint32 x , uint32 y , uint32 z ,
                              uint16 s ) ;
extern int TIFFCheckTile(TIFF *tif , uint32 x , uint32 y , uint32 z , uint16 s ) ;
extern uint32 TIFFNumberOfTiles(TIFF * ) ;
tmsize_t TIFFReadTile(TIFF *tif , void *buf , uint32 x , uint32 y , uint32 z ,
                      uint16 s ) ;
extern tmsize_t TIFFWriteTile(TIFF *tif , void *buf , uint32 x , uint32 y ,
                              uint32 z , uint16 s ) ;
extern uint32 TIFFComputeStrip(TIFF * , uint32  , uint16  ) ;
extern uint32 TIFFNumberOfStrips(TIFF * ) ;
tmsize_t TIFFReadEncodedStrip(TIFF *tif , uint32 strip , void *buf ,
                              tmsize_t size ) ;
tmsize_t TIFFReadRawStrip(TIFF *tif , uint32 strip , void *buf , tmsize_t size ) ;
tmsize_t TIFFReadEncodedTile(TIFF *tif , uint32 tile , void *buf ,
                             tmsize_t size ) ;
tmsize_t TIFFReadRawTile(TIFF *tif , uint32 tile , void *buf , tmsize_t size ) ;
extern tmsize_t TIFFWriteEncodedStrip(TIFF *tif , uint32 strip , void *data ,
                                      tmsize_t cc ) ;
extern tmsize_t TIFFWriteRawStrip(TIFF *tif , uint32 strip , void *data ,
                                  tmsize_t cc ) ;
extern tmsize_t TIFFWriteEncodedTile(TIFF *tif , uint32 tile , void *data ,
                                     tmsize_t cc ) ;
extern tmsize_t TIFFWriteRawTile(TIFF *tif , uint32 tile , void *data ,
                                 tmsize_t cc ) ;
extern int TIFFDataWidth(TIFFDataType  ) ;
extern void TIFFSetWriteOffset(TIFF *tif , uint64 off ) ;
extern void TIFFSwabShort(uint16 * ) ;
extern void TIFFSwabLong(uint32 * ) ;
extern void TIFFSwabLong8(uint64 * ) ;
extern void TIFFSwabFloat(float * ) ;
extern void TIFFSwabDouble(double * ) ;
extern void TIFFSwabArrayOfShort(uint16 *wp , tmsize_t n ) ;
extern void TIFFSwabArrayOfTriples(uint8 *tp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong(uint32 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong8(uint64 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfFloat(float *fp , tmsize_t n ) ;
extern void TIFFSwabArrayOfDouble(double *dp , tmsize_t n ) ;
extern void TIFFReverseBits(uint8 *cp , tmsize_t n ) ;
extern unsigned char const   *TIFFGetBitRevTable(int  ) ;
extern double LogL16toY(int  ) ;
extern double LogL10toY(int  ) ;
extern void XYZtoRGB24(float * , uint8 * ) ;
extern int uv_decode(double * , double * , int  ) ;
extern void LogLuv24toXYZ(uint32  , float * ) ;
extern void LogLuv32toXYZ(uint32  , float * ) ;
extern int LogL16fromY(double  , int  ) ;
extern int LogL10fromY(double  , int  ) ;
extern int uv_encode(double  , double  , int  ) ;
extern uint32 LogLuv24fromXYZ(float * , int  ) ;
extern uint32 LogLuv32fromXYZ(float * , int  ) ;
extern int TIFFCIELabToRGBInit(TIFFCIELabToRGB * , TIFFDisplay * , float * ) ;
extern void TIFFCIELabToXYZ(TIFFCIELabToRGB * , uint32  , int32  , int32  ,
                            float * , float * , float * ) ;
extern void TIFFXYZToRGB(TIFFCIELabToRGB * , float  , float  , float  ,
                         uint32 * , uint32 * , uint32 * ) ;
extern int TIFFYCbCrToRGBInit(TIFFYCbCrToRGB * , float * , float * ) ;
extern void TIFFYCbCrtoRGB(TIFFYCbCrToRGB * , uint32  , int32  , int32  ,
                           uint32 * , uint32 * , uint32 * ) ;
extern int TIFFMergeFieldInfo(TIFF * , TIFFFieldInfo const   * , uint32  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfo(TIFF * , uint32  ,
                                                TIFFDataType  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfoByName(TIFF * , char const   * ,
                                                      TIFFDataType  ) ;
extern TIFFFieldArray const   *_TIFFGetFields(void) ;
extern TIFFFieldArray const   *_TIFFGetExifFields(void) ;
extern void _TIFFSetupFields(TIFF *tif , TIFFFieldArray const   *infoarray ) ;
extern void _TIFFPrintFieldInfo(TIFF * , FILE * ) ;
extern int _TIFFMergeFields(TIFF * , TIFFField const   * , uint32  ) ;
extern TIFFField const   *_TIFFFindOrRegisterField(TIFF * , uint32  ,
                                                   TIFFDataType  ) ;
extern TIFFField *_TIFFCreateAnonField(TIFF * , uint32  , TIFFDataType  ) ;
extern int _TIFFgetMode(char const   *mode , char const   *module ) ;
extern int _TIFFNoRowEncode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoStripEncode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoTileEncode(TIFF * , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoRowDecode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoStripDecode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoTileDecode(TIFF * , uint8 *pp , tmsize_t cc , uint16 s ) ;
void _TIFFNoPostDecode(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern int _TIFFNoPreCode(TIFF *tif , uint16 s ) ;
extern int _TIFFNoSeek(TIFF *tif , uint32 off ) ;
void _TIFFSwab16BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
void _TIFFSwab24BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
void _TIFFSwab32BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
void _TIFFSwab64BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern int TIFFFlushData1(TIFF *tif ) ;
extern int TIFFDefaultDirectory(TIFF *tif ) ;
extern void _TIFFSetDefaultCompressionState(TIFF *tif ) ;
extern int TIFFSetCompressionScheme(TIFF *tif , int scheme ) ;
extern int TIFFSetDefaultCompressionState(TIFF *tif ) ;
extern uint32 _TIFFDefaultStripSize(TIFF *tif , uint32 s ) ;
extern void _TIFFDefaultTileSize(TIFF *tif , uint32 *tw , uint32 *th ) ;
extern int _TIFFDataSize(TIFFDataType type ) ;
extern void _TIFFsetByteArray(void ** , void * , uint32  ) ;
extern void _TIFFsetString(char ** , char * ) ;
extern void _TIFFsetShortArray(uint16 ** , uint16 * , uint32  ) ;
extern void _TIFFsetLongArray(uint32 ** , uint32 * , uint32  ) ;
extern void _TIFFsetFloatArray(float ** , float * , uint32  ) ;
extern void _TIFFsetDoubleArray(double ** , double * , uint32  ) ;
extern void _TIFFprintAscii(FILE * , char const   * ) ;
extern void _TIFFprintAsciiTag(FILE * , char const   * , char const   * ) ;
extern void (*_TIFFwarningHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFerrorHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFwarningHandlerExt)(thandle_t  , char const   * ,
                                      char const   * , va_list  ) ;
extern void (*_TIFFerrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  ) ;
extern void *_TIFFCheckMalloc(TIFF *tif , tmsize_t nmemb , tmsize_t elem_size ,
                              char const   *what ) ;
extern void *_TIFFCheckRealloc(TIFF *tif , void *buffer , tmsize_t nmemb ,
                               tmsize_t elem_size , char const   *what ) ;
extern double _TIFFUInt64ToDouble(uint64  ) ;
extern float _TIFFUInt64ToFloat(uint64  ) ;
extern int TIFFInitDumpMode(TIFF * , int  ) ;
extern int TIFFInitPackBits(TIFF * , int  ) ;
extern int TIFFInitCCITTRLE(TIFF * , int  ) ;
extern int TIFFInitCCITTRLEW(TIFF * , int  ) ;
extern int TIFFInitCCITTFax3(TIFF * , int  ) ;
extern int TIFFInitCCITTFax4(TIFF * , int  ) ;
extern int TIFFInitThunderScan(TIFF * , int  ) ;
extern int TIFFInitNeXT(TIFF * , int  ) ;
extern int TIFFInitLZW(TIFF * , int  ) ;
extern int TIFFInitZIP(TIFF * , int  ) ;
extern int TIFFInitPixarLog(TIFF * , int  ) ;
extern int TIFFInitSGILog(TIFF * , int  ) ;
extern TIFFCodec _TIFFBuiltinCODECS[] ;
int TIFFFillStrip(TIFF *tif , uint32 strip ) ;
int TIFFFillTile(TIFF *tif , uint32 tile ) ;
static int TIFFStartStrip(TIFF *tif , uint32 strip ) ;
static int TIFFStartTile(TIFF *tif , uint32 tile ) ;
static int TIFFCheckRead(TIFF *tif , int tiles ) ;
static int TIFFSeek(TIFF *tif , uint32 row , uint16 sample ) 
{ register TIFFDirectory *td ;
  uint32 strip ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7343\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "7344\n");
  fflush(_coverage_fout);
  if (row >= td->td_imagelength) {
    fprintf(_coverage_fout, "7318\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                 "%lu: Row out of range, max %lu", (unsigned long )row,
                 (unsigned long )td->td_imagelength);
    fprintf(_coverage_fout, "7319\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "7320\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7345\n");
  fflush(_coverage_fout);
  if ((int )td->td_planarconfig == 2) {
    fprintf(_coverage_fout, "7324\n");
    fflush(_coverage_fout);
    if ((int )sample >= (int )td->td_samplesperpixel) {
      fprintf(_coverage_fout, "7321\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                   "%lu: Sample out of range, max %lu", (unsigned long )sample,
                   (unsigned long )td->td_samplesperpixel);
      fprintf(_coverage_fout, "7322\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "7323\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "7325\n");
    fflush(_coverage_fout);
    strip = (unsigned int )sample * td->td_stripsperimage + row / td->td_rowsperstrip;
  } else {
    fprintf(_coverage_fout, "7326\n");
    fflush(_coverage_fout);
    strip = row / td->td_rowsperstrip;
  }
  fprintf(_coverage_fout, "7346\n");
  fflush(_coverage_fout);
  if (strip != tif->tif_curstrip) {
    fprintf(_coverage_fout, "7329\n");
    fflush(_coverage_fout);
    tmp = TIFFFillStrip(tif, strip);
    fprintf(_coverage_fout, "7330\n");
    fflush(_coverage_fout);
    if (tmp) {
      fprintf(_coverage_fout, "7327\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "7328\n");
      fflush(_coverage_fout);
      return (0);
    }
  } else {
    fprintf(_coverage_fout, "7336\n");
    fflush(_coverage_fout);
    if (row < tif->tif_row) {
      fprintf(_coverage_fout, "7333\n");
      fflush(_coverage_fout);
      tmp___0 = TIFFStartStrip(tif, strip);
      fprintf(_coverage_fout, "7334\n");
      fflush(_coverage_fout);
      if (tmp___0) {
        fprintf(_coverage_fout, "7331\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "7332\n");
        fflush(_coverage_fout);
        return (0);
      }
    } else {
      fprintf(_coverage_fout, "7335\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "7347\n");
  fflush(_coverage_fout);
  if (row != tif->tif_row) {
    fprintf(_coverage_fout, "7339\n");
    fflush(_coverage_fout);
    tmp___1 = (*(tif->tif_seek))(tif, row - tif->tif_row);
    fprintf(_coverage_fout, "7340\n");
    fflush(_coverage_fout);
    if (tmp___1) {
      fprintf(_coverage_fout, "7337\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "7338\n");
      fflush(_coverage_fout);
      return (0);
    }
    fprintf(_coverage_fout, "7341\n");
    fflush(_coverage_fout);
    tif->tif_row = row;
  } else {
    fprintf(_coverage_fout, "7342\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7348\n");
  fflush(_coverage_fout);
  return (1);
}
}
int TIFFReadScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) 
{ int e ;
  int tmp ;
  int tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7359\n");
  fflush(_coverage_fout);
  tmp = TIFFCheckRead(tif, 0);
  fprintf(_coverage_fout, "7360\n");
  fflush(_coverage_fout);
  if (tmp) {
    fprintf(_coverage_fout, "7349\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "7350\n");
    fflush(_coverage_fout);
    return (-1);
  }
  fprintf(_coverage_fout, "7361\n");
  fflush(_coverage_fout);
  e = TIFFSeek(tif, row, sample);
  fprintf(_coverage_fout, "7362\n");
  fflush(_coverage_fout);
  if (e != 0) {
    fprintf(_coverage_fout, "7353\n");
    fflush(_coverage_fout);
    e = (*(tif->tif_decoderow))(tif, (uint8 *)buf, tif->tif_scanlinesize, sample);
    fprintf(_coverage_fout, "7354\n");
    fflush(_coverage_fout);
    tif->tif_row = row + 1U;
    fprintf(_coverage_fout, "7355\n");
    fflush(_coverage_fout);
    if (e) {
      fprintf(_coverage_fout, "7351\n");
      fflush(_coverage_fout);
      (*(tif->tif_postdecode))(tif, (uint8 *)buf, tif->tif_scanlinesize);
    } else {
      fprintf(_coverage_fout, "7352\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "7356\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7363\n");
  fflush(_coverage_fout);
  if (e > 0) {
    fprintf(_coverage_fout, "7357\n");
    fflush(_coverage_fout);
    tmp___0 = 1;
  } else {
    fprintf(_coverage_fout, "7358\n");
    fflush(_coverage_fout);
    tmp___0 = -1;
  }
  fprintf(_coverage_fout, "7364\n");
  fflush(_coverage_fout);
  return (tmp___0);
}
}
tmsize_t TIFFReadEncodedStrip(TIFF *tif , uint32 strip , void *buf ,
                              tmsize_t size ) ;
static char const   module[21]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'R',      (char const   )'e',      (char const   )'a',      (char const   )'d', 
        (char const   )'E',      (char const   )'n',      (char const   )'c',      (char const   )'o', 
        (char const   )'d',      (char const   )'e',      (char const   )'d',      (char const   )'S', 
        (char const   )'t',      (char const   )'r',      (char const   )'i',      (char const   )'p', 
        (char const   )'\000'};
tmsize_t TIFFReadEncodedStrip(TIFF *tif , uint32 strip , void *buf ,
                              tmsize_t size ) 
{ TIFFDirectory *td ;
  uint32 rowsperstrip ;
  uint32 stripsperplane ;
  uint32 stripinplane ;
  uint16 plane ;
  uint32 rows ;
  tmsize_t stripsize ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7384\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "7385\n");
  fflush(_coverage_fout);
  tmp = TIFFCheckRead(tif, 0);
  fprintf(_coverage_fout, "7386\n");
  fflush(_coverage_fout);
  if (tmp) {
    fprintf(_coverage_fout, "7365\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "7366\n");
    fflush(_coverage_fout);
    return (-1L);
  }
  fprintf(_coverage_fout, "7387\n");
  fflush(_coverage_fout);
  if (strip >= td->td_nstrips) {
    fprintf(_coverage_fout, "7367\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module,
                 "%lu: Strip out of range, max %lu", (unsigned long )strip,
                 (unsigned long )td->td_nstrips);
    fprintf(_coverage_fout, "7368\n");
    fflush(_coverage_fout);
    return (-1L);
  } else {
    fprintf(_coverage_fout, "7369\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7388\n");
  fflush(_coverage_fout);
  rowsperstrip = td->td_rowsperstrip;
  fprintf(_coverage_fout, "7389\n");
  fflush(_coverage_fout);
  if (rowsperstrip > td->td_imagelength) {
    fprintf(_coverage_fout, "7370\n");
    fflush(_coverage_fout);
    rowsperstrip = td->td_imagelength;
  } else {
    fprintf(_coverage_fout, "7371\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7390\n");
  fflush(_coverage_fout);
  stripsperplane = ((td->td_imagelength + rowsperstrip) - 1U) / rowsperstrip;
  fprintf(_coverage_fout, "7391\n");
  fflush(_coverage_fout);
  stripinplane = strip % stripsperplane;
  fprintf(_coverage_fout, "7392\n");
  fflush(_coverage_fout);
  plane = (unsigned short )(strip / stripsperplane);
  fprintf(_coverage_fout, "7393\n");
  fflush(_coverage_fout);
  rows = td->td_imagelength - stripinplane * rowsperstrip;
  fprintf(_coverage_fout, "7394\n");
  fflush(_coverage_fout);
  if (rows > rowsperstrip) {
    fprintf(_coverage_fout, "7372\n");
    fflush(_coverage_fout);
    rows = rowsperstrip;
  } else {
    fprintf(_coverage_fout, "7373\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7395\n");
  fflush(_coverage_fout);
  stripsize = TIFFVStripSize(tif, rows);
  fprintf(_coverage_fout, "7396\n");
  fflush(_coverage_fout);
  if (stripsize == 0L) {
    fprintf(_coverage_fout, "7374\n");
    fflush(_coverage_fout);
    return (-1L);
  } else {
    fprintf(_coverage_fout, "7375\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7397\n");
  fflush(_coverage_fout);
  if (size != -1L) {
    fprintf(_coverage_fout, "7378\n");
    fflush(_coverage_fout);
    if (size < stripsize) {
      fprintf(_coverage_fout, "7376\n");
      fflush(_coverage_fout);
      stripsize = size;
    } else {
      fprintf(_coverage_fout, "7377\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "7379\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7398\n");
  fflush(_coverage_fout);
  tmp___0 = TIFFFillStrip(tif, strip);
  fprintf(_coverage_fout, "7399\n");
  fflush(_coverage_fout);
  if (tmp___0) {
    fprintf(_coverage_fout, "7380\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "7381\n");
    fflush(_coverage_fout);
    return (-1L);
  }
  fprintf(_coverage_fout, "7400\n");
  fflush(_coverage_fout);
  tmp___1 = (*(tif->tif_decodestrip))(tif, (uint8 *)buf, stripsize, plane);
  fprintf(_coverage_fout, "7401\n");
  fflush(_coverage_fout);
  if (tmp___1 <= 0) {
    fprintf(_coverage_fout, "7382\n");
    fflush(_coverage_fout);
    return (-1L);
  } else {
    fprintf(_coverage_fout, "7383\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7402\n");
  fflush(_coverage_fout);
  (*(tif->tif_postdecode))(tif, (uint8 *)buf, stripsize);
  fprintf(_coverage_fout, "7403\n");
  fflush(_coverage_fout);
  return (stripsize);
}
}
static tmsize_t TIFFReadRawStrip1(TIFF *tif , uint32 strip , void *buf ,
                                  tmsize_t size , char const   *module___0 ) 
{ TIFFDirectory *td ;
  tmsize_t cc ;
  uint64 tmp ;
  tmsize_t ma ;
  tmsize_t mb ;
  tmsize_t n ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7434\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "7435\n");
  fflush(_coverage_fout);
  if ((tif->tif_flags & 131072U) == 0U) {
    fprintf(_coverage_fout, "7404\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "7405\n");
    fflush(_coverage_fout);
    __assert_fail("(tif->tif_flags&0x20000)==0", "tif_read.c", 176U,
                  "TIFFReadRawStrip1");
  }
  fprintf(_coverage_fout, "7436\n");
  fflush(_coverage_fout);
  if (! ((tif->tif_flags & 2048U) != 0U)) {
    fprintf(_coverage_fout, "7412\n");
    fflush(_coverage_fout);
    tmp = (*(tif->tif_seekproc))(tif->tif_clientdata,
                                 *(td->td_stripoffset + strip), 0);
    fprintf(_coverage_fout, "7413\n");
    fflush(_coverage_fout);
    if (tmp == *(td->td_stripoffset + strip)) {
      fprintf(_coverage_fout, "7406\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "7407\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "Seek error at scanline %lu, strip %lu",
                   (unsigned long )tif->tif_row, (unsigned long )strip);
      fprintf(_coverage_fout, "7408\n");
      fflush(_coverage_fout);
      return (-1L);
    }
    fprintf(_coverage_fout, "7414\n");
    fflush(_coverage_fout);
    cc = (*(tif->tif_readproc))(tif->tif_clientdata, buf, size);
    fprintf(_coverage_fout, "7415\n");
    fflush(_coverage_fout);
    if (cc != size) {
      fprintf(_coverage_fout, "7409\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "Read error at scanline %lu; got %llu bytes, expected %llu",
                   (unsigned long )tif->tif_row, (unsigned long long )cc,
                   (unsigned long long )size);
      fprintf(_coverage_fout, "7410\n");
      fflush(_coverage_fout);
      return (-1L);
    } else {
      fprintf(_coverage_fout, "7411\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "7429\n");
    fflush(_coverage_fout);
    ma = (long )*(td->td_stripoffset + strip);
    fprintf(_coverage_fout, "7430\n");
    fflush(_coverage_fout);
    mb = ma + size;
    fprintf(_coverage_fout, "7431\n");
    fflush(_coverage_fout);
    if ((unsigned long long )ma != *(td->td_stripoffset + strip)) {
      fprintf(_coverage_fout, "7416\n");
      fflush(_coverage_fout);
      n = 0L;
    } else {
      fprintf(_coverage_fout, "7425\n");
      fflush(_coverage_fout);
      if (ma > tif->tif_size) {
        fprintf(_coverage_fout, "7417\n");
        fflush(_coverage_fout);
        n = 0L;
      } else {
        fprintf(_coverage_fout, "7424\n");
        fflush(_coverage_fout);
        if (mb < ma) {
          fprintf(_coverage_fout, "7418\n");
          fflush(_coverage_fout);
          n = tif->tif_size - ma;
        } else {
          fprintf(_coverage_fout, "7423\n");
          fflush(_coverage_fout);
          if (mb < size) {
            fprintf(_coverage_fout, "7419\n");
            fflush(_coverage_fout);
            n = tif->tif_size - ma;
          } else {
            fprintf(_coverage_fout, "7422\n");
            fflush(_coverage_fout);
            if (mb > tif->tif_size) {
              fprintf(_coverage_fout, "7420\n");
              fflush(_coverage_fout);
              n = tif->tif_size - ma;
            } else {
              fprintf(_coverage_fout, "7421\n");
              fflush(_coverage_fout);
              n = size;
            }
          }
        }
      }
    }
    fprintf(_coverage_fout, "7432\n");
    fflush(_coverage_fout);
    if (n != size) {
      fprintf(_coverage_fout, "7426\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "Read error at scanline %lu, strip %lu; got %llu bytes, expected %llu",
                   (unsigned long )tif->tif_row, (unsigned long )strip,
                   (unsigned long long )n, (unsigned long long )size);
      fprintf(_coverage_fout, "7427\n");
      fflush(_coverage_fout);
      return (-1L);
    } else {
      fprintf(_coverage_fout, "7428\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "7433\n");
    fflush(_coverage_fout);
    _TIFFmemcpy(buf, (void const   *)(tif->tif_base + ma), size);
  }
  fprintf(_coverage_fout, "7437\n");
  fflush(_coverage_fout);
  return (size);
}
}
tmsize_t TIFFReadRawStrip(TIFF *tif , uint32 strip , void *buf , tmsize_t size ) ;
static char const   module___0[17]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'R',      (char const   )'e',      (char const   )'a',      (char const   )'d', 
        (char const   )'R',      (char const   )'a',      (char const   )'w',      (char const   )'S', 
        (char const   )'t',      (char const   )'r',      (char const   )'i',      (char const   )'p', 
        (char const   )'\000'};
tmsize_t TIFFReadRawStrip(TIFF *tif , uint32 strip , void *buf , tmsize_t size ) 
{ TIFFDirectory *td ;
  uint64 bytecount ;
  tmsize_t bytecountm ;
  int tmp ;
  tmsize_t tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7456\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "7457\n");
  fflush(_coverage_fout);
  tmp = TIFFCheckRead(tif, 0);
  fprintf(_coverage_fout, "7458\n");
  fflush(_coverage_fout);
  if (tmp) {
    fprintf(_coverage_fout, "7438\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "7439\n");
    fflush(_coverage_fout);
    return (-1L);
  }
  fprintf(_coverage_fout, "7459\n");
  fflush(_coverage_fout);
  if (strip >= td->td_nstrips) {
    fprintf(_coverage_fout, "7440\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___0,
                 "%lu: Strip out of range, max %lu", (unsigned long )strip,
                 (unsigned long )td->td_nstrips);
    fprintf(_coverage_fout, "7441\n");
    fflush(_coverage_fout);
    return (-1L);
  } else {
    fprintf(_coverage_fout, "7442\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7460\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 131072U) {
    fprintf(_coverage_fout, "7443\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___0,
                 "Compression scheme does not support access to raw uncompressed data");
    fprintf(_coverage_fout, "7444\n");
    fflush(_coverage_fout);
    return (-1L);
  } else {
    fprintf(_coverage_fout, "7445\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7461\n");
  fflush(_coverage_fout);
  bytecount = *(td->td_stripbytecount + strip);
  fprintf(_coverage_fout, "7462\n");
  fflush(_coverage_fout);
  if (bytecount <= 0ULL) {
    fprintf(_coverage_fout, "7446\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___0,
                 "%llu: Invalid strip byte count, strip %lu", bytecount,
                 (unsigned long )strip);
    fprintf(_coverage_fout, "7447\n");
    fflush(_coverage_fout);
    return (-1L);
  } else {
    fprintf(_coverage_fout, "7448\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7463\n");
  fflush(_coverage_fout);
  bytecountm = (long )bytecount;
  fprintf(_coverage_fout, "7464\n");
  fflush(_coverage_fout);
  if ((unsigned long long )bytecountm != bytecount) {
    fprintf(_coverage_fout, "7449\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___0, "Integer overflow");
    fprintf(_coverage_fout, "7450\n");
    fflush(_coverage_fout);
    return (-1L);
  } else {
    fprintf(_coverage_fout, "7451\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7465\n");
  fflush(_coverage_fout);
  if (size != -1L) {
    fprintf(_coverage_fout, "7454\n");
    fflush(_coverage_fout);
    if (size < bytecountm) {
      fprintf(_coverage_fout, "7452\n");
      fflush(_coverage_fout);
      bytecountm = size;
    } else {
      fprintf(_coverage_fout, "7453\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "7455\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7466\n");
  fflush(_coverage_fout);
  tmp___0 = TIFFReadRawStrip1(tif, strip, buf, bytecountm, module___0);
  fprintf(_coverage_fout, "7467\n");
  fflush(_coverage_fout);
  return (tmp___0);
}
}
int TIFFFillStrip(TIFF *tif , uint32 strip ) ;
static char const   module___1[14]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'F',      (char const   )'i',      (char const   )'l',      (char const   )'l', 
        (char const   )'S',      (char const   )'t',      (char const   )'r',      (char const   )'i', 
        (char const   )'p',      (char const   )'\000'};
int TIFFFillStrip(TIFF *tif , uint32 strip ) 
{ TIFFDirectory *td ;
  uint64 bytecount ;
  tmsize_t bytecountm ;
  int tmp ;
  tmsize_t tmp___0 ;
  int tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7519\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "7520\n");
  fflush(_coverage_fout);
  if ((tif->tif_flags & 131072U) == 0U) {
    fprintf(_coverage_fout, "7515\n");
    fflush(_coverage_fout);
    bytecount = *(td->td_stripbytecount + strip);
    fprintf(_coverage_fout, "7516\n");
    fflush(_coverage_fout);
    if (bytecount <= 0ULL) {
      fprintf(_coverage_fout, "7468\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___1,
                   "Invalid strip byte count %llu, strip %lu", bytecount,
                   (unsigned long )strip);
      fprintf(_coverage_fout, "7469\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "7470\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "7517\n");
    fflush(_coverage_fout);
    if ((tif->tif_flags & 2048U) != 0U) {
      fprintf(_coverage_fout, "7489\n");
      fflush(_coverage_fout);
      if ((tif->tif_flags & (unsigned int )td->td_fillorder) != 0U) {
        goto _L___0;
      } else {
        fprintf(_coverage_fout, "7488\n");
        fflush(_coverage_fout);
        if (tif->tif_flags & 256U) {
          fprintf(_coverage_fout, "7483\n");
          fflush(_coverage_fout);
          _L___0: /* CIL Label */ 
          if (tif->tif_flags & 512U) {
            fprintf(_coverage_fout, "7473\n");
            fflush(_coverage_fout);
            if (tif->tif_rawdata) {
              fprintf(_coverage_fout, "7471\n");
              fflush(_coverage_fout);
              _TIFFfree((void *)tif->tif_rawdata);
            } else {
              fprintf(_coverage_fout, "7472\n");
              fflush(_coverage_fout);

            }
          } else {
            fprintf(_coverage_fout, "7474\n");
            fflush(_coverage_fout);

          }
          fprintf(_coverage_fout, "7484\n");
          fflush(_coverage_fout);
          tif->tif_flags &= 4294966783U;
          fprintf(_coverage_fout, "7485\n");
          fflush(_coverage_fout);
          if (bytecount > (unsigned long long )tif->tif_size) {
            fprintf(_coverage_fout, "7475\n");
            fflush(_coverage_fout);
            TIFFErrorExt(tif->tif_clientdata, module___1,
                         "Read error on strip %lu; got %llu bytes, expected %llu",
                         (unsigned long )strip,
                         (unsigned long long )tif->tif_size - *(td->td_stripoffset + strip),
                         bytecount);
            fprintf(_coverage_fout, "7476\n");
            fflush(_coverage_fout);
            tif->tif_curstrip = 4294967295U;
            fprintf(_coverage_fout, "7477\n");
            fflush(_coverage_fout);
            return (0);
          } else {
            fprintf(_coverage_fout, "7482\n");
            fflush(_coverage_fout);
            if (*(td->td_stripoffset + strip) > (unsigned long long )tif->tif_size - bytecount) {
              fprintf(_coverage_fout, "7478\n");
              fflush(_coverage_fout);
              TIFFErrorExt(tif->tif_clientdata, module___1,
                           "Read error on strip %lu; got %llu bytes, expected %llu",
                           (unsigned long )strip,
                           (unsigned long long )tif->tif_size - *(td->td_stripoffset + strip),
                           bytecount);
              fprintf(_coverage_fout, "7479\n");
              fflush(_coverage_fout);
              tif->tif_curstrip = 4294967295U;
              fprintf(_coverage_fout, "7480\n");
              fflush(_coverage_fout);
              return (0);
            } else {
              fprintf(_coverage_fout, "7481\n");
              fflush(_coverage_fout);

            }
          }
          fprintf(_coverage_fout, "7486\n");
          fflush(_coverage_fout);
          tif->tif_rawdatasize = (long )bytecount;
          fprintf(_coverage_fout, "7487\n");
          fflush(_coverage_fout);
          tif->tif_rawdata = tif->tif_base + (long )*(td->td_stripoffset + strip);
        } else {
          goto _L;
        }
      }
    } else {
      fprintf(_coverage_fout, "7509\n");
      fflush(_coverage_fout);
      _L: /* CIL Label */ 
      bytecountm = (long )bytecount;
      fprintf(_coverage_fout, "7510\n");
      fflush(_coverage_fout);
      if ((unsigned long long )bytecountm != bytecount) {
        fprintf(_coverage_fout, "7490\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___1, "Integer overflow");
        fprintf(_coverage_fout, "7491\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "7492\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "7511\n");
      fflush(_coverage_fout);
      if (bytecountm > tif->tif_rawdatasize) {
        fprintf(_coverage_fout, "7498\n");
        fflush(_coverage_fout);
        tif->tif_curstrip = 4294967295U;
        fprintf(_coverage_fout, "7499\n");
        fflush(_coverage_fout);
        if ((tif->tif_flags & 512U) == 0U) {
          fprintf(_coverage_fout, "7493\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___1,
                       "Data buffer too small to hold strip %lu",
                       (unsigned long )strip);
          fprintf(_coverage_fout, "7494\n");
          fflush(_coverage_fout);
          return (0);
        } else {
          fprintf(_coverage_fout, "7495\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "7500\n");
        fflush(_coverage_fout);
        tmp = TIFFReadBufferSetup(tif, (void *)0, bytecountm);
        fprintf(_coverage_fout, "7501\n");
        fflush(_coverage_fout);
        if (tmp) {
          fprintf(_coverage_fout, "7496\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "7497\n");
          fflush(_coverage_fout);
          return (0);
        }
      } else {
        fprintf(_coverage_fout, "7502\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "7512\n");
      fflush(_coverage_fout);
      tmp___0 = TIFFReadRawStrip1(tif, strip, (void *)tif->tif_rawdata,
                                  bytecountm, module___1);
      fprintf(_coverage_fout, "7513\n");
      fflush(_coverage_fout);
      if (tmp___0 != bytecountm) {
        fprintf(_coverage_fout, "7503\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "7504\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "7514\n");
      fflush(_coverage_fout);
      if (! ((tif->tif_flags & (unsigned int )td->td_fillorder) != 0U)) {
        fprintf(_coverage_fout, "7507\n");
        fflush(_coverage_fout);
        if ((tif->tif_flags & 256U) == 0U) {
          fprintf(_coverage_fout, "7505\n");
          fflush(_coverage_fout);
          TIFFReverseBits(tif->tif_rawdata, bytecountm);
        } else {
          fprintf(_coverage_fout, "7506\n");
          fflush(_coverage_fout);

        }
      } else {
        fprintf(_coverage_fout, "7508\n");
        fflush(_coverage_fout);

      }
    }
  } else {
    fprintf(_coverage_fout, "7518\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7521\n");
  fflush(_coverage_fout);
  tmp___1 = TIFFStartStrip(tif, strip);
  fprintf(_coverage_fout, "7522\n");
  fflush(_coverage_fout);
  return (tmp___1);
}
}
tmsize_t TIFFReadTile(TIFF *tif , void *buf , uint32 x , uint32 y , uint32 z ,
                      uint16 s ) 
{ int tmp ;
  int tmp___0 ;
  uint32 tmp___1 ;
  tmsize_t tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7528\n");
  fflush(_coverage_fout);
  tmp = TIFFCheckRead(tif, 1);
  fprintf(_coverage_fout, "7529\n");
  fflush(_coverage_fout);
  if (tmp) {
    fprintf(_coverage_fout, "7525\n");
    fflush(_coverage_fout);
    tmp___0 = TIFFCheckTile(tif, x, y, z, s);
    fprintf(_coverage_fout, "7526\n");
    fflush(_coverage_fout);
    if (tmp___0) {
      fprintf(_coverage_fout, "7523\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "7524\n");
      fflush(_coverage_fout);
      return (-1L);
    }
  } else {
    fprintf(_coverage_fout, "7527\n");
    fflush(_coverage_fout);
    return (-1L);
  }
  fprintf(_coverage_fout, "7530\n");
  fflush(_coverage_fout);
  tmp___1 = TIFFComputeTile(tif, x, y, z, s);
  fprintf(_coverage_fout, "7531\n");
  fflush(_coverage_fout);
  tmp___2 = TIFFReadEncodedTile(tif, tmp___1, buf, -1L);
  fprintf(_coverage_fout, "7532\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
tmsize_t TIFFReadEncodedTile(TIFF *tif , uint32 tile , void *buf ,
                             tmsize_t size ) ;
static char const   module___2[20]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'R',      (char const   )'e',      (char const   )'a',      (char const   )'d', 
        (char const   )'E',      (char const   )'n',      (char const   )'c',      (char const   )'o', 
        (char const   )'d',      (char const   )'e',      (char const   )'d',      (char const   )'T', 
        (char const   )'i',      (char const   )'l',      (char const   )'e',      (char const   )'\000'};
tmsize_t TIFFReadEncodedTile(TIFF *tif , uint32 tile , void *buf ,
                             tmsize_t size ) 
{ TIFFDirectory *td ;
  tmsize_t tilesize ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7548\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "7549\n");
  fflush(_coverage_fout);
  tilesize = tif->tif_tilesize;
  fprintf(_coverage_fout, "7550\n");
  fflush(_coverage_fout);
  tmp = TIFFCheckRead(tif, 1);
  fprintf(_coverage_fout, "7551\n");
  fflush(_coverage_fout);
  if (tmp) {
    fprintf(_coverage_fout, "7533\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "7534\n");
    fflush(_coverage_fout);
    return (-1L);
  }
  fprintf(_coverage_fout, "7552\n");
  fflush(_coverage_fout);
  if (tile >= td->td_nstrips) {
    fprintf(_coverage_fout, "7535\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___2,
                 "%lu: Tile out of range, max %lu", (unsigned long )tile,
                 (unsigned long )td->td_nstrips);
    fprintf(_coverage_fout, "7536\n");
    fflush(_coverage_fout);
    return (-1L);
  } else {
    fprintf(_coverage_fout, "7537\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7553\n");
  fflush(_coverage_fout);
  if (size == -1L) {
    fprintf(_coverage_fout, "7538\n");
    fflush(_coverage_fout);
    size = tilesize;
  } else {
    fprintf(_coverage_fout, "7541\n");
    fflush(_coverage_fout);
    if (size > tilesize) {
      fprintf(_coverage_fout, "7539\n");
      fflush(_coverage_fout);
      size = tilesize;
    } else {
      fprintf(_coverage_fout, "7540\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "7554\n");
  fflush(_coverage_fout);
  tmp___0 = TIFFFillTile(tif, tile);
  fprintf(_coverage_fout, "7555\n");
  fflush(_coverage_fout);
  if (tmp___0) {
    fprintf(_coverage_fout, "7545\n");
    fflush(_coverage_fout);
    tmp___1 = (*(tif->tif_decodetile))(tif, (uint8 *)buf, size,
                                       (unsigned short )(tile / td->td_stripsperimage));
    fprintf(_coverage_fout, "7546\n");
    fflush(_coverage_fout);
    if (tmp___1) {
      fprintf(_coverage_fout, "7542\n");
      fflush(_coverage_fout);
      (*(tif->tif_postdecode))(tif, (uint8 *)buf, size);
      fprintf(_coverage_fout, "7543\n");
      fflush(_coverage_fout);
      return (size);
    } else {
      fprintf(_coverage_fout, "7544\n");
      fflush(_coverage_fout);
      return (-1L);
    }
  } else {
    fprintf(_coverage_fout, "7547\n");
    fflush(_coverage_fout);
    return (-1L);
  }
}
}
static tmsize_t TIFFReadRawTile1(TIFF *tif , uint32 tile , void *buf ,
                                 tmsize_t size , char const   *module___3 ) 
{ TIFFDirectory *td ;
  tmsize_t cc ;
  uint64 tmp ;
  tmsize_t ma ;
  tmsize_t mb ;
  tmsize_t n ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7586\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "7587\n");
  fflush(_coverage_fout);
  if ((tif->tif_flags & 131072U) == 0U) {
    fprintf(_coverage_fout, "7556\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "7557\n");
    fflush(_coverage_fout);
    __assert_fail("(tif->tif_flags&0x20000)==0", "tif_read.c", 460U,
                  "TIFFReadRawTile1");
  }
  fprintf(_coverage_fout, "7588\n");
  fflush(_coverage_fout);
  if (! ((tif->tif_flags & 2048U) != 0U)) {
    fprintf(_coverage_fout, "7564\n");
    fflush(_coverage_fout);
    tmp = (*(tif->tif_seekproc))(tif->tif_clientdata,
                                 *(td->td_stripoffset + tile), 0);
    fprintf(_coverage_fout, "7565\n");
    fflush(_coverage_fout);
    if (tmp == *(td->td_stripoffset + tile)) {
      fprintf(_coverage_fout, "7558\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "7559\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___3,
                   "Seek error at row %lu, col %lu, tile %lu",
                   (unsigned long )tif->tif_row, (unsigned long )tif->tif_col,
                   (unsigned long )tile);
      fprintf(_coverage_fout, "7560\n");
      fflush(_coverage_fout);
      return (-1L);
    }
    fprintf(_coverage_fout, "7566\n");
    fflush(_coverage_fout);
    cc = (*(tif->tif_readproc))(tif->tif_clientdata, buf, size);
    fprintf(_coverage_fout, "7567\n");
    fflush(_coverage_fout);
    if (cc != size) {
      fprintf(_coverage_fout, "7561\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___3,
                   "Read error at row %lu, col %lu; got %llu bytes, expected %llu",
                   (unsigned long )tif->tif_row, (unsigned long )tif->tif_col,
                   (unsigned long long )cc, (unsigned long long )size);
      fprintf(_coverage_fout, "7562\n");
      fflush(_coverage_fout);
      return (-1L);
    } else {
      fprintf(_coverage_fout, "7563\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "7581\n");
    fflush(_coverage_fout);
    ma = (long )*(td->td_stripoffset + tile);
    fprintf(_coverage_fout, "7582\n");
    fflush(_coverage_fout);
    mb = ma + size;
    fprintf(_coverage_fout, "7583\n");
    fflush(_coverage_fout);
    if ((unsigned long long )ma != *(td->td_stripoffset + tile)) {
      fprintf(_coverage_fout, "7568\n");
      fflush(_coverage_fout);
      n = 0L;
    } else {
      fprintf(_coverage_fout, "7577\n");
      fflush(_coverage_fout);
      if (ma > tif->tif_size) {
        fprintf(_coverage_fout, "7569\n");
        fflush(_coverage_fout);
        n = 0L;
      } else {
        fprintf(_coverage_fout, "7576\n");
        fflush(_coverage_fout);
        if (mb < ma) {
          fprintf(_coverage_fout, "7570\n");
          fflush(_coverage_fout);
          n = tif->tif_size - ma;
        } else {
          fprintf(_coverage_fout, "7575\n");
          fflush(_coverage_fout);
          if (mb < size) {
            fprintf(_coverage_fout, "7571\n");
            fflush(_coverage_fout);
            n = tif->tif_size - ma;
          } else {
            fprintf(_coverage_fout, "7574\n");
            fflush(_coverage_fout);
            if (mb > tif->tif_size) {
              fprintf(_coverage_fout, "7572\n");
              fflush(_coverage_fout);
              n = tif->tif_size - ma;
            } else {
              fprintf(_coverage_fout, "7573\n");
              fflush(_coverage_fout);
              n = size;
            }
          }
        }
      }
    }
    fprintf(_coverage_fout, "7584\n");
    fflush(_coverage_fout);
    if (n != size) {
      fprintf(_coverage_fout, "7578\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___3,
                   "Read error at row %lu, col %lu, tile %lu; got %llu bytes, expected %llu",
                   (unsigned long )tif->tif_row, (unsigned long )tif->tif_col,
                   (unsigned long )tile, (unsigned long long )n,
                   (unsigned long long )size);
      fprintf(_coverage_fout, "7579\n");
      fflush(_coverage_fout);
      return (-1L);
    } else {
      fprintf(_coverage_fout, "7580\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "7585\n");
    fflush(_coverage_fout);
    _TIFFmemcpy(buf, (void const   *)(tif->tif_base + ma), size);
  }
  fprintf(_coverage_fout, "7589\n");
  fflush(_coverage_fout);
  return (size);
}
}
tmsize_t TIFFReadRawTile(TIFF *tif , uint32 tile , void *buf , tmsize_t size ) ;
static char const   module___3[16]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'R',      (char const   )'e',      (char const   )'a',      (char const   )'d', 
        (char const   )'R',      (char const   )'a',      (char const   )'w',      (char const   )'T', 
        (char const   )'i',      (char const   )'l',      (char const   )'e',      (char const   )'\000'};
tmsize_t TIFFReadRawTile(TIFF *tif , uint32 tile , void *buf , tmsize_t size ) 
{ TIFFDirectory *td ;
  uint64 bytecount64 ;
  tmsize_t bytecountm ;
  int tmp ;
  tmsize_t tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7605\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "7606\n");
  fflush(_coverage_fout);
  tmp = TIFFCheckRead(tif, 1);
  fprintf(_coverage_fout, "7607\n");
  fflush(_coverage_fout);
  if (tmp) {
    fprintf(_coverage_fout, "7590\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "7591\n");
    fflush(_coverage_fout);
    return (-1L);
  }
  fprintf(_coverage_fout, "7608\n");
  fflush(_coverage_fout);
  if (tile >= td->td_nstrips) {
    fprintf(_coverage_fout, "7592\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___3,
                 "%lu: Tile out of range, max %lu", (unsigned long )tile,
                 (unsigned long )td->td_nstrips);
    fprintf(_coverage_fout, "7593\n");
    fflush(_coverage_fout);
    return (-1L);
  } else {
    fprintf(_coverage_fout, "7594\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7609\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 131072U) {
    fprintf(_coverage_fout, "7595\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___3,
                 "Compression scheme does not support access to raw uncompressed data");
    fprintf(_coverage_fout, "7596\n");
    fflush(_coverage_fout);
    return (-1L);
  } else {
    fprintf(_coverage_fout, "7597\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7610\n");
  fflush(_coverage_fout);
  bytecount64 = *(td->td_stripbytecount + tile);
  fprintf(_coverage_fout, "7611\n");
  fflush(_coverage_fout);
  if (size != -1L) {
    fprintf(_coverage_fout, "7600\n");
    fflush(_coverage_fout);
    if ((unsigned long long )size < bytecount64) {
      fprintf(_coverage_fout, "7598\n");
      fflush(_coverage_fout);
      bytecount64 = (unsigned long long )size;
    } else {
      fprintf(_coverage_fout, "7599\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "7601\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7612\n");
  fflush(_coverage_fout);
  bytecountm = (long )bytecount64;
  fprintf(_coverage_fout, "7613\n");
  fflush(_coverage_fout);
  if ((unsigned long long )bytecountm != bytecount64) {
    fprintf(_coverage_fout, "7602\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___3, "Integer overflow");
    fprintf(_coverage_fout, "7603\n");
    fflush(_coverage_fout);
    return (-1L);
  } else {
    fprintf(_coverage_fout, "7604\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7614\n");
  fflush(_coverage_fout);
  tmp___0 = TIFFReadRawTile1(tif, tile, buf, bytecountm, module___3);
  fprintf(_coverage_fout, "7615\n");
  fflush(_coverage_fout);
  return (tmp___0);
}
}
int TIFFFillTile(TIFF *tif , uint32 tile ) ;
static char const   module___4[13]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'F',      (char const   )'i',      (char const   )'l',      (char const   )'l', 
        (char const   )'T',      (char const   )'i',      (char const   )'l',      (char const   )'e', 
        (char const   )'\000'};
int TIFFFillTile(TIFF *tif , uint32 tile ) 
{ TIFFDirectory *td ;
  uint64 bytecount ;
  tmsize_t bytecountm ;
  int tmp ;
  tmsize_t tmp___0 ;
  int tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7665\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "7666\n");
  fflush(_coverage_fout);
  if ((tif->tif_flags & 131072U) == 0U) {
    fprintf(_coverage_fout, "7661\n");
    fflush(_coverage_fout);
    bytecount = *(td->td_stripbytecount + tile);
    fprintf(_coverage_fout, "7662\n");
    fflush(_coverage_fout);
    if (bytecount <= 0ULL) {
      fprintf(_coverage_fout, "7616\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___4,
                   "%llu: Invalid tile byte count, tile %lu", bytecount,
                   (unsigned long )tile);
      fprintf(_coverage_fout, "7617\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "7618\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "7663\n");
    fflush(_coverage_fout);
    if ((tif->tif_flags & 2048U) != 0U) {
      fprintf(_coverage_fout, "7635\n");
      fflush(_coverage_fout);
      if ((tif->tif_flags & (unsigned int )td->td_fillorder) != 0U) {
        goto _L___0;
      } else {
        fprintf(_coverage_fout, "7634\n");
        fflush(_coverage_fout);
        if (tif->tif_flags & 256U) {
          fprintf(_coverage_fout, "7629\n");
          fflush(_coverage_fout);
          _L___0: /* CIL Label */ 
          if (tif->tif_flags & 512U) {
            fprintf(_coverage_fout, "7621\n");
            fflush(_coverage_fout);
            if (tif->tif_rawdata) {
              fprintf(_coverage_fout, "7619\n");
              fflush(_coverage_fout);
              _TIFFfree((void *)tif->tif_rawdata);
            } else {
              fprintf(_coverage_fout, "7620\n");
              fflush(_coverage_fout);

            }
          } else {
            fprintf(_coverage_fout, "7622\n");
            fflush(_coverage_fout);

          }
          fprintf(_coverage_fout, "7630\n");
          fflush(_coverage_fout);
          tif->tif_flags &= 4294966783U;
          fprintf(_coverage_fout, "7631\n");
          fflush(_coverage_fout);
          if (bytecount > (unsigned long long )tif->tif_size) {
            fprintf(_coverage_fout, "7623\n");
            fflush(_coverage_fout);
            tif->tif_curtile = 4294967295U;
            fprintf(_coverage_fout, "7624\n");
            fflush(_coverage_fout);
            return (0);
          } else {
            fprintf(_coverage_fout, "7628\n");
            fflush(_coverage_fout);
            if (*(td->td_stripoffset + tile) > (unsigned long long )tif->tif_size - bytecount) {
              fprintf(_coverage_fout, "7625\n");
              fflush(_coverage_fout);
              tif->tif_curtile = 4294967295U;
              fprintf(_coverage_fout, "7626\n");
              fflush(_coverage_fout);
              return (0);
            } else {
              fprintf(_coverage_fout, "7627\n");
              fflush(_coverage_fout);

            }
          }
          fprintf(_coverage_fout, "7632\n");
          fflush(_coverage_fout);
          tif->tif_rawdatasize = (long )bytecount;
          fprintf(_coverage_fout, "7633\n");
          fflush(_coverage_fout);
          tif->tif_rawdata = tif->tif_base + (long )*(td->td_stripoffset + tile);
        } else {
          goto _L;
        }
      }
    } else {
      fprintf(_coverage_fout, "7655\n");
      fflush(_coverage_fout);
      _L: /* CIL Label */ 
      bytecountm = (long )bytecount;
      fprintf(_coverage_fout, "7656\n");
      fflush(_coverage_fout);
      if ((unsigned long long )bytecountm != bytecount) {
        fprintf(_coverage_fout, "7636\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___4, "Integer overflow");
        fprintf(_coverage_fout, "7637\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "7638\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "7657\n");
      fflush(_coverage_fout);
      if (bytecountm > tif->tif_rawdatasize) {
        fprintf(_coverage_fout, "7644\n");
        fflush(_coverage_fout);
        tif->tif_curtile = 4294967295U;
        fprintf(_coverage_fout, "7645\n");
        fflush(_coverage_fout);
        if ((tif->tif_flags & 512U) == 0U) {
          fprintf(_coverage_fout, "7639\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___4,
                       "Data buffer too small to hold tile %lu",
                       (unsigned long )tile);
          fprintf(_coverage_fout, "7640\n");
          fflush(_coverage_fout);
          return (0);
        } else {
          fprintf(_coverage_fout, "7641\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "7646\n");
        fflush(_coverage_fout);
        tmp = TIFFReadBufferSetup(tif, (void *)0, bytecountm);
        fprintf(_coverage_fout, "7647\n");
        fflush(_coverage_fout);
        if (tmp) {
          fprintf(_coverage_fout, "7642\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "7643\n");
          fflush(_coverage_fout);
          return (0);
        }
      } else {
        fprintf(_coverage_fout, "7648\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "7658\n");
      fflush(_coverage_fout);
      tmp___0 = TIFFReadRawTile1(tif, tile, (void *)tif->tif_rawdata,
                                 bytecountm, module___4);
      fprintf(_coverage_fout, "7659\n");
      fflush(_coverage_fout);
      if (tmp___0 != bytecountm) {
        fprintf(_coverage_fout, "7649\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "7650\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "7660\n");
      fflush(_coverage_fout);
      if (! ((tif->tif_flags & (unsigned int )td->td_fillorder) != 0U)) {
        fprintf(_coverage_fout, "7653\n");
        fflush(_coverage_fout);
        if ((tif->tif_flags & 256U) == 0U) {
          fprintf(_coverage_fout, "7651\n");
          fflush(_coverage_fout);
          TIFFReverseBits(tif->tif_rawdata, bytecountm);
        } else {
          fprintf(_coverage_fout, "7652\n");
          fflush(_coverage_fout);

        }
      } else {
        fprintf(_coverage_fout, "7654\n");
        fflush(_coverage_fout);

      }
    }
  } else {
    fprintf(_coverage_fout, "7664\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7667\n");
  fflush(_coverage_fout);
  tmp___1 = TIFFStartTile(tif, tile);
  fprintf(_coverage_fout, "7668\n");
  fflush(_coverage_fout);
  return (tmp___1);
}
}
int TIFFReadBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
static char const   module___5[20]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'R',      (char const   )'e',      (char const   )'a',      (char const   )'d', 
        (char const   )'B',      (char const   )'u',      (char const   )'f',      (char const   )'f', 
        (char const   )'e',      (char const   )'r',      (char const   )'S',      (char const   )'e', 
        (char const   )'t',      (char const   )'u',      (char const   )'p',      (char const   )'\000'};
int TIFFReadBufferSetup(TIFF *tif , void *bp , tmsize_t size ) 
{ void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7690\n");
  fflush(_coverage_fout);
  if ((tif->tif_flags & 131072U) == 0U) {
    fprintf(_coverage_fout, "7669\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "7670\n");
    fflush(_coverage_fout);
    __assert_fail("(tif->tif_flags&0x20000)==0", "tif_read.c", 674U,
                  "TIFFReadBufferSetup");
  }
  fprintf(_coverage_fout, "7691\n");
  fflush(_coverage_fout);
  if (tif->tif_rawdata) {
    fprintf(_coverage_fout, "7673\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 512U) {
      fprintf(_coverage_fout, "7671\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)tif->tif_rawdata);
    } else {
      fprintf(_coverage_fout, "7672\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "7674\n");
    fflush(_coverage_fout);
    tif->tif_rawdata = (uint8 *)((void *)0);
  } else {
    fprintf(_coverage_fout, "7675\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7692\n");
  fflush(_coverage_fout);
  if (bp) {
    fprintf(_coverage_fout, "7676\n");
    fflush(_coverage_fout);
    tif->tif_rawdatasize = size;
    fprintf(_coverage_fout, "7677\n");
    fflush(_coverage_fout);
    tif->tif_rawdata = (uint8 *)bp;
    fprintf(_coverage_fout, "7678\n");
    fflush(_coverage_fout);
    tif->tif_flags &= 4294966783U;
  } else {
    fprintf(_coverage_fout, "7681\n");
    fflush(_coverage_fout);
    tif->tif_rawdatasize = (long )((((unsigned long long )size + 1023ULL) / 1024ULL) * 1024ULL);
    fprintf(_coverage_fout, "7682\n");
    fflush(_coverage_fout);
    if (tif->tif_rawdatasize == 0L) {
      fprintf(_coverage_fout, "7679\n");
      fflush(_coverage_fout);
      tif->tif_rawdatasize = -1L;
    } else {
      fprintf(_coverage_fout, "7680\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "7683\n");
    fflush(_coverage_fout);
    tmp = _TIFFmalloc(tif->tif_rawdatasize);
    fprintf(_coverage_fout, "7684\n");
    fflush(_coverage_fout);
    tif->tif_rawdata = (uint8 *)tmp;
    fprintf(_coverage_fout, "7685\n");
    fflush(_coverage_fout);
    tif->tif_flags |= 512U;
  }
  fprintf(_coverage_fout, "7693\n");
  fflush(_coverage_fout);
  if ((unsigned int )tif->tif_rawdata == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "7686\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___5,
                 "No space for data buffer at scanline %lu",
                 (unsigned long )tif->tif_row);
    fprintf(_coverage_fout, "7687\n");
    fflush(_coverage_fout);
    tif->tif_rawdatasize = 0L;
    fprintf(_coverage_fout, "7688\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "7689\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7694\n");
  fflush(_coverage_fout);
  return (1);
}
}
static int TIFFStartStrip(TIFF *tif , uint32 strip ) 
{ TIFFDirectory *td ;
  int tmp ;
  int tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7705\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "7706\n");
  fflush(_coverage_fout);
  if ((tif->tif_flags & 32U) == 0U) {
    fprintf(_coverage_fout, "7697\n");
    fflush(_coverage_fout);
    tmp = (*(tif->tif_setupdecode))(tif);
    fprintf(_coverage_fout, "7698\n");
    fflush(_coverage_fout);
    if (tmp) {
      fprintf(_coverage_fout, "7695\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "7696\n");
      fflush(_coverage_fout);
      return (0);
    }
    fprintf(_coverage_fout, "7699\n");
    fflush(_coverage_fout);
    tif->tif_flags |= 32U;
  } else {
    fprintf(_coverage_fout, "7700\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7707\n");
  fflush(_coverage_fout);
  tif->tif_curstrip = strip;
  fprintf(_coverage_fout, "7708\n");
  fflush(_coverage_fout);
  tif->tif_row = (strip % td->td_stripsperimage) * td->td_rowsperstrip;
  fprintf(_coverage_fout, "7709\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 131072U) {
    fprintf(_coverage_fout, "7701\n");
    fflush(_coverage_fout);
    tif->tif_rawcp = (uint8 *)((void *)0);
    fprintf(_coverage_fout, "7702\n");
    fflush(_coverage_fout);
    tif->tif_rawcc = 0L;
  } else {
    fprintf(_coverage_fout, "7703\n");
    fflush(_coverage_fout);
    tif->tif_rawcp = tif->tif_rawdata;
    fprintf(_coverage_fout, "7704\n");
    fflush(_coverage_fout);
    tif->tif_rawcc = (long )*(td->td_stripbytecount + strip);
  }
  fprintf(_coverage_fout, "7710\n");
  fflush(_coverage_fout);
  tmp___0 = (*(tif->tif_predecode))(tif,
                                    (unsigned short )(strip / td->td_stripsperimage));
  fprintf(_coverage_fout, "7711\n");
  fflush(_coverage_fout);
  return (tmp___0);
}
}
static int TIFFStartTile(TIFF *tif , uint32 tile ) 
{ TIFFDirectory *td ;
  int tmp ;
  int tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7722\n");
  fflush(_coverage_fout);
  td = & tif->tif_dir;
  fprintf(_coverage_fout, "7723\n");
  fflush(_coverage_fout);
  if ((tif->tif_flags & 32U) == 0U) {
    fprintf(_coverage_fout, "7714\n");
    fflush(_coverage_fout);
    tmp = (*(tif->tif_setupdecode))(tif);
    fprintf(_coverage_fout, "7715\n");
    fflush(_coverage_fout);
    if (tmp) {
      fprintf(_coverage_fout, "7712\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "7713\n");
      fflush(_coverage_fout);
      return (0);
    }
    fprintf(_coverage_fout, "7716\n");
    fflush(_coverage_fout);
    tif->tif_flags |= 32U;
  } else {
    fprintf(_coverage_fout, "7717\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7724\n");
  fflush(_coverage_fout);
  tif->tif_curtile = tile;
  fprintf(_coverage_fout, "7725\n");
  fflush(_coverage_fout);
  tif->tif_row = (tile % ((td->td_imagewidth + (td->td_tilewidth - 1U)) / td->td_tilewidth)) * td->td_tilelength;
  fprintf(_coverage_fout, "7726\n");
  fflush(_coverage_fout);
  tif->tif_col = (tile % ((td->td_imagelength + (td->td_tilelength - 1U)) / td->td_tilelength)) * td->td_tilewidth;
  fprintf(_coverage_fout, "7727\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 131072U) {
    fprintf(_coverage_fout, "7718\n");
    fflush(_coverage_fout);
    tif->tif_rawcp = (uint8 *)((void *)0);
    fprintf(_coverage_fout, "7719\n");
    fflush(_coverage_fout);
    tif->tif_rawcc = 0L;
  } else {
    fprintf(_coverage_fout, "7720\n");
    fflush(_coverage_fout);
    tif->tif_rawcp = tif->tif_rawdata;
    fprintf(_coverage_fout, "7721\n");
    fflush(_coverage_fout);
    tif->tif_rawcc = (long )*(td->td_stripbytecount + tile);
  }
  fprintf(_coverage_fout, "7728\n");
  fflush(_coverage_fout);
  tmp___0 = (*(tif->tif_predecode))(tif,
                                    (unsigned short )(tile / td->td_stripsperimage));
  fprintf(_coverage_fout, "7729\n");
  fflush(_coverage_fout);
  return (tmp___0);
}
}
static int TIFFCheckRead(TIFF *tif , int tiles ) 
{ char const   *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7739\n");
  fflush(_coverage_fout);
  if (tif->tif_mode == 01) {
    fprintf(_coverage_fout, "7730\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                 "File not open for reading");
    fprintf(_coverage_fout, "7731\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "7732\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7740\n");
  fflush(_coverage_fout);
  if (tiles ^ ((tif->tif_flags & 1024U) != 0U)) {
    fprintf(_coverage_fout, "7735\n");
    fflush(_coverage_fout);
    if (tiles) {
      fprintf(_coverage_fout, "7733\n");
      fflush(_coverage_fout);
      tmp = "Can not read tiles from a stripped image";
    } else {
      fprintf(_coverage_fout, "7734\n");
      fflush(_coverage_fout);
      tmp = "Can not read scanlines from a tiled image";
    }
    fprintf(_coverage_fout, "7736\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name, tmp);
    fprintf(_coverage_fout, "7737\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "7738\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "7741\n");
  fflush(_coverage_fout);
  return (1);
}
}
void _TIFFNoPostDecode(TIFF *tif , uint8 *buf , tmsize_t cc ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7742\n");
  fflush(_coverage_fout);
  return;
}
}
void _TIFFSwab16BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7745\n");
  fflush(_coverage_fout);
  if ((cc & 1L) == 0L) {
    fprintf(_coverage_fout, "7743\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "7744\n");
    fflush(_coverage_fout);
    __assert_fail("(cc & 1) == 0", "tif_read.c", 792U, "_TIFFSwab16BitData");
  }
  fprintf(_coverage_fout, "7746\n");
  fflush(_coverage_fout);
  TIFFSwabArrayOfShort((uint16 *)buf, cc / 2L);
  fprintf(_coverage_fout, "7747\n");
  fflush(_coverage_fout);
  return;
}
}
void _TIFFSwab24BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7750\n");
  fflush(_coverage_fout);
  if (cc % 3L == 0L) {
    fprintf(_coverage_fout, "7748\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "7749\n");
    fflush(_coverage_fout);
    __assert_fail("(cc % 3) == 0", "tif_read.c", 800U, "_TIFFSwab24BitData");
  }
  fprintf(_coverage_fout, "7751\n");
  fflush(_coverage_fout);
  TIFFSwabArrayOfTriples(buf, cc / 3L);
  fprintf(_coverage_fout, "7752\n");
  fflush(_coverage_fout);
  return;
}
}
void _TIFFSwab32BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7755\n");
  fflush(_coverage_fout);
  if ((cc & 3L) == 0L) {
    fprintf(_coverage_fout, "7753\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "7754\n");
    fflush(_coverage_fout);
    __assert_fail("(cc & 3) == 0", "tif_read.c", 808U, "_TIFFSwab32BitData");
  }
  fprintf(_coverage_fout, "7756\n");
  fflush(_coverage_fout);
  TIFFSwabArrayOfLong((uint32 *)buf, cc / 4L);
  fprintf(_coverage_fout, "7757\n");
  fflush(_coverage_fout);
  return;
}
}
void _TIFFSwab64BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-5e6542ee-e779b6cd/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "7760\n");
  fflush(_coverage_fout);
  if ((cc & 7L) == 0L) {
    fprintf(_coverage_fout, "7758\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "7759\n");
    fflush(_coverage_fout);
    __assert_fail("(cc & 7) == 0", "tif_read.c", 816U, "_TIFFSwab64BitData");
  }
  fprintf(_coverage_fout, "7761\n");
  fflush(_coverage_fout);
  TIFFSwabArrayOfDouble((double *)buf, cc / 8L);
  fprintf(_coverage_fout, "7762\n");
  fflush(_coverage_fout);
  return;
}
}
