void *_coverage_fout ;
typedef unsigned int size_t;
typedef unsigned char __u_char;
typedef unsigned short __u_short;
typedef unsigned int __u_int;
typedef unsigned long __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;
typedef long long __quad_t;
typedef unsigned long long __u_quad_t;
typedef __u_quad_t __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef __u_quad_t __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long __off_t;
typedef __quad_t __off64_t;
typedef int __pid_t;
struct __anonstruct___fsid_t_1 {
   int __val[2] ;
};
typedef struct __anonstruct___fsid_t_1 __fsid_t;
typedef long __clock_t;
typedef unsigned long __rlim_t;
typedef __u_quad_t __rlim64_t;
typedef unsigned int __id_t;
typedef long __time_t;
typedef unsigned int __useconds_t;
typedef long __suseconds_t;
typedef int __daddr_t;
typedef long __swblk_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void *__timer_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef __quad_t __blkcnt64_t;
typedef unsigned long __fsblkcnt_t;
typedef __u_quad_t __fsblkcnt64_t;
typedef unsigned long __fsfilcnt_t;
typedef __u_quad_t __fsfilcnt64_t;
typedef int __ssize_t;
typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;
typedef int __intptr_t;
typedef unsigned int __socklen_t;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_3 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_2 {
   int __count ;
   union __anonunion___value_3 __value ;
};
typedef struct __anonstruct___mbstate_t_2 __mbstate_t;
struct __anonstruct__G_fpos_t_4 {
   __off_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos_t_4 _G_fpos_t;
struct __anonstruct__G_fpos64_t_5 {
   __off64_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos64_t_5 _G_fpos64_t;
typedef short _G_int16_t;
typedef int _G_int32_t;
typedef unsigned short _G_uint16_t;
typedef unsigned int _G_uint32_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_jump_t;
struct _IO_jump_t;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
enum __codecvt_result {
    __codecvt_ok = 0,
    __codecvt_partial = 1,
    __codecvt_error = 2,
    __codecvt_noconv = 3
} ;
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15U * sizeof(int ) - 4U * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
struct _IO_FILE_plus;
struct _IO_FILE_plus;
typedef __ssize_t __io_read_fn(void *__cookie , char *__buf , size_t __nbytes );
typedef __ssize_t __io_write_fn(void *__cookie , char const   *__buf ,
                                size_t __n );
typedef int __io_seek_fn(void *__cookie , __off64_t *__pos , int __w );
typedef int __io_close_fn(void *__cookie );
typedef __gnuc_va_list va_list;
typedef __off64_t off_t;
typedef __ssize_t ssize_t;
typedef _G_fpos64_t fpos_t;
typedef long wchar_t;
struct __anonstruct___wait_terminated_6 {
   unsigned int __w_termsig : 7 ;
   unsigned int __w_coredump : 1 ;
   unsigned int __w_retcode : 8 ;
   unsigned int  : 16 ;
};
struct __anonstruct___wait_stopped_7 {
   unsigned int __w_stopval : 8 ;
   unsigned int __w_stopsig : 8 ;
   unsigned int  : 16 ;
};
union wait {
   int w_status ;
   struct __anonstruct___wait_terminated_6 __wait_terminated ;
   struct __anonstruct___wait_stopped_7 __wait_stopped ;
};
union __anonunion___WAIT_STATUS_8 {
   union wait *__uptr ;
   int *__iptr ;
};
typedef union __anonunion___WAIT_STATUS_8  __attribute__((__transparent_union__)) __WAIT_STATUS;
struct __anonstruct_div_t_9 {
   int quot ;
   int rem ;
};
typedef struct __anonstruct_div_t_9 div_t;
struct __anonstruct_ldiv_t_10 {
   long quot ;
   long rem ;
};
typedef struct __anonstruct_ldiv_t_10 ldiv_t;
struct __anonstruct_lldiv_t_11 {
   long long quot ;
   long long rem ;
};
typedef struct __anonstruct_lldiv_t_11 lldiv_t;
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;
typedef __loff_t loff_t;
typedef __ino64_t ino_t;
typedef __dev_t dev_t;
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __nlink_t nlink_t;
typedef __uid_t uid_t;
typedef __pid_t pid_t;
typedef __id_t id_t;
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;
typedef __key_t key_t;
typedef __clock_t clock_t;
typedef __time_t time_t;
typedef __clockid_t clockid_t;
typedef __timer_t timer_t;
typedef unsigned long ulong;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char u_int8_t;
typedef unsigned short u_int16_t;
typedef unsigned int u_int32_t;
typedef unsigned long long u_int64_t;
typedef int register_t;
typedef int __sig_atomic_t;
struct __anonstruct___sigset_t_12 {
   unsigned long __val[1024U / (8U * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_12 __sigset_t;
typedef __sigset_t sigset_t;
struct timespec {
   __time_t tv_sec ;
   long tv_nsec ;
};
struct timeval {
   __time_t tv_sec ;
   __suseconds_t tv_usec ;
};
typedef __suseconds_t suseconds_t;
typedef long __fd_mask;
struct __anonstruct_fd_set_13 {
   __fd_mask __fds_bits[1024 / (8 * (int )sizeof(__fd_mask ))] ;
};
typedef struct __anonstruct_fd_set_13 fd_set;
typedef __fd_mask fd_mask;
typedef __blksize_t blksize_t;
typedef __blkcnt64_t blkcnt_t;
typedef __fsblkcnt64_t fsblkcnt_t;
typedef __fsfilcnt64_t fsfilcnt_t;
typedef unsigned long pthread_t;
union __anonunion_pthread_attr_t_14 {
   char __size[36] ;
   long __align ;
};
typedef union __anonunion_pthread_attr_t_14 pthread_attr_t;
struct __pthread_internal_slist {
   struct __pthread_internal_slist *__next ;
};
typedef struct __pthread_internal_slist __pthread_slist_t;
union __anonunion____missing_field_name_16 {
   int __spins ;
   __pthread_slist_t __list ;
};
struct __pthread_mutex_s {
   int __lock ;
   unsigned int __count ;
   int __owner ;
   int __kind ;
   unsigned int __nusers ;
   union __anonunion____missing_field_name_16 __annonCompField1 ;
};
union __anonunion_pthread_mutex_t_15 {
   struct __pthread_mutex_s __data ;
   char __size[24] ;
   long __align ;
};
typedef union __anonunion_pthread_mutex_t_15 pthread_mutex_t;
union __anonunion_pthread_mutexattr_t_17 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_mutexattr_t_17 pthread_mutexattr_t;
struct __anonstruct___data_19 {
   int __lock ;
   unsigned int __futex ;
   unsigned long long __total_seq ;
   unsigned long long __wakeup_seq ;
   unsigned long long __woken_seq ;
   void *__mutex ;
   unsigned int __nwaiters ;
   unsigned int __broadcast_seq ;
};
union __anonunion_pthread_cond_t_18 {
   struct __anonstruct___data_19 __data ;
   char __size[48] ;
   long long __align ;
};
typedef union __anonunion_pthread_cond_t_18 pthread_cond_t;
union __anonunion_pthread_condattr_t_20 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_condattr_t_20 pthread_condattr_t;
typedef unsigned int pthread_key_t;
typedef int pthread_once_t;
struct __anonstruct___data_22 {
   int __lock ;
   unsigned int __nr_readers ;
   unsigned int __readers_wakeup ;
   unsigned int __writer_wakeup ;
   unsigned int __nr_readers_queued ;
   unsigned int __nr_writers_queued ;
   unsigned char __flags ;
   unsigned char __shared ;
   unsigned char __pad1 ;
   unsigned char __pad2 ;
   int __writer ;
};
union __anonunion_pthread_rwlock_t_21 {
   struct __anonstruct___data_22 __data ;
   char __size[32] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlock_t_21 pthread_rwlock_t;
union __anonunion_pthread_rwlockattr_t_23 {
   char __size[8] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlockattr_t_23 pthread_rwlockattr_t;
typedef int volatile   pthread_spinlock_t;
union __anonunion_pthread_barrier_t_24 {
   char __size[20] ;
   long __align ;
};
typedef union __anonunion_pthread_barrier_t_24 pthread_barrier_t;
union __anonunion_pthread_barrierattr_t_25 {
   char __size[4] ;
   int __align ;
};
typedef union __anonunion_pthread_barrierattr_t_25 pthread_barrierattr_t;
struct random_data {
   int32_t *fptr ;
   int32_t *rptr ;
   int32_t *state ;
   int rand_type ;
   int rand_deg ;
   int rand_sep ;
   int32_t *end_ptr ;
};
struct drand48_data {
   unsigned short __x[3] ;
   unsigned short __old_x[3] ;
   unsigned short __c ;
   unsigned short __init ;
   unsigned long long __a ;
};
typedef int (*__compar_fn_t)(void const   * , void const   * );
struct __locale_data;
struct __locale_struct {
   struct __locale_data *__locales[13] ;
   unsigned short const   *__ctype_b ;
   int const   *__ctype_tolower ;
   int const   *__ctype_toupper ;
   char const   *__names[13] ;
};
typedef struct __locale_struct *__locale_t;
typedef __locale_t locale_t;
typedef __useconds_t useconds_t;
typedef __intptr_t intptr_t;
typedef __socklen_t socklen_t;
enum __anonenum_26 {
    _PC_LINK_MAX = 0,
    _PC_MAX_CANON = 1,
    _PC_MAX_INPUT = 2,
    _PC_NAME_MAX = 3,
    _PC_PATH_MAX = 4,
    _PC_PIPE_BUF = 5,
    _PC_CHOWN_RESTRICTED = 6,
    _PC_NO_TRUNC = 7,
    _PC_VDISABLE = 8,
    _PC_SYNC_IO = 9,
    _PC_ASYNC_IO = 10,
    _PC_PRIO_IO = 11,
    _PC_SOCK_MAXBUF = 12,
    _PC_FILESIZEBITS = 13,
    _PC_REC_INCR_XFER_SIZE = 14,
    _PC_REC_MAX_XFER_SIZE = 15,
    _PC_REC_MIN_XFER_SIZE = 16,
    _PC_REC_XFER_ALIGN = 17,
    _PC_ALLOC_SIZE_MIN = 18,
    _PC_SYMLINK_MAX = 19,
    _PC_2_SYMLINKS = 20
} ;
enum __anonenum_27 {
    _SC_ARG_MAX = 0,
    _SC_CHILD_MAX = 1,
    _SC_CLK_TCK = 2,
    _SC_NGROUPS_MAX = 3,
    _SC_OPEN_MAX = 4,
    _SC_STREAM_MAX = 5,
    _SC_TZNAME_MAX = 6,
    _SC_JOB_CONTROL = 7,
    _SC_SAVED_IDS = 8,
    _SC_REALTIME_SIGNALS = 9,
    _SC_PRIORITY_SCHEDULING = 10,
    _SC_TIMERS = 11,
    _SC_ASYNCHRONOUS_IO = 12,
    _SC_PRIORITIZED_IO = 13,
    _SC_SYNCHRONIZED_IO = 14,
    _SC_FSYNC = 15,
    _SC_MAPPED_FILES = 16,
    _SC_MEMLOCK = 17,
    _SC_MEMLOCK_RANGE = 18,
    _SC_MEMORY_PROTECTION = 19,
    _SC_MESSAGE_PASSING = 20,
    _SC_SEMAPHORES = 21,
    _SC_SHARED_MEMORY_OBJECTS = 22,
    _SC_AIO_LISTIO_MAX = 23,
    _SC_AIO_MAX = 24,
    _SC_AIO_PRIO_DELTA_MAX = 25,
    _SC_DELAYTIMER_MAX = 26,
    _SC_MQ_OPEN_MAX = 27,
    _SC_MQ_PRIO_MAX = 28,
    _SC_VERSION = 29,
    _SC_PAGESIZE = 30,
    _SC_RTSIG_MAX = 31,
    _SC_SEM_NSEMS_MAX = 32,
    _SC_SEM_VALUE_MAX = 33,
    _SC_SIGQUEUE_MAX = 34,
    _SC_TIMER_MAX = 35,
    _SC_BC_BASE_MAX = 36,
    _SC_BC_DIM_MAX = 37,
    _SC_BC_SCALE_MAX = 38,
    _SC_BC_STRING_MAX = 39,
    _SC_COLL_WEIGHTS_MAX = 40,
    _SC_EQUIV_CLASS_MAX = 41,
    _SC_EXPR_NEST_MAX = 42,
    _SC_LINE_MAX = 43,
    _SC_RE_DUP_MAX = 44,
    _SC_CHARCLASS_NAME_MAX = 45,
    _SC_2_VERSION = 46,
    _SC_2_C_BIND = 47,
    _SC_2_C_DEV = 48,
    _SC_2_FORT_DEV = 49,
    _SC_2_FORT_RUN = 50,
    _SC_2_SW_DEV = 51,
    _SC_2_LOCALEDEF = 52,
    _SC_PII = 53,
    _SC_PII_XTI = 54,
    _SC_PII_SOCKET = 55,
    _SC_PII_INTERNET = 56,
    _SC_PII_OSI = 57,
    _SC_POLL = 58,
    _SC_SELECT = 59,
    _SC_UIO_MAXIOV = 60,
    _SC_IOV_MAX = 60,
    _SC_PII_INTERNET_STREAM = 61,
    _SC_PII_INTERNET_DGRAM = 62,
    _SC_PII_OSI_COTS = 63,
    _SC_PII_OSI_CLTS = 64,
    _SC_PII_OSI_M = 65,
    _SC_T_IOV_MAX = 66,
    _SC_THREADS = 67,
    _SC_THREAD_SAFE_FUNCTIONS = 68,
    _SC_GETGR_R_SIZE_MAX = 69,
    _SC_GETPW_R_SIZE_MAX = 70,
    _SC_LOGIN_NAME_MAX = 71,
    _SC_TTY_NAME_MAX = 72,
    _SC_THREAD_DESTRUCTOR_ITERATIONS = 73,
    _SC_THREAD_KEYS_MAX = 74,
    _SC_THREAD_STACK_MIN = 75,
    _SC_THREAD_THREADS_MAX = 76,
    _SC_THREAD_ATTR_STACKADDR = 77,
    _SC_THREAD_ATTR_STACKSIZE = 78,
    _SC_THREAD_PRIORITY_SCHEDULING = 79,
    _SC_THREAD_PRIO_INHERIT = 80,
    _SC_THREAD_PRIO_PROTECT = 81,
    _SC_THREAD_PROCESS_SHARED = 82,
    _SC_NPROCESSORS_CONF = 83,
    _SC_NPROCESSORS_ONLN = 84,
    _SC_PHYS_PAGES = 85,
    _SC_AVPHYS_PAGES = 86,
    _SC_ATEXIT_MAX = 87,
    _SC_PASS_MAX = 88,
    _SC_XOPEN_VERSION = 89,
    _SC_XOPEN_XCU_VERSION = 90,
    _SC_XOPEN_UNIX = 91,
    _SC_XOPEN_CRYPT = 92,
    _SC_XOPEN_ENH_I18N = 93,
    _SC_XOPEN_SHM = 94,
    _SC_2_CHAR_TERM = 95,
    _SC_2_C_VERSION = 96,
    _SC_2_UPE = 97,
    _SC_XOPEN_XPG2 = 98,
    _SC_XOPEN_XPG3 = 99,
    _SC_XOPEN_XPG4 = 100,
    _SC_CHAR_BIT = 101,
    _SC_CHAR_MAX = 102,
    _SC_CHAR_MIN = 103,
    _SC_INT_MAX = 104,
    _SC_INT_MIN = 105,
    _SC_LONG_BIT = 106,
    _SC_WORD_BIT = 107,
    _SC_MB_LEN_MAX = 108,
    _SC_NZERO = 109,
    _SC_SSIZE_MAX = 110,
    _SC_SCHAR_MAX = 111,
    _SC_SCHAR_MIN = 112,
    _SC_SHRT_MAX = 113,
    _SC_SHRT_MIN = 114,
    _SC_UCHAR_MAX = 115,
    _SC_UINT_MAX = 116,
    _SC_ULONG_MAX = 117,
    _SC_USHRT_MAX = 118,
    _SC_NL_ARGMAX = 119,
    _SC_NL_LANGMAX = 120,
    _SC_NL_MSGMAX = 121,
    _SC_NL_NMAX = 122,
    _SC_NL_SETMAX = 123,
    _SC_NL_TEXTMAX = 124,
    _SC_XBS5_ILP32_OFF32 = 125,
    _SC_XBS5_ILP32_OFFBIG = 126,
    _SC_XBS5_LP64_OFF64 = 127,
    _SC_XBS5_LPBIG_OFFBIG = 128,
    _SC_XOPEN_LEGACY = 129,
    _SC_XOPEN_REALTIME = 130,
    _SC_XOPEN_REALTIME_THREADS = 131,
    _SC_ADVISORY_INFO = 132,
    _SC_BARRIERS = 133,
    _SC_BASE = 134,
    _SC_C_LANG_SUPPORT = 135,
    _SC_C_LANG_SUPPORT_R = 136,
    _SC_CLOCK_SELECTION = 137,
    _SC_CPUTIME = 138,
    _SC_THREAD_CPUTIME = 139,
    _SC_DEVICE_IO = 140,
    _SC_DEVICE_SPECIFIC = 141,
    _SC_DEVICE_SPECIFIC_R = 142,
    _SC_FD_MGMT = 143,
    _SC_FIFO = 144,
    _SC_PIPE = 145,
    _SC_FILE_ATTRIBUTES = 146,
    _SC_FILE_LOCKING = 147,
    _SC_FILE_SYSTEM = 148,
    _SC_MONOTONIC_CLOCK = 149,
    _SC_MULTI_PROCESS = 150,
    _SC_SINGLE_PROCESS = 151,
    _SC_NETWORKING = 152,
    _SC_READER_WRITER_LOCKS = 153,
    _SC_SPIN_LOCKS = 154,
    _SC_REGEXP = 155,
    _SC_REGEX_VERSION = 156,
    _SC_SHELL = 157,
    _SC_SIGNALS = 158,
    _SC_SPAWN = 159,
    _SC_SPORADIC_SERVER = 160,
    _SC_THREAD_SPORADIC_SERVER = 161,
    _SC_SYSTEM_DATABASE = 162,
    _SC_SYSTEM_DATABASE_R = 163,
    _SC_TIMEOUTS = 164,
    _SC_TYPED_MEMORY_OBJECTS = 165,
    _SC_USER_GROUPS = 166,
    _SC_USER_GROUPS_R = 167,
    _SC_2_PBS = 168,
    _SC_2_PBS_ACCOUNTING = 169,
    _SC_2_PBS_LOCATE = 170,
    _SC_2_PBS_MESSAGE = 171,
    _SC_2_PBS_TRACK = 172,
    _SC_SYMLOOP_MAX = 173,
    _SC_STREAMS = 174,
    _SC_2_PBS_CHECKPOINT = 175,
    _SC_V6_ILP32_OFF32 = 176,
    _SC_V6_ILP32_OFFBIG = 177,
    _SC_V6_LP64_OFF64 = 178,
    _SC_V6_LPBIG_OFFBIG = 179,
    _SC_HOST_NAME_MAX = 180,
    _SC_TRACE = 181,
    _SC_TRACE_EVENT_FILTER = 182,
    _SC_TRACE_INHERIT = 183,
    _SC_TRACE_LOG = 184,
    _SC_LEVEL1_ICACHE_SIZE = 185,
    _SC_LEVEL1_ICACHE_ASSOC = 186,
    _SC_LEVEL1_ICACHE_LINESIZE = 187,
    _SC_LEVEL1_DCACHE_SIZE = 188,
    _SC_LEVEL1_DCACHE_ASSOC = 189,
    _SC_LEVEL1_DCACHE_LINESIZE = 190,
    _SC_LEVEL2_CACHE_SIZE = 191,
    _SC_LEVEL2_CACHE_ASSOC = 192,
    _SC_LEVEL2_CACHE_LINESIZE = 193,
    _SC_LEVEL3_CACHE_SIZE = 194,
    _SC_LEVEL3_CACHE_ASSOC = 195,
    _SC_LEVEL3_CACHE_LINESIZE = 196,
    _SC_LEVEL4_CACHE_SIZE = 197,
    _SC_LEVEL4_CACHE_ASSOC = 198,
    _SC_LEVEL4_CACHE_LINESIZE = 199,
    _SC_IPV6 = 235,
    _SC_RAW_SOCKETS = 236,
    _SC_V7_ILP32_OFF32 = 237,
    _SC_V7_ILP32_OFFBIG = 238,
    _SC_V7_LP64_OFF64 = 239,
    _SC_V7_LPBIG_OFFBIG = 240,
    _SC_SS_REPL_MAX = 241,
    _SC_TRACE_EVENT_NAME_MAX = 242,
    _SC_TRACE_NAME_MAX = 243,
    _SC_TRACE_SYS_MAX = 244,
    _SC_TRACE_USER_EVENT_MAX = 245,
    _SC_XOPEN_STREAMS = 246,
    _SC_THREAD_ROBUST_PRIO_INHERIT = 247,
    _SC_THREAD_ROBUST_PRIO_PROTECT = 248
} ;
enum __anonenum_28 {
    _CS_PATH = 0,
    _CS_V6_WIDTH_RESTRICTED_ENVS = 1,
    _CS_GNU_LIBC_VERSION = 2,
    _CS_GNU_LIBPTHREAD_VERSION = 3,
    _CS_V5_WIDTH_RESTRICTED_ENVS = 4,
    _CS_V7_WIDTH_RESTRICTED_ENVS = 5,
    _CS_LFS_CFLAGS = 1000,
    _CS_LFS_LDFLAGS = 1001,
    _CS_LFS_LIBS = 1002,
    _CS_LFS_LINTFLAGS = 1003,
    _CS_LFS64_CFLAGS = 1004,
    _CS_LFS64_LDFLAGS = 1005,
    _CS_LFS64_LIBS = 1006,
    _CS_LFS64_LINTFLAGS = 1007,
    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,
    _CS_XBS5_ILP32_OFF32_LDFLAGS = 1101,
    _CS_XBS5_ILP32_OFF32_LIBS = 1102,
    _CS_XBS5_ILP32_OFF32_LINTFLAGS = 1103,
    _CS_XBS5_ILP32_OFFBIG_CFLAGS = 1104,
    _CS_XBS5_ILP32_OFFBIG_LDFLAGS = 1105,
    _CS_XBS5_ILP32_OFFBIG_LIBS = 1106,
    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS = 1107,
    _CS_XBS5_LP64_OFF64_CFLAGS = 1108,
    _CS_XBS5_LP64_OFF64_LDFLAGS = 1109,
    _CS_XBS5_LP64_OFF64_LIBS = 1110,
    _CS_XBS5_LP64_OFF64_LINTFLAGS = 1111,
    _CS_XBS5_LPBIG_OFFBIG_CFLAGS = 1112,
    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS = 1113,
    _CS_XBS5_LPBIG_OFFBIG_LIBS = 1114,
    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS = 1115,
    _CS_POSIX_V6_ILP32_OFF32_CFLAGS = 1116,
    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS = 1117,
    _CS_POSIX_V6_ILP32_OFF32_LIBS = 1118,
    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS = 1119,
    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS = 1120,
    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS = 1121,
    _CS_POSIX_V6_ILP32_OFFBIG_LIBS = 1122,
    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS = 1123,
    _CS_POSIX_V6_LP64_OFF64_CFLAGS = 1124,
    _CS_POSIX_V6_LP64_OFF64_LDFLAGS = 1125,
    _CS_POSIX_V6_LP64_OFF64_LIBS = 1126,
    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS = 1127,
    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS = 1128,
    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS = 1129,
    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS = 1130,
    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS = 1131,
    _CS_POSIX_V7_ILP32_OFF32_CFLAGS = 1132,
    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS = 1133,
    _CS_POSIX_V7_ILP32_OFF32_LIBS = 1134,
    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS = 1135,
    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS = 1136,
    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS = 1137,
    _CS_POSIX_V7_ILP32_OFFBIG_LIBS = 1138,
    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS = 1139,
    _CS_POSIX_V7_LP64_OFF64_CFLAGS = 1140,
    _CS_POSIX_V7_LP64_OFF64_LDFLAGS = 1141,
    _CS_POSIX_V7_LP64_OFF64_LIBS = 1142,
    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS = 1143,
    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS = 1144,
    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS = 1145,
    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS = 1146,
    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS = 1147,
    _CS_V6_ENV = 1148,
    _CS_V7_ENV = 1149
} ;
struct flock {
   short l_type ;
   short l_whence ;
   __off64_t l_start ;
   __off64_t l_len ;
   __pid_t l_pid ;
};
struct stat {
   __dev_t st_dev ;
   unsigned short __pad1 ;
   __ino_t __st_ino ;
   __mode_t st_mode ;
   __nlink_t st_nlink ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   __dev_t st_rdev ;
   unsigned short __pad2 ;
   __off64_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt64_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __ino64_t st_ino ;
};
enum __anonenum_ACTION_29 {
    FIND = 0,
    ENTER = 1
} ;
typedef enum __anonenum_ACTION_29 ACTION;
struct entry {
   char *key ;
   void *data ;
};
typedef struct entry ENTRY;
struct _ENTRY;
struct _ENTRY;
enum __anonenum_VISIT_30 {
    preorder = 0,
    postorder = 1,
    endorder = 2,
    leaf = 3
} ;
typedef enum __anonenum_VISIT_30 VISIT;
typedef void (*__action_fn_t)(void const   *__nodep , VISIT __value ,
                              int __level );
typedef signed char int8;
typedef unsigned char uint8;
typedef short int16;
typedef unsigned short uint16;
typedef int int32;
typedef unsigned int uint32;
typedef long long int64;
typedef unsigned long long uint64;
typedef int uint16_vap;
struct __anonstruct_TIFFHeaderCommon_31 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
};
typedef struct __anonstruct_TIFFHeaderCommon_31 TIFFHeaderCommon;
struct __anonstruct_TIFFHeaderClassic_32 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint32 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderClassic_32 TIFFHeaderClassic;
struct __anonstruct_TIFFHeaderBig_33 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint16 tiff_offsetsize ;
   uint16 tiff_unused ;
   uint64 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderBig_33 TIFFHeaderBig;
enum __anonenum_TIFFDataType_34 {
    TIFF_NOTYPE = 0,
    TIFF_BYTE = 1,
    TIFF_ASCII = 2,
    TIFF_SHORT = 3,
    TIFF_LONG = 4,
    TIFF_RATIONAL = 5,
    TIFF_SBYTE = 6,
    TIFF_UNDEFINED = 7,
    TIFF_SSHORT = 8,
    TIFF_SLONG = 9,
    TIFF_SRATIONAL = 10,
    TIFF_FLOAT = 11,
    TIFF_DOUBLE = 12,
    TIFF_IFD = 13,
    TIFF_LONG8 = 16,
    TIFF_SLONG8 = 17,
    TIFF_IFD8 = 18
} ;
typedef enum __anonenum_TIFFDataType_34 TIFFDataType;
struct tiff;
typedef struct tiff TIFF;
typedef long tmsize_t;
typedef uint64 toff_t;
typedef uint32 ttag_t;
typedef uint16 tdir_t;
typedef uint16 tsample_t;
typedef uint32 tstrile_t;
typedef tstrile_t tstrip_t;
typedef tstrile_t ttile_t;
typedef tmsize_t tsize_t;
typedef void *tdata_t;
typedef void *thandle_t;
typedef unsigned char TIFFRGBValue;
struct __anonstruct_TIFFDisplay_35 {
   float d_mat[3][3] ;
   float d_YCR ;
   float d_YCG ;
   float d_YCB ;
   uint32 d_Vrwr ;
   uint32 d_Vrwg ;
   uint32 d_Vrwb ;
   float d_Y0R ;
   float d_Y0G ;
   float d_Y0B ;
   float d_gammaR ;
   float d_gammaG ;
   float d_gammaB ;
};
typedef struct __anonstruct_TIFFDisplay_35 TIFFDisplay;
struct __anonstruct_TIFFYCbCrToRGB_36 {
   TIFFRGBValue *clamptab ;
   int *Cr_r_tab ;
   int *Cb_b_tab ;
   int32 *Cr_g_tab ;
   int32 *Cb_g_tab ;
   int32 *Y_tab ;
};
typedef struct __anonstruct_TIFFYCbCrToRGB_36 TIFFYCbCrToRGB;
struct __anonstruct_TIFFCIELabToRGB_37 {
   int range ;
   float rstep ;
   float gstep ;
   float bstep ;
   float X0 ;
   float Y0 ;
   float Z0 ;
   TIFFDisplay display ;
   float Yr2r[1501] ;
   float Yg2g[1501] ;
   float Yb2b[1501] ;
};
typedef struct __anonstruct_TIFFCIELabToRGB_37 TIFFCIELabToRGB;
struct _TIFFRGBAImage;
typedef struct _TIFFRGBAImage TIFFRGBAImage;
typedef void (*tileContigRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                  uint32  , uint32  , uint32  , int32  ,
                                  int32  , unsigned char * );
typedef void (*tileSeparateRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                    uint32  , uint32  , uint32  , int32  ,
                                    int32  , unsigned char * , unsigned char * ,
                                    unsigned char * , unsigned char * );
union __anonunion_put_38 {
   void (*any)(TIFFRGBAImage * ) ;
   void (*contig)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                  uint32  , int32  , int32  , unsigned char * ) ;
   void (*separate)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                    uint32  , int32  , int32  , unsigned char * ,
                    unsigned char * , unsigned char * , unsigned char * ) ;
};
struct _TIFFRGBAImage {
   TIFF *tif ;
   int stoponerr ;
   int isContig ;
   int alpha ;
   uint32 width ;
   uint32 height ;
   uint16 bitspersample ;
   uint16 samplesperpixel ;
   uint16 orientation ;
   uint16 req_orientation ;
   uint16 photometric ;
   uint16 *redcmap ;
   uint16 *greencmap ;
   uint16 *bluecmap ;
   int (*get)(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
   union __anonunion_put_38 put ;
   TIFFRGBValue *Map ;
   uint32 **BWmap ;
   uint32 **PALmap ;
   TIFFYCbCrToRGB *ycbcr ;
   TIFFCIELabToRGB *cielab ;
   uint8 *UaToAa ;
   uint8 *Bitdepth16To8 ;
   int row_offset ;
   int col_offset ;
};
typedef int (*TIFFInitMethod)(TIFF * , int  );
struct __anonstruct_TIFFCodec_39 {
   char *name ;
   uint16 scheme ;
   int (*init)(TIFF * , int  ) ;
};
typedef struct __anonstruct_TIFFCodec_39 TIFFCodec;
typedef void (*TIFFErrorHandler)(char const   * , char const   * , va_list  );
typedef void (*TIFFErrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  );
typedef tmsize_t (*TIFFReadWriteProc)(thandle_t  , void * , tmsize_t  );
typedef toff_t (*TIFFSeekProc)(thandle_t  , toff_t  , int  );
typedef int (*TIFFCloseProc)(thandle_t  );
typedef toff_t (*TIFFSizeProc)(thandle_t  );
typedef int (*TIFFMapFileProc)(thandle_t  , void **base , toff_t *size );
typedef void (*TIFFUnmapFileProc)(thandle_t  , void *base , toff_t size );
typedef void (*TIFFExtendProc)(TIFF * );
struct _TIFFField;
typedef struct _TIFFField TIFFField;
struct _TIFFFieldArray;
typedef struct _TIFFFieldArray TIFFFieldArray;
typedef int (*TIFFVSetMethod)(TIFF * , uint32  , va_list  );
typedef int (*TIFFVGetMethod)(TIFF * , uint32  , va_list  );
typedef void (*TIFFPrintMethod)(TIFF * , FILE * , long  );
struct __anonstruct_TIFFTagMethods_40 {
   int (*vsetfield)(TIFF * , uint32  , va_list  ) ;
   int (*vgetfield)(TIFF * , uint32  , va_list  ) ;
   void (*printdir)(TIFF * , FILE * , long  ) ;
};
typedef struct __anonstruct_TIFFTagMethods_40 TIFFTagMethods;
struct __anonstruct_TIFFFieldInfo_41 {
   ttag_t field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
};
typedef struct __anonstruct_TIFFFieldInfo_41 TIFFFieldInfo;
struct __anonstruct_TIFFTagValue_42 {
   TIFFField const   *info ;
   int count ;
   void *value ;
};
typedef struct __anonstruct_TIFFTagValue_42 TIFFTagValue;
struct __anonstruct_TIFFDirectory_43 {
   unsigned long td_fieldsset[4] ;
   uint32 td_imagewidth ;
   uint32 td_imagelength ;
   uint32 td_imagedepth ;
   uint32 td_tilewidth ;
   uint32 td_tilelength ;
   uint32 td_tiledepth ;
   uint32 td_subfiletype ;
   uint16 td_bitspersample ;
   uint16 td_sampleformat ;
   uint16 td_compression ;
   uint16 td_photometric ;
   uint16 td_threshholding ;
   uint16 td_fillorder ;
   uint16 td_orientation ;
   uint16 td_samplesperpixel ;
   uint32 td_rowsperstrip ;
   uint16 td_minsamplevalue ;
   uint16 td_maxsamplevalue ;
   double td_sminsamplevalue ;
   double td_smaxsamplevalue ;
   float td_xresolution ;
   float td_yresolution ;
   uint16 td_resolutionunit ;
   uint16 td_planarconfig ;
   float td_xposition ;
   float td_yposition ;
   uint16 td_pagenumber[2] ;
   uint16 *td_colormap[3] ;
   uint16 td_halftonehints[2] ;
   uint16 td_extrasamples ;
   uint16 *td_sampleinfo ;
   uint32 td_stripsperimage ;
   uint32 td_nstrips ;
   uint64 *td_stripoffset ;
   uint64 *td_stripbytecount ;
   int td_stripbytecountsorted ;
   uint16 td_nsubifd ;
   uint64 *td_subifd ;
   uint16 td_ycbcrsubsampling[2] ;
   uint16 td_ycbcrpositioning ;
   uint16 *td_transferfunction[3] ;
   int td_inknameslen ;
   char *td_inknames ;
   int td_customValueCount ;
   TIFFTagValue *td_customValues ;
};
typedef struct __anonstruct_TIFFDirectory_43 TIFFDirectory;
enum __anonenum_TIFFSetGetFieldType_44 {
    TIFF_SETGET_UNDEFINED = 0,
    TIFF_SETGET_ASCII = 1,
    TIFF_SETGET_UINT8 = 2,
    TIFF_SETGET_SINT8 = 3,
    TIFF_SETGET_UINT16 = 4,
    TIFF_SETGET_SINT16 = 5,
    TIFF_SETGET_UINT32 = 6,
    TIFF_SETGET_SINT32 = 7,
    TIFF_SETGET_UINT64 = 8,
    TIFF_SETGET_SINT64 = 9,
    TIFF_SETGET_FLOAT = 10,
    TIFF_SETGET_DOUBLE = 11,
    TIFF_SETGET_IFD8 = 12,
    TIFF_SETGET_INT = 13,
    TIFF_SETGET_UINT16_PAIR = 14,
    TIFF_SETGET_C0_ASCII = 15,
    TIFF_SETGET_C0_UINT8 = 16,
    TIFF_SETGET_C0_SINT8 = 17,
    TIFF_SETGET_C0_UINT16 = 18,
    TIFF_SETGET_C0_SINT16 = 19,
    TIFF_SETGET_C0_UINT32 = 20,
    TIFF_SETGET_C0_SINT32 = 21,
    TIFF_SETGET_C0_UINT64 = 22,
    TIFF_SETGET_C0_SINT64 = 23,
    TIFF_SETGET_C0_FLOAT = 24,
    TIFF_SETGET_C0_DOUBLE = 25,
    TIFF_SETGET_C0_IFD8 = 26,
    TIFF_SETGET_C16_ASCII = 27,
    TIFF_SETGET_C16_UINT8 = 28,
    TIFF_SETGET_C16_SINT8 = 29,
    TIFF_SETGET_C16_UINT16 = 30,
    TIFF_SETGET_C16_SINT16 = 31,
    TIFF_SETGET_C16_UINT32 = 32,
    TIFF_SETGET_C16_SINT32 = 33,
    TIFF_SETGET_C16_UINT64 = 34,
    TIFF_SETGET_C16_SINT64 = 35,
    TIFF_SETGET_C16_FLOAT = 36,
    TIFF_SETGET_C16_DOUBLE = 37,
    TIFF_SETGET_C16_IFD8 = 38,
    TIFF_SETGET_C32_ASCII = 39,
    TIFF_SETGET_C32_UINT8 = 40,
    TIFF_SETGET_C32_SINT8 = 41,
    TIFF_SETGET_C32_UINT16 = 42,
    TIFF_SETGET_C32_SINT16 = 43,
    TIFF_SETGET_C32_UINT32 = 44,
    TIFF_SETGET_C32_SINT32 = 45,
    TIFF_SETGET_C32_UINT64 = 46,
    TIFF_SETGET_C32_SINT64 = 47,
    TIFF_SETGET_C32_FLOAT = 48,
    TIFF_SETGET_C32_DOUBLE = 49,
    TIFF_SETGET_C32_IFD8 = 50,
    TIFF_SETGET_OTHER = 51
} ;
typedef enum __anonenum_TIFFSetGetFieldType_44 TIFFSetGetFieldType;
enum __anonenum_TIFFFieldArrayType_45 {
    tfiatImage = 0,
    tfiatExif = 1,
    tfiatOther = 2
} ;
typedef enum __anonenum_TIFFFieldArrayType_45 TIFFFieldArrayType;
struct _TIFFFieldArray {
   TIFFFieldArrayType type ;
   uint32 allocated_size ;
   uint32 count ;
   TIFFField *fields ;
};
struct _TIFFField {
   uint32 field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   uint32 reserved ;
   TIFFSetGetFieldType set_field_type ;
   TIFFSetGetFieldType get_field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
   TIFFFieldArray *field_subfields ;
};
union __anonunion_tdir_offset_47 {
   uint16 toff_short ;
   uint32 toff_long ;
   uint64 toff_long8 ;
};
struct __anonstruct_TIFFDirEntry_46 {
   uint16 tdir_tag ;
   uint16 tdir_type ;
   uint64 tdir_count ;
   union __anonunion_tdir_offset_47 tdir_offset ;
};
typedef struct __anonstruct_TIFFDirEntry_46 TIFFDirEntry;
struct client_info {
   struct client_info *next ;
   void *data ;
   char *name ;
};
typedef struct client_info TIFFClientInfoLink;
typedef unsigned char tidataval_t;
typedef tidataval_t *tidata_t;
typedef void (*TIFFVoidMethod)(TIFF * );
typedef int (*TIFFBoolMethod)(TIFF * );
typedef int (*TIFFPreMethod)(TIFF * , uint16  );
typedef int (*TIFFCodeMethod)(TIFF *tif , uint8 *buf , tmsize_t size ,
                              uint16 sample );
typedef int (*TIFFSeekMethod)(TIFF * , uint32  );
typedef void (*TIFFPostMethod)(TIFF *tif , uint8 *buf , tmsize_t size );
typedef uint32 (*TIFFStripMethod)(TIFF * , uint32  );
typedef void (*TIFFTileMethod)(TIFF * , uint32 * , uint32 * );
union __anonunion_tif_header_48 {
   TIFFHeaderCommon common ;
   TIFFHeaderClassic classic ;
   TIFFHeaderBig big ;
};
struct tiff {
   char *tif_name ;
   int tif_fd ;
   int tif_mode ;
   uint32 tif_flags ;
   uint64 tif_diroff ;
   uint64 tif_nextdiroff ;
   uint64 *tif_dirlist ;
   uint16 tif_dirlistsize ;
   uint16 tif_dirnumber ;
   TIFFDirectory tif_dir ;
   TIFFDirectory tif_customdir ;
   union __anonunion_tif_header_48 tif_header ;
   uint16 tif_header_size ;
   uint32 tif_row ;
   uint16 tif_curdir ;
   uint32 tif_curstrip ;
   uint64 tif_curoff ;
   uint64 tif_dataoff ;
   uint16 tif_nsubifd ;
   uint64 tif_subifdoff ;
   uint32 tif_col ;
   uint32 tif_curtile ;
   tmsize_t tif_tilesize ;
   int tif_decodestatus ;
   int (*tif_fixuptags)(TIFF * ) ;
   int (*tif_setupdecode)(TIFF * ) ;
   int (*tif_predecode)(TIFF * , uint16  ) ;
   int (*tif_setupencode)(TIFF * ) ;
   int tif_encodestatus ;
   int (*tif_preencode)(TIFF * , uint16  ) ;
   int (*tif_postencode)(TIFF * ) ;
   int (*tif_decoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_decodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_encodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_decodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   void (*tif_close)(TIFF * ) ;
   int (*tif_seek)(TIFF * , uint32  ) ;
   void (*tif_cleanup)(TIFF * ) ;
   uint32 (*tif_defstripsize)(TIFF * , uint32  ) ;
   void (*tif_deftilesize)(TIFF * , uint32 * , uint32 * ) ;
   uint8 *tif_data ;
   tmsize_t tif_scanlinesize ;
   tmsize_t tif_scanlineskew ;
   uint8 *tif_rawdata ;
   tmsize_t tif_rawdatasize ;
   uint8 *tif_rawcp ;
   tmsize_t tif_rawcc ;
   uint8 *tif_base ;
   tmsize_t tif_size ;
   int (*tif_mapproc)(thandle_t  , void **base , toff_t *size ) ;
   void (*tif_unmapproc)(thandle_t  , void *base , toff_t size ) ;
   thandle_t tif_clientdata ;
   tmsize_t (*tif_readproc)(thandle_t  , void * , tmsize_t  ) ;
   tmsize_t (*tif_writeproc)(thandle_t  , void * , tmsize_t  ) ;
   toff_t (*tif_seekproc)(thandle_t  , toff_t  , int  ) ;
   int (*tif_closeproc)(thandle_t  ) ;
   toff_t (*tif_sizeproc)(thandle_t  ) ;
   void (*tif_postdecode)(TIFF *tif , uint8 *buf , tmsize_t size ) ;
   TIFFField **tif_fields ;
   size_t tif_nfields ;
   TIFFField const   *tif_foundfield ;
   TIFFTagMethods tif_tagmethods ;
   TIFFClientInfoLink *tif_clientinfo ;
   TIFFFieldArray *tif_fieldscompat ;
   size_t tif_nfieldscompat ;
};
extern struct _IO_FILE_plus _IO_2_1_stdin_ ;
extern struct _IO_FILE_plus _IO_2_1_stdout_ ;
extern struct _IO_FILE_plus _IO_2_1_stderr_ ;
extern int __underflow(_IO_FILE * ) ;
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_feof(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_ferror(_IO_FILE *__fp ) ;
extern int _IO_peekc_locked(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) void _IO_flockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) void _IO_funlockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) int _IO_ftrylockfile(_IO_FILE * ) ;
extern int _IO_vfscanf(_IO_FILE * __restrict   , char const   * __restrict   ,
                       __gnuc_va_list  , int * __restrict   ) ;
extern int _IO_vfprintf(_IO_FILE * __restrict   , char const   * __restrict   ,
                        __gnuc_va_list  ) ;
extern __ssize_t _IO_padn(_IO_FILE * , int  , __ssize_t  ) ;
extern size_t _IO_sgetn(_IO_FILE * , void * , size_t  ) ;
extern __off64_t _IO_seekoff(_IO_FILE * , __off64_t  , int  , int  ) ;
extern __off64_t _IO_seekpos(_IO_FILE * , __off64_t  , int  ) ;
extern  __attribute__((__nothrow__)) void _IO_free_backup_area(_IO_FILE * ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
extern  __attribute__((__nothrow__)) int remove(char const   *__filename ) ;
extern  __attribute__((__nothrow__)) int rename(char const   *__old ,
                                                char const   *__new ) ;
extern  __attribute__((__nothrow__)) int renameat(int __oldfd ,
                                                  char const   *__old ,
                                                  int __newfd ,
                                                  char const   *__new ) ;
extern FILE *tmpfile(void)  __asm__("tmpfile64")  ;
extern  __attribute__((__nothrow__)) char *tmpnam(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tmpnam_r(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tempnam(char const   *__dir ,
                                                   char const   *__pfx )  __attribute__((__malloc__)) ;
extern int fclose(FILE *__stream ) ;
extern int fflush(FILE *__stream ) ;
extern int fflush_unlocked(FILE *__stream ) ;
extern FILE *freopen(char const   * __restrict  __filename ,
                     char const   * __restrict  __modes ,
                     FILE * __restrict  __stream )  __asm__("freopen64")  ;
extern  __attribute__((__nothrow__)) FILE *fdopen(int __fd ,
                                                  char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *fmemopen(void *__s , size_t __len ,
                                                    char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *open_memstream(char **__bufloc ,
                                                          size_t *__sizeloc ) ;
extern  __attribute__((__nothrow__)) void setbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) int setvbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ,
                                                 int __modes , size_t __n ) ;
extern  __attribute__((__nothrow__)) void setbuffer(FILE * __restrict  __stream ,
                                                    char * __restrict  __buf ,
                                                    size_t __size ) ;
extern  __attribute__((__nothrow__)) void setlinebuf(FILE *__stream ) ;
extern int fprintf(FILE * __restrict  __stream ,
                   char const   * __restrict  __format  , ...) ;
extern int printf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sprintf(char * __restrict  __s ,
                                                 char const   * __restrict  __format 
                                                 , ...) ;
extern int vfprintf(FILE * __restrict  __s ,
                    char const   * __restrict  __format , __gnuc_va_list __arg ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vsprintf(char * __restrict  __s ,
                                                  char const   * __restrict  __format ,
                                                  __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  snprintf)(char * __restrict  __s ,
                                                                             size_t __maxlen ,
                                                                             char const   * __restrict  __format 
                                                                             , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsnprintf)(char * __restrict  __s ,
                                                                              size_t __maxlen ,
                                                                              char const   * __restrict  __format ,
                                                                              __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  vdprintf)(int __fd ,
                                               char const   * __restrict  __fmt ,
                                               __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  dprintf)(int __fd ,
                                              char const   * __restrict  __fmt 
                                              , ...) ;
extern int fscanf(FILE * __restrict  __stream ,
                  char const   * __restrict  __format  , ...)  __asm__("__isoc99_fscanf")  ;
extern int scanf(char const   * __restrict  __format  , ...)  __asm__("__isoc99_scanf")  ;
extern  __attribute__((__nothrow__)) int sscanf(char const   * __restrict  __s ,
                                                char const   * __restrict  __format 
                                                , ...)  __asm__("__isoc99_sscanf")  ;
extern int ( /* format attribute */  vfscanf)(FILE * __restrict  __s ,
                                              char const   * __restrict  __format ,
                                              __gnuc_va_list __arg )  __asm__("__isoc99_vfscanf")  ;
extern int ( /* format attribute */  vscanf)(char const   * __restrict  __format ,
                                             __gnuc_va_list __arg )  __asm__("__isoc99_vscanf")  ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsscanf)(char const   * __restrict  __s ,
                                                                            char const   * __restrict  __format ,
                                                                            __gnuc_va_list __arg )  __asm__("__isoc99_vsscanf")  ;
extern int fgetc(FILE *__stream ) ;
extern int getc(FILE *__stream ) ;
__inline extern int getchar(void) ;
__inline extern int getc_unlocked(FILE *__fp ) ;
__inline extern int getchar_unlocked(void) ;
__inline extern int fgetc_unlocked(FILE *__fp ) ;
extern int fputc(int __c , FILE *__stream ) ;
extern int putc(int __c , FILE *__stream ) ;
__inline extern int putchar(int __c ) ;
__inline extern int fputc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putchar_unlocked(int __c ) ;
extern int getw(FILE *__stream ) ;
extern int putw(int __w , FILE *__stream ) ;
extern char *fgets(char * __restrict  __s , int __n ,
                   FILE * __restrict  __stream ) ;
extern char *gets(char *__s ) ;
extern __ssize_t __getdelim(char ** __restrict  __lineptr ,
                            size_t * __restrict  __n , int __delimiter ,
                            FILE * __restrict  __stream ) ;
extern __ssize_t getdelim(char ** __restrict  __lineptr ,
                          size_t * __restrict  __n , int __delimiter ,
                          FILE * __restrict  __stream ) ;
extern __ssize_t getline(char ** __restrict  __lineptr ,
                         size_t * __restrict  __n , FILE * __restrict  __stream ) ;
extern int fputs(char const   * __restrict  __s , FILE * __restrict  __stream ) ;
extern int puts(char const   *__s ) ;
extern int ungetc(int __c , FILE *__stream ) ;
extern size_t fread(void * __restrict  __ptr , size_t __size , size_t __n ,
                    FILE * __restrict  __stream ) ;
extern size_t fwrite(void const   * __restrict  __ptr , size_t __size ,
                     size_t __n , FILE * __restrict  __s ) ;
extern size_t fread_unlocked(void * __restrict  __ptr , size_t __size ,
                             size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite_unlocked(void const   * __restrict  __ptr , size_t __size ,
                              size_t __n , FILE * __restrict  __stream ) ;
extern int fseek(FILE *__stream , long __off , int __whence ) ;
extern long ftell(FILE *__stream ) ;
extern void rewind(FILE *__stream ) ;
extern int fseeko(FILE *__stream , __off64_t __off , int __whence )  __asm__("fseeko64")  ;
extern __off64_t ftello(FILE *__stream )  __asm__("ftello64")  ;
extern int fgetpos(FILE * __restrict  __stream , fpos_t * __restrict  __pos )  __asm__("fgetpos64")  ;
extern int fsetpos(FILE *__stream , fpos_t const   *__pos )  __asm__("fsetpos64")  ;
extern  __attribute__((__nothrow__)) void clearerr(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int feof(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ferror(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void clearerr_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
extern void perror(char const   *__s ) ;
extern int sys_nerr ;
extern char const   * const  sys_errlist[] ;
extern  __attribute__((__nothrow__)) int fileno(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int fileno_unlocked(FILE *__stream ) ;
extern FILE *popen(char const   *__command , char const   *__modes ) ;
extern int pclose(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) char *ctermid(char *__s ) ;
extern  __attribute__((__nothrow__)) void flockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ftrylockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void funlockfile(FILE *__stream ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1\n");
  fflush(_coverage_fout);
  tmp = vfprintf((FILE */* __restrict  */)stdout, __fmt, __arg);
  fprintf(_coverage_fout, "2\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int getchar(void) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3\n");
  fflush(_coverage_fout);
  tmp = _IO_getc(stdin);
  fprintf(_coverage_fout, "4\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int fgetc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "10\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "11\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "5\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "6\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "7\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "8\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "9\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "12\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int getc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "18\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "19\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "13\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "14\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "15\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "16\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "17\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "20\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int getchar_unlocked(void) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "26\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )stdin->_IO_read_ptr >= (unsigned int )stdin->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "27\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "21\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(stdin);
    fprintf(_coverage_fout, "22\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "23\n");
    fflush(_coverage_fout);
    tmp___1 = stdin->_IO_read_ptr;
    fprintf(_coverage_fout, "24\n");
    fflush(_coverage_fout);
    (stdin->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "25\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "28\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int putchar(int __c ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "29\n");
  fflush(_coverage_fout);
  tmp = _IO_putc(__c, stdout);
  fprintf(_coverage_fout, "30\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int fputc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "38\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "39\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "31\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "32\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "33\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "34\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "35\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "36\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "37\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "40\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern int putc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "48\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "49\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "41\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "42\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "43\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "44\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "45\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "46\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "47\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "50\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern int putchar_unlocked(int __c ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "58\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )stdout->_IO_write_ptr >= (unsigned int )stdout->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "59\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "51\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "52\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "53\n");
    fflush(_coverage_fout);
    tmp___1 = stdout->_IO_write_ptr;
    fprintf(_coverage_fout, "54\n");
    fflush(_coverage_fout);
    (stdout->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "55\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "56\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "57\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "60\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern int feof_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "61\n");
  fflush(_coverage_fout);
  return ((__stream->_flags & 0x10) != 0);
}
}
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
__inline extern int ferror_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "62\n");
  fflush(_coverage_fout);
  return ((__stream->_flags & 0x20) != 0);
}
}
extern  __attribute__((__nothrow__)) size_t __ctype_get_mb_cur_max(void) ;
__inline extern  __attribute__((__nothrow__)) double atof(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) int atoi(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) long atol(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) long long atoll(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) double strtod(char const   * __restrict  __nptr ,
                                                   char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) float strtof(char const   * __restrict  __nptr ,
                                                  char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long double strtold(char const   * __restrict  __nptr ,
                                                         char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long strtol(char const   * __restrict  __nptr ,
                                                 char ** __restrict  __endptr ,
                                                 int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long strtoul(char const   * __restrict  __nptr ,
                                                           char ** __restrict  __endptr ,
                                                           int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long long strtoq(char const   * __restrict  __nptr ,
                                                      char ** __restrict  __endptr ,
                                                      int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long long strtouq(char const   * __restrict  __nptr ,
                                                                char ** __restrict  __endptr ,
                                                                int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long long strtoll(char const   * __restrict  __nptr ,
                                                       char ** __restrict  __endptr ,
                                                       int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long long strtoull(char const   * __restrict  __nptr ,
                                                                 char ** __restrict  __endptr ,
                                                                 int __base )  __attribute__((__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) double atof(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern double atof(char const   *__nptr ) 
{ double tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "63\n");
  fflush(_coverage_fout);
  tmp = strtod((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)));
  fprintf(_coverage_fout, "64\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int atoi(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern int atoi(char const   *__nptr ) 
{ long tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "65\n");
  fflush(_coverage_fout);
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  fprintf(_coverage_fout, "66\n");
  fflush(_coverage_fout);
  return ((int )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long atol(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern long atol(char const   *__nptr ) 
{ long tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "67\n");
  fflush(_coverage_fout);
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  fprintf(_coverage_fout, "68\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long long atoll(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern long long atoll(char const   *__nptr ) 
{ long long tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "69\n");
  fflush(_coverage_fout);
  tmp = strtoll((char const   */* __restrict  */)__nptr,
                (char **/* __restrict  */)((char **)((void *)0)), 10);
  fprintf(_coverage_fout, "70\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
extern  __attribute__((__nothrow__)) char *l64a(long __n ) ;
extern  __attribute__((__nothrow__)) long a64l(char const   *__s )  __attribute__((__pure__,
__nonnull__(1))) ;
extern int select(int __nfds , fd_set * __restrict  __readfds ,
                  fd_set * __restrict  __writefds ,
                  fd_set * __restrict  __exceptfds ,
                  struct timeval * __restrict  __timeout ) ;
extern int pselect(int __nfds , fd_set * __restrict  __readfds ,
                   fd_set * __restrict  __writefds ,
                   fd_set * __restrict  __exceptfds ,
                   struct timespec  const  * __restrict  __timeout ,
                   __sigset_t const   * __restrict  __sigmask ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_major(unsigned long long __dev ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "71\n");
  fflush(_coverage_fout);
  return ((unsigned int )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_minor(unsigned long long __dev ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "72\n");
  fflush(_coverage_fout);
  return ((unsigned int )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                   unsigned int __minor ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "73\n");
  fflush(_coverage_fout);
  return (((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32));
}
}
extern  __attribute__((__nothrow__)) long random(void) ;
extern  __attribute__((__nothrow__)) void srandom(unsigned int __seed ) ;
extern  __attribute__((__nothrow__)) char *initstate(unsigned int __seed ,
                                                     char *__statebuf ,
                                                     size_t __statelen )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *setstate(char *__statebuf )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int random_r(struct random_data * __restrict  __buf ,
                                                  int32_t * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int srandom_r(unsigned int __seed ,
                                                   struct random_data *__buf )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int initstate_r(unsigned int __seed ,
                                                     char * __restrict  __statebuf ,
                                                     size_t __statelen ,
                                                     struct random_data * __restrict  __buf )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) int setstate_r(char * __restrict  __statebuf ,
                                                    struct random_data * __restrict  __buf )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int rand(void) ;
extern  __attribute__((__nothrow__)) void srand(unsigned int __seed ) ;
extern  __attribute__((__nothrow__)) int rand_r(unsigned int *__seed ) ;
extern  __attribute__((__nothrow__)) double drand48(void) ;
extern  __attribute__((__nothrow__)) double erand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long lrand48(void) ;
extern  __attribute__((__nothrow__)) long nrand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long mrand48(void) ;
extern  __attribute__((__nothrow__)) long jrand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void srand48(long __seedval ) ;
extern  __attribute__((__nothrow__)) unsigned short *seed48(unsigned short *__seed16v )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void lcong48(unsigned short *__param )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int drand48_r(struct drand48_data * __restrict  __buffer ,
                                                   double * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int erand48_r(unsigned short *__xsubi ,
                                                   struct drand48_data * __restrict  __buffer ,
                                                   double * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int lrand48_r(struct drand48_data * __restrict  __buffer ,
                                                   long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int nrand48_r(unsigned short *__xsubi ,
                                                   struct drand48_data * __restrict  __buffer ,
                                                   long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int mrand48_r(struct drand48_data * __restrict  __buffer ,
                                                   long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int jrand48_r(unsigned short *__xsubi ,
                                                   struct drand48_data * __restrict  __buffer ,
                                                   long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int srand48_r(long __seedval ,
                                                   struct drand48_data *__buffer )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int seed48_r(unsigned short *__seed16v ,
                                                  struct drand48_data *__buffer )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int lcong48_r(unsigned short *__param ,
                                                   struct drand48_data *__buffer )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *malloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *calloc(size_t __nmemb ,
                                                  size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *realloc(void *__ptr , size_t __size )  __attribute__((__warn_unused_result__)) ;
extern  __attribute__((__nothrow__)) void free(void *__ptr ) ;
extern  __attribute__((__nothrow__)) void cfree(void *__ptr ) ;
extern  __attribute__((__nothrow__)) void *alloca(size_t __size ) ;
extern  __attribute__((__nothrow__)) void *valloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) int posix_memalign(void **__memptr ,
                                                        size_t __alignment ,
                                                        size_t __size )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__, __noreturn__)) void abort(void) ;
extern  __attribute__((__nothrow__)) int atexit(void (*__func)(void) )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int on_exit(void (*__func)(int __status ,
                                                                void *__arg ) ,
                                                 void *__arg )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__, __noreturn__)) void exit(int __status ) ;
extern  __attribute__((__nothrow__, __noreturn__)) void _Exit(int __status ) ;
extern  __attribute__((__nothrow__)) char *getenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *__secure_getenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int putenv(char *__string )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int setenv(char const   *__name ,
                                                char const   *__value ,
                                                int __replace )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int unsetenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int clearenv(void) ;
extern  __attribute__((__nothrow__)) char *mktemp(char *__template )  __attribute__((__nonnull__(1))) ;
extern int mkstemp(char *__template )  __asm__("mkstemp64") __attribute__((__nonnull__(1))) ;
extern int mkstemps(char *__template , int __suffixlen )  __asm__("mkstemps64") __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *mkdtemp(char *__template )  __attribute__((__nonnull__(1))) ;
extern int system(char const   *__command ) ;
extern  __attribute__((__nothrow__)) char *realpath(char const   * __restrict  __name ,
                                                    char * __restrict  __resolved ) ;
extern void *bsearch(void const   *__key , void const   *__base ,
                     size_t __nmemb , size_t __size ,
                     int (*__compar)(void const   * , void const   * ) )  __attribute__((__nonnull__(1,2,5))) ;
extern void qsort(void *__base , size_t __nmemb , size_t __size ,
                  int (*__compar)(void const   * , void const   * ) )  __attribute__((__nonnull__(1,4))) ;
extern  __attribute__((__nothrow__)) int abs(int __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long labs(long __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long long llabs(long long __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) div_t div(int __numer , int __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) ldiv_t ldiv(long __numer , long __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) lldiv_t lldiv(long long __numer ,
                                                   long long __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) char *ecvt(double __value , int __ndigit ,
                                                int * __restrict  __decpt ,
                                                int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *fcvt(double __value , int __ndigit ,
                                                int * __restrict  __decpt ,
                                                int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *gcvt(double __value , int __ndigit ,
                                                char *__buf )  __attribute__((__nonnull__(3))) ;
extern  __attribute__((__nothrow__)) char *qecvt(long double __value ,
                                                 int __ndigit ,
                                                 int * __restrict  __decpt ,
                                                 int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *qfcvt(long double __value ,
                                                 int __ndigit ,
                                                 int * __restrict  __decpt ,
                                                 int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *qgcvt(long double __value ,
                                                 int __ndigit , char *__buf )  __attribute__((__nonnull__(3))) ;
extern  __attribute__((__nothrow__)) int ecvt_r(double __value , int __ndigit ,
                                                int * __restrict  __decpt ,
                                                int * __restrict  __sign ,
                                                char * __restrict  __buf ,
                                                size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int fcvt_r(double __value , int __ndigit ,
                                                int * __restrict  __decpt ,
                                                int * __restrict  __sign ,
                                                char * __restrict  __buf ,
                                                size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int qecvt_r(long double __value ,
                                                 int __ndigit ,
                                                 int * __restrict  __decpt ,
                                                 int * __restrict  __sign ,
                                                 char * __restrict  __buf ,
                                                 size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int qfcvt_r(long double __value ,
                                                 int __ndigit ,
                                                 int * __restrict  __decpt ,
                                                 int * __restrict  __sign ,
                                                 char * __restrict  __buf ,
                                                 size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int mblen(char const   *__s , size_t __n ) ;
extern  __attribute__((__nothrow__)) int mbtowc(wchar_t * __restrict  __pwc ,
                                                char const   * __restrict  __s ,
                                                size_t __n ) ;
extern  __attribute__((__nothrow__)) int wctomb(char *__s , wchar_t __wchar ) ;
extern  __attribute__((__nothrow__)) size_t mbstowcs(wchar_t * __restrict  __pwcs ,
                                                     char const   * __restrict  __s ,
                                                     size_t __n ) ;
extern  __attribute__((__nothrow__)) size_t wcstombs(char * __restrict  __s ,
                                                     wchar_t const   * __restrict  __pwcs ,
                                                     size_t __n ) ;
extern  __attribute__((__nothrow__)) int rpmatch(char const   *__response )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int getsubopt(char ** __restrict  __optionp ,
                                                   char * const  * __restrict  __tokens ,
                                                   char ** __restrict  __valuep )  __attribute__((__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) int getloadavg(double *__loadavg ,
                                                    int __nelem )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void *memcpy(void * __restrict  __dest ,
                                                  void const   * __restrict  __src ,
                                                  size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memmove(void *__dest ,
                                                   void const   *__src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memccpy(void * __restrict  __dest ,
                                                   void const   * __restrict  __src ,
                                                   int __c , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memset(void *__s , int __c ,
                                                  size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int memcmp(void const   *__s1 ,
                                                void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memchr(void const   *__s , int __c ,
                                                  size_t __n )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strcat(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncat(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcmp(char const   *__s1 ,
                                                char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncmp(char const   *__s1 ,
                                                 char const   *__s2 ,
                                                 size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcoll(char const   *__s1 ,
                                                 char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm(char * __restrict  __dest ,
                                                    char const   * __restrict  __src ,
                                                    size_t __n )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int strcoll_l(char const   *__s1 ,
                                                   char const   *__s2 ,
                                                   __locale_t __l )  __attribute__((__pure__,
__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm_l(char *__dest ,
                                                      char const   *__src ,
                                                      size_t __n ,
                                                      __locale_t __l )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) char *strdup(char const   *__s )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strndup(char const   *__string ,
                                                   size_t __n )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strrchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strcspn(char const   *__s ,
                                                    char const   *__reject )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strspn(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strpbrk(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strstr(char const   *__haystack ,
                                                  char const   *__needle )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strtok(char * __restrict  __s ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *__strtok_r(char * __restrict  __s ,
                                                      char const   * __restrict  __delim ,
                                                      char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) char *strtok_r(char * __restrict  __s ,
                                                    char const   * __restrict  __delim ,
                                                    char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) size_t strlen(char const   *__s )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strnlen(char const   *__string ,
                                                    size_t __maxlen )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strerror(int __errnum ) ;
extern  __attribute__((__nothrow__)) int strerror_r(int __errnum , char *__buf ,
                                                    size_t __buflen )  __asm__("__xpg_strerror_r") __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *strerror_l(int __errnum ,
                                                      __locale_t __l ) ;
extern  __attribute__((__nothrow__)) void __bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void bcopy(void const   *__src ,
                                                void *__dest , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int bcmp(void const   *__s1 ,
                                              void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *index(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *rindex(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int ffs(int __i )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int strcasecmp(char const   *__s1 ,
                                                    char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncasecmp(char const   *__s1 ,
                                                     char const   *__s2 ,
                                                     size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsep(char ** __restrict  __stringp ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsignal(int __sig ) ;
extern  __attribute__((__nothrow__)) char *__stpcpy(char * __restrict  __dest ,
                                                    char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *__stpncpy(char * __restrict  __dest ,
                                                     char const   * __restrict  __src ,
                                                     size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern void *__rawmemchr(void const   *__s , int __c ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "78\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "79\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "76\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "75\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject) {
        fprintf(_coverage_fout, "74\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "77\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "80\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) ;
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "86\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "87\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "84\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "83\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        fprintf(_coverage_fout, "82\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          fprintf(_coverage_fout, "81\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "85\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "88\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) ;
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "95\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "96\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "93\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "92\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        fprintf(_coverage_fout, "91\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          fprintf(_coverage_fout, "90\n");
          fflush(_coverage_fout);
          if ((int const   )*(__s + __result) != (int const   )__reject3) {
            fprintf(_coverage_fout, "89\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "94\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "97\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) ;
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "101\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "102\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "99\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept) {
      fprintf(_coverage_fout, "98\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "100\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "103\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "109\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "110\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "107\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      fprintf(_coverage_fout, "104\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "106\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        fprintf(_coverage_fout, "105\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    }
    fprintf(_coverage_fout, "108\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "111\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "119\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "120\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "117\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      fprintf(_coverage_fout, "112\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "116\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        fprintf(_coverage_fout, "113\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "115\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) == (int const   )__accept3) {
          fprintf(_coverage_fout, "114\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      }
    }
    fprintf(_coverage_fout, "118\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "121\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "129\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "125\n");
    fflush(_coverage_fout);
    if ((int const   )*__s != 0) {
      fprintf(_coverage_fout, "124\n");
      fflush(_coverage_fout);
      if ((int const   )*__s != (int const   )__accept1) {
        fprintf(_coverage_fout, "123\n");
        fflush(_coverage_fout);
        if ((int const   )*__s != (int const   )__accept2) {
          fprintf(_coverage_fout, "122\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "126\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "130\n");
  fflush(_coverage_fout);
  if ((int const   )*__s == 0) {
    fprintf(_coverage_fout, "127\n");
    fflush(_coverage_fout);
    tmp = (char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "128\n");
    fflush(_coverage_fout);
    tmp = (char *)((unsigned int )__s);
  }
  fprintf(_coverage_fout, "131\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "140\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "136\n");
    fflush(_coverage_fout);
    if ((int const   )*__s != 0) {
      fprintf(_coverage_fout, "135\n");
      fflush(_coverage_fout);
      if ((int const   )*__s != (int const   )__accept1) {
        fprintf(_coverage_fout, "134\n");
        fflush(_coverage_fout);
        if ((int const   )*__s != (int const   )__accept2) {
          fprintf(_coverage_fout, "133\n");
          fflush(_coverage_fout);
          if ((int const   )*__s != (int const   )__accept3) {
            fprintf(_coverage_fout, "132\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "137\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "141\n");
  fflush(_coverage_fout);
  if ((int const   )*__s == 0) {
    fprintf(_coverage_fout, "138\n");
    fflush(_coverage_fout);
    tmp = (char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "139\n");
    fflush(_coverage_fout);
    tmp = (char *)((unsigned int )__s);
  }
  fprintf(_coverage_fout, "142\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) ;
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) 
{ char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "160\n");
  fflush(_coverage_fout);
  if ((unsigned int )__s == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "143\n");
    fflush(_coverage_fout);
    __s = *__nextp;
  } else {
    fprintf(_coverage_fout, "144\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "161\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "146\n");
    fflush(_coverage_fout);
    if ((int )*__s == (int )__sep) {
      fprintf(_coverage_fout, "145\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "147\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "162\n");
  fflush(_coverage_fout);
  __result = (char *)((void *)0);
  fprintf(_coverage_fout, "163\n");
  fflush(_coverage_fout);
  if ((int )*__s != 0) {
    fprintf(_coverage_fout, "155\n");
    fflush(_coverage_fout);
    tmp = __s;
    fprintf(_coverage_fout, "156\n");
    fflush(_coverage_fout);
    __s ++;
    fprintf(_coverage_fout, "157\n");
    fflush(_coverage_fout);
    __result = tmp;
    fprintf(_coverage_fout, "158\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "151\n");
      fflush(_coverage_fout);
      if ((int )*__s != 0) {
        fprintf(_coverage_fout, "148\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "152\n");
      fflush(_coverage_fout);
      tmp___0 = __s;
      fprintf(_coverage_fout, "153\n");
      fflush(_coverage_fout);
      __s ++;
      fprintf(_coverage_fout, "154\n");
      fflush(_coverage_fout);
      if ((int )*tmp___0 == (int )__sep) {
        fprintf(_coverage_fout, "149\n");
        fflush(_coverage_fout);
        *(__s + -1) = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "150\n");
        fflush(_coverage_fout);

      }
    }
  } else {
    fprintf(_coverage_fout, "159\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "164\n");
  fflush(_coverage_fout);
  *__nextp = __s;
  fprintf(_coverage_fout, "165\n");
  fflush(_coverage_fout);
  return (__result);
}
}
extern char *__strsep_g(char **__stringp , char const   *__delim ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) 
{ register char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  void *tmp___1 ;
  char *tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "175\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "176\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "170\n");
    fflush(_coverage_fout);
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    fprintf(_coverage_fout, "171\n");
    fflush(_coverage_fout);
    tmp___0 = tmp___2;
    fprintf(_coverage_fout, "172\n");
    fflush(_coverage_fout);
    *__s = tmp___0;
    fprintf(_coverage_fout, "173\n");
    fflush(_coverage_fout);
    if ((unsigned int )tmp___0 != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "166\n");
      fflush(_coverage_fout);
      tmp = *__s;
      fprintf(_coverage_fout, "167\n");
      fflush(_coverage_fout);
      (*__s) ++;
      fprintf(_coverage_fout, "168\n");
      fflush(_coverage_fout);
      *tmp = (char )'\000';
    } else {
      fprintf(_coverage_fout, "169\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "174\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "177\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) ;
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "195\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "196\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "191\n");
    fflush(_coverage_fout);
    __cp = __retval;
    fprintf(_coverage_fout, "192\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "188\n");
      fflush(_coverage_fout);
      if ((int )*__cp == 0) {
        fprintf(_coverage_fout, "178\n");
        fflush(_coverage_fout);
        __cp = (char *)((void *)0);
        break;
      } else {
        fprintf(_coverage_fout, "179\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "189\n");
      fflush(_coverage_fout);
      if ((int )*__cp == (int )__reject1) {
        fprintf(_coverage_fout, "180\n");
        fflush(_coverage_fout);
        tmp = __cp;
        fprintf(_coverage_fout, "181\n");
        fflush(_coverage_fout);
        __cp ++;
        fprintf(_coverage_fout, "182\n");
        fflush(_coverage_fout);
        *tmp = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "187\n");
        fflush(_coverage_fout);
        if ((int )*__cp == (int )__reject2) {
          fprintf(_coverage_fout, "183\n");
          fflush(_coverage_fout);
          tmp = __cp;
          fprintf(_coverage_fout, "184\n");
          fflush(_coverage_fout);
          __cp ++;
          fprintf(_coverage_fout, "185\n");
          fflush(_coverage_fout);
          *tmp = (char )'\000';
          break;
        } else {
          fprintf(_coverage_fout, "186\n");
          fflush(_coverage_fout);

        }
      }
      fprintf(_coverage_fout, "190\n");
      fflush(_coverage_fout);
      __cp ++;
    }
    fprintf(_coverage_fout, "193\n");
    fflush(_coverage_fout);
    *__s = __cp;
  } else {
    fprintf(_coverage_fout, "194\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "197\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) ;
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "219\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "220\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "215\n");
    fflush(_coverage_fout);
    __cp = __retval;
    fprintf(_coverage_fout, "216\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "212\n");
      fflush(_coverage_fout);
      if ((int )*__cp == 0) {
        fprintf(_coverage_fout, "198\n");
        fflush(_coverage_fout);
        __cp = (char *)((void *)0);
        break;
      } else {
        fprintf(_coverage_fout, "199\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "213\n");
      fflush(_coverage_fout);
      if ((int )*__cp == (int )__reject1) {
        fprintf(_coverage_fout, "200\n");
        fflush(_coverage_fout);
        tmp = __cp;
        fprintf(_coverage_fout, "201\n");
        fflush(_coverage_fout);
        __cp ++;
        fprintf(_coverage_fout, "202\n");
        fflush(_coverage_fout);
        *tmp = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "211\n");
        fflush(_coverage_fout);
        if ((int )*__cp == (int )__reject2) {
          fprintf(_coverage_fout, "203\n");
          fflush(_coverage_fout);
          tmp = __cp;
          fprintf(_coverage_fout, "204\n");
          fflush(_coverage_fout);
          __cp ++;
          fprintf(_coverage_fout, "205\n");
          fflush(_coverage_fout);
          *tmp = (char )'\000';
          break;
        } else {
          fprintf(_coverage_fout, "210\n");
          fflush(_coverage_fout);
          if ((int )*__cp == (int )__reject3) {
            fprintf(_coverage_fout, "206\n");
            fflush(_coverage_fout);
            tmp = __cp;
            fprintf(_coverage_fout, "207\n");
            fflush(_coverage_fout);
            __cp ++;
            fprintf(_coverage_fout, "208\n");
            fflush(_coverage_fout);
            *tmp = (char )'\000';
            break;
          } else {
            fprintf(_coverage_fout, "209\n");
            fflush(_coverage_fout);

          }
        }
      }
      fprintf(_coverage_fout, "214\n");
      fflush(_coverage_fout);
      __cp ++;
    }
    fprintf(_coverage_fout, "217\n");
    fflush(_coverage_fout);
    *__s = __cp;
  } else {
    fprintf(_coverage_fout, "218\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "221\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
extern  __attribute__((__nothrow__)) char *__strdup(char const   *__string )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strndup(char const   *__string ,
                                                     size_t __n )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) int access(char const   *__name ,
                                                int __type )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int faccessat(int __fd ,
                                                   char const   *__file ,
                                                   int __type , int __flag )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) __off64_t lseek(int __fd ,
                                                     __off64_t __offset ,
                                                     int __whence )  __asm__("lseek64")  ;
extern int close(int __fd ) ;
extern ssize_t read(int __fd , void *__buf , size_t __nbytes ) ;
extern ssize_t write(int __fd , void const   *__buf , size_t __n ) ;
extern ssize_t pread(int __fd , void *__buf , size_t __nbytes ,
                     __off64_t __offset )  __asm__("pread64")  ;
extern ssize_t pwrite(int __fd , void const   *__buf , size_t __nbytes ,
                      __off64_t __offset )  __asm__("pwrite64")  ;
extern  __attribute__((__nothrow__)) int pipe(int *__pipedes ) ;
extern  __attribute__((__nothrow__)) unsigned int alarm(unsigned int __seconds ) ;
extern unsigned int sleep(unsigned int __seconds ) ;
extern  __attribute__((__nothrow__)) __useconds_t ualarm(__useconds_t __value ,
                                                         __useconds_t __interval ) ;
extern int usleep(__useconds_t __useconds ) ;
extern int pause(void) ;
extern  __attribute__((__nothrow__)) int chown(char const   *__file ,
                                               __uid_t __owner ,
                                               __gid_t __group )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int fchown(int __fd , __uid_t __owner ,
                                                __gid_t __group ) ;
extern  __attribute__((__nothrow__)) int lchown(char const   *__file ,
                                                __uid_t __owner ,
                                                __gid_t __group )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int fchownat(int __fd ,
                                                  char const   *__file ,
                                                  __uid_t __owner ,
                                                  __gid_t __group , int __flag )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int chdir(char const   *__path )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int fchdir(int __fd ) ;
extern  __attribute__((__nothrow__)) char *getcwd(char *__buf , size_t __size ) ;
extern  __attribute__((__nothrow__)) char *getwd(char *__buf )  __attribute__((__nonnull__(1),
__deprecated__)) ;
extern  __attribute__((__nothrow__)) int dup(int __fd ) ;
extern  __attribute__((__nothrow__)) int dup2(int __fd , int __fd2 ) ;
extern char **__environ ;
extern  __attribute__((__nothrow__)) int execve(char const   *__path ,
                                                char * const  *__argv ,
                                                char * const  *__envp )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int fexecve(int __fd ,
                                                 char * const  *__argv ,
                                                 char * const  *__envp )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int execv(char const   *__path ,
                                               char * const  *__argv )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execle(char const   *__path ,
                                                char const   *__arg  , ...)  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execl(char const   *__path ,
                                               char const   *__arg  , ...)  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execvp(char const   *__file ,
                                                char * const  *__argv )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execlp(char const   *__file ,
                                                char const   *__arg  , ...)  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int nice(int __inc ) ;
extern  __attribute__((__noreturn__)) void _exit(int __status ) ;
extern  __attribute__((__nothrow__)) long pathconf(char const   *__path ,
                                                   int __name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long fpathconf(int __fd , int __name ) ;
extern  __attribute__((__nothrow__)) long sysconf(int __name ) ;
extern  __attribute__((__nothrow__)) size_t confstr(int __name , char *__buf ,
                                                    size_t __len ) ;
extern  __attribute__((__nothrow__)) __pid_t getpid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getppid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getpgrp(void) ;
extern  __attribute__((__nothrow__)) __pid_t __getpgid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) __pid_t getpgid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) int setpgid(__pid_t __pid , __pid_t __pgid ) ;
extern  __attribute__((__nothrow__)) int setpgrp(void) ;
extern  __attribute__((__nothrow__)) __pid_t setsid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getsid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) __uid_t getuid(void) ;
extern  __attribute__((__nothrow__)) __uid_t geteuid(void) ;
extern  __attribute__((__nothrow__)) __gid_t getgid(void) ;
extern  __attribute__((__nothrow__)) __gid_t getegid(void) ;
extern  __attribute__((__nothrow__)) int getgroups(int __size , __gid_t *__list ) ;
extern  __attribute__((__nothrow__)) int setuid(__uid_t __uid ) ;
extern  __attribute__((__nothrow__)) int setreuid(__uid_t __ruid ,
                                                  __uid_t __euid ) ;
extern  __attribute__((__nothrow__)) int seteuid(__uid_t __uid ) ;
extern  __attribute__((__nothrow__)) int setgid(__gid_t __gid ) ;
extern  __attribute__((__nothrow__)) int setregid(__gid_t __rgid ,
                                                  __gid_t __egid ) ;
extern  __attribute__((__nothrow__)) int setegid(__gid_t __gid ) ;
extern  __attribute__((__nothrow__)) __pid_t fork(void) ;
extern  __attribute__((__nothrow__)) __pid_t vfork(void) ;
extern  __attribute__((__nothrow__)) char *ttyname(int __fd ) ;
extern  __attribute__((__nothrow__)) int ttyname_r(int __fd , char *__buf ,
                                                   size_t __buflen )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int isatty(int __fd ) ;
extern  __attribute__((__nothrow__)) int ttyslot(void) ;
extern  __attribute__((__nothrow__)) int link(char const   *__from ,
                                              char const   *__to )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int linkat(int __fromfd ,
                                                char const   *__from ,
                                                int __tofd ,
                                                char const   *__to ,
                                                int __flags )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) int symlink(char const   *__from ,
                                                 char const   *__to )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) ssize_t readlink(char const   * __restrict  __path ,
                                                      char * __restrict  __buf ,
                                                      size_t __len )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int symlinkat(char const   *__from ,
                                                   int __tofd ,
                                                   char const   *__to )  __attribute__((__nonnull__(1,3))) ;
extern  __attribute__((__nothrow__)) ssize_t readlinkat(int __fd ,
                                                        char const   * __restrict  __path ,
                                                        char * __restrict  __buf ,
                                                        size_t __len )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) int unlink(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int unlinkat(int __fd ,
                                                  char const   *__name ,
                                                  int __flag )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int rmdir(char const   *__path )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) __pid_t tcgetpgrp(int __fd ) ;
extern  __attribute__((__nothrow__)) int tcsetpgrp(int __fd , __pid_t __pgrp_id ) ;
extern char *getlogin(void) ;
extern int getlogin_r(char *__name , size_t __name_len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int setlogin(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern char *optarg ;
extern int optind ;
extern int opterr ;
extern int optopt ;
extern  __attribute__((__nothrow__)) int getopt(int ___argc ,
                                                char * const  *___argv ,
                                                char const   *__shortopts ) ;
extern  __attribute__((__nothrow__)) int gethostname(char *__name ,
                                                     size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int sethostname(char const   *__name ,
                                                     size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int sethostid(long __id ) ;
extern  __attribute__((__nothrow__)) int getdomainname(char *__name ,
                                                       size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int setdomainname(char const   *__name ,
                                                       size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int vhangup(void) ;
extern  __attribute__((__nothrow__)) int revoke(char const   *__file )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int profil(unsigned short *__sample_buffer ,
                                                size_t __size ,
                                                size_t __offset ,
                                                unsigned int __scale )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int acct(char const   *__name ) ;
extern  __attribute__((__nothrow__)) char *getusershell(void) ;
extern  __attribute__((__nothrow__)) void endusershell(void) ;
extern  __attribute__((__nothrow__)) void setusershell(void) ;
extern  __attribute__((__nothrow__)) int daemon(int __nochdir , int __noclose ) ;
extern  __attribute__((__nothrow__)) int chroot(char const   *__path )  __attribute__((__nonnull__(1))) ;
extern char *getpass(char const   *__prompt )  __attribute__((__nonnull__(1))) ;
extern int fsync(int __fd ) ;
extern long gethostid(void) ;
extern  __attribute__((__nothrow__)) void sync(void) ;
extern  __attribute__((__nothrow__)) int getpagesize(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int getdtablesize(void) ;
extern  __attribute__((__nothrow__)) int truncate(char const   *__file ,
                                                  __off64_t __length )  __asm__("truncate64") __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int ftruncate(int __fd ,
                                                   __off64_t __length )  __asm__("ftruncate64")  ;
extern  __attribute__((__nothrow__)) int brk(void *__addr ) ;
extern  __attribute__((__nothrow__)) void *sbrk(intptr_t __delta ) ;
extern  __attribute__((__nothrow__)) long syscall(long __sysno  , ...) ;
extern int lockf(int __fd , int __cmd , __off64_t __len )  __asm__("lockf64")  ;
extern int fdatasync(int __fildes ) ;
extern int fcntl(int __fd , int __cmd  , ...) ;
extern int open(char const   *__file , int __oflag  , ...)  __asm__("open64") __attribute__((__nonnull__(1))) ;
extern int openat(int __fd , char const   *__file , int __oflag  , ...)  __asm__("openat64") __attribute__((__nonnull__(2))) ;
extern int creat(char const   *__file , __mode_t __mode )  __asm__("creat64") __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int posix_fadvise(int __fd ,
                                                       __off64_t __offset ,
                                                       __off64_t __len ,
                                                       int __advise )  __asm__("posix_fadvise64")  ;
extern int posix_fallocate(int __fd , __off64_t __offset , __off64_t __len )  __asm__("posix_fallocate64")  ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_fail(char const   *__assertion ,
                                  char const   *__file , unsigned int __line ,
                                  char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_perror_fail(int __errnum , char const   *__file ,
                                         unsigned int __line ,
                                         char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert(char const   *__assertion , char const   *__file ,
                             int __line ) ;
extern  __attribute__((__nothrow__)) void insque(void *__elem , void *__prev ) ;
extern  __attribute__((__nothrow__)) void remque(void *__elem ) ;
extern  __attribute__((__nothrow__)) ENTRY *hsearch(ENTRY __item ,
                                                    ACTION __action ) ;
extern  __attribute__((__nothrow__)) int hcreate(size_t __nel ) ;
extern  __attribute__((__nothrow__)) void hdestroy(void) ;
extern void *tsearch(void const   *__key , void **__rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void *tfind(void const   *__key , void * const  *__rootp ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *tdelete(void const   * __restrict  __key ,
                     void ** __restrict  __rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void twalk(void const   *__root ,
                  void (*__action)(void const   *__nodep , VISIT __value ,
                                   int __level ) ) ;
extern void *lfind(void const   *__key , void const   *__base ,
                   size_t *__nmemb , size_t __size ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *lsearch(void const   *__key , void *__base , size_t *__nmemb ,
                     size_t __size , int (*__compar)(void const   * ,
                                                     void const   * ) ) ;
extern char const   *TIFFGetVersion(void) ;
extern TIFFCodec const   *TIFFFindCODEC(uint16  ) ;
extern TIFFCodec *TIFFRegisterCODEC(uint16  , char const   * ,
                                    int (*)(TIFF * , int  ) ) ;
extern void TIFFUnRegisterCODEC(TIFFCodec * ) ;
extern int TIFFIsCODECConfigured(uint16  ) ;
extern TIFFCodec *TIFFGetConfiguredCODECs(void) ;
extern void *_TIFFmalloc(tmsize_t s ) ;
extern void *_TIFFrealloc(void *p , tmsize_t s ) ;
extern void _TIFFmemset(void *p , int v , tmsize_t c ) ;
extern void _TIFFmemcpy(void *d , void const   *s , tmsize_t c ) ;
extern int _TIFFmemcmp(void const   *p1 , void const   *p2 , tmsize_t c ) ;
extern void _TIFFfree(void *p ) ;
extern int TIFFGetTagListCount(TIFF * ) ;
extern uint32 TIFFGetTagListEntry(TIFF * , int tag_index ) ;
extern TIFFField const   *TIFFFindField(TIFF * , uint32  , TIFFDataType  ) ;
extern TIFFField const   *TIFFFieldWithTag(TIFF * , uint32  ) ;
extern TIFFField const   *TIFFFieldWithName(TIFF * , char const   * ) ;
extern TIFFTagMethods *TIFFAccessTagMethods(TIFF * ) ;
extern void *TIFFGetClientInfo(TIFF * , char const   * ) ;
extern void TIFFSetClientInfo(TIFF * , void * , char const   * ) ;
extern void TIFFCleanup(TIFF *tif ) ;
extern void TIFFClose(TIFF *tif ) ;
extern int TIFFFlush(TIFF *tif ) ;
extern int TIFFFlushData(TIFF *tif ) ;
extern int TIFFGetField(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFVGetField(TIFF *tif , uint32 tag , va_list ap ) ;
extern int TIFFGetFieldDefaulted(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFVGetFieldDefaulted(TIFF *tif , uint32 tag , va_list ap ) ;
extern int TIFFReadDirectory(TIFF *tif ) ;
extern int TIFFReadCustomDirectory(TIFF *tif , toff_t diroff ,
                                   TIFFFieldArray const   *infoarray ) ;
extern int TIFFReadEXIFDirectory(TIFF *tif , toff_t diroff ) ;
extern uint64 TIFFScanlineSize64(TIFF *tif ) ;
extern tmsize_t TIFFScanlineSize(TIFF *tif ) ;
extern uint64 TIFFRasterScanlineSize64(TIFF *tif ) ;
extern tmsize_t TIFFRasterScanlineSize(TIFF *tif ) ;
extern uint64 TIFFStripSize64(TIFF *tif ) ;
extern tmsize_t TIFFStripSize(TIFF *tif ) ;
extern uint64 TIFFRawStripSize64(TIFF *tif , uint32 strip ) ;
extern tmsize_t TIFFRawStripSize(TIFF *tif , uint32 strip ) ;
extern uint64 TIFFVStripSize64(TIFF *tif , uint32 nrows ) ;
extern tmsize_t TIFFVStripSize(TIFF *tif , uint32 nrows ) ;
extern uint64 TIFFTileRowSize64(TIFF *tif ) ;
extern tmsize_t TIFFTileRowSize(TIFF *tif ) ;
extern uint64 TIFFTileSize64(TIFF *tif ) ;
extern tmsize_t TIFFTileSize(TIFF *tif ) ;
extern uint64 TIFFVTileSize64(TIFF *tif , uint32 nrows ) ;
extern tmsize_t TIFFVTileSize(TIFF *tif , uint32 nrows ) ;
extern uint32 TIFFDefaultStripSize(TIFF *tif , uint32 request ) ;
extern void TIFFDefaultTileSize(TIFF * , uint32 * , uint32 * ) ;
extern int TIFFFileno(TIFF * ) ;
extern int TIFFSetFileno(TIFF * , int  ) ;
extern thandle_t TIFFClientdata(TIFF * ) ;
extern thandle_t TIFFSetClientdata(TIFF * , thandle_t  ) ;
extern int TIFFGetMode(TIFF * ) ;
extern int TIFFSetMode(TIFF * , int  ) ;
extern int TIFFIsTiled(TIFF * ) ;
extern int TIFFIsByteSwapped(TIFF * ) ;
extern int TIFFIsUpSampled(TIFF * ) ;
extern int TIFFIsMSB2LSB(TIFF * ) ;
extern int TIFFIsBigEndian(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetReadProc(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetWriteProc(TIFF * ) ;
extern TIFFSeekProc TIFFGetSeekProc(TIFF * ) ;
extern TIFFCloseProc TIFFGetCloseProc(TIFF * ) ;
extern TIFFSizeProc TIFFGetSizeProc(TIFF * ) ;
extern TIFFMapFileProc TIFFGetMapFileProc(TIFF * ) ;
extern TIFFUnmapFileProc TIFFGetUnmapFileProc(TIFF * ) ;
extern uint32 TIFFCurrentRow(TIFF * ) ;
extern uint16 TIFFCurrentDirectory(TIFF * ) ;
extern uint16 TIFFNumberOfDirectories(TIFF * ) ;
extern uint64 TIFFCurrentDirOffset(TIFF * ) ;
extern uint32 TIFFCurrentStrip(TIFF * ) ;
extern uint32 TIFFCurrentTile(TIFF *tif ) ;
extern int TIFFReadBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
extern int TIFFWriteBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
extern int TIFFSetupStrips(TIFF * ) ;
extern int TIFFWriteCheck(TIFF * , int  , char const   * ) ;
extern void TIFFFreeDirectory(TIFF * ) ;
extern int TIFFCreateDirectory(TIFF * ) ;
extern int TIFFLastDirectory(TIFF * ) ;
extern int TIFFSetDirectory(TIFF * , uint16  ) ;
extern int TIFFSetSubDirectory(TIFF * , uint64  ) ;
extern int TIFFUnlinkDirectory(TIFF * , uint16  ) ;
extern int TIFFSetField(TIFF * , uint32   , ...) ;
extern int TIFFVSetField(TIFF * , uint32  , va_list  ) ;
extern int TIFFUnsetField(TIFF * , uint32  ) ;
extern int TIFFWriteDirectory(TIFF * ) ;
extern int TIFFCheckpointDirectory(TIFF * ) ;
extern int TIFFRewriteDirectory(TIFF * ) ;
extern void TIFFPrintDirectory(TIFF * , FILE * , long  ) ;
extern int TIFFReadScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) ;
extern int TIFFWriteScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) ;
extern int TIFFReadRGBAImage(TIFF * , uint32  , uint32  , uint32 * , int  ) ;
extern int TIFFReadRGBAImageOriented(TIFF * , uint32  , uint32  , uint32 * ,
                                     int  , int  ) ;
extern int TIFFReadRGBAStrip(TIFF * , uint32  , uint32 * ) ;
extern int TIFFReadRGBATile(TIFF * , uint32  , uint32  , uint32 * ) ;
extern int TIFFRGBAImageOK(TIFF * , char * ) ;
extern int TIFFRGBAImageBegin(TIFFRGBAImage * , TIFF * , int  , char * ) ;
extern int TIFFRGBAImageGet(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
extern void TIFFRGBAImageEnd(TIFFRGBAImage * ) ;
extern TIFF *TIFFOpen(char const   * , char const   * ) ;
extern TIFF *TIFFFdOpen(int  , char const   * , char const   * ) ;
extern TIFF *TIFFClientOpen(char const   * , char const   * , thandle_t  ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            toff_t (*)(thandle_t  , toff_t  , int  ) ,
                            int (*)(thandle_t  ) , toff_t (*)(thandle_t  ) ,
                            int (*)(thandle_t  , void **base , toff_t *size ) ,
                            void (*)(thandle_t  , void *base , toff_t size ) ) ;
extern char const   *TIFFFileName(TIFF * ) ;
extern char const   *TIFFSetFileName(TIFF * , char const   * ) ;
extern void ( /* format attribute */  TIFFError)(char const   * ,
                                                 char const   *  , ...) ;
extern void ( /* format attribute */  TIFFErrorExt)(thandle_t  ,
                                                    char const   * ,
                                                    char const   *  , ...) ;
extern void ( /* format attribute */  TIFFWarning)(char const   * ,
                                                   char const   *  , ...) ;
extern void ( /* format attribute */  TIFFWarningExt)(thandle_t  ,
                                                      char const   * ,
                                                      char const   *  , ...) ;
extern TIFFErrorHandler TIFFSetErrorHandler(void (*)(char const   * ,
                                                     char const   * , va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetErrorHandlerExt(void (*)(thandle_t  ,
                                                           char const   * ,
                                                           char const   * ,
                                                           va_list  ) ) ;
extern TIFFErrorHandler TIFFSetWarningHandler(void (*)(char const   * ,
                                                       char const   * ,
                                                       va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetWarningHandlerExt(void (*)(thandle_t  ,
                                                             char const   * ,
                                                             char const   * ,
                                                             va_list  ) ) ;
extern TIFFExtendProc TIFFSetTagExtender(void (*)(TIFF * ) ) ;
extern uint32 TIFFComputeTile(TIFF *tif , uint32 x , uint32 y , uint32 z ,
                              uint16 s ) ;
extern int TIFFCheckTile(TIFF *tif , uint32 x , uint32 y , uint32 z , uint16 s ) ;
extern uint32 TIFFNumberOfTiles(TIFF * ) ;
extern tmsize_t TIFFReadTile(TIFF *tif , void *buf , uint32 x , uint32 y ,
                             uint32 z , uint16 s ) ;
extern tmsize_t TIFFWriteTile(TIFF *tif , void *buf , uint32 x , uint32 y ,
                              uint32 z , uint16 s ) ;
extern uint32 TIFFComputeStrip(TIFF * , uint32  , uint16  ) ;
extern uint32 TIFFNumberOfStrips(TIFF * ) ;
extern tmsize_t TIFFReadEncodedStrip(TIFF *tif , uint32 strip , void *buf ,
                                     tmsize_t size ) ;
extern tmsize_t TIFFReadRawStrip(TIFF *tif , uint32 strip , void *buf ,
                                 tmsize_t size ) ;
extern tmsize_t TIFFReadEncodedTile(TIFF *tif , uint32 tile , void *buf ,
                                    tmsize_t size ) ;
extern tmsize_t TIFFReadRawTile(TIFF *tif , uint32 tile , void *buf ,
                                tmsize_t size ) ;
extern tmsize_t TIFFWriteEncodedStrip(TIFF *tif , uint32 strip , void *data ,
                                      tmsize_t cc ) ;
extern tmsize_t TIFFWriteRawStrip(TIFF *tif , uint32 strip , void *data ,
                                  tmsize_t cc ) ;
extern tmsize_t TIFFWriteEncodedTile(TIFF *tif , uint32 tile , void *data ,
                                     tmsize_t cc ) ;
extern tmsize_t TIFFWriteRawTile(TIFF *tif , uint32 tile , void *data ,
                                 tmsize_t cc ) ;
extern int TIFFDataWidth(TIFFDataType  ) ;
extern void TIFFSetWriteOffset(TIFF *tif , toff_t off ) ;
extern void TIFFSwabShort(uint16 * ) ;
extern void TIFFSwabLong(uint32 * ) ;
extern void TIFFSwabLong8(uint64 * ) ;
extern void TIFFSwabFloat(float * ) ;
extern void TIFFSwabDouble(double * ) ;
extern void TIFFSwabArrayOfShort(uint16 *wp , tmsize_t n ) ;
extern void TIFFSwabArrayOfTriples(uint8 *tp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong(uint32 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong8(uint64 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfFloat(float *fp , tmsize_t n ) ;
extern void TIFFSwabArrayOfDouble(double *dp , tmsize_t n ) ;
extern void TIFFReverseBits(uint8 *cp , tmsize_t n ) ;
extern unsigned char const   *TIFFGetBitRevTable(int  ) ;
extern double LogL16toY(int  ) ;
extern double LogL10toY(int  ) ;
extern void XYZtoRGB24(float * , uint8 * ) ;
extern int uv_decode(double * , double * , int  ) ;
extern void LogLuv24toXYZ(uint32  , float * ) ;
extern void LogLuv32toXYZ(uint32  , float * ) ;
extern int LogL16fromY(double  , int  ) ;
extern int LogL10fromY(double  , int  ) ;
extern int uv_encode(double  , double  , int  ) ;
extern uint32 LogLuv24fromXYZ(float * , int  ) ;
extern uint32 LogLuv32fromXYZ(float * , int  ) ;
extern int TIFFCIELabToRGBInit(TIFFCIELabToRGB * , TIFFDisplay * , float * ) ;
extern void TIFFCIELabToXYZ(TIFFCIELabToRGB * , uint32  , int32  , int32  ,
                            float * , float * , float * ) ;
extern void TIFFXYZToRGB(TIFFCIELabToRGB * , float  , float  , float  ,
                         uint32 * , uint32 * , uint32 * ) ;
extern int TIFFYCbCrToRGBInit(TIFFYCbCrToRGB * , float * , float * ) ;
extern void TIFFYCbCrtoRGB(TIFFYCbCrToRGB * , uint32  , int32  , int32  ,
                           uint32 * , uint32 * , uint32 * ) ;
extern int TIFFMergeFieldInfo(TIFF * , TIFFFieldInfo const   * , uint32  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfo(TIFF * , uint32  ,
                                                TIFFDataType  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfoByName(TIFF * , char const   * ,
                                                      TIFFDataType  ) ;
extern TIFFFieldArray const   *_TIFFGetFields(void) ;
extern TIFFFieldArray const   *_TIFFGetExifFields(void) ;
extern void _TIFFSetupFields(TIFF *tif , TIFFFieldArray const   *infoarray ) ;
extern void _TIFFPrintFieldInfo(TIFF * , FILE * ) ;
extern int _TIFFMergeFields(TIFF * , TIFFField const   * , uint32  ) ;
extern TIFFField const   *_TIFFFindOrRegisterField(TIFF * , uint32  ,
                                                   TIFFDataType  ) ;
extern TIFFField *_TIFFCreateAnonField(TIFF * , uint32  , TIFFDataType  ) ;
extern int _TIFFgetMode(char const   *mode , char const   *module ) ;
extern int _TIFFNoRowEncode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoStripEncode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoTileEncode(TIFF * , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoRowDecode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoStripDecode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoTileDecode(TIFF * , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern void _TIFFNoPostDecode(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern int _TIFFNoPreCode(TIFF *tif , uint16 s ) ;
extern int _TIFFNoSeek(TIFF *tif , uint32 off ) ;
extern void _TIFFSwab16BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab24BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab32BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab64BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern int TIFFFlushData1(TIFF *tif ) ;
extern int TIFFDefaultDirectory(TIFF *tif ) ;
extern void _TIFFSetDefaultCompressionState(TIFF *tif ) ;
extern int _TIFFRewriteField(TIFF * , uint16  , TIFFDataType  , tmsize_t  ,
                             void * ) ;
extern int TIFFSetCompressionScheme(TIFF *tif , int scheme ) ;
extern int TIFFSetDefaultCompressionState(TIFF *tif ) ;
extern uint32 _TIFFDefaultStripSize(TIFF *tif , uint32 s ) ;
extern void _TIFFDefaultTileSize(TIFF *tif , uint32 *tw , uint32 *th ) ;
extern int _TIFFDataSize(TIFFDataType type ) ;
extern void _TIFFsetByteArray(void ** , void * , uint32  ) ;
extern void _TIFFsetString(char ** , char * ) ;
extern void _TIFFsetShortArray(uint16 ** , uint16 * , uint32  ) ;
extern void _TIFFsetLongArray(uint32 ** , uint32 * , uint32  ) ;
extern void _TIFFsetFloatArray(float ** , float * , uint32  ) ;
extern void _TIFFsetDoubleArray(double ** , double * , uint32  ) ;
extern void _TIFFprintAscii(FILE * , char const   * ) ;
extern void _TIFFprintAsciiTag(FILE * , char const   * , char const   * ) ;
extern void (*_TIFFwarningHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFerrorHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFwarningHandlerExt)(thandle_t  , char const   * ,
                                      char const   * , va_list  ) ;
extern void (*_TIFFerrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  ) ;
extern void *_TIFFCheckMalloc(TIFF *tif , tmsize_t nmemb , tmsize_t elem_size ,
                              char const   *what ) ;
extern void *_TIFFCheckRealloc(TIFF *tif , void *buffer , tmsize_t nmemb ,
                               tmsize_t elem_size , char const   *what ) ;
extern double _TIFFUInt64ToDouble(uint64  ) ;
extern float _TIFFUInt64ToFloat(uint64  ) ;
extern int TIFFInitDumpMode(TIFF * , int  ) ;
extern int TIFFInitPackBits(TIFF * , int  ) ;
extern int TIFFInitCCITTRLE(TIFF * , int  ) ;
extern int TIFFInitCCITTRLEW(TIFF * , int  ) ;
extern int TIFFInitCCITTFax3(TIFF * , int  ) ;
extern int TIFFInitCCITTFax4(TIFF * , int  ) ;
extern int TIFFInitThunderScan(TIFF * , int  ) ;
extern int TIFFInitNeXT(TIFF * , int  ) ;
extern int TIFFInitLZW(TIFF * , int  ) ;
extern int TIFFInitZIP(TIFF * , int  ) ;
extern int TIFFInitPixarLog(TIFF * , int  ) ;
extern int TIFFInitSGILog(TIFF * , int  ) ;
extern TIFFCodec _TIFFBuiltinCODECS[] ;
static void (*old_error_handler)(char const   * , char const   * , va_list  )  =    (void (*)(char const   * ,
             char const   * , va_list  ))0;
static int status  =    0;
static int showdata  =    0;
static int rawdata  =    0;
static int showwords  =    0;
static int readdata  =    0;
static int stoponerr  =    1;
static void usage(void) ;
static void tiffinfo(TIFF *tif , uint16 order , long flags ) ;
static void PrivateErrorHandler(char const   *module , char const   *fmt ,
                                va_list ap ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "224\n");
  fflush(_coverage_fout);
  if (old_error_handler) {
    fprintf(_coverage_fout, "222\n");
    fflush(_coverage_fout);
    (*old_error_handler)(module, fmt, ap);
  } else {
    fprintf(_coverage_fout, "223\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "225\n");
  fflush(_coverage_fout);
  status = 1;
  fprintf(_coverage_fout, "226\n");
  fflush(_coverage_fout);
  return;
}
}
int main(int argc , char **argv ) 
{ int dirnum ;
  int multiplefiles ;
  int c ;
  uint16 order ;
  TIFF *tif ;
  long flags ;
  uint64 diroff ;
  int chopstrips ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  unsigned char const   *__s2 ;
  register int __result ;
  int tmp___2 ;
  unsigned char const   *__s1 ;
  register int __result___0 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  unsigned char const   *__s2___0 ;
  register int __result___1 ;
  int tmp___9 ;
  unsigned char const   *__s1___0 ;
  register int __result___2 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  unsigned long tmp___13 ;
  char const   *tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  toff_t offset ;
  int tmp___17 ;
  int tmp___18 ;
  int tmp___19 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "321\n");
  fflush(_coverage_fout);
  dirnum = -1;
  fprintf(_coverage_fout, "322\n");
  fflush(_coverage_fout);
  order = (uint16 )0;
  fprintf(_coverage_fout, "323\n");
  fflush(_coverage_fout);
  flags = 0L;
  fprintf(_coverage_fout, "324\n");
  fflush(_coverage_fout);
  diroff = (uint64 )0;
  fprintf(_coverage_fout, "325\n");
  fflush(_coverage_fout);
  chopstrips = 0;
  fprintf(_coverage_fout, "326\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "282\n");
    fflush(_coverage_fout);
    c = getopt(argc, (char * const  *)argv, "f:o:cdDSjilmrsvwz0123456789");
    fprintf(_coverage_fout, "283\n");
    fflush(_coverage_fout);
    if (c != -1) {
      fprintf(_coverage_fout, "227\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    switch (c) {
    fprintf(_coverage_fout, "267\n");
    fflush(_coverage_fout);
    case 48: 
    case 49: 
    case 50: 
    case 51: 
    case 52: 
    case 53: 
    case 54: 
    case 55: 
    case 56: 
    case 57: 
    dirnum = atoi((char const   *)(*(argv + (optind - 1)) + 1));
    break;
    fprintf(_coverage_fout, "268\n");
    fflush(_coverage_fout);
    case 100: 
    showdata ++;
    fprintf(_coverage_fout, "269\n");
    fflush(_coverage_fout);
    case 68: 
    readdata ++;
    break;
    fprintf(_coverage_fout, "270\n");
    fflush(_coverage_fout);
    case 99: 
    flags |= 6L;
    break;
    fprintf(_coverage_fout, "271\n");
    fflush(_coverage_fout);
    case 102: 
    if (0) {
      fprintf(_coverage_fout, "239\n");
      fflush(_coverage_fout);
      __s1_len___0 = strlen((char const   *)optarg);
      fprintf(_coverage_fout, "240\n");
      fflush(_coverage_fout);
      __s2_len___0 = strlen("lsb2msb");
      fprintf(_coverage_fout, "241\n");
      fflush(_coverage_fout);
      if (! ((unsigned int )((void const   *)(optarg + 1)) - (unsigned int )((void const   *)optarg) == 1U)) {
        goto _L___2;
      } else {
        fprintf(_coverage_fout, "234\n");
        fflush(_coverage_fout);
        if (__s1_len___0 >= 4U) {
          fprintf(_coverage_fout, "232\n");
          fflush(_coverage_fout);
          _L___2: /* CIL Label */ 
          if (! ((unsigned int )((void const   *)("lsb2msb" + 1)) - (unsigned int )((void const   *)"lsb2msb") == 1U)) {
            fprintf(_coverage_fout, "228\n");
            fflush(_coverage_fout);
            tmp___12 = 1;
          } else {
            fprintf(_coverage_fout, "231\n");
            fflush(_coverage_fout);
            if (__s2_len___0 >= 4U) {
              fprintf(_coverage_fout, "229\n");
              fflush(_coverage_fout);
              tmp___12 = 1;
            } else {
              fprintf(_coverage_fout, "230\n");
              fflush(_coverage_fout);
              tmp___12 = 0;
            }
          }
        } else {
          fprintf(_coverage_fout, "233\n");
          fflush(_coverage_fout);
          tmp___12 = 0;
        }
      }
      fprintf(_coverage_fout, "242\n");
      fflush(_coverage_fout);
      if (tmp___12) {
        fprintf(_coverage_fout, "235\n");
        fflush(_coverage_fout);
        tmp___7 = __builtin_strcmp((char const   *)optarg, "lsb2msb");
        fprintf(_coverage_fout, "236\n");
        fflush(_coverage_fout);
        tmp___11 = tmp___7;
      } else {
        fprintf(_coverage_fout, "237\n");
        fflush(_coverage_fout);
        tmp___10 = __builtin_strcmp((char const   *)optarg, "lsb2msb");
        fprintf(_coverage_fout, "238\n");
        fflush(_coverage_fout);
        tmp___11 = tmp___10;
      }
    } else {
      fprintf(_coverage_fout, "243\n");
      fflush(_coverage_fout);
      tmp___10 = __builtin_strcmp((char const   *)optarg, "lsb2msb");
      fprintf(_coverage_fout, "244\n");
      fflush(_coverage_fout);
      tmp___11 = tmp___10;
    }
    fprintf(_coverage_fout, "272\n");
    fflush(_coverage_fout);
    if (tmp___11 == 0) {
      fprintf(_coverage_fout, "245\n");
      fflush(_coverage_fout);
      order = (unsigned short)2;
    } else {
      fprintf(_coverage_fout, "265\n");
      fflush(_coverage_fout);
      if (0) {
        fprintf(_coverage_fout, "257\n");
        fflush(_coverage_fout);
        __s1_len = strlen((char const   *)optarg);
        fprintf(_coverage_fout, "258\n");
        fflush(_coverage_fout);
        __s2_len = strlen("msb2lsb");
        fprintf(_coverage_fout, "259\n");
        fflush(_coverage_fout);
        if (! ((unsigned int )((void const   *)(optarg + 1)) - (unsigned int )((void const   *)optarg) == 1U)) {
          goto _L___0;
        } else {
          fprintf(_coverage_fout, "252\n");
          fflush(_coverage_fout);
          if (__s1_len >= 4U) {
            fprintf(_coverage_fout, "250\n");
            fflush(_coverage_fout);
            _L___0: /* CIL Label */ 
            if (! ((unsigned int )((void const   *)("msb2lsb" + 1)) - (unsigned int )((void const   *)"msb2lsb") == 1U)) {
              fprintf(_coverage_fout, "246\n");
              fflush(_coverage_fout);
              tmp___5 = 1;
            } else {
              fprintf(_coverage_fout, "249\n");
              fflush(_coverage_fout);
              if (__s2_len >= 4U) {
                fprintf(_coverage_fout, "247\n");
                fflush(_coverage_fout);
                tmp___5 = 1;
              } else {
                fprintf(_coverage_fout, "248\n");
                fflush(_coverage_fout);
                tmp___5 = 0;
              }
            }
          } else {
            fprintf(_coverage_fout, "251\n");
            fflush(_coverage_fout);
            tmp___5 = 0;
          }
        }
        fprintf(_coverage_fout, "260\n");
        fflush(_coverage_fout);
        if (tmp___5) {
          fprintf(_coverage_fout, "253\n");
          fflush(_coverage_fout);
          tmp___0 = __builtin_strcmp((char const   *)optarg, "msb2lsb");
          fprintf(_coverage_fout, "254\n");
          fflush(_coverage_fout);
          tmp___4 = tmp___0;
        } else {
          fprintf(_coverage_fout, "255\n");
          fflush(_coverage_fout);
          tmp___3 = __builtin_strcmp((char const   *)optarg, "msb2lsb");
          fprintf(_coverage_fout, "256\n");
          fflush(_coverage_fout);
          tmp___4 = tmp___3;
        }
      } else {
        fprintf(_coverage_fout, "261\n");
        fflush(_coverage_fout);
        tmp___3 = __builtin_strcmp((char const   *)optarg, "msb2lsb");
        fprintf(_coverage_fout, "262\n");
        fflush(_coverage_fout);
        tmp___4 = tmp___3;
      }
      fprintf(_coverage_fout, "266\n");
      fflush(_coverage_fout);
      if (tmp___4 == 0) {
        fprintf(_coverage_fout, "263\n");
        fflush(_coverage_fout);
        order = (unsigned short)1;
      } else {
        fprintf(_coverage_fout, "264\n");
        fflush(_coverage_fout);
        usage();
      }
    }
    break;
    fprintf(_coverage_fout, "273\n");
    fflush(_coverage_fout);
    case 105: 
    stoponerr = 0;
    break;
    fprintf(_coverage_fout, "274\n");
    fflush(_coverage_fout);
    case 111: 
    tmp___13 = strtoul((char const   */* __restrict  */)optarg,
                       (char **/* __restrict  */)((void *)0), 0);
    fprintf(_coverage_fout, "275\n");
    fflush(_coverage_fout);
    diroff = (unsigned long long )tmp___13;
    break;
    fprintf(_coverage_fout, "276\n");
    fflush(_coverage_fout);
    case 106: 
    flags |= 768L;
    break;
    fprintf(_coverage_fout, "277\n");
    fflush(_coverage_fout);
    case 114: 
    rawdata = 1;
    break;
    fprintf(_coverage_fout, "278\n");
    fflush(_coverage_fout);
    case 115: 
    flags |= 1L;
    break;
    fprintf(_coverage_fout, "279\n");
    fflush(_coverage_fout);
    case 119: 
    showwords = 1;
    break;
    fprintf(_coverage_fout, "280\n");
    fflush(_coverage_fout);
    case 122: 
    chopstrips = 1;
    break;
    fprintf(_coverage_fout, "281\n");
    fflush(_coverage_fout);
    case 63: 
    usage();
    }
  }
  fprintf(_coverage_fout, "327\n");
  fflush(_coverage_fout);
  if (optind >= argc) {
    fprintf(_coverage_fout, "284\n");
    fflush(_coverage_fout);
    usage();
  } else {
    fprintf(_coverage_fout, "285\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "328\n");
  fflush(_coverage_fout);
  old_error_handler = _TIFFerrorHandler;
  fprintf(_coverage_fout, "329\n");
  fflush(_coverage_fout);
  TIFFSetErrorHandler(& PrivateErrorHandler);
  fprintf(_coverage_fout, "330\n");
  fflush(_coverage_fout);
  multiplefiles = argc - optind > 1;
  fprintf(_coverage_fout, "331\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "315\n");
    fflush(_coverage_fout);
    if (optind < argc) {
      fprintf(_coverage_fout, "286\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "316\n");
    fflush(_coverage_fout);
    if (multiplefiles) {
      fprintf(_coverage_fout, "287\n");
      fflush(_coverage_fout);
      printf((char const   */* __restrict  */)"%s:\n", *(argv + optind));
    } else {
      fprintf(_coverage_fout, "288\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "317\n");
    fflush(_coverage_fout);
    if (chopstrips) {
      fprintf(_coverage_fout, "289\n");
      fflush(_coverage_fout);
      tmp___14 = "rC";
    } else {
      fprintf(_coverage_fout, "290\n");
      fflush(_coverage_fout);
      tmp___14 = "rc";
    }
    fprintf(_coverage_fout, "318\n");
    fflush(_coverage_fout);
    tif = TIFFOpen((char const   *)*(argv + optind), tmp___14);
    fprintf(_coverage_fout, "319\n");
    fflush(_coverage_fout);
    if ((unsigned int )tif != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "312\n");
      fflush(_coverage_fout);
      if (dirnum != -1) {
        fprintf(_coverage_fout, "293\n");
        fflush(_coverage_fout);
        tmp___15 = TIFFSetDirectory(tif, (unsigned short )dirnum);
        fprintf(_coverage_fout, "294\n");
        fflush(_coverage_fout);
        if (tmp___15) {
          fprintf(_coverage_fout, "291\n");
          fflush(_coverage_fout);
          tiffinfo(tif, order, flags);
        } else {
          fprintf(_coverage_fout, "292\n");
          fflush(_coverage_fout);

        }
      } else {
        fprintf(_coverage_fout, "311\n");
        fflush(_coverage_fout);
        if (diroff != 0ULL) {
          fprintf(_coverage_fout, "297\n");
          fflush(_coverage_fout);
          tmp___16 = TIFFSetSubDirectory(tif, diroff);
          fprintf(_coverage_fout, "298\n");
          fflush(_coverage_fout);
          if (tmp___16) {
            fprintf(_coverage_fout, "295\n");
            fflush(_coverage_fout);
            tiffinfo(tif, order, flags);
          } else {
            fprintf(_coverage_fout, "296\n");
            fflush(_coverage_fout);

          }
        } else {
          fprintf(_coverage_fout, "310\n");
          fflush(_coverage_fout);
          while (1) {
            fprintf(_coverage_fout, "305\n");
            fflush(_coverage_fout);
            tiffinfo(tif, order, flags);
            fprintf(_coverage_fout, "306\n");
            fflush(_coverage_fout);
            tmp___18 = TIFFGetField(tif, 34665U, & offset);
            fprintf(_coverage_fout, "307\n");
            fflush(_coverage_fout);
            if (tmp___18) {
              fprintf(_coverage_fout, "301\n");
              fflush(_coverage_fout);
              tmp___17 = TIFFReadEXIFDirectory(tif, offset);
              fprintf(_coverage_fout, "302\n");
              fflush(_coverage_fout);
              if (tmp___17) {
                fprintf(_coverage_fout, "299\n");
                fflush(_coverage_fout);
                tiffinfo(tif, order, flags);
              } else {
                fprintf(_coverage_fout, "300\n");
                fflush(_coverage_fout);

              }
            } else {
              fprintf(_coverage_fout, "303\n");
              fflush(_coverage_fout);

            }
            fprintf(_coverage_fout, "308\n");
            fflush(_coverage_fout);
            tmp___19 = TIFFReadDirectory(tif);
            fprintf(_coverage_fout, "309\n");
            fflush(_coverage_fout);
            if (tmp___19) {
              fprintf(_coverage_fout, "304\n");
              fflush(_coverage_fout);

            } else {
              break;
            }
          }
        }
      }
      fprintf(_coverage_fout, "313\n");
      fflush(_coverage_fout);
      TIFFClose(tif);
    } else {
      fprintf(_coverage_fout, "314\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "320\n");
    fflush(_coverage_fout);
    optind ++;
  }
  fprintf(_coverage_fout, "332\n");
  fflush(_coverage_fout);
  return (status);
}
}
char *stuff[16]  = 
  {      (char *)"usage: tiffinfo [options] input...",      (char *)"where options are:",      (char *)" -D\t\tread data",      (char *)" -i\t\tignore read errors", 
        (char *)" -c\t\tdisplay data for grey/color response curve or colormap",      (char *)" -d\t\tdisplay raw/decoded image data",      (char *)" -f lsb2msb\tforce lsb-to-msb FillOrder for input",      (char *)" -f msb2lsb\tforce msb-to-lsb FillOrder for input", 
        (char *)" -j\t\tshow JPEG tables",      (char *)" -o offset\tset initial directory offset",      (char *)" -r\t\tread/display raw image data instead of decoded data",      (char *)" -s\t\tdisplay strip offsets and byte counts", 
        (char *)" -w\t\tdisplay raw data in words rather than bytes",      (char *)" -z\t\tenable strip chopping",      (char *)" -#\t\tset initial directory (first directory is # 0)",      (char *)((void *)0)};
static void usage(void) 
{ char buf[8192] ;
  int i ;
  char const   *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "337\n");
  fflush(_coverage_fout);
  setbuf((FILE */* __restrict  */)stderr, (char */* __restrict  */)(buf));
  fprintf(_coverage_fout, "338\n");
  fflush(_coverage_fout);
  tmp = TIFFGetVersion();
  fprintf(_coverage_fout, "339\n");
  fflush(_coverage_fout);
  fprintf((FILE */* __restrict  */)stderr,
          (char const   */* __restrict  */)"%s\n\n", tmp);
  fprintf(_coverage_fout, "340\n");
  fflush(_coverage_fout);
  i = 0;
  fprintf(_coverage_fout, "341\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "334\n");
    fflush(_coverage_fout);
    if ((unsigned int )stuff[i] != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "333\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "335\n");
    fflush(_coverage_fout);
    fprintf((FILE */* __restrict  */)stderr,
            (char const   */* __restrict  */)"%s\n", stuff[i]);
    fprintf(_coverage_fout, "336\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "342\n");
  fflush(_coverage_fout);
  exit(-1);
}
}
static void ShowStrip(tstrip_t strip , unsigned char *pp , uint32 nrow ,
                      tsize_t scanline ) 
{ register tsize_t cc ;
  unsigned char *tmp ;
  uint32 tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "359\n");
  fflush(_coverage_fout);
  printf((char const   */* __restrict  */)"Strip %lu:\n", (unsigned long )strip);
  fprintf(_coverage_fout, "360\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "353\n");
    fflush(_coverage_fout);
    tmp___0 = nrow;
    fprintf(_coverage_fout, "354\n");
    fflush(_coverage_fout);
    nrow --;
    fprintf(_coverage_fout, "355\n");
    fflush(_coverage_fout);
    if (tmp___0 > 0U) {
      fprintf(_coverage_fout, "343\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "356\n");
    fflush(_coverage_fout);
    cc = 0L;
    fprintf(_coverage_fout, "357\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "347\n");
      fflush(_coverage_fout);
      if (cc < scanline) {
        fprintf(_coverage_fout, "344\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "348\n");
      fflush(_coverage_fout);
      tmp = pp;
      fprintf(_coverage_fout, "349\n");
      fflush(_coverage_fout);
      pp ++;
      fprintf(_coverage_fout, "350\n");
      fflush(_coverage_fout);
      printf((char const   */* __restrict  */)" %02x", *tmp);
      fprintf(_coverage_fout, "351\n");
      fflush(_coverage_fout);
      if ((cc + 1L) % 24L == 0L) {
        fprintf(_coverage_fout, "345\n");
        fflush(_coverage_fout);
        putchar('\n');
      } else {
        fprintf(_coverage_fout, "346\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "352\n");
      fflush(_coverage_fout);
      cc ++;
    }
    fprintf(_coverage_fout, "358\n");
    fflush(_coverage_fout);
    putchar('\n');
  }
  fprintf(_coverage_fout, "361\n");
  fflush(_coverage_fout);
  return;
}
}
void TIFFReadContigStripData(TIFF *tif ) 
{ unsigned char *buf ;
  tsize_t scanline ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  void *tmp___1 ;
  uint32 row ;
  uint32 h ;
  uint32 rowsperstrip ;
  uint32 nrow ;
  uint32 tmp___2 ;
  tstrip_t strip ;
  uint32 tmp___3 ;
  tmsize_t tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "385\n");
  fflush(_coverage_fout);
  tmp = TIFFScanlineSize(tif);
  fprintf(_coverage_fout, "386\n");
  fflush(_coverage_fout);
  scanline = tmp;
  fprintf(_coverage_fout, "387\n");
  fflush(_coverage_fout);
  tmp___0 = TIFFStripSize(tif);
  fprintf(_coverage_fout, "388\n");
  fflush(_coverage_fout);
  tmp___1 = _TIFFmalloc(tmp___0);
  fprintf(_coverage_fout, "389\n");
  fflush(_coverage_fout);
  buf = (unsigned char *)tmp___1;
  fprintf(_coverage_fout, "390\n");
  fflush(_coverage_fout);
  if (buf) {
    fprintf(_coverage_fout, "378\n");
    fflush(_coverage_fout);
    rowsperstrip = 4294967295U;
    fprintf(_coverage_fout, "379\n");
    fflush(_coverage_fout);
    TIFFGetField(tif, 257U, & h);
    fprintf(_coverage_fout, "380\n");
    fflush(_coverage_fout);
    TIFFGetField(tif, 278U, & rowsperstrip);
    fprintf(_coverage_fout, "381\n");
    fflush(_coverage_fout);
    row = 0U;
    fprintf(_coverage_fout, "382\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "370\n");
      fflush(_coverage_fout);
      if (row < h) {
        fprintf(_coverage_fout, "362\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "371\n");
      fflush(_coverage_fout);
      if (row + rowsperstrip > h) {
        fprintf(_coverage_fout, "363\n");
        fflush(_coverage_fout);
        tmp___2 = h - row;
      } else {
        fprintf(_coverage_fout, "364\n");
        fflush(_coverage_fout);
        tmp___2 = rowsperstrip;
      }
      fprintf(_coverage_fout, "372\n");
      fflush(_coverage_fout);
      nrow = tmp___2;
      fprintf(_coverage_fout, "373\n");
      fflush(_coverage_fout);
      tmp___3 = TIFFComputeStrip(tif, row, (unsigned short)0);
      fprintf(_coverage_fout, "374\n");
      fflush(_coverage_fout);
      strip = tmp___3;
      fprintf(_coverage_fout, "375\n");
      fflush(_coverage_fout);
      tmp___4 = TIFFReadEncodedStrip(tif, strip, (void *)buf,
                                     (long )((unsigned long )nrow * (unsigned long )scanline));
      fprintf(_coverage_fout, "376\n");
      fflush(_coverage_fout);
      if (tmp___4 < 0L) {
        fprintf(_coverage_fout, "366\n");
        fflush(_coverage_fout);
        if (stoponerr) {
          break;
        } else {
          fprintf(_coverage_fout, "365\n");
          fflush(_coverage_fout);

        }
      } else {
        fprintf(_coverage_fout, "369\n");
        fflush(_coverage_fout);
        if (showdata) {
          fprintf(_coverage_fout, "367\n");
          fflush(_coverage_fout);
          ShowStrip(strip, buf, nrow, scanline);
        } else {
          fprintf(_coverage_fout, "368\n");
          fflush(_coverage_fout);

        }
      }
      fprintf(_coverage_fout, "377\n");
      fflush(_coverage_fout);
      row += rowsperstrip;
    }
    fprintf(_coverage_fout, "383\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)buf);
  } else {
    fprintf(_coverage_fout, "384\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "391\n");
  fflush(_coverage_fout);
  return;
}
}
void TIFFReadSeparateStripData(TIFF *tif ) 
{ unsigned char *buf ;
  tsize_t scanline ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  void *tmp___1 ;
  uint32 row ;
  uint32 h ;
  uint32 rowsperstrip ;
  tsample_t s ;
  tsample_t samplesperpixel ;
  uint32 nrow ;
  uint32 tmp___2 ;
  tstrip_t strip ;
  uint32 tmp___3 ;
  tmsize_t tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "421\n");
  fflush(_coverage_fout);
  tmp = TIFFScanlineSize(tif);
  fprintf(_coverage_fout, "422\n");
  fflush(_coverage_fout);
  scanline = tmp;
  fprintf(_coverage_fout, "423\n");
  fflush(_coverage_fout);
  tmp___0 = TIFFStripSize(tif);
  fprintf(_coverage_fout, "424\n");
  fflush(_coverage_fout);
  tmp___1 = _TIFFmalloc(tmp___0);
  fprintf(_coverage_fout, "425\n");
  fflush(_coverage_fout);
  buf = (unsigned char *)tmp___1;
  fprintf(_coverage_fout, "426\n");
  fflush(_coverage_fout);
  if (buf) {
    fprintf(_coverage_fout, "413\n");
    fflush(_coverage_fout);
    rowsperstrip = 4294967295U;
    fprintf(_coverage_fout, "414\n");
    fflush(_coverage_fout);
    TIFFGetField(tif, 257U, & h);
    fprintf(_coverage_fout, "415\n");
    fflush(_coverage_fout);
    TIFFGetField(tif, 278U, & rowsperstrip);
    fprintf(_coverage_fout, "416\n");
    fflush(_coverage_fout);
    TIFFGetField(tif, 277U, & samplesperpixel);
    fprintf(_coverage_fout, "417\n");
    fflush(_coverage_fout);
    row = 0U;
    fprintf(_coverage_fout, "418\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "409\n");
      fflush(_coverage_fout);
      if (row < h) {
        fprintf(_coverage_fout, "392\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "410\n");
      fflush(_coverage_fout);
      s = (unsigned short)0;
      fprintf(_coverage_fout, "411\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "401\n");
        fflush(_coverage_fout);
        if ((int )s < (int )samplesperpixel) {
          fprintf(_coverage_fout, "393\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "402\n");
        fflush(_coverage_fout);
        if (row + rowsperstrip > h) {
          fprintf(_coverage_fout, "394\n");
          fflush(_coverage_fout);
          tmp___2 = h - row;
        } else {
          fprintf(_coverage_fout, "395\n");
          fflush(_coverage_fout);
          tmp___2 = rowsperstrip;
        }
        fprintf(_coverage_fout, "403\n");
        fflush(_coverage_fout);
        nrow = tmp___2;
        fprintf(_coverage_fout, "404\n");
        fflush(_coverage_fout);
        tmp___3 = TIFFComputeStrip(tif, row, s);
        fprintf(_coverage_fout, "405\n");
        fflush(_coverage_fout);
        strip = tmp___3;
        fprintf(_coverage_fout, "406\n");
        fflush(_coverage_fout);
        tmp___4 = TIFFReadEncodedStrip(tif, strip, (void *)buf,
                                       (long )((unsigned long )nrow * (unsigned long )scanline));
        fprintf(_coverage_fout, "407\n");
        fflush(_coverage_fout);
        if (tmp___4 < 0L) {
          fprintf(_coverage_fout, "397\n");
          fflush(_coverage_fout);
          if (stoponerr) {
            break;
          } else {
            fprintf(_coverage_fout, "396\n");
            fflush(_coverage_fout);

          }
        } else {
          fprintf(_coverage_fout, "400\n");
          fflush(_coverage_fout);
          if (showdata) {
            fprintf(_coverage_fout, "398\n");
            fflush(_coverage_fout);
            ShowStrip(strip, buf, nrow, scanline);
          } else {
            fprintf(_coverage_fout, "399\n");
            fflush(_coverage_fout);

          }
        }
        fprintf(_coverage_fout, "408\n");
        fflush(_coverage_fout);
        s = (tsample_t )((int )s + 1);
      }
      fprintf(_coverage_fout, "412\n");
      fflush(_coverage_fout);
      row += rowsperstrip;
    }
    fprintf(_coverage_fout, "419\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)buf);
  } else {
    fprintf(_coverage_fout, "420\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "427\n");
  fflush(_coverage_fout);
  return;
}
}
static void ShowTile(uint32 row , uint32 col , tsample_t sample ,
                     unsigned char *pp , uint32 nrow , tsize_t rowsize ) 
{ uint32 cc ;
  unsigned char *tmp ;
  uint32 tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "446\n");
  fflush(_coverage_fout);
  printf((char const   */* __restrict  */)"Tile (%lu,%lu", (unsigned long )row,
         (unsigned long )col);
  fprintf(_coverage_fout, "447\n");
  fflush(_coverage_fout);
  if ((int )sample != 65535) {
    fprintf(_coverage_fout, "428\n");
    fflush(_coverage_fout);
    printf((char const   */* __restrict  */)",%u", sample);
  } else {
    fprintf(_coverage_fout, "429\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "448\n");
  fflush(_coverage_fout);
  printf((char const   */* __restrict  */)"):\n");
  fprintf(_coverage_fout, "449\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "440\n");
    fflush(_coverage_fout);
    tmp___0 = nrow;
    fprintf(_coverage_fout, "441\n");
    fflush(_coverage_fout);
    nrow --;
    fprintf(_coverage_fout, "442\n");
    fflush(_coverage_fout);
    if (tmp___0 > 0U) {
      fprintf(_coverage_fout, "430\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "443\n");
    fflush(_coverage_fout);
    cc = 0U;
    fprintf(_coverage_fout, "444\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "434\n");
      fflush(_coverage_fout);
      if (cc < (unsigned int )rowsize) {
        fprintf(_coverage_fout, "431\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "435\n");
      fflush(_coverage_fout);
      tmp = pp;
      fprintf(_coverage_fout, "436\n");
      fflush(_coverage_fout);
      pp ++;
      fprintf(_coverage_fout, "437\n");
      fflush(_coverage_fout);
      printf((char const   */* __restrict  */)" %02x", *tmp);
      fprintf(_coverage_fout, "438\n");
      fflush(_coverage_fout);
      if ((cc + 1U) % 24U == 0U) {
        fprintf(_coverage_fout, "432\n");
        fflush(_coverage_fout);
        putchar('\n');
      } else {
        fprintf(_coverage_fout, "433\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "439\n");
      fflush(_coverage_fout);
      cc ++;
    }
    fprintf(_coverage_fout, "445\n");
    fflush(_coverage_fout);
    putchar('\n');
  }
  fprintf(_coverage_fout, "450\n");
  fflush(_coverage_fout);
  return;
}
}
void TIFFReadContigTileData(TIFF *tif ) 
{ unsigned char *buf ;
  tsize_t rowsize ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  void *tmp___1 ;
  uint32 tw ;
  uint32 th ;
  uint32 w ;
  uint32 h ;
  uint32 row ;
  uint32 col ;
  tmsize_t tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "474\n");
  fflush(_coverage_fout);
  tmp = TIFFTileRowSize(tif);
  fprintf(_coverage_fout, "475\n");
  fflush(_coverage_fout);
  rowsize = tmp;
  fprintf(_coverage_fout, "476\n");
  fflush(_coverage_fout);
  tmp___0 = TIFFTileSize(tif);
  fprintf(_coverage_fout, "477\n");
  fflush(_coverage_fout);
  tmp___1 = _TIFFmalloc(tmp___0);
  fprintf(_coverage_fout, "478\n");
  fflush(_coverage_fout);
  buf = (unsigned char *)tmp___1;
  fprintf(_coverage_fout, "479\n");
  fflush(_coverage_fout);
  if (buf) {
    fprintf(_coverage_fout, "466\n");
    fflush(_coverage_fout);
    TIFFGetField(tif, 256U, & w);
    fprintf(_coverage_fout, "467\n");
    fflush(_coverage_fout);
    TIFFGetField(tif, 257U, & h);
    fprintf(_coverage_fout, "468\n");
    fflush(_coverage_fout);
    TIFFGetField(tif, 322U, & tw);
    fprintf(_coverage_fout, "469\n");
    fflush(_coverage_fout);
    TIFFGetField(tif, 323U, & th);
    fprintf(_coverage_fout, "470\n");
    fflush(_coverage_fout);
    row = 0U;
    fprintf(_coverage_fout, "471\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "462\n");
      fflush(_coverage_fout);
      if (row < h) {
        fprintf(_coverage_fout, "451\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "463\n");
      fflush(_coverage_fout);
      col = 0U;
      fprintf(_coverage_fout, "464\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "458\n");
        fflush(_coverage_fout);
        if (col < w) {
          fprintf(_coverage_fout, "452\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "459\n");
        fflush(_coverage_fout);
        tmp___2 = TIFFReadTile(tif, (void *)buf, col, row, 0U, (unsigned short)0);
        fprintf(_coverage_fout, "460\n");
        fflush(_coverage_fout);
        if (tmp___2 < 0L) {
          fprintf(_coverage_fout, "454\n");
          fflush(_coverage_fout);
          if (stoponerr) {
            break;
          } else {
            fprintf(_coverage_fout, "453\n");
            fflush(_coverage_fout);

          }
        } else {
          fprintf(_coverage_fout, "457\n");
          fflush(_coverage_fout);
          if (showdata) {
            fprintf(_coverage_fout, "455\n");
            fflush(_coverage_fout);
            ShowTile(row, col, (unsigned short)65535, buf, th, rowsize);
          } else {
            fprintf(_coverage_fout, "456\n");
            fflush(_coverage_fout);

          }
        }
        fprintf(_coverage_fout, "461\n");
        fflush(_coverage_fout);
        col += tw;
      }
      fprintf(_coverage_fout, "465\n");
      fflush(_coverage_fout);
      row += th;
    }
    fprintf(_coverage_fout, "472\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)buf);
  } else {
    fprintf(_coverage_fout, "473\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "480\n");
  fflush(_coverage_fout);
  return;
}
}
void TIFFReadSeparateTileData(TIFF *tif ) 
{ unsigned char *buf ;
  tsize_t rowsize ;
  tmsize_t tmp ;
  tmsize_t tmp___0 ;
  void *tmp___1 ;
  uint32 tw ;
  uint32 th ;
  uint32 w ;
  uint32 h ;
  uint32 row ;
  uint32 col ;
  tsample_t s ;
  tsample_t samplesperpixel ;
  tmsize_t tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "510\n");
  fflush(_coverage_fout);
  tmp = TIFFTileRowSize(tif);
  fprintf(_coverage_fout, "511\n");
  fflush(_coverage_fout);
  rowsize = tmp;
  fprintf(_coverage_fout, "512\n");
  fflush(_coverage_fout);
  tmp___0 = TIFFTileSize(tif);
  fprintf(_coverage_fout, "513\n");
  fflush(_coverage_fout);
  tmp___1 = _TIFFmalloc(tmp___0);
  fprintf(_coverage_fout, "514\n");
  fflush(_coverage_fout);
  buf = (unsigned char *)tmp___1;
  fprintf(_coverage_fout, "515\n");
  fflush(_coverage_fout);
  if (buf) {
    fprintf(_coverage_fout, "501\n");
    fflush(_coverage_fout);
    TIFFGetField(tif, 256U, & w);
    fprintf(_coverage_fout, "502\n");
    fflush(_coverage_fout);
    TIFFGetField(tif, 257U, & h);
    fprintf(_coverage_fout, "503\n");
    fflush(_coverage_fout);
    TIFFGetField(tif, 322U, & tw);
    fprintf(_coverage_fout, "504\n");
    fflush(_coverage_fout);
    TIFFGetField(tif, 323U, & th);
    fprintf(_coverage_fout, "505\n");
    fflush(_coverage_fout);
    TIFFGetField(tif, 277U, & samplesperpixel);
    fprintf(_coverage_fout, "506\n");
    fflush(_coverage_fout);
    row = 0U;
    fprintf(_coverage_fout, "507\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "497\n");
      fflush(_coverage_fout);
      if (row < h) {
        fprintf(_coverage_fout, "481\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "498\n");
      fflush(_coverage_fout);
      col = 0U;
      fprintf(_coverage_fout, "499\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "493\n");
        fflush(_coverage_fout);
        if (col < w) {
          fprintf(_coverage_fout, "482\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "494\n");
        fflush(_coverage_fout);
        s = (unsigned short)0;
        fprintf(_coverage_fout, "495\n");
        fflush(_coverage_fout);
        while (1) {
          fprintf(_coverage_fout, "489\n");
          fflush(_coverage_fout);
          if ((int )s < (int )samplesperpixel) {
            fprintf(_coverage_fout, "483\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
          fprintf(_coverage_fout, "490\n");
          fflush(_coverage_fout);
          tmp___2 = TIFFReadTile(tif, (void *)buf, col, row, 0U, s);
          fprintf(_coverage_fout, "491\n");
          fflush(_coverage_fout);
          if (tmp___2 < 0L) {
            fprintf(_coverage_fout, "485\n");
            fflush(_coverage_fout);
            if (stoponerr) {
              break;
            } else {
              fprintf(_coverage_fout, "484\n");
              fflush(_coverage_fout);

            }
          } else {
            fprintf(_coverage_fout, "488\n");
            fflush(_coverage_fout);
            if (showdata) {
              fprintf(_coverage_fout, "486\n");
              fflush(_coverage_fout);
              ShowTile(row, col, s, buf, th, rowsize);
            } else {
              fprintf(_coverage_fout, "487\n");
              fflush(_coverage_fout);

            }
          }
          fprintf(_coverage_fout, "492\n");
          fflush(_coverage_fout);
          s = (tsample_t )((int )s + 1);
        }
        fprintf(_coverage_fout, "496\n");
        fflush(_coverage_fout);
        col += tw;
      }
      fprintf(_coverage_fout, "500\n");
      fflush(_coverage_fout);
      row += th;
    }
    fprintf(_coverage_fout, "508\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)buf);
  } else {
    fprintf(_coverage_fout, "509\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "516\n");
  fflush(_coverage_fout);
  return;
}
}
void TIFFReadData(TIFF *tif ) 
{ uint16 config ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "523\n");
  fflush(_coverage_fout);
  TIFFGetField(tif, 284U, & config);
  fprintf(_coverage_fout, "524\n");
  fflush(_coverage_fout);
  tmp = TIFFIsTiled(tif);
  fprintf(_coverage_fout, "525\n");
  fflush(_coverage_fout);
  if (tmp) {
    fprintf(_coverage_fout, "519\n");
    fflush(_coverage_fout);
    if ((int )config == 1) {
      fprintf(_coverage_fout, "517\n");
      fflush(_coverage_fout);
      TIFFReadContigTileData(tif);
    } else {
      fprintf(_coverage_fout, "518\n");
      fflush(_coverage_fout);
      TIFFReadSeparateTileData(tif);
    }
  } else {
    fprintf(_coverage_fout, "522\n");
    fflush(_coverage_fout);
    if ((int )config == 1) {
      fprintf(_coverage_fout, "520\n");
      fflush(_coverage_fout);
      TIFFReadContigStripData(tif);
    } else {
      fprintf(_coverage_fout, "521\n");
      fflush(_coverage_fout);
      TIFFReadSeparateStripData(tif);
    }
  }
  fprintf(_coverage_fout, "526\n");
  fflush(_coverage_fout);
  return;
}
}
static void ShowRawBytes(unsigned char *pp , uint32 n ) 
{ uint32 i ;
  unsigned char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "536\n");
  fflush(_coverage_fout);
  i = 0U;
  fprintf(_coverage_fout, "537\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "530\n");
    fflush(_coverage_fout);
    if (i < n) {
      fprintf(_coverage_fout, "527\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "531\n");
    fflush(_coverage_fout);
    tmp = pp;
    fprintf(_coverage_fout, "532\n");
    fflush(_coverage_fout);
    pp ++;
    fprintf(_coverage_fout, "533\n");
    fflush(_coverage_fout);
    printf((char const   */* __restrict  */)" %02x", *tmp);
    fprintf(_coverage_fout, "534\n");
    fflush(_coverage_fout);
    if ((i + 1U) % 24U == 0U) {
      fprintf(_coverage_fout, "528\n");
      fflush(_coverage_fout);
      printf((char const   */* __restrict  */)"\n ");
    } else {
      fprintf(_coverage_fout, "529\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "535\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "538\n");
  fflush(_coverage_fout);
  putchar('\n');
  fprintf(_coverage_fout, "539\n");
  fflush(_coverage_fout);
  return;
}
}
static void ShowRawWords(uint16 *pp , uint32 n ) 
{ uint32 i ;
  uint16 *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "549\n");
  fflush(_coverage_fout);
  i = 0U;
  fprintf(_coverage_fout, "550\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "543\n");
    fflush(_coverage_fout);
    if (i < n) {
      fprintf(_coverage_fout, "540\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "544\n");
    fflush(_coverage_fout);
    tmp = pp;
    fprintf(_coverage_fout, "545\n");
    fflush(_coverage_fout);
    pp ++;
    fprintf(_coverage_fout, "546\n");
    fflush(_coverage_fout);
    printf((char const   */* __restrict  */)" %04x", *tmp);
    fprintf(_coverage_fout, "547\n");
    fflush(_coverage_fout);
    if ((i + 1U) % 15U == 0U) {
      fprintf(_coverage_fout, "541\n");
      fflush(_coverage_fout);
      printf((char const   */* __restrict  */)"\n ");
    } else {
      fprintf(_coverage_fout, "542\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "548\n");
    fflush(_coverage_fout);
    i ++;
  }
  fprintf(_coverage_fout, "551\n");
  fflush(_coverage_fout);
  putchar('\n');
  fprintf(_coverage_fout, "552\n");
  fflush(_coverage_fout);
  return;
}
}
void TIFFReadRawData(TIFF *tif , int bitrev ) 
{ tstrip_t nstrips ;
  uint32 tmp ;
  char const   *what ;
  int tmp___0 ;
  char const   *tmp___1 ;
  int tmp___2 ;
  uint64 *stripbc ;
  uint32 bufsize ;
  tdata_t buf ;
  void *tmp___3 ;
  tstrip_t s ;
  tmsize_t tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "588\n");
  fflush(_coverage_fout);
  tmp = TIFFNumberOfStrips(tif);
  fprintf(_coverage_fout, "589\n");
  fflush(_coverage_fout);
  nstrips = tmp;
  fprintf(_coverage_fout, "590\n");
  fflush(_coverage_fout);
  tmp___2 = TIFFIsTiled(tif);
  fprintf(_coverage_fout, "591\n");
  fflush(_coverage_fout);
  if (tmp___2) {
    fprintf(_coverage_fout, "553\n");
    fflush(_coverage_fout);
    tmp___1 = "Tile";
  } else {
    fprintf(_coverage_fout, "554\n");
    fflush(_coverage_fout);
    tmp___1 = "Strip";
  }
  fprintf(_coverage_fout, "592\n");
  fflush(_coverage_fout);
  what = tmp___1;
  fprintf(_coverage_fout, "593\n");
  fflush(_coverage_fout);
  TIFFGetField(tif, 279U, & stripbc);
  fprintf(_coverage_fout, "594\n");
  fflush(_coverage_fout);
  if (nstrips > 0U) {
    fprintf(_coverage_fout, "581\n");
    fflush(_coverage_fout);
    bufsize = (unsigned int )*(stripbc + 0);
    fprintf(_coverage_fout, "582\n");
    fflush(_coverage_fout);
    tmp___3 = _TIFFmalloc((long )bufsize);
    fprintf(_coverage_fout, "583\n");
    fflush(_coverage_fout);
    buf = tmp___3;
    fprintf(_coverage_fout, "584\n");
    fflush(_coverage_fout);
    s = 0U;
    fprintf(_coverage_fout, "585\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "573\n");
      fflush(_coverage_fout);
      if (s < nstrips) {
        fprintf(_coverage_fout, "555\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "574\n");
      fflush(_coverage_fout);
      if (*(stripbc + s) > (uint64 )bufsize) {
        fprintf(_coverage_fout, "556\n");
        fflush(_coverage_fout);
        buf = _TIFFrealloc(buf, (long )*(stripbc + s));
        fprintf(_coverage_fout, "557\n");
        fflush(_coverage_fout);
        bufsize = (unsigned int )*(stripbc + s);
      } else {
        fprintf(_coverage_fout, "558\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "575\n");
      fflush(_coverage_fout);
      if ((unsigned int )buf == (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "559\n");
        fflush(_coverage_fout);
        fprintf((FILE */* __restrict  */)stderr,
                (char const   */* __restrict  */)"Cannot allocate buffer to read strip %lu\n",
                (unsigned long )s);
        break;
      } else {
        fprintf(_coverage_fout, "560\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "576\n");
      fflush(_coverage_fout);
      tmp___4 = TIFFReadRawStrip(tif, s, buf, (long )*(stripbc + s));
      fprintf(_coverage_fout, "577\n");
      fflush(_coverage_fout);
      if (tmp___4 < 0L) {
        fprintf(_coverage_fout, "562\n");
        fflush(_coverage_fout);
        fprintf((FILE */* __restrict  */)stderr,
                (char const   */* __restrict  */)"Error reading strip %lu\n",
                (unsigned long )s);
        fprintf(_coverage_fout, "563\n");
        fflush(_coverage_fout);
        if (stoponerr) {
          break;
        } else {
          fprintf(_coverage_fout, "561\n");
          fflush(_coverage_fout);

        }
      } else {
        fprintf(_coverage_fout, "572\n");
        fflush(_coverage_fout);
        if (showdata) {
          fprintf(_coverage_fout, "569\n");
          fflush(_coverage_fout);
          if (bitrev) {
            fprintf(_coverage_fout, "564\n");
            fflush(_coverage_fout);
            TIFFReverseBits((uint8 *)buf, (long )*(stripbc + s));
            fprintf(_coverage_fout, "565\n");
            fflush(_coverage_fout);
            printf((char const   */* __restrict  */)"%s %lu: (bit reversed)\n ",
                   what, (unsigned long )s);
          } else {
            fprintf(_coverage_fout, "566\n");
            fflush(_coverage_fout);
            printf((char const   */* __restrict  */)"%s %lu:\n ", what,
                   (unsigned long )s);
          }
          fprintf(_coverage_fout, "570\n");
          fflush(_coverage_fout);
          if (showwords) {
            fprintf(_coverage_fout, "567\n");
            fflush(_coverage_fout);
            ShowRawWords((uint16 *)buf, (unsigned int )*(stripbc + s) >> 1);
          } else {
            fprintf(_coverage_fout, "568\n");
            fflush(_coverage_fout);
            ShowRawBytes((unsigned char *)buf, (unsigned int )*(stripbc + s));
          }
        } else {
          fprintf(_coverage_fout, "571\n");
          fflush(_coverage_fout);

        }
      }
      fprintf(_coverage_fout, "578\n");
      fflush(_coverage_fout);
      s ++;
    }
    fprintf(_coverage_fout, "586\n");
    fflush(_coverage_fout);
    if ((unsigned int )buf != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "579\n");
      fflush(_coverage_fout);
      _TIFFfree(buf);
    } else {
      fprintf(_coverage_fout, "580\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "587\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "595\n");
  fflush(_coverage_fout);
  return;
}
}
static void tiffinfo(TIFF *tif , uint16 order , long flags ) 
{ uint16 o ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-d39db2b-4cd598c/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "606\n");
  fflush(_coverage_fout);
  TIFFPrintDirectory(tif, stdout, flags);
  fprintf(_coverage_fout, "607\n");
  fflush(_coverage_fout);
  if (! readdata) {
    fprintf(_coverage_fout, "596\n");
    fflush(_coverage_fout);
    return;
  } else {
    fprintf(_coverage_fout, "597\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "608\n");
  fflush(_coverage_fout);
  if (rawdata) {
    fprintf(_coverage_fout, "601\n");
    fflush(_coverage_fout);
    if (order) {
      fprintf(_coverage_fout, "598\n");
      fflush(_coverage_fout);
      TIFFGetFieldDefaulted(tif, 266U, & o);
      fprintf(_coverage_fout, "599\n");
      fflush(_coverage_fout);
      TIFFReadRawData(tif, (int )o != (int )order);
    } else {
      fprintf(_coverage_fout, "600\n");
      fflush(_coverage_fout);
      TIFFReadRawData(tif, 0);
    }
  } else {
    fprintf(_coverage_fout, "604\n");
    fflush(_coverage_fout);
    if (order) {
      fprintf(_coverage_fout, "602\n");
      fflush(_coverage_fout);
      TIFFSetField(tif, 266U, order);
    } else {
      fprintf(_coverage_fout, "603\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "605\n");
    fflush(_coverage_fout);
    TIFFReadData(tif);
  }
  fprintf(_coverage_fout, "609\n");
  fflush(_coverage_fout);
  return;
}
}
