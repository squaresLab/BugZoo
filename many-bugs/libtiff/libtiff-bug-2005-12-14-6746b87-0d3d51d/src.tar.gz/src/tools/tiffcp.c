struct _IO_FILE;
struct _IO_FILE *_coverage_fout  ;
typedef unsigned int size_t;
typedef unsigned char __u_char;
typedef unsigned short __u_short;
typedef unsigned int __u_int;
typedef unsigned long __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;
typedef long long __quad_t;
typedef unsigned long long __u_quad_t;
typedef __u_quad_t __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef __u_quad_t __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long __off_t;
typedef __quad_t __off64_t;
typedef int __pid_t;
struct __anonstruct___fsid_t_1 {
   int __val[2] ;
};
typedef struct __anonstruct___fsid_t_1 __fsid_t;
typedef long __clock_t;
typedef unsigned long __rlim_t;
typedef __u_quad_t __rlim64_t;
typedef unsigned int __id_t;
typedef long __time_t;
typedef unsigned int __useconds_t;
typedef long __suseconds_t;
typedef int __daddr_t;
typedef long __swblk_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void *__timer_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef __quad_t __blkcnt64_t;
typedef unsigned long __fsblkcnt_t;
typedef __u_quad_t __fsblkcnt64_t;
typedef unsigned long __fsfilcnt_t;
typedef __u_quad_t __fsfilcnt64_t;
typedef int __ssize_t;
typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;
typedef int __intptr_t;
typedef unsigned int __socklen_t;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_3 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_2 {
   int __count ;
   union __anonunion___value_3 __value ;
};
typedef struct __anonstruct___mbstate_t_2 __mbstate_t;
struct __anonstruct__G_fpos_t_4 {
   __off_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos_t_4 _G_fpos_t;
struct __anonstruct__G_fpos64_t_5 {
   __off64_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos64_t_5 _G_fpos64_t;
typedef short _G_int16_t;
typedef int _G_int32_t;
typedef unsigned short _G_uint16_t;
typedef unsigned int _G_uint32_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_jump_t;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
enum __codecvt_result {
    __codecvt_ok = 0,
    __codecvt_partial = 1,
    __codecvt_error = 2,
    __codecvt_noconv = 3
} ;
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15U * sizeof(int ) - 4U * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
struct _IO_FILE_plus;
typedef __ssize_t __io_read_fn(void *__cookie , char *__buf , size_t __nbytes );
typedef __ssize_t __io_write_fn(void *__cookie , char const   *__buf ,
                                size_t __n );
typedef int __io_seek_fn(void *__cookie , __off64_t *__pos , int __w );
typedef int __io_close_fn(void *__cookie );
typedef __gnuc_va_list va_list;
typedef __off64_t off_t;
typedef __ssize_t ssize_t;
typedef _G_fpos64_t fpos_t;
typedef long wchar_t;
struct __anonstruct___wait_terminated_6 {
   unsigned int __w_termsig : 7 ;
   unsigned int __w_coredump : 1 ;
   unsigned int __w_retcode : 8 ;
   unsigned int  : 16 ;
};
struct __anonstruct___wait_stopped_7 {
   unsigned int __w_stopval : 8 ;
   unsigned int __w_stopsig : 8 ;
   unsigned int  : 16 ;
};
union wait {
   int w_status ;
   struct __anonstruct___wait_terminated_6 __wait_terminated ;
   struct __anonstruct___wait_stopped_7 __wait_stopped ;
};
union __anonunion___WAIT_STATUS_8 {
   union wait *__uptr ;
   int *__iptr ;
};
typedef union __anonunion___WAIT_STATUS_8  __attribute__((__transparent_union__)) __WAIT_STATUS;
struct __anonstruct_div_t_9 {
   int quot ;
   int rem ;
};
typedef struct __anonstruct_div_t_9 div_t;
struct __anonstruct_ldiv_t_10 {
   long quot ;
   long rem ;
};
typedef struct __anonstruct_ldiv_t_10 ldiv_t;
struct __anonstruct_lldiv_t_11 {
   long long quot ;
   long long rem ;
};
typedef struct __anonstruct_lldiv_t_11 lldiv_t;
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;
typedef __loff_t loff_t;
typedef __ino64_t ino_t;
typedef __dev_t dev_t;
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __nlink_t nlink_t;
typedef __uid_t uid_t;
typedef __pid_t pid_t;
typedef __id_t id_t;
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;
typedef __key_t key_t;
typedef __clock_t clock_t;
typedef __time_t time_t;
typedef __clockid_t clockid_t;
typedef __timer_t timer_t;
typedef unsigned long ulong;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char u_int8_t;
typedef unsigned short u_int16_t;
typedef unsigned int u_int32_t;
typedef unsigned long long u_int64_t;
typedef int register_t;
typedef int __sig_atomic_t;
struct __anonstruct___sigset_t_12 {
   unsigned long __val[1024U / (8U * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_12 __sigset_t;
typedef __sigset_t sigset_t;
struct timespec {
   __time_t tv_sec ;
   long tv_nsec ;
};
struct timeval {
   __time_t tv_sec ;
   __suseconds_t tv_usec ;
};
typedef __suseconds_t suseconds_t;
typedef long __fd_mask;
struct __anonstruct_fd_set_13 {
   __fd_mask __fds_bits[1024 / (8 * (int )sizeof(__fd_mask ))] ;
};
typedef struct __anonstruct_fd_set_13 fd_set;
typedef __fd_mask fd_mask;
typedef __blksize_t blksize_t;
typedef __blkcnt64_t blkcnt_t;
typedef __fsblkcnt64_t fsblkcnt_t;
typedef __fsfilcnt64_t fsfilcnt_t;
typedef unsigned long pthread_t;
union __anonunion_pthread_attr_t_14 {
   char __size[36] ;
   long __align ;
};
typedef union __anonunion_pthread_attr_t_14 pthread_attr_t;
struct __pthread_internal_slist {
   struct __pthread_internal_slist *__next ;
};
typedef struct __pthread_internal_slist __pthread_slist_t;
union __anonunion____missing_field_name_16 {
   int __spins ;
   __pthread_slist_t __list ;
};
struct __pthread_mutex_s {
   int __lock ;
   unsigned int __count ;
   int __owner ;
   int __kind ;
   unsigned int __nusers ;
   union __anonunion____missing_field_name_16 __annonCompField1 ;
};
union __anonunion_pthread_mutex_t_15 {
   struct __pthread_mutex_s __data ;
   char __size[24] ;
   long __align ;
};
typedef union __anonunion_pthread_mutex_t_15 pthread_mutex_t;
union __anonunion_pthread_mutexattr_t_17 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_mutexattr_t_17 pthread_mutexattr_t;
struct __anonstruct___data_19 {
   int __lock ;
   unsigned int __futex ;
   unsigned long long __total_seq ;
   unsigned long long __wakeup_seq ;
   unsigned long long __woken_seq ;
   void *__mutex ;
   unsigned int __nwaiters ;
   unsigned int __broadcast_seq ;
};
union __anonunion_pthread_cond_t_18 {
   struct __anonstruct___data_19 __data ;
   char __size[48] ;
   long long __align ;
};
typedef union __anonunion_pthread_cond_t_18 pthread_cond_t;
union __anonunion_pthread_condattr_t_20 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_condattr_t_20 pthread_condattr_t;
typedef unsigned int pthread_key_t;
typedef int pthread_once_t;
struct __anonstruct___data_22 {
   int __lock ;
   unsigned int __nr_readers ;
   unsigned int __readers_wakeup ;
   unsigned int __writer_wakeup ;
   unsigned int __nr_readers_queued ;
   unsigned int __nr_writers_queued ;
   unsigned char __flags ;
   unsigned char __shared ;
   unsigned char __pad1 ;
   unsigned char __pad2 ;
   int __writer ;
};
union __anonunion_pthread_rwlock_t_21 {
   struct __anonstruct___data_22 __data ;
   char __size[32] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlock_t_21 pthread_rwlock_t;
union __anonunion_pthread_rwlockattr_t_23 {
   char __size[8] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlockattr_t_23 pthread_rwlockattr_t;
typedef int volatile   pthread_spinlock_t;
union __anonunion_pthread_barrier_t_24 {
   char __size[20] ;
   long __align ;
};
typedef union __anonunion_pthread_barrier_t_24 pthread_barrier_t;
union __anonunion_pthread_barrierattr_t_25 {
   char __size[4] ;
   int __align ;
};
typedef union __anonunion_pthread_barrierattr_t_25 pthread_barrierattr_t;
struct random_data {
   int32_t *fptr ;
   int32_t *rptr ;
   int32_t *state ;
   int rand_type ;
   int rand_deg ;
   int rand_sep ;
   int32_t *end_ptr ;
};
struct drand48_data {
   unsigned short __x[3] ;
   unsigned short __old_x[3] ;
   unsigned short __c ;
   unsigned short __init ;
   unsigned long long __a ;
};
typedef int (*__compar_fn_t)(void const   * , void const   * );
struct __locale_data;
struct __locale_struct {
   struct __locale_data *__locales[13] ;
   unsigned short const   *__ctype_b ;
   int const   *__ctype_tolower ;
   int const   *__ctype_toupper ;
   char const   *__names[13] ;
};
typedef struct __locale_struct *__locale_t;
typedef __locale_t locale_t;
enum __anonenum_26 {
    _ISupper = 256,
    _ISlower = 512,
    _ISalpha = 1024,
    _ISdigit = 2048,
    _ISxdigit = 4096,
    _ISspace = 8192,
    _ISprint = 16384,
    _ISgraph = 32768,
    _ISblank = 1,
    _IScntrl = 2,
    _ISpunct = 4,
    _ISalnum = 8
} ;
typedef __useconds_t useconds_t;
typedef __intptr_t intptr_t;
typedef __socklen_t socklen_t;
enum __anonenum_27 {
    _PC_LINK_MAX = 0,
    _PC_MAX_CANON = 1,
    _PC_MAX_INPUT = 2,
    _PC_NAME_MAX = 3,
    _PC_PATH_MAX = 4,
    _PC_PIPE_BUF = 5,
    _PC_CHOWN_RESTRICTED = 6,
    _PC_NO_TRUNC = 7,
    _PC_VDISABLE = 8,
    _PC_SYNC_IO = 9,
    _PC_ASYNC_IO = 10,
    _PC_PRIO_IO = 11,
    _PC_SOCK_MAXBUF = 12,
    _PC_FILESIZEBITS = 13,
    _PC_REC_INCR_XFER_SIZE = 14,
    _PC_REC_MAX_XFER_SIZE = 15,
    _PC_REC_MIN_XFER_SIZE = 16,
    _PC_REC_XFER_ALIGN = 17,
    _PC_ALLOC_SIZE_MIN = 18,
    _PC_SYMLINK_MAX = 19,
    _PC_2_SYMLINKS = 20
} ;
enum __anonenum_28 {
    _SC_ARG_MAX = 0,
    _SC_CHILD_MAX = 1,
    _SC_CLK_TCK = 2,
    _SC_NGROUPS_MAX = 3,
    _SC_OPEN_MAX = 4,
    _SC_STREAM_MAX = 5,
    _SC_TZNAME_MAX = 6,
    _SC_JOB_CONTROL = 7,
    _SC_SAVED_IDS = 8,
    _SC_REALTIME_SIGNALS = 9,
    _SC_PRIORITY_SCHEDULING = 10,
    _SC_TIMERS = 11,
    _SC_ASYNCHRONOUS_IO = 12,
    _SC_PRIORITIZED_IO = 13,
    _SC_SYNCHRONIZED_IO = 14,
    _SC_FSYNC = 15,
    _SC_MAPPED_FILES = 16,
    _SC_MEMLOCK = 17,
    _SC_MEMLOCK_RANGE = 18,
    _SC_MEMORY_PROTECTION = 19,
    _SC_MESSAGE_PASSING = 20,
    _SC_SEMAPHORES = 21,
    _SC_SHARED_MEMORY_OBJECTS = 22,
    _SC_AIO_LISTIO_MAX = 23,
    _SC_AIO_MAX = 24,
    _SC_AIO_PRIO_DELTA_MAX = 25,
    _SC_DELAYTIMER_MAX = 26,
    _SC_MQ_OPEN_MAX = 27,
    _SC_MQ_PRIO_MAX = 28,
    _SC_VERSION = 29,
    _SC_PAGESIZE = 30,
    _SC_RTSIG_MAX = 31,
    _SC_SEM_NSEMS_MAX = 32,
    _SC_SEM_VALUE_MAX = 33,
    _SC_SIGQUEUE_MAX = 34,
    _SC_TIMER_MAX = 35,
    _SC_BC_BASE_MAX = 36,
    _SC_BC_DIM_MAX = 37,
    _SC_BC_SCALE_MAX = 38,
    _SC_BC_STRING_MAX = 39,
    _SC_COLL_WEIGHTS_MAX = 40,
    _SC_EQUIV_CLASS_MAX = 41,
    _SC_EXPR_NEST_MAX = 42,
    _SC_LINE_MAX = 43,
    _SC_RE_DUP_MAX = 44,
    _SC_CHARCLASS_NAME_MAX = 45,
    _SC_2_VERSION = 46,
    _SC_2_C_BIND = 47,
    _SC_2_C_DEV = 48,
    _SC_2_FORT_DEV = 49,
    _SC_2_FORT_RUN = 50,
    _SC_2_SW_DEV = 51,
    _SC_2_LOCALEDEF = 52,
    _SC_PII = 53,
    _SC_PII_XTI = 54,
    _SC_PII_SOCKET = 55,
    _SC_PII_INTERNET = 56,
    _SC_PII_OSI = 57,
    _SC_POLL = 58,
    _SC_SELECT = 59,
    _SC_UIO_MAXIOV = 60,
    _SC_IOV_MAX = 60,
    _SC_PII_INTERNET_STREAM = 61,
    _SC_PII_INTERNET_DGRAM = 62,
    _SC_PII_OSI_COTS = 63,
    _SC_PII_OSI_CLTS = 64,
    _SC_PII_OSI_M = 65,
    _SC_T_IOV_MAX = 66,
    _SC_THREADS = 67,
    _SC_THREAD_SAFE_FUNCTIONS = 68,
    _SC_GETGR_R_SIZE_MAX = 69,
    _SC_GETPW_R_SIZE_MAX = 70,
    _SC_LOGIN_NAME_MAX = 71,
    _SC_TTY_NAME_MAX = 72,
    _SC_THREAD_DESTRUCTOR_ITERATIONS = 73,
    _SC_THREAD_KEYS_MAX = 74,
    _SC_THREAD_STACK_MIN = 75,
    _SC_THREAD_THREADS_MAX = 76,
    _SC_THREAD_ATTR_STACKADDR = 77,
    _SC_THREAD_ATTR_STACKSIZE = 78,
    _SC_THREAD_PRIORITY_SCHEDULING = 79,
    _SC_THREAD_PRIO_INHERIT = 80,
    _SC_THREAD_PRIO_PROTECT = 81,
    _SC_THREAD_PROCESS_SHARED = 82,
    _SC_NPROCESSORS_CONF = 83,
    _SC_NPROCESSORS_ONLN = 84,
    _SC_PHYS_PAGES = 85,
    _SC_AVPHYS_PAGES = 86,
    _SC_ATEXIT_MAX = 87,
    _SC_PASS_MAX = 88,
    _SC_XOPEN_VERSION = 89,
    _SC_XOPEN_XCU_VERSION = 90,
    _SC_XOPEN_UNIX = 91,
    _SC_XOPEN_CRYPT = 92,
    _SC_XOPEN_ENH_I18N = 93,
    _SC_XOPEN_SHM = 94,
    _SC_2_CHAR_TERM = 95,
    _SC_2_C_VERSION = 96,
    _SC_2_UPE = 97,
    _SC_XOPEN_XPG2 = 98,
    _SC_XOPEN_XPG3 = 99,
    _SC_XOPEN_XPG4 = 100,
    _SC_CHAR_BIT = 101,
    _SC_CHAR_MAX = 102,
    _SC_CHAR_MIN = 103,
    _SC_INT_MAX = 104,
    _SC_INT_MIN = 105,
    _SC_LONG_BIT = 106,
    _SC_WORD_BIT = 107,
    _SC_MB_LEN_MAX = 108,
    _SC_NZERO = 109,
    _SC_SSIZE_MAX = 110,
    _SC_SCHAR_MAX = 111,
    _SC_SCHAR_MIN = 112,
    _SC_SHRT_MAX = 113,
    _SC_SHRT_MIN = 114,
    _SC_UCHAR_MAX = 115,
    _SC_UINT_MAX = 116,
    _SC_ULONG_MAX = 117,
    _SC_USHRT_MAX = 118,
    _SC_NL_ARGMAX = 119,
    _SC_NL_LANGMAX = 120,
    _SC_NL_MSGMAX = 121,
    _SC_NL_NMAX = 122,
    _SC_NL_SETMAX = 123,
    _SC_NL_TEXTMAX = 124,
    _SC_XBS5_ILP32_OFF32 = 125,
    _SC_XBS5_ILP32_OFFBIG = 126,
    _SC_XBS5_LP64_OFF64 = 127,
    _SC_XBS5_LPBIG_OFFBIG = 128,
    _SC_XOPEN_LEGACY = 129,
    _SC_XOPEN_REALTIME = 130,
    _SC_XOPEN_REALTIME_THREADS = 131,
    _SC_ADVISORY_INFO = 132,
    _SC_BARRIERS = 133,
    _SC_BASE = 134,
    _SC_C_LANG_SUPPORT = 135,
    _SC_C_LANG_SUPPORT_R = 136,
    _SC_CLOCK_SELECTION = 137,
    _SC_CPUTIME = 138,
    _SC_THREAD_CPUTIME = 139,
    _SC_DEVICE_IO = 140,
    _SC_DEVICE_SPECIFIC = 141,
    _SC_DEVICE_SPECIFIC_R = 142,
    _SC_FD_MGMT = 143,
    _SC_FIFO = 144,
    _SC_PIPE = 145,
    _SC_FILE_ATTRIBUTES = 146,
    _SC_FILE_LOCKING = 147,
    _SC_FILE_SYSTEM = 148,
    _SC_MONOTONIC_CLOCK = 149,
    _SC_MULTI_PROCESS = 150,
    _SC_SINGLE_PROCESS = 151,
    _SC_NETWORKING = 152,
    _SC_READER_WRITER_LOCKS = 153,
    _SC_SPIN_LOCKS = 154,
    _SC_REGEXP = 155,
    _SC_REGEX_VERSION = 156,
    _SC_SHELL = 157,
    _SC_SIGNALS = 158,
    _SC_SPAWN = 159,
    _SC_SPORADIC_SERVER = 160,
    _SC_THREAD_SPORADIC_SERVER = 161,
    _SC_SYSTEM_DATABASE = 162,
    _SC_SYSTEM_DATABASE_R = 163,
    _SC_TIMEOUTS = 164,
    _SC_TYPED_MEMORY_OBJECTS = 165,
    _SC_USER_GROUPS = 166,
    _SC_USER_GROUPS_R = 167,
    _SC_2_PBS = 168,
    _SC_2_PBS_ACCOUNTING = 169,
    _SC_2_PBS_LOCATE = 170,
    _SC_2_PBS_MESSAGE = 171,
    _SC_2_PBS_TRACK = 172,
    _SC_SYMLOOP_MAX = 173,
    _SC_STREAMS = 174,
    _SC_2_PBS_CHECKPOINT = 175,
    _SC_V6_ILP32_OFF32 = 176,
    _SC_V6_ILP32_OFFBIG = 177,
    _SC_V6_LP64_OFF64 = 178,
    _SC_V6_LPBIG_OFFBIG = 179,
    _SC_HOST_NAME_MAX = 180,
    _SC_TRACE = 181,
    _SC_TRACE_EVENT_FILTER = 182,
    _SC_TRACE_INHERIT = 183,
    _SC_TRACE_LOG = 184,
    _SC_LEVEL1_ICACHE_SIZE = 185,
    _SC_LEVEL1_ICACHE_ASSOC = 186,
    _SC_LEVEL1_ICACHE_LINESIZE = 187,
    _SC_LEVEL1_DCACHE_SIZE = 188,
    _SC_LEVEL1_DCACHE_ASSOC = 189,
    _SC_LEVEL1_DCACHE_LINESIZE = 190,
    _SC_LEVEL2_CACHE_SIZE = 191,
    _SC_LEVEL2_CACHE_ASSOC = 192,
    _SC_LEVEL2_CACHE_LINESIZE = 193,
    _SC_LEVEL3_CACHE_SIZE = 194,
    _SC_LEVEL3_CACHE_ASSOC = 195,
    _SC_LEVEL3_CACHE_LINESIZE = 196,
    _SC_LEVEL4_CACHE_SIZE = 197,
    _SC_LEVEL4_CACHE_ASSOC = 198,
    _SC_LEVEL4_CACHE_LINESIZE = 199,
    _SC_IPV6 = 235,
    _SC_RAW_SOCKETS = 236,
    _SC_V7_ILP32_OFF32 = 237,
    _SC_V7_ILP32_OFFBIG = 238,
    _SC_V7_LP64_OFF64 = 239,
    _SC_V7_LPBIG_OFFBIG = 240,
    _SC_SS_REPL_MAX = 241,
    _SC_TRACE_EVENT_NAME_MAX = 242,
    _SC_TRACE_NAME_MAX = 243,
    _SC_TRACE_SYS_MAX = 244,
    _SC_TRACE_USER_EVENT_MAX = 245,
    _SC_XOPEN_STREAMS = 246,
    _SC_THREAD_ROBUST_PRIO_INHERIT = 247,
    _SC_THREAD_ROBUST_PRIO_PROTECT = 248
} ;
enum __anonenum_29 {
    _CS_PATH = 0,
    _CS_V6_WIDTH_RESTRICTED_ENVS = 1,
    _CS_GNU_LIBC_VERSION = 2,
    _CS_GNU_LIBPTHREAD_VERSION = 3,
    _CS_V5_WIDTH_RESTRICTED_ENVS = 4,
    _CS_V7_WIDTH_RESTRICTED_ENVS = 5,
    _CS_LFS_CFLAGS = 1000,
    _CS_LFS_LDFLAGS = 1001,
    _CS_LFS_LIBS = 1002,
    _CS_LFS_LINTFLAGS = 1003,
    _CS_LFS64_CFLAGS = 1004,
    _CS_LFS64_LDFLAGS = 1005,
    _CS_LFS64_LIBS = 1006,
    _CS_LFS64_LINTFLAGS = 1007,
    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,
    _CS_XBS5_ILP32_OFF32_LDFLAGS = 1101,
    _CS_XBS5_ILP32_OFF32_LIBS = 1102,
    _CS_XBS5_ILP32_OFF32_LINTFLAGS = 1103,
    _CS_XBS5_ILP32_OFFBIG_CFLAGS = 1104,
    _CS_XBS5_ILP32_OFFBIG_LDFLAGS = 1105,
    _CS_XBS5_ILP32_OFFBIG_LIBS = 1106,
    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS = 1107,
    _CS_XBS5_LP64_OFF64_CFLAGS = 1108,
    _CS_XBS5_LP64_OFF64_LDFLAGS = 1109,
    _CS_XBS5_LP64_OFF64_LIBS = 1110,
    _CS_XBS5_LP64_OFF64_LINTFLAGS = 1111,
    _CS_XBS5_LPBIG_OFFBIG_CFLAGS = 1112,
    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS = 1113,
    _CS_XBS5_LPBIG_OFFBIG_LIBS = 1114,
    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS = 1115,
    _CS_POSIX_V6_ILP32_OFF32_CFLAGS = 1116,
    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS = 1117,
    _CS_POSIX_V6_ILP32_OFF32_LIBS = 1118,
    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS = 1119,
    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS = 1120,
    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS = 1121,
    _CS_POSIX_V6_ILP32_OFFBIG_LIBS = 1122,
    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS = 1123,
    _CS_POSIX_V6_LP64_OFF64_CFLAGS = 1124,
    _CS_POSIX_V6_LP64_OFF64_LDFLAGS = 1125,
    _CS_POSIX_V6_LP64_OFF64_LIBS = 1126,
    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS = 1127,
    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS = 1128,
    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS = 1129,
    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS = 1130,
    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS = 1131,
    _CS_POSIX_V7_ILP32_OFF32_CFLAGS = 1132,
    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS = 1133,
    _CS_POSIX_V7_ILP32_OFF32_LIBS = 1134,
    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS = 1135,
    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS = 1136,
    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS = 1137,
    _CS_POSIX_V7_ILP32_OFFBIG_LIBS = 1138,
    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS = 1139,
    _CS_POSIX_V7_LP64_OFF64_CFLAGS = 1140,
    _CS_POSIX_V7_LP64_OFF64_LDFLAGS = 1141,
    _CS_POSIX_V7_LP64_OFF64_LIBS = 1142,
    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS = 1143,
    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS = 1144,
    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS = 1145,
    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS = 1146,
    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS = 1147,
    _CS_V6_ENV = 1148,
    _CS_V7_ENV = 1149
} ;
typedef signed char int8;
typedef unsigned char uint8;
typedef short int16;
typedef unsigned short uint16;
typedef int int32;
typedef unsigned int uint32;
enum TIFFIgnoreSense {
    TIS_STORE = 0,
    TIS_EXTRACT = 1,
    TIS_EMPTY = 2
} ;
struct __anonstruct_TIFFHeader_30 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint32 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeader_30 TIFFHeader;
struct __anonstruct_TIFFDirEntry_31 {
   uint16 tdir_tag ;
   uint16 tdir_type ;
   uint32 tdir_count ;
   uint32 tdir_offset ;
};
typedef struct __anonstruct_TIFFDirEntry_31 TIFFDirEntry;
enum __anonenum_TIFFDataType_32 {
    TIFF_NOTYPE = 0,
    TIFF_BYTE = 1,
    TIFF_ASCII = 2,
    TIFF_SHORT = 3,
    TIFF_LONG = 4,
    TIFF_RATIONAL = 5,
    TIFF_SBYTE = 6,
    TIFF_UNDEFINED = 7,
    TIFF_SSHORT = 8,
    TIFF_SLONG = 9,
    TIFF_SRATIONAL = 10,
    TIFF_FLOAT = 11,
    TIFF_DOUBLE = 12,
    TIFF_IFD = 13
} ;
typedef enum __anonenum_TIFFDataType_32 TIFFDataType;
struct tiff;
typedef struct tiff TIFF;
typedef uint32 ttag_t;
typedef uint16 tdir_t;
typedef uint16 tsample_t;
typedef uint32 tstrip_t;
typedef uint32 ttile_t;
typedef int32 tsize_t;
typedef void *tdata_t;
typedef uint32 toff_t;
typedef void *thandle_t;
typedef unsigned char TIFFRGBValue;
struct __anonstruct_TIFFDisplay_33 {
   float d_mat[3][3] ;
   float d_YCR ;
   float d_YCG ;
   float d_YCB ;
   uint32 d_Vrwr ;
   uint32 d_Vrwg ;
   uint32 d_Vrwb ;
   float d_Y0R ;
   float d_Y0G ;
   float d_Y0B ;
   float d_gammaR ;
   float d_gammaG ;
   float d_gammaB ;
};
typedef struct __anonstruct_TIFFDisplay_33 TIFFDisplay;
struct __anonstruct_TIFFYCbCrToRGB_34 {
   TIFFRGBValue *clamptab ;
   int *Cr_r_tab ;
   int *Cb_b_tab ;
   int32 *Cr_g_tab ;
   int32 *Cb_g_tab ;
   int32 *Y_tab ;
};
typedef struct __anonstruct_TIFFYCbCrToRGB_34 TIFFYCbCrToRGB;
struct __anonstruct_TIFFCIELabToRGB_35 {
   int range ;
   float rstep ;
   float gstep ;
   float bstep ;
   float X0 ;
   float Y0 ;
   float Z0 ;
   TIFFDisplay display ;
   float Yr2r[1501] ;
   float Yg2g[1501] ;
   float Yb2b[1501] ;
};
typedef struct __anonstruct_TIFFCIELabToRGB_35 TIFFCIELabToRGB;
struct _TIFFRGBAImage;
typedef struct _TIFFRGBAImage TIFFRGBAImage;
typedef void (*tileContigRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                  uint32  , uint32  , uint32  , int32  ,
                                  int32  , unsigned char * );
typedef void (*tileSeparateRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                    uint32  , uint32  , uint32  , int32  ,
                                    int32  , unsigned char * , unsigned char * ,
                                    unsigned char * , unsigned char * );
union __anonunion_put_36 {
   void (*any)(TIFFRGBAImage * ) ;
   void (*contig)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                  uint32  , int32  , int32  , unsigned char * ) ;
   void (*separate)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                    uint32  , int32  , int32  , unsigned char * ,
                    unsigned char * , unsigned char * , unsigned char * ) ;
};
struct _TIFFRGBAImage {
   TIFF *tif ;
   int stoponerr ;
   int isContig ;
   int alpha ;
   uint32 width ;
   uint32 height ;
   uint16 bitspersample ;
   uint16 samplesperpixel ;
   uint16 orientation ;
   uint16 req_orientation ;
   uint16 photometric ;
   uint16 *redcmap ;
   uint16 *greencmap ;
   uint16 *bluecmap ;
   int (*get)(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
   union __anonunion_put_36 put ;
   TIFFRGBValue *Map ;
   uint32 **BWmap ;
   uint32 **PALmap ;
   TIFFYCbCrToRGB *ycbcr ;
   TIFFCIELabToRGB *cielab ;
   int row_offset ;
   int col_offset ;
};
typedef int (*TIFFInitMethod)(TIFF * , int  );
struct __anonstruct_TIFFCodec_37 {
   char *name ;
   uint16 scheme ;
   int (*init)(TIFF * , int  ) ;
};
typedef struct __anonstruct_TIFFCodec_37 TIFFCodec;
typedef void (*TIFFErrorHandler)(char const   * , char const   * , va_list  );
typedef tsize_t (*TIFFReadWriteProc)(thandle_t  , tdata_t  , tsize_t  );
typedef toff_t (*TIFFSeekProc)(thandle_t  , toff_t  , int  );
typedef int (*TIFFCloseProc)(thandle_t  );
typedef toff_t (*TIFFSizeProc)(thandle_t  );
typedef int (*TIFFMapFileProc)(thandle_t  , tdata_t * , toff_t * );
typedef void (*TIFFUnmapFileProc)(thandle_t  , tdata_t  , toff_t  );
typedef void (*TIFFExtendProc)(TIFF * );
struct __anonstruct_TIFFFieldInfo_38 {
   ttag_t field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
};
typedef struct __anonstruct_TIFFFieldInfo_38 TIFFFieldInfo;
struct _TIFFTagValue {
   TIFFFieldInfo const   *info ;
   int count ;
   void *value ;
};
typedef struct _TIFFTagValue TIFFTagValue;
typedef int (*TIFFVSetMethod)(TIFF * , ttag_t  , va_list  );
typedef int (*TIFFVGetMethod)(TIFF * , ttag_t  , va_list  );
typedef void (*TIFFPrintMethod)(TIFF * , FILE * , long  );
struct __anonstruct_TIFFTagMethods_39 {
   int (*vsetfield)(TIFF * , ttag_t  , va_list  ) ;
   int (*vgetfield)(TIFF * , ttag_t  , va_list  ) ;
   void (*printdir)(TIFF * , FILE * , long  ) ;
};
typedef struct __anonstruct_TIFFTagMethods_39 TIFFTagMethods;
struct cpTag {
   uint16 tag ;
   uint16 count ;
   TIFFDataType type ;
};
typedef int (*copyFunc)(TIFF *in , TIFF *out , uint32 l , uint32 w ,
                        uint16 samplesperpixel );
typedef int (*readFunc)(TIFF * , uint8 * , uint32  , uint32  , tsample_t  );
typedef int (*writeFunc)(TIFF * , uint8 * , uint32  , uint32  , tsample_t  );
typedef void biasFn(void *image , void *bias , uint32 pixels );
extern struct _IO_FILE_plus _IO_2_1_stdin_ ;
extern struct _IO_FILE_plus _IO_2_1_stdout_ ;
extern struct _IO_FILE_plus _IO_2_1_stderr_ ;
extern int __underflow(_IO_FILE * ) ;
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_feof(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_ferror(_IO_FILE *__fp ) ;
extern int _IO_peekc_locked(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) void _IO_flockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) void _IO_funlockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) int _IO_ftrylockfile(_IO_FILE * ) ;
extern int _IO_vfscanf(_IO_FILE * __restrict   , char const   * __restrict   ,
                       __gnuc_va_list  , int * __restrict   ) ;
extern int _IO_vfprintf(_IO_FILE * __restrict   , char const   * __restrict   ,
                        __gnuc_va_list  ) ;
extern __ssize_t _IO_padn(_IO_FILE * , int  , __ssize_t  ) ;
extern size_t _IO_sgetn(_IO_FILE * , void * , size_t  ) ;
extern __off64_t _IO_seekoff(_IO_FILE * , __off64_t  , int  , int  ) ;
extern __off64_t _IO_seekpos(_IO_FILE * , __off64_t  , int  ) ;
extern  __attribute__((__nothrow__)) void _IO_free_backup_area(_IO_FILE * ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
extern  __attribute__((__nothrow__)) int remove(char const   *__filename ) ;
extern  __attribute__((__nothrow__)) int rename(char const   *__old ,
                                                char const   *__new ) ;
extern  __attribute__((__nothrow__)) int renameat(int __oldfd ,
                                                  char const   *__old ,
                                                  int __newfd ,
                                                  char const   *__new ) ;
extern FILE *tmpfile(void)  __asm__("tmpfile64")  ;
extern  __attribute__((__nothrow__)) char *tmpnam(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tmpnam_r(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tempnam(char const   *__dir ,
                                                   char const   *__pfx )  __attribute__((__malloc__)) ;
extern int fclose(FILE *__stream ) ;
extern int fflush(FILE *__stream ) ;
extern int fflush_unlocked(FILE *__stream ) ;
extern FILE *fopen(char const   * __restrict  __filename ,
                   char const   * __restrict  __modes )  __asm__("fopen64")  ;
extern FILE *freopen(char const   * __restrict  __filename ,
                     char const   * __restrict  __modes ,
                     FILE * __restrict  __stream )  __asm__("freopen64")  ;
extern  __attribute__((__nothrow__)) FILE *fdopen(int __fd ,
                                                  char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *fmemopen(void *__s , size_t __len ,
                                                    char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *open_memstream(char **__bufloc ,
                                                          size_t *__sizeloc ) ;
extern  __attribute__((__nothrow__)) void setbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) int setvbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ,
                                                 int __modes , size_t __n ) ;
extern  __attribute__((__nothrow__)) void setbuffer(FILE * __restrict  __stream ,
                                                    char * __restrict  __buf ,
                                                    size_t __size ) ;
extern  __attribute__((__nothrow__)) void setlinebuf(FILE *__stream ) ;
extern int fprintf(FILE * __restrict  __stream ,
                   char const   * __restrict  __format  , ...) ;
extern int printf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sprintf(char * __restrict  __s ,
                                                 char const   * __restrict  __format 
                                                 , ...) ;
extern int vfprintf(FILE * __restrict  __s ,
                    char const   * __restrict  __format , __gnuc_va_list __arg ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vsprintf(char * __restrict  __s ,
                                                  char const   * __restrict  __format ,
                                                  __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  snprintf)(char * __restrict  __s ,
                                                                             size_t __maxlen ,
                                                                             char const   * __restrict  __format 
                                                                             , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsnprintf)(char * __restrict  __s ,
                                                                              size_t __maxlen ,
                                                                              char const   * __restrict  __format ,
                                                                              __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  vdprintf)(int __fd ,
                                               char const   * __restrict  __fmt ,
                                               __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  dprintf)(int __fd ,
                                              char const   * __restrict  __fmt 
                                              , ...) ;
extern int fscanf(FILE * __restrict  __stream ,
                  char const   * __restrict  __format  , ...)  __asm__("__isoc99_fscanf")  ;
extern int scanf(char const   * __restrict  __format  , ...)  __asm__("__isoc99_scanf")  ;
extern  __attribute__((__nothrow__)) int sscanf(char const   * __restrict  __s ,
                                                char const   * __restrict  __format 
                                                , ...)  __asm__("__isoc99_sscanf")  ;
extern int ( /* format attribute */  vfscanf)(FILE * __restrict  __s ,
                                              char const   * __restrict  __format ,
                                              __gnuc_va_list __arg )  __asm__("__isoc99_vfscanf")  ;
extern int ( /* format attribute */  vscanf)(char const   * __restrict  __format ,
                                             __gnuc_va_list __arg )  __asm__("__isoc99_vscanf")  ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsscanf)(char const   * __restrict  __s ,
                                                                            char const   * __restrict  __format ,
                                                                            __gnuc_va_list __arg )  __asm__("__isoc99_vsscanf")  ;
extern int fgetc(FILE *__stream ) ;
extern int getc(FILE *__stream ) ;
__inline extern int getchar(void) ;
__inline extern int getc_unlocked(FILE *__fp ) ;
__inline extern int getchar_unlocked(void) ;
__inline extern int fgetc_unlocked(FILE *__fp ) ;
extern int fputc(int __c , FILE *__stream ) ;
extern int putc(int __c , FILE *__stream ) ;
__inline extern int putchar(int __c ) ;
__inline extern int fputc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putchar_unlocked(int __c ) ;
extern int getw(FILE *__stream ) ;
extern int putw(int __w , FILE *__stream ) ;
extern char *fgets(char * __restrict  __s , int __n ,
                   FILE * __restrict  __stream ) ;
extern char *gets(char *__s ) ;
extern __ssize_t __getdelim(char ** __restrict  __lineptr ,
                            size_t * __restrict  __n , int __delimiter ,
                            FILE * __restrict  __stream ) ;
extern __ssize_t getdelim(char ** __restrict  __lineptr ,
                          size_t * __restrict  __n , int __delimiter ,
                          FILE * __restrict  __stream ) ;
extern __ssize_t getline(char ** __restrict  __lineptr ,
                         size_t * __restrict  __n , FILE * __restrict  __stream ) ;
extern int fputs(char const   * __restrict  __s , FILE * __restrict  __stream ) ;
extern int puts(char const   *__s ) ;
extern int ungetc(int __c , FILE *__stream ) ;
extern size_t fread(void * __restrict  __ptr , size_t __size , size_t __n ,
                    FILE * __restrict  __stream ) ;
extern size_t fwrite(void const   * __restrict  __ptr , size_t __size ,
                     size_t __n , FILE * __restrict  __s ) ;
extern size_t fread_unlocked(void * __restrict  __ptr , size_t __size ,
                             size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite_unlocked(void const   * __restrict  __ptr , size_t __size ,
                              size_t __n , FILE * __restrict  __stream ) ;
extern int fseek(FILE *__stream , long __off , int __whence ) ;
extern long ftell(FILE *__stream ) ;
extern void rewind(FILE *__stream ) ;
extern int fseeko(FILE *__stream , __off64_t __off , int __whence )  __asm__("fseeko64")  ;
extern __off64_t ftello(FILE *__stream )  __asm__("ftello64")  ;
extern int fgetpos(FILE * __restrict  __stream , fpos_t * __restrict  __pos )  __asm__("fgetpos64")  ;
extern int fsetpos(FILE *__stream , fpos_t const   *__pos )  __asm__("fsetpos64")  ;
extern  __attribute__((__nothrow__)) void clearerr(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int feof(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ferror(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void clearerr_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
extern void perror(char const   *__s ) ;
extern int sys_nerr ;
extern char const   * const  sys_errlist[] ;
extern  __attribute__((__nothrow__)) int fileno(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int fileno_unlocked(FILE *__stream ) ;
extern FILE *popen(char const   *__command , char const   *__modes ) ;
extern int pclose(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) char *ctermid(char *__s ) ;
extern  __attribute__((__nothrow__)) void flockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ftrylockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void funlockfile(FILE *__stream ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1\n");
  fflush(_coverage_fout);
  }
  tmp = vfprintf((FILE */* __restrict  */)stdout, __fmt, __arg);
  {
  fprintf(_coverage_fout, "2\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
__inline extern int getchar(void) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "3\n");
  fflush(_coverage_fout);
  }
  tmp = _IO_getc(stdin);
  {
  fprintf(_coverage_fout, "4\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
__inline extern int fgetc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "10\n");
  fflush(_coverage_fout);
  }
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  {
  fprintf(_coverage_fout, "11\n");
  fflush(_coverage_fout);
  }
  if (tmp___3) {
    {
    fprintf(_coverage_fout, "5\n");
    fflush(_coverage_fout);
    }
    tmp___0 = __uflow(__fp);
    {
    fprintf(_coverage_fout, "6\n");
    fflush(_coverage_fout);
    }
    tmp___2 = tmp___0;
  } else {
    {
    fprintf(_coverage_fout, "7\n");
    fflush(_coverage_fout);
    }
    tmp___1 = __fp->_IO_read_ptr;
    {
    fprintf(_coverage_fout, "8\n");
    fflush(_coverage_fout);
    }
    (__fp->_IO_read_ptr) ++;
    {
    fprintf(_coverage_fout, "9\n");
    fflush(_coverage_fout);
    }
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  {
  fprintf(_coverage_fout, "12\n");
  fflush(_coverage_fout);
  }
  return (tmp___2);
}
}
__inline extern int getc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "18\n");
  fflush(_coverage_fout);
  }
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  {
  fprintf(_coverage_fout, "19\n");
  fflush(_coverage_fout);
  }
  if (tmp___3) {
    {
    fprintf(_coverage_fout, "13\n");
    fflush(_coverage_fout);
    }
    tmp___0 = __uflow(__fp);
    {
    fprintf(_coverage_fout, "14\n");
    fflush(_coverage_fout);
    }
    tmp___2 = tmp___0;
  } else {
    {
    fprintf(_coverage_fout, "15\n");
    fflush(_coverage_fout);
    }
    tmp___1 = __fp->_IO_read_ptr;
    {
    fprintf(_coverage_fout, "16\n");
    fflush(_coverage_fout);
    }
    (__fp->_IO_read_ptr) ++;
    {
    fprintf(_coverage_fout, "17\n");
    fflush(_coverage_fout);
    }
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  {
  fprintf(_coverage_fout, "20\n");
  fflush(_coverage_fout);
  }
  return (tmp___2);
}
}
__inline extern int getchar_unlocked(void) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "26\n");
  fflush(_coverage_fout);
  }
  tmp___3 = __builtin_expect((long )((unsigned int )stdin->_IO_read_ptr >= (unsigned int )stdin->_IO_read_end),
                             0L);
  {
  fprintf(_coverage_fout, "27\n");
  fflush(_coverage_fout);
  }
  if (tmp___3) {
    {
    fprintf(_coverage_fout, "21\n");
    fflush(_coverage_fout);
    }
    tmp___0 = __uflow(stdin);
    {
    fprintf(_coverage_fout, "22\n");
    fflush(_coverage_fout);
    }
    tmp___2 = tmp___0;
  } else {
    {
    fprintf(_coverage_fout, "23\n");
    fflush(_coverage_fout);
    }
    tmp___1 = stdin->_IO_read_ptr;
    {
    fprintf(_coverage_fout, "24\n");
    fflush(_coverage_fout);
    }
    (stdin->_IO_read_ptr) ++;
    {
    fprintf(_coverage_fout, "25\n");
    fflush(_coverage_fout);
    }
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  {
  fprintf(_coverage_fout, "28\n");
  fflush(_coverage_fout);
  }
  return (tmp___2);
}
}
__inline extern int putchar(int __c ) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "29\n");
  fflush(_coverage_fout);
  }
  tmp = _IO_putc(__c, stdout);
  {
  fprintf(_coverage_fout, "30\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
__inline extern int fputc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "38\n");
  fflush(_coverage_fout);
  }
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  {
  fprintf(_coverage_fout, "39\n");
  fflush(_coverage_fout);
  }
  if (tmp___4) {
    {
    fprintf(_coverage_fout, "31\n");
    fflush(_coverage_fout);
    }
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    {
    fprintf(_coverage_fout, "32\n");
    fflush(_coverage_fout);
    }
    tmp___3 = tmp___0;
  } else {
    {
    fprintf(_coverage_fout, "33\n");
    fflush(_coverage_fout);
    }
    tmp___1 = __stream->_IO_write_ptr;
    {
    fprintf(_coverage_fout, "34\n");
    fflush(_coverage_fout);
    }
    (__stream->_IO_write_ptr) ++;
    {
    fprintf(_coverage_fout, "35\n");
    fflush(_coverage_fout);
    }
    tmp___2 = (char )__c;
    {
    fprintf(_coverage_fout, "36\n");
    fflush(_coverage_fout);
    }
    *tmp___1 = tmp___2;
    {
    fprintf(_coverage_fout, "37\n");
    fflush(_coverage_fout);
    }
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  {
  fprintf(_coverage_fout, "40\n");
  fflush(_coverage_fout);
  }
  return (tmp___3);
}
}
__inline extern int putc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "48\n");
  fflush(_coverage_fout);
  }
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  {
  fprintf(_coverage_fout, "49\n");
  fflush(_coverage_fout);
  }
  if (tmp___4) {
    {
    fprintf(_coverage_fout, "41\n");
    fflush(_coverage_fout);
    }
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    {
    fprintf(_coverage_fout, "42\n");
    fflush(_coverage_fout);
    }
    tmp___3 = tmp___0;
  } else {
    {
    fprintf(_coverage_fout, "43\n");
    fflush(_coverage_fout);
    }
    tmp___1 = __stream->_IO_write_ptr;
    {
    fprintf(_coverage_fout, "44\n");
    fflush(_coverage_fout);
    }
    (__stream->_IO_write_ptr) ++;
    {
    fprintf(_coverage_fout, "45\n");
    fflush(_coverage_fout);
    }
    tmp___2 = (char )__c;
    {
    fprintf(_coverage_fout, "46\n");
    fflush(_coverage_fout);
    }
    *tmp___1 = tmp___2;
    {
    fprintf(_coverage_fout, "47\n");
    fflush(_coverage_fout);
    }
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  {
  fprintf(_coverage_fout, "50\n");
  fflush(_coverage_fout);
  }
  return (tmp___3);
}
}
__inline extern int putchar_unlocked(int __c ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "58\n");
  fflush(_coverage_fout);
  }
  tmp___4 = __builtin_expect((long )((unsigned int )stdout->_IO_write_ptr >= (unsigned int )stdout->_IO_write_end),
                             0L);
  {
  fprintf(_coverage_fout, "59\n");
  fflush(_coverage_fout);
  }
  if (tmp___4) {
    {
    fprintf(_coverage_fout, "51\n");
    fflush(_coverage_fout);
    }
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    {
    fprintf(_coverage_fout, "52\n");
    fflush(_coverage_fout);
    }
    tmp___3 = tmp___0;
  } else {
    {
    fprintf(_coverage_fout, "53\n");
    fflush(_coverage_fout);
    }
    tmp___1 = stdout->_IO_write_ptr;
    {
    fprintf(_coverage_fout, "54\n");
    fflush(_coverage_fout);
    }
    (stdout->_IO_write_ptr) ++;
    {
    fprintf(_coverage_fout, "55\n");
    fflush(_coverage_fout);
    }
    tmp___2 = (char )__c;
    {
    fprintf(_coverage_fout, "56\n");
    fflush(_coverage_fout);
    }
    *tmp___1 = tmp___2;
    {
    fprintf(_coverage_fout, "57\n");
    fflush(_coverage_fout);
    }
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  {
  fprintf(_coverage_fout, "60\n");
  fflush(_coverage_fout);
  }
  return (tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern int feof_unlocked(FILE *__stream ) 
{ 

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "61\n");
  fflush(_coverage_fout);
  }
  return ((__stream->_flags & 0x10) != 0);
}
}
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
__inline extern int ferror_unlocked(FILE *__stream ) 
{ 

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "62\n");
  fflush(_coverage_fout);
  }
  return ((__stream->_flags & 0x20) != 0);
}
}
extern  __attribute__((__nothrow__)) size_t __ctype_get_mb_cur_max(void) ;
__inline extern  __attribute__((__nothrow__)) double atof(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) int atoi(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) long atol(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) long long atoll(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) double strtod(char const   * __restrict  __nptr ,
                                                   char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) float strtof(char const   * __restrict  __nptr ,
                                                  char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long double strtold(char const   * __restrict  __nptr ,
                                                         char ** __restrict  __endptr )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long strtol(char const   * __restrict  __nptr ,
                                                 char ** __restrict  __endptr ,
                                                 int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long strtoul(char const   * __restrict  __nptr ,
                                                           char ** __restrict  __endptr ,
                                                           int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long long strtoq(char const   * __restrict  __nptr ,
                                                      char ** __restrict  __endptr ,
                                                      int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long long strtouq(char const   * __restrict  __nptr ,
                                                                char ** __restrict  __endptr ,
                                                                int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long long strtoll(char const   * __restrict  __nptr ,
                                                       char ** __restrict  __endptr ,
                                                       int __base )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) unsigned long long strtoull(char const   * __restrict  __nptr ,
                                                                 char ** __restrict  __endptr ,
                                                                 int __base )  __attribute__((__nonnull__(1))) ;
__inline extern  __attribute__((__nothrow__)) double atof(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern double atof(char const   *__nptr ) 
{ double tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "63\n");
  fflush(_coverage_fout);
  }
  tmp = strtod((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)));
  {
  fprintf(_coverage_fout, "64\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) int atoi(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern int atoi(char const   *__nptr ) 
{ long tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "65\n");
  fflush(_coverage_fout);
  }
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  {
  fprintf(_coverage_fout, "66\n");
  fflush(_coverage_fout);
  }
  return ((int )tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long atol(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern long atol(char const   *__nptr ) 
{ long tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "67\n");
  fflush(_coverage_fout);
  }
  tmp = strtol((char const   */* __restrict  */)__nptr,
               (char **/* __restrict  */)((char **)((void *)0)), 10);
  {
  fprintf(_coverage_fout, "68\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
__inline extern  __attribute__((__nothrow__)) long long atoll(char const   *__nptr )  __attribute__((__pure__,
__nonnull__(1))) ;
__inline extern long long atoll(char const   *__nptr ) 
{ long long tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "69\n");
  fflush(_coverage_fout);
  }
  tmp = strtoll((char const   */* __restrict  */)__nptr,
                (char **/* __restrict  */)((char **)((void *)0)), 10);
  {
  fprintf(_coverage_fout, "70\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
extern  __attribute__((__nothrow__)) char *l64a(long __n ) ;
extern  __attribute__((__nothrow__)) long a64l(char const   *__s )  __attribute__((__pure__,
__nonnull__(1))) ;
extern int select(int __nfds , fd_set * __restrict  __readfds ,
                  fd_set * __restrict  __writefds ,
                  fd_set * __restrict  __exceptfds ,
                  struct timeval * __restrict  __timeout ) ;
extern int pselect(int __nfds , fd_set * __restrict  __readfds ,
                   fd_set * __restrict  __writefds ,
                   fd_set * __restrict  __exceptfds ,
                   struct timespec  const  * __restrict  __timeout ,
                   __sigset_t const   * __restrict  __sigmask ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_major(unsigned long long __dev ) 
{ 

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "71\n");
  fflush(_coverage_fout);
  }
  return ((unsigned int )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_minor(unsigned long long __dev ) 
{ 

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "72\n");
  fflush(_coverage_fout);
  }
  return ((unsigned int )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                   unsigned int __minor ) 
{ 

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "73\n");
  fflush(_coverage_fout);
  }
  return (((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32));
}
}
extern  __attribute__((__nothrow__)) long random(void) ;
extern  __attribute__((__nothrow__)) void srandom(unsigned int __seed ) ;
extern  __attribute__((__nothrow__)) char *initstate(unsigned int __seed ,
                                                     char *__statebuf ,
                                                     size_t __statelen )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *setstate(char *__statebuf )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int random_r(struct random_data * __restrict  __buf ,
                                                  int32_t * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int srandom_r(unsigned int __seed ,
                                                   struct random_data *__buf )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int initstate_r(unsigned int __seed ,
                                                     char * __restrict  __statebuf ,
                                                     size_t __statelen ,
                                                     struct random_data * __restrict  __buf )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) int setstate_r(char * __restrict  __statebuf ,
                                                    struct random_data * __restrict  __buf )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int rand(void) ;
extern  __attribute__((__nothrow__)) void srand(unsigned int __seed ) ;
extern  __attribute__((__nothrow__)) int rand_r(unsigned int *__seed ) ;
extern  __attribute__((__nothrow__)) double drand48(void) ;
extern  __attribute__((__nothrow__)) double erand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long lrand48(void) ;
extern  __attribute__((__nothrow__)) long nrand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long mrand48(void) ;
extern  __attribute__((__nothrow__)) long jrand48(unsigned short *__xsubi )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void srand48(long __seedval ) ;
extern  __attribute__((__nothrow__)) unsigned short *seed48(unsigned short *__seed16v )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void lcong48(unsigned short *__param )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int drand48_r(struct drand48_data * __restrict  __buffer ,
                                                   double * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int erand48_r(unsigned short *__xsubi ,
                                                   struct drand48_data * __restrict  __buffer ,
                                                   double * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int lrand48_r(struct drand48_data * __restrict  __buffer ,
                                                   long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int nrand48_r(unsigned short *__xsubi ,
                                                   struct drand48_data * __restrict  __buffer ,
                                                   long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int mrand48_r(struct drand48_data * __restrict  __buffer ,
                                                   long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int jrand48_r(unsigned short *__xsubi ,
                                                   struct drand48_data * __restrict  __buffer ,
                                                   long * __restrict  __result )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int srand48_r(long __seedval ,
                                                   struct drand48_data *__buffer )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int seed48_r(unsigned short *__seed16v ,
                                                  struct drand48_data *__buffer )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int lcong48_r(unsigned short *__param ,
                                                   struct drand48_data *__buffer )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *malloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *calloc(size_t __nmemb ,
                                                  size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *realloc(void *__ptr , size_t __size )  __attribute__((__warn_unused_result__)) ;
extern  __attribute__((__nothrow__)) void free(void *__ptr ) ;
extern  __attribute__((__nothrow__)) void cfree(void *__ptr ) ;
extern  __attribute__((__nothrow__)) void *alloca(size_t __size ) ;
extern  __attribute__((__nothrow__)) void *valloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) int posix_memalign(void **__memptr ,
                                                        size_t __alignment ,
                                                        size_t __size )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__, __noreturn__)) void abort(void) ;
extern  __attribute__((__nothrow__)) int atexit(void (*__func)(void) )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int on_exit(void (*__func)(int __status ,
                                                                void *__arg ) ,
                                                 void *__arg )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__, __noreturn__)) void exit(int __status ) ;
extern  __attribute__((__nothrow__, __noreturn__)) void _Exit(int __status ) ;
extern  __attribute__((__nothrow__)) char *getenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *__secure_getenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int putenv(char *__string )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int setenv(char const   *__name ,
                                                char const   *__value ,
                                                int __replace )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int unsetenv(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int clearenv(void) ;
extern  __attribute__((__nothrow__)) char *mktemp(char *__template )  __attribute__((__nonnull__(1))) ;
extern int mkstemp(char *__template )  __asm__("mkstemp64") __attribute__((__nonnull__(1))) ;
extern int mkstemps(char *__template , int __suffixlen )  __asm__("mkstemps64") __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *mkdtemp(char *__template )  __attribute__((__nonnull__(1))) ;
extern int system(char const   *__command ) ;
extern  __attribute__((__nothrow__)) char *realpath(char const   * __restrict  __name ,
                                                    char * __restrict  __resolved ) ;
extern void *bsearch(void const   *__key , void const   *__base ,
                     size_t __nmemb , size_t __size ,
                     int (*__compar)(void const   * , void const   * ) )  __attribute__((__nonnull__(1,2,5))) ;
extern void qsort(void *__base , size_t __nmemb , size_t __size ,
                  int (*__compar)(void const   * , void const   * ) )  __attribute__((__nonnull__(1,4))) ;
extern  __attribute__((__nothrow__)) int abs(int __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long labs(long __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) long long llabs(long long __x )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) div_t div(int __numer , int __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) ldiv_t ldiv(long __numer , long __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) lldiv_t lldiv(long long __numer ,
                                                   long long __denom )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) char *ecvt(double __value , int __ndigit ,
                                                int * __restrict  __decpt ,
                                                int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *fcvt(double __value , int __ndigit ,
                                                int * __restrict  __decpt ,
                                                int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *gcvt(double __value , int __ndigit ,
                                                char *__buf )  __attribute__((__nonnull__(3))) ;
extern  __attribute__((__nothrow__)) char *qecvt(long double __value ,
                                                 int __ndigit ,
                                                 int * __restrict  __decpt ,
                                                 int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *qfcvt(long double __value ,
                                                 int __ndigit ,
                                                 int * __restrict  __decpt ,
                                                 int * __restrict  __sign )  __attribute__((__nonnull__(3,4))) ;
extern  __attribute__((__nothrow__)) char *qgcvt(long double __value ,
                                                 int __ndigit , char *__buf )  __attribute__((__nonnull__(3))) ;
extern  __attribute__((__nothrow__)) int ecvt_r(double __value , int __ndigit ,
                                                int * __restrict  __decpt ,
                                                int * __restrict  __sign ,
                                                char * __restrict  __buf ,
                                                size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int fcvt_r(double __value , int __ndigit ,
                                                int * __restrict  __decpt ,
                                                int * __restrict  __sign ,
                                                char * __restrict  __buf ,
                                                size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int qecvt_r(long double __value ,
                                                 int __ndigit ,
                                                 int * __restrict  __decpt ,
                                                 int * __restrict  __sign ,
                                                 char * __restrict  __buf ,
                                                 size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int qfcvt_r(long double __value ,
                                                 int __ndigit ,
                                                 int * __restrict  __decpt ,
                                                 int * __restrict  __sign ,
                                                 char * __restrict  __buf ,
                                                 size_t __len )  __attribute__((__nonnull__(3,4,5))) ;
extern  __attribute__((__nothrow__)) int mblen(char const   *__s , size_t __n ) ;
extern  __attribute__((__nothrow__)) int mbtowc(wchar_t * __restrict  __pwc ,
                                                char const   * __restrict  __s ,
                                                size_t __n ) ;
extern  __attribute__((__nothrow__)) int wctomb(char *__s , wchar_t __wchar ) ;
extern  __attribute__((__nothrow__)) size_t mbstowcs(wchar_t * __restrict  __pwcs ,
                                                     char const   * __restrict  __s ,
                                                     size_t __n ) ;
extern  __attribute__((__nothrow__)) size_t wcstombs(char * __restrict  __s ,
                                                     wchar_t const   * __restrict  __pwcs ,
                                                     size_t __n ) ;
extern  __attribute__((__nothrow__)) int rpmatch(char const   *__response )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int getsubopt(char ** __restrict  __optionp ,
                                                   char * const  * __restrict  __tokens ,
                                                   char ** __restrict  __valuep )  __attribute__((__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) int getloadavg(double *__loadavg ,
                                                    int __nelem )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void *memcpy(void * __restrict  __dest ,
                                                  void const   * __restrict  __src ,
                                                  size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memmove(void *__dest ,
                                                   void const   *__src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memccpy(void * __restrict  __dest ,
                                                   void const   * __restrict  __src ,
                                                   int __c , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memset(void *__s , int __c ,
                                                  size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int memcmp(void const   *__s1 ,
                                                void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memchr(void const   *__s , int __c ,
                                                  size_t __n )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strcat(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncat(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcmp(char const   *__s1 ,
                                                char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncmp(char const   *__s1 ,
                                                 char const   *__s2 ,
                                                 size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcoll(char const   *__s1 ,
                                                 char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm(char * __restrict  __dest ,
                                                    char const   * __restrict  __src ,
                                                    size_t __n )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int strcoll_l(char const   *__s1 ,
                                                   char const   *__s2 ,
                                                   __locale_t __l )  __attribute__((__pure__,
__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm_l(char *__dest ,
                                                      char const   *__src ,
                                                      size_t __n ,
                                                      __locale_t __l )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) char *strdup(char const   *__s )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strndup(char const   *__string ,
                                                   size_t __n )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strrchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strcspn(char const   *__s ,
                                                    char const   *__reject )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strspn(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strpbrk(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strstr(char const   *__haystack ,
                                                  char const   *__needle )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strtok(char * __restrict  __s ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *__strtok_r(char * __restrict  __s ,
                                                      char const   * __restrict  __delim ,
                                                      char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) char *strtok_r(char * __restrict  __s ,
                                                    char const   * __restrict  __delim ,
                                                    char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) size_t strlen(char const   *__s )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strnlen(char const   *__string ,
                                                    size_t __maxlen )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strerror(int __errnum ) ;
extern  __attribute__((__nothrow__)) int strerror_r(int __errnum , char *__buf ,
                                                    size_t __buflen )  __asm__("__xpg_strerror_r") __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *strerror_l(int __errnum ,
                                                      __locale_t __l ) ;
extern  __attribute__((__nothrow__)) void __bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void bcopy(void const   *__src ,
                                                void *__dest , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int bcmp(void const   *__s1 ,
                                              void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *index(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *rindex(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int ffs(int __i )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int strcasecmp(char const   *__s1 ,
                                                    char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncasecmp(char const   *__s1 ,
                                                     char const   *__s2 ,
                                                     size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsep(char ** __restrict  __stringp ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsignal(int __sig ) ;
extern  __attribute__((__nothrow__)) char *__stpcpy(char * __restrict  __dest ,
                                                    char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *__stpncpy(char * __restrict  __dest ,
                                                     char const   * __restrict  __src ,
                                                     size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern void *__rawmemchr(void const   *__s , int __c ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) 
{ register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "78\n");
  fflush(_coverage_fout);
  }
  __result = (size_t )0;
  {
  fprintf(_coverage_fout, "79\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "76\n");
    fflush(_coverage_fout);
    }
    if ((int const   )*(__s + __result) != 0) {
      {
      fprintf(_coverage_fout, "75\n");
      fflush(_coverage_fout);
      }
      if ((int const   )*(__s + __result) != (int const   )__reject) {
        {
        fprintf(_coverage_fout, "74\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "77\n");
    fflush(_coverage_fout);
    }
    __result ++;
  }
  {
  fprintf(_coverage_fout, "80\n");
  fflush(_coverage_fout);
  }
  return (__result);
}
}
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) ;
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) 
{ register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "86\n");
  fflush(_coverage_fout);
  }
  __result = (size_t )0;
  {
  fprintf(_coverage_fout, "87\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "84\n");
    fflush(_coverage_fout);
    }
    if ((int const   )*(__s + __result) != 0) {
      {
      fprintf(_coverage_fout, "83\n");
      fflush(_coverage_fout);
      }
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        {
        fprintf(_coverage_fout, "82\n");
        fflush(_coverage_fout);
        }
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          {
          fprintf(_coverage_fout, "81\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "85\n");
    fflush(_coverage_fout);
    }
    __result ++;
  }
  {
  fprintf(_coverage_fout, "88\n");
  fflush(_coverage_fout);
  }
  return (__result);
}
}
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) ;
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) 
{ register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "95\n");
  fflush(_coverage_fout);
  }
  __result = (size_t )0;
  {
  fprintf(_coverage_fout, "96\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "93\n");
    fflush(_coverage_fout);
    }
    if ((int const   )*(__s + __result) != 0) {
      {
      fprintf(_coverage_fout, "92\n");
      fflush(_coverage_fout);
      }
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        {
        fprintf(_coverage_fout, "91\n");
        fflush(_coverage_fout);
        }
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          {
          fprintf(_coverage_fout, "90\n");
          fflush(_coverage_fout);
          }
          if ((int const   )*(__s + __result) != (int const   )__reject3) {
            {
            fprintf(_coverage_fout, "89\n");
            fflush(_coverage_fout);
            }

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "94\n");
    fflush(_coverage_fout);
    }
    __result ++;
  }
  {
  fprintf(_coverage_fout, "97\n");
  fflush(_coverage_fout);
  }
  return (__result);
}
}
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) ;
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) 
{ register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "101\n");
  fflush(_coverage_fout);
  }
  __result = (size_t )0;
  {
  fprintf(_coverage_fout, "102\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "99\n");
    fflush(_coverage_fout);
    }
    if ((int const   )*(__s + __result) == (int const   )__accept) {
      {
      fprintf(_coverage_fout, "98\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "100\n");
    fflush(_coverage_fout);
    }
    __result ++;
  }
  {
  fprintf(_coverage_fout, "103\n");
  fflush(_coverage_fout);
  }
  return (__result);
}
}
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "109\n");
  fflush(_coverage_fout);
  }
  __result = (size_t )0;
  {
  fprintf(_coverage_fout, "110\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "107\n");
    fflush(_coverage_fout);
    }
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      {
      fprintf(_coverage_fout, "104\n");
      fflush(_coverage_fout);
      }

    } else {
      {
      fprintf(_coverage_fout, "106\n");
      fflush(_coverage_fout);
      }
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        {
        fprintf(_coverage_fout, "105\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
    }
    {
    fprintf(_coverage_fout, "108\n");
    fflush(_coverage_fout);
    }
    __result ++;
  }
  {
  fprintf(_coverage_fout, "111\n");
  fflush(_coverage_fout);
  }
  return (__result);
}
}
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ register size_t __result ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "119\n");
  fflush(_coverage_fout);
  }
  __result = (size_t )0;
  {
  fprintf(_coverage_fout, "120\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "117\n");
    fflush(_coverage_fout);
    }
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      {
      fprintf(_coverage_fout, "112\n");
      fflush(_coverage_fout);
      }

    } else {
      {
      fprintf(_coverage_fout, "116\n");
      fflush(_coverage_fout);
      }
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        {
        fprintf(_coverage_fout, "113\n");
        fflush(_coverage_fout);
        }

      } else {
        {
        fprintf(_coverage_fout, "115\n");
        fflush(_coverage_fout);
        }
        if ((int const   )*(__s + __result) == (int const   )__accept3) {
          {
          fprintf(_coverage_fout, "114\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
      }
    }
    {
    fprintf(_coverage_fout, "118\n");
    fflush(_coverage_fout);
    }
    __result ++;
  }
  {
  fprintf(_coverage_fout, "121\n");
  fflush(_coverage_fout);
  }
  return (__result);
}
}
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ char *tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "129\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "125\n");
    fflush(_coverage_fout);
    }
    if ((int const   )*__s != 0) {
      {
      fprintf(_coverage_fout, "124\n");
      fflush(_coverage_fout);
      }
      if ((int const   )*__s != (int const   )__accept1) {
        {
        fprintf(_coverage_fout, "123\n");
        fflush(_coverage_fout);
        }
        if ((int const   )*__s != (int const   )__accept2) {
          {
          fprintf(_coverage_fout, "122\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "126\n");
    fflush(_coverage_fout);
    }
    __s ++;
  }
  {
  fprintf(_coverage_fout, "130\n");
  fflush(_coverage_fout);
  }
  if ((int const   )*__s == 0) {
    {
    fprintf(_coverage_fout, "127\n");
    fflush(_coverage_fout);
    }
    tmp = (char *)((void *)0);
  } else {
    {
    fprintf(_coverage_fout, "128\n");
    fflush(_coverage_fout);
    }
    tmp = (char *)((unsigned int )__s);
  }
  {
  fprintf(_coverage_fout, "131\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ char *tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "140\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "136\n");
    fflush(_coverage_fout);
    }
    if ((int const   )*__s != 0) {
      {
      fprintf(_coverage_fout, "135\n");
      fflush(_coverage_fout);
      }
      if ((int const   )*__s != (int const   )__accept1) {
        {
        fprintf(_coverage_fout, "134\n");
        fflush(_coverage_fout);
        }
        if ((int const   )*__s != (int const   )__accept2) {
          {
          fprintf(_coverage_fout, "133\n");
          fflush(_coverage_fout);
          }
          if ((int const   )*__s != (int const   )__accept3) {
            {
            fprintf(_coverage_fout, "132\n");
            fflush(_coverage_fout);
            }

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "137\n");
    fflush(_coverage_fout);
    }
    __s ++;
  }
  {
  fprintf(_coverage_fout, "141\n");
  fflush(_coverage_fout);
  }
  if ((int const   )*__s == 0) {
    {
    fprintf(_coverage_fout, "138\n");
    fflush(_coverage_fout);
    }
    tmp = (char *)((void *)0);
  } else {
    {
    fprintf(_coverage_fout, "139\n");
    fflush(_coverage_fout);
    }
    tmp = (char *)((unsigned int )__s);
  }
  {
  fprintf(_coverage_fout, "142\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) ;
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) 
{ char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "160\n");
  fflush(_coverage_fout);
  }
  if ((unsigned int )__s == (unsigned int )((void *)0)) {
    {
    fprintf(_coverage_fout, "143\n");
    fflush(_coverage_fout);
    }
    __s = *__nextp;
  } else {
    {
    fprintf(_coverage_fout, "144\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "161\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "146\n");
    fflush(_coverage_fout);
    }
    if ((int )*__s == (int )__sep) {
      {
      fprintf(_coverage_fout, "145\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "147\n");
    fflush(_coverage_fout);
    }
    __s ++;
  }
  {
  fprintf(_coverage_fout, "162\n");
  fflush(_coverage_fout);
  }
  __result = (char *)((void *)0);
  {
  fprintf(_coverage_fout, "163\n");
  fflush(_coverage_fout);
  }
  if ((int )*__s != 0) {
    {
    fprintf(_coverage_fout, "155\n");
    fflush(_coverage_fout);
    }
    tmp = __s;
    {
    fprintf(_coverage_fout, "156\n");
    fflush(_coverage_fout);
    }
    __s ++;
    {
    fprintf(_coverage_fout, "157\n");
    fflush(_coverage_fout);
    }
    __result = tmp;
    {
    fprintf(_coverage_fout, "158\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "151\n");
      fflush(_coverage_fout);
      }
      if ((int )*__s != 0) {
        {
        fprintf(_coverage_fout, "148\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "152\n");
      fflush(_coverage_fout);
      }
      tmp___0 = __s;
      {
      fprintf(_coverage_fout, "153\n");
      fflush(_coverage_fout);
      }
      __s ++;
      {
      fprintf(_coverage_fout, "154\n");
      fflush(_coverage_fout);
      }
      if ((int )*tmp___0 == (int )__sep) {
        {
        fprintf(_coverage_fout, "149\n");
        fflush(_coverage_fout);
        }
        *(__s + -1) = (char )'\000';
        break;
      } else {
        {
        fprintf(_coverage_fout, "150\n");
        fflush(_coverage_fout);
        }

      }
    }
  } else {
    {
    fprintf(_coverage_fout, "159\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "164\n");
  fflush(_coverage_fout);
  }
  *__nextp = __s;
  {
  fprintf(_coverage_fout, "165\n");
  fflush(_coverage_fout);
  }
  return (__result);
}
}
extern char *__strsep_g(char **__stringp , char const   *__delim ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) 
{ register char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  void *tmp___1 ;
  char *tmp___2 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "175\n");
  fflush(_coverage_fout);
  }
  __retval = *__s;
  {
  fprintf(_coverage_fout, "176\n");
  fflush(_coverage_fout);
  }
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    {
    fprintf(_coverage_fout, "170\n");
    fflush(_coverage_fout);
    }
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    {
    fprintf(_coverage_fout, "171\n");
    fflush(_coverage_fout);
    }
    tmp___0 = tmp___2;
    {
    fprintf(_coverage_fout, "172\n");
    fflush(_coverage_fout);
    }
    *__s = tmp___0;
    {
    fprintf(_coverage_fout, "173\n");
    fflush(_coverage_fout);
    }
    if ((unsigned int )tmp___0 != (unsigned int )((void *)0)) {
      {
      fprintf(_coverage_fout, "166\n");
      fflush(_coverage_fout);
      }
      tmp = *__s;
      {
      fprintf(_coverage_fout, "167\n");
      fflush(_coverage_fout);
      }
      (*__s) ++;
      {
      fprintf(_coverage_fout, "168\n");
      fflush(_coverage_fout);
      }
      *tmp = (char )'\000';
    } else {
      {
      fprintf(_coverage_fout, "169\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "174\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "177\n");
  fflush(_coverage_fout);
  }
  return (__retval);
}
}
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) ;
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "195\n");
  fflush(_coverage_fout);
  }
  __retval = *__s;
  {
  fprintf(_coverage_fout, "196\n");
  fflush(_coverage_fout);
  }
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    {
    fprintf(_coverage_fout, "191\n");
    fflush(_coverage_fout);
    }
    __cp = __retval;
    {
    fprintf(_coverage_fout, "192\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "188\n");
      fflush(_coverage_fout);
      }
      if ((int )*__cp == 0) {
        {
        fprintf(_coverage_fout, "178\n");
        fflush(_coverage_fout);
        }
        __cp = (char *)((void *)0);
        break;
      } else {
        {
        fprintf(_coverage_fout, "179\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "189\n");
      fflush(_coverage_fout);
      }
      if ((int )*__cp == (int )__reject1) {
        {
        fprintf(_coverage_fout, "180\n");
        fflush(_coverage_fout);
        }
        tmp = __cp;
        {
        fprintf(_coverage_fout, "181\n");
        fflush(_coverage_fout);
        }
        __cp ++;
        {
        fprintf(_coverage_fout, "182\n");
        fflush(_coverage_fout);
        }
        *tmp = (char )'\000';
        break;
      } else {
        {
        fprintf(_coverage_fout, "187\n");
        fflush(_coverage_fout);
        }
        if ((int )*__cp == (int )__reject2) {
          {
          fprintf(_coverage_fout, "183\n");
          fflush(_coverage_fout);
          }
          tmp = __cp;
          {
          fprintf(_coverage_fout, "184\n");
          fflush(_coverage_fout);
          }
          __cp ++;
          {
          fprintf(_coverage_fout, "185\n");
          fflush(_coverage_fout);
          }
          *tmp = (char )'\000';
          break;
        } else {
          {
          fprintf(_coverage_fout, "186\n");
          fflush(_coverage_fout);
          }

        }
      }
      {
      fprintf(_coverage_fout, "190\n");
      fflush(_coverage_fout);
      }
      __cp ++;
    }
    {
    fprintf(_coverage_fout, "193\n");
    fflush(_coverage_fout);
    }
    *__s = __cp;
  } else {
    {
    fprintf(_coverage_fout, "194\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "197\n");
  fflush(_coverage_fout);
  }
  return (__retval);
}
}
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) ;
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "219\n");
  fflush(_coverage_fout);
  }
  __retval = *__s;
  {
  fprintf(_coverage_fout, "220\n");
  fflush(_coverage_fout);
  }
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    {
    fprintf(_coverage_fout, "215\n");
    fflush(_coverage_fout);
    }
    __cp = __retval;
    {
    fprintf(_coverage_fout, "216\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "212\n");
      fflush(_coverage_fout);
      }
      if ((int )*__cp == 0) {
        {
        fprintf(_coverage_fout, "198\n");
        fflush(_coverage_fout);
        }
        __cp = (char *)((void *)0);
        break;
      } else {
        {
        fprintf(_coverage_fout, "199\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "213\n");
      fflush(_coverage_fout);
      }
      if ((int )*__cp == (int )__reject1) {
        {
        fprintf(_coverage_fout, "200\n");
        fflush(_coverage_fout);
        }
        tmp = __cp;
        {
        fprintf(_coverage_fout, "201\n");
        fflush(_coverage_fout);
        }
        __cp ++;
        {
        fprintf(_coverage_fout, "202\n");
        fflush(_coverage_fout);
        }
        *tmp = (char )'\000';
        break;
      } else {
        {
        fprintf(_coverage_fout, "211\n");
        fflush(_coverage_fout);
        }
        if ((int )*__cp == (int )__reject2) {
          {
          fprintf(_coverage_fout, "203\n");
          fflush(_coverage_fout);
          }
          tmp = __cp;
          {
          fprintf(_coverage_fout, "204\n");
          fflush(_coverage_fout);
          }
          __cp ++;
          {
          fprintf(_coverage_fout, "205\n");
          fflush(_coverage_fout);
          }
          *tmp = (char )'\000';
          break;
        } else {
          {
          fprintf(_coverage_fout, "210\n");
          fflush(_coverage_fout);
          }
          if ((int )*__cp == (int )__reject3) {
            {
            fprintf(_coverage_fout, "206\n");
            fflush(_coverage_fout);
            }
            tmp = __cp;
            {
            fprintf(_coverage_fout, "207\n");
            fflush(_coverage_fout);
            }
            __cp ++;
            {
            fprintf(_coverage_fout, "208\n");
            fflush(_coverage_fout);
            }
            *tmp = (char )'\000';
            break;
          } else {
            {
            fprintf(_coverage_fout, "209\n");
            fflush(_coverage_fout);
            }

          }
        }
      }
      {
      fprintf(_coverage_fout, "214\n");
      fflush(_coverage_fout);
      }
      __cp ++;
    }
    {
    fprintf(_coverage_fout, "217\n");
    fflush(_coverage_fout);
    }
    *__s = __cp;
  } else {
    {
    fprintf(_coverage_fout, "218\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "221\n");
  fflush(_coverage_fout);
  }
  return (__retval);
}
}
extern  __attribute__((__nothrow__)) char *__strdup(char const   *__string )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strndup(char const   *__string ,
                                                     size_t __n )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) unsigned short const   **__ctype_b_loc(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) __int32_t const   **__ctype_tolower_loc(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) __int32_t const   **__ctype_toupper_loc(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int isalnum(int  ) ;
extern  __attribute__((__nothrow__)) int isalpha(int  ) ;
extern  __attribute__((__nothrow__)) int iscntrl(int  ) ;
extern  __attribute__((__nothrow__)) int isdigit(int  ) ;
extern  __attribute__((__nothrow__)) int islower(int  ) ;
extern  __attribute__((__nothrow__)) int isgraph(int  ) ;
extern  __attribute__((__nothrow__)) int isprint(int  ) ;
extern  __attribute__((__nothrow__)) int ispunct(int  ) ;
extern  __attribute__((__nothrow__)) int isspace(int  ) ;
extern  __attribute__((__nothrow__)) int isupper(int  ) ;
extern  __attribute__((__nothrow__)) int isxdigit(int  ) ;
__inline extern  __attribute__((__nothrow__)) int tolower(int __c ) ;
__inline extern  __attribute__((__nothrow__)) int toupper(int __c ) ;
extern  __attribute__((__nothrow__)) int isblank(int  ) ;
extern  __attribute__((__nothrow__)) int isascii(int __c ) ;
extern  __attribute__((__nothrow__)) int toascii(int __c ) ;
extern  __attribute__((__nothrow__)) int _toupper(int  ) ;
extern  __attribute__((__nothrow__)) int _tolower(int  ) ;
__inline extern  __attribute__((__nothrow__)) int tolower(int __c ) ;
__inline extern int tolower(int __c ) 
{ __int32_t const   **tmp ;
  __int32_t tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "227\n");
  fflush(_coverage_fout);
  }
  if (__c >= -128) {
    {
    fprintf(_coverage_fout, "225\n");
    fflush(_coverage_fout);
    }
    if (__c < 256) {
      {
      fprintf(_coverage_fout, "222\n");
      fflush(_coverage_fout);
      }
      tmp = __ctype_tolower_loc();
      {
      fprintf(_coverage_fout, "223\n");
      fflush(_coverage_fout);
      }
      tmp___0 = *(*tmp + __c);
    } else {
      {
      fprintf(_coverage_fout, "224\n");
      fflush(_coverage_fout);
      }
      tmp___0 = (int const   )__c;
    }
  } else {
    {
    fprintf(_coverage_fout, "226\n");
    fflush(_coverage_fout);
    }
    tmp___0 = (int const   )__c;
  }
  {
  fprintf(_coverage_fout, "228\n");
  fflush(_coverage_fout);
  }
  return ((int )tmp___0);
}
}
__inline extern  __attribute__((__nothrow__)) int toupper(int __c ) ;
__inline extern int toupper(int __c ) 
{ __int32_t const   **tmp ;
  __int32_t tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "234\n");
  fflush(_coverage_fout);
  }
  if (__c >= -128) {
    {
    fprintf(_coverage_fout, "232\n");
    fflush(_coverage_fout);
    }
    if (__c < 256) {
      {
      fprintf(_coverage_fout, "229\n");
      fflush(_coverage_fout);
      }
      tmp = __ctype_toupper_loc();
      {
      fprintf(_coverage_fout, "230\n");
      fflush(_coverage_fout);
      }
      tmp___0 = *(*tmp + __c);
    } else {
      {
      fprintf(_coverage_fout, "231\n");
      fflush(_coverage_fout);
      }
      tmp___0 = (int const   )__c;
    }
  } else {
    {
    fprintf(_coverage_fout, "233\n");
    fflush(_coverage_fout);
    }
    tmp___0 = (int const   )__c;
  }
  {
  fprintf(_coverage_fout, "235\n");
  fflush(_coverage_fout);
  }
  return ((int )tmp___0);
}
}
extern  __attribute__((__nothrow__)) int isalnum_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isalpha_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int iscntrl_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isdigit_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int islower_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isgraph_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isprint_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int ispunct_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isspace_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isupper_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isxdigit_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int isblank_l(int  , __locale_t  ) ;
extern  __attribute__((__nothrow__)) int __tolower_l(int __c , __locale_t __l ) ;
extern  __attribute__((__nothrow__)) int tolower_l(int __c , __locale_t __l ) ;
extern  __attribute__((__nothrow__)) int __toupper_l(int __c , __locale_t __l ) ;
extern  __attribute__((__nothrow__)) int toupper_l(int __c , __locale_t __l ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_fail(char const   *__assertion ,
                                  char const   *__file , unsigned int __line ,
                                  char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_perror_fail(int __errnum , char const   *__file ,
                                         unsigned int __line ,
                                         char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert(char const   *__assertion , char const   *__file ,
                             int __line ) ;
extern  __attribute__((__nothrow__)) int access(char const   *__name ,
                                                int __type )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int faccessat(int __fd ,
                                                   char const   *__file ,
                                                   int __type , int __flag )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) __off64_t lseek(int __fd ,
                                                     __off64_t __offset ,
                                                     int __whence )  __asm__("lseek64")  ;
extern int close(int __fd ) ;
extern ssize_t read(int __fd , void *__buf , size_t __nbytes ) ;
extern ssize_t write(int __fd , void const   *__buf , size_t __n ) ;
extern ssize_t pread(int __fd , void *__buf , size_t __nbytes ,
                     __off64_t __offset )  __asm__("pread64")  ;
extern ssize_t pwrite(int __fd , void const   *__buf , size_t __nbytes ,
                      __off64_t __offset )  __asm__("pwrite64")  ;
extern  __attribute__((__nothrow__)) int pipe(int *__pipedes ) ;
extern  __attribute__((__nothrow__)) unsigned int alarm(unsigned int __seconds ) ;
extern unsigned int sleep(unsigned int __seconds ) ;
extern  __attribute__((__nothrow__)) __useconds_t ualarm(__useconds_t __value ,
                                                         __useconds_t __interval ) ;
extern int usleep(__useconds_t __useconds ) ;
extern int pause(void) ;
extern  __attribute__((__nothrow__)) int chown(char const   *__file ,
                                               __uid_t __owner ,
                                               __gid_t __group )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int fchown(int __fd , __uid_t __owner ,
                                                __gid_t __group ) ;
extern  __attribute__((__nothrow__)) int lchown(char const   *__file ,
                                                __uid_t __owner ,
                                                __gid_t __group )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int fchownat(int __fd ,
                                                  char const   *__file ,
                                                  __uid_t __owner ,
                                                  __gid_t __group , int __flag )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int chdir(char const   *__path )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int fchdir(int __fd ) ;
extern  __attribute__((__nothrow__)) char *getcwd(char *__buf , size_t __size ) ;
extern  __attribute__((__nothrow__)) char *getwd(char *__buf )  __attribute__((__nonnull__(1),
__deprecated__)) ;
extern  __attribute__((__nothrow__)) int dup(int __fd ) ;
extern  __attribute__((__nothrow__)) int dup2(int __fd , int __fd2 ) ;
extern char **__environ ;
extern  __attribute__((__nothrow__)) int execve(char const   *__path ,
                                                char * const  *__argv ,
                                                char * const  *__envp )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int fexecve(int __fd ,
                                                 char * const  *__argv ,
                                                 char * const  *__envp )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int execv(char const   *__path ,
                                               char * const  *__argv )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execle(char const   *__path ,
                                                char const   *__arg  , ...)  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execl(char const   *__path ,
                                               char const   *__arg  , ...)  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execvp(char const   *__file ,
                                                char * const  *__argv )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int execlp(char const   *__file ,
                                                char const   *__arg  , ...)  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int nice(int __inc ) ;
extern  __attribute__((__noreturn__)) void _exit(int __status ) ;
extern  __attribute__((__nothrow__)) long pathconf(char const   *__path ,
                                                   int __name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) long fpathconf(int __fd , int __name ) ;
extern  __attribute__((__nothrow__)) long sysconf(int __name ) ;
extern  __attribute__((__nothrow__)) size_t confstr(int __name , char *__buf ,
                                                    size_t __len ) ;
extern  __attribute__((__nothrow__)) __pid_t getpid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getppid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getpgrp(void) ;
extern  __attribute__((__nothrow__)) __pid_t __getpgid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) __pid_t getpgid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) int setpgid(__pid_t __pid , __pid_t __pgid ) ;
extern  __attribute__((__nothrow__)) int setpgrp(void) ;
extern  __attribute__((__nothrow__)) __pid_t setsid(void) ;
extern  __attribute__((__nothrow__)) __pid_t getsid(__pid_t __pid ) ;
extern  __attribute__((__nothrow__)) __uid_t getuid(void) ;
extern  __attribute__((__nothrow__)) __uid_t geteuid(void) ;
extern  __attribute__((__nothrow__)) __gid_t getgid(void) ;
extern  __attribute__((__nothrow__)) __gid_t getegid(void) ;
extern  __attribute__((__nothrow__)) int getgroups(int __size , __gid_t *__list ) ;
extern  __attribute__((__nothrow__)) int setuid(__uid_t __uid ) ;
extern  __attribute__((__nothrow__)) int setreuid(__uid_t __ruid ,
                                                  __uid_t __euid ) ;
extern  __attribute__((__nothrow__)) int seteuid(__uid_t __uid ) ;
extern  __attribute__((__nothrow__)) int setgid(__gid_t __gid ) ;
extern  __attribute__((__nothrow__)) int setregid(__gid_t __rgid ,
                                                  __gid_t __egid ) ;
extern  __attribute__((__nothrow__)) int setegid(__gid_t __gid ) ;
extern  __attribute__((__nothrow__)) __pid_t fork(void) ;
extern  __attribute__((__nothrow__)) __pid_t vfork(void) ;
extern  __attribute__((__nothrow__)) char *ttyname(int __fd ) ;
extern  __attribute__((__nothrow__)) int ttyname_r(int __fd , char *__buf ,
                                                   size_t __buflen )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int isatty(int __fd ) ;
extern  __attribute__((__nothrow__)) int ttyslot(void) ;
extern  __attribute__((__nothrow__)) int link(char const   *__from ,
                                              char const   *__to )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int linkat(int __fromfd ,
                                                char const   *__from ,
                                                int __tofd ,
                                                char const   *__to ,
                                                int __flags )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) int symlink(char const   *__from ,
                                                 char const   *__to )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) ssize_t readlink(char const   * __restrict  __path ,
                                                      char * __restrict  __buf ,
                                                      size_t __len )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int symlinkat(char const   *__from ,
                                                   int __tofd ,
                                                   char const   *__to )  __attribute__((__nonnull__(1,3))) ;
extern  __attribute__((__nothrow__)) ssize_t readlinkat(int __fd ,
                                                        char const   * __restrict  __path ,
                                                        char * __restrict  __buf ,
                                                        size_t __len )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) int unlink(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int unlinkat(int __fd ,
                                                  char const   *__name ,
                                                  int __flag )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int rmdir(char const   *__path )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) __pid_t tcgetpgrp(int __fd ) ;
extern  __attribute__((__nothrow__)) int tcsetpgrp(int __fd , __pid_t __pgrp_id ) ;
extern char *getlogin(void) ;
extern int getlogin_r(char *__name , size_t __name_len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int setlogin(char const   *__name )  __attribute__((__nonnull__(1))) ;
extern char *optarg ;
extern int optind ;
extern int opterr ;
extern int optopt ;
extern  __attribute__((__nothrow__)) int getopt(int ___argc ,
                                                char * const  *___argv ,
                                                char const   *__shortopts ) ;
extern  __attribute__((__nothrow__)) int gethostname(char *__name ,
                                                     size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int sethostname(char const   *__name ,
                                                     size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int sethostid(long __id ) ;
extern  __attribute__((__nothrow__)) int getdomainname(char *__name ,
                                                       size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int setdomainname(char const   *__name ,
                                                       size_t __len )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int vhangup(void) ;
extern  __attribute__((__nothrow__)) int revoke(char const   *__file )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int profil(unsigned short *__sample_buffer ,
                                                size_t __size ,
                                                size_t __offset ,
                                                unsigned int __scale )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int acct(char const   *__name ) ;
extern  __attribute__((__nothrow__)) char *getusershell(void) ;
extern  __attribute__((__nothrow__)) void endusershell(void) ;
extern  __attribute__((__nothrow__)) void setusershell(void) ;
extern  __attribute__((__nothrow__)) int daemon(int __nochdir , int __noclose ) ;
extern  __attribute__((__nothrow__)) int chroot(char const   *__path )  __attribute__((__nonnull__(1))) ;
extern char *getpass(char const   *__prompt )  __attribute__((__nonnull__(1))) ;
extern int fsync(int __fd ) ;
extern long gethostid(void) ;
extern  __attribute__((__nothrow__)) void sync(void) ;
extern  __attribute__((__nothrow__)) int getpagesize(void)  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int getdtablesize(void) ;
extern  __attribute__((__nothrow__)) int truncate(char const   *__file ,
                                                  __off64_t __length )  __asm__("truncate64") __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int ftruncate(int __fd ,
                                                   __off64_t __length )  __asm__("ftruncate64")  ;
extern  __attribute__((__nothrow__)) int brk(void *__addr ) ;
extern  __attribute__((__nothrow__)) void *sbrk(intptr_t __delta ) ;
extern  __attribute__((__nothrow__)) long syscall(long __sysno  , ...) ;
extern int lockf(int __fd , int __cmd , __off64_t __len )  __asm__("lockf64")  ;
extern int fdatasync(int __fildes ) ;
extern char const   *TIFFGetVersion(void) ;
extern TIFFCodec const   *TIFFFindCODEC(uint16  ) ;
extern TIFFCodec *TIFFRegisterCODEC(uint16  , char const   * ,
                                    int (*)(TIFF * , int  ) ) ;
extern void TIFFUnRegisterCODEC(TIFFCodec * ) ;
extern int TIFFIsCODECConfigured(uint16  ) ;
extern TIFFCodec *TIFFGetConfiguredCODECs(void) ;
extern tdata_t _TIFFmalloc(tsize_t  ) ;
extern tdata_t _TIFFrealloc(tdata_t  , tsize_t  ) ;
extern void _TIFFmemset(tdata_t  , int  , tsize_t  ) ;
extern void _TIFFmemcpy(tdata_t  , tdata_t  , tsize_t  ) ;
extern int _TIFFmemcmp(tdata_t  , tdata_t  , tsize_t  ) ;
extern void _TIFFfree(tdata_t  ) ;
extern int TIFFGetTagListCount(TIFF * ) ;
extern ttag_t TIFFGetTagListEntry(TIFF * , int tag_index ) ;
extern void TIFFMergeFieldInfo(TIFF * , TIFFFieldInfo const   * , int  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfo(TIFF * , ttag_t  ,
                                                TIFFDataType  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfoByName(TIFF * , char const   * ,
                                                      TIFFDataType  ) ;
extern TIFFFieldInfo const   *TIFFFieldWithTag(TIFF * , ttag_t  ) ;
extern TIFFFieldInfo const   *TIFFFieldWithName(TIFF * , char const   * ) ;
extern TIFFTagMethods *TIFFAccessTagMethods(TIFF * ) ;
extern void *TIFFGetClientInfo(TIFF * , char const   * ) ;
extern void TIFFSetClientInfo(TIFF * , void * , char const   * ) ;
extern void TIFFCleanup(TIFF * ) ;
extern void TIFFClose(TIFF * ) ;
extern int TIFFFlush(TIFF * ) ;
extern int TIFFFlushData(TIFF * ) ;
extern int TIFFGetField(TIFF * , ttag_t   , ...) ;
extern int TIFFVGetField(TIFF * , ttag_t  , va_list  ) ;
extern int TIFFGetFieldDefaulted(TIFF * , ttag_t   , ...) ;
extern int TIFFVGetFieldDefaulted(TIFF * , ttag_t  , va_list  ) ;
extern int TIFFReadDirectory(TIFF * ) ;
extern int TIFFReadCustomDirectory(TIFF * , toff_t  , TIFFFieldInfo const   * ,
                                   size_t  ) ;
extern int TIFFReadEXIFDirectory(TIFF * , toff_t  ) ;
extern tsize_t TIFFScanlineSize(TIFF * ) ;
extern tsize_t TIFFRasterScanlineSize(TIFF * ) ;
extern tsize_t TIFFStripSize(TIFF * ) ;
extern tsize_t TIFFRawStripSize(TIFF * , tstrip_t  ) ;
extern tsize_t TIFFVStripSize(TIFF * , uint32  ) ;
extern tsize_t TIFFTileRowSize(TIFF * ) ;
extern tsize_t TIFFTileSize(TIFF * ) ;
extern tsize_t TIFFVTileSize(TIFF * , uint32  ) ;
extern uint32 TIFFDefaultStripSize(TIFF * , uint32  ) ;
extern void TIFFDefaultTileSize(TIFF * , uint32 * , uint32 * ) ;
extern int TIFFFileno(TIFF * ) ;
extern int TIFFSetFileno(TIFF * , int  ) ;
extern thandle_t TIFFClientdata(TIFF * ) ;
extern thandle_t TIFFSetClientdata(TIFF * , thandle_t  ) ;
extern int TIFFGetMode(TIFF * ) ;
extern int TIFFSetMode(TIFF * , int  ) ;
extern int TIFFIsTiled(TIFF * ) ;
extern int TIFFIsByteSwapped(TIFF * ) ;
extern int TIFFIsUpSampled(TIFF * ) ;
extern int TIFFIsMSB2LSB(TIFF * ) ;
extern int TIFFIsBigEndian(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetReadProc(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetWriteProc(TIFF * ) ;
extern TIFFSeekProc TIFFGetSeekProc(TIFF * ) ;
extern TIFFCloseProc TIFFGetCloseProc(TIFF * ) ;
extern TIFFSizeProc TIFFGetSizeProc(TIFF * ) ;
extern TIFFMapFileProc TIFFGetMapFileProc(TIFF * ) ;
extern TIFFUnmapFileProc TIFFGetUnmapFileProc(TIFF * ) ;
extern uint32 TIFFCurrentRow(TIFF * ) ;
extern tdir_t TIFFCurrentDirectory(TIFF * ) ;
extern tdir_t TIFFNumberOfDirectories(TIFF * ) ;
extern uint32 TIFFCurrentDirOffset(TIFF * ) ;
extern tstrip_t TIFFCurrentStrip(TIFF * ) ;
extern ttile_t TIFFCurrentTile(TIFF * ) ;
extern int TIFFReadBufferSetup(TIFF * , tdata_t  , tsize_t  ) ;
extern int TIFFWriteBufferSetup(TIFF * , tdata_t  , tsize_t  ) ;
extern int TIFFSetupStrips(TIFF * ) ;
extern int TIFFWriteCheck(TIFF * , int  , char const   * ) ;
extern void TIFFFreeDirectory(TIFF * ) ;
extern int TIFFCreateDirectory(TIFF * ) ;
extern int TIFFLastDirectory(TIFF * ) ;
extern int TIFFSetDirectory(TIFF * , tdir_t  ) ;
extern int TIFFSetSubDirectory(TIFF * , uint32  ) ;
extern int TIFFUnlinkDirectory(TIFF * , tdir_t  ) ;
extern int TIFFSetField(TIFF * , ttag_t   , ...) ;
extern int TIFFVSetField(TIFF * , ttag_t  , va_list  ) ;
extern int TIFFWriteDirectory(TIFF * ) ;
extern int TIFFCheckpointDirectory(TIFF * ) ;
extern int TIFFRewriteDirectory(TIFF * ) ;
extern int TIFFReassignTagToIgnore(enum TIFFIgnoreSense  , int  ) ;
extern void TIFFPrintDirectory(TIFF * , FILE * , long  ) ;
extern int TIFFReadScanline(TIFF * , tdata_t  , uint32  , tsample_t  ) ;
extern int TIFFWriteScanline(TIFF * , tdata_t  , uint32  , tsample_t  ) ;
extern int TIFFReadRGBAImage(TIFF * , uint32  , uint32  , uint32 * , int  ) ;
extern int TIFFReadRGBAImageOriented(TIFF * , uint32  , uint32  , uint32 * ,
                                     int  , int  ) ;
extern int TIFFReadRGBAStrip(TIFF * , tstrip_t  , uint32 * ) ;
extern int TIFFReadRGBATile(TIFF * , uint32  , uint32  , uint32 * ) ;
extern int TIFFRGBAImageOK(TIFF * , char * ) ;
extern int TIFFRGBAImageBegin(TIFFRGBAImage * , TIFF * , int  , char * ) ;
extern int TIFFRGBAImageGet(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
extern void TIFFRGBAImageEnd(TIFFRGBAImage * ) ;
extern TIFF *TIFFOpen(char const   * , char const   * ) ;
extern TIFF *TIFFFdOpen(int  , char const   * , char const   * ) ;
extern TIFF *TIFFClientOpen(char const   * , char const   * , thandle_t  ,
                            tsize_t (*)(thandle_t  , tdata_t  , tsize_t  ) ,
                            tsize_t (*)(thandle_t  , tdata_t  , tsize_t  ) ,
                            toff_t (*)(thandle_t  , toff_t  , int  ) ,
                            int (*)(thandle_t  ) , toff_t (*)(thandle_t  ) ,
                            int (*)(thandle_t  , tdata_t * , toff_t * ) ,
                            void (*)(thandle_t  , tdata_t  , toff_t  ) ) ;
extern char const   *TIFFFileName(TIFF * ) ;
extern char const   *TIFFSetFileName(TIFF * , char const   * ) ;
extern void TIFFError(char const   * , char const   *  , ...) ;
extern void TIFFWarning(char const   * , char const   *  , ...) ;
extern TIFFErrorHandler TIFFSetErrorHandler(void (*)(char const   * ,
                                                     char const   * , va_list  ) ) ;
extern TIFFErrorHandler TIFFSetWarningHandler(void (*)(char const   * ,
                                                       char const   * ,
                                                       va_list  ) ) ;
extern TIFFExtendProc TIFFSetTagExtender(void (*)(TIFF * ) ) ;
extern ttile_t TIFFComputeTile(TIFF * , uint32  , uint32  , uint32  ,
                               tsample_t  ) ;
extern int TIFFCheckTile(TIFF * , uint32  , uint32  , uint32  , tsample_t  ) ;
extern ttile_t TIFFNumberOfTiles(TIFF * ) ;
extern tsize_t TIFFReadTile(TIFF * , tdata_t  , uint32  , uint32  , uint32  ,
                            tsample_t  ) ;
extern tsize_t TIFFWriteTile(TIFF * , tdata_t  , uint32  , uint32  , uint32  ,
                             tsample_t  ) ;
extern tstrip_t TIFFComputeStrip(TIFF * , uint32  , tsample_t  ) ;
extern tstrip_t TIFFNumberOfStrips(TIFF * ) ;
extern tsize_t TIFFReadEncodedStrip(TIFF * , tstrip_t  , tdata_t  , tsize_t  ) ;
extern tsize_t TIFFReadRawStrip(TIFF * , tstrip_t  , tdata_t  , tsize_t  ) ;
extern tsize_t TIFFReadEncodedTile(TIFF * , ttile_t  , tdata_t  , tsize_t  ) ;
extern tsize_t TIFFReadRawTile(TIFF * , ttile_t  , tdata_t  , tsize_t  ) ;
extern tsize_t TIFFWriteEncodedStrip(TIFF * , tstrip_t  , tdata_t  , tsize_t  ) ;
extern tsize_t TIFFWriteRawStrip(TIFF * , tstrip_t  , tdata_t  , tsize_t  ) ;
extern tsize_t TIFFWriteEncodedTile(TIFF * , ttile_t  , tdata_t  , tsize_t  ) ;
extern tsize_t TIFFWriteRawTile(TIFF * , ttile_t  , tdata_t  , tsize_t  ) ;
extern int TIFFDataWidth(TIFFDataType  ) ;
extern void TIFFSetWriteOffset(TIFF * , toff_t  ) ;
extern void TIFFSwabShort(uint16 * ) ;
extern void TIFFSwabLong(uint32 * ) ;
extern void TIFFSwabDouble(double * ) ;
extern void TIFFSwabArrayOfShort(uint16 * , unsigned long  ) ;
extern void TIFFSwabArrayOfTriples(uint8 * , unsigned long  ) ;
extern void TIFFSwabArrayOfLong(uint32 * , unsigned long  ) ;
extern void TIFFSwabArrayOfDouble(double * , unsigned long  ) ;
extern void TIFFReverseBits(unsigned char * , unsigned long  ) ;
extern unsigned char const   *TIFFGetBitRevTable(int  ) ;
extern double LogL16toY(int  ) ;
extern double LogL10toY(int  ) ;
extern void XYZtoRGB24(float * , uint8 * ) ;
extern int uv_decode(double * , double * , int  ) ;
extern void LogLuv24toXYZ(uint32  , float * ) ;
extern void LogLuv32toXYZ(uint32  , float * ) ;
extern int LogL16fromY(double  , int  ) ;
extern int LogL10fromY(double  , int  ) ;
extern int uv_encode(double  , double  , int  ) ;
extern uint32 LogLuv24fromXYZ(float * , int  ) ;
extern uint32 LogLuv32fromXYZ(float * , int  ) ;
extern int TIFFCIELabToRGBInit(TIFFCIELabToRGB * , TIFFDisplay * , float * ) ;
extern void TIFFCIELabToXYZ(TIFFCIELabToRGB * , uint32  , int32  , int32  ,
                            float * , float * , float * ) ;
extern void TIFFXYZToRGB(TIFFCIELabToRGB * , float  , float  , float  ,
                         uint32 * , uint32 * , uint32 * ) ;
extern int TIFFYCbCrToRGBInit(TIFFYCbCrToRGB * , float * , float * ) ;
extern void TIFFYCbCrtoRGB(TIFFYCbCrToRGB * , uint32  , int32  , int32  ,
                           uint32 * , uint32 * , uint32 * ) ;
static int outtiled  =    -1;
static uint32 tilewidth  ;
static uint32 tilelength  ;
static uint16 config  ;
static uint16 compression  ;
static uint16 predictor  ;
static uint16 fillorder  ;
static uint16 orientation  ;
static uint32 rowsperstrip  ;
static uint32 g3opts  ;
static int ignore  =    0;
static uint32 defg3opts  =    4294967295U;
static int quality  =    75;
static int jpegcolormode  =    0x0001;
static uint16 defcompression  =    (unsigned short)65535;
static uint16 defpredictor  =    (unsigned short)65535;
static int tiffcp(TIFF *in , TIFF *out ) ;
static int processCompressOptions(char *opt ) ;
static void usage(void) ;
static char comma  =    (char )',';
static TIFF *bias  =    (TIFF *)((void *)0);
static int pageNum  =    0;
static int nextSrcImage(TIFF *tif , char **imageSpec ) 
{ char *start ;
  tdir_t nextImage ;
  long tmp ;
  char const   *tmp___0 ;
  int tmp___1 ;
  char const   *tmp___2 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "258\n");
  fflush(_coverage_fout);
  }
  if ((int )*(*imageSpec) == (int )comma) {
    {
    fprintf(_coverage_fout, "248\n");
    fflush(_coverage_fout);
    }
    start = *imageSpec + 1;
    {
    fprintf(_coverage_fout, "249\n");
    fflush(_coverage_fout);
    }
    tmp = strtol((char const   */* __restrict  */)start,
                 (char **/* __restrict  */)imageSpec, 0);
    {
    fprintf(_coverage_fout, "250\n");
    fflush(_coverage_fout);
    }
    nextImage = (unsigned short )tmp;
    {
    fprintf(_coverage_fout, "251\n");
    fflush(_coverage_fout);
    }
    if ((unsigned int )start == (unsigned int )*imageSpec) {
      {
      fprintf(_coverage_fout, "236\n");
      fflush(_coverage_fout);
      }
      nextImage = TIFFCurrentDirectory(tif);
    } else {
      {
      fprintf(_coverage_fout, "237\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "252\n");
    fflush(_coverage_fout);
    }
    if (*(*imageSpec)) {
      {
      fprintf(_coverage_fout, "244\n");
      fflush(_coverage_fout);
      }
      if ((int )*(*imageSpec) == (int )comma) {
        {
        fprintf(_coverage_fout, "240\n");
        fflush(_coverage_fout);
        }
        if ((int )*(*imageSpec + 1) == 0) {
          {
          fprintf(_coverage_fout, "238\n");
          fflush(_coverage_fout);
          }
          *imageSpec = (char *)((void *)0);
        } else {
          {
          fprintf(_coverage_fout, "239\n");
          fflush(_coverage_fout);
          }

        }
      } else {
        {
        fprintf(_coverage_fout, "241\n");
        fflush(_coverage_fout);
        }
        tmp___0 = TIFFFileName(tif);
        {
        fprintf(_coverage_fout, "242\n");
        fflush(_coverage_fout);
        }
        fprintf((FILE */* __restrict  */)stderr,
                (char const   */* __restrict  */)"Expected a %c separated image # list after %s\n",
                comma, tmp___0);
        {
        fprintf(_coverage_fout, "243\n");
        fflush(_coverage_fout);
        }
        exit(-4);
      }
    } else {
      {
      fprintf(_coverage_fout, "245\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "253\n");
    fflush(_coverage_fout);
    }
    tmp___1 = TIFFSetDirectory(tif, nextImage);
    {
    fprintf(_coverage_fout, "254\n");
    fflush(_coverage_fout);
    }
    if (tmp___1) {
      {
      fprintf(_coverage_fout, "246\n");
      fflush(_coverage_fout);
      }
      return (1);
    } else {
      {
      fprintf(_coverage_fout, "247\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "255\n");
    fflush(_coverage_fout);
    }
    tmp___2 = TIFFFileName(tif);
    {
    fprintf(_coverage_fout, "256\n");
    fflush(_coverage_fout);
    }
    fprintf((FILE */* __restrict  */)stderr,
            (char const   */* __restrict  */)"%s%c%d not found!\n", tmp___2,
            comma, (int )nextImage);
  } else {
    {
    fprintf(_coverage_fout, "257\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "259\n");
  fflush(_coverage_fout);
  }
  return (0);
}
}
static TIFF *openSrcImage(char **imageSpec ) 
{ TIFF *tif ;
  char *fn ;
  void *tmp ;
  char *tmp___0 ;
  int tmp___1 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "275\n");
  fflush(_coverage_fout);
  }
  fn = *imageSpec;
  {
  fprintf(_coverage_fout, "276\n");
  fflush(_coverage_fout);
  }
  tmp___0 = __builtin_strchr(fn, (int )comma);
  {
  fprintf(_coverage_fout, "277\n");
  fflush(_coverage_fout);
  }
  *imageSpec = tmp___0;
  {
  fprintf(_coverage_fout, "278\n");
  fflush(_coverage_fout);
  }
  if (*imageSpec) {
    {
    fprintf(_coverage_fout, "270\n");
    fflush(_coverage_fout);
    }
    *(*imageSpec) = (char )'\000';
    {
    fprintf(_coverage_fout, "271\n");
    fflush(_coverage_fout);
    }
    tif = TIFFOpen((char const   *)fn, "r");
    {
    fprintf(_coverage_fout, "272\n");
    fflush(_coverage_fout);
    }
    if (! *(*imageSpec + 1)) {
      {
      fprintf(_coverage_fout, "260\n");
      fflush(_coverage_fout);
      }
      *imageSpec = (char *)((void *)0);
      {
      fprintf(_coverage_fout, "261\n");
      fflush(_coverage_fout);
      }
      return (tif);
    } else {
      {
      fprintf(_coverage_fout, "262\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "273\n");
    fflush(_coverage_fout);
    }
    if (tif) {
      {
      fprintf(_coverage_fout, "266\n");
      fflush(_coverage_fout);
      }
      *(*imageSpec) = comma;
      {
      fprintf(_coverage_fout, "267\n");
      fflush(_coverage_fout);
      }
      tmp___1 = nextSrcImage(tif, imageSpec);
      {
      fprintf(_coverage_fout, "268\n");
      fflush(_coverage_fout);
      }
      if (tmp___1) {
        {
        fprintf(_coverage_fout, "263\n");
        fflush(_coverage_fout);
        }

      } else {
        {
        fprintf(_coverage_fout, "264\n");
        fflush(_coverage_fout);
        }
        TIFFClose(tif);
        {
        fprintf(_coverage_fout, "265\n");
        fflush(_coverage_fout);
        }
        tif = (TIFF *)((void *)0);
      }
    } else {
      {
      fprintf(_coverage_fout, "269\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "274\n");
    fflush(_coverage_fout);
    }
    tif = TIFFOpen((char const   *)fn, "r");
  }
  {
  fprintf(_coverage_fout, "279\n");
  fflush(_coverage_fout);
  }
  return (tif);
}
}
int main(int argc , char **argv ) 
{ uint16 defconfig ;
  uint16 deffillorder ;
  uint32 deftilewidth ;
  uint32 deftilelength ;
  uint32 defrowsperstrip ;
  uint32 diroff ;
  TIFF *in ;
  TIFF *out ;
  char mode[10] ;
  char *mp ;
  int c ;
  char *tmp ;
  uint16 samples ;
  char **biasFn ;
  int tmp___0 ;
  int tmp___1 ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  unsigned char const   *__s2 ;
  register int __result ;
  int tmp___5 ;
  unsigned char const   *__s1 ;
  register int __result___0 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  unsigned char const   *__s2___0 ;
  register int __result___1 ;
  int tmp___12 ;
  unsigned char const   *__s1___0 ;
  register int __result___2 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  unsigned long tmp___17 ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___18 ;
  int tmp___19 ;
  int tmp___20 ;
  unsigned char const   *__s2___1 ;
  register int __result___3 ;
  int tmp___21 ;
  unsigned char const   *__s1___1 ;
  register int __result___4 ;
  int tmp___22 ;
  int tmp___23 ;
  int tmp___24 ;
  size_t __s1_len___2 ;
  size_t __s2_len___2 ;
  int tmp___25 ;
  int tmp___26 ;
  int tmp___27 ;
  unsigned char const   *__s2___2 ;
  register int __result___5 ;
  int tmp___28 ;
  unsigned char const   *__s1___2 ;
  register int __result___6 ;
  int tmp___29 ;
  int tmp___30 ;
  int tmp___31 ;
  long tmp___32 ;
  int tmp___33 ;
  char *tmp___34 ;
  char *tmp___35 ;
  char *tmp___36 ;
  char *tmp___37 ;
  char *imageCursor ;
  char const   *tmp___38 ;
  int tmp___39 ;
  int tmp___40 ;
  int tmp___41 ;
  int tmp___42 ;
  int tmp___43 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "473\n");
  fflush(_coverage_fout);
  }
  defconfig = (unsigned short)65535;
  {
  fprintf(_coverage_fout, "474\n");
  fflush(_coverage_fout);
  }
  deffillorder = (uint16 )0;
  {
  fprintf(_coverage_fout, "475\n");
  fflush(_coverage_fout);
  }
  deftilewidth = 4294967295U;
  {
  fprintf(_coverage_fout, "476\n");
  fflush(_coverage_fout);
  }
  deftilelength = 4294967295U;
  {
  fprintf(_coverage_fout, "477\n");
  fflush(_coverage_fout);
  }
  defrowsperstrip = 0U;
  {
  fprintf(_coverage_fout, "478\n");
  fflush(_coverage_fout);
  }
  diroff = (uint32 )0;
  {
  fprintf(_coverage_fout, "479\n");
  fflush(_coverage_fout);
  }
  mp = mode;
  {
  fprintf(_coverage_fout, "480\n");
  fflush(_coverage_fout);
  }
  tmp = mp;
  {
  fprintf(_coverage_fout, "481\n");
  fflush(_coverage_fout);
  }
  mp ++;
  {
  fprintf(_coverage_fout, "482\n");
  fflush(_coverage_fout);
  }
  *tmp = (char )'w';
  {
  fprintf(_coverage_fout, "483\n");
  fflush(_coverage_fout);
  }
  *mp = (char )'\000';
  {
  fprintf(_coverage_fout, "484\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "422\n");
    fflush(_coverage_fout);
    }
    c = getopt(argc, (char * const  *)argv, ",:b:c:f:l:o:z:p:r:w:aistBLMC");
    {
    fprintf(_coverage_fout, "423\n");
    fflush(_coverage_fout);
    }
    if (c != -1) {
      {
      fprintf(_coverage_fout, "280\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    switch (c) {
    {
    fprintf(_coverage_fout, "374\n");
    fflush(_coverage_fout);
    }
    case 44: 
    if ((int )*(optarg + 0) != 61) {
      {
      fprintf(_coverage_fout, "281\n");
      fflush(_coverage_fout);
      }
      usage();
    } else {
      {
      fprintf(_coverage_fout, "282\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "375\n");
    fflush(_coverage_fout);
    }
    comma = *(optarg + 1);
    break;
    {
    fprintf(_coverage_fout, "376\n");
    fflush(_coverage_fout);
    }
    case 98: 
    if (bias) {
      {
      fprintf(_coverage_fout, "283\n");
      fflush(_coverage_fout);
      }
      fputs((char const   */* __restrict  */)"Only 1 bias image may be specified\n",
            (FILE */* __restrict  */)stderr);
      {
      fprintf(_coverage_fout, "284\n");
      fflush(_coverage_fout);
      }
      exit(-2);
    } else {
      {
      fprintf(_coverage_fout, "285\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "377\n");
    fflush(_coverage_fout);
    }
    samples = (unsigned short)65535;
    {
    fprintf(_coverage_fout, "378\n");
    fflush(_coverage_fout);
    }
    biasFn = & optarg;
    {
    fprintf(_coverage_fout, "379\n");
    fflush(_coverage_fout);
    }
    bias = openSrcImage(biasFn);
    {
    fprintf(_coverage_fout, "380\n");
    fflush(_coverage_fout);
    }
    if (! bias) {
      {
      fprintf(_coverage_fout, "286\n");
      fflush(_coverage_fout);
      }
      exit(-5);
    } else {
      {
      fprintf(_coverage_fout, "287\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "381\n");
    fflush(_coverage_fout);
    }
    tmp___0 = TIFFIsTiled(bias);
    {
    fprintf(_coverage_fout, "382\n");
    fflush(_coverage_fout);
    }
    if (tmp___0) {
      {
      fprintf(_coverage_fout, "288\n");
      fflush(_coverage_fout);
      }
      fputs((char const   */* __restrict  */)"Bias image must be organized in strips\n",
            (FILE */* __restrict  */)stderr);
      {
      fprintf(_coverage_fout, "289\n");
      fflush(_coverage_fout);
      }
      exit(-7);
    } else {
      {
      fprintf(_coverage_fout, "290\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "383\n");
    fflush(_coverage_fout);
    }
    TIFFGetField(bias, 277U, & samples);
    {
    fprintf(_coverage_fout, "384\n");
    fflush(_coverage_fout);
    }
    if ((int )samples != 1) {
      {
      fprintf(_coverage_fout, "291\n");
      fflush(_coverage_fout);
      }
      fputs((char const   */* __restrict  */)"Bias image must be monochrome\n",
            (FILE */* __restrict  */)stderr);
      {
      fprintf(_coverage_fout, "292\n");
      fflush(_coverage_fout);
      }
      exit(-7);
    } else {
      {
      fprintf(_coverage_fout, "293\n");
      fflush(_coverage_fout);
      }

    }
    break;
    {
    fprintf(_coverage_fout, "385\n");
    fflush(_coverage_fout);
    }
    case 97: 
    mode[0] = (char )'a';
    break;
    {
    fprintf(_coverage_fout, "386\n");
    fflush(_coverage_fout);
    }
    case 99: 
    tmp___1 = processCompressOptions(optarg);
    {
    fprintf(_coverage_fout, "387\n");
    fflush(_coverage_fout);
    }
    if (tmp___1) {
      {
      fprintf(_coverage_fout, "294\n");
      fflush(_coverage_fout);
      }

    } else {
      {
      fprintf(_coverage_fout, "295\n");
      fflush(_coverage_fout);
      }
      usage();
    }
    break;
    {
    fprintf(_coverage_fout, "388\n");
    fflush(_coverage_fout);
    }
    case 102: 
    if (0) {
      {
      fprintf(_coverage_fout, "307\n");
      fflush(_coverage_fout);
      }
      __s1_len___0 = strlen((char const   *)optarg);
      {
      fprintf(_coverage_fout, "308\n");
      fflush(_coverage_fout);
      }
      __s2_len___0 = strlen("lsb2msb");
      {
      fprintf(_coverage_fout, "309\n");
      fflush(_coverage_fout);
      }
      if (! ((unsigned int )((void const   *)(optarg + 1)) - (unsigned int )((void const   *)optarg) == 1U)) {
        goto _L___2;
      } else {
        {
        fprintf(_coverage_fout, "302\n");
        fflush(_coverage_fout);
        }
        if (__s1_len___0 >= 4U) {
          {
          fprintf(_coverage_fout, "300\n");
          fflush(_coverage_fout);
          }
          _L___2: /* CIL Label */ 
          if (! ((unsigned int )((void const   *)("lsb2msb" + 1)) - (unsigned int )((void const   *)"lsb2msb") == 1U)) {
            {
            fprintf(_coverage_fout, "296\n");
            fflush(_coverage_fout);
            }
            tmp___15 = 1;
          } else {
            {
            fprintf(_coverage_fout, "299\n");
            fflush(_coverage_fout);
            }
            if (__s2_len___0 >= 4U) {
              {
              fprintf(_coverage_fout, "297\n");
              fflush(_coverage_fout);
              }
              tmp___15 = 1;
            } else {
              {
              fprintf(_coverage_fout, "298\n");
              fflush(_coverage_fout);
              }
              tmp___15 = 0;
            }
          }
        } else {
          {
          fprintf(_coverage_fout, "301\n");
          fflush(_coverage_fout);
          }
          tmp___15 = 0;
        }
      }
      {
      fprintf(_coverage_fout, "310\n");
      fflush(_coverage_fout);
      }
      if (tmp___15) {
        {
        fprintf(_coverage_fout, "303\n");
        fflush(_coverage_fout);
        }
        tmp___10 = __builtin_strcmp((char const   *)optarg, "lsb2msb");
        {
        fprintf(_coverage_fout, "304\n");
        fflush(_coverage_fout);
        }
        tmp___14 = tmp___10;
      } else {
        {
        fprintf(_coverage_fout, "305\n");
        fflush(_coverage_fout);
        }
        tmp___13 = __builtin_strcmp((char const   *)optarg, "lsb2msb");
        {
        fprintf(_coverage_fout, "306\n");
        fflush(_coverage_fout);
        }
        tmp___14 = tmp___13;
      }
    } else {
      {
      fprintf(_coverage_fout, "311\n");
      fflush(_coverage_fout);
      }
      tmp___13 = __builtin_strcmp((char const   *)optarg, "lsb2msb");
      {
      fprintf(_coverage_fout, "312\n");
      fflush(_coverage_fout);
      }
      tmp___14 = tmp___13;
    }
    {
    fprintf(_coverage_fout, "389\n");
    fflush(_coverage_fout);
    }
    if (tmp___14 == 0) {
      {
      fprintf(_coverage_fout, "313\n");
      fflush(_coverage_fout);
      }
      deffillorder = (unsigned short)2;
    } else {
      {
      fprintf(_coverage_fout, "333\n");
      fflush(_coverage_fout);
      }
      if (0) {
        {
        fprintf(_coverage_fout, "325\n");
        fflush(_coverage_fout);
        }
        __s1_len = strlen((char const   *)optarg);
        {
        fprintf(_coverage_fout, "326\n");
        fflush(_coverage_fout);
        }
        __s2_len = strlen("msb2lsb");
        {
        fprintf(_coverage_fout, "327\n");
        fflush(_coverage_fout);
        }
        if (! ((unsigned int )((void const   *)(optarg + 1)) - (unsigned int )((void const   *)optarg) == 1U)) {
          goto _L___0;
        } else {
          {
          fprintf(_coverage_fout, "320\n");
          fflush(_coverage_fout);
          }
          if (__s1_len >= 4U) {
            {
            fprintf(_coverage_fout, "318\n");
            fflush(_coverage_fout);
            }
            _L___0: /* CIL Label */ 
            if (! ((unsigned int )((void const   *)("msb2lsb" + 1)) - (unsigned int )((void const   *)"msb2lsb") == 1U)) {
              {
              fprintf(_coverage_fout, "314\n");
              fflush(_coverage_fout);
              }
              tmp___8 = 1;
            } else {
              {
              fprintf(_coverage_fout, "317\n");
              fflush(_coverage_fout);
              }
              if (__s2_len >= 4U) {
                {
                fprintf(_coverage_fout, "315\n");
                fflush(_coverage_fout);
                }
                tmp___8 = 1;
              } else {
                {
                fprintf(_coverage_fout, "316\n");
                fflush(_coverage_fout);
                }
                tmp___8 = 0;
              }
            }
          } else {
            {
            fprintf(_coverage_fout, "319\n");
            fflush(_coverage_fout);
            }
            tmp___8 = 0;
          }
        }
        {
        fprintf(_coverage_fout, "328\n");
        fflush(_coverage_fout);
        }
        if (tmp___8) {
          {
          fprintf(_coverage_fout, "321\n");
          fflush(_coverage_fout);
          }
          tmp___3 = __builtin_strcmp((char const   *)optarg, "msb2lsb");
          {
          fprintf(_coverage_fout, "322\n");
          fflush(_coverage_fout);
          }
          tmp___7 = tmp___3;
        } else {
          {
          fprintf(_coverage_fout, "323\n");
          fflush(_coverage_fout);
          }
          tmp___6 = __builtin_strcmp((char const   *)optarg, "msb2lsb");
          {
          fprintf(_coverage_fout, "324\n");
          fflush(_coverage_fout);
          }
          tmp___7 = tmp___6;
        }
      } else {
        {
        fprintf(_coverage_fout, "329\n");
        fflush(_coverage_fout);
        }
        tmp___6 = __builtin_strcmp((char const   *)optarg, "msb2lsb");
        {
        fprintf(_coverage_fout, "330\n");
        fflush(_coverage_fout);
        }
        tmp___7 = tmp___6;
      }
      {
      fprintf(_coverage_fout, "334\n");
      fflush(_coverage_fout);
      }
      if (tmp___7 == 0) {
        {
        fprintf(_coverage_fout, "331\n");
        fflush(_coverage_fout);
        }
        deffillorder = (unsigned short)1;
      } else {
        {
        fprintf(_coverage_fout, "332\n");
        fflush(_coverage_fout);
        }
        usage();
      }
    }
    break;
    {
    fprintf(_coverage_fout, "390\n");
    fflush(_coverage_fout);
    }
    case 105: 
    ignore = 1;
    break;
    {
    fprintf(_coverage_fout, "391\n");
    fflush(_coverage_fout);
    }
    case 108: 
    outtiled = 1;
    {
    fprintf(_coverage_fout, "392\n");
    fflush(_coverage_fout);
    }
    tmp___16 = atoi((char const   *)optarg);
    {
    fprintf(_coverage_fout, "393\n");
    fflush(_coverage_fout);
    }
    deftilelength = (unsigned int )tmp___16;
    break;
    {
    fprintf(_coverage_fout, "394\n");
    fflush(_coverage_fout);
    }
    case 111: 
    tmp___17 = strtoul((char const   */* __restrict  */)optarg,
                       (char **/* __restrict  */)((void *)0), 0);
    {
    fprintf(_coverage_fout, "395\n");
    fflush(_coverage_fout);
    }
    diroff = (unsigned int )tmp___17;
    break;
    {
    fprintf(_coverage_fout, "396\n");
    fflush(_coverage_fout);
    }
    case 112: 
    if (0) {
      {
      fprintf(_coverage_fout, "346\n");
      fflush(_coverage_fout);
      }
      __s1_len___2 = strlen((char const   *)optarg);
      {
      fprintf(_coverage_fout, "347\n");
      fflush(_coverage_fout);
      }
      __s2_len___2 = strlen("separate");
      {
      fprintf(_coverage_fout, "348\n");
      fflush(_coverage_fout);
      }
      if (! ((unsigned int )((void const   *)(optarg + 1)) - (unsigned int )((void const   *)optarg) == 1U)) {
        goto _L___6;
      } else {
        {
        fprintf(_coverage_fout, "341\n");
        fflush(_coverage_fout);
        }
        if (__s1_len___2 >= 4U) {
          {
          fprintf(_coverage_fout, "339\n");
          fflush(_coverage_fout);
          }
          _L___6: /* CIL Label */ 
          if (! ((unsigned int )((void const   *)("separate" + 1)) - (unsigned int )((void const   *)"separate") == 1U)) {
            {
            fprintf(_coverage_fout, "335\n");
            fflush(_coverage_fout);
            }
            tmp___31 = 1;
          } else {
            {
            fprintf(_coverage_fout, "338\n");
            fflush(_coverage_fout);
            }
            if (__s2_len___2 >= 4U) {
              {
              fprintf(_coverage_fout, "336\n");
              fflush(_coverage_fout);
              }
              tmp___31 = 1;
            } else {
              {
              fprintf(_coverage_fout, "337\n");
              fflush(_coverage_fout);
              }
              tmp___31 = 0;
            }
          }
        } else {
          {
          fprintf(_coverage_fout, "340\n");
          fflush(_coverage_fout);
          }
          tmp___31 = 0;
        }
      }
      {
      fprintf(_coverage_fout, "349\n");
      fflush(_coverage_fout);
      }
      if (tmp___31) {
        {
        fprintf(_coverage_fout, "342\n");
        fflush(_coverage_fout);
        }
        tmp___26 = __builtin_strcmp((char const   *)optarg, "separate");
        {
        fprintf(_coverage_fout, "343\n");
        fflush(_coverage_fout);
        }
        tmp___30 = tmp___26;
      } else {
        {
        fprintf(_coverage_fout, "344\n");
        fflush(_coverage_fout);
        }
        tmp___29 = __builtin_strcmp((char const   *)optarg, "separate");
        {
        fprintf(_coverage_fout, "345\n");
        fflush(_coverage_fout);
        }
        tmp___30 = tmp___29;
      }
    } else {
      {
      fprintf(_coverage_fout, "350\n");
      fflush(_coverage_fout);
      }
      tmp___29 = __builtin_strcmp((char const   *)optarg, "separate");
      {
      fprintf(_coverage_fout, "351\n");
      fflush(_coverage_fout);
      }
      tmp___30 = tmp___29;
    }
    {
    fprintf(_coverage_fout, "397\n");
    fflush(_coverage_fout);
    }
    if (tmp___30 == 0) {
      {
      fprintf(_coverage_fout, "352\n");
      fflush(_coverage_fout);
      }
      defconfig = (unsigned short)2;
    } else {
      {
      fprintf(_coverage_fout, "372\n");
      fflush(_coverage_fout);
      }
      if (0) {
        {
        fprintf(_coverage_fout, "364\n");
        fflush(_coverage_fout);
        }
        __s1_len___1 = strlen((char const   *)optarg);
        {
        fprintf(_coverage_fout, "365\n");
        fflush(_coverage_fout);
        }
        __s2_len___1 = strlen("contig");
        {
        fprintf(_coverage_fout, "366\n");
        fflush(_coverage_fout);
        }
        if (! ((unsigned int )((void const   *)(optarg + 1)) - (unsigned int )((void const   *)optarg) == 1U)) {
          goto _L___4;
        } else {
          {
          fprintf(_coverage_fout, "359\n");
          fflush(_coverage_fout);
          }
          if (__s1_len___1 >= 4U) {
            {
            fprintf(_coverage_fout, "357\n");
            fflush(_coverage_fout);
            }
            _L___4: /* CIL Label */ 
            if (! ((unsigned int )((void const   *)("contig" + 1)) - (unsigned int )((void const   *)"contig") == 1U)) {
              {
              fprintf(_coverage_fout, "353\n");
              fflush(_coverage_fout);
              }
              tmp___24 = 1;
            } else {
              {
              fprintf(_coverage_fout, "356\n");
              fflush(_coverage_fout);
              }
              if (__s2_len___1 >= 4U) {
                {
                fprintf(_coverage_fout, "354\n");
                fflush(_coverage_fout);
                }
                tmp___24 = 1;
              } else {
                {
                fprintf(_coverage_fout, "355\n");
                fflush(_coverage_fout);
                }
                tmp___24 = 0;
              }
            }
          } else {
            {
            fprintf(_coverage_fout, "358\n");
            fflush(_coverage_fout);
            }
            tmp___24 = 0;
          }
        }
        {
        fprintf(_coverage_fout, "367\n");
        fflush(_coverage_fout);
        }
        if (tmp___24) {
          {
          fprintf(_coverage_fout, "360\n");
          fflush(_coverage_fout);
          }
          tmp___19 = __builtin_strcmp((char const   *)optarg, "contig");
          {
          fprintf(_coverage_fout, "361\n");
          fflush(_coverage_fout);
          }
          tmp___23 = tmp___19;
        } else {
          {
          fprintf(_coverage_fout, "362\n");
          fflush(_coverage_fout);
          }
          tmp___22 = __builtin_strcmp((char const   *)optarg, "contig");
          {
          fprintf(_coverage_fout, "363\n");
          fflush(_coverage_fout);
          }
          tmp___23 = tmp___22;
        }
      } else {
        {
        fprintf(_coverage_fout, "368\n");
        fflush(_coverage_fout);
        }
        tmp___22 = __builtin_strcmp((char const   *)optarg, "contig");
        {
        fprintf(_coverage_fout, "369\n");
        fflush(_coverage_fout);
        }
        tmp___23 = tmp___22;
      }
      {
      fprintf(_coverage_fout, "373\n");
      fflush(_coverage_fout);
      }
      if (tmp___23 == 0) {
        {
        fprintf(_coverage_fout, "370\n");
        fflush(_coverage_fout);
        }
        defconfig = (unsigned short)1;
      } else {
        {
        fprintf(_coverage_fout, "371\n");
        fflush(_coverage_fout);
        }
        usage();
      }
    }
    break;
    {
    fprintf(_coverage_fout, "398\n");
    fflush(_coverage_fout);
    }
    case 114: 
    tmp___32 = atol((char const   *)optarg);
    {
    fprintf(_coverage_fout, "399\n");
    fflush(_coverage_fout);
    }
    defrowsperstrip = (unsigned int )tmp___32;
    break;
    {
    fprintf(_coverage_fout, "400\n");
    fflush(_coverage_fout);
    }
    case 115: 
    outtiled = 0;
    break;
    {
    fprintf(_coverage_fout, "401\n");
    fflush(_coverage_fout);
    }
    case 116: 
    outtiled = 1;
    break;
    {
    fprintf(_coverage_fout, "402\n");
    fflush(_coverage_fout);
    }
    case 119: 
    outtiled = 1;
    {
    fprintf(_coverage_fout, "403\n");
    fflush(_coverage_fout);
    }
    tmp___33 = atoi((char const   *)optarg);
    {
    fprintf(_coverage_fout, "404\n");
    fflush(_coverage_fout);
    }
    deftilewidth = (unsigned int )tmp___33;
    break;
    {
    fprintf(_coverage_fout, "405\n");
    fflush(_coverage_fout);
    }
    case 66: 
    tmp___34 = mp;
    {
    fprintf(_coverage_fout, "406\n");
    fflush(_coverage_fout);
    }
    mp ++;
    {
    fprintf(_coverage_fout, "407\n");
    fflush(_coverage_fout);
    }
    *tmp___34 = (char )'b';
    {
    fprintf(_coverage_fout, "408\n");
    fflush(_coverage_fout);
    }
    *mp = (char )'\000';
    break;
    {
    fprintf(_coverage_fout, "409\n");
    fflush(_coverage_fout);
    }
    case 76: 
    tmp___35 = mp;
    {
    fprintf(_coverage_fout, "410\n");
    fflush(_coverage_fout);
    }
    mp ++;
    {
    fprintf(_coverage_fout, "411\n");
    fflush(_coverage_fout);
    }
    *tmp___35 = (char )'l';
    {
    fprintf(_coverage_fout, "412\n");
    fflush(_coverage_fout);
    }
    *mp = (char )'\000';
    break;
    {
    fprintf(_coverage_fout, "413\n");
    fflush(_coverage_fout);
    }
    case 77: 
    tmp___36 = mp;
    {
    fprintf(_coverage_fout, "414\n");
    fflush(_coverage_fout);
    }
    mp ++;
    {
    fprintf(_coverage_fout, "415\n");
    fflush(_coverage_fout);
    }
    *tmp___36 = (char )'m';
    {
    fprintf(_coverage_fout, "416\n");
    fflush(_coverage_fout);
    }
    *mp = (char )'\000';
    break;
    {
    fprintf(_coverage_fout, "417\n");
    fflush(_coverage_fout);
    }
    case 67: 
    tmp___37 = mp;
    {
    fprintf(_coverage_fout, "418\n");
    fflush(_coverage_fout);
    }
    mp ++;
    {
    fprintf(_coverage_fout, "419\n");
    fflush(_coverage_fout);
    }
    *tmp___37 = (char )'c';
    {
    fprintf(_coverage_fout, "420\n");
    fflush(_coverage_fout);
    }
    *mp = (char )'\000';
    break;
    {
    fprintf(_coverage_fout, "421\n");
    fflush(_coverage_fout);
    }
    case 63: 
    usage();
    }
  }
  {
  fprintf(_coverage_fout, "485\n");
  fflush(_coverage_fout);
  }
  if (argc - optind < 2) {
    {
    fprintf(_coverage_fout, "424\n");
    fflush(_coverage_fout);
    }
    usage();
  } else {
    {
    fprintf(_coverage_fout, "425\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "486\n");
  fflush(_coverage_fout);
  }
  out = TIFFOpen((char const   *)*(argv + (argc - 1)), (char const   *)(mode));
  {
  fprintf(_coverage_fout, "487\n");
  fflush(_coverage_fout);
  }
  if ((unsigned int )out == (unsigned int )((void *)0)) {
    {
    fprintf(_coverage_fout, "426\n");
    fflush(_coverage_fout);
    }
    return (-2);
  } else {
    {
    fprintf(_coverage_fout, "427\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "488\n");
  fflush(_coverage_fout);
  }
  if (argc - optind == 2) {
    {
    fprintf(_coverage_fout, "428\n");
    fflush(_coverage_fout);
    }
    pageNum = -1;
  } else {
    {
    fprintf(_coverage_fout, "429\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "489\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "465\n");
    fflush(_coverage_fout);
    }
    if (optind < argc - 1) {
      {
      fprintf(_coverage_fout, "430\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "466\n");
    fflush(_coverage_fout);
    }
    imageCursor = *(argv + optind);
    {
    fprintf(_coverage_fout, "467\n");
    fflush(_coverage_fout);
    }
    in = openSrcImage(& imageCursor);
    {
    fprintf(_coverage_fout, "468\n");
    fflush(_coverage_fout);
    }
    if ((unsigned int )in == (unsigned int )((void *)0)) {
      {
      fprintf(_coverage_fout, "431\n");
      fflush(_coverage_fout);
      }
      return (-3);
    } else {
      {
      fprintf(_coverage_fout, "432\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "469\n");
    fflush(_coverage_fout);
    }
    if (diroff != 0U) {
      {
      fprintf(_coverage_fout, "438\n");
      fflush(_coverage_fout);
      }
      tmp___39 = TIFFSetSubDirectory(in, diroff);
      {
      fprintf(_coverage_fout, "439\n");
      fflush(_coverage_fout);
      }
      if (tmp___39) {
        {
        fprintf(_coverage_fout, "433\n");
        fflush(_coverage_fout);
        }

      } else {
        {
        fprintf(_coverage_fout, "434\n");
        fflush(_coverage_fout);
        }
        tmp___38 = TIFFFileName(in);
        {
        fprintf(_coverage_fout, "435\n");
        fflush(_coverage_fout);
        }
        TIFFError(tmp___38, "Error, setting subdirectory at %#x", diroff);
        {
        fprintf(_coverage_fout, "436\n");
        fflush(_coverage_fout);
        }
        TIFFClose(out);
        {
        fprintf(_coverage_fout, "437\n");
        fflush(_coverage_fout);
        }
        return (1);
      }
    } else {
      {
      fprintf(_coverage_fout, "440\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "470\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "454\n");
      fflush(_coverage_fout);
      }
      config = defconfig;
      {
      fprintf(_coverage_fout, "455\n");
      fflush(_coverage_fout);
      }
      compression = defcompression;
      {
      fprintf(_coverage_fout, "456\n");
      fflush(_coverage_fout);
      }
      predictor = defpredictor;
      {
      fprintf(_coverage_fout, "457\n");
      fflush(_coverage_fout);
      }
      fillorder = deffillorder;
      {
      fprintf(_coverage_fout, "458\n");
      fflush(_coverage_fout);
      }
      rowsperstrip = defrowsperstrip;
      {
      fprintf(_coverage_fout, "459\n");
      fflush(_coverage_fout);
      }
      tilewidth = deftilewidth;
      {
      fprintf(_coverage_fout, "460\n");
      fflush(_coverage_fout);
      }
      tilelength = deftilelength;
      {
      fprintf(_coverage_fout, "461\n");
      fflush(_coverage_fout);
      }
      g3opts = defg3opts;
      {
      fprintf(_coverage_fout, "462\n");
      fflush(_coverage_fout);
      }
      tmp___40 = tiffcp(in, out);
      {
      fprintf(_coverage_fout, "463\n");
      fflush(_coverage_fout);
      }
      if (tmp___40) {
        {
        fprintf(_coverage_fout, "444\n");
        fflush(_coverage_fout);
        }
        tmp___41 = TIFFWriteDirectory(out);
        {
        fprintf(_coverage_fout, "445\n");
        fflush(_coverage_fout);
        }
        if (tmp___41) {
          {
          fprintf(_coverage_fout, "441\n");
          fflush(_coverage_fout);
          }

        } else {
          {
          fprintf(_coverage_fout, "442\n");
          fflush(_coverage_fout);
          }
          TIFFClose(out);
          {
          fprintf(_coverage_fout, "443\n");
          fflush(_coverage_fout);
          }
          return (1);
        }
      } else {
        {
        fprintf(_coverage_fout, "446\n");
        fflush(_coverage_fout);
        }
        TIFFClose(out);
        {
        fprintf(_coverage_fout, "447\n");
        fflush(_coverage_fout);
        }
        return (1);
      }
      {
      fprintf(_coverage_fout, "464\n");
      fflush(_coverage_fout);
      }
      if (imageCursor) {
        {
        fprintf(_coverage_fout, "449\n");
        fflush(_coverage_fout);
        }
        tmp___42 = nextSrcImage(in, & imageCursor);
        {
        fprintf(_coverage_fout, "450\n");
        fflush(_coverage_fout);
        }
        if (tmp___42) {
          {
          fprintf(_coverage_fout, "448\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
      } else {
        {
        fprintf(_coverage_fout, "452\n");
        fflush(_coverage_fout);
        }
        tmp___43 = TIFFReadDirectory(in);
        {
        fprintf(_coverage_fout, "453\n");
        fflush(_coverage_fout);
        }
        if (tmp___43) {
          {
          fprintf(_coverage_fout, "451\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
      }
    }
    {
    fprintf(_coverage_fout, "471\n");
    fflush(_coverage_fout);
    }
    TIFFClose(in);
    {
    fprintf(_coverage_fout, "472\n");
    fflush(_coverage_fout);
    }
    optind ++;
  }
  {
  fprintf(_coverage_fout, "490\n");
  fflush(_coverage_fout);
  }
  TIFFClose(out);
  {
  fprintf(_coverage_fout, "491\n");
  fflush(_coverage_fout);
  }
  return (0);
}
}
static void processG3Options(char *cp ) 
{ size_t tmp ;
  size_t tmp___0 ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  unsigned char const   *__s2 ;
  register int __result ;
  int tmp___4 ;
  unsigned char const   *__s1 ;
  register int __result___0 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  size_t tmp___10 ;
  size_t tmp___11 ;
  size_t tmp___12 ;
  size_t tmp___13 ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  unsigned char const   *__s2___0 ;
  register int __result___1 ;
  int tmp___17 ;
  unsigned char const   *__s1___0 ;
  register int __result___2 ;
  int tmp___18 ;
  int tmp___19 ;
  int tmp___20 ;
  int tmp___21 ;
  int tmp___22 ;
  size_t tmp___23 ;
  size_t tmp___24 ;
  size_t tmp___25 ;
  size_t tmp___26 ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___27 ;
  int tmp___28 ;
  int tmp___29 ;
  unsigned char const   *__s2___1 ;
  register int __result___3 ;
  int tmp___30 ;
  unsigned char const   *__s1___1 ;
  register int __result___4 ;
  int tmp___31 ;
  int tmp___32 ;
  int tmp___33 ;
  int tmp___34 ;
  int tmp___35 ;
  size_t tmp___36 ;
  size_t tmp___37 ;
  void *tmp___38 ;
  char *tmp___39 ;
  void *tmp___40 ;
  char *tmp___41 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "575\n");
  fflush(_coverage_fout);
  }
  tmp___41 = __builtin_strchr(cp, ':');
  {
  fprintf(_coverage_fout, "576\n");
  fflush(_coverage_fout);
  }
  cp = tmp___41;
  {
  fprintf(_coverage_fout, "577\n");
  fflush(_coverage_fout);
  }
  if (cp) {
    {
    fprintf(_coverage_fout, "572\n");
    fflush(_coverage_fout);
    }
    if (defg3opts == 4294967295U) {
      {
      fprintf(_coverage_fout, "492\n");
      fflush(_coverage_fout);
      }
      defg3opts = 0U;
    } else {
      {
      fprintf(_coverage_fout, "493\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "573\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "566\n");
      fflush(_coverage_fout);
      }
      cp ++;
      {
      fprintf(_coverage_fout, "567\n");
      fflush(_coverage_fout);
      }
      if (0) {
        {
        fprintf(_coverage_fout, "511\n");
        fflush(_coverage_fout);
        }
        if (0) {
          {
          fprintf(_coverage_fout, "505\n");
          fflush(_coverage_fout);
          }
          __s1_len___1 = strlen((char const   *)cp);
          {
          fprintf(_coverage_fout, "506\n");
          fflush(_coverage_fout);
          }
          __s2_len___1 = strlen("1d");
          {
          fprintf(_coverage_fout, "507\n");
          fflush(_coverage_fout);
          }
          if (! ((unsigned int )((void const   *)(cp + 1)) - (unsigned int )((void const   *)cp) == 1U)) {
            goto _L___4;
          } else {
            {
            fprintf(_coverage_fout, "500\n");
            fflush(_coverage_fout);
            }
            if (__s1_len___1 >= 4U) {
              {
              fprintf(_coverage_fout, "498\n");
              fflush(_coverage_fout);
              }
              _L___4: /* CIL Label */ 
              if (! ((unsigned int )((void const   *)("1d" + 1)) - (unsigned int )((void const   *)"1d") == 1U)) {
                {
                fprintf(_coverage_fout, "494\n");
                fflush(_coverage_fout);
                }
                tmp___33 = 1;
              } else {
                {
                fprintf(_coverage_fout, "497\n");
                fflush(_coverage_fout);
                }
                if (__s2_len___1 >= 4U) {
                  {
                  fprintf(_coverage_fout, "495\n");
                  fflush(_coverage_fout);
                  }
                  tmp___33 = 1;
                } else {
                  {
                  fprintf(_coverage_fout, "496\n");
                  fflush(_coverage_fout);
                  }
                  tmp___33 = 0;
                }
              }
            } else {
              {
              fprintf(_coverage_fout, "499\n");
              fflush(_coverage_fout);
              }
              tmp___33 = 0;
            }
          }
          {
          fprintf(_coverage_fout, "508\n");
          fflush(_coverage_fout);
          }
          if (tmp___33) {
            {
            fprintf(_coverage_fout, "501\n");
            fflush(_coverage_fout);
            }
            tmp___28 = __builtin_strcmp((char const   *)cp, "1d");
            {
            fprintf(_coverage_fout, "502\n");
            fflush(_coverage_fout);
            }
            tmp___32 = tmp___28;
          } else {
            {
            fprintf(_coverage_fout, "503\n");
            fflush(_coverage_fout);
            }
            tmp___31 = __builtin_strcmp((char const   *)cp, "1d");
            {
            fprintf(_coverage_fout, "504\n");
            fflush(_coverage_fout);
            }
            tmp___32 = tmp___31;
          }
        } else {
          {
          fprintf(_coverage_fout, "509\n");
          fflush(_coverage_fout);
          }
          tmp___31 = __builtin_strcmp((char const   *)cp, "1d");
          {
          fprintf(_coverage_fout, "510\n");
          fflush(_coverage_fout);
          }
          tmp___32 = tmp___31;
        }
        {
        fprintf(_coverage_fout, "512\n");
        fflush(_coverage_fout);
        }
        tmp___35 = tmp___32;
      } else {
        {
        fprintf(_coverage_fout, "513\n");
        fflush(_coverage_fout);
        }
        tmp___34 = strncmp((char const   *)cp, "1d", 2U);
        {
        fprintf(_coverage_fout, "514\n");
        fflush(_coverage_fout);
        }
        tmp___35 = tmp___34;
      }
      {
      fprintf(_coverage_fout, "568\n");
      fflush(_coverage_fout);
      }
      if (tmp___35 == 0) {
        {
        fprintf(_coverage_fout, "515\n");
        fflush(_coverage_fout);
        }
        defg3opts &= 4294967294U;
      } else {
        {
        fprintf(_coverage_fout, "563\n");
        fflush(_coverage_fout);
        }
        if (0) {
          {
          fprintf(_coverage_fout, "533\n");
          fflush(_coverage_fout);
          }
          if (0) {
            {
            fprintf(_coverage_fout, "527\n");
            fflush(_coverage_fout);
            }
            __s1_len___0 = strlen((char const   *)cp);
            {
            fprintf(_coverage_fout, "528\n");
            fflush(_coverage_fout);
            }
            __s2_len___0 = strlen("2d");
            {
            fprintf(_coverage_fout, "529\n");
            fflush(_coverage_fout);
            }
            if (! ((unsigned int )((void const   *)(cp + 1)) - (unsigned int )((void const   *)cp) == 1U)) {
              goto _L___2;
            } else {
              {
              fprintf(_coverage_fout, "522\n");
              fflush(_coverage_fout);
              }
              if (__s1_len___0 >= 4U) {
                {
                fprintf(_coverage_fout, "520\n");
                fflush(_coverage_fout);
                }
                _L___2: /* CIL Label */ 
                if (! ((unsigned int )((void const   *)("2d" + 1)) - (unsigned int )((void const   *)"2d") == 1U)) {
                  {
                  fprintf(_coverage_fout, "516\n");
                  fflush(_coverage_fout);
                  }
                  tmp___20 = 1;
                } else {
                  {
                  fprintf(_coverage_fout, "519\n");
                  fflush(_coverage_fout);
                  }
                  if (__s2_len___0 >= 4U) {
                    {
                    fprintf(_coverage_fout, "517\n");
                    fflush(_coverage_fout);
                    }
                    tmp___20 = 1;
                  } else {
                    {
                    fprintf(_coverage_fout, "518\n");
                    fflush(_coverage_fout);
                    }
                    tmp___20 = 0;
                  }
                }
              } else {
                {
                fprintf(_coverage_fout, "521\n");
                fflush(_coverage_fout);
                }
                tmp___20 = 0;
              }
            }
            {
            fprintf(_coverage_fout, "530\n");
            fflush(_coverage_fout);
            }
            if (tmp___20) {
              {
              fprintf(_coverage_fout, "523\n");
              fflush(_coverage_fout);
              }
              tmp___15 = __builtin_strcmp((char const   *)cp, "2d");
              {
              fprintf(_coverage_fout, "524\n");
              fflush(_coverage_fout);
              }
              tmp___19 = tmp___15;
            } else {
              {
              fprintf(_coverage_fout, "525\n");
              fflush(_coverage_fout);
              }
              tmp___18 = __builtin_strcmp((char const   *)cp, "2d");
              {
              fprintf(_coverage_fout, "526\n");
              fflush(_coverage_fout);
              }
              tmp___19 = tmp___18;
            }
          } else {
            {
            fprintf(_coverage_fout, "531\n");
            fflush(_coverage_fout);
            }
            tmp___18 = __builtin_strcmp((char const   *)cp, "2d");
            {
            fprintf(_coverage_fout, "532\n");
            fflush(_coverage_fout);
            }
            tmp___19 = tmp___18;
          }
          {
          fprintf(_coverage_fout, "534\n");
          fflush(_coverage_fout);
          }
          tmp___22 = tmp___19;
        } else {
          {
          fprintf(_coverage_fout, "535\n");
          fflush(_coverage_fout);
          }
          tmp___21 = strncmp((char const   *)cp, "2d", 2U);
          {
          fprintf(_coverage_fout, "536\n");
          fflush(_coverage_fout);
          }
          tmp___22 = tmp___21;
        }
        {
        fprintf(_coverage_fout, "564\n");
        fflush(_coverage_fout);
        }
        if (tmp___22 == 0) {
          {
          fprintf(_coverage_fout, "537\n");
          fflush(_coverage_fout);
          }
          defg3opts |= 1U;
        } else {
          {
          fprintf(_coverage_fout, "561\n");
          fflush(_coverage_fout);
          }
          if (0) {
            {
            fprintf(_coverage_fout, "555\n");
            fflush(_coverage_fout);
            }
            if (0) {
              {
              fprintf(_coverage_fout, "549\n");
              fflush(_coverage_fout);
              }
              __s1_len = strlen((char const   *)cp);
              {
              fprintf(_coverage_fout, "550\n");
              fflush(_coverage_fout);
              }
              __s2_len = strlen("fill");
              {
              fprintf(_coverage_fout, "551\n");
              fflush(_coverage_fout);
              }
              if (! ((unsigned int )((void const   *)(cp + 1)) - (unsigned int )((void const   *)cp) == 1U)) {
                goto _L___0;
              } else {
                {
                fprintf(_coverage_fout, "544\n");
                fflush(_coverage_fout);
                }
                if (__s1_len >= 4U) {
                  {
                  fprintf(_coverage_fout, "542\n");
                  fflush(_coverage_fout);
                  }
                  _L___0: /* CIL Label */ 
                  if (! ((unsigned int )((void const   *)("fill" + 1)) - (unsigned int )((void const   *)"fill") == 1U)) {
                    {
                    fprintf(_coverage_fout, "538\n");
                    fflush(_coverage_fout);
                    }
                    tmp___7 = 1;
                  } else {
                    {
                    fprintf(_coverage_fout, "541\n");
                    fflush(_coverage_fout);
                    }
                    if (__s2_len >= 4U) {
                      {
                      fprintf(_coverage_fout, "539\n");
                      fflush(_coverage_fout);
                      }
                      tmp___7 = 1;
                    } else {
                      {
                      fprintf(_coverage_fout, "540\n");
                      fflush(_coverage_fout);
                      }
                      tmp___7 = 0;
                    }
                  }
                } else {
                  {
                  fprintf(_coverage_fout, "543\n");
                  fflush(_coverage_fout);
                  }
                  tmp___7 = 0;
                }
              }
              {
              fprintf(_coverage_fout, "552\n");
              fflush(_coverage_fout);
              }
              if (tmp___7) {
                {
                fprintf(_coverage_fout, "545\n");
                fflush(_coverage_fout);
                }
                tmp___2 = __builtin_strcmp((char const   *)cp, "fill");
                {
                fprintf(_coverage_fout, "546\n");
                fflush(_coverage_fout);
                }
                tmp___6 = tmp___2;
              } else {
                {
                fprintf(_coverage_fout, "547\n");
                fflush(_coverage_fout);
                }
                tmp___5 = __builtin_strcmp((char const   *)cp, "fill");
                {
                fprintf(_coverage_fout, "548\n");
                fflush(_coverage_fout);
                }
                tmp___6 = tmp___5;
              }
            } else {
              {
              fprintf(_coverage_fout, "553\n");
              fflush(_coverage_fout);
              }
              tmp___5 = __builtin_strcmp((char const   *)cp, "fill");
              {
              fprintf(_coverage_fout, "554\n");
              fflush(_coverage_fout);
              }
              tmp___6 = tmp___5;
            }
            {
            fprintf(_coverage_fout, "556\n");
            fflush(_coverage_fout);
            }
            tmp___9 = tmp___6;
          } else {
            {
            fprintf(_coverage_fout, "557\n");
            fflush(_coverage_fout);
            }
            tmp___8 = strncmp((char const   *)cp, "fill", 4U);
            {
            fprintf(_coverage_fout, "558\n");
            fflush(_coverage_fout);
            }
            tmp___9 = tmp___8;
          }
          {
          fprintf(_coverage_fout, "562\n");
          fflush(_coverage_fout);
          }
          if (tmp___9 == 0) {
            {
            fprintf(_coverage_fout, "559\n");
            fflush(_coverage_fout);
            }
            defg3opts |= 4U;
          } else {
            {
            fprintf(_coverage_fout, "560\n");
            fflush(_coverage_fout);
            }
            usage();
          }
        }
      }
      {
      fprintf(_coverage_fout, "569\n");
      fflush(_coverage_fout);
      }
      tmp___39 = __builtin_strchr(cp, ':');
      {
      fprintf(_coverage_fout, "570\n");
      fflush(_coverage_fout);
      }
      cp = tmp___39;
      {
      fprintf(_coverage_fout, "571\n");
      fflush(_coverage_fout);
      }
      if (cp) {
        {
        fprintf(_coverage_fout, "565\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
    }
  } else {
    {
    fprintf(_coverage_fout, "574\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "578\n");
  fflush(_coverage_fout);
  }
  return;
}
}
static int processCompressOptions(char *opt ) 
{ char *cp ;
  void *tmp ;
  char *tmp___0 ;
  unsigned short const   **tmp___1 ;
  void *tmp___2 ;
  char *tmp___3 ;
  char *cp___0 ;
  void *tmp___4 ;
  char *tmp___5 ;
  int tmp___6 ;
  char *cp___1 ;
  void *tmp___7 ;
  char *tmp___8 ;
  int tmp___9 ;
  size_t tmp___10 ;
  size_t tmp___11 ;
  size_t __s1_len ;
  size_t __s2_len ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  unsigned char const   *__s2 ;
  register int __result ;
  int tmp___15 ;
  unsigned char const   *__s1 ;
  register int __result___0 ;
  int tmp___16 ;
  int tmp___17 ;
  int tmp___18 ;
  int tmp___19 ;
  int tmp___20 ;
  size_t tmp___21 ;
  size_t tmp___22 ;
  size_t tmp___23 ;
  size_t tmp___24 ;
  size_t __s1_len___0 ;
  size_t __s2_len___0 ;
  int tmp___25 ;
  int tmp___26 ;
  int tmp___27 ;
  unsigned char const   *__s2___0 ;
  register int __result___1 ;
  int tmp___28 ;
  unsigned char const   *__s1___0 ;
  register int __result___2 ;
  int tmp___29 ;
  int tmp___30 ;
  int tmp___31 ;
  int tmp___32 ;
  int tmp___33 ;
  size_t tmp___34 ;
  size_t tmp___35 ;
  size_t __s1_len___1 ;
  size_t __s2_len___1 ;
  int tmp___36 ;
  int tmp___37 ;
  int tmp___38 ;
  unsigned char const   *__s2___1 ;
  register int __result___3 ;
  int tmp___39 ;
  unsigned char const   *__s1___1 ;
  register int __result___4 ;
  int tmp___40 ;
  int tmp___41 ;
  int tmp___42 ;
  size_t tmp___43 ;
  size_t tmp___44 ;
  size_t __s1_len___2 ;
  size_t __s2_len___2 ;
  int tmp___45 ;
  int tmp___46 ;
  int tmp___47 ;
  unsigned char const   *__s2___2 ;
  register int __result___5 ;
  int tmp___48 ;
  unsigned char const   *__s1___2 ;
  register int __result___6 ;
  int tmp___49 ;
  int tmp___50 ;
  int tmp___51 ;
  int tmp___52 ;
  int tmp___53 ;
  size_t tmp___54 ;
  size_t tmp___55 ;
  size_t tmp___56 ;
  size_t tmp___57 ;
  size_t __s1_len___3 ;
  size_t __s2_len___3 ;
  int tmp___58 ;
  int tmp___59 ;
  int tmp___60 ;
  unsigned char const   *__s2___3 ;
  register int __result___7 ;
  int tmp___61 ;
  unsigned char const   *__s1___3 ;
  register int __result___8 ;
  int tmp___62 ;
  int tmp___63 ;
  int tmp___64 ;
  int tmp___65 ;
  int tmp___66 ;
  size_t tmp___67 ;
  size_t tmp___68 ;
  size_t __s1_len___4 ;
  size_t __s2_len___4 ;
  int tmp___69 ;
  int tmp___70 ;
  int tmp___71 ;
  unsigned char const   *__s2___4 ;
  register int __result___9 ;
  int tmp___72 ;
  unsigned char const   *__s1___4 ;
  register int __result___10 ;
  int tmp___73 ;
  int tmp___74 ;
  int tmp___75 ;
  size_t __s1_len___5 ;
  size_t __s2_len___5 ;
  int tmp___76 ;
  int tmp___77 ;
  int tmp___78 ;
  unsigned char const   *__s2___5 ;
  register int __result___11 ;
  int tmp___79 ;
  unsigned char const   *__s1___5 ;
  register int __result___12 ;
  int tmp___80 ;
  int tmp___81 ;
  int tmp___82 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "761\n");
  fflush(_coverage_fout);
  }
  if (0) {
    {
    fprintf(_coverage_fout, "590\n");
    fflush(_coverage_fout);
    }
    __s1_len___5 = strlen((char const   *)opt);
    {
    fprintf(_coverage_fout, "591\n");
    fflush(_coverage_fout);
    }
    __s2_len___5 = strlen("none");
    {
    fprintf(_coverage_fout, "592\n");
    fflush(_coverage_fout);
    }
    if (! ((unsigned int )((void const   *)(opt + 1)) - (unsigned int )((void const   *)opt) == 1U)) {
      goto _L___12;
    } else {
      {
      fprintf(_coverage_fout, "585\n");
      fflush(_coverage_fout);
      }
      if (__s1_len___5 >= 4U) {
        {
        fprintf(_coverage_fout, "583\n");
        fflush(_coverage_fout);
        }
        _L___12: /* CIL Label */ 
        if (! ((unsigned int )((void const   *)("none" + 1)) - (unsigned int )((void const   *)"none") == 1U)) {
          {
          fprintf(_coverage_fout, "579\n");
          fflush(_coverage_fout);
          }
          tmp___82 = 1;
        } else {
          {
          fprintf(_coverage_fout, "582\n");
          fflush(_coverage_fout);
          }
          if (__s2_len___5 >= 4U) {
            {
            fprintf(_coverage_fout, "580\n");
            fflush(_coverage_fout);
            }
            tmp___82 = 1;
          } else {
            {
            fprintf(_coverage_fout, "581\n");
            fflush(_coverage_fout);
            }
            tmp___82 = 0;
          }
        }
      } else {
        {
        fprintf(_coverage_fout, "584\n");
        fflush(_coverage_fout);
        }
        tmp___82 = 0;
      }
    }
    {
    fprintf(_coverage_fout, "593\n");
    fflush(_coverage_fout);
    }
    if (tmp___82) {
      {
      fprintf(_coverage_fout, "586\n");
      fflush(_coverage_fout);
      }
      tmp___77 = __builtin_strcmp((char const   *)opt, "none");
      {
      fprintf(_coverage_fout, "587\n");
      fflush(_coverage_fout);
      }
      tmp___81 = tmp___77;
    } else {
      {
      fprintf(_coverage_fout, "588\n");
      fflush(_coverage_fout);
      }
      tmp___80 = __builtin_strcmp((char const   *)opt, "none");
      {
      fprintf(_coverage_fout, "589\n");
      fflush(_coverage_fout);
      }
      tmp___81 = tmp___80;
    }
  } else {
    {
    fprintf(_coverage_fout, "594\n");
    fflush(_coverage_fout);
    }
    tmp___80 = __builtin_strcmp((char const   *)opt, "none");
    {
    fprintf(_coverage_fout, "595\n");
    fflush(_coverage_fout);
    }
    tmp___81 = tmp___80;
  }
  {
  fprintf(_coverage_fout, "762\n");
  fflush(_coverage_fout);
  }
  if (tmp___81 == 0) {
    {
    fprintf(_coverage_fout, "596\n");
    fflush(_coverage_fout);
    }
    defcompression = (unsigned short)1;
  } else {
    {
    fprintf(_coverage_fout, "759\n");
    fflush(_coverage_fout);
    }
    if (0) {
      {
      fprintf(_coverage_fout, "608\n");
      fflush(_coverage_fout);
      }
      __s1_len___4 = strlen((char const   *)opt);
      {
      fprintf(_coverage_fout, "609\n");
      fflush(_coverage_fout);
      }
      __s2_len___4 = strlen("packbits");
      {
      fprintf(_coverage_fout, "610\n");
      fflush(_coverage_fout);
      }
      if (! ((unsigned int )((void const   *)(opt + 1)) - (unsigned int )((void const   *)opt) == 1U)) {
        goto _L___10;
      } else {
        {
        fprintf(_coverage_fout, "603\n");
        fflush(_coverage_fout);
        }
        if (__s1_len___4 >= 4U) {
          {
          fprintf(_coverage_fout, "601\n");
          fflush(_coverage_fout);
          }
          _L___10: /* CIL Label */ 
          if (! ((unsigned int )((void const   *)("packbits" + 1)) - (unsigned int )((void const   *)"packbits") == 1U)) {
            {
            fprintf(_coverage_fout, "597\n");
            fflush(_coverage_fout);
            }
            tmp___75 = 1;
          } else {
            {
            fprintf(_coverage_fout, "600\n");
            fflush(_coverage_fout);
            }
            if (__s2_len___4 >= 4U) {
              {
              fprintf(_coverage_fout, "598\n");
              fflush(_coverage_fout);
              }
              tmp___75 = 1;
            } else {
              {
              fprintf(_coverage_fout, "599\n");
              fflush(_coverage_fout);
              }
              tmp___75 = 0;
            }
          }
        } else {
          {
          fprintf(_coverage_fout, "602\n");
          fflush(_coverage_fout);
          }
          tmp___75 = 0;
        }
      }
      {
      fprintf(_coverage_fout, "611\n");
      fflush(_coverage_fout);
      }
      if (tmp___75) {
        {
        fprintf(_coverage_fout, "604\n");
        fflush(_coverage_fout);
        }
        tmp___70 = __builtin_strcmp((char const   *)opt, "packbits");
        {
        fprintf(_coverage_fout, "605\n");
        fflush(_coverage_fout);
        }
        tmp___74 = tmp___70;
      } else {
        {
        fprintf(_coverage_fout, "606\n");
        fflush(_coverage_fout);
        }
        tmp___73 = __builtin_strcmp((char const   *)opt, "packbits");
        {
        fprintf(_coverage_fout, "607\n");
        fflush(_coverage_fout);
        }
        tmp___74 = tmp___73;
      }
    } else {
      {
      fprintf(_coverage_fout, "612\n");
      fflush(_coverage_fout);
      }
      tmp___73 = __builtin_strcmp((char const   *)opt, "packbits");
      {
      fprintf(_coverage_fout, "613\n");
      fflush(_coverage_fout);
      }
      tmp___74 = tmp___73;
    }
    {
    fprintf(_coverage_fout, "760\n");
    fflush(_coverage_fout);
    }
    if (tmp___74 == 0) {
      {
      fprintf(_coverage_fout, "614\n");
      fflush(_coverage_fout);
      }
      defcompression = (unsigned short)32773;
    } else {
      {
      fprintf(_coverage_fout, "757\n");
      fflush(_coverage_fout);
      }
      if (0) {
        {
        fprintf(_coverage_fout, "632\n");
        fflush(_coverage_fout);
        }
        if (0) {
          {
          fprintf(_coverage_fout, "626\n");
          fflush(_coverage_fout);
          }
          __s1_len___3 = strlen((char const   *)opt);
          {
          fprintf(_coverage_fout, "627\n");
          fflush(_coverage_fout);
          }
          __s2_len___3 = strlen("jpeg");
          {
          fprintf(_coverage_fout, "628\n");
          fflush(_coverage_fout);
          }
          if (! ((unsigned int )((void const   *)(opt + 1)) - (unsigned int )((void const   *)opt) == 1U)) {
            goto _L___8;
          } else {
            {
            fprintf(_coverage_fout, "621\n");
            fflush(_coverage_fout);
            }
            if (__s1_len___3 >= 4U) {
              {
              fprintf(_coverage_fout, "619\n");
              fflush(_coverage_fout);
              }
              _L___8: /* CIL Label */ 
              if (! ((unsigned int )((void const   *)("jpeg" + 1)) - (unsigned int )((void const   *)"jpeg") == 1U)) {
                {
                fprintf(_coverage_fout, "615\n");
                fflush(_coverage_fout);
                }
                tmp___64 = 1;
              } else {
                {
                fprintf(_coverage_fout, "618\n");
                fflush(_coverage_fout);
                }
                if (__s2_len___3 >= 4U) {
                  {
                  fprintf(_coverage_fout, "616\n");
                  fflush(_coverage_fout);
                  }
                  tmp___64 = 1;
                } else {
                  {
                  fprintf(_coverage_fout, "617\n");
                  fflush(_coverage_fout);
                  }
                  tmp___64 = 0;
                }
              }
            } else {
              {
              fprintf(_coverage_fout, "620\n");
              fflush(_coverage_fout);
              }
              tmp___64 = 0;
            }
          }
          {
          fprintf(_coverage_fout, "629\n");
          fflush(_coverage_fout);
          }
          if (tmp___64) {
            {
            fprintf(_coverage_fout, "622\n");
            fflush(_coverage_fout);
            }
            tmp___59 = __builtin_strcmp((char const   *)opt, "jpeg");
            {
            fprintf(_coverage_fout, "623\n");
            fflush(_coverage_fout);
            }
            tmp___63 = tmp___59;
          } else {
            {
            fprintf(_coverage_fout, "624\n");
            fflush(_coverage_fout);
            }
            tmp___62 = __builtin_strcmp((char const   *)opt, "jpeg");
            {
            fprintf(_coverage_fout, "625\n");
            fflush(_coverage_fout);
            }
            tmp___63 = tmp___62;
          }
        } else {
          {
          fprintf(_coverage_fout, "630\n");
          fflush(_coverage_fout);
          }
          tmp___62 = __builtin_strcmp((char const   *)opt, "jpeg");
          {
          fprintf(_coverage_fout, "631\n");
          fflush(_coverage_fout);
          }
          tmp___63 = tmp___62;
        }
        {
        fprintf(_coverage_fout, "633\n");
        fflush(_coverage_fout);
        }
        tmp___66 = tmp___63;
      } else {
        {
        fprintf(_coverage_fout, "634\n");
        fflush(_coverage_fout);
        }
        tmp___65 = strncmp((char const   *)opt, "jpeg", 4U);
        {
        fprintf(_coverage_fout, "635\n");
        fflush(_coverage_fout);
        }
        tmp___66 = tmp___65;
      }
      {
      fprintf(_coverage_fout, "758\n");
      fflush(_coverage_fout);
      }
      if (tmp___66 == 0) {
        {
        fprintf(_coverage_fout, "646\n");
        fflush(_coverage_fout);
        }
        tmp___0 = __builtin_strchr(opt, ':');
        {
        fprintf(_coverage_fout, "647\n");
        fflush(_coverage_fout);
        }
        cp = tmp___0;
        {
        fprintf(_coverage_fout, "648\n");
        fflush(_coverage_fout);
        }
        if (cp) {
          {
          fprintf(_coverage_fout, "638\n");
          fflush(_coverage_fout);
          }
          tmp___1 = __ctype_b_loc();
          {
          fprintf(_coverage_fout, "639\n");
          fflush(_coverage_fout);
          }
          if ((int const   )*(*tmp___1 + (int )*(cp + 1)) & 2048) {
            {
            fprintf(_coverage_fout, "636\n");
            fflush(_coverage_fout);
            }
            quality = atoi((char const   *)(cp + 1));
          } else {
            {
            fprintf(_coverage_fout, "637\n");
            fflush(_coverage_fout);
            }

          }
        } else {
          {
          fprintf(_coverage_fout, "640\n");
          fflush(_coverage_fout);
          }

        }
        {
        fprintf(_coverage_fout, "649\n");
        fflush(_coverage_fout);
        }
        if (cp) {
          {
          fprintf(_coverage_fout, "643\n");
          fflush(_coverage_fout);
          }
          tmp___3 = __builtin_strchr(cp, 'r');
          {
          fprintf(_coverage_fout, "644\n");
          fflush(_coverage_fout);
          }
          if (tmp___3) {
            {
            fprintf(_coverage_fout, "641\n");
            fflush(_coverage_fout);
            }
            jpegcolormode = 0x0000;
          } else {
            {
            fprintf(_coverage_fout, "642\n");
            fflush(_coverage_fout);
            }

          }
        } else {
          {
          fprintf(_coverage_fout, "645\n");
          fflush(_coverage_fout);
          }

        }
        {
        fprintf(_coverage_fout, "650\n");
        fflush(_coverage_fout);
        }
        defcompression = (unsigned short)7;
      } else {
        {
        fprintf(_coverage_fout, "755\n");
        fflush(_coverage_fout);
        }
        if (0) {
          {
          fprintf(_coverage_fout, "668\n");
          fflush(_coverage_fout);
          }
          if (0) {
            {
            fprintf(_coverage_fout, "662\n");
            fflush(_coverage_fout);
            }
            __s1_len___2 = strlen((char const   *)opt);
            {
            fprintf(_coverage_fout, "663\n");
            fflush(_coverage_fout);
            }
            __s2_len___2 = strlen("g3");
            {
            fprintf(_coverage_fout, "664\n");
            fflush(_coverage_fout);
            }
            if (! ((unsigned int )((void const   *)(opt + 1)) - (unsigned int )((void const   *)opt) == 1U)) {
              goto _L___6;
            } else {
              {
              fprintf(_coverage_fout, "657\n");
              fflush(_coverage_fout);
              }
              if (__s1_len___2 >= 4U) {
                {
                fprintf(_coverage_fout, "655\n");
                fflush(_coverage_fout);
                }
                _L___6: /* CIL Label */ 
                if (! ((unsigned int )((void const   *)("g3" + 1)) - (unsigned int )((void const   *)"g3") == 1U)) {
                  {
                  fprintf(_coverage_fout, "651\n");
                  fflush(_coverage_fout);
                  }
                  tmp___51 = 1;
                } else {
                  {
                  fprintf(_coverage_fout, "654\n");
                  fflush(_coverage_fout);
                  }
                  if (__s2_len___2 >= 4U) {
                    {
                    fprintf(_coverage_fout, "652\n");
                    fflush(_coverage_fout);
                    }
                    tmp___51 = 1;
                  } else {
                    {
                    fprintf(_coverage_fout, "653\n");
                    fflush(_coverage_fout);
                    }
                    tmp___51 = 0;
                  }
                }
              } else {
                {
                fprintf(_coverage_fout, "656\n");
                fflush(_coverage_fout);
                }
                tmp___51 = 0;
              }
            }
            {
            fprintf(_coverage_fout, "665\n");
            fflush(_coverage_fout);
            }
            if (tmp___51) {
              {
              fprintf(_coverage_fout, "658\n");
              fflush(_coverage_fout);
              }
              tmp___46 = __builtin_strcmp((char const   *)opt, "g3");
              {
              fprintf(_coverage_fout, "659\n");
              fflush(_coverage_fout);
              }
              tmp___50 = tmp___46;
            } else {
              {
              fprintf(_coverage_fout, "660\n");
              fflush(_coverage_fout);
              }
              tmp___49 = __builtin_strcmp((char const   *)opt, "g3");
              {
              fprintf(_coverage_fout, "661\n");
              fflush(_coverage_fout);
              }
              tmp___50 = tmp___49;
            }
          } else {
            {
            fprintf(_coverage_fout, "666\n");
            fflush(_coverage_fout);
            }
            tmp___49 = __builtin_strcmp((char const   *)opt, "g3");
            {
            fprintf(_coverage_fout, "667\n");
            fflush(_coverage_fout);
            }
            tmp___50 = tmp___49;
          }
          {
          fprintf(_coverage_fout, "669\n");
          fflush(_coverage_fout);
          }
          tmp___53 = tmp___50;
        } else {
          {
          fprintf(_coverage_fout, "670\n");
          fflush(_coverage_fout);
          }
          tmp___52 = strncmp((char const   *)opt, "g3", 2U);
          {
          fprintf(_coverage_fout, "671\n");
          fflush(_coverage_fout);
          }
          tmp___53 = tmp___52;
        }
        {
        fprintf(_coverage_fout, "756\n");
        fflush(_coverage_fout);
        }
        if (tmp___53 == 0) {
          {
          fprintf(_coverage_fout, "672\n");
          fflush(_coverage_fout);
          }
          processG3Options(opt);
          {
          fprintf(_coverage_fout, "673\n");
          fflush(_coverage_fout);
          }
          defcompression = (unsigned short)3;
        } else {
          {
          fprintf(_coverage_fout, "753\n");
          fflush(_coverage_fout);
          }
          if (0) {
            {
            fprintf(_coverage_fout, "685\n");
            fflush(_coverage_fout);
            }
            __s1_len___1 = strlen((char const   *)opt);
            {
            fprintf(_coverage_fout, "686\n");
            fflush(_coverage_fout);
            }
            __s2_len___1 = strlen("g4");
            {
            fprintf(_coverage_fout, "687\n");
            fflush(_coverage_fout);
            }
            if (! ((unsigned int )((void const   *)(opt + 1)) - (unsigned int )((void const   *)opt) == 1U)) {
              goto _L___4;
            } else {
              {
              fprintf(_coverage_fout, "680\n");
              fflush(_coverage_fout);
              }
              if (__s1_len___1 >= 4U) {
                {
                fprintf(_coverage_fout, "678\n");
                fflush(_coverage_fout);
                }
                _L___4: /* CIL Label */ 
                if (! ((unsigned int )((void const   *)("g4" + 1)) - (unsigned int )((void const   *)"g4") == 1U)) {
                  {
                  fprintf(_coverage_fout, "674\n");
                  fflush(_coverage_fout);
                  }
                  tmp___42 = 1;
                } else {
                  {
                  fprintf(_coverage_fout, "677\n");
                  fflush(_coverage_fout);
                  }
                  if (__s2_len___1 >= 4U) {
                    {
                    fprintf(_coverage_fout, "675\n");
                    fflush(_coverage_fout);
                    }
                    tmp___42 = 1;
                  } else {
                    {
                    fprintf(_coverage_fout, "676\n");
                    fflush(_coverage_fout);
                    }
                    tmp___42 = 0;
                  }
                }
              } else {
                {
                fprintf(_coverage_fout, "679\n");
                fflush(_coverage_fout);
                }
                tmp___42 = 0;
              }
            }
            {
            fprintf(_coverage_fout, "688\n");
            fflush(_coverage_fout);
            }
            if (tmp___42) {
              {
              fprintf(_coverage_fout, "681\n");
              fflush(_coverage_fout);
              }
              tmp___37 = __builtin_strcmp((char const   *)opt, "g4");
              {
              fprintf(_coverage_fout, "682\n");
              fflush(_coverage_fout);
              }
              tmp___41 = tmp___37;
            } else {
              {
              fprintf(_coverage_fout, "683\n");
              fflush(_coverage_fout);
              }
              tmp___40 = __builtin_strcmp((char const   *)opt, "g4");
              {
              fprintf(_coverage_fout, "684\n");
              fflush(_coverage_fout);
              }
              tmp___41 = tmp___40;
            }
          } else {
            {
            fprintf(_coverage_fout, "689\n");
            fflush(_coverage_fout);
            }
            tmp___40 = __builtin_strcmp((char const   *)opt, "g4");
            {
            fprintf(_coverage_fout, "690\n");
            fflush(_coverage_fout);
            }
            tmp___41 = tmp___40;
          }
          {
          fprintf(_coverage_fout, "754\n");
          fflush(_coverage_fout);
          }
          if (tmp___41 == 0) {
            {
            fprintf(_coverage_fout, "691\n");
            fflush(_coverage_fout);
            }
            defcompression = (unsigned short)4;
          } else {
            {
            fprintf(_coverage_fout, "751\n");
            fflush(_coverage_fout);
            }
            if (0) {
              {
              fprintf(_coverage_fout, "709\n");
              fflush(_coverage_fout);
              }
              if (0) {
                {
                fprintf(_coverage_fout, "703\n");
                fflush(_coverage_fout);
                }
                __s1_len___0 = strlen((char const   *)opt);
                {
                fprintf(_coverage_fout, "704\n");
                fflush(_coverage_fout);
                }
                __s2_len___0 = strlen("lzw");
                {
                fprintf(_coverage_fout, "705\n");
                fflush(_coverage_fout);
                }
                if (! ((unsigned int )((void const   *)(opt + 1)) - (unsigned int )((void const   *)opt) == 1U)) {
                  goto _L___2;
                } else {
                  {
                  fprintf(_coverage_fout, "698\n");
                  fflush(_coverage_fout);
                  }
                  if (__s1_len___0 >= 4U) {
                    {
                    fprintf(_coverage_fout, "696\n");
                    fflush(_coverage_fout);
                    }
                    _L___2: /* CIL Label */ 
                    if (! ((unsigned int )((void const   *)("lzw" + 1)) - (unsigned int )((void const   *)"lzw") == 1U)) {
                      {
                      fprintf(_coverage_fout, "692\n");
                      fflush(_coverage_fout);
                      }
                      tmp___31 = 1;
                    } else {
                      {
                      fprintf(_coverage_fout, "695\n");
                      fflush(_coverage_fout);
                      }
                      if (__s2_len___0 >= 4U) {
                        {
                        fprintf(_coverage_fout, "693\n");
                        fflush(_coverage_fout);
                        }
                        tmp___31 = 1;
                      } else {
                        {
                        fprintf(_coverage_fout, "694\n");
                        fflush(_coverage_fout);
                        }
                        tmp___31 = 0;
                      }
                    }
                  } else {
                    {
                    fprintf(_coverage_fout, "697\n");
                    fflush(_coverage_fout);
                    }
                    tmp___31 = 0;
                  }
                }
                {
                fprintf(_coverage_fout, "706\n");
                fflush(_coverage_fout);
                }
                if (tmp___31) {
                  {
                  fprintf(_coverage_fout, "699\n");
                  fflush(_coverage_fout);
                  }
                  tmp___26 = __builtin_strcmp((char const   *)opt, "lzw");
                  {
                  fprintf(_coverage_fout, "700\n");
                  fflush(_coverage_fout);
                  }
                  tmp___30 = tmp___26;
                } else {
                  {
                  fprintf(_coverage_fout, "701\n");
                  fflush(_coverage_fout);
                  }
                  tmp___29 = __builtin_strcmp((char const   *)opt, "lzw");
                  {
                  fprintf(_coverage_fout, "702\n");
                  fflush(_coverage_fout);
                  }
                  tmp___30 = tmp___29;
                }
              } else {
                {
                fprintf(_coverage_fout, "707\n");
                fflush(_coverage_fout);
                }
                tmp___29 = __builtin_strcmp((char const   *)opt, "lzw");
                {
                fprintf(_coverage_fout, "708\n");
                fflush(_coverage_fout);
                }
                tmp___30 = tmp___29;
              }
              {
              fprintf(_coverage_fout, "710\n");
              fflush(_coverage_fout);
              }
              tmp___33 = tmp___30;
            } else {
              {
              fprintf(_coverage_fout, "711\n");
              fflush(_coverage_fout);
              }
              tmp___32 = strncmp((char const   *)opt, "lzw", 3U);
              {
              fprintf(_coverage_fout, "712\n");
              fflush(_coverage_fout);
              }
              tmp___33 = tmp___32;
            }
            {
            fprintf(_coverage_fout, "752\n");
            fflush(_coverage_fout);
            }
            if (tmp___33 == 0) {
              {
              fprintf(_coverage_fout, "716\n");
              fflush(_coverage_fout);
              }
              tmp___5 = __builtin_strchr(opt, ':');
              {
              fprintf(_coverage_fout, "717\n");
              fflush(_coverage_fout);
              }
              cp___0 = tmp___5;
              {
              fprintf(_coverage_fout, "718\n");
              fflush(_coverage_fout);
              }
              if (cp___0) {
                {
                fprintf(_coverage_fout, "713\n");
                fflush(_coverage_fout);
                }
                tmp___6 = atoi((char const   *)(cp___0 + 1));
                {
                fprintf(_coverage_fout, "714\n");
                fflush(_coverage_fout);
                }
                defpredictor = (unsigned short )tmp___6;
              } else {
                {
                fprintf(_coverage_fout, "715\n");
                fflush(_coverage_fout);
                }

              }
              {
              fprintf(_coverage_fout, "719\n");
              fflush(_coverage_fout);
              }
              defcompression = (unsigned short)5;
            } else {
              {
              fprintf(_coverage_fout, "749\n");
              fflush(_coverage_fout);
              }
              if (0) {
                {
                fprintf(_coverage_fout, "737\n");
                fflush(_coverage_fout);
                }
                if (0) {
                  {
                  fprintf(_coverage_fout, "731\n");
                  fflush(_coverage_fout);
                  }
                  __s1_len = strlen((char const   *)opt);
                  {
                  fprintf(_coverage_fout, "732\n");
                  fflush(_coverage_fout);
                  }
                  __s2_len = strlen("zip");
                  {
                  fprintf(_coverage_fout, "733\n");
                  fflush(_coverage_fout);
                  }
                  if (! ((unsigned int )((void const   *)(opt + 1)) - (unsigned int )((void const   *)opt) == 1U)) {
                    goto _L___0;
                  } else {
                    {
                    fprintf(_coverage_fout, "726\n");
                    fflush(_coverage_fout);
                    }
                    if (__s1_len >= 4U) {
                      {
                      fprintf(_coverage_fout, "724\n");
                      fflush(_coverage_fout);
                      }
                      _L___0: /* CIL Label */ 
                      if (! ((unsigned int )((void const   *)("zip" + 1)) - (unsigned int )((void const   *)"zip") == 1U)) {
                        {
                        fprintf(_coverage_fout, "720\n");
                        fflush(_coverage_fout);
                        }
                        tmp___18 = 1;
                      } else {
                        {
                        fprintf(_coverage_fout, "723\n");
                        fflush(_coverage_fout);
                        }
                        if (__s2_len >= 4U) {
                          {
                          fprintf(_coverage_fout, "721\n");
                          fflush(_coverage_fout);
                          }
                          tmp___18 = 1;
                        } else {
                          {
                          fprintf(_coverage_fout, "722\n");
                          fflush(_coverage_fout);
                          }
                          tmp___18 = 0;
                        }
                      }
                    } else {
                      {
                      fprintf(_coverage_fout, "725\n");
                      fflush(_coverage_fout);
                      }
                      tmp___18 = 0;
                    }
                  }
                  {
                  fprintf(_coverage_fout, "734\n");
                  fflush(_coverage_fout);
                  }
                  if (tmp___18) {
                    {
                    fprintf(_coverage_fout, "727\n");
                    fflush(_coverage_fout);
                    }
                    tmp___13 = __builtin_strcmp((char const   *)opt, "zip");
                    {
                    fprintf(_coverage_fout, "728\n");
                    fflush(_coverage_fout);
                    }
                    tmp___17 = tmp___13;
                  } else {
                    {
                    fprintf(_coverage_fout, "729\n");
                    fflush(_coverage_fout);
                    }
                    tmp___16 = __builtin_strcmp((char const   *)opt, "zip");
                    {
                    fprintf(_coverage_fout, "730\n");
                    fflush(_coverage_fout);
                    }
                    tmp___17 = tmp___16;
                  }
                } else {
                  {
                  fprintf(_coverage_fout, "735\n");
                  fflush(_coverage_fout);
                  }
                  tmp___16 = __builtin_strcmp((char const   *)opt, "zip");
                  {
                  fprintf(_coverage_fout, "736\n");
                  fflush(_coverage_fout);
                  }
                  tmp___17 = tmp___16;
                }
                {
                fprintf(_coverage_fout, "738\n");
                fflush(_coverage_fout);
                }
                tmp___20 = tmp___17;
              } else {
                {
                fprintf(_coverage_fout, "739\n");
                fflush(_coverage_fout);
                }
                tmp___19 = strncmp((char const   *)opt, "zip", 3U);
                {
                fprintf(_coverage_fout, "740\n");
                fflush(_coverage_fout);
                }
                tmp___20 = tmp___19;
              }
              {
              fprintf(_coverage_fout, "750\n");
              fflush(_coverage_fout);
              }
              if (tmp___20 == 0) {
                {
                fprintf(_coverage_fout, "744\n");
                fflush(_coverage_fout);
                }
                tmp___8 = __builtin_strchr(opt, ':');
                {
                fprintf(_coverage_fout, "745\n");
                fflush(_coverage_fout);
                }
                cp___1 = tmp___8;
                {
                fprintf(_coverage_fout, "746\n");
                fflush(_coverage_fout);
                }
                if (cp___1) {
                  {
                  fprintf(_coverage_fout, "741\n");
                  fflush(_coverage_fout);
                  }
                  tmp___9 = atoi((char const   *)(cp___1 + 1));
                  {
                  fprintf(_coverage_fout, "742\n");
                  fflush(_coverage_fout);
                  }
                  defpredictor = (unsigned short )tmp___9;
                } else {
                  {
                  fprintf(_coverage_fout, "743\n");
                  fflush(_coverage_fout);
                  }

                }
                {
                fprintf(_coverage_fout, "747\n");
                fflush(_coverage_fout);
                }
                defcompression = (unsigned short)8;
              } else {
                {
                fprintf(_coverage_fout, "748\n");
                fflush(_coverage_fout);
                }
                return (0);
              }
            }
          }
        }
      }
    }
  }
  {
  fprintf(_coverage_fout, "763\n");
  fflush(_coverage_fout);
  }
  return (1);
}
}
char *stuff[47]  = 
  {      (char *)"usage: tiffcp [options] input... output",      (char *)"where options are:",      (char *)" -a\t\tappend to output instead of overwriting",      (char *)" -o offset\tset initial directory offset", 
        (char *)" -p contig\tpack samples contiguously (e.g. RGBRGB...)",      (char *)" -p separate\tstore samples separately (e.g. RRR...GGG...BBB...)",      (char *)" -s\t\twrite output in strips",      (char *)" -t\t\twrite output in tiles", 
        (char *)" -i\t\tignore read errors",      (char *)" -b file[,#]\tbias (dark) monochrome image to be subtracted from all others",      (char *)" -,=%\t\tuse % rather than , to separate image #\'s (per Note below)",      (char *)"", 
        (char *)" -r #\t\tmake each strip have no more than # rows",      (char *)" -w #\t\tset output tile width (pixels)",      (char *)" -l #\t\tset output tile length (pixels)",      (char *)"", 
        (char *)" -f lsb2msb\tforce lsb-to-msb FillOrder for output",      (char *)" -f msb2lsb\tforce msb-to-lsb FillOrder for output",      (char *)"",      (char *)" -c lzw[:opts]\tcompress output with Lempel-Ziv & Welch encoding", 
        (char *)" -c zip[:opts]\tcompress output with deflate encoding",      (char *)" -c jpeg[:opts]\tcompress output with JPEG encoding",      (char *)" -c packbits\tcompress output with packbits encoding",      (char *)" -c g3[:opts]\tcompress output with CCITT Group 3 encoding", 
        (char *)" -c g4\t\tcompress output with CCITT Group 4 encoding",      (char *)" -c none\tuse no compression algorithm on output",      (char *)"",      (char *)"Group 3 options:", 
        (char *)" 1d\t\tuse default CCITT Group 3 1D-encoding",      (char *)" 2d\t\tuse optional CCITT Group 3 2D-encoding",      (char *)" fill\t\tbyte-align EOL codes",      (char *)"For example, -c g3:2d:fill to get G3-2D-encoded data with byte-aligned EOLs", 
        (char *)"",      (char *)"JPEG options:",      (char *)" #\t\tset compression quality level (0-100, default 75)",      (char *)" r\t\toutput color image as RGB rather than YCbCr", 
        (char *)"For example, -c jpeg:r:50 to get JPEG-encoded RGB data with 50% comp. quality",      (char *)"",      (char *)"LZW and deflate options:",      (char *)" #\t\tset predictor value", 
        (char *)"For example, -c lzw:2 to get LZW-encoded data with horizontal differencing",      (char *)"",      (char *)"Note that input filenames may be of the form filename,x,y,z",      (char *)"where x, y, and z specify image numbers in the filename to copy.", 
        (char *)"example:  tiffcp -c none -b esp.tif,1 esp.tif,0 test.tif",      (char *)"  subtract 2nd image in esp.tif from 1st yielding uncompressed result test.tif",      (char *)((void *)0)};
static void usage(void) 
{ char buf[8192] ;
  int i ;
  char const   *tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "768\n");
  fflush(_coverage_fout);
  }
  setbuf((FILE */* __restrict  */)stderr, (char */* __restrict  */)(buf));
  {
  fprintf(_coverage_fout, "769\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFGetVersion();
  {
  fprintf(_coverage_fout, "770\n");
  fflush(_coverage_fout);
  }
  fprintf((FILE */* __restrict  */)stderr,
          (char const   */* __restrict  */)"%s\n\n", tmp);
  {
  fprintf(_coverage_fout, "771\n");
  fflush(_coverage_fout);
  }
  i = 0;
  {
  fprintf(_coverage_fout, "772\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "765\n");
    fflush(_coverage_fout);
    }
    if ((unsigned int )stuff[i] != (unsigned int )((void *)0)) {
      {
      fprintf(_coverage_fout, "764\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "766\n");
    fflush(_coverage_fout);
    }
    fprintf((FILE */* __restrict  */)stderr,
            (char const   */* __restrict  */)"%s\n", stuff[i]);
    {
    fprintf(_coverage_fout, "767\n");
    fflush(_coverage_fout);
    }
    i ++;
  }
  {
  fprintf(_coverage_fout, "773\n");
  fflush(_coverage_fout);
  }
  exit(-1);
}
}
static void cpTag(TIFF *in , TIFF *out , uint16 tag , uint16 count ,
                  TIFFDataType type ) 
{ uint16 shortv ;
  int tmp ;
  uint16 shortv1 ;
  uint16 shortv2 ;
  int tmp___0 ;
  uint16 *tr ;
  uint16 *tg ;
  uint16 *tb ;
  uint16 *ta ;
  int tmp___1 ;
  uint16 shortv1___0 ;
  uint16 *shortav ;
  int tmp___2 ;
  uint32 longv ;
  int tmp___3 ;
  float floatv ;
  int tmp___4 ;
  float *floatav ;
  int tmp___5 ;
  char *stringv ;
  int tmp___6 ;
  double doublev ;
  int tmp___7 ;
  double *doubleav ;
  int tmp___8 ;
  char const   *tmp___9 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  switch ((int )type) {
  {
  fprintf(_coverage_fout, "818\n");
  fflush(_coverage_fout);
  }
  case 3: 
  if ((int )count == 1) {
    {
    fprintf(_coverage_fout, "776\n");
    fflush(_coverage_fout);
    }
    tmp = TIFFGetField(in, (unsigned int )tag, & shortv);
    {
    fprintf(_coverage_fout, "777\n");
    fflush(_coverage_fout);
    }
    if (tmp) {
      {
      fprintf(_coverage_fout, "774\n");
      fflush(_coverage_fout);
      }
      TIFFSetField(out, (unsigned int )tag, shortv);
    } else {
      {
      fprintf(_coverage_fout, "775\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "793\n");
    fflush(_coverage_fout);
    }
    if ((int )count == 2) {
      {
      fprintf(_coverage_fout, "780\n");
      fflush(_coverage_fout);
      }
      tmp___0 = TIFFGetField(in, (unsigned int )tag, & shortv1, & shortv2);
      {
      fprintf(_coverage_fout, "781\n");
      fflush(_coverage_fout);
      }
      if (tmp___0) {
        {
        fprintf(_coverage_fout, "778\n");
        fflush(_coverage_fout);
        }
        TIFFSetField(out, (unsigned int )tag, shortv1, shortv2);
      } else {
        {
        fprintf(_coverage_fout, "779\n");
        fflush(_coverage_fout);
        }

      }
    } else {
      {
      fprintf(_coverage_fout, "792\n");
      fflush(_coverage_fout);
      }
      if ((int )count == 4) {
        {
        fprintf(_coverage_fout, "784\n");
        fflush(_coverage_fout);
        }
        tmp___1 = TIFFGetField(in, (unsigned int )tag, & tr, & tg, & tb, & ta);
        {
        fprintf(_coverage_fout, "785\n");
        fflush(_coverage_fout);
        }
        if (tmp___1) {
          {
          fprintf(_coverage_fout, "782\n");
          fflush(_coverage_fout);
          }
          TIFFSetField(out, (unsigned int )tag, tr, tg, tb, ta);
        } else {
          {
          fprintf(_coverage_fout, "783\n");
          fflush(_coverage_fout);
          }

        }
      } else {
        {
        fprintf(_coverage_fout, "791\n");
        fflush(_coverage_fout);
        }
        if ((int )count == 65535) {
          {
          fprintf(_coverage_fout, "788\n");
          fflush(_coverage_fout);
          }
          tmp___2 = TIFFGetField(in, (unsigned int )tag, & shortv1___0,
                                 & shortav);
          {
          fprintf(_coverage_fout, "789\n");
          fflush(_coverage_fout);
          }
          if (tmp___2) {
            {
            fprintf(_coverage_fout, "786\n");
            fflush(_coverage_fout);
            }
            TIFFSetField(out, (unsigned int )tag, shortv1___0, shortav);
          } else {
            {
            fprintf(_coverage_fout, "787\n");
            fflush(_coverage_fout);
            }

          }
        } else {
          {
          fprintf(_coverage_fout, "790\n");
          fflush(_coverage_fout);
          }

        }
      }
    }
  }
  break;
  {
  fprintf(_coverage_fout, "819\n");
  fflush(_coverage_fout);
  }
  case 4: 
  tmp___3 = TIFFGetField(in, (unsigned int )tag, & longv);
  {
  fprintf(_coverage_fout, "820\n");
  fflush(_coverage_fout);
  }
  if (tmp___3) {
    {
    fprintf(_coverage_fout, "794\n");
    fflush(_coverage_fout);
    }
    TIFFSetField(out, (unsigned int )tag, longv);
  } else {
    {
    fprintf(_coverage_fout, "795\n");
    fflush(_coverage_fout);
    }

  }
  break;
  {
  fprintf(_coverage_fout, "821\n");
  fflush(_coverage_fout);
  }
  case 5: 
  if ((int )count == 1) {
    {
    fprintf(_coverage_fout, "798\n");
    fflush(_coverage_fout);
    }
    tmp___4 = TIFFGetField(in, (unsigned int )tag, & floatv);
    {
    fprintf(_coverage_fout, "799\n");
    fflush(_coverage_fout);
    }
    if (tmp___4) {
      {
      fprintf(_coverage_fout, "796\n");
      fflush(_coverage_fout);
      }
      TIFFSetField(out, (unsigned int )tag, floatv);
    } else {
      {
      fprintf(_coverage_fout, "797\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "805\n");
    fflush(_coverage_fout);
    }
    if ((int )count == 65535) {
      {
      fprintf(_coverage_fout, "802\n");
      fflush(_coverage_fout);
      }
      tmp___5 = TIFFGetField(in, (unsigned int )tag, & floatav);
      {
      fprintf(_coverage_fout, "803\n");
      fflush(_coverage_fout);
      }
      if (tmp___5) {
        {
        fprintf(_coverage_fout, "800\n");
        fflush(_coverage_fout);
        }
        TIFFSetField(out, (unsigned int )tag, floatav);
      } else {
        {
        fprintf(_coverage_fout, "801\n");
        fflush(_coverage_fout);
        }

      }
    } else {
      {
      fprintf(_coverage_fout, "804\n");
      fflush(_coverage_fout);
      }

    }
  }
  break;
  {
  fprintf(_coverage_fout, "822\n");
  fflush(_coverage_fout);
  }
  case 2: 
  tmp___6 = TIFFGetField(in, (unsigned int )tag, & stringv);
  {
  fprintf(_coverage_fout, "823\n");
  fflush(_coverage_fout);
  }
  if (tmp___6) {
    {
    fprintf(_coverage_fout, "806\n");
    fflush(_coverage_fout);
    }
    TIFFSetField(out, (unsigned int )tag, stringv);
  } else {
    {
    fprintf(_coverage_fout, "807\n");
    fflush(_coverage_fout);
    }

  }
  break;
  {
  fprintf(_coverage_fout, "824\n");
  fflush(_coverage_fout);
  }
  case 12: 
  if ((int )count == 1) {
    {
    fprintf(_coverage_fout, "810\n");
    fflush(_coverage_fout);
    }
    tmp___7 = TIFFGetField(in, (unsigned int )tag, & doublev);
    {
    fprintf(_coverage_fout, "811\n");
    fflush(_coverage_fout);
    }
    if (tmp___7) {
      {
      fprintf(_coverage_fout, "808\n");
      fflush(_coverage_fout);
      }
      TIFFSetField(out, (unsigned int )tag, doublev);
    } else {
      {
      fprintf(_coverage_fout, "809\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "817\n");
    fflush(_coverage_fout);
    }
    if ((int )count == 65535) {
      {
      fprintf(_coverage_fout, "814\n");
      fflush(_coverage_fout);
      }
      tmp___8 = TIFFGetField(in, (unsigned int )tag, & doubleav);
      {
      fprintf(_coverage_fout, "815\n");
      fflush(_coverage_fout);
      }
      if (tmp___8) {
        {
        fprintf(_coverage_fout, "812\n");
        fflush(_coverage_fout);
        }
        TIFFSetField(out, (unsigned int )tag, doubleav);
      } else {
        {
        fprintf(_coverage_fout, "813\n");
        fflush(_coverage_fout);
        }

      }
    } else {
      {
      fprintf(_coverage_fout, "816\n");
      fflush(_coverage_fout);
      }

    }
  }
  break;
  {
  fprintf(_coverage_fout, "825\n");
  fflush(_coverage_fout);
  }
  default: 
  tmp___9 = TIFFFileName(in);
  {
  fprintf(_coverage_fout, "826\n");
  fflush(_coverage_fout);
  }
  TIFFError(tmp___9, "Data type %d is not supported, tag %d skipped.", tag, type);
  }
  {
  fprintf(_coverage_fout, "827\n");
  fflush(_coverage_fout);
  }
  return;
}
}
static struct cpTag tags[33]  = 
  {      {(uint16 )254, (uint16 )1, (TIFFDataType )4}, 
        {(uint16 )263, (uint16 )1, (TIFFDataType )3}, 
        {(uint16 )269, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )270, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )271, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )272, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )280, (uint16 )1, (TIFFDataType )3}, 
        {(uint16 )281, (uint16 )1, (TIFFDataType )3}, 
        {(uint16 )282, (uint16 )1, (TIFFDataType )5}, 
        {(uint16 )283, (uint16 )1, (TIFFDataType )5}, 
        {(uint16 )285, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )286, (uint16 )1, (TIFFDataType )5}, 
        {(uint16 )287, (uint16 )1, (TIFFDataType )5}, 
        {(uint16 )296, (uint16 )1, (TIFFDataType )3}, 
        {(uint16 )305, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )306, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )315, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )316, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )318, (unsigned short)65535, (TIFFDataType )5}, 
        {(uint16 )319, (unsigned short)65535, (TIFFDataType )5}, 
        {(uint16 )321, (uint16 )2, (TIFFDataType )3}, 
        {(uint16 )332, (uint16 )1, (TIFFDataType )3}, 
        {(uint16 )336, (uint16 )2, (TIFFDataType )3}, 
        {(uint16 )337, (uint16 )1, (TIFFDataType )2}, 
        {(uint16 )339, (uint16 )1, (TIFFDataType )3}, 
        {(uint16 )529, (unsigned short)65535, (TIFFDataType )5}, 
        {(uint16 )530, (uint16 )2, (TIFFDataType )3}, 
        {(uint16 )531, (uint16 )1, (TIFFDataType )3}, 
        {(uint16 )532, (unsigned short)65535, (TIFFDataType )5}, 
        {(uint16 )338, (unsigned short)65535, (TIFFDataType )3}, 
        {(uint16 )340, (uint16 )1, (TIFFDataType )12}, 
        {(uint16 )341, (uint16 )1, (TIFFDataType )12}, 
        {(uint16 )37439, (uint16 )1, (TIFFDataType )12}};
static copyFunc pickCopyFunc(TIFF *in , TIFF *out , uint16 bitspersample ,
                             uint16 samplesperpixel ) ;
static int tiffcp(TIFF *in , TIFF *out ) 
{ uint16 bitspersample ;
  uint16 samplesperpixel ;
  int (*cf)(TIFF *in , TIFF *out , uint32 l , uint32 w , uint16 samplesperpixel ) ;
  uint32 width ;
  uint32 length ;
  struct cpTag *p ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  uint16 input_compression ;
  uint16 input_photometric ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  char const   *tmp___7 ;
  char const   *tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  uint32 len32 ;
  void **data ;
  int tmp___13 ;
  uint16 ninks ;
  char const   *inknames ;
  int inknameslen ;
  size_t tmp___14 ;
  char const   *cp ;
  void *tmp___15 ;
  char *tmp___16 ;
  size_t tmp___17 ;
  int tmp___18 ;
  int tmp___19 ;
  unsigned short pg0 ;
  unsigned short pg1 ;
  int tmp___20 ;
  int tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "954\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFGetField(in, 256U, & width);
  {
  fprintf(_coverage_fout, "955\n");
  fflush(_coverage_fout);
  }
  if (tmp) {
    {
    fprintf(_coverage_fout, "828\n");
    fflush(_coverage_fout);
    }
    TIFFSetField(out, 256U, width);
  } else {
    {
    fprintf(_coverage_fout, "829\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "956\n");
  fflush(_coverage_fout);
  }
  tmp___0 = TIFFGetField(in, 257U, & length);
  {
  fprintf(_coverage_fout, "957\n");
  fflush(_coverage_fout);
  }
  if (tmp___0) {
    {
    fprintf(_coverage_fout, "830\n");
    fflush(_coverage_fout);
    }
    TIFFSetField(out, 257U, length);
  } else {
    {
    fprintf(_coverage_fout, "831\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "958\n");
  fflush(_coverage_fout);
  }
  tmp___1 = TIFFGetField(in, 258U, & bitspersample);
  {
  fprintf(_coverage_fout, "959\n");
  fflush(_coverage_fout);
  }
  if (tmp___1) {
    {
    fprintf(_coverage_fout, "832\n");
    fflush(_coverage_fout);
    }
    TIFFSetField(out, 258U, bitspersample);
  } else {
    {
    fprintf(_coverage_fout, "833\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "960\n");
  fflush(_coverage_fout);
  }
  tmp___2 = TIFFGetField(in, 277U, & samplesperpixel);
  {
  fprintf(_coverage_fout, "961\n");
  fflush(_coverage_fout);
  }
  if (tmp___2) {
    {
    fprintf(_coverage_fout, "834\n");
    fflush(_coverage_fout);
    }
    TIFFSetField(out, 277U, samplesperpixel);
  } else {
    {
    fprintf(_coverage_fout, "835\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "962\n");
  fflush(_coverage_fout);
  }
  if ((int )compression != 65535) {
    {
    fprintf(_coverage_fout, "836\n");
    fflush(_coverage_fout);
    }
    TIFFSetField(out, 259U, compression);
  } else {
    {
    fprintf(_coverage_fout, "839\n");
    fflush(_coverage_fout);
    }
    tmp___3 = TIFFGetField(in, 259U, & compression);
    {
    fprintf(_coverage_fout, "840\n");
    fflush(_coverage_fout);
    }
    if (tmp___3) {
      {
      fprintf(_coverage_fout, "837\n");
      fflush(_coverage_fout);
      }
      TIFFSetField(out, 259U, compression);
    } else {
      {
      fprintf(_coverage_fout, "838\n");
      fflush(_coverage_fout);
      }

    }
  }
  {
  fprintf(_coverage_fout, "963\n");
  fflush(_coverage_fout);
  }
  if ((int )compression == 7) {
    {
    fprintf(_coverage_fout, "851\n");
    fflush(_coverage_fout);
    }
    tmp___4 = TIFFGetField(in, 259U, & input_compression);
    {
    fprintf(_coverage_fout, "852\n");
    fflush(_coverage_fout);
    }
    if (tmp___4) {
      {
      fprintf(_coverage_fout, "843\n");
      fflush(_coverage_fout);
      }
      if ((int )input_compression == 7) {
        {
        fprintf(_coverage_fout, "841\n");
        fflush(_coverage_fout);
        }
        TIFFSetField(in, 65538U, 0x0001);
      } else {
        {
        fprintf(_coverage_fout, "842\n");
        fflush(_coverage_fout);
        }

      }
    } else {
      {
      fprintf(_coverage_fout, "844\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "853\n");
    fflush(_coverage_fout);
    }
    tmp___5 = TIFFGetField(in, 262U, & input_photometric);
    {
    fprintf(_coverage_fout, "854\n");
    fflush(_coverage_fout);
    }
    if (tmp___5) {
      {
      fprintf(_coverage_fout, "849\n");
      fflush(_coverage_fout);
      }
      if ((int )input_photometric == 2) {
        {
        fprintf(_coverage_fout, "847\n");
        fflush(_coverage_fout);
        }
        if (jpegcolormode == 0x0001) {
          {
          fprintf(_coverage_fout, "845\n");
          fflush(_coverage_fout);
          }
          TIFFSetField(out, 262U, 6);
        } else {
          {
          fprintf(_coverage_fout, "846\n");
          fflush(_coverage_fout);
          }
          TIFFSetField(out, 262U, 2);
        }
      } else {
        {
        fprintf(_coverage_fout, "848\n");
        fflush(_coverage_fout);
        }
        TIFFSetField(out, 262U, input_photometric);
      }
    } else {
      {
      fprintf(_coverage_fout, "850\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "861\n");
    fflush(_coverage_fout);
    }
    if ((int )compression == 34676) {
      goto _L;
    } else {
      {
      fprintf(_coverage_fout, "860\n");
      fflush(_coverage_fout);
      }
      if ((int )compression == 34677) {
        {
        fprintf(_coverage_fout, "857\n");
        fflush(_coverage_fout);
        }
        _L: /* CIL Label */ 
        if ((int )samplesperpixel == 1) {
          {
          fprintf(_coverage_fout, "855\n");
          fflush(_coverage_fout);
          }
          tmp___6 = 32844;
        } else {
          {
          fprintf(_coverage_fout, "856\n");
          fflush(_coverage_fout);
          }
          tmp___6 = 32845;
        }
        {
        fprintf(_coverage_fout, "858\n");
        fflush(_coverage_fout);
        }
        TIFFSetField(out, 262U, tmp___6);
      } else {
        {
        fprintf(_coverage_fout, "859\n");
        fflush(_coverage_fout);
        }
        cpTag(in, out, (unsigned short)262, (unsigned short)1,
              (enum __anonenum_TIFFDataType_32 )3);
      }
    }
  }
  {
  fprintf(_coverage_fout, "964\n");
  fflush(_coverage_fout);
  }
  if ((int )fillorder != 0) {
    {
    fprintf(_coverage_fout, "862\n");
    fflush(_coverage_fout);
    }
    TIFFSetField(out, 266U, fillorder);
  } else {
    {
    fprintf(_coverage_fout, "863\n");
    fflush(_coverage_fout);
    }
    cpTag(in, out, (unsigned short)266, (unsigned short)1,
          (enum __anonenum_TIFFDataType_32 )3);
  }
  {
  fprintf(_coverage_fout, "965\n");
  fflush(_coverage_fout);
  }
  TIFFGetFieldDefaulted(in, 274U, & orientation);
  switch ((int )orientation) {
  {
  fprintf(_coverage_fout, "864\n");
  fflush(_coverage_fout);
  }
  case 3: 
  case 7: 
  tmp___7 = TIFFFileName(in);
  {
  fprintf(_coverage_fout, "865\n");
  fflush(_coverage_fout);
  }
  TIFFWarning(tmp___7, "using bottom-left orientation");
  {
  fprintf(_coverage_fout, "866\n");
  fflush(_coverage_fout);
  }
  orientation = (unsigned short)4;
  case 8: 
  case 4: 
  break;
  {
  fprintf(_coverage_fout, "867\n");
  fflush(_coverage_fout);
  }
  case 2: 
  case 6: 
  default: 
  tmp___8 = TIFFFileName(in);
  {
  fprintf(_coverage_fout, "868\n");
  fflush(_coverage_fout);
  }
  TIFFWarning(tmp___8, "using top-left orientation");
  {
  fprintf(_coverage_fout, "869\n");
  fflush(_coverage_fout);
  }
  orientation = (unsigned short)1;
  case 5: 
  case 1: 
  break;
  }
  {
  fprintf(_coverage_fout, "966\n");
  fflush(_coverage_fout);
  }
  TIFFSetField(out, 274U, orientation);
  {
  fprintf(_coverage_fout, "967\n");
  fflush(_coverage_fout);
  }
  if (outtiled == -1) {
    {
    fprintf(_coverage_fout, "870\n");
    fflush(_coverage_fout);
    }
    outtiled = TIFFIsTiled(in);
  } else {
    {
    fprintf(_coverage_fout, "871\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "968\n");
  fflush(_coverage_fout);
  }
  if (outtiled) {
    {
    fprintf(_coverage_fout, "876\n");
    fflush(_coverage_fout);
    }
    if (tilewidth == 4294967295U) {
      {
      fprintf(_coverage_fout, "872\n");
      fflush(_coverage_fout);
      }
      TIFFGetField(in, 322U, & tilewidth);
    } else {
      {
      fprintf(_coverage_fout, "873\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "877\n");
    fflush(_coverage_fout);
    }
    if (tilelength == 4294967295U) {
      {
      fprintf(_coverage_fout, "874\n");
      fflush(_coverage_fout);
      }
      TIFFGetField(in, 323U, & tilelength);
    } else {
      {
      fprintf(_coverage_fout, "875\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "878\n");
    fflush(_coverage_fout);
    }
    TIFFDefaultTileSize(out, & tilewidth, & tilelength);
    {
    fprintf(_coverage_fout, "879\n");
    fflush(_coverage_fout);
    }
    TIFFSetField(out, 322U, tilewidth);
    {
    fprintf(_coverage_fout, "880\n");
    fflush(_coverage_fout);
    }
    TIFFSetField(out, 323U, tilelength);
  } else {
    {
    fprintf(_coverage_fout, "888\n");
    fflush(_coverage_fout);
    }
    if (rowsperstrip == 0U) {
      {
      fprintf(_coverage_fout, "883\n");
      fflush(_coverage_fout);
      }
      tmp___9 = TIFFGetField(in, 278U, & rowsperstrip);
      {
      fprintf(_coverage_fout, "884\n");
      fflush(_coverage_fout);
      }
      if (tmp___9) {
        {
        fprintf(_coverage_fout, "881\n");
        fflush(_coverage_fout);
        }

      } else {
        {
        fprintf(_coverage_fout, "882\n");
        fflush(_coverage_fout);
        }
        rowsperstrip = TIFFDefaultStripSize(out, rowsperstrip);
      }
    } else {
      {
      fprintf(_coverage_fout, "887\n");
      fflush(_coverage_fout);
      }
      if (rowsperstrip == 4294967295U) {
        {
        fprintf(_coverage_fout, "885\n");
        fflush(_coverage_fout);
        }
        rowsperstrip = length;
      } else {
        {
        fprintf(_coverage_fout, "886\n");
        fflush(_coverage_fout);
        }

      }
    }
    {
    fprintf(_coverage_fout, "889\n");
    fflush(_coverage_fout);
    }
    TIFFSetField(out, 278U, rowsperstrip);
  }
  {
  fprintf(_coverage_fout, "969\n");
  fflush(_coverage_fout);
  }
  if ((int )config != 65535) {
    {
    fprintf(_coverage_fout, "890\n");
    fflush(_coverage_fout);
    }
    TIFFSetField(out, 284U, config);
  } else {
    {
    fprintf(_coverage_fout, "893\n");
    fflush(_coverage_fout);
    }
    tmp___10 = TIFFGetField(in, 284U, & config);
    {
    fprintf(_coverage_fout, "894\n");
    fflush(_coverage_fout);
    }
    if (tmp___10) {
      {
      fprintf(_coverage_fout, "891\n");
      fflush(_coverage_fout);
      }
      TIFFSetField(out, 284U, config);
    } else {
      {
      fprintf(_coverage_fout, "892\n");
      fflush(_coverage_fout);
      }

    }
  }
  {
  fprintf(_coverage_fout, "970\n");
  fflush(_coverage_fout);
  }
  if ((int )samplesperpixel <= 4) {
    {
    fprintf(_coverage_fout, "895\n");
    fflush(_coverage_fout);
    }
    cpTag(in, out, (unsigned short)301, (unsigned short)4,
          (enum __anonenum_TIFFDataType_32 )3);
  } else {
    {
    fprintf(_coverage_fout, "896\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "971\n");
  fflush(_coverage_fout);
  }
  cpTag(in, out, (unsigned short)320, (unsigned short)4,
        (enum __anonenum_TIFFDataType_32 )3);
  switch ((int )compression) {
  {
  fprintf(_coverage_fout, "909\n");
  fflush(_coverage_fout);
  }
  case 7: 
  TIFFSetField(out, 65537U, quality);
  {
  fprintf(_coverage_fout, "910\n");
  fflush(_coverage_fout);
  }
  TIFFSetField(out, 65538U, jpegcolormode);
  break;
  {
  fprintf(_coverage_fout, "911\n");
  fflush(_coverage_fout);
  }
  case 5: 
  case 8: 
  case 32946: 
  if ((int )predictor != 65535) {
    {
    fprintf(_coverage_fout, "897\n");
    fflush(_coverage_fout);
    }
    TIFFSetField(out, 317U, predictor);
  } else {
    {
    fprintf(_coverage_fout, "900\n");
    fflush(_coverage_fout);
    }
    tmp___11 = TIFFGetField(in, 317U, & predictor);
    {
    fprintf(_coverage_fout, "901\n");
    fflush(_coverage_fout);
    }
    if (tmp___11) {
      {
      fprintf(_coverage_fout, "898\n");
      fflush(_coverage_fout);
      }
      TIFFSetField(out, 317U, predictor);
    } else {
      {
      fprintf(_coverage_fout, "899\n");
      fflush(_coverage_fout);
      }

    }
  }
  break;
  {
  fprintf(_coverage_fout, "912\n");
  fflush(_coverage_fout);
  }
  case 3: 
  case 4: 
  if ((int )compression == 3) {
    {
    fprintf(_coverage_fout, "907\n");
    fflush(_coverage_fout);
    }
    if (g3opts != 4294967295U) {
      {
      fprintf(_coverage_fout, "902\n");
      fflush(_coverage_fout);
      }
      TIFFSetField(out, 292U, g3opts);
    } else {
      {
      fprintf(_coverage_fout, "905\n");
      fflush(_coverage_fout);
      }
      tmp___12 = TIFFGetField(in, 292U, & g3opts);
      {
      fprintf(_coverage_fout, "906\n");
      fflush(_coverage_fout);
      }
      if (tmp___12) {
        {
        fprintf(_coverage_fout, "903\n");
        fflush(_coverage_fout);
        }
        TIFFSetField(out, 292U, g3opts);
      } else {
        {
        fprintf(_coverage_fout, "904\n");
        fflush(_coverage_fout);
        }

      }
    }
  } else {
    {
    fprintf(_coverage_fout, "908\n");
    fflush(_coverage_fout);
    }
    cpTag(in, out, (unsigned short)293, (unsigned short)1,
          (enum __anonenum_TIFFDataType_32 )4);
  }
  {
  fprintf(_coverage_fout, "913\n");
  fflush(_coverage_fout);
  }
  cpTag(in, out, (unsigned short)326, (unsigned short)1,
        (enum __anonenum_TIFFDataType_32 )4);
  {
  fprintf(_coverage_fout, "914\n");
  fflush(_coverage_fout);
  }
  cpTag(in, out, (unsigned short)327, (unsigned short)1,
        (enum __anonenum_TIFFDataType_32 )4);
  {
  fprintf(_coverage_fout, "915\n");
  fflush(_coverage_fout);
  }
  cpTag(in, out, (unsigned short)328, (unsigned short)1,
        (enum __anonenum_TIFFDataType_32 )4);
  {
  fprintf(_coverage_fout, "916\n");
  fflush(_coverage_fout);
  }
  cpTag(in, out, (unsigned short)34908, (unsigned short)1,
        (enum __anonenum_TIFFDataType_32 )4);
  {
  fprintf(_coverage_fout, "917\n");
  fflush(_coverage_fout);
  }
  cpTag(in, out, (unsigned short)34910, (unsigned short)1,
        (enum __anonenum_TIFFDataType_32 )4);
  {
  fprintf(_coverage_fout, "918\n");
  fflush(_coverage_fout);
  }
  cpTag(in, out, (unsigned short)34909, (unsigned short)1,
        (enum __anonenum_TIFFDataType_32 )2);
  break;
  }
  {
  fprintf(_coverage_fout, "972\n");
  fflush(_coverage_fout);
  }
  tmp___13 = TIFFGetField(in, 34675U, & len32, & data);
  {
  fprintf(_coverage_fout, "973\n");
  fflush(_coverage_fout);
  }
  if (tmp___13) {
    {
    fprintf(_coverage_fout, "919\n");
    fflush(_coverage_fout);
    }
    TIFFSetField(out, 34675U, len32, data);
  } else {
    {
    fprintf(_coverage_fout, "920\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "974\n");
  fflush(_coverage_fout);
  }
  tmp___19 = TIFFGetField(in, 334U, & ninks);
  {
  fprintf(_coverage_fout, "975\n");
  fflush(_coverage_fout);
  }
  if (tmp___19) {
    {
    fprintf(_coverage_fout, "937\n");
    fflush(_coverage_fout);
    }
    TIFFSetField(out, 334U, ninks);
    {
    fprintf(_coverage_fout, "938\n");
    fflush(_coverage_fout);
    }
    tmp___18 = TIFFGetField(in, 333U, & inknames);
    {
    fprintf(_coverage_fout, "939\n");
    fflush(_coverage_fout);
    }
    if (tmp___18) {
      {
      fprintf(_coverage_fout, "931\n");
      fflush(_coverage_fout);
      }
      tmp___14 = strlen(inknames);
      {
      fprintf(_coverage_fout, "932\n");
      fflush(_coverage_fout);
      }
      inknameslen = (int )(tmp___14 + 1U);
      {
      fprintf(_coverage_fout, "933\n");
      fflush(_coverage_fout);
      }
      cp = inknames;
      {
      fprintf(_coverage_fout, "934\n");
      fflush(_coverage_fout);
      }
      while (1) {
        {
        fprintf(_coverage_fout, "926\n");
        fflush(_coverage_fout);
        }
        if ((int )ninks > 1) {
          {
          fprintf(_coverage_fout, "921\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
        {
        fprintf(_coverage_fout, "927\n");
        fflush(_coverage_fout);
        }
        tmp___15 = __rawmemchr((void const   *)cp, '\000');
        {
        fprintf(_coverage_fout, "928\n");
        fflush(_coverage_fout);
        }
        cp = (char const   *)((char *)tmp___15);
        {
        fprintf(_coverage_fout, "929\n");
        fflush(_coverage_fout);
        }
        if (cp) {
          {
          fprintf(_coverage_fout, "922\n");
          fflush(_coverage_fout);
          }
          cp ++;
          {
          fprintf(_coverage_fout, "923\n");
          fflush(_coverage_fout);
          }
          tmp___17 = strlen(cp);
          {
          fprintf(_coverage_fout, "924\n");
          fflush(_coverage_fout);
          }
          inknameslen = (int )((size_t )inknameslen + (tmp___17 + 1U));
        } else {
          {
          fprintf(_coverage_fout, "925\n");
          fflush(_coverage_fout);
          }

        }
        {
        fprintf(_coverage_fout, "930\n");
        fflush(_coverage_fout);
        }
        ninks = (uint16 )((int )ninks - 1);
      }
      {
      fprintf(_coverage_fout, "935\n");
      fflush(_coverage_fout);
      }
      TIFFSetField(out, 333U, inknameslen, inknames);
    } else {
      {
      fprintf(_coverage_fout, "936\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "940\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "976\n");
  fflush(_coverage_fout);
  }
  tmp___21 = TIFFGetField(in, 297U, & pg0, & pg1);
  {
  fprintf(_coverage_fout, "977\n");
  fflush(_coverage_fout);
  }
  if (tmp___21) {
    {
    fprintf(_coverage_fout, "945\n");
    fflush(_coverage_fout);
    }
    if (pageNum < 0) {
      {
      fprintf(_coverage_fout, "941\n");
      fflush(_coverage_fout);
      }
      TIFFSetField(out, 297U, pg0, pg1);
    } else {
      {
      fprintf(_coverage_fout, "942\n");
      fflush(_coverage_fout);
      }
      tmp___20 = pageNum;
      {
      fprintf(_coverage_fout, "943\n");
      fflush(_coverage_fout);
      }
      pageNum ++;
      {
      fprintf(_coverage_fout, "944\n");
      fflush(_coverage_fout);
      }
      TIFFSetField(out, 297U, tmp___20, 0);
    }
  } else {
    {
    fprintf(_coverage_fout, "946\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "978\n");
  fflush(_coverage_fout);
  }
  p = tags;
  {
  fprintf(_coverage_fout, "979\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "948\n");
    fflush(_coverage_fout);
    }
    if ((unsigned int )p < (unsigned int )(& tags[sizeof(tags) / sizeof(tags[0])])) {
      {
      fprintf(_coverage_fout, "947\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "949\n");
    fflush(_coverage_fout);
    }
    cpTag(in, out, p->tag, p->count, p->type);
    {
    fprintf(_coverage_fout, "950\n");
    fflush(_coverage_fout);
    }
    p ++;
  }
  {
  fprintf(_coverage_fout, "980\n");
  fflush(_coverage_fout);
  }
  cf = pickCopyFunc(in, out, bitspersample, samplesperpixel);
  {
  fprintf(_coverage_fout, "981\n");
  fflush(_coverage_fout);
  }
  if (cf) {
    {
    fprintf(_coverage_fout, "951\n");
    fflush(_coverage_fout);
    }
    tmp___22 = (*cf)(in, out, length, width, samplesperpixel);
    {
    fprintf(_coverage_fout, "952\n");
    fflush(_coverage_fout);
    }
    tmp___23 = tmp___22;
  } else {
    {
    fprintf(_coverage_fout, "953\n");
    fflush(_coverage_fout);
    }
    tmp___23 = 0;
  }
  {
  fprintf(_coverage_fout, "982\n");
  fflush(_coverage_fout);
  }
  return (tmp___23);
}
}
static int cpContig2ContigByRow(TIFF *in , TIFF *out , uint32 imagelength ,
                                uint32 imagewidth , tsample_t spp ) 
{ tdata_t buf ;
  tsize_t tmp ;
  tdata_t tmp___0 ;
  uint32 row ;
  int tmp___1 ;
  int tmp___2 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "994\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFScanlineSize(in);
  {
  fprintf(_coverage_fout, "995\n");
  fflush(_coverage_fout);
  }
  tmp___0 = _TIFFmalloc(tmp);
  {
  fprintf(_coverage_fout, "996\n");
  fflush(_coverage_fout);
  }
  buf = tmp___0;
  {
  fprintf(_coverage_fout, "997\n");
  fflush(_coverage_fout);
  }
  row = 0U;
  {
  fprintf(_coverage_fout, "998\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "988\n");
    fflush(_coverage_fout);
    }
    if (row < imagelength) {
      {
      fprintf(_coverage_fout, "983\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "989\n");
    fflush(_coverage_fout);
    }
    tmp___1 = TIFFReadScanline(in, buf, row, (unsigned short)0);
    {
    fprintf(_coverage_fout, "990\n");
    fflush(_coverage_fout);
    }
    if (tmp___1 < 0) {
      {
      fprintf(_coverage_fout, "985\n");
      fflush(_coverage_fout);
      }
      if (! ignore) {
        goto bad;
      } else {
        {
        fprintf(_coverage_fout, "984\n");
        fflush(_coverage_fout);
        }

      }
    } else {
      {
      fprintf(_coverage_fout, "986\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "991\n");
    fflush(_coverage_fout);
    }
    tmp___2 = TIFFWriteScanline(out, buf, row, (unsigned short)0);
    {
    fprintf(_coverage_fout, "992\n");
    fflush(_coverage_fout);
    }
    if (tmp___2 < 0) {
      goto bad;
    } else {
      {
      fprintf(_coverage_fout, "987\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "993\n");
    fflush(_coverage_fout);
    }
    row ++;
  }
  {
  fprintf(_coverage_fout, "999\n");
  fflush(_coverage_fout);
  }
  _TIFFfree(buf);
  {
  fprintf(_coverage_fout, "1000\n");
  fflush(_coverage_fout);
  }
  return (1);
  {
  fprintf(_coverage_fout, "1001\n");
  fflush(_coverage_fout);
  }
  bad: 
  _TIFFfree(buf);
  {
  fprintf(_coverage_fout, "1002\n");
  fflush(_coverage_fout);
  }
  return (0);
}
}
static void subtract8(void *i , void *b , uint32 pixels ) 
{ uint8 *image ;
  uint8 *bias___0 ;
  uint32 tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1012\n");
  fflush(_coverage_fout);
  }
  image = (uint8 *)i;
  {
  fprintf(_coverage_fout, "1013\n");
  fflush(_coverage_fout);
  }
  bias___0 = (uint8 *)b;
  {
  fprintf(_coverage_fout, "1014\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "1006\n");
    fflush(_coverage_fout);
    }
    tmp = pixels;
    {
    fprintf(_coverage_fout, "1007\n");
    fflush(_coverage_fout);
    }
    pixels --;
    {
    fprintf(_coverage_fout, "1008\n");
    fflush(_coverage_fout);
    }
    if (tmp) {
      {
      fprintf(_coverage_fout, "1003\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "1009\n");
    fflush(_coverage_fout);
    }
    if ((int )*image > (int )*bias___0) {
      {
      fprintf(_coverage_fout, "1004\n");
      fflush(_coverage_fout);
      }
      *image = (unsigned char )((int )*image - (int )*bias___0);
    } else {
      {
      fprintf(_coverage_fout, "1005\n");
      fflush(_coverage_fout);
      }
      *image = (unsigned char)0;
    }
    {
    fprintf(_coverage_fout, "1010\n");
    fflush(_coverage_fout);
    }
    image ++;
    {
    fprintf(_coverage_fout, "1011\n");
    fflush(_coverage_fout);
    }
    bias___0 ++;
  }
  {
  fprintf(_coverage_fout, "1015\n");
  fflush(_coverage_fout);
  }
  return;
}
}
static void subtract16(void *i , void *b , uint32 pixels ) 
{ uint16 *image ;
  uint16 *bias___0 ;
  uint32 tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1025\n");
  fflush(_coverage_fout);
  }
  image = (uint16 *)i;
  {
  fprintf(_coverage_fout, "1026\n");
  fflush(_coverage_fout);
  }
  bias___0 = (uint16 *)b;
  {
  fprintf(_coverage_fout, "1027\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "1019\n");
    fflush(_coverage_fout);
    }
    tmp = pixels;
    {
    fprintf(_coverage_fout, "1020\n");
    fflush(_coverage_fout);
    }
    pixels --;
    {
    fprintf(_coverage_fout, "1021\n");
    fflush(_coverage_fout);
    }
    if (tmp) {
      {
      fprintf(_coverage_fout, "1016\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "1022\n");
    fflush(_coverage_fout);
    }
    if ((int )*image > (int )*bias___0) {
      {
      fprintf(_coverage_fout, "1017\n");
      fflush(_coverage_fout);
      }
      *image = (unsigned short )((int )*image - (int )*bias___0);
    } else {
      {
      fprintf(_coverage_fout, "1018\n");
      fflush(_coverage_fout);
      }
      *image = (unsigned short)0;
    }
    {
    fprintf(_coverage_fout, "1023\n");
    fflush(_coverage_fout);
    }
    image ++;
    {
    fprintf(_coverage_fout, "1024\n");
    fflush(_coverage_fout);
    }
    bias___0 ++;
  }
  {
  fprintf(_coverage_fout, "1028\n");
  fflush(_coverage_fout);
  }
  return;
}
}
static void subtract32(void *i , void *b , uint32 pixels ) 
{ uint32 *image ;
  uint32 *bias___0 ;
  uint32 tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1038\n");
  fflush(_coverage_fout);
  }
  image = (uint32 *)i;
  {
  fprintf(_coverage_fout, "1039\n");
  fflush(_coverage_fout);
  }
  bias___0 = (uint32 *)b;
  {
  fprintf(_coverage_fout, "1040\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "1032\n");
    fflush(_coverage_fout);
    }
    tmp = pixels;
    {
    fprintf(_coverage_fout, "1033\n");
    fflush(_coverage_fout);
    }
    pixels --;
    {
    fprintf(_coverage_fout, "1034\n");
    fflush(_coverage_fout);
    }
    if (tmp) {
      {
      fprintf(_coverage_fout, "1029\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "1035\n");
    fflush(_coverage_fout);
    }
    if (*image > *bias___0) {
      {
      fprintf(_coverage_fout, "1030\n");
      fflush(_coverage_fout);
      }
      *image -= *bias___0;
    } else {
      {
      fprintf(_coverage_fout, "1031\n");
      fflush(_coverage_fout);
      }
      *image = 0U;
    }
    {
    fprintf(_coverage_fout, "1036\n");
    fflush(_coverage_fout);
    }
    image ++;
    {
    fprintf(_coverage_fout, "1037\n");
    fflush(_coverage_fout);
    }
    bias___0 ++;
  }
  {
  fprintf(_coverage_fout, "1041\n");
  fflush(_coverage_fout);
  }
  return;
}
}
static biasFn *lineSubtractFn(unsigned int bits ) 
{ 

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  switch ((int )bits) {
  {
  fprintf(_coverage_fout, "1042\n");
  fflush(_coverage_fout);
  }
  case 8: 
  return (& subtract8);
  {
  fprintf(_coverage_fout, "1043\n");
  fflush(_coverage_fout);
  }
  case 16: 
  return (& subtract16);
  {
  fprintf(_coverage_fout, "1044\n");
  fflush(_coverage_fout);
  }
  case 32: 
  return (& subtract32);
  }
  {
  fprintf(_coverage_fout, "1045\n");
  fflush(_coverage_fout);
  }
  return ((biasFn *)((void *)0));
}
}
static int cpBiasedContig2Contig(TIFF *in , TIFF *out , uint32 imagelength ,
                                 uint32 imagewidth , tsample_t spp ) 
{ tsize_t biasSize ;
  tsize_t tmp ;
  tsize_t bufSize ;
  tsize_t tmp___0 ;
  tdata_t buf ;
  tdata_t biasBuf ;
  uint32 biasWidth ;
  uint32 biasLength ;
  uint16 sampleBits ;
  biasFn *subtractLine ;
  uint32 row ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  tdir_t tmp___4 ;
  tdir_t tmp___5 ;
  char const   *tmp___6 ;
  tdir_t tmp___7 ;
  char const   *tmp___8 ;
  tdir_t tmp___9 ;
  char const   *tmp___10 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1105\n");
  fflush(_coverage_fout);
  }
  if ((int )spp == 1) {
    {
    fprintf(_coverage_fout, "1086\n");
    fflush(_coverage_fout);
    }
    tmp = TIFFScanlineSize(bias);
    {
    fprintf(_coverage_fout, "1087\n");
    fflush(_coverage_fout);
    }
    biasSize = tmp;
    {
    fprintf(_coverage_fout, "1088\n");
    fflush(_coverage_fout);
    }
    tmp___0 = TIFFScanlineSize(in);
    {
    fprintf(_coverage_fout, "1089\n");
    fflush(_coverage_fout);
    }
    bufSize = tmp___0;
    {
    fprintf(_coverage_fout, "1090\n");
    fflush(_coverage_fout);
    }
    biasWidth = (uint32 )0;
    {
    fprintf(_coverage_fout, "1091\n");
    fflush(_coverage_fout);
    }
    biasLength = (uint32 )0;
    {
    fprintf(_coverage_fout, "1092\n");
    fflush(_coverage_fout);
    }
    TIFFGetField(bias, 256U, & biasWidth);
    {
    fprintf(_coverage_fout, "1093\n");
    fflush(_coverage_fout);
    }
    TIFFGetField(bias, 257U, & biasLength);
    {
    fprintf(_coverage_fout, "1094\n");
    fflush(_coverage_fout);
    }
    if (biasSize == bufSize) {
      {
      fprintf(_coverage_fout, "1084\n");
      fflush(_coverage_fout);
      }
      if (imagelength == biasLength) {
        {
        fprintf(_coverage_fout, "1082\n");
        fflush(_coverage_fout);
        }
        if (imagewidth == biasWidth) {
          {
          fprintf(_coverage_fout, "1077\n");
          fflush(_coverage_fout);
          }
          sampleBits = (uint16 )0;
          {
          fprintf(_coverage_fout, "1078\n");
          fflush(_coverage_fout);
          }
          TIFFGetField(in, 258U, & sampleBits);
          {
          fprintf(_coverage_fout, "1079\n");
          fflush(_coverage_fout);
          }
          subtractLine = lineSubtractFn((unsigned int )sampleBits);
          {
          fprintf(_coverage_fout, "1080\n");
          fflush(_coverage_fout);
          }
          if (subtractLine) {
            {
            fprintf(_coverage_fout, "1063\n");
            fflush(_coverage_fout);
            }
            buf = _TIFFmalloc(bufSize);
            {
            fprintf(_coverage_fout, "1064\n");
            fflush(_coverage_fout);
            }
            biasBuf = _TIFFmalloc(bufSize);
            {
            fprintf(_coverage_fout, "1065\n");
            fflush(_coverage_fout);
            }
            row = 0U;
            {
            fprintf(_coverage_fout, "1066\n");
            fflush(_coverage_fout);
            }
            while (1) {
              {
              fprintf(_coverage_fout, "1054\n");
              fflush(_coverage_fout);
              }
              if (row < imagelength) {
                {
                fprintf(_coverage_fout, "1046\n");
                fflush(_coverage_fout);
                }

              } else {
                break;
              }
              {
              fprintf(_coverage_fout, "1055\n");
              fflush(_coverage_fout);
              }
              tmp___1 = TIFFReadScanline(in, buf, row, (unsigned short)0);
              {
              fprintf(_coverage_fout, "1056\n");
              fflush(_coverage_fout);
              }
              if (tmp___1 < 0) {
                {
                fprintf(_coverage_fout, "1048\n");
                fflush(_coverage_fout);
                }
                if (! ignore) {
                  goto bad;
                } else {
                  {
                  fprintf(_coverage_fout, "1047\n");
                  fflush(_coverage_fout);
                  }

                }
              } else {
                {
                fprintf(_coverage_fout, "1049\n");
                fflush(_coverage_fout);
                }

              }
              {
              fprintf(_coverage_fout, "1057\n");
              fflush(_coverage_fout);
              }
              tmp___2 = TIFFReadScanline(bias, biasBuf, row, (unsigned short)0);
              {
              fprintf(_coverage_fout, "1058\n");
              fflush(_coverage_fout);
              }
              if (tmp___2 < 0) {
                {
                fprintf(_coverage_fout, "1051\n");
                fflush(_coverage_fout);
                }
                if (! ignore) {
                  goto bad;
                } else {
                  {
                  fprintf(_coverage_fout, "1050\n");
                  fflush(_coverage_fout);
                  }

                }
              } else {
                {
                fprintf(_coverage_fout, "1052\n");
                fflush(_coverage_fout);
                }

              }
              {
              fprintf(_coverage_fout, "1059\n");
              fflush(_coverage_fout);
              }
              (*subtractLine)(buf, biasBuf, imagewidth);
              {
              fprintf(_coverage_fout, "1060\n");
              fflush(_coverage_fout);
              }
              tmp___3 = TIFFWriteScanline(out, buf, row, (unsigned short)0);
              {
              fprintf(_coverage_fout, "1061\n");
              fflush(_coverage_fout);
              }
              if (tmp___3 < 0) {
                goto bad;
              } else {
                {
                fprintf(_coverage_fout, "1053\n");
                fflush(_coverage_fout);
                }

              }
              {
              fprintf(_coverage_fout, "1062\n");
              fflush(_coverage_fout);
              }
              row ++;
            }
            {
            fprintf(_coverage_fout, "1067\n");
            fflush(_coverage_fout);
            }
            _TIFFfree(buf);
            {
            fprintf(_coverage_fout, "1068\n");
            fflush(_coverage_fout);
            }
            _TIFFfree(biasBuf);
            {
            fprintf(_coverage_fout, "1069\n");
            fflush(_coverage_fout);
            }
            tmp___4 = TIFFCurrentDirectory(bias);
            {
            fprintf(_coverage_fout, "1070\n");
            fflush(_coverage_fout);
            }
            TIFFSetDirectory(bias, tmp___4);
            {
            fprintf(_coverage_fout, "1071\n");
            fflush(_coverage_fout);
            }
            return (1);
            {
            fprintf(_coverage_fout, "1072\n");
            fflush(_coverage_fout);
            }
            bad: 
            _TIFFfree(buf);
            {
            fprintf(_coverage_fout, "1073\n");
            fflush(_coverage_fout);
            }
            _TIFFfree(biasBuf);
            {
            fprintf(_coverage_fout, "1074\n");
            fflush(_coverage_fout);
            }
            return (0);
          } else {
            {
            fprintf(_coverage_fout, "1075\n");
            fflush(_coverage_fout);
            }
            fprintf((FILE */* __restrict  */)stderr,
                    (char const   */* __restrict  */)"No support for biasing %d bit pixels\n",
                    sampleBits);
            {
            fprintf(_coverage_fout, "1076\n");
            fflush(_coverage_fout);
            }
            return (0);
          }
        } else {
          {
          fprintf(_coverage_fout, "1081\n");
          fflush(_coverage_fout);
          }

        }
      } else {
        {
        fprintf(_coverage_fout, "1083\n");
        fflush(_coverage_fout);
        }

      }
    } else {
      {
      fprintf(_coverage_fout, "1085\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "1095\n");
    fflush(_coverage_fout);
    }
    tmp___5 = TIFFCurrentDirectory(in);
    {
    fprintf(_coverage_fout, "1096\n");
    fflush(_coverage_fout);
    }
    tmp___6 = TIFFFileName(in);
    {
    fprintf(_coverage_fout, "1097\n");
    fflush(_coverage_fout);
    }
    tmp___7 = TIFFCurrentDirectory(bias);
    {
    fprintf(_coverage_fout, "1098\n");
    fflush(_coverage_fout);
    }
    tmp___8 = TIFFFileName(bias);
    {
    fprintf(_coverage_fout, "1099\n");
    fflush(_coverage_fout);
    }
    fprintf((FILE */* __restrict  */)stderr,
            (char const   */* __restrict  */)"Bias image %s,%d\nis not the same size as %s,%d\n",
            tmp___8, tmp___7, tmp___6, tmp___5);
    {
    fprintf(_coverage_fout, "1100\n");
    fflush(_coverage_fout);
    }
    return (0);
  } else {
    {
    fprintf(_coverage_fout, "1101\n");
    fflush(_coverage_fout);
    }
    tmp___9 = TIFFCurrentDirectory(in);
    {
    fprintf(_coverage_fout, "1102\n");
    fflush(_coverage_fout);
    }
    tmp___10 = TIFFFileName(in);
    {
    fprintf(_coverage_fout, "1103\n");
    fflush(_coverage_fout);
    }
    fprintf((FILE */* __restrict  */)stderr,
            (char const   */* __restrict  */)"Can\'t bias %s,%d as it has >1 Sample/Pixel\n",
            tmp___10, tmp___9);
    {
    fprintf(_coverage_fout, "1104\n");
    fflush(_coverage_fout);
    }
    return (0);
  }
}
}
static int cpDecodedStrips(TIFF *in , TIFF *out , uint32 imagelength ,
                           uint32 imagewidth , tsample_t spp ) 
{ tsize_t stripsize ;
  tsize_t tmp ;
  tdata_t buf ;
  tdata_t tmp___0 ;
  tstrip_t s ;
  tstrip_t ns ;
  tstrip_t tmp___1 ;
  uint32 row ;
  tsize_t cc ;
  tsize_t tmp___2 ;
  tsize_t tmp___3 ;
  tsize_t tmp___4 ;
  tsize_t tmp___5 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1131\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFStripSize(in);
  {
  fprintf(_coverage_fout, "1132\n");
  fflush(_coverage_fout);
  }
  stripsize = tmp;
  {
  fprintf(_coverage_fout, "1133\n");
  fflush(_coverage_fout);
  }
  tmp___0 = _TIFFmalloc(stripsize);
  {
  fprintf(_coverage_fout, "1134\n");
  fflush(_coverage_fout);
  }
  buf = tmp___0;
  {
  fprintf(_coverage_fout, "1135\n");
  fflush(_coverage_fout);
  }
  if (buf) {
    {
    fprintf(_coverage_fout, "1123\n");
    fflush(_coverage_fout);
    }
    tmp___1 = TIFFNumberOfStrips(in);
    {
    fprintf(_coverage_fout, "1124\n");
    fflush(_coverage_fout);
    }
    ns = tmp___1;
    {
    fprintf(_coverage_fout, "1125\n");
    fflush(_coverage_fout);
    }
    row = (uint32 )0;
    {
    fprintf(_coverage_fout, "1126\n");
    fflush(_coverage_fout);
    }
    s = 0U;
    {
    fprintf(_coverage_fout, "1127\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "1114\n");
      fflush(_coverage_fout);
      }
      if (s < ns) {
        {
        fprintf(_coverage_fout, "1106\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "1115\n");
      fflush(_coverage_fout);
      }
      if (row + rowsperstrip > imagelength) {
        {
        fprintf(_coverage_fout, "1107\n");
        fflush(_coverage_fout);
        }
        tmp___2 = TIFFVStripSize(in, imagelength - row);
        {
        fprintf(_coverage_fout, "1108\n");
        fflush(_coverage_fout);
        }
        tmp___3 = tmp___2;
      } else {
        {
        fprintf(_coverage_fout, "1109\n");
        fflush(_coverage_fout);
        }
        tmp___3 = stripsize;
      }
      {
      fprintf(_coverage_fout, "1116\n");
      fflush(_coverage_fout);
      }
      cc = tmp___3;
      {
      fprintf(_coverage_fout, "1117\n");
      fflush(_coverage_fout);
      }
      tmp___4 = TIFFReadEncodedStrip(in, s, buf, cc);
      {
      fprintf(_coverage_fout, "1118\n");
      fflush(_coverage_fout);
      }
      if (tmp___4 < 0) {
        {
        fprintf(_coverage_fout, "1111\n");
        fflush(_coverage_fout);
        }
        if (! ignore) {
          goto bad;
        } else {
          {
          fprintf(_coverage_fout, "1110\n");
          fflush(_coverage_fout);
          }

        }
      } else {
        {
        fprintf(_coverage_fout, "1112\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "1119\n");
      fflush(_coverage_fout);
      }
      tmp___5 = TIFFWriteEncodedStrip(out, s, buf, cc);
      {
      fprintf(_coverage_fout, "1120\n");
      fflush(_coverage_fout);
      }
      if (tmp___5 < 0) {
        goto bad;
      } else {
        {
        fprintf(_coverage_fout, "1113\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "1121\n");
      fflush(_coverage_fout);
      }
      row += rowsperstrip;
      {
      fprintf(_coverage_fout, "1122\n");
      fflush(_coverage_fout);
      }
      s ++;
    }
    {
    fprintf(_coverage_fout, "1128\n");
    fflush(_coverage_fout);
    }
    _TIFFfree(buf);
    {
    fprintf(_coverage_fout, "1129\n");
    fflush(_coverage_fout);
    }
    return (1);
  } else {
    {
    fprintf(_coverage_fout, "1130\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1136\n");
  fflush(_coverage_fout);
  }
  return (0);
  {
  fprintf(_coverage_fout, "1137\n");
  fflush(_coverage_fout);
  }
  bad: 
  _TIFFfree(buf);
  {
  fprintf(_coverage_fout, "1138\n");
  fflush(_coverage_fout);
  }
  return (0);
}
}
static int cpSeparate2SeparateByRow(TIFF *in , TIFF *out , uint32 imagelength ,
                                    uint32 imagewidth , tsample_t spp ) 
{ tdata_t buf ;
  tsize_t tmp ;
  tdata_t tmp___0 ;
  uint32 row ;
  tsample_t s ;
  int tmp___1 ;
  int tmp___2 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1155\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFScanlineSize(in);
  {
  fprintf(_coverage_fout, "1156\n");
  fflush(_coverage_fout);
  }
  tmp___0 = _TIFFmalloc(tmp);
  {
  fprintf(_coverage_fout, "1157\n");
  fflush(_coverage_fout);
  }
  buf = tmp___0;
  {
  fprintf(_coverage_fout, "1158\n");
  fflush(_coverage_fout);
  }
  s = (unsigned short)0;
  {
  fprintf(_coverage_fout, "1159\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "1151\n");
    fflush(_coverage_fout);
    }
    if ((int )s < (int )spp) {
      {
      fprintf(_coverage_fout, "1139\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "1152\n");
    fflush(_coverage_fout);
    }
    row = 0U;
    {
    fprintf(_coverage_fout, "1153\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "1145\n");
      fflush(_coverage_fout);
      }
      if (row < imagelength) {
        {
        fprintf(_coverage_fout, "1140\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "1146\n");
      fflush(_coverage_fout);
      }
      tmp___1 = TIFFReadScanline(in, buf, row, s);
      {
      fprintf(_coverage_fout, "1147\n");
      fflush(_coverage_fout);
      }
      if (tmp___1 < 0) {
        {
        fprintf(_coverage_fout, "1142\n");
        fflush(_coverage_fout);
        }
        if (! ignore) {
          goto bad;
        } else {
          {
          fprintf(_coverage_fout, "1141\n");
          fflush(_coverage_fout);
          }

        }
      } else {
        {
        fprintf(_coverage_fout, "1143\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "1148\n");
      fflush(_coverage_fout);
      }
      tmp___2 = TIFFWriteScanline(out, buf, row, s);
      {
      fprintf(_coverage_fout, "1149\n");
      fflush(_coverage_fout);
      }
      if (tmp___2 < 0) {
        goto bad;
      } else {
        {
        fprintf(_coverage_fout, "1144\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "1150\n");
      fflush(_coverage_fout);
      }
      row ++;
    }
    {
    fprintf(_coverage_fout, "1154\n");
    fflush(_coverage_fout);
    }
    s = (tsample_t )((int )s + 1);
  }
  {
  fprintf(_coverage_fout, "1160\n");
  fflush(_coverage_fout);
  }
  _TIFFfree(buf);
  {
  fprintf(_coverage_fout, "1161\n");
  fflush(_coverage_fout);
  }
  return (1);
  {
  fprintf(_coverage_fout, "1162\n");
  fflush(_coverage_fout);
  }
  bad: 
  _TIFFfree(buf);
  {
  fprintf(_coverage_fout, "1163\n");
  fflush(_coverage_fout);
  }
  return (0);
}
}
static int cpContig2SeparateByRow(TIFF *in , TIFF *out , uint32 imagelength ,
                                  uint32 imagewidth , tsample_t spp ) 
{ tdata_t inbuf ;
  tsize_t tmp ;
  tdata_t tmp___0 ;
  tdata_t outbuf ;
  tsize_t tmp___1 ;
  tdata_t tmp___2 ;
  register uint8 *inp ;
  register uint8 *outp ;
  register uint32 n ;
  uint32 row ;
  tsample_t s ;
  int tmp___3 ;
  uint8 *tmp___4 ;
  uint32 tmp___5 ;
  int tmp___6 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1200\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFScanlineSize(in);
  {
  fprintf(_coverage_fout, "1201\n");
  fflush(_coverage_fout);
  }
  tmp___0 = _TIFFmalloc(tmp);
  {
  fprintf(_coverage_fout, "1202\n");
  fflush(_coverage_fout);
  }
  inbuf = tmp___0;
  {
  fprintf(_coverage_fout, "1203\n");
  fflush(_coverage_fout);
  }
  tmp___1 = TIFFScanlineSize(out);
  {
  fprintf(_coverage_fout, "1204\n");
  fflush(_coverage_fout);
  }
  tmp___2 = _TIFFmalloc(tmp___1);
  {
  fprintf(_coverage_fout, "1205\n");
  fflush(_coverage_fout);
  }
  outbuf = tmp___2;
  {
  fprintf(_coverage_fout, "1206\n");
  fflush(_coverage_fout);
  }
  s = (unsigned short)0;
  {
  fprintf(_coverage_fout, "1207\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "1188\n");
    fflush(_coverage_fout);
    }
    if ((int )s < (int )spp) {
      {
      fprintf(_coverage_fout, "1164\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "1189\n");
    fflush(_coverage_fout);
    }
    row = 0U;
    {
    fprintf(_coverage_fout, "1190\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "1178\n");
      fflush(_coverage_fout);
      }
      if (row < imagelength) {
        {
        fprintf(_coverage_fout, "1165\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "1179\n");
      fflush(_coverage_fout);
      }
      tmp___3 = TIFFReadScanline(in, inbuf, row, (unsigned short)0);
      {
      fprintf(_coverage_fout, "1180\n");
      fflush(_coverage_fout);
      }
      if (tmp___3 < 0) {
        {
        fprintf(_coverage_fout, "1167\n");
        fflush(_coverage_fout);
        }
        if (! ignore) {
          goto bad;
        } else {
          {
          fprintf(_coverage_fout, "1166\n");
          fflush(_coverage_fout);
          }

        }
      } else {
        {
        fprintf(_coverage_fout, "1168\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "1181\n");
      fflush(_coverage_fout);
      }
      inp = (uint8 *)inbuf + (int )s;
      {
      fprintf(_coverage_fout, "1182\n");
      fflush(_coverage_fout);
      }
      outp = (uint8 *)outbuf;
      {
      fprintf(_coverage_fout, "1183\n");
      fflush(_coverage_fout);
      }
      n = imagewidth;
      {
      fprintf(_coverage_fout, "1184\n");
      fflush(_coverage_fout);
      }
      while (1) {
        {
        fprintf(_coverage_fout, "1170\n");
        fflush(_coverage_fout);
        }
        tmp___5 = n;
        {
        fprintf(_coverage_fout, "1171\n");
        fflush(_coverage_fout);
        }
        n --;
        {
        fprintf(_coverage_fout, "1172\n");
        fflush(_coverage_fout);
        }
        if (tmp___5 > 0U) {
          {
          fprintf(_coverage_fout, "1169\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
        {
        fprintf(_coverage_fout, "1173\n");
        fflush(_coverage_fout);
        }
        tmp___4 = outp;
        {
        fprintf(_coverage_fout, "1174\n");
        fflush(_coverage_fout);
        }
        outp ++;
        {
        fprintf(_coverage_fout, "1175\n");
        fflush(_coverage_fout);
        }
        *tmp___4 = *inp;
        {
        fprintf(_coverage_fout, "1176\n");
        fflush(_coverage_fout);
        }
        inp += (int )spp;
      }
      {
      fprintf(_coverage_fout, "1185\n");
      fflush(_coverage_fout);
      }
      tmp___6 = TIFFWriteScanline(out, outbuf, row, s);
      {
      fprintf(_coverage_fout, "1186\n");
      fflush(_coverage_fout);
      }
      if (tmp___6 < 0) {
        goto bad;
      } else {
        {
        fprintf(_coverage_fout, "1177\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "1187\n");
      fflush(_coverage_fout);
      }
      row ++;
    }
    {
    fprintf(_coverage_fout, "1191\n");
    fflush(_coverage_fout);
    }
    s = (tsample_t )((int )s + 1);
  }
  {
  fprintf(_coverage_fout, "1208\n");
  fflush(_coverage_fout);
  }
  if (inbuf) {
    {
    fprintf(_coverage_fout, "1192\n");
    fflush(_coverage_fout);
    }
    _TIFFfree(inbuf);
  } else {
    {
    fprintf(_coverage_fout, "1193\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1209\n");
  fflush(_coverage_fout);
  }
  if (outbuf) {
    {
    fprintf(_coverage_fout, "1194\n");
    fflush(_coverage_fout);
    }
    _TIFFfree(outbuf);
  } else {
    {
    fprintf(_coverage_fout, "1195\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1210\n");
  fflush(_coverage_fout);
  }
  return (1);
  {
  fprintf(_coverage_fout, "1211\n");
  fflush(_coverage_fout);
  }
  bad: 
  if (inbuf) {
    {
    fprintf(_coverage_fout, "1196\n");
    fflush(_coverage_fout);
    }
    _TIFFfree(inbuf);
  } else {
    {
    fprintf(_coverage_fout, "1197\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1212\n");
  fflush(_coverage_fout);
  }
  if (outbuf) {
    {
    fprintf(_coverage_fout, "1198\n");
    fflush(_coverage_fout);
    }
    _TIFFfree(outbuf);
  } else {
    {
    fprintf(_coverage_fout, "1199\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1213\n");
  fflush(_coverage_fout);
  }
  return (0);
}
}
static int cpSeparate2ContigByRow(TIFF *in , TIFF *out , uint32 imagelength ,
                                  uint32 imagewidth , tsample_t spp ) 
{ tdata_t inbuf ;
  tsize_t tmp ;
  tdata_t tmp___0 ;
  tdata_t outbuf ;
  tsize_t tmp___1 ;
  tdata_t tmp___2 ;
  register uint8 *inp ;
  register uint8 *outp ;
  register uint32 n ;
  uint32 row ;
  tsample_t s ;
  int tmp___3 ;
  uint8 *tmp___4 ;
  uint32 tmp___5 ;
  int tmp___6 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1250\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFScanlineSize(in);
  {
  fprintf(_coverage_fout, "1251\n");
  fflush(_coverage_fout);
  }
  tmp___0 = _TIFFmalloc(tmp);
  {
  fprintf(_coverage_fout, "1252\n");
  fflush(_coverage_fout);
  }
  inbuf = tmp___0;
  {
  fprintf(_coverage_fout, "1253\n");
  fflush(_coverage_fout);
  }
  tmp___1 = TIFFScanlineSize(out);
  {
  fprintf(_coverage_fout, "1254\n");
  fflush(_coverage_fout);
  }
  tmp___2 = _TIFFmalloc(tmp___1);
  {
  fprintf(_coverage_fout, "1255\n");
  fflush(_coverage_fout);
  }
  outbuf = tmp___2;
  {
  fprintf(_coverage_fout, "1256\n");
  fflush(_coverage_fout);
  }
  row = 0U;
  {
  fprintf(_coverage_fout, "1257\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "1236\n");
    fflush(_coverage_fout);
    }
    if (row < imagelength) {
      {
      fprintf(_coverage_fout, "1214\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "1237\n");
    fflush(_coverage_fout);
    }
    s = (unsigned short)0;
    {
    fprintf(_coverage_fout, "1238\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "1227\n");
      fflush(_coverage_fout);
      }
      if ((int )s < (int )spp) {
        {
        fprintf(_coverage_fout, "1215\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "1228\n");
      fflush(_coverage_fout);
      }
      tmp___3 = TIFFReadScanline(in, inbuf, row, s);
      {
      fprintf(_coverage_fout, "1229\n");
      fflush(_coverage_fout);
      }
      if (tmp___3 < 0) {
        {
        fprintf(_coverage_fout, "1217\n");
        fflush(_coverage_fout);
        }
        if (! ignore) {
          goto bad;
        } else {
          {
          fprintf(_coverage_fout, "1216\n");
          fflush(_coverage_fout);
          }

        }
      } else {
        {
        fprintf(_coverage_fout, "1218\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "1230\n");
      fflush(_coverage_fout);
      }
      inp = (uint8 *)inbuf;
      {
      fprintf(_coverage_fout, "1231\n");
      fflush(_coverage_fout);
      }
      outp = (uint8 *)outbuf + (int )s;
      {
      fprintf(_coverage_fout, "1232\n");
      fflush(_coverage_fout);
      }
      n = imagewidth;
      {
      fprintf(_coverage_fout, "1233\n");
      fflush(_coverage_fout);
      }
      while (1) {
        {
        fprintf(_coverage_fout, "1220\n");
        fflush(_coverage_fout);
        }
        tmp___5 = n;
        {
        fprintf(_coverage_fout, "1221\n");
        fflush(_coverage_fout);
        }
        n --;
        {
        fprintf(_coverage_fout, "1222\n");
        fflush(_coverage_fout);
        }
        if (tmp___5 > 0U) {
          {
          fprintf(_coverage_fout, "1219\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
        {
        fprintf(_coverage_fout, "1223\n");
        fflush(_coverage_fout);
        }
        tmp___4 = inp;
        {
        fprintf(_coverage_fout, "1224\n");
        fflush(_coverage_fout);
        }
        inp ++;
        {
        fprintf(_coverage_fout, "1225\n");
        fflush(_coverage_fout);
        }
        *outp = *tmp___4;
        {
        fprintf(_coverage_fout, "1226\n");
        fflush(_coverage_fout);
        }
        outp += (int )spp;
      }
      {
      fprintf(_coverage_fout, "1234\n");
      fflush(_coverage_fout);
      }
      s = (tsample_t )((int )s + 1);
    }
    {
    fprintf(_coverage_fout, "1239\n");
    fflush(_coverage_fout);
    }
    tmp___6 = TIFFWriteScanline(out, outbuf, row, (unsigned short)0);
    {
    fprintf(_coverage_fout, "1240\n");
    fflush(_coverage_fout);
    }
    if (tmp___6 < 0) {
      goto bad;
    } else {
      {
      fprintf(_coverage_fout, "1235\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "1241\n");
    fflush(_coverage_fout);
    }
    row ++;
  }
  {
  fprintf(_coverage_fout, "1258\n");
  fflush(_coverage_fout);
  }
  if (inbuf) {
    {
    fprintf(_coverage_fout, "1242\n");
    fflush(_coverage_fout);
    }
    _TIFFfree(inbuf);
  } else {
    {
    fprintf(_coverage_fout, "1243\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1259\n");
  fflush(_coverage_fout);
  }
  if (outbuf) {
    {
    fprintf(_coverage_fout, "1244\n");
    fflush(_coverage_fout);
    }
    _TIFFfree(outbuf);
  } else {
    {
    fprintf(_coverage_fout, "1245\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1260\n");
  fflush(_coverage_fout);
  }
  return (1);
  {
  fprintf(_coverage_fout, "1261\n");
  fflush(_coverage_fout);
  }
  bad: 
  if (inbuf) {
    {
    fprintf(_coverage_fout, "1246\n");
    fflush(_coverage_fout);
    }
    _TIFFfree(inbuf);
  } else {
    {
    fprintf(_coverage_fout, "1247\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1262\n");
  fflush(_coverage_fout);
  }
  if (outbuf) {
    {
    fprintf(_coverage_fout, "1248\n");
    fflush(_coverage_fout);
    }
    _TIFFfree(outbuf);
  } else {
    {
    fprintf(_coverage_fout, "1249\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1263\n");
  fflush(_coverage_fout);
  }
  return (0);
}
}
static void cpStripToTile(uint8 *out , uint8 *in , uint32 rows , uint32 cols ,
                          int outskew , int inskew ) 
{ uint32 j ;
  uint8 *tmp ;
  uint8 *tmp___0 ;
  uint32 tmp___1 ;
  uint32 tmp___2 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1281\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "1274\n");
    fflush(_coverage_fout);
    }
    tmp___2 = rows;
    {
    fprintf(_coverage_fout, "1275\n");
    fflush(_coverage_fout);
    }
    rows --;
    {
    fprintf(_coverage_fout, "1276\n");
    fflush(_coverage_fout);
    }
    if (tmp___2 > 0U) {
      {
      fprintf(_coverage_fout, "1264\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "1277\n");
    fflush(_coverage_fout);
    }
    j = cols;
    {
    fprintf(_coverage_fout, "1278\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "1266\n");
      fflush(_coverage_fout);
      }
      tmp___1 = j;
      {
      fprintf(_coverage_fout, "1267\n");
      fflush(_coverage_fout);
      }
      j --;
      {
      fprintf(_coverage_fout, "1268\n");
      fflush(_coverage_fout);
      }
      if (tmp___1 > 0U) {
        {
        fprintf(_coverage_fout, "1265\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "1269\n");
      fflush(_coverage_fout);
      }
      tmp = out;
      {
      fprintf(_coverage_fout, "1270\n");
      fflush(_coverage_fout);
      }
      out ++;
      {
      fprintf(_coverage_fout, "1271\n");
      fflush(_coverage_fout);
      }
      tmp___0 = in;
      {
      fprintf(_coverage_fout, "1272\n");
      fflush(_coverage_fout);
      }
      in ++;
      {
      fprintf(_coverage_fout, "1273\n");
      fflush(_coverage_fout);
      }
      *tmp = *tmp___0;
    }
    {
    fprintf(_coverage_fout, "1279\n");
    fflush(_coverage_fout);
    }
    out += outskew;
    {
    fprintf(_coverage_fout, "1280\n");
    fflush(_coverage_fout);
    }
    in += inskew;
  }
  {
  fprintf(_coverage_fout, "1282\n");
  fflush(_coverage_fout);
  }
  return;
}
}
static void cpContigBufToSeparateBuf(uint8 *out , uint8 *in , uint32 rows ,
                                     uint32 cols , int outskew , int inskew ,
                                     tsample_t spp , int bytes_per_sample ) 
{ uint32 j ;
  int n ;
  uint8 *tmp ;
  uint8 *tmp___0 ;
  int tmp___1 ;
  uint32 tmp___2 ;
  uint32 tmp___3 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1307\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "1300\n");
    fflush(_coverage_fout);
    }
    tmp___3 = rows;
    {
    fprintf(_coverage_fout, "1301\n");
    fflush(_coverage_fout);
    }
    rows --;
    {
    fprintf(_coverage_fout, "1302\n");
    fflush(_coverage_fout);
    }
    if (tmp___3 > 0U) {
      {
      fprintf(_coverage_fout, "1283\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "1303\n");
    fflush(_coverage_fout);
    }
    j = cols;
    {
    fprintf(_coverage_fout, "1304\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "1294\n");
      fflush(_coverage_fout);
      }
      tmp___2 = j;
      {
      fprintf(_coverage_fout, "1295\n");
      fflush(_coverage_fout);
      }
      j --;
      {
      fprintf(_coverage_fout, "1296\n");
      fflush(_coverage_fout);
      }
      if (tmp___2 > 0U) {
        {
        fprintf(_coverage_fout, "1284\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "1297\n");
      fflush(_coverage_fout);
      }
      n = bytes_per_sample;
      {
      fprintf(_coverage_fout, "1298\n");
      fflush(_coverage_fout);
      }
      while (1) {
        {
        fprintf(_coverage_fout, "1286\n");
        fflush(_coverage_fout);
        }
        tmp___1 = n;
        {
        fprintf(_coverage_fout, "1287\n");
        fflush(_coverage_fout);
        }
        n --;
        {
        fprintf(_coverage_fout, "1288\n");
        fflush(_coverage_fout);
        }
        if (tmp___1) {
          {
          fprintf(_coverage_fout, "1285\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
        {
        fprintf(_coverage_fout, "1289\n");
        fflush(_coverage_fout);
        }
        tmp = out;
        {
        fprintf(_coverage_fout, "1290\n");
        fflush(_coverage_fout);
        }
        out ++;
        {
        fprintf(_coverage_fout, "1291\n");
        fflush(_coverage_fout);
        }
        tmp___0 = in;
        {
        fprintf(_coverage_fout, "1292\n");
        fflush(_coverage_fout);
        }
        in ++;
        {
        fprintf(_coverage_fout, "1293\n");
        fflush(_coverage_fout);
        }
        *tmp = *tmp___0;
      }
      {
      fprintf(_coverage_fout, "1299\n");
      fflush(_coverage_fout);
      }
      in += ((int )spp - 1) * bytes_per_sample;
    }
    {
    fprintf(_coverage_fout, "1305\n");
    fflush(_coverage_fout);
    }
    out += outskew;
    {
    fprintf(_coverage_fout, "1306\n");
    fflush(_coverage_fout);
    }
    in += inskew;
  }
  {
  fprintf(_coverage_fout, "1308\n");
  fflush(_coverage_fout);
  }
  return;
}
}
static void cpSeparateBufToContigBuf(uint8 *out , uint8 *in , uint32 rows ,
                                     uint32 cols , int outskew , int inskew ,
                                     tsample_t spp , int bytes_per_sample ) 
{ uint32 j ;
  int n ;
  uint8 *tmp ;
  uint8 *tmp___0 ;
  int tmp___1 ;
  uint32 tmp___2 ;
  uint32 tmp___3 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1333\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "1326\n");
    fflush(_coverage_fout);
    }
    tmp___3 = rows;
    {
    fprintf(_coverage_fout, "1327\n");
    fflush(_coverage_fout);
    }
    rows --;
    {
    fprintf(_coverage_fout, "1328\n");
    fflush(_coverage_fout);
    }
    if (tmp___3 > 0U) {
      {
      fprintf(_coverage_fout, "1309\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "1329\n");
    fflush(_coverage_fout);
    }
    j = cols;
    {
    fprintf(_coverage_fout, "1330\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "1320\n");
      fflush(_coverage_fout);
      }
      tmp___2 = j;
      {
      fprintf(_coverage_fout, "1321\n");
      fflush(_coverage_fout);
      }
      j --;
      {
      fprintf(_coverage_fout, "1322\n");
      fflush(_coverage_fout);
      }
      if (tmp___2 > 0U) {
        {
        fprintf(_coverage_fout, "1310\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "1323\n");
      fflush(_coverage_fout);
      }
      n = bytes_per_sample;
      {
      fprintf(_coverage_fout, "1324\n");
      fflush(_coverage_fout);
      }
      while (1) {
        {
        fprintf(_coverage_fout, "1312\n");
        fflush(_coverage_fout);
        }
        tmp___1 = n;
        {
        fprintf(_coverage_fout, "1313\n");
        fflush(_coverage_fout);
        }
        n --;
        {
        fprintf(_coverage_fout, "1314\n");
        fflush(_coverage_fout);
        }
        if (tmp___1) {
          {
          fprintf(_coverage_fout, "1311\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
        {
        fprintf(_coverage_fout, "1315\n");
        fflush(_coverage_fout);
        }
        tmp = out;
        {
        fprintf(_coverage_fout, "1316\n");
        fflush(_coverage_fout);
        }
        out ++;
        {
        fprintf(_coverage_fout, "1317\n");
        fflush(_coverage_fout);
        }
        tmp___0 = in;
        {
        fprintf(_coverage_fout, "1318\n");
        fflush(_coverage_fout);
        }
        in ++;
        {
        fprintf(_coverage_fout, "1319\n");
        fflush(_coverage_fout);
        }
        *tmp = *tmp___0;
      }
      {
      fprintf(_coverage_fout, "1325\n");
      fflush(_coverage_fout);
      }
      out += ((int )spp - 1) * bytes_per_sample;
    }
    {
    fprintf(_coverage_fout, "1331\n");
    fflush(_coverage_fout);
    }
    out += outskew;
    {
    fprintf(_coverage_fout, "1332\n");
    fflush(_coverage_fout);
    }
    in += inskew;
  }
  {
  fprintf(_coverage_fout, "1334\n");
  fflush(_coverage_fout);
  }
  return;
}
}
static int cpImage(TIFF *in , TIFF *out ,
                   int (*fin)(TIFF * , uint8 * , uint32  , uint32  , tsample_t  ) ,
                   int (*fout)(TIFF * , uint8 * , uint32  , uint32  ,
                               tsample_t  ) , uint32 imagelength ,
                   uint32 imagewidth , tsample_t spp ) 
{ int status ;
  tdata_t buf ;
  tsize_t tmp ;
  tdata_t tmp___0 ;
  int tmp___1 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1341\n");
  fflush(_coverage_fout);
  }
  status = 0;
  {
  fprintf(_coverage_fout, "1342\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFRasterScanlineSize(in);
  {
  fprintf(_coverage_fout, "1343\n");
  fflush(_coverage_fout);
  }
  tmp___0 = _TIFFmalloc((int )((uint32 )tmp * imagelength));
  {
  fprintf(_coverage_fout, "1344\n");
  fflush(_coverage_fout);
  }
  buf = tmp___0;
  {
  fprintf(_coverage_fout, "1345\n");
  fflush(_coverage_fout);
  }
  if (buf) {
    {
    fprintf(_coverage_fout, "1337\n");
    fflush(_coverage_fout);
    }
    tmp___1 = (*fin)(in, (uint8 *)buf, imagelength, imagewidth, spp);
    {
    fprintf(_coverage_fout, "1338\n");
    fflush(_coverage_fout);
    }
    if (tmp___1) {
      {
      fprintf(_coverage_fout, "1335\n");
      fflush(_coverage_fout);
      }
      status = (*fout)(out, (uint8 *)buf, imagelength, imagewidth, spp);
    } else {
      {
      fprintf(_coverage_fout, "1336\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "1339\n");
    fflush(_coverage_fout);
    }
    _TIFFfree(buf);
  } else {
    {
    fprintf(_coverage_fout, "1340\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1346\n");
  fflush(_coverage_fout);
  }
  return (status);
}
}
static int readContigStripsIntoBuffer(TIFF *in , uint8 *buf ,
                                      uint32 imagelength , uint32 imagewidth ,
                                      tsample_t spp ) 
{ tsize_t scanlinesize ;
  tsize_t tmp ;
  uint8 *bufp ;
  uint32 row ;
  int tmp___0 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1357\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFScanlineSize(in);
  {
  fprintf(_coverage_fout, "1358\n");
  fflush(_coverage_fout);
  }
  scanlinesize = tmp;
  {
  fprintf(_coverage_fout, "1359\n");
  fflush(_coverage_fout);
  }
  bufp = buf;
  {
  fprintf(_coverage_fout, "1360\n");
  fflush(_coverage_fout);
  }
  row = 0U;
  {
  fprintf(_coverage_fout, "1361\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "1352\n");
    fflush(_coverage_fout);
    }
    if (row < imagelength) {
      {
      fprintf(_coverage_fout, "1347\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "1353\n");
    fflush(_coverage_fout);
    }
    tmp___0 = TIFFReadScanline(in, (void *)bufp, row, (unsigned short)0);
    {
    fprintf(_coverage_fout, "1354\n");
    fflush(_coverage_fout);
    }
    if (tmp___0 < 0) {
      {
      fprintf(_coverage_fout, "1350\n");
      fflush(_coverage_fout);
      }
      if (! ignore) {
        {
        fprintf(_coverage_fout, "1348\n");
        fflush(_coverage_fout);
        }
        return (0);
      } else {
        {
        fprintf(_coverage_fout, "1349\n");
        fflush(_coverage_fout);
        }

      }
    } else {
      {
      fprintf(_coverage_fout, "1351\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "1355\n");
    fflush(_coverage_fout);
    }
    bufp += scanlinesize;
    {
    fprintf(_coverage_fout, "1356\n");
    fflush(_coverage_fout);
    }
    row ++;
  }
  {
  fprintf(_coverage_fout, "1362\n");
  fflush(_coverage_fout);
  }
  return (1);
}
}
static int readSeparateStripsIntoBuffer(TIFF *in , uint8 *buf ,
                                        uint32 imagelength , uint32 imagewidth ,
                                        tsample_t spp ) 
{ int status ;
  tsize_t scanlinesize ;
  tsize_t tmp ;
  tdata_t scanline ;
  tdata_t tmp___0 ;
  uint8 *bufp ;
  uint32 row ;
  tsample_t s ;
  uint8 *bp ;
  tsize_t n ;
  uint8 *sbuf ;
  int tmp___1 ;
  uint8 *tmp___2 ;
  tsize_t tmp___3 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1398\n");
  fflush(_coverage_fout);
  }
  status = 1;
  {
  fprintf(_coverage_fout, "1399\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFScanlineSize(in);
  {
  fprintf(_coverage_fout, "1400\n");
  fflush(_coverage_fout);
  }
  scanlinesize = tmp;
  {
  fprintf(_coverage_fout, "1401\n");
  fflush(_coverage_fout);
  }
  tmp___0 = _TIFFmalloc(scanlinesize);
  {
  fprintf(_coverage_fout, "1402\n");
  fflush(_coverage_fout);
  }
  scanline = tmp___0;
  {
  fprintf(_coverage_fout, "1403\n");
  fflush(_coverage_fout);
  }
  if (! scanlinesize) {
    {
    fprintf(_coverage_fout, "1363\n");
    fflush(_coverage_fout);
    }
    return (0);
  } else {
    {
    fprintf(_coverage_fout, "1364\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1404\n");
  fflush(_coverage_fout);
  }
  if (scanline) {
    {
    fprintf(_coverage_fout, "1392\n");
    fflush(_coverage_fout);
    }
    bufp = buf;
    {
    fprintf(_coverage_fout, "1393\n");
    fflush(_coverage_fout);
    }
    row = 0U;
    {
    fprintf(_coverage_fout, "1394\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "1387\n");
      fflush(_coverage_fout);
      }
      if (row < imagelength) {
        {
        fprintf(_coverage_fout, "1365\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "1388\n");
      fflush(_coverage_fout);
      }
      s = (unsigned short)0;
      {
      fprintf(_coverage_fout, "1389\n");
      fflush(_coverage_fout);
      }
      while (1) {
        {
        fprintf(_coverage_fout, "1379\n");
        fflush(_coverage_fout);
        }
        if ((int )s < (int )spp) {
          {
          fprintf(_coverage_fout, "1366\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
        {
        fprintf(_coverage_fout, "1380\n");
        fflush(_coverage_fout);
        }
        bp = bufp + (int )s;
        {
        fprintf(_coverage_fout, "1381\n");
        fflush(_coverage_fout);
        }
        n = scanlinesize;
        {
        fprintf(_coverage_fout, "1382\n");
        fflush(_coverage_fout);
        }
        sbuf = (uint8 *)scanline;
        {
        fprintf(_coverage_fout, "1383\n");
        fflush(_coverage_fout);
        }
        tmp___1 = TIFFReadScanline(in, scanline, row, s);
        {
        fprintf(_coverage_fout, "1384\n");
        fflush(_coverage_fout);
        }
        if (tmp___1 < 0) {
          {
          fprintf(_coverage_fout, "1369\n");
          fflush(_coverage_fout);
          }
          if (! ignore) {
            {
            fprintf(_coverage_fout, "1367\n");
            fflush(_coverage_fout);
            }
            status = 0;
            goto done;
          } else {
            {
            fprintf(_coverage_fout, "1368\n");
            fflush(_coverage_fout);
            }

          }
        } else {
          {
          fprintf(_coverage_fout, "1370\n");
          fflush(_coverage_fout);
          }

        }
        {
        fprintf(_coverage_fout, "1385\n");
        fflush(_coverage_fout);
        }
        while (1) {
          {
          fprintf(_coverage_fout, "1372\n");
          fflush(_coverage_fout);
          }
          tmp___3 = n;
          {
          fprintf(_coverage_fout, "1373\n");
          fflush(_coverage_fout);
          }
          n --;
          {
          fprintf(_coverage_fout, "1374\n");
          fflush(_coverage_fout);
          }
          if (tmp___3 > 0) {
            {
            fprintf(_coverage_fout, "1371\n");
            fflush(_coverage_fout);
            }

          } else {
            break;
          }
          {
          fprintf(_coverage_fout, "1375\n");
          fflush(_coverage_fout);
          }
          tmp___2 = sbuf;
          {
          fprintf(_coverage_fout, "1376\n");
          fflush(_coverage_fout);
          }
          sbuf ++;
          {
          fprintf(_coverage_fout, "1377\n");
          fflush(_coverage_fout);
          }
          *bp = *tmp___2;
          {
          fprintf(_coverage_fout, "1378\n");
          fflush(_coverage_fout);
          }
          bp += (int )spp;
        }
        {
        fprintf(_coverage_fout, "1386\n");
        fflush(_coverage_fout);
        }
        s = (tsample_t )((int )s + 1);
      }
      {
      fprintf(_coverage_fout, "1390\n");
      fflush(_coverage_fout);
      }
      bufp += scanlinesize * (tsize_t )spp;
      {
      fprintf(_coverage_fout, "1391\n");
      fflush(_coverage_fout);
      }
      row ++;
    }
    {
    fprintf(_coverage_fout, "1395\n");
    fflush(_coverage_fout);
    }
    done: 
    _TIFFfree(scanline);
    {
    fprintf(_coverage_fout, "1396\n");
    fflush(_coverage_fout);
    }
    return (status);
  } else {
    {
    fprintf(_coverage_fout, "1397\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1405\n");
  fflush(_coverage_fout);
  }
  return (0);
}
}
static int readContigTilesIntoBuffer(TIFF *in , uint8 *buf ,
                                     uint32 imagelength , uint32 imagewidth ,
                                     tsample_t spp ) 
{ int status ;
  tdata_t tilebuf ;
  tsize_t tmp ;
  tdata_t tmp___0 ;
  uint32 imagew ;
  tsize_t tmp___1 ;
  uint32 tilew ;
  tsize_t tmp___2 ;
  int iskew ;
  uint8 *bufp ;
  uint32 tw ;
  uint32 tl ;
  uint32 row ;
  uint32 nrow ;
  uint32 tmp___3 ;
  uint32 colb ;
  uint32 col ;
  tsize_t tmp___4 ;
  uint32 width ;
  uint32 oskew ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1434\n");
  fflush(_coverage_fout);
  }
  status = 1;
  {
  fprintf(_coverage_fout, "1435\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFTileSize(in);
  {
  fprintf(_coverage_fout, "1436\n");
  fflush(_coverage_fout);
  }
  tmp___0 = _TIFFmalloc(tmp);
  {
  fprintf(_coverage_fout, "1437\n");
  fflush(_coverage_fout);
  }
  tilebuf = tmp___0;
  {
  fprintf(_coverage_fout, "1438\n");
  fflush(_coverage_fout);
  }
  tmp___1 = TIFFScanlineSize(in);
  {
  fprintf(_coverage_fout, "1439\n");
  fflush(_coverage_fout);
  }
  imagew = (uint32 )tmp___1;
  {
  fprintf(_coverage_fout, "1440\n");
  fflush(_coverage_fout);
  }
  tmp___2 = TIFFTileRowSize(in);
  {
  fprintf(_coverage_fout, "1441\n");
  fflush(_coverage_fout);
  }
  tilew = (uint32 )tmp___2;
  {
  fprintf(_coverage_fout, "1442\n");
  fflush(_coverage_fout);
  }
  iskew = (int )(imagew - tilew);
  {
  fprintf(_coverage_fout, "1443\n");
  fflush(_coverage_fout);
  }
  bufp = buf;
  {
  fprintf(_coverage_fout, "1444\n");
  fflush(_coverage_fout);
  }
  if ((unsigned int )tilebuf == (unsigned int )((tdata_t )0)) {
    {
    fprintf(_coverage_fout, "1406\n");
    fflush(_coverage_fout);
    }
    return (0);
  } else {
    {
    fprintf(_coverage_fout, "1407\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1445\n");
  fflush(_coverage_fout);
  }
  TIFFGetField(in, 322U, & tw);
  {
  fprintf(_coverage_fout, "1446\n");
  fflush(_coverage_fout);
  }
  TIFFGetField(in, 323U, & tl);
  {
  fprintf(_coverage_fout, "1447\n");
  fflush(_coverage_fout);
  }
  row = 0U;
  {
  fprintf(_coverage_fout, "1448\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "1426\n");
    fflush(_coverage_fout);
    }
    if (row < imagelength) {
      {
      fprintf(_coverage_fout, "1408\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "1427\n");
    fflush(_coverage_fout);
    }
    if (row + tl > imagelength) {
      {
      fprintf(_coverage_fout, "1409\n");
      fflush(_coverage_fout);
      }
      tmp___3 = imagelength - row;
    } else {
      {
      fprintf(_coverage_fout, "1410\n");
      fflush(_coverage_fout);
      }
      tmp___3 = tl;
    }
    {
    fprintf(_coverage_fout, "1428\n");
    fflush(_coverage_fout);
    }
    nrow = tmp___3;
    {
    fprintf(_coverage_fout, "1429\n");
    fflush(_coverage_fout);
    }
    colb = (uint32 )0;
    {
    fprintf(_coverage_fout, "1430\n");
    fflush(_coverage_fout);
    }
    col = 0U;
    {
    fprintf(_coverage_fout, "1431\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "1420\n");
      fflush(_coverage_fout);
      }
      if (col < imagewidth) {
        {
        fprintf(_coverage_fout, "1411\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "1421\n");
      fflush(_coverage_fout);
      }
      tmp___4 = TIFFReadTile(in, tilebuf, col, row, 0U, (unsigned short)0);
      {
      fprintf(_coverage_fout, "1422\n");
      fflush(_coverage_fout);
      }
      if (tmp___4 < 0) {
        {
        fprintf(_coverage_fout, "1414\n");
        fflush(_coverage_fout);
        }
        if (! ignore) {
          {
          fprintf(_coverage_fout, "1412\n");
          fflush(_coverage_fout);
          }
          status = 0;
          goto done;
        } else {
          {
          fprintf(_coverage_fout, "1413\n");
          fflush(_coverage_fout);
          }

        }
      } else {
        {
        fprintf(_coverage_fout, "1415\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "1423\n");
      fflush(_coverage_fout);
      }
      if (colb + tilew > imagew) {
        {
        fprintf(_coverage_fout, "1416\n");
        fflush(_coverage_fout);
        }
        width = imagew - colb;
        {
        fprintf(_coverage_fout, "1417\n");
        fflush(_coverage_fout);
        }
        oskew = tilew - width;
        {
        fprintf(_coverage_fout, "1418\n");
        fflush(_coverage_fout);
        }
        cpStripToTile(bufp + colb, (uint8 *)tilebuf, nrow, width,
                      (int )(oskew + (uint32 )iskew), (int )oskew);
      } else {
        {
        fprintf(_coverage_fout, "1419\n");
        fflush(_coverage_fout);
        }
        cpStripToTile(bufp + colb, (uint8 *)tilebuf, nrow, tilew, iskew, 0);
      }
      {
      fprintf(_coverage_fout, "1424\n");
      fflush(_coverage_fout);
      }
      colb += tilew;
      {
      fprintf(_coverage_fout, "1425\n");
      fflush(_coverage_fout);
      }
      col += tw;
    }
    {
    fprintf(_coverage_fout, "1432\n");
    fflush(_coverage_fout);
    }
    bufp += imagew * nrow;
    {
    fprintf(_coverage_fout, "1433\n");
    fflush(_coverage_fout);
    }
    row += tl;
  }
  {
  fprintf(_coverage_fout, "1449\n");
  fflush(_coverage_fout);
  }
  done: 
  _TIFFfree(tilebuf);
  {
  fprintf(_coverage_fout, "1450\n");
  fflush(_coverage_fout);
  }
  return (status);
}
}
static int readSeparateTilesIntoBuffer(TIFF *in , uint8 *buf ,
                                       uint32 imagelength , uint32 imagewidth ,
                                       tsample_t spp ) 
{ int status ;
  uint32 imagew ;
  tsize_t tmp ;
  uint32 tilew ;
  tsize_t tmp___0 ;
  int iskew ;
  tdata_t tilebuf ;
  tsize_t tmp___1 ;
  tdata_t tmp___2 ;
  uint8 *bufp ;
  uint32 tw ;
  uint32 tl ;
  uint32 row ;
  uint16 bps ;
  uint16 bytes_per_sample ;
  uint32 nrow ;
  uint32 tmp___3 ;
  uint32 colb ;
  uint32 col ;
  tsample_t s ;
  tsize_t tmp___4 ;
  uint32 width ;
  int oskew ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1486\n");
  fflush(_coverage_fout);
  }
  status = 1;
  {
  fprintf(_coverage_fout, "1487\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFRasterScanlineSize(in);
  {
  fprintf(_coverage_fout, "1488\n");
  fflush(_coverage_fout);
  }
  imagew = (uint32 )tmp;
  {
  fprintf(_coverage_fout, "1489\n");
  fflush(_coverage_fout);
  }
  tmp___0 = TIFFTileRowSize(in);
  {
  fprintf(_coverage_fout, "1490\n");
  fflush(_coverage_fout);
  }
  tilew = (uint32 )tmp___0;
  {
  fprintf(_coverage_fout, "1491\n");
  fflush(_coverage_fout);
  }
  iskew = (int )(imagew - tilew * (uint32 )spp);
  {
  fprintf(_coverage_fout, "1492\n");
  fflush(_coverage_fout);
  }
  tmp___1 = TIFFTileSize(in);
  {
  fprintf(_coverage_fout, "1493\n");
  fflush(_coverage_fout);
  }
  tmp___2 = _TIFFmalloc(tmp___1);
  {
  fprintf(_coverage_fout, "1494\n");
  fflush(_coverage_fout);
  }
  tilebuf = tmp___2;
  {
  fprintf(_coverage_fout, "1495\n");
  fflush(_coverage_fout);
  }
  bufp = buf;
  {
  fprintf(_coverage_fout, "1496\n");
  fflush(_coverage_fout);
  }
  if ((unsigned int )tilebuf == (unsigned int )((tdata_t )0)) {
    {
    fprintf(_coverage_fout, "1451\n");
    fflush(_coverage_fout);
    }
    return (0);
  } else {
    {
    fprintf(_coverage_fout, "1452\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1497\n");
  fflush(_coverage_fout);
  }
  TIFFGetField(in, 322U, & tw);
  {
  fprintf(_coverage_fout, "1498\n");
  fflush(_coverage_fout);
  }
  TIFFGetField(in, 323U, & tl);
  {
  fprintf(_coverage_fout, "1499\n");
  fflush(_coverage_fout);
  }
  TIFFGetField(in, 258U, & bps);
  {
  fprintf(_coverage_fout, "1500\n");
  fflush(_coverage_fout);
  }
  if ((int )bps % 8 == 0) {
    {
    fprintf(_coverage_fout, "1453\n");
    fflush(_coverage_fout);
    }

  } else {
    {
    fprintf(_coverage_fout, "1454\n");
    fflush(_coverage_fout);
    }
    __assert_fail("bps % 8 == 0", "tiffcp.c", 1163U,
                  "readSeparateTilesIntoBuffer");
  }
  {
  fprintf(_coverage_fout, "1501\n");
  fflush(_coverage_fout);
  }
  bytes_per_sample = (unsigned short )((int )bps / 8);
  {
  fprintf(_coverage_fout, "1502\n");
  fflush(_coverage_fout);
  }
  row = 0U;
  {
  fprintf(_coverage_fout, "1503\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "1478\n");
    fflush(_coverage_fout);
    }
    if (row < imagelength) {
      {
      fprintf(_coverage_fout, "1455\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "1479\n");
    fflush(_coverage_fout);
    }
    if (row + tl > imagelength) {
      {
      fprintf(_coverage_fout, "1456\n");
      fflush(_coverage_fout);
      }
      tmp___3 = imagelength - row;
    } else {
      {
      fprintf(_coverage_fout, "1457\n");
      fflush(_coverage_fout);
      }
      tmp___3 = tl;
    }
    {
    fprintf(_coverage_fout, "1480\n");
    fflush(_coverage_fout);
    }
    nrow = tmp___3;
    {
    fprintf(_coverage_fout, "1481\n");
    fflush(_coverage_fout);
    }
    colb = (uint32 )0;
    {
    fprintf(_coverage_fout, "1482\n");
    fflush(_coverage_fout);
    }
    col = 0U;
    {
    fprintf(_coverage_fout, "1483\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "1473\n");
      fflush(_coverage_fout);
      }
      if (col < imagewidth) {
        {
        fprintf(_coverage_fout, "1458\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "1474\n");
      fflush(_coverage_fout);
      }
      s = (unsigned short)0;
      {
      fprintf(_coverage_fout, "1475\n");
      fflush(_coverage_fout);
      }
      while (1) {
        {
        fprintf(_coverage_fout, "1468\n");
        fflush(_coverage_fout);
        }
        if ((int )s < (int )spp) {
          {
          fprintf(_coverage_fout, "1459\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
        {
        fprintf(_coverage_fout, "1469\n");
        fflush(_coverage_fout);
        }
        tmp___4 = TIFFReadTile(in, tilebuf, col, row, 0U, s);
        {
        fprintf(_coverage_fout, "1470\n");
        fflush(_coverage_fout);
        }
        if (tmp___4 < 0) {
          {
          fprintf(_coverage_fout, "1462\n");
          fflush(_coverage_fout);
          }
          if (! ignore) {
            {
            fprintf(_coverage_fout, "1460\n");
            fflush(_coverage_fout);
            }
            status = 0;
            goto done;
          } else {
            {
            fprintf(_coverage_fout, "1461\n");
            fflush(_coverage_fout);
            }

          }
        } else {
          {
          fprintf(_coverage_fout, "1463\n");
          fflush(_coverage_fout);
          }

        }
        {
        fprintf(_coverage_fout, "1471\n");
        fflush(_coverage_fout);
        }
        if (colb + tilew * (uint32 )spp > imagew) {
          {
          fprintf(_coverage_fout, "1464\n");
          fflush(_coverage_fout);
          }
          width = imagew - colb;
          {
          fprintf(_coverage_fout, "1465\n");
          fflush(_coverage_fout);
          }
          oskew = (int )(tilew * (uint32 )spp - width);
          {
          fprintf(_coverage_fout, "1466\n");
          fflush(_coverage_fout);
          }
          cpSeparateBufToContigBuf((bufp + colb) + (int )s * (int )bytes_per_sample,
                                   (uint8 *)tilebuf, nrow,
                                   width / (uint32 )((int )spp * (int )bytes_per_sample),
                                   oskew + iskew, oskew / (int )spp, spp,
                                   (int )bytes_per_sample);
        } else {
          {
          fprintf(_coverage_fout, "1467\n");
          fflush(_coverage_fout);
          }
          cpSeparateBufToContigBuf((bufp + colb) + (int )s * (int )bytes_per_sample,
                                   (uint8 *)tilebuf, nrow, tw, iskew, 0, spp,
                                   (int )bytes_per_sample);
        }
        {
        fprintf(_coverage_fout, "1472\n");
        fflush(_coverage_fout);
        }
        s = (tsample_t )((int )s + 1);
      }
      {
      fprintf(_coverage_fout, "1476\n");
      fflush(_coverage_fout);
      }
      colb += tilew * (uint32 )spp;
      {
      fprintf(_coverage_fout, "1477\n");
      fflush(_coverage_fout);
      }
      col += tw;
    }
    {
    fprintf(_coverage_fout, "1484\n");
    fflush(_coverage_fout);
    }
    bufp += imagew * nrow;
    {
    fprintf(_coverage_fout, "1485\n");
    fflush(_coverage_fout);
    }
    row += tl;
  }
  {
  fprintf(_coverage_fout, "1504\n");
  fflush(_coverage_fout);
  }
  done: 
  _TIFFfree(tilebuf);
  {
  fprintf(_coverage_fout, "1505\n");
  fflush(_coverage_fout);
  }
  return (status);
}
}
static int writeBufferToContigStrips(TIFF *out , uint8 *buf ,
                                     uint32 imagelength , uint32 imagewidth ,
                                     tsample_t spp ) 
{ uint32 row ;
  uint32 rowsperstrip___0 ;
  tstrip_t strip ;
  uint32 nrows ;
  uint32 tmp ;
  tsize_t stripsize ;
  tsize_t tmp___0 ;
  tstrip_t tmp___1 ;
  tsize_t tmp___2 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1522\n");
  fflush(_coverage_fout);
  }
  strip = (tstrip_t )0;
  {
  fprintf(_coverage_fout, "1523\n");
  fflush(_coverage_fout);
  }
  TIFFGetFieldDefaulted(out, 278U, & rowsperstrip___0);
  {
  fprintf(_coverage_fout, "1524\n");
  fflush(_coverage_fout);
  }
  row = 0U;
  {
  fprintf(_coverage_fout, "1525\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "1511\n");
    fflush(_coverage_fout);
    }
    if (row < imagelength) {
      {
      fprintf(_coverage_fout, "1506\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "1512\n");
    fflush(_coverage_fout);
    }
    if (row + rowsperstrip___0 > imagelength) {
      {
      fprintf(_coverage_fout, "1507\n");
      fflush(_coverage_fout);
      }
      tmp = imagelength - row;
    } else {
      {
      fprintf(_coverage_fout, "1508\n");
      fflush(_coverage_fout);
      }
      tmp = rowsperstrip___0;
    }
    {
    fprintf(_coverage_fout, "1513\n");
    fflush(_coverage_fout);
    }
    nrows = tmp;
    {
    fprintf(_coverage_fout, "1514\n");
    fflush(_coverage_fout);
    }
    tmp___0 = TIFFVStripSize(out, nrows);
    {
    fprintf(_coverage_fout, "1515\n");
    fflush(_coverage_fout);
    }
    stripsize = tmp___0;
    {
    fprintf(_coverage_fout, "1516\n");
    fflush(_coverage_fout);
    }
    tmp___1 = strip;
    {
    fprintf(_coverage_fout, "1517\n");
    fflush(_coverage_fout);
    }
    strip ++;
    {
    fprintf(_coverage_fout, "1518\n");
    fflush(_coverage_fout);
    }
    tmp___2 = TIFFWriteEncodedStrip(out, tmp___1, (void *)buf, stripsize);
    {
    fprintf(_coverage_fout, "1519\n");
    fflush(_coverage_fout);
    }
    if (tmp___2 < 0) {
      {
      fprintf(_coverage_fout, "1509\n");
      fflush(_coverage_fout);
      }
      return (0);
    } else {
      {
      fprintf(_coverage_fout, "1510\n");
      fflush(_coverage_fout);
      }

    }
    {
    fprintf(_coverage_fout, "1520\n");
    fflush(_coverage_fout);
    }
    buf += stripsize;
    {
    fprintf(_coverage_fout, "1521\n");
    fflush(_coverage_fout);
    }
    row += rowsperstrip___0;
  }
  {
  fprintf(_coverage_fout, "1526\n");
  fflush(_coverage_fout);
  }
  return (1);
}
}
static int writeBufferToSeparateStrips(TIFF *out , uint8 *buf ,
                                       uint32 imagelength , uint32 imagewidth ,
                                       tsample_t spp ) 
{ uint32 rowsize ;
  uint32 rowsperstrip___0 ;
  tdata_t obuf ;
  tsize_t tmp ;
  tdata_t tmp___0 ;
  tstrip_t strip ;
  tsample_t s ;
  uint32 row ;
  uint32 nrows ;
  uint32 tmp___1 ;
  tsize_t stripsize ;
  tsize_t tmp___2 ;
  tstrip_t tmp___3 ;
  tsize_t tmp___4 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1551\n");
  fflush(_coverage_fout);
  }
  rowsize = imagewidth * (uint32 )spp;
  {
  fprintf(_coverage_fout, "1552\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFStripSize(out);
  {
  fprintf(_coverage_fout, "1553\n");
  fflush(_coverage_fout);
  }
  tmp___0 = _TIFFmalloc(tmp);
  {
  fprintf(_coverage_fout, "1554\n");
  fflush(_coverage_fout);
  }
  obuf = tmp___0;
  {
  fprintf(_coverage_fout, "1555\n");
  fflush(_coverage_fout);
  }
  strip = (tstrip_t )0;
  {
  fprintf(_coverage_fout, "1556\n");
  fflush(_coverage_fout);
  }
  if ((unsigned int )obuf == (unsigned int )((void *)0)) {
    {
    fprintf(_coverage_fout, "1527\n");
    fflush(_coverage_fout);
    }
    return (0);
  } else {
    {
    fprintf(_coverage_fout, "1528\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1557\n");
  fflush(_coverage_fout);
  }
  TIFFGetFieldDefaulted(out, 278U, & rowsperstrip___0);
  {
  fprintf(_coverage_fout, "1558\n");
  fflush(_coverage_fout);
  }
  s = (unsigned short)0;
  {
  fprintf(_coverage_fout, "1559\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "1547\n");
    fflush(_coverage_fout);
    }
    if ((int )s < (int )spp) {
      {
      fprintf(_coverage_fout, "1529\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "1548\n");
    fflush(_coverage_fout);
    }
    row = 0U;
    {
    fprintf(_coverage_fout, "1549\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "1536\n");
      fflush(_coverage_fout);
      }
      if (row < imagelength) {
        {
        fprintf(_coverage_fout, "1530\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "1537\n");
      fflush(_coverage_fout);
      }
      if (row + rowsperstrip___0 > imagelength) {
        {
        fprintf(_coverage_fout, "1531\n");
        fflush(_coverage_fout);
        }
        tmp___1 = imagelength - row;
      } else {
        {
        fprintf(_coverage_fout, "1532\n");
        fflush(_coverage_fout);
        }
        tmp___1 = rowsperstrip___0;
      }
      {
      fprintf(_coverage_fout, "1538\n");
      fflush(_coverage_fout);
      }
      nrows = tmp___1;
      {
      fprintf(_coverage_fout, "1539\n");
      fflush(_coverage_fout);
      }
      tmp___2 = TIFFVStripSize(out, nrows);
      {
      fprintf(_coverage_fout, "1540\n");
      fflush(_coverage_fout);
      }
      stripsize = tmp___2;
      {
      fprintf(_coverage_fout, "1541\n");
      fflush(_coverage_fout);
      }
      cpContigBufToSeparateBuf((uint8 *)obuf, (buf + row * rowsize) + (int )s,
                               nrows, imagewidth, 0, 0, spp, 1);
      {
      fprintf(_coverage_fout, "1542\n");
      fflush(_coverage_fout);
      }
      tmp___3 = strip;
      {
      fprintf(_coverage_fout, "1543\n");
      fflush(_coverage_fout);
      }
      strip ++;
      {
      fprintf(_coverage_fout, "1544\n");
      fflush(_coverage_fout);
      }
      tmp___4 = TIFFWriteEncodedStrip(out, tmp___3, obuf, stripsize);
      {
      fprintf(_coverage_fout, "1545\n");
      fflush(_coverage_fout);
      }
      if (tmp___4 < 0) {
        {
        fprintf(_coverage_fout, "1533\n");
        fflush(_coverage_fout);
        }
        _TIFFfree(obuf);
        {
        fprintf(_coverage_fout, "1534\n");
        fflush(_coverage_fout);
        }
        return (0);
      } else {
        {
        fprintf(_coverage_fout, "1535\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "1546\n");
      fflush(_coverage_fout);
      }
      row += rowsperstrip___0;
    }
    {
    fprintf(_coverage_fout, "1550\n");
    fflush(_coverage_fout);
    }
    s = (tsample_t )((int )s + 1);
  }
  {
  fprintf(_coverage_fout, "1560\n");
  fflush(_coverage_fout);
  }
  _TIFFfree(obuf);
  {
  fprintf(_coverage_fout, "1561\n");
  fflush(_coverage_fout);
  }
  return (1);
}
}
static int writeBufferToContigTiles(TIFF *out , uint8 *buf ,
                                    uint32 imagelength , uint32 imagewidth ,
                                    tsample_t spp ) 
{ uint32 imagew ;
  tsize_t tmp ;
  uint32 tilew ;
  tsize_t tmp___0 ;
  int iskew ;
  tdata_t obuf ;
  tsize_t tmp___1 ;
  tdata_t tmp___2 ;
  uint8 *bufp ;
  uint32 tl ;
  uint32 tw ;
  uint32 row ;
  uint32 nrow ;
  uint32 tmp___3 ;
  uint32 colb ;
  uint32 col ;
  uint32 width ;
  int oskew ;
  tsize_t tmp___4 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1589\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFScanlineSize(out);
  {
  fprintf(_coverage_fout, "1590\n");
  fflush(_coverage_fout);
  }
  imagew = (uint32 )tmp;
  {
  fprintf(_coverage_fout, "1591\n");
  fflush(_coverage_fout);
  }
  tmp___0 = TIFFTileRowSize(out);
  {
  fprintf(_coverage_fout, "1592\n");
  fflush(_coverage_fout);
  }
  tilew = (uint32 )tmp___0;
  {
  fprintf(_coverage_fout, "1593\n");
  fflush(_coverage_fout);
  }
  iskew = (int )(imagew - tilew);
  {
  fprintf(_coverage_fout, "1594\n");
  fflush(_coverage_fout);
  }
  tmp___1 = TIFFTileSize(out);
  {
  fprintf(_coverage_fout, "1595\n");
  fflush(_coverage_fout);
  }
  tmp___2 = _TIFFmalloc(tmp___1);
  {
  fprintf(_coverage_fout, "1596\n");
  fflush(_coverage_fout);
  }
  obuf = tmp___2;
  {
  fprintf(_coverage_fout, "1597\n");
  fflush(_coverage_fout);
  }
  bufp = buf;
  {
  fprintf(_coverage_fout, "1598\n");
  fflush(_coverage_fout);
  }
  if ((unsigned int )obuf == (unsigned int )((void *)0)) {
    {
    fprintf(_coverage_fout, "1562\n");
    fflush(_coverage_fout);
    }
    return (0);
  } else {
    {
    fprintf(_coverage_fout, "1563\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1599\n");
  fflush(_coverage_fout);
  }
  TIFFGetField(out, 323U, & tl);
  {
  fprintf(_coverage_fout, "1600\n");
  fflush(_coverage_fout);
  }
  TIFFGetField(out, 322U, & tw);
  {
  fprintf(_coverage_fout, "1601\n");
  fflush(_coverage_fout);
  }
  row = 0U;
  {
  fprintf(_coverage_fout, "1602\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "1581\n");
    fflush(_coverage_fout);
    }
    if (row < imagelength) {
      {
      fprintf(_coverage_fout, "1564\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "1582\n");
    fflush(_coverage_fout);
    }
    if (row + tl > imagelength) {
      {
      fprintf(_coverage_fout, "1565\n");
      fflush(_coverage_fout);
      }
      tmp___3 = imagelength - row;
    } else {
      {
      fprintf(_coverage_fout, "1566\n");
      fflush(_coverage_fout);
      }
      tmp___3 = tl;
    }
    {
    fprintf(_coverage_fout, "1583\n");
    fflush(_coverage_fout);
    }
    nrow = tmp___3;
    {
    fprintf(_coverage_fout, "1584\n");
    fflush(_coverage_fout);
    }
    colb = (uint32 )0;
    {
    fprintf(_coverage_fout, "1585\n");
    fflush(_coverage_fout);
    }
    col = 0U;
    {
    fprintf(_coverage_fout, "1586\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "1575\n");
      fflush(_coverage_fout);
      }
      if (col < imagewidth) {
        {
        fprintf(_coverage_fout, "1567\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "1576\n");
      fflush(_coverage_fout);
      }
      if (colb + tilew > imagew) {
        {
        fprintf(_coverage_fout, "1568\n");
        fflush(_coverage_fout);
        }
        width = imagew - colb;
        {
        fprintf(_coverage_fout, "1569\n");
        fflush(_coverage_fout);
        }
        oskew = (int )(tilew - width);
        {
        fprintf(_coverage_fout, "1570\n");
        fflush(_coverage_fout);
        }
        cpStripToTile((uint8 *)obuf, bufp + colb, nrow, width, oskew,
                      oskew + iskew);
      } else {
        {
        fprintf(_coverage_fout, "1571\n");
        fflush(_coverage_fout);
        }
        cpStripToTile((uint8 *)obuf, bufp + colb, nrow, tilew, 0, iskew);
      }
      {
      fprintf(_coverage_fout, "1577\n");
      fflush(_coverage_fout);
      }
      tmp___4 = TIFFWriteTile(out, obuf, col, row, 0U, (unsigned short)0);
      {
      fprintf(_coverage_fout, "1578\n");
      fflush(_coverage_fout);
      }
      if (tmp___4 < 0) {
        {
        fprintf(_coverage_fout, "1572\n");
        fflush(_coverage_fout);
        }
        _TIFFfree(obuf);
        {
        fprintf(_coverage_fout, "1573\n");
        fflush(_coverage_fout);
        }
        return (0);
      } else {
        {
        fprintf(_coverage_fout, "1574\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "1579\n");
      fflush(_coverage_fout);
      }
      colb += tilew;
      {
      fprintf(_coverage_fout, "1580\n");
      fflush(_coverage_fout);
      }
      col += tw;
    }
    {
    fprintf(_coverage_fout, "1587\n");
    fflush(_coverage_fout);
    }
    bufp += nrow * imagew;
    {
    fprintf(_coverage_fout, "1588\n");
    fflush(_coverage_fout);
    }
    row += tilelength;
  }
  {
  fprintf(_coverage_fout, "1603\n");
  fflush(_coverage_fout);
  }
  _TIFFfree(obuf);
  {
  fprintf(_coverage_fout, "1604\n");
  fflush(_coverage_fout);
  }
  return (1);
}
}
static int writeBufferToSeparateTiles(TIFF *out , uint8 *buf ,
                                      uint32 imagelength , uint32 imagewidth ,
                                      tsample_t spp ) 
{ uint32 imagew ;
  tsize_t tmp ;
  tsize_t tilew ;
  tsize_t tmp___0 ;
  uint32 iimagew ;
  tsize_t tmp___1 ;
  int iskew ;
  tdata_t obuf ;
  tsize_t tmp___2 ;
  tdata_t tmp___3 ;
  uint8 *bufp ;
  uint32 tl ;
  uint32 tw ;
  uint32 row ;
  uint16 bps ;
  uint16 bytes_per_sample ;
  uint32 nrow ;
  uint32 tmp___4 ;
  uint32 colb ;
  uint32 col ;
  tsample_t s ;
  uint32 width ;
  int oskew ;
  tsize_t tmp___5 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1639\n");
  fflush(_coverage_fout);
  }
  tmp = TIFFScanlineSize(out);
  {
  fprintf(_coverage_fout, "1640\n");
  fflush(_coverage_fout);
  }
  imagew = (uint32 )tmp;
  {
  fprintf(_coverage_fout, "1641\n");
  fflush(_coverage_fout);
  }
  tmp___0 = TIFFTileRowSize(out);
  {
  fprintf(_coverage_fout, "1642\n");
  fflush(_coverage_fout);
  }
  tilew = tmp___0;
  {
  fprintf(_coverage_fout, "1643\n");
  fflush(_coverage_fout);
  }
  tmp___1 = TIFFRasterScanlineSize(out);
  {
  fprintf(_coverage_fout, "1644\n");
  fflush(_coverage_fout);
  }
  iimagew = (uint32 )tmp___1;
  {
  fprintf(_coverage_fout, "1645\n");
  fflush(_coverage_fout);
  }
  iskew = (int )(iimagew - (uint32 )(tilew * (tsize_t )spp));
  {
  fprintf(_coverage_fout, "1646\n");
  fflush(_coverage_fout);
  }
  tmp___2 = TIFFTileSize(out);
  {
  fprintf(_coverage_fout, "1647\n");
  fflush(_coverage_fout);
  }
  tmp___3 = _TIFFmalloc(tmp___2);
  {
  fprintf(_coverage_fout, "1648\n");
  fflush(_coverage_fout);
  }
  obuf = tmp___3;
  {
  fprintf(_coverage_fout, "1649\n");
  fflush(_coverage_fout);
  }
  bufp = buf;
  {
  fprintf(_coverage_fout, "1650\n");
  fflush(_coverage_fout);
  }
  if ((unsigned int )obuf == (unsigned int )((void *)0)) {
    {
    fprintf(_coverage_fout, "1605\n");
    fflush(_coverage_fout);
    }
    return (0);
  } else {
    {
    fprintf(_coverage_fout, "1606\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1651\n");
  fflush(_coverage_fout);
  }
  TIFFGetField(out, 323U, & tl);
  {
  fprintf(_coverage_fout, "1652\n");
  fflush(_coverage_fout);
  }
  TIFFGetField(out, 322U, & tw);
  {
  fprintf(_coverage_fout, "1653\n");
  fflush(_coverage_fout);
  }
  TIFFGetField(out, 258U, & bps);
  {
  fprintf(_coverage_fout, "1654\n");
  fflush(_coverage_fout);
  }
  if ((int )bps % 8 == 0) {
    {
    fprintf(_coverage_fout, "1607\n");
    fflush(_coverage_fout);
    }

  } else {
    {
    fprintf(_coverage_fout, "1608\n");
    fflush(_coverage_fout);
    }
    __assert_fail("bps % 8 == 0", "tiffcp.c", 1322U,
                  "writeBufferToSeparateTiles");
  }
  {
  fprintf(_coverage_fout, "1655\n");
  fflush(_coverage_fout);
  }
  bytes_per_sample = (unsigned short )((int )bps / 8);
  {
  fprintf(_coverage_fout, "1656\n");
  fflush(_coverage_fout);
  }
  row = 0U;
  {
  fprintf(_coverage_fout, "1657\n");
  fflush(_coverage_fout);
  }
  while (1) {
    {
    fprintf(_coverage_fout, "1631\n");
    fflush(_coverage_fout);
    }
    if (row < imagelength) {
      {
      fprintf(_coverage_fout, "1609\n");
      fflush(_coverage_fout);
      }

    } else {
      break;
    }
    {
    fprintf(_coverage_fout, "1632\n");
    fflush(_coverage_fout);
    }
    if (row + tl > imagelength) {
      {
      fprintf(_coverage_fout, "1610\n");
      fflush(_coverage_fout);
      }
      tmp___4 = imagelength - row;
    } else {
      {
      fprintf(_coverage_fout, "1611\n");
      fflush(_coverage_fout);
      }
      tmp___4 = tl;
    }
    {
    fprintf(_coverage_fout, "1633\n");
    fflush(_coverage_fout);
    }
    nrow = tmp___4;
    {
    fprintf(_coverage_fout, "1634\n");
    fflush(_coverage_fout);
    }
    colb = (uint32 )0;
    {
    fprintf(_coverage_fout, "1635\n");
    fflush(_coverage_fout);
    }
    col = 0U;
    {
    fprintf(_coverage_fout, "1636\n");
    fflush(_coverage_fout);
    }
    while (1) {
      {
      fprintf(_coverage_fout, "1626\n");
      fflush(_coverage_fout);
      }
      if (col < imagewidth) {
        {
        fprintf(_coverage_fout, "1612\n");
        fflush(_coverage_fout);
        }

      } else {
        break;
      }
      {
      fprintf(_coverage_fout, "1627\n");
      fflush(_coverage_fout);
      }
      s = (unsigned short)0;
      {
      fprintf(_coverage_fout, "1628\n");
      fflush(_coverage_fout);
      }
      while (1) {
        {
        fprintf(_coverage_fout, "1621\n");
        fflush(_coverage_fout);
        }
        if ((int )s < (int )spp) {
          {
          fprintf(_coverage_fout, "1613\n");
          fflush(_coverage_fout);
          }

        } else {
          break;
        }
        {
        fprintf(_coverage_fout, "1622\n");
        fflush(_coverage_fout);
        }
        if (colb + (uint32 )tilew > imagew) {
          {
          fprintf(_coverage_fout, "1614\n");
          fflush(_coverage_fout);
          }
          width = imagew - colb;
          {
          fprintf(_coverage_fout, "1615\n");
          fflush(_coverage_fout);
          }
          oskew = (int )((uint32 )tilew - width);
          {
          fprintf(_coverage_fout, "1616\n");
          fflush(_coverage_fout);
          }
          cpContigBufToSeparateBuf((uint8 *)obuf,
                                   (bufp + colb * (uint32 )spp) + (int )s, nrow,
                                   width / (uint32 )bytes_per_sample, oskew,
                                   oskew * (int )spp + iskew, spp,
                                   (int )bytes_per_sample);
        } else {
          {
          fprintf(_coverage_fout, "1617\n");
          fflush(_coverage_fout);
          }
          cpContigBufToSeparateBuf((uint8 *)obuf,
                                   (bufp + colb * (uint32 )spp) + (int )s, nrow,
                                   tilewidth, 0, iskew, spp,
                                   (int )bytes_per_sample);
        }
        {
        fprintf(_coverage_fout, "1623\n");
        fflush(_coverage_fout);
        }
        tmp___5 = TIFFWriteTile(out, obuf, col, row, 0U, s);
        {
        fprintf(_coverage_fout, "1624\n");
        fflush(_coverage_fout);
        }
        if (tmp___5 < 0) {
          {
          fprintf(_coverage_fout, "1618\n");
          fflush(_coverage_fout);
          }
          _TIFFfree(obuf);
          {
          fprintf(_coverage_fout, "1619\n");
          fflush(_coverage_fout);
          }
          return (0);
        } else {
          {
          fprintf(_coverage_fout, "1620\n");
          fflush(_coverage_fout);
          }

        }
        {
        fprintf(_coverage_fout, "1625\n");
        fflush(_coverage_fout);
        }
        s = (tsample_t )((int )s + 1);
      }
      {
      fprintf(_coverage_fout, "1629\n");
      fflush(_coverage_fout);
      }
      colb += (uint32 )tilew;
      {
      fprintf(_coverage_fout, "1630\n");
      fflush(_coverage_fout);
      }
      col += tw;
    }
    {
    fprintf(_coverage_fout, "1637\n");
    fflush(_coverage_fout);
    }
    bufp += nrow * iimagew;
    {
    fprintf(_coverage_fout, "1638\n");
    fflush(_coverage_fout);
    }
    row += tl;
  }
  {
  fprintf(_coverage_fout, "1658\n");
  fflush(_coverage_fout);
  }
  _TIFFfree(obuf);
  {
  fprintf(_coverage_fout, "1659\n");
  fflush(_coverage_fout);
  }
  return (1);
}
}
static int cpContigStrips2ContigTiles(TIFF *in , TIFF *out ,
                                      uint32 imagelength , uint32 imagewidth ,
                                      tsample_t spp ) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1660\n");
  fflush(_coverage_fout);
  }
  tmp = cpImage(in, out, & readContigStripsIntoBuffer,
                & writeBufferToContigTiles, imagelength, imagewidth, spp);
  {
  fprintf(_coverage_fout, "1661\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
static int cpContigStrips2SeparateTiles(TIFF *in , TIFF *out ,
                                        uint32 imagelength , uint32 imagewidth ,
                                        tsample_t spp ) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1662\n");
  fflush(_coverage_fout);
  }
  tmp = cpImage(in, out, & readContigStripsIntoBuffer,
                & writeBufferToSeparateTiles, imagelength, imagewidth, spp);
  {
  fprintf(_coverage_fout, "1663\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
static int cpSeparateStrips2ContigTiles(TIFF *in , TIFF *out ,
                                        uint32 imagelength , uint32 imagewidth ,
                                        tsample_t spp ) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1664\n");
  fflush(_coverage_fout);
  }
  tmp = cpImage(in, out, & readSeparateStripsIntoBuffer,
                & writeBufferToContigTiles, imagelength, imagewidth, spp);
  {
  fprintf(_coverage_fout, "1665\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
static int cpSeparateStrips2SeparateTiles(TIFF *in , TIFF *out ,
                                          uint32 imagelength ,
                                          uint32 imagewidth , tsample_t spp ) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1666\n");
  fflush(_coverage_fout);
  }
  tmp = cpImage(in, out, & readSeparateStripsIntoBuffer,
                & writeBufferToSeparateTiles, imagelength, imagewidth, spp);
  {
  fprintf(_coverage_fout, "1667\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
static int cpContigTiles2ContigTiles(TIFF *in , TIFF *out , uint32 imagelength ,
                                     uint32 imagewidth , tsample_t spp ) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1668\n");
  fflush(_coverage_fout);
  }
  tmp = cpImage(in, out, & readContigTilesIntoBuffer,
                & writeBufferToContigTiles, imagelength, imagewidth, spp);
  {
  fprintf(_coverage_fout, "1669\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
static int cpContigTiles2SeparateTiles(TIFF *in , TIFF *out ,
                                       uint32 imagelength , uint32 imagewidth ,
                                       tsample_t spp ) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1670\n");
  fflush(_coverage_fout);
  }
  tmp = cpImage(in, out, & readContigTilesIntoBuffer,
                & writeBufferToSeparateTiles, imagelength, imagewidth, spp);
  {
  fprintf(_coverage_fout, "1671\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
static int cpSeparateTiles2ContigTiles(TIFF *in , TIFF *out ,
                                       uint32 imagelength , uint32 imagewidth ,
                                       tsample_t spp ) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1672\n");
  fflush(_coverage_fout);
  }
  tmp = cpImage(in, out, & readSeparateTilesIntoBuffer,
                & writeBufferToContigTiles, imagelength, imagewidth, spp);
  {
  fprintf(_coverage_fout, "1673\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
static int cpSeparateTiles2SeparateTiles(TIFF *in , TIFF *out ,
                                         uint32 imagelength ,
                                         uint32 imagewidth , tsample_t spp ) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1674\n");
  fflush(_coverage_fout);
  }
  tmp = cpImage(in, out, & readSeparateTilesIntoBuffer,
                & writeBufferToSeparateTiles, imagelength, imagewidth, spp);
  {
  fprintf(_coverage_fout, "1675\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
static int cpContigTiles2ContigStrips(TIFF *in , TIFF *out ,
                                      uint32 imagelength , uint32 imagewidth ,
                                      tsample_t spp ) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1676\n");
  fflush(_coverage_fout);
  }
  tmp = cpImage(in, out, & readContigTilesIntoBuffer,
                & writeBufferToContigStrips, imagelength, imagewidth, spp);
  {
  fprintf(_coverage_fout, "1677\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
static int cpContigTiles2SeparateStrips(TIFF *in , TIFF *out ,
                                        uint32 imagelength , uint32 imagewidth ,
                                        tsample_t spp ) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1678\n");
  fflush(_coverage_fout);
  }
  tmp = cpImage(in, out, & readContigTilesIntoBuffer,
                & writeBufferToSeparateStrips, imagelength, imagewidth, spp);
  {
  fprintf(_coverage_fout, "1679\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
static int cpSeparateTiles2ContigStrips(TIFF *in , TIFF *out ,
                                        uint32 imagelength , uint32 imagewidth ,
                                        tsample_t spp ) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1680\n");
  fflush(_coverage_fout);
  }
  tmp = cpImage(in, out, & readSeparateTilesIntoBuffer,
                & writeBufferToContigStrips, imagelength, imagewidth, spp);
  {
  fprintf(_coverage_fout, "1681\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
static int cpSeparateTiles2SeparateStrips(TIFF *in , TIFF *out ,
                                          uint32 imagelength ,
                                          uint32 imagewidth , tsample_t spp ) 
{ int tmp ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1682\n");
  fflush(_coverage_fout);
  }
  tmp = cpImage(in, out, & readSeparateTilesIntoBuffer,
                & writeBufferToSeparateStrips, imagelength, imagewidth, spp);
  {
  fprintf(_coverage_fout, "1683\n");
  fflush(_coverage_fout);
  }
  return (tmp);
}
}
static copyFunc pickCopyFunc(TIFF *in , TIFF *out , uint16 bitspersample ,
                             uint16 samplesperpixel ) 
{ uint16 shortv ;
  uint32 w ;
  uint32 l ;
  uint32 tw ;
  uint32 tl ;
  int bychunk ;
  char const   *tmp ;
  uint32 irps ;
  int tmp___0 ;
  char const   *tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  int (*tmp___11)(TIFF *in , TIFF *out , uint32 imagelength ,
                  uint32 imagewidth , tsample_t spp ) ;
  char const   *tmp___12 ;

  {
  {
  if (_coverage_fout == 0) {
    {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-2005-12-14-6746b87-0d3d51d/coverage/coverage.path",
                           "wb");
    }
  }
  }
  {
  fprintf(_coverage_fout, "1751\n");
  fflush(_coverage_fout);
  }
  TIFFGetField(in, 284U, & shortv);
  {
  fprintf(_coverage_fout, "1752\n");
  fflush(_coverage_fout);
  }
  if ((int )shortv != (int )config) {
    {
    fprintf(_coverage_fout, "1690\n");
    fflush(_coverage_fout);
    }
    if ((int )bitspersample != 8) {
      {
      fprintf(_coverage_fout, "1688\n");
      fflush(_coverage_fout);
      }
      if ((int )samplesperpixel > 1) {
        {
        fprintf(_coverage_fout, "1684\n");
        fflush(_coverage_fout);
        }
        tmp = TIFFFileName(in);
        {
        fprintf(_coverage_fout, "1685\n");
        fflush(_coverage_fout);
        }
        fprintf((FILE */* __restrict  */)stderr,
                (char const   */* __restrict  */)"%s: Cannot handle different planar configuration w/ bits/sample != 8\n",
                tmp);
        {
        fprintf(_coverage_fout, "1686\n");
        fflush(_coverage_fout);
        }
        return ((int (*)(TIFF *in , TIFF *out , uint32 l , uint32 w ,
                         uint16 samplesperpixel ))((void *)0));
      } else {
        {
        fprintf(_coverage_fout, "1687\n");
        fflush(_coverage_fout);
        }

      }
    } else {
      {
      fprintf(_coverage_fout, "1689\n");
      fflush(_coverage_fout);
      }

    }
  } else {
    {
    fprintf(_coverage_fout, "1691\n");
    fflush(_coverage_fout);
    }

  }
  {
  fprintf(_coverage_fout, "1753\n");
  fflush(_coverage_fout);
  }
  TIFFGetField(in, 256U, & w);
  {
  fprintf(_coverage_fout, "1754\n");
  fflush(_coverage_fout);
  }
  TIFFGetField(in, 257U, & l);
  {
  fprintf(_coverage_fout, "1755\n");
  fflush(_coverage_fout);
  }
  tmp___7 = TIFFIsTiled(out);
  {
  fprintf(_coverage_fout, "1756\n");
  fflush(_coverage_fout);
  }
  if (tmp___7) {
    goto _L;
  } else {
    {
    fprintf(_coverage_fout, "1729\n");
    fflush(_coverage_fout);
    }
    tmp___8 = TIFFIsTiled(in);
    {
    fprintf(_coverage_fout, "1730\n");
    fflush(_coverage_fout);
    }
    if (tmp___8) {
      {
      fprintf(_coverage_fout, "1718\n");
      fflush(_coverage_fout);
      }
      _L: /* CIL Label */ 
      if (bias) {
        {
        fprintf(_coverage_fout, "1692\n");
        fflush(_coverage_fout);
        }
        tmp___1 = TIFFFileName(in);
        {
        fprintf(_coverage_fout, "1693\n");
        fflush(_coverage_fout);
        }
        fprintf((FILE */* __restrict  */)stderr,
                (char const   */* __restrict  */)"%s: Cannot handle tiled configuration w/bias image\n",
                tmp___1);
        {
        fprintf(_coverage_fout, "1694\n");
        fflush(_coverage_fout);
        }
        return ((int (*)(TIFF *in , TIFF *out , uint32 l , uint32 w ,
                         uint16 samplesperpixel ))((void *)0));
      } else {
        {
        fprintf(_coverage_fout, "1695\n");
        fflush(_coverage_fout);
        }

      }
      {
      fprintf(_coverage_fout, "1719\n");
      fflush(_coverage_fout);
      }
      tmp___6 = TIFFIsTiled(out);
      {
      fprintf(_coverage_fout, "1720\n");
      fflush(_coverage_fout);
      }
      if (tmp___6) {
        {
        fprintf(_coverage_fout, "1704\n");
        fflush(_coverage_fout);
        }
        tmp___2 = TIFFGetField(in, 322U, & tw);
        {
        fprintf(_coverage_fout, "1705\n");
        fflush(_coverage_fout);
        }
        if (tmp___2) {
          {
          fprintf(_coverage_fout, "1696\n");
          fflush(_coverage_fout);
          }

        } else {
          {
          fprintf(_coverage_fout, "1697\n");
          fflush(_coverage_fout);
          }
          tw = w;
        }
        {
        fprintf(_coverage_fout, "1706\n");
        fflush(_coverage_fout);
        }
        tmp___3 = TIFFGetField(in, 323U, & tl);
        {
        fprintf(_coverage_fout, "1707\n");
        fflush(_coverage_fout);
        }
        if (tmp___3) {
          {
          fprintf(_coverage_fout, "1698\n");
          fflush(_coverage_fout);
          }

        } else {
          {
          fprintf(_coverage_fout, "1699\n");
          fflush(_coverage_fout);
          }
          tl = l;
        }
        {
        fprintf(_coverage_fout, "1708\n");
        fflush(_coverage_fout);
        }
        if (tw == tilewidth) {
          {
          fprintf(_coverage_fout, "1702\n");
          fflush(_coverage_fout);
          }
          if (tl == tilelength) {
            {
            fprintf(_coverage_fout, "1700\n");
            fflush(_coverage_fout);
            }
            tmp___4 = 1;
          } else {
            {
            fprintf(_coverage_fout, "1701\n");
            fflush(_coverage_fout);
            }
            tmp___4 = 0;
          }
        } else {
          {
          fprintf(_coverage_fout, "1703\n");
          fflush(_coverage_fout);
          }
          tmp___4 = 0;
        }
        {
        fprintf(_coverage_fout, "1709\n");
        fflush(_coverage_fout);
        }
        bychunk = tmp___4;
      } else {
        {
        fprintf(_coverage_fout, "1714\n");
        fflush(_coverage_fout);
        }
        TIFFGetField(in, 322U, & tw);
        {
        fprintf(_coverage_fout, "1715\n");
        fflush(_coverage_fout);
        }
        TIFFGetField(in, 323U, & tl);
        {
        fprintf(_coverage_fout, "1716\n");
        fflush(_coverage_fout);
        }
        if (tw == w) {
          {
          fprintf(_coverage_fout, "1712\n");
          fflush(_coverage_fout);
          }
          if (tl == rowsperstrip) {
            {
            fprintf(_coverage_fout, "1710\n");
            fflush(_coverage_fout);
            }
            tmp___5 = 1;
          } else {
            {
            fprintf(_coverage_fout, "1711\n");
            fflush(_coverage_fout);
            }
            tmp___5 = 0;
          }
        } else {
          {
          fprintf(_coverage_fout, "1713\n");
          fflush(_coverage_fout);
          }
          tmp___5 = 0;
        }
        {
        fprintf(_coverage_fout, "1717\n");
        fflush(_coverage_fout);
        }
        bychunk = tmp___5;
      }
    } else {
      {
      fprintf(_coverage_fout, "1725\n");
      fflush(_coverage_fout);
      }
      irps = 4294967295U;
      {
      fprintf(_coverage_fout, "1726\n");
      fflush(_coverage_fout);
      }
      TIFFGetField(in, 278U, & irps);
      {
      fprintf(_coverage_fout, "1727\n");
      fflush(_coverage_fout);
      }
      if (! bias) {
        {
        fprintf(_coverage_fout, "1723\n");
        fflush(_coverage_fout);
        }
        if (rowsperstrip == irps) {
          {
          fprintf(_coverage_fout, "1721\n");
          fflush(_coverage_fout);
          }
          tmp___0 = 1;
        } else {
          {
          fprintf(_coverage_fout, "1722\n");
          fflush(_coverage_fout);
          }
          tmp___0 = 0;
        }
      } else {
        {
        fprintf(_coverage_fout, "1724\n");
        fflush(_coverage_fout);
        }
        tmp___0 = 0;
      }
      {
      fprintf(_coverage_fout, "1728\n");
      fflush(_coverage_fout);
      }
      bychunk = tmp___0;
    }
  }
  {
  fprintf(_coverage_fout, "1757\n");
  fflush(_coverage_fout);
  }
  tmp___9 = TIFFIsTiled(in);
  {
  fprintf(_coverage_fout, "1758\n");
  fflush(_coverage_fout);
  }
  tmp___10 = TIFFIsTiled(out);
  switch ((int )((long )((((((int )shortv << 11) | ((int )config << 3)) | (tmp___9 << 2)) | (tmp___10 << 1)) | bychunk))) {
  {
  fprintf(_coverage_fout, "1733\n");
  fflush(_coverage_fout);
  }
  case (long )(((1 << 11) | (1 << 3)) | (1 << 1)): 
  case (long )((((1 << 11) | (1 << 3)) | (1 << 1)) | 1): 
  return (& cpContigStrips2ContigTiles);
  {
  fprintf(_coverage_fout, "1734\n");
  fflush(_coverage_fout);
  }
  case (long )(((1 << 11) | (2 << 3)) | (1 << 1)): 
  case (long )((((1 << 11) | (2 << 3)) | (1 << 1)) | 1): 
  return (& cpContigStrips2SeparateTiles);
  {
  fprintf(_coverage_fout, "1735\n");
  fflush(_coverage_fout);
  }
  case (long )(((2 << 11) | (1 << 3)) | (1 << 1)): 
  case (long )((((2 << 11) | (1 << 3)) | (1 << 1)) | 1): 
  return (& cpSeparateStrips2ContigTiles);
  {
  fprintf(_coverage_fout, "1736\n");
  fflush(_coverage_fout);
  }
  case (long )(((2 << 11) | (2 << 3)) | (1 << 1)): 
  case (long )((((2 << 11) | (2 << 3)) | (1 << 1)) | 1): 
  return (& cpSeparateStrips2SeparateTiles);
  {
  fprintf(_coverage_fout, "1737\n");
  fflush(_coverage_fout);
  }
  case (long )((((1 << 11) | (1 << 3)) | (1 << 2)) | (1 << 1)): 
  case (long )(((((1 << 11) | (1 << 3)) | (1 << 2)) | (1 << 1)) | 1): 
  return (& cpContigTiles2ContigTiles);
  {
  fprintf(_coverage_fout, "1738\n");
  fflush(_coverage_fout);
  }
  case (long )((((1 << 11) | (2 << 3)) | (1 << 2)) | (1 << 1)): 
  case (long )(((((1 << 11) | (2 << 3)) | (1 << 2)) | (1 << 1)) | 1): 
  return (& cpContigTiles2SeparateTiles);
  {
  fprintf(_coverage_fout, "1739\n");
  fflush(_coverage_fout);
  }
  case (long )((((2 << 11) | (1 << 3)) | (1 << 2)) | (1 << 1)): 
  case (long )(((((2 << 11) | (1 << 3)) | (1 << 2)) | (1 << 1)) | 1): 
  return (& cpSeparateTiles2ContigTiles);
  {
  fprintf(_coverage_fout, "1740\n");
  fflush(_coverage_fout);
  }
  case (long )((((2 << 11) | (2 << 3)) | (1 << 2)) | (1 << 1)): 
  case (long )(((((2 << 11) | (2 << 3)) | (1 << 2)) | (1 << 1)) | 1): 
  return (& cpSeparateTiles2SeparateTiles);
  {
  fprintf(_coverage_fout, "1741\n");
  fflush(_coverage_fout);
  }
  case (long )(((1 << 11) | (1 << 3)) | (1 << 2)): 
  case (long )((((1 << 11) | (1 << 3)) | (1 << 2)) | 1): 
  return (& cpContigTiles2ContigStrips);
  {
  fprintf(_coverage_fout, "1742\n");
  fflush(_coverage_fout);
  }
  case (long )(((1 << 11) | (2 << 3)) | (1 << 2)): 
  case (long )((((1 << 11) | (2 << 3)) | (1 << 2)) | 1): 
  return (& cpContigTiles2SeparateStrips);
  {
  fprintf(_coverage_fout, "1743\n");
  fflush(_coverage_fout);
  }
  case (long )(((2 << 11) | (1 << 3)) | (1 << 2)): 
  case (long )((((2 << 11) | (1 << 3)) | (1 << 2)) | 1): 
  return (& cpSeparateTiles2ContigStrips);
  {
  fprintf(_coverage_fout, "1744\n");
  fflush(_coverage_fout);
  }
  case (long )(((2 << 11) | (2 << 3)) | (1 << 2)): 
  case (long )((((2 << 11) | (2 << 3)) | (1 << 2)) | 1): 
  return (& cpSeparateTiles2SeparateStrips);
  {
  fprintf(_coverage_fout, "1745\n");
  fflush(_coverage_fout);
  }
  case (long )((1 << 11) | (1 << 3)): 
  if (bias) {
    {
    fprintf(_coverage_fout, "1731\n");
    fflush(_coverage_fout);
    }
    tmp___11 = & cpBiasedContig2Contig;
  } else {
    {
    fprintf(_coverage_fout, "1732\n");
    fflush(_coverage_fout);
    }
    tmp___11 = & cpContig2ContigByRow;
  }
  {
  fprintf(_coverage_fout, "1746\n");
  fflush(_coverage_fout);
  }
  return (tmp___11);
  {
  fprintf(_coverage_fout, "1747\n");
  fflush(_coverage_fout);
  }
  case (long )(((1 << 11) | (1 << 3)) | 1): 
  return (& cpDecodedStrips);
  {
  fprintf(_coverage_fout, "1748\n");
  fflush(_coverage_fout);
  }
  case (long )((1 << 11) | (2 << 3)): 
  case (long )(((1 << 11) | (2 << 3)) | 1): 
  return (& cpContig2SeparateByRow);
  {
  fprintf(_coverage_fout, "1749\n");
  fflush(_coverage_fout);
  }
  case (long )((2 << 11) | (1 << 3)): 
  case (long )(((2 << 11) | (1 << 3)) | 1): 
  return (& cpSeparate2ContigByRow);
  {
  fprintf(_coverage_fout, "1750\n");
  fflush(_coverage_fout);
  }
  case (long )((2 << 11) | (2 << 3)): 
  case (long )(((2 << 11) | (2 << 3)) | 1): 
  return (& cpSeparate2SeparateByRow);
  }
  {
  fprintf(_coverage_fout, "1759\n");
  fflush(_coverage_fout);
  }
  tmp___12 = TIFFFileName(in);
  {
  fprintf(_coverage_fout, "1760\n");
  fflush(_coverage_fout);
  }
  fprintf((FILE */* __restrict  */)stderr,
          (char const   */* __restrict  */)"tiffcp: %s: Don\'t know how to copy/convert image.\n",
          tmp___12);
  {
  fprintf(_coverage_fout, "1761\n");
  fflush(_coverage_fout);
  }
  return ((int (*)(TIFF *in , TIFF *out , uint32 l , uint32 w ,
                   uint16 samplesperpixel ))((void *)0));
}
}
