#!/bin/sh
rm -f ./ascii-log && make ascii-log &> /dev/null && ./ascii-log
