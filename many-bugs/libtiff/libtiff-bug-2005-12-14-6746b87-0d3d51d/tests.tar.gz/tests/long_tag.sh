#!/bin/sh
rm -f long_tag && make long_tag &> /dev/null && ./long_tag
