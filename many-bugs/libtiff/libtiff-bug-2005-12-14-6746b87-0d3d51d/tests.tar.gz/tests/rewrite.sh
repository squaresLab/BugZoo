#!/bin/sh
rm -f rewrite && make rewrite && ./rewrite
