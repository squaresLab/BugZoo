void *_coverage_fout ;
typedef unsigned char __u_char;
typedef unsigned short __u_short;
typedef unsigned int __u_int;
typedef unsigned long __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef short __int16_t;
typedef unsigned short __uint16_t;
typedef int __int32_t;
typedef unsigned int __uint32_t;
typedef long long __int64_t;
typedef unsigned long long __uint64_t;
typedef long long __quad_t;
typedef unsigned long long __u_quad_t;
typedef __u_quad_t __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long __ino_t;
typedef __u_quad_t __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned int __nlink_t;
typedef long __off_t;
typedef __quad_t __off64_t;
typedef int __pid_t;
struct __anonstruct___fsid_t_1 {
   int __val[2] ;
};
typedef struct __anonstruct___fsid_t_1 __fsid_t;
typedef long __clock_t;
typedef unsigned long __rlim_t;
typedef __u_quad_t __rlim64_t;
typedef unsigned int __id_t;
typedef long __time_t;
typedef unsigned int __useconds_t;
typedef long __suseconds_t;
typedef int __daddr_t;
typedef long __swblk_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void *__timer_t;
typedef long __blksize_t;
typedef long __blkcnt_t;
typedef __quad_t __blkcnt64_t;
typedef unsigned long __fsblkcnt_t;
typedef __u_quad_t __fsblkcnt64_t;
typedef unsigned long __fsfilcnt_t;
typedef __u_quad_t __fsfilcnt64_t;
typedef int __ssize_t;
typedef __off64_t __loff_t;
typedef __quad_t *__qaddr_t;
typedef char *__caddr_t;
typedef int __intptr_t;
typedef unsigned int __socklen_t;
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;
typedef __loff_t loff_t;
typedef __ino64_t ino_t;
typedef __dev_t dev_t;
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __nlink_t nlink_t;
typedef __uid_t uid_t;
typedef __off64_t off_t;
typedef __pid_t pid_t;
typedef __id_t id_t;
typedef __ssize_t ssize_t;
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;
typedef __key_t key_t;
typedef __clock_t clock_t;
typedef __time_t time_t;
typedef __clockid_t clockid_t;
typedef __timer_t timer_t;
typedef unsigned int size_t;
typedef unsigned long ulong;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char u_int8_t;
typedef unsigned short u_int16_t;
typedef unsigned int u_int32_t;
typedef unsigned long long u_int64_t;
typedef int register_t;
typedef int __sig_atomic_t;
struct __anonstruct___sigset_t_2 {
   unsigned long __val[1024U / (8U * sizeof(unsigned long ))] ;
};
typedef struct __anonstruct___sigset_t_2 __sigset_t;
typedef __sigset_t sigset_t;
struct timespec {
   __time_t tv_sec ;
   long tv_nsec ;
};
struct timeval {
   __time_t tv_sec ;
   __suseconds_t tv_usec ;
};
typedef __suseconds_t suseconds_t;
typedef long __fd_mask;
struct __anonstruct_fd_set_3 {
   __fd_mask __fds_bits[1024 / (8 * (int )sizeof(__fd_mask ))] ;
};
typedef struct __anonstruct_fd_set_3 fd_set;
typedef __fd_mask fd_mask;
typedef __blksize_t blksize_t;
typedef __blkcnt64_t blkcnt_t;
typedef __fsblkcnt64_t fsblkcnt_t;
typedef __fsfilcnt64_t fsfilcnt_t;
typedef unsigned long pthread_t;
union __anonunion_pthread_attr_t_4 {
   char __size[36] ;
   long __align ;
};
typedef union __anonunion_pthread_attr_t_4 pthread_attr_t;
struct __pthread_internal_slist {
   struct __pthread_internal_slist *__next ;
};
typedef struct __pthread_internal_slist __pthread_slist_t;
union __anonunion____missing_field_name_6 {
   int __spins ;
   __pthread_slist_t __list ;
};
struct __pthread_mutex_s {
   int __lock ;
   unsigned int __count ;
   int __owner ;
   int __kind ;
   unsigned int __nusers ;
   union __anonunion____missing_field_name_6 __annonCompField1 ;
};
union __anonunion_pthread_mutex_t_5 {
   struct __pthread_mutex_s __data ;
   char __size[24] ;
   long __align ;
};
typedef union __anonunion_pthread_mutex_t_5 pthread_mutex_t;
union __anonunion_pthread_mutexattr_t_7 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_mutexattr_t_7 pthread_mutexattr_t;
struct __anonstruct___data_9 {
   int __lock ;
   unsigned int __futex ;
   unsigned long long __total_seq ;
   unsigned long long __wakeup_seq ;
   unsigned long long __woken_seq ;
   void *__mutex ;
   unsigned int __nwaiters ;
   unsigned int __broadcast_seq ;
};
union __anonunion_pthread_cond_t_8 {
   struct __anonstruct___data_9 __data ;
   char __size[48] ;
   long long __align ;
};
typedef union __anonunion_pthread_cond_t_8 pthread_cond_t;
union __anonunion_pthread_condattr_t_10 {
   char __size[4] ;
   long __align ;
};
typedef union __anonunion_pthread_condattr_t_10 pthread_condattr_t;
typedef unsigned int pthread_key_t;
typedef int pthread_once_t;
struct __anonstruct___data_12 {
   int __lock ;
   unsigned int __nr_readers ;
   unsigned int __readers_wakeup ;
   unsigned int __writer_wakeup ;
   unsigned int __nr_readers_queued ;
   unsigned int __nr_writers_queued ;
   unsigned char __flags ;
   unsigned char __shared ;
   unsigned char __pad1 ;
   unsigned char __pad2 ;
   int __writer ;
};
union __anonunion_pthread_rwlock_t_11 {
   struct __anonstruct___data_12 __data ;
   char __size[32] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlock_t_11 pthread_rwlock_t;
union __anonunion_pthread_rwlockattr_t_13 {
   char __size[8] ;
   long __align ;
};
typedef union __anonunion_pthread_rwlockattr_t_13 pthread_rwlockattr_t;
typedef int volatile   pthread_spinlock_t;
union __anonunion_pthread_barrier_t_14 {
   char __size[20] ;
   long __align ;
};
typedef union __anonunion_pthread_barrier_t_14 pthread_barrier_t;
union __anonunion_pthread_barrierattr_t_15 {
   char __size[4] ;
   int __align ;
};
typedef union __anonunion_pthread_barrierattr_t_15 pthread_barrierattr_t;
struct flock {
   short l_type ;
   short l_whence ;
   __off64_t l_start ;
   __off64_t l_len ;
   __pid_t l_pid ;
};
struct stat {
   __dev_t st_dev ;
   unsigned short __pad1 ;
   __ino_t __st_ino ;
   __mode_t st_mode ;
   __nlink_t st_nlink ;
   __uid_t st_uid ;
   __gid_t st_gid ;
   __dev_t st_rdev ;
   unsigned short __pad2 ;
   __off64_t st_size ;
   __blksize_t st_blksize ;
   __blkcnt64_t st_blocks ;
   struct timespec st_atim ;
   struct timespec st_mtim ;
   struct timespec st_ctim ;
   __ino64_t st_ino ;
};
struct __locale_data;
struct __locale_struct {
   struct __locale_data *__locales[13] ;
   unsigned short const   *__ctype_b ;
   int const   *__ctype_tolower ;
   int const   *__ctype_toupper ;
   char const   *__names[13] ;
};
typedef struct __locale_struct *__locale_t;
typedef __locale_t locale_t;
typedef int (*__compar_fn_t)(void const   * , void const   * );
enum __anonenum_ACTION_16 {
    FIND = 0,
    ENTER = 1
} ;
typedef enum __anonenum_ACTION_16 ACTION;
struct entry {
   char *key ;
   void *data ;
};
typedef struct entry ENTRY;
struct _ENTRY;
struct _ENTRY;
enum __anonenum_VISIT_17 {
    preorder = 0,
    postorder = 1,
    endorder = 2,
    leaf = 3
} ;
typedef enum __anonenum_VISIT_17 VISIT;
typedef void (*__action_fn_t)(void const   *__nodep , VISIT __value ,
                              int __level );
typedef signed char int8;
typedef unsigned char uint8;
typedef short int16;
typedef unsigned short uint16;
typedef int int32;
typedef unsigned int uint32;
typedef long long int64;
typedef unsigned long long uint64;
typedef int uint16_vap;
struct __anonstruct_TIFFHeaderCommon_18 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
};
typedef struct __anonstruct_TIFFHeaderCommon_18 TIFFHeaderCommon;
struct __anonstruct_TIFFHeaderClassic_19 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint32 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderClassic_19 TIFFHeaderClassic;
struct __anonstruct_TIFFHeaderBig_20 {
   uint16 tiff_magic ;
   uint16 tiff_version ;
   uint16 tiff_offsetsize ;
   uint16 tiff_unused ;
   uint64 tiff_diroff ;
};
typedef struct __anonstruct_TIFFHeaderBig_20 TIFFHeaderBig;
enum __anonenum_TIFFDataType_21 {
    TIFF_NOTYPE = 0,
    TIFF_BYTE = 1,
    TIFF_ASCII = 2,
    TIFF_SHORT = 3,
    TIFF_LONG = 4,
    TIFF_RATIONAL = 5,
    TIFF_SBYTE = 6,
    TIFF_UNDEFINED = 7,
    TIFF_SSHORT = 8,
    TIFF_SLONG = 9,
    TIFF_SRATIONAL = 10,
    TIFF_FLOAT = 11,
    TIFF_DOUBLE = 12,
    TIFF_IFD = 13,
    TIFF_LONG8 = 16,
    TIFF_SLONG8 = 17,
    TIFF_IFD8 = 18
} ;
typedef enum __anonenum_TIFFDataType_21 TIFFDataType;
struct tiff;
typedef struct tiff TIFF;
typedef long tmsize_t;
typedef uint32 ttag_t;
typedef uint16 tdir_t;
typedef uint16 tsample_t;
typedef uint32 tstrile_t;
typedef tstrile_t tstrip_t;
typedef tstrile_t ttile_t;
typedef tmsize_t tsize_t;
typedef void *tdata_t;
typedef uint64 toff_t;
typedef void *thandle_t;
typedef unsigned char TIFFRGBValue;
struct __anonstruct_TIFFDisplay_22 {
   float d_mat[3][3] ;
   float d_YCR ;
   float d_YCG ;
   float d_YCB ;
   uint32 d_Vrwr ;
   uint32 d_Vrwg ;
   uint32 d_Vrwb ;
   float d_Y0R ;
   float d_Y0G ;
   float d_Y0B ;
   float d_gammaR ;
   float d_gammaG ;
   float d_gammaB ;
};
typedef struct __anonstruct_TIFFDisplay_22 TIFFDisplay;
struct __anonstruct_TIFFYCbCrToRGB_23 {
   TIFFRGBValue *clamptab ;
   int *Cr_r_tab ;
   int *Cb_b_tab ;
   int32 *Cr_g_tab ;
   int32 *Cb_g_tab ;
   int32 *Y_tab ;
};
typedef struct __anonstruct_TIFFYCbCrToRGB_23 TIFFYCbCrToRGB;
struct __anonstruct_TIFFCIELabToRGB_24 {
   int range ;
   float rstep ;
   float gstep ;
   float bstep ;
   float X0 ;
   float Y0 ;
   float Z0 ;
   TIFFDisplay display ;
   float Yr2r[1501] ;
   float Yg2g[1501] ;
   float Yb2b[1501] ;
};
typedef struct __anonstruct_TIFFCIELabToRGB_24 TIFFCIELabToRGB;
struct _TIFFRGBAImage;
typedef struct _TIFFRGBAImage TIFFRGBAImage;
typedef void (*tileContigRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                  uint32  , uint32  , uint32  , int32  ,
                                  int32  , unsigned char * );
typedef void (*tileSeparateRoutine)(TIFFRGBAImage * , uint32 * , uint32  ,
                                    uint32  , uint32  , uint32  , int32  ,
                                    int32  , unsigned char * , unsigned char * ,
                                    unsigned char * , unsigned char * );
union __anonunion_put_25 {
   void (*any)(TIFFRGBAImage * ) ;
   void (*contig)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                  uint32  , int32  , int32  , unsigned char * ) ;
   void (*separate)(TIFFRGBAImage * , uint32 * , uint32  , uint32  , uint32  ,
                    uint32  , int32  , int32  , unsigned char * ,
                    unsigned char * , unsigned char * , unsigned char * ) ;
};
struct _TIFFRGBAImage {
   TIFF *tif ;
   int stoponerr ;
   int isContig ;
   int alpha ;
   uint32 width ;
   uint32 height ;
   uint16 bitspersample ;
   uint16 samplesperpixel ;
   uint16 orientation ;
   uint16 req_orientation ;
   uint16 photometric ;
   uint16 *redcmap ;
   uint16 *greencmap ;
   uint16 *bluecmap ;
   int (*get)(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
   union __anonunion_put_25 put ;
   TIFFRGBValue *Map ;
   uint32 **BWmap ;
   uint32 **PALmap ;
   TIFFYCbCrToRGB *ycbcr ;
   TIFFCIELabToRGB *cielab ;
   uint8 *UaToAa ;
   uint8 *Bitdepth16To8 ;
   int row_offset ;
   int col_offset ;
};
typedef int (*TIFFInitMethod)(TIFF * , int  );
struct __anonstruct_TIFFCodec_26 {
   char *name ;
   uint16 scheme ;
   int (*init)(TIFF * , int  ) ;
};
typedef struct __anonstruct_TIFFCodec_26 TIFFCodec;
struct _IO_FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
typedef struct _IO_FILE __FILE;
union __anonunion___value_28 {
   unsigned int __wch ;
   char __wchb[4] ;
};
struct __anonstruct___mbstate_t_27 {
   int __count ;
   union __anonunion___value_28 __value ;
};
typedef struct __anonstruct___mbstate_t_27 __mbstate_t;
struct __anonstruct__G_fpos_t_29 {
   __off_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos_t_29 _G_fpos_t;
struct __anonstruct__G_fpos64_t_30 {
   __off64_t __pos ;
   __mbstate_t __state ;
};
typedef struct __anonstruct__G_fpos64_t_30 _G_fpos64_t;
typedef short _G_int16_t;
typedef int _G_int32_t;
typedef unsigned short _G_uint16_t;
typedef unsigned int _G_uint32_t;
typedef __builtin_va_list __gnuc_va_list;
struct _IO_jump_t;
struct _IO_jump_t;
struct _IO_FILE;
typedef void _IO_lock_t;
struct _IO_marker {
   struct _IO_marker *_next ;
   struct _IO_FILE *_sbuf ;
   int _pos ;
};
enum __codecvt_result {
    __codecvt_ok = 0,
    __codecvt_partial = 1,
    __codecvt_error = 2,
    __codecvt_noconv = 3
} ;
struct _IO_FILE {
   int _flags ;
   char *_IO_read_ptr ;
   char *_IO_read_end ;
   char *_IO_read_base ;
   char *_IO_write_base ;
   char *_IO_write_ptr ;
   char *_IO_write_end ;
   char *_IO_buf_base ;
   char *_IO_buf_end ;
   char *_IO_save_base ;
   char *_IO_backup_base ;
   char *_IO_save_end ;
   struct _IO_marker *_markers ;
   struct _IO_FILE *_chain ;
   int _fileno ;
   int _flags2 ;
   __off_t _old_offset ;
   unsigned short _cur_column ;
   signed char _vtable_offset ;
   char _shortbuf[1] ;
   _IO_lock_t *_lock ;
   __off64_t _offset ;
   void *__pad1 ;
   void *__pad2 ;
   void *__pad3 ;
   void *__pad4 ;
   size_t __pad5 ;
   int _mode ;
   char _unused2[(15U * sizeof(int ) - 4U * sizeof(void *)) - sizeof(size_t )] ;
};
typedef struct _IO_FILE _IO_FILE;
struct _IO_FILE_plus;
struct _IO_FILE_plus;
typedef __ssize_t __io_read_fn(void *__cookie , char *__buf , size_t __nbytes );
typedef __ssize_t __io_write_fn(void *__cookie , char const   *__buf ,
                                size_t __n );
typedef int __io_seek_fn(void *__cookie , __off64_t *__pos , int __w );
typedef int __io_close_fn(void *__cookie );
typedef __gnuc_va_list va_list;
typedef _G_fpos64_t fpos_t;
typedef void (*TIFFErrorHandler)(char const   * , char const   * , va_list  );
typedef void (*TIFFErrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  );
typedef tmsize_t (*TIFFReadWriteProc)(thandle_t  , void * , tmsize_t  );
typedef uint64 (*TIFFSeekProc)(thandle_t  , uint64  , int  );
typedef int (*TIFFCloseProc)(thandle_t  );
typedef uint64 (*TIFFSizeProc)(thandle_t  );
typedef int (*TIFFMapFileProc)(thandle_t  , void **base , toff_t *size );
typedef void (*TIFFUnmapFileProc)(thandle_t  , void *base , toff_t size );
typedef void (*TIFFExtendProc)(TIFF * );
struct _TIFFField;
typedef struct _TIFFField TIFFField;
struct _TIFFFieldArray;
typedef struct _TIFFFieldArray TIFFFieldArray;
typedef int (*TIFFVSetMethod)(TIFF * , uint32  , va_list  );
typedef int (*TIFFVGetMethod)(TIFF * , uint32  , va_list  );
typedef void (*TIFFPrintMethod)(TIFF * , FILE * , long  );
struct __anonstruct_TIFFTagMethods_31 {
   int (*vsetfield)(TIFF * , uint32  , va_list  ) ;
   int (*vgetfield)(TIFF * , uint32  , va_list  ) ;
   void (*printdir)(TIFF * , FILE * , long  ) ;
};
typedef struct __anonstruct_TIFFTagMethods_31 TIFFTagMethods;
struct __anonstruct_TIFFFieldInfo_32 {
   ttag_t field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
};
typedef struct __anonstruct_TIFFFieldInfo_32 TIFFFieldInfo;
struct __anonstruct_TIFFTagValue_33 {
   TIFFField const   *info ;
   int count ;
   void *value ;
};
typedef struct __anonstruct_TIFFTagValue_33 TIFFTagValue;
struct __anonstruct_TIFFDirectory_34 {
   unsigned long td_fieldsset[4] ;
   uint32 td_imagewidth ;
   uint32 td_imagelength ;
   uint32 td_imagedepth ;
   uint32 td_tilewidth ;
   uint32 td_tilelength ;
   uint32 td_tiledepth ;
   uint32 td_subfiletype ;
   uint16 td_bitspersample ;
   uint16 td_sampleformat ;
   uint16 td_compression ;
   uint16 td_photometric ;
   uint16 td_threshholding ;
   uint16 td_fillorder ;
   uint16 td_orientation ;
   uint16 td_samplesperpixel ;
   uint32 td_rowsperstrip ;
   uint16 td_minsamplevalue ;
   uint16 td_maxsamplevalue ;
   double td_sminsamplevalue ;
   double td_smaxsamplevalue ;
   float td_xresolution ;
   float td_yresolution ;
   uint16 td_resolutionunit ;
   uint16 td_planarconfig ;
   float td_xposition ;
   float td_yposition ;
   uint16 td_pagenumber[2] ;
   uint16 *td_colormap[3] ;
   uint16 td_halftonehints[2] ;
   uint16 td_extrasamples ;
   uint16 *td_sampleinfo ;
   uint32 td_stripsperimage ;
   uint32 td_nstrips ;
   uint64 *td_stripoffset ;
   uint64 *td_stripbytecount ;
   int td_stripbytecountsorted ;
   uint16 td_nsubifd ;
   uint64 *td_subifd ;
   uint16 td_ycbcrsubsampling[2] ;
   uint16 td_ycbcrpositioning ;
   uint16 *td_transferfunction[3] ;
   int td_inknameslen ;
   char *td_inknames ;
   int td_customValueCount ;
   TIFFTagValue *td_customValues ;
};
typedef struct __anonstruct_TIFFDirectory_34 TIFFDirectory;
enum __anonenum_TIFFSetGetFieldType_35 {
    TIFF_SETGET_UNDEFINED = 0,
    TIFF_SETGET_ASCII = 1,
    TIFF_SETGET_UINT8 = 2,
    TIFF_SETGET_SINT8 = 3,
    TIFF_SETGET_UINT16 = 4,
    TIFF_SETGET_SINT16 = 5,
    TIFF_SETGET_UINT32 = 6,
    TIFF_SETGET_SINT32 = 7,
    TIFF_SETGET_UINT64 = 8,
    TIFF_SETGET_SINT64 = 9,
    TIFF_SETGET_FLOAT = 10,
    TIFF_SETGET_DOUBLE = 11,
    TIFF_SETGET_IFD8 = 12,
    TIFF_SETGET_INT = 13,
    TIFF_SETGET_UINT16_PAIR = 14,
    TIFF_SETGET_C0_ASCII = 15,
    TIFF_SETGET_C0_UINT8 = 16,
    TIFF_SETGET_C0_SINT8 = 17,
    TIFF_SETGET_C0_UINT16 = 18,
    TIFF_SETGET_C0_SINT16 = 19,
    TIFF_SETGET_C0_UINT32 = 20,
    TIFF_SETGET_C0_SINT32 = 21,
    TIFF_SETGET_C0_UINT64 = 22,
    TIFF_SETGET_C0_SINT64 = 23,
    TIFF_SETGET_C0_FLOAT = 24,
    TIFF_SETGET_C0_DOUBLE = 25,
    TIFF_SETGET_C0_IFD8 = 26,
    TIFF_SETGET_C16_ASCII = 27,
    TIFF_SETGET_C16_UINT8 = 28,
    TIFF_SETGET_C16_SINT8 = 29,
    TIFF_SETGET_C16_UINT16 = 30,
    TIFF_SETGET_C16_SINT16 = 31,
    TIFF_SETGET_C16_UINT32 = 32,
    TIFF_SETGET_C16_SINT32 = 33,
    TIFF_SETGET_C16_UINT64 = 34,
    TIFF_SETGET_C16_SINT64 = 35,
    TIFF_SETGET_C16_FLOAT = 36,
    TIFF_SETGET_C16_DOUBLE = 37,
    TIFF_SETGET_C16_IFD8 = 38,
    TIFF_SETGET_C32_ASCII = 39,
    TIFF_SETGET_C32_UINT8 = 40,
    TIFF_SETGET_C32_SINT8 = 41,
    TIFF_SETGET_C32_UINT16 = 42,
    TIFF_SETGET_C32_SINT16 = 43,
    TIFF_SETGET_C32_UINT32 = 44,
    TIFF_SETGET_C32_SINT32 = 45,
    TIFF_SETGET_C32_UINT64 = 46,
    TIFF_SETGET_C32_SINT64 = 47,
    TIFF_SETGET_C32_FLOAT = 48,
    TIFF_SETGET_C32_DOUBLE = 49,
    TIFF_SETGET_C32_IFD8 = 50,
    TIFF_SETGET_OTHER = 51
} ;
typedef enum __anonenum_TIFFSetGetFieldType_35 TIFFSetGetFieldType;
enum __anonenum_TIFFFieldArrayType_36 {
    tfiatImage = 0,
    tfiatExif = 1,
    tfiatOther = 2
} ;
typedef enum __anonenum_TIFFFieldArrayType_36 TIFFFieldArrayType;
struct _TIFFFieldArray {
   TIFFFieldArrayType type ;
   uint32 allocated_size ;
   uint32 count ;
   TIFFField *fields ;
};
struct _TIFFField {
   uint32 field_tag ;
   short field_readcount ;
   short field_writecount ;
   TIFFDataType field_type ;
   uint32 reserved ;
   TIFFSetGetFieldType set_field_type ;
   TIFFSetGetFieldType get_field_type ;
   unsigned short field_bit ;
   unsigned char field_oktochange ;
   unsigned char field_passcount ;
   char *field_name ;
   TIFFFieldArray *field_subfields ;
};
struct __anonstruct_TIFFDirEntry_37 {
   uint16 tdir_tag ;
   uint16 tdir_type ;
   uint64 tdir_count ;
   uint64 tdir_offset ;
};
typedef struct __anonstruct_TIFFDirEntry_37 TIFFDirEntry;
struct client_info {
   struct client_info *next ;
   void *data ;
   char *name ;
};
typedef struct client_info TIFFClientInfoLink;
typedef unsigned char tidataval_t;
typedef tidataval_t *tidata_t;
typedef void (*TIFFVoidMethod)(TIFF * );
typedef int (*TIFFBoolMethod)(TIFF * );
typedef int (*TIFFPreMethod)(TIFF * , uint16  );
typedef int (*TIFFCodeMethod)(TIFF *tif , uint8 *buf , tmsize_t size ,
                              uint16 sample );
typedef int (*TIFFSeekMethod)(TIFF * , uint32  );
typedef void (*TIFFPostMethod)(TIFF *tif , uint8 *buf , tmsize_t size );
typedef uint32 (*TIFFStripMethod)(TIFF * , uint32  );
typedef void (*TIFFTileMethod)(TIFF * , uint32 * , uint32 * );
union __anonunion_tif_header_38 {
   TIFFHeaderCommon common ;
   TIFFHeaderClassic classic ;
   TIFFHeaderBig big ;
};
struct tiff {
   char *tif_name ;
   int tif_fd ;
   int tif_mode ;
   uint32 tif_flags ;
   uint64 tif_diroff ;
   uint64 tif_nextdiroff ;
   uint64 *tif_dirlist ;
   uint16 tif_dirlistsize ;
   uint16 tif_dirnumber ;
   TIFFDirectory tif_dir ;
   TIFFDirectory tif_customdir ;
   union __anonunion_tif_header_38 tif_header ;
   uint16 tif_header_size ;
   uint32 tif_row ;
   uint16 tif_curdir ;
   uint32 tif_curstrip ;
   uint64 tif_curoff ;
   uint64 tif_dataoff ;
   uint16 tif_nsubifd ;
   uint64 tif_subifdoff ;
   uint32 tif_col ;
   uint32 tif_curtile ;
   tmsize_t tif_tilesize ;
   int tif_decodestatus ;
   int (*tif_fixuptags)(TIFF * ) ;
   int (*tif_setupdecode)(TIFF * ) ;
   int (*tif_predecode)(TIFF * , uint16  ) ;
   int (*tif_setupencode)(TIFF * ) ;
   int tif_encodestatus ;
   int (*tif_preencode)(TIFF * , uint16  ) ;
   int (*tif_postencode)(TIFF * ) ;
   int (*tif_decoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encoderow)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_decodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_encodestrip)(TIFF *tif , uint8 *buf , tmsize_t size ,
                          uint16 sample ) ;
   int (*tif_decodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   int (*tif_encodetile)(TIFF *tif , uint8 *buf , tmsize_t size , uint16 sample ) ;
   void (*tif_close)(TIFF * ) ;
   int (*tif_seek)(TIFF * , uint32  ) ;
   void (*tif_cleanup)(TIFF * ) ;
   uint32 (*tif_defstripsize)(TIFF * , uint32  ) ;
   void (*tif_deftilesize)(TIFF * , uint32 * , uint32 * ) ;
   uint8 *tif_data ;
   tmsize_t tif_scanlinesize ;
   tmsize_t tif_scanlineskew ;
   uint8 *tif_rawdata ;
   tmsize_t tif_rawdatasize ;
   uint8 *tif_rawcp ;
   tmsize_t tif_rawcc ;
   uint8 *tif_base ;
   tmsize_t tif_size ;
   int (*tif_mapproc)(thandle_t  , void **base , toff_t *size ) ;
   void (*tif_unmapproc)(thandle_t  , void *base , toff_t size ) ;
   thandle_t tif_clientdata ;
   tmsize_t (*tif_readproc)(thandle_t  , void * , tmsize_t  ) ;
   tmsize_t (*tif_writeproc)(thandle_t  , void * , tmsize_t  ) ;
   uint64 (*tif_seekproc)(thandle_t  , uint64  , int  ) ;
   int (*tif_closeproc)(thandle_t  ) ;
   uint64 (*tif_sizeproc)(thandle_t  ) ;
   void (*tif_postdecode)(TIFF *tif , uint8 *buf , tmsize_t size ) ;
   TIFFField **tif_fields ;
   uint32 tif_nfields ;
   TIFFField const   *tif_foundfield ;
   TIFFTagMethods tif_tagmethods ;
   TIFFClientInfoLink *tif_clientinfo ;
   TIFFFieldArray *tif_fieldscompat ;
   uint32 tif_nfieldscompat ;
};
extern int select(int __nfds , fd_set * __restrict  __readfds ,
                  fd_set * __restrict  __writefds ,
                  fd_set * __restrict  __exceptfds ,
                  struct timeval * __restrict  __timeout ) ;
extern int pselect(int __nfds , fd_set * __restrict  __readfds ,
                   fd_set * __restrict  __writefds ,
                   fd_set * __restrict  __exceptfds ,
                   struct timespec  const  * __restrict  __timeout ,
                   __sigset_t const   * __restrict  __sigmask ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_major(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_major(unsigned long long __dev ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1\n");
  fflush(_coverage_fout);
  return ((unsigned int )(((__dev >> 8) & 4095ULL) | (unsigned long long )((unsigned int )(__dev >> 32) & 4294963200U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned int gnu_dev_minor(unsigned long long __dev ) ;
__inline extern unsigned int gnu_dev_minor(unsigned long long __dev ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "2\n");
  fflush(_coverage_fout);
  return ((unsigned int )((__dev & 255ULL) | (unsigned long long )((unsigned int )(__dev >> 12) & 4294967040U)));
}
}
__inline extern  __attribute__((__nothrow__)) unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                                                 unsigned int __minor ) ;
__inline extern unsigned long long gnu_dev_makedev(unsigned int __major ,
                                                   unsigned int __minor ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "3\n");
  fflush(_coverage_fout);
  return (((unsigned long long )((__minor & 255U) | ((__major & 4095U) << 8)) | ((unsigned long long )(__minor & 4294967040U) << 12)) | ((unsigned long long )(__major & 4294963200U) << 32));
}
}
extern int fcntl(int __fd , int __cmd  , ...) ;
extern int open(char const   *__file , int __oflag  , ...)  __asm__("open64") __attribute__((__nonnull__(1))) ;
extern int openat(int __fd , char const   *__file , int __oflag  , ...)  __asm__("openat64") __attribute__((__nonnull__(2))) ;
extern int creat(char const   *__file , __mode_t __mode )  __asm__("creat64") __attribute__((__nonnull__(1))) ;
extern int lockf(int __fd , int __cmd , __off64_t __len )  __asm__("lockf64")  ;
extern  __attribute__((__nothrow__)) int posix_fadvise(int __fd ,
                                                       __off64_t __offset ,
                                                       __off64_t __len ,
                                                       int __advise )  __asm__("posix_fadvise64")  ;
extern int posix_fallocate(int __fd , __off64_t __offset , __off64_t __len )  __asm__("posix_fallocate64")  ;
extern  __attribute__((__nothrow__)) void *memcpy(void * __restrict  __dest ,
                                                  void const   * __restrict  __src ,
                                                  size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memmove(void *__dest ,
                                                   void const   *__src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memccpy(void * __restrict  __dest ,
                                                   void const   * __restrict  __src ,
                                                   int __c , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memset(void *__s , int __c ,
                                                  size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int memcmp(void const   *__s1 ,
                                                void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void *memchr(void const   *__s , int __c ,
                                                  size_t __n )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strcat(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strncat(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcmp(char const   *__s1 ,
                                                char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncmp(char const   *__s1 ,
                                                 char const   *__s2 ,
                                                 size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strcoll(char const   *__s1 ,
                                                 char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm(char * __restrict  __dest ,
                                                    char const   * __restrict  __src ,
                                                    size_t __n )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) int strcoll_l(char const   *__s1 ,
                                                   char const   *__s2 ,
                                                   __locale_t __l )  __attribute__((__pure__,
__nonnull__(1,2,3))) ;
extern  __attribute__((__nothrow__)) size_t strxfrm_l(char *__dest ,
                                                      char const   *__src ,
                                                      size_t __n ,
                                                      __locale_t __l )  __attribute__((__nonnull__(2,4))) ;
extern  __attribute__((__nothrow__)) char *strdup(char const   *__s )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strndup(char const   *__string ,
                                                   size_t __n )  __attribute__((__nonnull__(1),
__malloc__)) ;
extern  __attribute__((__nothrow__)) char *strchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strrchr(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strcspn(char const   *__s ,
                                                    char const   *__reject )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) size_t strspn(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strpbrk(char const   *__s ,
                                                   char const   *__accept )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strstr(char const   *__haystack ,
                                                  char const   *__needle )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strtok(char * __restrict  __s ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *__strtok_r(char * __restrict  __s ,
                                                      char const   * __restrict  __delim ,
                                                      char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) char *strtok_r(char * __restrict  __s ,
                                                    char const   * __restrict  __delim ,
                                                    char ** __restrict  __save_ptr )  __attribute__((__nonnull__(2,3))) ;
extern  __attribute__((__nothrow__)) size_t strlen(char const   *__s )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) size_t strnlen(char const   *__string ,
                                                    size_t __maxlen )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *strerror(int __errnum ) ;
extern  __attribute__((__nothrow__)) int strerror_r(int __errnum , char *__buf ,
                                                    size_t __buflen )  __asm__("__xpg_strerror_r") __attribute__((__nonnull__(2))) ;
extern  __attribute__((__nothrow__)) char *strerror_l(int __errnum ,
                                                      __locale_t __l ) ;
extern  __attribute__((__nothrow__)) void __bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) void bcopy(void const   *__src ,
                                                void *__dest , size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) void bzero(void *__s , size_t __n )  __attribute__((__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int bcmp(void const   *__s1 ,
                                              void const   *__s2 , size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *index(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) char *rindex(char const   *__s , int __c )  __attribute__((__pure__,
__nonnull__(1))) ;
extern  __attribute__((__nothrow__)) int ffs(int __i )  __attribute__((__const__)) ;
extern  __attribute__((__nothrow__)) int strcasecmp(char const   *__s1 ,
                                                    char const   *__s2 )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) int strncasecmp(char const   *__s1 ,
                                                     char const   *__s2 ,
                                                     size_t __n )  __attribute__((__pure__,
__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsep(char ** __restrict  __stringp ,
                                                  char const   * __restrict  __delim )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *strsignal(int __sig ) ;
extern  __attribute__((__nothrow__)) char *__stpcpy(char * __restrict  __dest ,
                                                    char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpcpy(char * __restrict  __dest ,
                                                  char const   * __restrict  __src )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *__stpncpy(char * __restrict  __dest ,
                                                     char const   * __restrict  __src ,
                                                     size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern  __attribute__((__nothrow__)) char *stpncpy(char * __restrict  __dest ,
                                                   char const   * __restrict  __src ,
                                                   size_t __n )  __attribute__((__nonnull__(1,2))) ;
extern void *__rawmemchr(void const   *__s , int __c ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) ;
__inline extern size_t __strcspn_c1(char const   *__s , int __reject ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "8\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "9\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "6\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "5\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject) {
        fprintf(_coverage_fout, "4\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "7\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "10\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) ;
__inline extern size_t __strcspn_c2(char const   *__s , int __reject1 ,
                                    int __reject2 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "16\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "17\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "14\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "13\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        fprintf(_coverage_fout, "12\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          fprintf(_coverage_fout, "11\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "15\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "18\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) ;
__inline extern size_t __strcspn_c3(char const   *__s , int __reject1 ,
                                    int __reject2 , int __reject3 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "25\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "26\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "23\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) != 0) {
      fprintf(_coverage_fout, "22\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) != (int const   )__reject1) {
        fprintf(_coverage_fout, "21\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) != (int const   )__reject2) {
          fprintf(_coverage_fout, "20\n");
          fflush(_coverage_fout);
          if ((int const   )*(__s + __result) != (int const   )__reject3) {
            fprintf(_coverage_fout, "19\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "24\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "27\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) ;
__inline extern size_t __strspn_c1(char const   *__s , int __accept ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "31\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "32\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "29\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept) {
      fprintf(_coverage_fout, "28\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "30\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "33\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern size_t __strspn_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "39\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "40\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "37\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      fprintf(_coverage_fout, "34\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "36\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        fprintf(_coverage_fout, "35\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
    }
    fprintf(_coverage_fout, "38\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "41\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern size_t __strspn_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ register size_t __result ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "49\n");
  fflush(_coverage_fout);
  __result = (size_t )0;
  fprintf(_coverage_fout, "50\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "47\n");
    fflush(_coverage_fout);
    if ((int const   )*(__s + __result) == (int const   )__accept1) {
      fprintf(_coverage_fout, "42\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "46\n");
      fflush(_coverage_fout);
      if ((int const   )*(__s + __result) == (int const   )__accept2) {
        fprintf(_coverage_fout, "43\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "45\n");
        fflush(_coverage_fout);
        if ((int const   )*(__s + __result) == (int const   )__accept3) {
          fprintf(_coverage_fout, "44\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      }
    }
    fprintf(_coverage_fout, "48\n");
    fflush(_coverage_fout);
    __result ++;
  }
  fprintf(_coverage_fout, "51\n");
  fflush(_coverage_fout);
  return (__result);
}
}
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) ;
__inline extern char *__strpbrk_c2(char const   *__s , int __accept1 ,
                                   int __accept2 ) 
{ char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "59\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "55\n");
    fflush(_coverage_fout);
    if ((int const   )*__s != 0) {
      fprintf(_coverage_fout, "54\n");
      fflush(_coverage_fout);
      if ((int const   )*__s != (int const   )__accept1) {
        fprintf(_coverage_fout, "53\n");
        fflush(_coverage_fout);
        if ((int const   )*__s != (int const   )__accept2) {
          fprintf(_coverage_fout, "52\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "56\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "60\n");
  fflush(_coverage_fout);
  if ((int const   )*__s == 0) {
    fprintf(_coverage_fout, "57\n");
    fflush(_coverage_fout);
    tmp = (char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "58\n");
    fflush(_coverage_fout);
    tmp = (char *)((unsigned int )__s);
  }
  fprintf(_coverage_fout, "61\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) ;
__inline extern char *__strpbrk_c3(char const   *__s , int __accept1 ,
                                   int __accept2 , int __accept3 ) 
{ char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "70\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "66\n");
    fflush(_coverage_fout);
    if ((int const   )*__s != 0) {
      fprintf(_coverage_fout, "65\n");
      fflush(_coverage_fout);
      if ((int const   )*__s != (int const   )__accept1) {
        fprintf(_coverage_fout, "64\n");
        fflush(_coverage_fout);
        if ((int const   )*__s != (int const   )__accept2) {
          fprintf(_coverage_fout, "63\n");
          fflush(_coverage_fout);
          if ((int const   )*__s != (int const   )__accept3) {
            fprintf(_coverage_fout, "62\n");
            fflush(_coverage_fout);

          } else {
            break;
          }
        } else {
          break;
        }
      } else {
        break;
      }
    } else {
      break;
    }
    fprintf(_coverage_fout, "67\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "71\n");
  fflush(_coverage_fout);
  if ((int const   )*__s == 0) {
    fprintf(_coverage_fout, "68\n");
    fflush(_coverage_fout);
    tmp = (char *)((void *)0);
  } else {
    fprintf(_coverage_fout, "69\n");
    fflush(_coverage_fout);
    tmp = (char *)((unsigned int )__s);
  }
  fprintf(_coverage_fout, "72\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) ;
__inline extern char *__strtok_r_1c(char *__s , char __sep , char **__nextp ) 
{ char *__result ;
  char *tmp ;
  char *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "90\n");
  fflush(_coverage_fout);
  if ((unsigned int )__s == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "73\n");
    fflush(_coverage_fout);
    __s = *__nextp;
  } else {
    fprintf(_coverage_fout, "74\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "91\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "76\n");
    fflush(_coverage_fout);
    if ((int )*__s == (int )__sep) {
      fprintf(_coverage_fout, "75\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "77\n");
    fflush(_coverage_fout);
    __s ++;
  }
  fprintf(_coverage_fout, "92\n");
  fflush(_coverage_fout);
  __result = (char *)((void *)0);
  fprintf(_coverage_fout, "93\n");
  fflush(_coverage_fout);
  if ((int )*__s != 0) {
    fprintf(_coverage_fout, "85\n");
    fflush(_coverage_fout);
    tmp = __s;
    fprintf(_coverage_fout, "86\n");
    fflush(_coverage_fout);
    __s ++;
    fprintf(_coverage_fout, "87\n");
    fflush(_coverage_fout);
    __result = tmp;
    fprintf(_coverage_fout, "88\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "81\n");
      fflush(_coverage_fout);
      if ((int )*__s != 0) {
        fprintf(_coverage_fout, "78\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "82\n");
      fflush(_coverage_fout);
      tmp___0 = __s;
      fprintf(_coverage_fout, "83\n");
      fflush(_coverage_fout);
      __s ++;
      fprintf(_coverage_fout, "84\n");
      fflush(_coverage_fout);
      if ((int )*tmp___0 == (int )__sep) {
        fprintf(_coverage_fout, "79\n");
        fflush(_coverage_fout);
        *(__s + -1) = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "80\n");
        fflush(_coverage_fout);

      }
    }
  } else {
    fprintf(_coverage_fout, "89\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "94\n");
  fflush(_coverage_fout);
  *__nextp = __s;
  fprintf(_coverage_fout, "95\n");
  fflush(_coverage_fout);
  return (__result);
}
}
extern char *__strsep_g(char **__stringp , char const   *__delim ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) ;
__inline extern char *__strsep_1c(char **__s , char __reject ) 
{ register char *__retval ;
  char *tmp ;
  char *tmp___0 ;
  void *tmp___1 ;
  char *tmp___2 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "105\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "106\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "100\n");
    fflush(_coverage_fout);
    tmp___2 = __builtin_strchr(__retval, (int )__reject);
    fprintf(_coverage_fout, "101\n");
    fflush(_coverage_fout);
    tmp___0 = tmp___2;
    fprintf(_coverage_fout, "102\n");
    fflush(_coverage_fout);
    *__s = tmp___0;
    fprintf(_coverage_fout, "103\n");
    fflush(_coverage_fout);
    if ((unsigned int )tmp___0 != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "96\n");
      fflush(_coverage_fout);
      tmp = *__s;
      fprintf(_coverage_fout, "97\n");
      fflush(_coverage_fout);
      (*__s) ++;
      fprintf(_coverage_fout, "98\n");
      fflush(_coverage_fout);
      *tmp = (char )'\000';
    } else {
      fprintf(_coverage_fout, "99\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "104\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "107\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) ;
__inline extern char *__strsep_2c(char **__s , char __reject1 , char __reject2 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "125\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "126\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "121\n");
    fflush(_coverage_fout);
    __cp = __retval;
    fprintf(_coverage_fout, "122\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "118\n");
      fflush(_coverage_fout);
      if ((int )*__cp == 0) {
        fprintf(_coverage_fout, "108\n");
        fflush(_coverage_fout);
        __cp = (char *)((void *)0);
        break;
      } else {
        fprintf(_coverage_fout, "109\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "119\n");
      fflush(_coverage_fout);
      if ((int )*__cp == (int )__reject1) {
        fprintf(_coverage_fout, "110\n");
        fflush(_coverage_fout);
        tmp = __cp;
        fprintf(_coverage_fout, "111\n");
        fflush(_coverage_fout);
        __cp ++;
        fprintf(_coverage_fout, "112\n");
        fflush(_coverage_fout);
        *tmp = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "117\n");
        fflush(_coverage_fout);
        if ((int )*__cp == (int )__reject2) {
          fprintf(_coverage_fout, "113\n");
          fflush(_coverage_fout);
          tmp = __cp;
          fprintf(_coverage_fout, "114\n");
          fflush(_coverage_fout);
          __cp ++;
          fprintf(_coverage_fout, "115\n");
          fflush(_coverage_fout);
          *tmp = (char )'\000';
          break;
        } else {
          fprintf(_coverage_fout, "116\n");
          fflush(_coverage_fout);

        }
      }
      fprintf(_coverage_fout, "120\n");
      fflush(_coverage_fout);
      __cp ++;
    }
    fprintf(_coverage_fout, "123\n");
    fflush(_coverage_fout);
    *__s = __cp;
  } else {
    fprintf(_coverage_fout, "124\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "127\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) ;
__inline extern char *__strsep_3c(char **__s , char __reject1 , char __reject2 ,
                                  char __reject3 ) 
{ register char *__retval ;
  register char *__cp ;
  char *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "149\n");
  fflush(_coverage_fout);
  __retval = *__s;
  fprintf(_coverage_fout, "150\n");
  fflush(_coverage_fout);
  if ((unsigned int )__retval != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "145\n");
    fflush(_coverage_fout);
    __cp = __retval;
    fprintf(_coverage_fout, "146\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "142\n");
      fflush(_coverage_fout);
      if ((int )*__cp == 0) {
        fprintf(_coverage_fout, "128\n");
        fflush(_coverage_fout);
        __cp = (char *)((void *)0);
        break;
      } else {
        fprintf(_coverage_fout, "129\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "143\n");
      fflush(_coverage_fout);
      if ((int )*__cp == (int )__reject1) {
        fprintf(_coverage_fout, "130\n");
        fflush(_coverage_fout);
        tmp = __cp;
        fprintf(_coverage_fout, "131\n");
        fflush(_coverage_fout);
        __cp ++;
        fprintf(_coverage_fout, "132\n");
        fflush(_coverage_fout);
        *tmp = (char )'\000';
        break;
      } else {
        fprintf(_coverage_fout, "141\n");
        fflush(_coverage_fout);
        if ((int )*__cp == (int )__reject2) {
          fprintf(_coverage_fout, "133\n");
          fflush(_coverage_fout);
          tmp = __cp;
          fprintf(_coverage_fout, "134\n");
          fflush(_coverage_fout);
          __cp ++;
          fprintf(_coverage_fout, "135\n");
          fflush(_coverage_fout);
          *tmp = (char )'\000';
          break;
        } else {
          fprintf(_coverage_fout, "140\n");
          fflush(_coverage_fout);
          if ((int )*__cp == (int )__reject3) {
            fprintf(_coverage_fout, "136\n");
            fflush(_coverage_fout);
            tmp = __cp;
            fprintf(_coverage_fout, "137\n");
            fflush(_coverage_fout);
            __cp ++;
            fprintf(_coverage_fout, "138\n");
            fflush(_coverage_fout);
            *tmp = (char )'\000';
            break;
          } else {
            fprintf(_coverage_fout, "139\n");
            fflush(_coverage_fout);

          }
        }
      }
      fprintf(_coverage_fout, "144\n");
      fflush(_coverage_fout);
      __cp ++;
    }
    fprintf(_coverage_fout, "147\n");
    fflush(_coverage_fout);
    *__s = __cp;
  } else {
    fprintf(_coverage_fout, "148\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "151\n");
  fflush(_coverage_fout);
  return (__retval);
}
}
extern  __attribute__((__nothrow__)) void *malloc(size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) void *calloc(size_t __nmemb ,
                                                  size_t __size )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strdup(char const   *__string )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__)) char *__strndup(char const   *__string ,
                                                     size_t __n )  __attribute__((__malloc__)) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_fail(char const   *__assertion ,
                                  char const   *__file , unsigned int __line ,
                                  char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert_perror_fail(int __errnum , char const   *__file ,
                                         unsigned int __line ,
                                         char const   *__function ) ;
extern  __attribute__((__nothrow__,
__noreturn__)) void __assert(char const   *__assertion , char const   *__file ,
                             int __line ) ;
extern  __attribute__((__nothrow__)) void insque(void *__elem , void *__prev ) ;
extern  __attribute__((__nothrow__)) void remque(void *__elem ) ;
extern  __attribute__((__nothrow__)) ENTRY *hsearch(ENTRY __item ,
                                                    ACTION __action ) ;
extern  __attribute__((__nothrow__)) int hcreate(size_t __nel ) ;
extern  __attribute__((__nothrow__)) void hdestroy(void) ;
extern void *tsearch(void const   *__key , void **__rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void *tfind(void const   *__key , void * const  *__rootp ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *tdelete(void const   * __restrict  __key ,
                     void ** __restrict  __rootp ,
                     int (*__compar)(void const   * , void const   * ) ) ;
extern void twalk(void const   *__root ,
                  void (*__action)(void const   *__nodep , VISIT __value ,
                                   int __level ) ) ;
extern void *lfind(void const   *__key , void const   *__base ,
                   size_t *__nmemb , size_t __size ,
                   int (*__compar)(void const   * , void const   * ) ) ;
extern void *lsearch(void const   *__key , void *__base , size_t *__nmemb ,
                     size_t __size , int (*__compar)(void const   * ,
                                                     void const   * ) ) ;
extern struct _IO_FILE_plus _IO_2_1_stdin_ ;
extern struct _IO_FILE_plus _IO_2_1_stdout_ ;
extern struct _IO_FILE_plus _IO_2_1_stderr_ ;
extern int __underflow(_IO_FILE * ) ;
extern int __uflow(_IO_FILE * ) ;
extern int __overflow(_IO_FILE * , int  ) ;
extern int _IO_getc(_IO_FILE *__fp ) ;
extern int _IO_putc(int __c , _IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_feof(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) int _IO_ferror(_IO_FILE *__fp ) ;
extern int _IO_peekc_locked(_IO_FILE *__fp ) ;
extern  __attribute__((__nothrow__)) void _IO_flockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) void _IO_funlockfile(_IO_FILE * ) ;
extern  __attribute__((__nothrow__)) int _IO_ftrylockfile(_IO_FILE * ) ;
extern int _IO_vfscanf(_IO_FILE * __restrict   , char const   * __restrict   ,
                       __gnuc_va_list  , int * __restrict   ) ;
extern int _IO_vfprintf(_IO_FILE * __restrict   , char const   * __restrict   ,
                        __gnuc_va_list  ) ;
extern __ssize_t _IO_padn(_IO_FILE * , int  , __ssize_t  ) ;
extern size_t _IO_sgetn(_IO_FILE * , void * , size_t  ) ;
extern __off64_t _IO_seekoff(_IO_FILE * , __off64_t  , int  , int  ) ;
extern __off64_t _IO_seekpos(_IO_FILE * , __off64_t  , int  ) ;
extern  __attribute__((__nothrow__)) void _IO_free_backup_area(_IO_FILE * ) ;
extern struct _IO_FILE *stdin ;
extern struct _IO_FILE *stdout ;
extern struct _IO_FILE *stderr ;
extern  __attribute__((__nothrow__)) int remove(char const   *__filename ) ;
extern  __attribute__((__nothrow__)) int rename(char const   *__old ,
                                                char const   *__new ) ;
extern  __attribute__((__nothrow__)) int renameat(int __oldfd ,
                                                  char const   *__old ,
                                                  int __newfd ,
                                                  char const   *__new ) ;
extern FILE *tmpfile(void)  __asm__("tmpfile64")  ;
extern  __attribute__((__nothrow__)) char *tmpnam(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tmpnam_r(char *__s ) ;
extern  __attribute__((__nothrow__)) char *tempnam(char const   *__dir ,
                                                   char const   *__pfx )  __attribute__((__malloc__)) ;
extern int fclose(FILE *__stream ) ;
extern int fflush(FILE *__stream ) ;
extern int fflush_unlocked(FILE *__stream ) ;
extern FILE *freopen(char const   * __restrict  __filename ,
                     char const   * __restrict  __modes ,
                     FILE * __restrict  __stream )  __asm__("freopen64")  ;
extern  __attribute__((__nothrow__)) FILE *fdopen(int __fd ,
                                                  char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *fmemopen(void *__s , size_t __len ,
                                                    char const   *__modes ) ;
extern  __attribute__((__nothrow__)) FILE *open_memstream(char **__bufloc ,
                                                          size_t *__sizeloc ) ;
extern  __attribute__((__nothrow__)) void setbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ) ;
extern  __attribute__((__nothrow__)) int setvbuf(FILE * __restrict  __stream ,
                                                 char * __restrict  __buf ,
                                                 int __modes , size_t __n ) ;
extern  __attribute__((__nothrow__)) void setbuffer(FILE * __restrict  __stream ,
                                                    char * __restrict  __buf ,
                                                    size_t __size ) ;
extern  __attribute__((__nothrow__)) void setlinebuf(FILE *__stream ) ;
extern int fprintf(FILE * __restrict  __stream ,
                   char const   * __restrict  __format  , ...) ;
extern int printf(char const   * __restrict  __format  , ...) ;
extern  __attribute__((__nothrow__)) int sprintf(char * __restrict  __s ,
                                                 char const   * __restrict  __format 
                                                 , ...) ;
extern int vfprintf(FILE * __restrict  __s ,
                    char const   * __restrict  __format , __gnuc_va_list __arg ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int vsprintf(char * __restrict  __s ,
                                                  char const   * __restrict  __format ,
                                                  __gnuc_va_list __arg ) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  snprintf)(char * __restrict  __s ,
                                                                             size_t __maxlen ,
                                                                             char const   * __restrict  __format 
                                                                             , ...) ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsnprintf)(char * __restrict  __s ,
                                                                              size_t __maxlen ,
                                                                              char const   * __restrict  __format ,
                                                                              __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  vdprintf)(int __fd ,
                                               char const   * __restrict  __fmt ,
                                               __gnuc_va_list __arg ) ;
extern int ( /* format attribute */  dprintf)(int __fd ,
                                              char const   * __restrict  __fmt 
                                              , ...) ;
extern int fscanf(FILE * __restrict  __stream ,
                  char const   * __restrict  __format  , ...)  __asm__("__isoc99_fscanf")  ;
extern int scanf(char const   * __restrict  __format  , ...)  __asm__("__isoc99_scanf")  ;
extern  __attribute__((__nothrow__)) int sscanf(char const   * __restrict  __s ,
                                                char const   * __restrict  __format 
                                                , ...)  __asm__("__isoc99_sscanf")  ;
extern int ( /* format attribute */  vfscanf)(FILE * __restrict  __s ,
                                              char const   * __restrict  __format ,
                                              __gnuc_va_list __arg )  __asm__("__isoc99_vfscanf")  ;
extern int ( /* format attribute */  vscanf)(char const   * __restrict  __format ,
                                             __gnuc_va_list __arg )  __asm__("__isoc99_vscanf")  ;
extern  __attribute__((__nothrow__)) int ( /* format attribute */  vsscanf)(char const   * __restrict  __s ,
                                                                            char const   * __restrict  __format ,
                                                                            __gnuc_va_list __arg )  __asm__("__isoc99_vsscanf")  ;
extern int fgetc(FILE *__stream ) ;
extern int getc(FILE *__stream ) ;
__inline extern int getchar(void) ;
__inline extern int getc_unlocked(FILE *__fp ) ;
__inline extern int getchar_unlocked(void) ;
__inline extern int fgetc_unlocked(FILE *__fp ) ;
extern int fputc(int __c , FILE *__stream ) ;
extern int putc(int __c , FILE *__stream ) ;
__inline extern int putchar(int __c ) ;
__inline extern int fputc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putc_unlocked(int __c , FILE *__stream ) ;
__inline extern int putchar_unlocked(int __c ) ;
extern int getw(FILE *__stream ) ;
extern int putw(int __w , FILE *__stream ) ;
extern char *fgets(char * __restrict  __s , int __n ,
                   FILE * __restrict  __stream ) ;
extern char *gets(char *__s ) ;
extern __ssize_t __getdelim(char ** __restrict  __lineptr ,
                            size_t * __restrict  __n , int __delimiter ,
                            FILE * __restrict  __stream ) ;
extern __ssize_t getdelim(char ** __restrict  __lineptr ,
                          size_t * __restrict  __n , int __delimiter ,
                          FILE * __restrict  __stream ) ;
extern __ssize_t getline(char ** __restrict  __lineptr ,
                         size_t * __restrict  __n , FILE * __restrict  __stream ) ;
extern int fputs(char const   * __restrict  __s , FILE * __restrict  __stream ) ;
extern int puts(char const   *__s ) ;
extern int ungetc(int __c , FILE *__stream ) ;
extern size_t fread(void * __restrict  __ptr , size_t __size , size_t __n ,
                    FILE * __restrict  __stream ) ;
extern size_t fwrite(void const   * __restrict  __ptr , size_t __size ,
                     size_t __n , FILE * __restrict  __s ) ;
extern size_t fread_unlocked(void * __restrict  __ptr , size_t __size ,
                             size_t __n , FILE * __restrict  __stream ) ;
extern size_t fwrite_unlocked(void const   * __restrict  __ptr , size_t __size ,
                              size_t __n , FILE * __restrict  __stream ) ;
extern int fseek(FILE *__stream , long __off , int __whence ) ;
extern long ftell(FILE *__stream ) ;
extern void rewind(FILE *__stream ) ;
extern int fseeko(FILE *__stream , __off64_t __off , int __whence )  __asm__("fseeko64")  ;
extern __off64_t ftello(FILE *__stream )  __asm__("ftello64")  ;
extern int fgetpos(FILE * __restrict  __stream , fpos_t * __restrict  __pos )  __asm__("fgetpos64")  ;
extern int fsetpos(FILE *__stream , fpos_t const   *__pos )  __asm__("fsetpos64")  ;
extern  __attribute__((__nothrow__)) void clearerr(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int feof(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ferror(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void clearerr_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
extern void perror(char const   *__s ) ;
extern int sys_nerr ;
extern char const   * const  sys_errlist[] ;
extern  __attribute__((__nothrow__)) int fileno(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int fileno_unlocked(FILE *__stream ) ;
extern FILE *popen(char const   *__command , char const   *__modes ) ;
extern int pclose(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) char *ctermid(char *__s ) ;
extern  __attribute__((__nothrow__)) void flockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) int ftrylockfile(FILE *__stream ) ;
extern  __attribute__((__nothrow__)) void funlockfile(FILE *__stream ) ;
__inline extern int vprintf(char const   * __restrict  __fmt ,
                            __gnuc_va_list __arg ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "152\n");
  fflush(_coverage_fout);
  tmp = vfprintf((FILE */* __restrict  */)stdout, __fmt, __arg);
  fprintf(_coverage_fout, "153\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int getchar(void) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "154\n");
  fflush(_coverage_fout);
  tmp = _IO_getc(stdin);
  fprintf(_coverage_fout, "155\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int fgetc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "161\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "162\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "156\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "157\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "158\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "159\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "160\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "163\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int getc_unlocked(FILE *__fp ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "169\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )__fp->_IO_read_ptr >= (unsigned int )__fp->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "170\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "164\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(__fp);
    fprintf(_coverage_fout, "165\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "166\n");
    fflush(_coverage_fout);
    tmp___1 = __fp->_IO_read_ptr;
    fprintf(_coverage_fout, "167\n");
    fflush(_coverage_fout);
    (__fp->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "168\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "171\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int getchar_unlocked(void) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  int tmp___2 ;
  long tmp___3 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "177\n");
  fflush(_coverage_fout);
  tmp___3 = __builtin_expect((long )((unsigned int )stdin->_IO_read_ptr >= (unsigned int )stdin->_IO_read_end),
                             0L);
  fprintf(_coverage_fout, "178\n");
  fflush(_coverage_fout);
  if (tmp___3) {
    fprintf(_coverage_fout, "172\n");
    fflush(_coverage_fout);
    tmp___0 = __uflow(stdin);
    fprintf(_coverage_fout, "173\n");
    fflush(_coverage_fout);
    tmp___2 = tmp___0;
  } else {
    fprintf(_coverage_fout, "174\n");
    fflush(_coverage_fout);
    tmp___1 = stdin->_IO_read_ptr;
    fprintf(_coverage_fout, "175\n");
    fflush(_coverage_fout);
    (stdin->_IO_read_ptr) ++;
    fprintf(_coverage_fout, "176\n");
    fflush(_coverage_fout);
    tmp___2 = (int )*((unsigned char *)tmp___1);
  }
  fprintf(_coverage_fout, "179\n");
  fflush(_coverage_fout);
  return (tmp___2);
}
}
__inline extern int putchar(int __c ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "180\n");
  fflush(_coverage_fout);
  tmp = _IO_putc(__c, stdout);
  fprintf(_coverage_fout, "181\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
__inline extern int fputc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "189\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "190\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "182\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "183\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "184\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "185\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "186\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "187\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "188\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "191\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern int putc_unlocked(int __c , FILE *__stream ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "199\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )__stream->_IO_write_ptr >= (unsigned int )__stream->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "200\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "192\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(__stream, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "193\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "194\n");
    fflush(_coverage_fout);
    tmp___1 = __stream->_IO_write_ptr;
    fprintf(_coverage_fout, "195\n");
    fflush(_coverage_fout);
    (__stream->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "196\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "197\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "198\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "201\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern int putchar_unlocked(int __c ) 
{ long tmp ;
  int tmp___0 ;
  char *tmp___1 ;
  char tmp___2 ;
  int tmp___3 ;
  long tmp___4 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "209\n");
  fflush(_coverage_fout);
  tmp___4 = __builtin_expect((long )((unsigned int )stdout->_IO_write_ptr >= (unsigned int )stdout->_IO_write_end),
                             0L);
  fprintf(_coverage_fout, "210\n");
  fflush(_coverage_fout);
  if (tmp___4) {
    fprintf(_coverage_fout, "202\n");
    fflush(_coverage_fout);
    tmp___0 = __overflow(stdout, (int )((unsigned char )__c));
    fprintf(_coverage_fout, "203\n");
    fflush(_coverage_fout);
    tmp___3 = tmp___0;
  } else {
    fprintf(_coverage_fout, "204\n");
    fflush(_coverage_fout);
    tmp___1 = stdout->_IO_write_ptr;
    fprintf(_coverage_fout, "205\n");
    fflush(_coverage_fout);
    (stdout->_IO_write_ptr) ++;
    fprintf(_coverage_fout, "206\n");
    fflush(_coverage_fout);
    tmp___2 = (char )__c;
    fprintf(_coverage_fout, "207\n");
    fflush(_coverage_fout);
    *tmp___1 = tmp___2;
    fprintf(_coverage_fout, "208\n");
    fflush(_coverage_fout);
    tmp___3 = (int )((unsigned char )tmp___2);
  }
  fprintf(_coverage_fout, "211\n");
  fflush(_coverage_fout);
  return (tmp___3);
}
}
__inline extern  __attribute__((__nothrow__)) int feof_unlocked(FILE *__stream ) ;
__inline extern int feof_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "212\n");
  fflush(_coverage_fout);
  return ((__stream->_flags & 0x10) != 0);
}
}
__inline extern  __attribute__((__nothrow__)) int ferror_unlocked(FILE *__stream ) ;
__inline extern int ferror_unlocked(FILE *__stream ) 
{ 

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "213\n");
  fflush(_coverage_fout);
  return ((__stream->_flags & 0x20) != 0);
}
}
extern char const   *TIFFGetVersion(void) ;
extern TIFFCodec const   *TIFFFindCODEC(uint16  ) ;
extern TIFFCodec *TIFFRegisterCODEC(uint16  , char const   * ,
                                    int (*)(TIFF * , int  ) ) ;
extern void TIFFUnRegisterCODEC(TIFFCodec * ) ;
extern int TIFFIsCODECConfigured(uint16  ) ;
extern TIFFCodec *TIFFGetConfiguredCODECs(void) ;
extern void *_TIFFmalloc(tmsize_t s ) ;
extern void *_TIFFrealloc(void *p , tmsize_t s ) ;
extern void _TIFFmemset(void *p , int v , tmsize_t c ) ;
extern void _TIFFmemcpy(void *d , void const   *s , tmsize_t c ) ;
extern int _TIFFmemcmp(void const   *p1 , void const   *p2 , tmsize_t c ) ;
extern void _TIFFfree(void *p ) ;
extern int TIFFGetTagListCount(TIFF * ) ;
extern uint32 TIFFGetTagListEntry(TIFF * , int tag_index ) ;
extern TIFFField const   *TIFFFindField(TIFF * , uint32  , TIFFDataType  ) ;
extern TIFFField const   *TIFFFieldWithTag(TIFF * , uint32  ) ;
extern TIFFField const   *TIFFFieldWithName(TIFF * , char const   * ) ;
extern TIFFTagMethods *TIFFAccessTagMethods(TIFF * ) ;
extern void *TIFFGetClientInfo(TIFF * , char const   * ) ;
extern void TIFFSetClientInfo(TIFF * , void * , char const   * ) ;
extern void TIFFCleanup(TIFF *tif ) ;
extern void TIFFClose(TIFF *tif ) ;
extern int TIFFFlush(TIFF *tif ) ;
extern int TIFFFlushData(TIFF *tif ) ;
extern int TIFFGetField(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFVGetField(TIFF *tif , uint32 tag , va_list ap ) ;
extern int TIFFGetFieldDefaulted(TIFF *tif , uint32 tag  , ...) ;
extern int TIFFVGetFieldDefaulted(TIFF *tif , uint32 tag , va_list ap ) ;
extern int TIFFReadDirectory(TIFF *tif ) ;
extern int TIFFReadCustomDirectory(TIFF *tif , uint64 diroff ,
                                   TIFFFieldArray const   *infoarray ) ;
extern int TIFFReadEXIFDirectory(TIFF *tif , uint64 diroff ) ;
extern uint64 TIFFScanlineSize64(TIFF *tif ) ;
extern tmsize_t TIFFScanlineSize(TIFF *tif ) ;
extern uint64 TIFFRasterScanlineSize64(TIFF *tif ) ;
extern tmsize_t TIFFRasterScanlineSize(TIFF *tif ) ;
extern uint64 TIFFStripSize64(TIFF *tif ) ;
extern tmsize_t TIFFStripSize(TIFF *tif ) ;
extern uint64 TIFFRawStripSize64(TIFF *tif , uint32 strip ) ;
extern tmsize_t TIFFRawStripSize(TIFF *tif , uint32 strip ) ;
extern uint64 TIFFVStripSize64(TIFF *tif , uint32 nrows ) ;
extern tmsize_t TIFFVStripSize(TIFF *tif , uint32 nrows ) ;
extern uint64 TIFFTileRowSize64(TIFF *tif ) ;
extern tmsize_t TIFFTileRowSize(TIFF *tif ) ;
extern uint64 TIFFTileSize64(TIFF *tif ) ;
extern tmsize_t TIFFTileSize(TIFF *tif ) ;
extern uint64 TIFFVTileSize64(TIFF *tif , uint32 nrows ) ;
extern tmsize_t TIFFVTileSize(TIFF *tif , uint32 nrows ) ;
extern uint32 TIFFDefaultStripSize(TIFF *tif , uint32 request ) ;
extern void TIFFDefaultTileSize(TIFF * , uint32 * , uint32 * ) ;
extern int TIFFFileno(TIFF * ) ;
extern int TIFFSetFileno(TIFF * , int  ) ;
extern thandle_t TIFFClientdata(TIFF * ) ;
extern thandle_t TIFFSetClientdata(TIFF * , thandle_t  ) ;
extern int TIFFGetMode(TIFF * ) ;
extern int TIFFSetMode(TIFF * , int  ) ;
extern int TIFFIsTiled(TIFF * ) ;
extern int TIFFIsByteSwapped(TIFF * ) ;
extern int TIFFIsUpSampled(TIFF * ) ;
extern int TIFFIsMSB2LSB(TIFF * ) ;
extern int TIFFIsBigEndian(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetReadProc(TIFF * ) ;
extern TIFFReadWriteProc TIFFGetWriteProc(TIFF * ) ;
extern TIFFSeekProc TIFFGetSeekProc(TIFF * ) ;
extern TIFFCloseProc TIFFGetCloseProc(TIFF * ) ;
extern TIFFSizeProc TIFFGetSizeProc(TIFF * ) ;
extern TIFFMapFileProc TIFFGetMapFileProc(TIFF * ) ;
extern TIFFUnmapFileProc TIFFGetUnmapFileProc(TIFF * ) ;
extern uint32 TIFFCurrentRow(TIFF * ) ;
extern uint16 TIFFCurrentDirectory(TIFF * ) ;
extern uint16 TIFFNumberOfDirectories(TIFF * ) ;
extern uint64 TIFFCurrentDirOffset(TIFF * ) ;
extern uint32 TIFFCurrentStrip(TIFF * ) ;
extern uint32 TIFFCurrentTile(TIFF *tif ) ;
extern int TIFFReadBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
extern int TIFFWriteBufferSetup(TIFF *tif , void *bp , tmsize_t size ) ;
extern int TIFFSetupStrips(TIFF * ) ;
extern int TIFFWriteCheck(TIFF * , int  , char const   * ) ;
extern void TIFFFreeDirectory(TIFF * ) ;
extern int TIFFCreateDirectory(TIFF * ) ;
extern int TIFFLastDirectory(TIFF * ) ;
extern int TIFFSetDirectory(TIFF * , uint16  ) ;
extern int TIFFSetSubDirectory(TIFF * , uint64  ) ;
extern int TIFFUnlinkDirectory(TIFF * , uint16  ) ;
extern int TIFFSetField(TIFF * , uint32   , ...) ;
extern int TIFFVSetField(TIFF * , uint32  , va_list  ) ;
int TIFFWriteDirectory(TIFF *tif ) ;
int TIFFCheckpointDirectory(TIFF *tif ) ;
int TIFFRewriteDirectory(TIFF *tif ) ;
extern void TIFFPrintDirectory(TIFF * , FILE * , long  ) ;
extern int TIFFReadScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) ;
extern int TIFFWriteScanline(TIFF *tif , void *buf , uint32 row , uint16 sample ) ;
extern int TIFFReadRGBAImage(TIFF * , uint32  , uint32  , uint32 * , int  ) ;
extern int TIFFReadRGBAImageOriented(TIFF * , uint32  , uint32  , uint32 * ,
                                     int  , int  ) ;
extern int TIFFReadRGBAStrip(TIFF * , uint32  , uint32 * ) ;
extern int TIFFReadRGBATile(TIFF * , uint32  , uint32  , uint32 * ) ;
extern int TIFFRGBAImageOK(TIFF * , char * ) ;
extern int TIFFRGBAImageBegin(TIFFRGBAImage * , TIFF * , int  , char * ) ;
extern int TIFFRGBAImageGet(TIFFRGBAImage * , uint32 * , uint32  , uint32  ) ;
extern void TIFFRGBAImageEnd(TIFFRGBAImage * ) ;
extern TIFF *TIFFOpen(char const   * , char const   * ) ;
extern TIFF *TIFFFdOpen(int  , char const   * , char const   * ) ;
extern TIFF *TIFFClientOpen(char const   * , char const   * , thandle_t  ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            tmsize_t (*)(thandle_t  , void * , tmsize_t  ) ,
                            uint64 (*)(thandle_t  , uint64  , int  ) ,
                            int (*)(thandle_t  ) , uint64 (*)(thandle_t  ) ,
                            int (*)(thandle_t  , void **base , toff_t *size ) ,
                            void (*)(thandle_t  , void *base , toff_t size ) ) ;
extern char const   *TIFFFileName(TIFF * ) ;
extern char const   *TIFFSetFileName(TIFF * , char const   * ) ;
extern void TIFFError(char const   * , char const   *  , ...) ;
extern void TIFFErrorExt(thandle_t  , char const   * , char const   *  , ...) ;
extern void TIFFWarning(char const   * , char const   *  , ...) ;
extern void TIFFWarningExt(thandle_t  , char const   * , char const   *  , ...) ;
extern TIFFErrorHandler TIFFSetErrorHandler(void (*)(char const   * ,
                                                     char const   * , va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetErrorHandlerExt(void (*)(thandle_t  ,
                                                           char const   * ,
                                                           char const   * ,
                                                           va_list  ) ) ;
extern TIFFErrorHandler TIFFSetWarningHandler(void (*)(char const   * ,
                                                       char const   * ,
                                                       va_list  ) ) ;
extern TIFFErrorHandlerExt TIFFSetWarningHandlerExt(void (*)(thandle_t  ,
                                                             char const   * ,
                                                             char const   * ,
                                                             va_list  ) ) ;
extern TIFFExtendProc TIFFSetTagExtender(void (*)(TIFF * ) ) ;
extern uint32 TIFFComputeTile(TIFF *tif , uint32 x , uint32 y , uint32 z ,
                              uint16 s ) ;
extern int TIFFCheckTile(TIFF *tif , uint32 x , uint32 y , uint32 z , uint16 s ) ;
extern uint32 TIFFNumberOfTiles(TIFF * ) ;
extern tmsize_t TIFFReadTile(TIFF *tif , void *buf , uint32 x , uint32 y ,
                             uint32 z , uint16 s ) ;
extern tmsize_t TIFFWriteTile(TIFF *tif , void *buf , uint32 x , uint32 y ,
                              uint32 z , uint16 s ) ;
extern uint32 TIFFComputeStrip(TIFF * , uint32  , uint16  ) ;
extern uint32 TIFFNumberOfStrips(TIFF * ) ;
extern tmsize_t TIFFReadEncodedStrip(TIFF *tif , uint32 strip , void *buf ,
                                     tmsize_t size ) ;
extern tmsize_t TIFFReadRawStrip(TIFF *tif , uint32 strip , void *buf ,
                                 tmsize_t size ) ;
extern tmsize_t TIFFReadEncodedTile(TIFF *tif , uint32 tile , void *buf ,
                                    tmsize_t size ) ;
extern tmsize_t TIFFReadRawTile(TIFF *tif , uint32 tile , void *buf ,
                                tmsize_t size ) ;
extern tmsize_t TIFFWriteEncodedStrip(TIFF *tif , uint32 strip , void *data ,
                                      tmsize_t cc ) ;
extern tmsize_t TIFFWriteRawStrip(TIFF *tif , uint32 strip , void *data ,
                                  tmsize_t cc ) ;
extern tmsize_t TIFFWriteEncodedTile(TIFF *tif , uint32 tile , void *data ,
                                     tmsize_t cc ) ;
extern tmsize_t TIFFWriteRawTile(TIFF *tif , uint32 tile , void *data ,
                                 tmsize_t cc ) ;
extern int TIFFDataWidth(TIFFDataType  ) ;
extern void TIFFSetWriteOffset(TIFF *tif , uint64 off ) ;
extern void TIFFSwabShort(uint16 * ) ;
extern void TIFFSwabLong(uint32 * ) ;
extern void TIFFSwabLong8(uint64 * ) ;
extern void TIFFSwabFloat(float * ) ;
extern void TIFFSwabDouble(double * ) ;
extern void TIFFSwabArrayOfShort(uint16 *wp , tmsize_t n ) ;
extern void TIFFSwabArrayOfTriples(uint8 *tp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong(uint32 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfLong8(uint64 *lp , tmsize_t n ) ;
extern void TIFFSwabArrayOfFloat(float *fp , tmsize_t n ) ;
extern void TIFFSwabArrayOfDouble(double *dp , tmsize_t n ) ;
extern void TIFFReverseBits(uint8 *cp , tmsize_t n ) ;
extern unsigned char const   *TIFFGetBitRevTable(int  ) ;
extern double LogL16toY(int  ) ;
extern double LogL10toY(int  ) ;
extern void XYZtoRGB24(float * , uint8 * ) ;
extern int uv_decode(double * , double * , int  ) ;
extern void LogLuv24toXYZ(uint32  , float * ) ;
extern void LogLuv32toXYZ(uint32  , float * ) ;
extern int LogL16fromY(double  , int  ) ;
extern int LogL10fromY(double  , int  ) ;
extern int uv_encode(double  , double  , int  ) ;
extern uint32 LogLuv24fromXYZ(float * , int  ) ;
extern uint32 LogLuv32fromXYZ(float * , int  ) ;
extern int TIFFCIELabToRGBInit(TIFFCIELabToRGB * , TIFFDisplay * , float * ) ;
extern void TIFFCIELabToXYZ(TIFFCIELabToRGB * , uint32  , int32  , int32  ,
                            float * , float * , float * ) ;
extern void TIFFXYZToRGB(TIFFCIELabToRGB * , float  , float  , float  ,
                         uint32 * , uint32 * , uint32 * ) ;
extern int TIFFYCbCrToRGBInit(TIFFYCbCrToRGB * , float * , float * ) ;
extern void TIFFYCbCrtoRGB(TIFFYCbCrToRGB * , uint32  , int32  , int32  ,
                           uint32 * , uint32 * , uint32 * ) ;
extern int TIFFMergeFieldInfo(TIFF * , TIFFFieldInfo const   * , uint32  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfo(TIFF * , uint32  ,
                                                TIFFDataType  ) ;
extern TIFFFieldInfo const   *TIFFFindFieldInfoByName(TIFF * , char const   * ,
                                                      TIFFDataType  ) ;
extern TIFFFieldArray const   *_TIFFGetFields(void) ;
extern TIFFFieldArray const   *_TIFFGetExifFields(void) ;
extern void _TIFFSetupFields(TIFF *tif , TIFFFieldArray const   *infoarray ) ;
extern void _TIFFPrintFieldInfo(TIFF * , FILE * ) ;
extern int _TIFFMergeFields(TIFF * , TIFFField const   * , uint32  ) ;
extern TIFFField const   *_TIFFFindOrRegisterField(TIFF * , uint32  ,
                                                   TIFFDataType  ) ;
extern TIFFField *_TIFFCreateAnonField(TIFF * , uint32  , TIFFDataType  ) ;
extern int _TIFFgetMode(char const   *mode , char const   *module ) ;
extern int _TIFFNoRowEncode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoStripEncode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoTileEncode(TIFF * , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoRowDecode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoStripDecode(TIFF *tif , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern int _TIFFNoTileDecode(TIFF * , uint8 *pp , tmsize_t cc , uint16 s ) ;
extern void _TIFFNoPostDecode(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern int _TIFFNoPreCode(TIFF *tif , uint16 s ) ;
extern int _TIFFNoSeek(TIFF *tif , uint32 off ) ;
extern void _TIFFSwab16BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab24BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab32BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern void _TIFFSwab64BitData(TIFF *tif , uint8 *buf , tmsize_t cc ) ;
extern int TIFFFlushData1(TIFF *tif ) ;
extern int TIFFDefaultDirectory(TIFF *tif ) ;
extern void _TIFFSetDefaultCompressionState(TIFF *tif ) ;
extern int TIFFSetCompressionScheme(TIFF *tif , int scheme ) ;
extern int TIFFSetDefaultCompressionState(TIFF *tif ) ;
extern uint32 _TIFFDefaultStripSize(TIFF *tif , uint32 s ) ;
extern void _TIFFDefaultTileSize(TIFF *tif , uint32 *tw , uint32 *th ) ;
extern int _TIFFDataSize(TIFFDataType type ) ;
extern void _TIFFsetByteArray(void ** , void * , uint32  ) ;
extern void _TIFFsetString(char ** , char * ) ;
extern void _TIFFsetShortArray(uint16 ** , uint16 * , uint32  ) ;
extern void _TIFFsetLongArray(uint32 ** , uint32 * , uint32  ) ;
extern void _TIFFsetFloatArray(float ** , float * , uint32  ) ;
extern void _TIFFsetDoubleArray(double ** , double * , uint32  ) ;
extern void _TIFFprintAscii(FILE * , char const   * ) ;
extern void _TIFFprintAsciiTag(FILE * , char const   * , char const   * ) ;
extern void (*_TIFFwarningHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFerrorHandler)(char const   * , char const   * , va_list  ) ;
extern void (*_TIFFwarningHandlerExt)(thandle_t  , char const   * ,
                                      char const   * , va_list  ) ;
extern void (*_TIFFerrorHandlerExt)(thandle_t  , char const   * ,
                                    char const   * , va_list  ) ;
extern void *_TIFFCheckMalloc(TIFF *tif , tmsize_t nmemb , tmsize_t elem_size ,
                              char const   *what ) ;
extern void *_TIFFCheckRealloc(TIFF *tif , void *buffer , tmsize_t nmemb ,
                               tmsize_t elem_size , char const   *what ) ;
extern double _TIFFUInt64ToDouble(uint64  ) ;
extern float _TIFFUInt64ToFloat(uint64  ) ;
extern int TIFFInitDumpMode(TIFF * , int  ) ;
extern int TIFFInitPackBits(TIFF * , int  ) ;
extern int TIFFInitCCITTRLE(TIFF * , int  ) ;
extern int TIFFInitCCITTRLEW(TIFF * , int  ) ;
extern int TIFFInitCCITTFax3(TIFF * , int  ) ;
extern int TIFFInitCCITTFax4(TIFF * , int  ) ;
extern int TIFFInitThunderScan(TIFF * , int  ) ;
extern int TIFFInitNeXT(TIFF * , int  ) ;
extern int TIFFInitLZW(TIFF * , int  ) ;
extern int TIFFInitZIP(TIFF * , int  ) ;
extern int TIFFInitPixarLog(TIFF * , int  ) ;
extern int TIFFInitSGILog(TIFF * , int  ) ;
extern TIFFCodec _TIFFBuiltinCODECS[] ;
static int TIFFWriteDirectorySec(TIFF *tif , int isimage , int imagedone ,
                                 uint64 *pdiroff ) ;
static int TIFFWriteDirectoryTagSampleformatPerSample(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag , double value ) ;
static int TIFFWriteDirectoryTagAscii(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      uint32 count , char *value ) ;
static int TIFFWriteDirectoryTagUndefinedArray(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , uint8 *value ) ;
static int TIFFWriteDirectoryTagByte(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint8 value ) ;
static int TIFFWriteDirectoryTagByteArray(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint8 *value ) ;
static int TIFFWriteDirectoryTagBytePerSample(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint8 value ) ;
static int TIFFWriteDirectoryTagSbyte(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      int8 value ) ;
static int TIFFWriteDirectoryTagSbyteArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , int8 *value ) ;
static int TIFFWriteDirectoryTagSbytePerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               int8 value ) ;
static int TIFFWriteDirectoryTagShort(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      uint16 value ) ;
static int TIFFWriteDirectoryTagShortArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , uint16 *value ) ;
static int TIFFWriteDirectoryTagShortPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint16 value ) ;
static int TIFFWriteDirectoryTagSshort(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir , uint16 tag ,
                                       int16 value ) ;
static int TIFFWriteDirectoryTagSshortArray(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , int16 *value ) ;
static int TIFFWriteDirectoryTagSshortPerSample(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                int16 value ) ;
static int TIFFWriteDirectoryTagLong(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint32 value ) ;
static int TIFFWriteDirectoryTagLongArray(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint32 *value ) ;
static int TIFFWriteDirectoryTagLongPerSample(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint32 value ) ;
static int TIFFWriteDirectoryTagSlong(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      int32 value ) ;
static int TIFFWriteDirectoryTagSlongArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , int32 *value ) ;
static int TIFFWriteDirectoryTagSlongPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               int32 value ) ;
static int TIFFWriteDirectoryTagLong8(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      uint64 value ) ;
static int TIFFWriteDirectoryTagLong8Array(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , uint64 *value ) ;
static int TIFFWriteDirectoryTagSlong8(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir , uint16 tag ,
                                       int64 value ) ;
static int TIFFWriteDirectoryTagSlong8Array(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , int64 *value ) ;
static int TIFFWriteDirectoryTagRational(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir , uint16 tag ,
                                         double value ) ;
static int TIFFWriteDirectoryTagRationalArray(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint32 count , float *value ) ;
static int TIFFWriteDirectoryTagSrationalArray(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , float *value ) ;
static int TIFFWriteDirectoryTagFloat(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      float value ) ;
static int TIFFWriteDirectoryTagFloatArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , float *value ) ;
static int TIFFWriteDirectoryTagFloatPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               float value ) ;
static int TIFFWriteDirectoryTagDouble(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir , uint16 tag ,
                                       double value ) ;
static int TIFFWriteDirectoryTagDoubleArray(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , double *value ) ;
static int TIFFWriteDirectoryTagDoublePerSample(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                double value ) ;
static int TIFFWriteDirectoryTagIfdArray(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir , uint16 tag ,
                                         uint32 count , uint32 *value ) ;
static int TIFFWriteDirectoryTagIfd8Array(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint64 *value ) ;
static int TIFFWriteDirectoryTagShortLong(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 value ) ;
static int TIFFWriteDirectoryTagLongLong8Array(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , uint64 *value ) ;
static int TIFFWriteDirectoryTagShortLongLong8Array(TIFF *tif , uint32 *ndir ,
                                                    TIFFDirEntry *dir ,
                                                    uint16 tag , uint32 count ,
                                                    uint64 *value ) ;
static int TIFFWriteDirectoryTagColormap(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir ) ;
static int TIFFWriteDirectoryTagTransferfunction(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ) ;
static int TIFFWriteDirectoryTagSubifd(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir ) ;
static int TIFFWriteDirectoryTagCheckedAscii(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             uint32 count , char *value ) ;
static int TIFFWriteDirectoryTagCheckedUndefinedArray(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag ,
                                                      uint32 count ,
                                                      uint8 *value ) ;
static int TIFFWriteDirectoryTagCheckedByte(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint8 value ) ;
static int TIFFWriteDirectoryTagCheckedByteArray(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint8 *value ) ;
static int TIFFWriteDirectoryTagCheckedSbyte(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             int8 value ) ;
static int TIFFWriteDirectoryTagCheckedSbyteArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  int8 *value ) ;
static int TIFFWriteDirectoryTagCheckedShort(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             uint16 value ) ;
static int TIFFWriteDirectoryTagCheckedShortArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  uint16 *value ) ;
static int TIFFWriteDirectoryTagCheckedSshort(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              int16 value ) ;
static int TIFFWriteDirectoryTagCheckedSshortArray(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   int16 *value ) ;
static int TIFFWriteDirectoryTagCheckedLong(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 value ) ;
static int TIFFWriteDirectoryTagCheckedLongArray(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint32 *value ) ;
static int TIFFWriteDirectoryTagCheckedSlong(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             int32 value ) ;
static int TIFFWriteDirectoryTagCheckedSlongArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  int32 *value ) ;
static int TIFFWriteDirectoryTagCheckedLong8(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             uint64 value ) ;
static int TIFFWriteDirectoryTagCheckedLong8Array(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  uint64 *value ) ;
static int TIFFWriteDirectoryTagCheckedSlong8(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              int64 value ) ;
static int TIFFWriteDirectoryTagCheckedSlong8Array(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   int64 *value ) ;
static int TIFFWriteDirectoryTagCheckedRational(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                double value ) ;
static int TIFFWriteDirectoryTagCheckedRationalArray(TIFF *tif , uint32 *ndir ,
                                                     TIFFDirEntry *dir ,
                                                     uint16 tag , uint32 count ,
                                                     float *value ) ;
static int TIFFWriteDirectoryTagCheckedSrationalArray(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag ,
                                                      uint32 count ,
                                                      float *value ) ;
static int TIFFWriteDirectoryTagCheckedFloat(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             float value ) ;
static int TIFFWriteDirectoryTagCheckedFloatArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  float *value ) ;
static int TIFFWriteDirectoryTagCheckedDouble(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              double value ) ;
static int TIFFWriteDirectoryTagCheckedDoubleArray(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   double *value ) ;
static int TIFFWriteDirectoryTagCheckedIfdArray(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                uint32 count , uint32 *value ) ;
static int TIFFWriteDirectoryTagCheckedIfd8Array(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint64 *value ) ;
static int TIFFWriteDirectoryTagData(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint16 datatype , uint32 count ,
                                     uint32 datalength , void *data ) ;
static int TIFFLinkDirectory(TIFF *tif ) ;
int TIFFWriteDirectory(TIFF *tif ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "214\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectorySec(tif, 1, 1, (uint64 *)((void *)0));
  fprintf(_coverage_fout, "215\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
int TIFFCheckpointDirectory(TIFF *tif ) 
{ int rc ;
  uint64 tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "218\n");
  fflush(_coverage_fout);
  if ((unsigned int )tif->tif_dir.td_stripoffset == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "216\n");
    fflush(_coverage_fout);
    TIFFSetupStrips(tif);
  } else {
    fprintf(_coverage_fout, "217\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "219\n");
  fflush(_coverage_fout);
  rc = TIFFWriteDirectorySec(tif, 1, 0, (uint64 *)((void *)0));
  fprintf(_coverage_fout, "220\n");
  fflush(_coverage_fout);
  tmp = (*(tif->tif_seekproc))(tif->tif_clientdata, 0ULL, 2);
  fprintf(_coverage_fout, "221\n");
  fflush(_coverage_fout);
  TIFFSetWriteOffset(tif, tmp);
  fprintf(_coverage_fout, "222\n");
  fflush(_coverage_fout);
  return (rc);
}
}
int TIFFWriteCustomDirectory(TIFF *tif , uint64 *pdiroff ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "223\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectorySec(tif, 0, 0, pdiroff);
  fprintf(_coverage_fout, "224\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
int TIFFRewriteDirectory(TIFF *tif ) ;
static char const   module[21]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'R',      (char const   )'e',      (char const   )'w',      (char const   )'r', 
        (char const   )'i',      (char const   )'t',      (char const   )'e',      (char const   )'D', 
        (char const   )'i',      (char const   )'r',      (char const   )'e',      (char const   )'c', 
        (char const   )'t',      (char const   )'o',      (char const   )'r',      (char const   )'y', 
        (char const   )'\000'};
int TIFFRewriteDirectory(TIFF *tif ) 
{ int tmp ;
  tmsize_t tmp___0 ;
  uint32 nextdir ;
  uint16 dircount ;
  uint32 nextnextdir ;
  uint64 tmp___1 ;
  tmsize_t tmp___2 ;
  tmsize_t tmp___3 ;
  uint32 m ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  uint64 nextdir___0 ;
  uint64 dircount64 ;
  uint16 dircount___0 ;
  uint64 nextnextdir___0 ;
  uint64 tmp___6 ;
  tmsize_t tmp___7 ;
  tmsize_t tmp___8 ;
  uint64 m___0 ;
  tmsize_t tmp___9 ;
  int tmp___10 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "319\n");
  fflush(_coverage_fout);
  if (tif->tif_diroff == 0ULL) {
    fprintf(_coverage_fout, "225\n");
    fflush(_coverage_fout);
    tmp = TIFFWriteDirectory(tif);
    fprintf(_coverage_fout, "226\n");
    fflush(_coverage_fout);
    return (tmp);
  } else {
    fprintf(_coverage_fout, "227\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "320\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "270\n");
    fflush(_coverage_fout);
    if ((uint64 )tif->tif_header.classic.tiff_diroff == tif->tif_diroff) {
      fprintf(_coverage_fout, "231\n");
      fflush(_coverage_fout);
      tif->tif_header.classic.tiff_diroff = 0U;
      fprintf(_coverage_fout, "232\n");
      fflush(_coverage_fout);
      tif->tif_diroff = 0ULL;
      fprintf(_coverage_fout, "233\n");
      fflush(_coverage_fout);
      (*(tif->tif_seekproc))(tif->tif_clientdata, 4ULL, 0);
      fprintf(_coverage_fout, "234\n");
      fflush(_coverage_fout);
      tmp___0 = (*(tif->tif_writeproc))(tif->tif_clientdata,
                                        (void *)(& tif->tif_header.classic.tiff_diroff),
                                        4L);
      fprintf(_coverage_fout, "235\n");
      fflush(_coverage_fout);
      if (tmp___0 == 4L) {
        fprintf(_coverage_fout, "228\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "229\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                     "Error updating TIFF header");
        fprintf(_coverage_fout, "230\n");
        fflush(_coverage_fout);
        return (0);
      }
    } else {
      fprintf(_coverage_fout, "268\n");
      fflush(_coverage_fout);
      nextdir = tif->tif_header.classic.tiff_diroff;
      fprintf(_coverage_fout, "269\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "259\n");
        fflush(_coverage_fout);
        tmp___1 = (*(tif->tif_seekproc))(tif->tif_clientdata,
                                         (unsigned long long )nextdir, 0);
        fprintf(_coverage_fout, "260\n");
        fflush(_coverage_fout);
        if (tmp___1 == (uint64 )nextdir) {
          fprintf(_coverage_fout, "239\n");
          fflush(_coverage_fout);
          tmp___2 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                           (void *)(& dircount), 2L);
          fprintf(_coverage_fout, "240\n");
          fflush(_coverage_fout);
          if (tmp___2 == 2L) {
            fprintf(_coverage_fout, "236\n");
            fflush(_coverage_fout);

          } else {
            fprintf(_coverage_fout, "237\n");
            fflush(_coverage_fout);
            TIFFErrorExt(tif->tif_clientdata, module,
                         "Error fetching directory count");
            fprintf(_coverage_fout, "238\n");
            fflush(_coverage_fout);
            return (0);
          }
        } else {
          fprintf(_coverage_fout, "241\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module,
                       "Error fetching directory count");
          fprintf(_coverage_fout, "242\n");
          fflush(_coverage_fout);
          return (0);
        }
        fprintf(_coverage_fout, "261\n");
        fflush(_coverage_fout);
        if (tif->tif_flags & 128U) {
          fprintf(_coverage_fout, "243\n");
          fflush(_coverage_fout);
          TIFFSwabShort(& dircount);
        } else {
          fprintf(_coverage_fout, "244\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "262\n");
        fflush(_coverage_fout);
        (*(tif->tif_seekproc))(tif->tif_clientdata,
                               (unsigned long long )((nextdir + 2U) + (uint32 )((int )dircount * 12)),
                               0);
        fprintf(_coverage_fout, "263\n");
        fflush(_coverage_fout);
        tmp___3 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                         (void *)(& nextnextdir), 4L);
        fprintf(_coverage_fout, "264\n");
        fflush(_coverage_fout);
        if (tmp___3 == 4L) {
          fprintf(_coverage_fout, "245\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "246\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module,
                       "Error fetching directory link");
          fprintf(_coverage_fout, "247\n");
          fflush(_coverage_fout);
          return (0);
        }
        fprintf(_coverage_fout, "265\n");
        fflush(_coverage_fout);
        if (tif->tif_flags & 128U) {
          fprintf(_coverage_fout, "248\n");
          fflush(_coverage_fout);
          TIFFSwabLong(& nextnextdir);
        } else {
          fprintf(_coverage_fout, "249\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "266\n");
        fflush(_coverage_fout);
        if ((uint64 )nextnextdir == tif->tif_diroff) {
          fprintf(_coverage_fout, "253\n");
          fflush(_coverage_fout);
          m = 0U;
          fprintf(_coverage_fout, "254\n");
          fflush(_coverage_fout);
          (*(tif->tif_seekproc))(tif->tif_clientdata,
                                 (unsigned long long )((nextdir + 2U) + (uint32 )((int )dircount * 12)),
                                 0);
          fprintf(_coverage_fout, "255\n");
          fflush(_coverage_fout);
          tmp___4 = (*(tif->tif_writeproc))(tif->tif_clientdata, (void *)(& m),
                                            4L);
          fprintf(_coverage_fout, "256\n");
          fflush(_coverage_fout);
          if (tmp___4 == 4L) {
            fprintf(_coverage_fout, "250\n");
            fflush(_coverage_fout);

          } else {
            fprintf(_coverage_fout, "251\n");
            fflush(_coverage_fout);
            TIFFErrorExt(tif->tif_clientdata, module,
                         "Error writing directory link");
            fprintf(_coverage_fout, "252\n");
            fflush(_coverage_fout);
            return (0);
          }
          fprintf(_coverage_fout, "257\n");
          fflush(_coverage_fout);
          tif->tif_diroff = 0ULL;
          break;
        } else {
          fprintf(_coverage_fout, "258\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "267\n");
        fflush(_coverage_fout);
        nextdir = nextnextdir;
      }
    }
  } else {
    fprintf(_coverage_fout, "318\n");
    fflush(_coverage_fout);
    if (tif->tif_header.big.tiff_diroff == tif->tif_diroff) {
      fprintf(_coverage_fout, "274\n");
      fflush(_coverage_fout);
      tif->tif_header.big.tiff_diroff = 0ULL;
      fprintf(_coverage_fout, "275\n");
      fflush(_coverage_fout);
      tif->tif_diroff = 0ULL;
      fprintf(_coverage_fout, "276\n");
      fflush(_coverage_fout);
      (*(tif->tif_seekproc))(tif->tif_clientdata, 8ULL, 0);
      fprintf(_coverage_fout, "277\n");
      fflush(_coverage_fout);
      tmp___5 = (*(tif->tif_writeproc))(tif->tif_clientdata,
                                        (void *)(& tif->tif_header.big.tiff_diroff),
                                        8L);
      fprintf(_coverage_fout, "278\n");
      fflush(_coverage_fout);
      if (tmp___5 == 8L) {
        fprintf(_coverage_fout, "271\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "272\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                     "Error updating TIFF header");
        fprintf(_coverage_fout, "273\n");
        fflush(_coverage_fout);
        return (0);
      }
    } else {
      fprintf(_coverage_fout, "316\n");
      fflush(_coverage_fout);
      nextdir___0 = tif->tif_header.big.tiff_diroff;
      fprintf(_coverage_fout, "317\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "305\n");
        fflush(_coverage_fout);
        tmp___6 = (*(tif->tif_seekproc))(tif->tif_clientdata, nextdir___0, 0);
        fprintf(_coverage_fout, "306\n");
        fflush(_coverage_fout);
        if (tmp___6 == nextdir___0) {
          fprintf(_coverage_fout, "282\n");
          fflush(_coverage_fout);
          tmp___7 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                           (void *)(& dircount64), 8L);
          fprintf(_coverage_fout, "283\n");
          fflush(_coverage_fout);
          if (tmp___7 == 8L) {
            fprintf(_coverage_fout, "279\n");
            fflush(_coverage_fout);

          } else {
            fprintf(_coverage_fout, "280\n");
            fflush(_coverage_fout);
            TIFFErrorExt(tif->tif_clientdata, module,
                         "Error fetching directory count");
            fprintf(_coverage_fout, "281\n");
            fflush(_coverage_fout);
            return (0);
          }
        } else {
          fprintf(_coverage_fout, "284\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module,
                       "Error fetching directory count");
          fprintf(_coverage_fout, "285\n");
          fflush(_coverage_fout);
          return (0);
        }
        fprintf(_coverage_fout, "307\n");
        fflush(_coverage_fout);
        if (tif->tif_flags & 128U) {
          fprintf(_coverage_fout, "286\n");
          fflush(_coverage_fout);
          TIFFSwabLong8(& dircount64);
        } else {
          fprintf(_coverage_fout, "287\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "308\n");
        fflush(_coverage_fout);
        if (dircount64 > 65535ULL) {
          fprintf(_coverage_fout, "288\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module,
                       "Sanity check on tag count failed, likely corrupt TIFF");
          fprintf(_coverage_fout, "289\n");
          fflush(_coverage_fout);
          return (0);
        } else {
          fprintf(_coverage_fout, "290\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "309\n");
        fflush(_coverage_fout);
        dircount___0 = (unsigned short )dircount64;
        fprintf(_coverage_fout, "310\n");
        fflush(_coverage_fout);
        (*(tif->tif_seekproc))(tif->tif_clientdata,
                               (nextdir___0 + 8ULL) + (uint64 )((int )dircount___0 * 20),
                               0);
        fprintf(_coverage_fout, "311\n");
        fflush(_coverage_fout);
        tmp___8 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                         (void *)(& nextnextdir___0), 8L);
        fprintf(_coverage_fout, "312\n");
        fflush(_coverage_fout);
        if (tmp___8 == 8L) {
          fprintf(_coverage_fout, "291\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "292\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module,
                       "Error fetching directory link");
          fprintf(_coverage_fout, "293\n");
          fflush(_coverage_fout);
          return (0);
        }
        fprintf(_coverage_fout, "313\n");
        fflush(_coverage_fout);
        if (tif->tif_flags & 128U) {
          fprintf(_coverage_fout, "294\n");
          fflush(_coverage_fout);
          TIFFSwabLong8(& nextnextdir___0);
        } else {
          fprintf(_coverage_fout, "295\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "314\n");
        fflush(_coverage_fout);
        if (nextnextdir___0 == tif->tif_diroff) {
          fprintf(_coverage_fout, "299\n");
          fflush(_coverage_fout);
          m___0 = 0ULL;
          fprintf(_coverage_fout, "300\n");
          fflush(_coverage_fout);
          (*(tif->tif_seekproc))(tif->tif_clientdata,
                                 (nextdir___0 + 8ULL) + (uint64 )((int )dircount___0 * 20),
                                 0);
          fprintf(_coverage_fout, "301\n");
          fflush(_coverage_fout);
          tmp___9 = (*(tif->tif_writeproc))(tif->tif_clientdata,
                                            (void *)(& m___0), 8L);
          fprintf(_coverage_fout, "302\n");
          fflush(_coverage_fout);
          if (tmp___9 == 8L) {
            fprintf(_coverage_fout, "296\n");
            fflush(_coverage_fout);

          } else {
            fprintf(_coverage_fout, "297\n");
            fflush(_coverage_fout);
            TIFFErrorExt(tif->tif_clientdata, module,
                         "Error writing directory link");
            fprintf(_coverage_fout, "298\n");
            fflush(_coverage_fout);
            return (0);
          }
          fprintf(_coverage_fout, "303\n");
          fflush(_coverage_fout);
          tif->tif_diroff = 0ULL;
          break;
        } else {
          fprintf(_coverage_fout, "304\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "315\n");
        fflush(_coverage_fout);
        nextdir___0 = nextnextdir___0;
      }
    }
  }
  fprintf(_coverage_fout, "321\n");
  fflush(_coverage_fout);
  tmp___10 = TIFFWriteDirectory(tif);
  fprintf(_coverage_fout, "322\n");
  fflush(_coverage_fout);
  return (tmp___10);
}
}
static int TIFFWriteDirectorySec(TIFF *tif , int isimage , int imagedone ,
                                 uint64 *pdiroff ) ;
static char const   module___0[22]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'S',      (char const   )'e', 
        (char const   )'c',      (char const   )'\000'};
static int TIFFWriteDirectorySec(TIFF *tif , int isimage , int imagedone ,
                                 uint64 *pdiroff ) 
{ uint32 ndir ;
  TIFFDirEntry *dir ;
  uint32 dirsize ;
  void *dirmem ;
  uint32 m ;
  tmsize_t orig_rawcc ;
  int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;
  int tmp___7 ;
  int tmp___8 ;
  int tmp___9 ;
  int tmp___10 ;
  int tmp___11 ;
  int tmp___12 ;
  int tmp___13 ;
  int tmp___14 ;
  int tmp___15 ;
  int tmp___16 ;
  int tmp___17 ;
  int tmp___18 ;
  int tmp___19 ;
  int tmp___20 ;
  int tmp___21 ;
  int tmp___22 ;
  int tmp___23 ;
  int tmp___24 ;
  int tmp___25 ;
  int tmp___26 ;
  int tmp___27 ;
  uint16 na ;
  uint16 *nb ;
  int tmp___28 ;
  int tmp___29 ;
  int tmp___30 ;
  int tmp___31 ;
  int tmp___32 ;
  int tmp___33 ;
  int tmp___34 ;
  int tmp___35 ;
  int tmp___36 ;
  int tmp___37 ;
  int tmp___38 ;
  int tmp___39 ;
  uint32 n ;
  TIFFField const   *o ;
  uint32 pa ;
  char *pb ;
  size_t tmp___40 ;
  int tmp___41 ;
  uint16 p ;
  int tmp___42 ;
  uint32 p___0 ;
  int tmp___43 ;
  uint32 pa___0 ;
  void *pb___0 ;
  int tmp___44 ;
  int tmp___45 ;
  int tmp___46 ;
  int tmp___47 ;
  int tmp___48 ;
  int tmp___49 ;
  int tmp___50 ;
  int tmp___51 ;
  int tmp___52 ;
  int tmp___53 ;
  int tmp___54 ;
  int tmp___55 ;
  int tmp___56 ;
  int tmp___57 ;
  int tmp___58 ;
  int tmp___59 ;
  int tmp___60 ;
  void *tmp___61 ;
  int tmp___62 ;
  uint64 tmp___63 ;
  uint32 na___0 ;
  TIFFDirEntry *nb___0 ;
  uint8 *n___0 ;
  TIFFDirEntry *o___0 ;
  uint8 *n___1 ;
  TIFFDirEntry *o___1 ;
  uint64 tmp___64 ;
  tmsize_t tmp___65 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "797\n");
  fflush(_coverage_fout);
  if (tif->tif_mode == 00) {
    fprintf(_coverage_fout, "323\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "324\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "798\n");
  fflush(_coverage_fout);
  if (imagedone) {
    fprintf(_coverage_fout, "349\n");
    fflush(_coverage_fout);
    orig_rawcc = tif->tif_rawcc;
    fprintf(_coverage_fout, "350\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 4096U) {
      fprintf(_coverage_fout, "328\n");
      fflush(_coverage_fout);
      tif->tif_flags &= 4294963199U;
      fprintf(_coverage_fout, "329\n");
      fflush(_coverage_fout);
      tmp = (*(tif->tif_postencode))(tif);
      fprintf(_coverage_fout, "330\n");
      fflush(_coverage_fout);
      if (tmp) {
        fprintf(_coverage_fout, "325\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "326\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___0,
                     "Error post-encoding before directory write");
        fprintf(_coverage_fout, "327\n");
        fflush(_coverage_fout);
        return (0);
      }
    } else {
      fprintf(_coverage_fout, "331\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "351\n");
    fflush(_coverage_fout);
    (*(tif->tif_close))(tif);
    fprintf(_coverage_fout, "352\n");
    fflush(_coverage_fout);
    if (tif->tif_rawcc > 0L) {
      fprintf(_coverage_fout, "340\n");
      fflush(_coverage_fout);
      if (tif->tif_rawcc != orig_rawcc) {
        fprintf(_coverage_fout, "338\n");
        fflush(_coverage_fout);
        if ((tif->tif_flags & 64U) != 0U) {
          fprintf(_coverage_fout, "335\n");
          fflush(_coverage_fout);
          tmp___0 = TIFFFlushData1(tif);
          fprintf(_coverage_fout, "336\n");
          fflush(_coverage_fout);
          if (tmp___0) {
            fprintf(_coverage_fout, "332\n");
            fflush(_coverage_fout);

          } else {
            fprintf(_coverage_fout, "333\n");
            fflush(_coverage_fout);
            TIFFErrorExt(tif->tif_clientdata, module___0,
                         "Error flushing data before directory write");
            fprintf(_coverage_fout, "334\n");
            fflush(_coverage_fout);
            return (0);
          }
        } else {
          fprintf(_coverage_fout, "337\n");
          fflush(_coverage_fout);

        }
      } else {
        fprintf(_coverage_fout, "339\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "341\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "353\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 512U) {
      fprintf(_coverage_fout, "347\n");
      fflush(_coverage_fout);
      if (tif->tif_rawdata) {
        fprintf(_coverage_fout, "342\n");
        fflush(_coverage_fout);
        _TIFFfree((void *)tif->tif_rawdata);
        fprintf(_coverage_fout, "343\n");
        fflush(_coverage_fout);
        tif->tif_rawdata = (uint8 *)((void *)0);
        fprintf(_coverage_fout, "344\n");
        fflush(_coverage_fout);
        tif->tif_rawcc = 0L;
        fprintf(_coverage_fout, "345\n");
        fflush(_coverage_fout);
        tif->tif_rawdatasize = 0L;
      } else {
        fprintf(_coverage_fout, "346\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "348\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "354\n");
    fflush(_coverage_fout);
    tif->tif_flags &= 4294967215U;
  } else {
    fprintf(_coverage_fout, "355\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "799\n");
  fflush(_coverage_fout);
  dir = (TIFFDirEntry *)((void *)0);
  fprintf(_coverage_fout, "800\n");
  fflush(_coverage_fout);
  dirmem = (void *)0;
  fprintf(_coverage_fout, "801\n");
  fflush(_coverage_fout);
  dirsize = 0U;
  fprintf(_coverage_fout, "802\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "686\n");
    fflush(_coverage_fout);
    ndir = 0U;
    fprintf(_coverage_fout, "687\n");
    fflush(_coverage_fout);
    if (isimage) {
      fprintf(_coverage_fout, "574\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 1)) {
        fprintf(_coverage_fout, "358\n");
        fflush(_coverage_fout);
        tmp___1 = TIFFWriteDirectoryTagShortLong(tif, & ndir, dir,
                                                 (unsigned short)256,
                                                 tif->tif_dir.td_imagewidth);
        fprintf(_coverage_fout, "359\n");
        fflush(_coverage_fout);
        if (tmp___1) {
          fprintf(_coverage_fout, "356\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
        fprintf(_coverage_fout, "360\n");
        fflush(_coverage_fout);
        tmp___2 = TIFFWriteDirectoryTagShortLong(tif, & ndir, dir,
                                                 (unsigned short)257,
                                                 tif->tif_dir.td_imagelength);
        fprintf(_coverage_fout, "361\n");
        fflush(_coverage_fout);
        if (tmp___2) {
          fprintf(_coverage_fout, "357\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "362\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "575\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 2)) {
        fprintf(_coverage_fout, "365\n");
        fflush(_coverage_fout);
        tmp___3 = TIFFWriteDirectoryTagShortLong(tif, & ndir, dir,
                                                 (unsigned short)322,
                                                 tif->tif_dir.td_tilewidth);
        fprintf(_coverage_fout, "366\n");
        fflush(_coverage_fout);
        if (tmp___3) {
          fprintf(_coverage_fout, "363\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
        fprintf(_coverage_fout, "367\n");
        fflush(_coverage_fout);
        tmp___4 = TIFFWriteDirectoryTagShortLong(tif, & ndir, dir,
                                                 (unsigned short)323,
                                                 tif->tif_dir.td_tilelength);
        fprintf(_coverage_fout, "368\n");
        fflush(_coverage_fout);
        if (tmp___4) {
          fprintf(_coverage_fout, "364\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "369\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "576\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 3)) {
        fprintf(_coverage_fout, "372\n");
        fflush(_coverage_fout);
        tmp___5 = TIFFWriteDirectoryTagRational(tif, & ndir, dir,
                                                (unsigned short)282,
                                                (double )tif->tif_dir.td_xresolution);
        fprintf(_coverage_fout, "373\n");
        fflush(_coverage_fout);
        if (tmp___5) {
          fprintf(_coverage_fout, "370\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
        fprintf(_coverage_fout, "374\n");
        fflush(_coverage_fout);
        tmp___6 = TIFFWriteDirectoryTagRational(tif, & ndir, dir,
                                                (unsigned short)283,
                                                (double )tif->tif_dir.td_yresolution);
        fprintf(_coverage_fout, "375\n");
        fflush(_coverage_fout);
        if (tmp___6) {
          fprintf(_coverage_fout, "371\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "376\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "577\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 4)) {
        fprintf(_coverage_fout, "379\n");
        fflush(_coverage_fout);
        tmp___7 = TIFFWriteDirectoryTagRational(tif, & ndir, dir,
                                                (unsigned short)286,
                                                (double )tif->tif_dir.td_xposition);
        fprintf(_coverage_fout, "380\n");
        fflush(_coverage_fout);
        if (tmp___7) {
          fprintf(_coverage_fout, "377\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
        fprintf(_coverage_fout, "381\n");
        fflush(_coverage_fout);
        tmp___8 = TIFFWriteDirectoryTagRational(tif, & ndir, dir,
                                                (unsigned short)287,
                                                (double )tif->tif_dir.td_yposition);
        fprintf(_coverage_fout, "382\n");
        fflush(_coverage_fout);
        if (tmp___8) {
          fprintf(_coverage_fout, "378\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "383\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "578\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 5)) {
        fprintf(_coverage_fout, "385\n");
        fflush(_coverage_fout);
        tmp___9 = TIFFWriteDirectoryTagLong(tif, & ndir, dir,
                                            (unsigned short)254,
                                            tif->tif_dir.td_subfiletype);
        fprintf(_coverage_fout, "386\n");
        fflush(_coverage_fout);
        if (tmp___9) {
          fprintf(_coverage_fout, "384\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "387\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "579\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 6)) {
        fprintf(_coverage_fout, "389\n");
        fflush(_coverage_fout);
        tmp___10 = TIFFWriteDirectoryTagShortPerSample(tif, & ndir, dir,
                                                       (unsigned short)258,
                                                       tif->tif_dir.td_bitspersample);
        fprintf(_coverage_fout, "390\n");
        fflush(_coverage_fout);
        if (tmp___10) {
          fprintf(_coverage_fout, "388\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "391\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "580\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 7)) {
        fprintf(_coverage_fout, "393\n");
        fflush(_coverage_fout);
        tmp___11 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)259,
                                              tif->tif_dir.td_compression);
        fprintf(_coverage_fout, "394\n");
        fflush(_coverage_fout);
        if (tmp___11) {
          fprintf(_coverage_fout, "392\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "395\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "581\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 8)) {
        fprintf(_coverage_fout, "397\n");
        fflush(_coverage_fout);
        tmp___12 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)262,
                                              tif->tif_dir.td_photometric);
        fprintf(_coverage_fout, "398\n");
        fflush(_coverage_fout);
        if (tmp___12) {
          fprintf(_coverage_fout, "396\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "399\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "582\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 9)) {
        fprintf(_coverage_fout, "401\n");
        fflush(_coverage_fout);
        tmp___13 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)263,
                                              tif->tif_dir.td_threshholding);
        fprintf(_coverage_fout, "402\n");
        fflush(_coverage_fout);
        if (tmp___13) {
          fprintf(_coverage_fout, "400\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "403\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "583\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 10)) {
        fprintf(_coverage_fout, "405\n");
        fflush(_coverage_fout);
        tmp___14 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)266,
                                              tif->tif_dir.td_fillorder);
        fprintf(_coverage_fout, "406\n");
        fflush(_coverage_fout);
        if (tmp___14) {
          fprintf(_coverage_fout, "404\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "407\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "584\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 15)) {
        fprintf(_coverage_fout, "409\n");
        fflush(_coverage_fout);
        tmp___15 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)274,
                                              tif->tif_dir.td_orientation);
        fprintf(_coverage_fout, "410\n");
        fflush(_coverage_fout);
        if (tmp___15) {
          fprintf(_coverage_fout, "408\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "411\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "585\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 16)) {
        fprintf(_coverage_fout, "413\n");
        fflush(_coverage_fout);
        tmp___16 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)277,
                                              tif->tif_dir.td_samplesperpixel);
        fprintf(_coverage_fout, "414\n");
        fflush(_coverage_fout);
        if (tmp___16) {
          fprintf(_coverage_fout, "412\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "415\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "586\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 17)) {
        fprintf(_coverage_fout, "417\n");
        fflush(_coverage_fout);
        tmp___17 = TIFFWriteDirectoryTagShortLong(tif, & ndir, dir,
                                                  (unsigned short)278,
                                                  tif->tif_dir.td_rowsperstrip);
        fprintf(_coverage_fout, "418\n");
        fflush(_coverage_fout);
        if (tmp___17) {
          fprintf(_coverage_fout, "416\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "419\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "587\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 18)) {
        fprintf(_coverage_fout, "421\n");
        fflush(_coverage_fout);
        tmp___18 = TIFFWriteDirectoryTagShortPerSample(tif, & ndir, dir,
                                                       (unsigned short)280,
                                                       tif->tif_dir.td_minsamplevalue);
        fprintf(_coverage_fout, "422\n");
        fflush(_coverage_fout);
        if (tmp___18) {
          fprintf(_coverage_fout, "420\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "423\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "588\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 19)) {
        fprintf(_coverage_fout, "425\n");
        fflush(_coverage_fout);
        tmp___19 = TIFFWriteDirectoryTagShortPerSample(tif, & ndir, dir,
                                                       (unsigned short)281,
                                                       tif->tif_dir.td_maxsamplevalue);
        fprintf(_coverage_fout, "426\n");
        fflush(_coverage_fout);
        if (tmp___19) {
          fprintf(_coverage_fout, "424\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "427\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "589\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 20)) {
        fprintf(_coverage_fout, "429\n");
        fflush(_coverage_fout);
        tmp___20 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)284,
                                              tif->tif_dir.td_planarconfig);
        fprintf(_coverage_fout, "430\n");
        fflush(_coverage_fout);
        if (tmp___20) {
          fprintf(_coverage_fout, "428\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "431\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "590\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 22)) {
        fprintf(_coverage_fout, "433\n");
        fflush(_coverage_fout);
        tmp___21 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)296,
                                              tif->tif_dir.td_resolutionunit);
        fprintf(_coverage_fout, "434\n");
        fflush(_coverage_fout);
        if (tmp___21) {
          fprintf(_coverage_fout, "432\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "435\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "591\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 23)) {
        fprintf(_coverage_fout, "437\n");
        fflush(_coverage_fout);
        tmp___22 = TIFFWriteDirectoryTagShortArray(tif, & ndir, dir,
                                                   (unsigned short)297, 2U,
                                                   & tif->tif_dir.td_pagenumber[0]);
        fprintf(_coverage_fout, "438\n");
        fflush(_coverage_fout);
        if (tmp___22) {
          fprintf(_coverage_fout, "436\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "439\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "592\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 24)) {
        fprintf(_coverage_fout, "446\n");
        fflush(_coverage_fout);
        if (! ((tif->tif_flags & 1024U) != 0U)) {
          fprintf(_coverage_fout, "441\n");
          fflush(_coverage_fout);
          tmp___23 = TIFFWriteDirectoryTagLongLong8Array(tif, & ndir, dir,
                                                         (unsigned short)279,
                                                         tif->tif_dir.td_nstrips,
                                                         tif->tif_dir.td_stripbytecount);
          fprintf(_coverage_fout, "442\n");
          fflush(_coverage_fout);
          if (tmp___23) {
            fprintf(_coverage_fout, "440\n");
            fflush(_coverage_fout);

          } else {
            goto bad;
          }
        } else {
          fprintf(_coverage_fout, "444\n");
          fflush(_coverage_fout);
          tmp___24 = TIFFWriteDirectoryTagLongLong8Array(tif, & ndir, dir,
                                                         (unsigned short)325,
                                                         tif->tif_dir.td_nstrips,
                                                         tif->tif_dir.td_stripbytecount);
          fprintf(_coverage_fout, "445\n");
          fflush(_coverage_fout);
          if (tmp___24) {
            fprintf(_coverage_fout, "443\n");
            fflush(_coverage_fout);

          } else {
            goto bad;
          }
        }
      } else {
        fprintf(_coverage_fout, "447\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "593\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 25)) {
        fprintf(_coverage_fout, "454\n");
        fflush(_coverage_fout);
        if (! ((tif->tif_flags & 1024U) != 0U)) {
          fprintf(_coverage_fout, "449\n");
          fflush(_coverage_fout);
          tmp___25 = TIFFWriteDirectoryTagLongLong8Array(tif, & ndir, dir,
                                                         (unsigned short)273,
                                                         tif->tif_dir.td_nstrips,
                                                         tif->tif_dir.td_stripoffset);
          fprintf(_coverage_fout, "450\n");
          fflush(_coverage_fout);
          if (tmp___25) {
            fprintf(_coverage_fout, "448\n");
            fflush(_coverage_fout);

          } else {
            goto bad;
          }
        } else {
          fprintf(_coverage_fout, "452\n");
          fflush(_coverage_fout);
          tmp___26 = TIFFWriteDirectoryTagLongLong8Array(tif, & ndir, dir,
                                                         (unsigned short)324,
                                                         tif->tif_dir.td_nstrips,
                                                         tif->tif_dir.td_stripoffset);
          fprintf(_coverage_fout, "453\n");
          fflush(_coverage_fout);
          if (tmp___26) {
            fprintf(_coverage_fout, "451\n");
            fflush(_coverage_fout);

          } else {
            goto bad;
          }
        }
      } else {
        fprintf(_coverage_fout, "455\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "594\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 26)) {
        fprintf(_coverage_fout, "457\n");
        fflush(_coverage_fout);
        tmp___27 = TIFFWriteDirectoryTagColormap(tif, & ndir, dir);
        fprintf(_coverage_fout, "458\n");
        fflush(_coverage_fout);
        if (tmp___27) {
          fprintf(_coverage_fout, "456\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "459\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "595\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[0] & (1UL << 31)) {
        fprintf(_coverage_fout, "465\n");
        fflush(_coverage_fout);
        if (tif->tif_dir.td_extrasamples) {
          fprintf(_coverage_fout, "461\n");
          fflush(_coverage_fout);
          TIFFGetFieldDefaulted(tif, 338U, & na, & nb);
          fprintf(_coverage_fout, "462\n");
          fflush(_coverage_fout);
          tmp___28 = TIFFWriteDirectoryTagShortArray(tif, & ndir, dir,
                                                     (unsigned short)338,
                                                     (unsigned int )na, nb);
          fprintf(_coverage_fout, "463\n");
          fflush(_coverage_fout);
          if (tmp___28) {
            fprintf(_coverage_fout, "460\n");
            fflush(_coverage_fout);

          } else {
            goto bad;
          }
        } else {
          fprintf(_coverage_fout, "464\n");
          fflush(_coverage_fout);

        }
      } else {
        fprintf(_coverage_fout, "466\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "596\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & 1UL) {
        fprintf(_coverage_fout, "468\n");
        fflush(_coverage_fout);
        tmp___29 = TIFFWriteDirectoryTagShortPerSample(tif, & ndir, dir,
                                                       (unsigned short)339,
                                                       tif->tif_dir.td_sampleformat);
        fprintf(_coverage_fout, "469\n");
        fflush(_coverage_fout);
        if (tmp___29) {
          fprintf(_coverage_fout, "467\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "470\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "597\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 1)) {
        fprintf(_coverage_fout, "472\n");
        fflush(_coverage_fout);
        tmp___30 = TIFFWriteDirectoryTagSampleformatPerSample(tif, & ndir, dir,
                                                              (unsigned short)340,
                                                              tif->tif_dir.td_sminsamplevalue);
        fprintf(_coverage_fout, "473\n");
        fflush(_coverage_fout);
        if (tmp___30) {
          fprintf(_coverage_fout, "471\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "474\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "598\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 2)) {
        fprintf(_coverage_fout, "476\n");
        fflush(_coverage_fout);
        tmp___31 = TIFFWriteDirectoryTagSampleformatPerSample(tif, & ndir, dir,
                                                              (unsigned short)341,
                                                              tif->tif_dir.td_smaxsamplevalue);
        fprintf(_coverage_fout, "477\n");
        fflush(_coverage_fout);
        if (tmp___31) {
          fprintf(_coverage_fout, "475\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "478\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "599\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 3)) {
        fprintf(_coverage_fout, "480\n");
        fflush(_coverage_fout);
        tmp___32 = TIFFWriteDirectoryTagLong(tif, & ndir, dir,
                                             (unsigned short)32997,
                                             tif->tif_dir.td_imagedepth);
        fprintf(_coverage_fout, "481\n");
        fflush(_coverage_fout);
        if (tmp___32) {
          fprintf(_coverage_fout, "479\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "482\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "600\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 4)) {
        fprintf(_coverage_fout, "484\n");
        fflush(_coverage_fout);
        tmp___33 = TIFFWriteDirectoryTagLong(tif, & ndir, dir,
                                             (unsigned short)32998,
                                             tif->tif_dir.td_tiledepth);
        fprintf(_coverage_fout, "485\n");
        fflush(_coverage_fout);
        if (tmp___33) {
          fprintf(_coverage_fout, "483\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "486\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "601\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 5)) {
        fprintf(_coverage_fout, "488\n");
        fflush(_coverage_fout);
        tmp___34 = TIFFWriteDirectoryTagShortArray(tif, & ndir, dir,
                                                   (unsigned short)321, 2U,
                                                   & tif->tif_dir.td_halftonehints[0]);
        fprintf(_coverage_fout, "489\n");
        fflush(_coverage_fout);
        if (tmp___34) {
          fprintf(_coverage_fout, "487\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "490\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "602\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 7)) {
        fprintf(_coverage_fout, "492\n");
        fflush(_coverage_fout);
        tmp___35 = TIFFWriteDirectoryTagShortArray(tif, & ndir, dir,
                                                   (unsigned short)530, 2U,
                                                   & tif->tif_dir.td_ycbcrsubsampling[0]);
        fprintf(_coverage_fout, "493\n");
        fflush(_coverage_fout);
        if (tmp___35) {
          fprintf(_coverage_fout, "491\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "494\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "603\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 8)) {
        fprintf(_coverage_fout, "496\n");
        fflush(_coverage_fout);
        tmp___36 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                              (unsigned short)531,
                                              tif->tif_dir.td_ycbcrpositioning);
        fprintf(_coverage_fout, "497\n");
        fflush(_coverage_fout);
        if (tmp___36) {
          fprintf(_coverage_fout, "495\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "498\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "604\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 12)) {
        fprintf(_coverage_fout, "500\n");
        fflush(_coverage_fout);
        tmp___37 = TIFFWriteDirectoryTagTransferfunction(tif, & ndir, dir);
        fprintf(_coverage_fout, "501\n");
        fflush(_coverage_fout);
        if (tmp___37) {
          fprintf(_coverage_fout, "499\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "502\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "605\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 14)) {
        fprintf(_coverage_fout, "504\n");
        fflush(_coverage_fout);
        tmp___38 = TIFFWriteDirectoryTagAscii(tif, & ndir, dir,
                                              (unsigned short)333,
                                              (unsigned int )tif->tif_dir.td_inknameslen,
                                              tif->tif_dir.td_inknames);
        fprintf(_coverage_fout, "505\n");
        fflush(_coverage_fout);
        if (tmp___38) {
          fprintf(_coverage_fout, "503\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "506\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "606\n");
      fflush(_coverage_fout);
      if (tif->tif_dir.td_fieldsset[1] & (1UL << 17)) {
        fprintf(_coverage_fout, "508\n");
        fflush(_coverage_fout);
        tmp___39 = TIFFWriteDirectoryTagSubifd(tif, & ndir, dir);
        fprintf(_coverage_fout, "509\n");
        fflush(_coverage_fout);
        if (tmp___39) {
          fprintf(_coverage_fout, "507\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "510\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "607\n");
      fflush(_coverage_fout);
      n = 0U;
      fprintf(_coverage_fout, "608\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "570\n");
        fflush(_coverage_fout);
        if (n < tif->tif_nfields) {
          fprintf(_coverage_fout, "511\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "571\n");
        fflush(_coverage_fout);
        o = (TIFFField const   *)*(tif->tif_fields + n);
        fprintf(_coverage_fout, "572\n");
        fflush(_coverage_fout);
        if ((int const   )o->field_bit >= 66) {
          fprintf(_coverage_fout, "568\n");
          fflush(_coverage_fout);
          if (tif->tif_dir.td_fieldsset[(int const   )o->field_bit / 32] & (1UL << ((int const   )o->field_bit & 31))) {
            switch ((int )o->get_field_type) {
            fprintf(_coverage_fout, "540\n");
            fflush(_coverage_fout);
            case 1: 
            if ((unsigned int const   )o->field_type == 2U) {
              fprintf(_coverage_fout, "512\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "513\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_type==TIFF_ASCII", "tif_dirwrite.c", 579U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "541\n");
            fflush(_coverage_fout);
            if ((int const   )o->field_readcount == -1) {
              fprintf(_coverage_fout, "514\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "515\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_readcount==-1", "tif_dirwrite.c", 580U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "542\n");
            fflush(_coverage_fout);
            if ((int const   )o->field_passcount == 0) {
              fprintf(_coverage_fout, "516\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "517\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_passcount==0", "tif_dirwrite.c", 581U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "543\n");
            fflush(_coverage_fout);
            TIFFGetField(tif, (unsigned int )o->field_tag, & pb);
            fprintf(_coverage_fout, "544\n");
            fflush(_coverage_fout);
            tmp___40 = strlen((char const   *)pb);
            fprintf(_coverage_fout, "545\n");
            fflush(_coverage_fout);
            pa = tmp___40;
            fprintf(_coverage_fout, "546\n");
            fflush(_coverage_fout);
            tmp___41 = TIFFWriteDirectoryTagAscii(tif, & ndir, dir,
                                                  (unsigned short )o->field_tag,
                                                  pa, pb);
            fprintf(_coverage_fout, "547\n");
            fflush(_coverage_fout);
            if (tmp___41) {
              fprintf(_coverage_fout, "518\n");
              fflush(_coverage_fout);

            } else {
              goto bad;
            }
            break;
            fprintf(_coverage_fout, "548\n");
            fflush(_coverage_fout);
            case 4: 
            if ((unsigned int const   )o->field_type == 3U) {
              fprintf(_coverage_fout, "519\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "520\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_type==TIFF_SHORT", "tif_dirwrite.c", 591U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "549\n");
            fflush(_coverage_fout);
            if ((int const   )o->field_readcount == 1) {
              fprintf(_coverage_fout, "521\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "522\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_readcount==1", "tif_dirwrite.c", 592U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "550\n");
            fflush(_coverage_fout);
            if ((int const   )o->field_passcount == 0) {
              fprintf(_coverage_fout, "523\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "524\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_passcount==0", "tif_dirwrite.c", 593U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "551\n");
            fflush(_coverage_fout);
            TIFFGetField(tif, (unsigned int )o->field_tag, & p);
            fprintf(_coverage_fout, "552\n");
            fflush(_coverage_fout);
            tmp___42 = TIFFWriteDirectoryTagShort(tif, & ndir, dir,
                                                  (unsigned short )o->field_tag,
                                                  p);
            fprintf(_coverage_fout, "553\n");
            fflush(_coverage_fout);
            if (tmp___42) {
              fprintf(_coverage_fout, "525\n");
              fflush(_coverage_fout);

            } else {
              goto bad;
            }
            break;
            fprintf(_coverage_fout, "554\n");
            fflush(_coverage_fout);
            case 6: 
            if ((unsigned int const   )o->field_type == 4U) {
              fprintf(_coverage_fout, "526\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "527\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_type==TIFF_LONG", "tif_dirwrite.c", 602U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "555\n");
            fflush(_coverage_fout);
            if ((int const   )o->field_readcount == 1) {
              fprintf(_coverage_fout, "528\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "529\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_readcount==1", "tif_dirwrite.c", 603U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "556\n");
            fflush(_coverage_fout);
            if ((int const   )o->field_passcount == 0) {
              fprintf(_coverage_fout, "530\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "531\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_passcount==0", "tif_dirwrite.c", 604U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "557\n");
            fflush(_coverage_fout);
            TIFFGetField(tif, (unsigned int )o->field_tag, & p___0);
            fprintf(_coverage_fout, "558\n");
            fflush(_coverage_fout);
            tmp___43 = TIFFWriteDirectoryTagLong(tif, & ndir, dir,
                                                 (unsigned short )o->field_tag,
                                                 p___0);
            fprintf(_coverage_fout, "559\n");
            fflush(_coverage_fout);
            if (tmp___43) {
              fprintf(_coverage_fout, "532\n");
              fflush(_coverage_fout);

            } else {
              goto bad;
            }
            break;
            fprintf(_coverage_fout, "560\n");
            fflush(_coverage_fout);
            case 40: 
            if ((unsigned int const   )o->field_type == 7U) {
              fprintf(_coverage_fout, "533\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "534\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_type==TIFF_UNDEFINED", "tif_dirwrite.c",
                            614U, "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "561\n");
            fflush(_coverage_fout);
            if ((int const   )o->field_readcount == -3) {
              fprintf(_coverage_fout, "535\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "536\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_readcount==-3", "tif_dirwrite.c", 615U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "562\n");
            fflush(_coverage_fout);
            if ((int const   )o->field_passcount == 1) {
              fprintf(_coverage_fout, "537\n");
              fflush(_coverage_fout);

            } else {
              fprintf(_coverage_fout, "538\n");
              fflush(_coverage_fout);
              __assert_fail("o->field_passcount==1", "tif_dirwrite.c", 616U,
                            "TIFFWriteDirectorySec");
            }
            fprintf(_coverage_fout, "563\n");
            fflush(_coverage_fout);
            TIFFGetField(tif, (unsigned int )o->field_tag, & pa___0, & pb___0);
            fprintf(_coverage_fout, "564\n");
            fflush(_coverage_fout);
            tmp___44 = TIFFWriteDirectoryTagUndefinedArray(tif, & ndir, dir,
                                                           (unsigned short )o->field_tag,
                                                           pa___0,
                                                           (uint8 *)pb___0);
            fprintf(_coverage_fout, "565\n");
            fflush(_coverage_fout);
            if (tmp___44) {
              fprintf(_coverage_fout, "539\n");
              fflush(_coverage_fout);

            } else {
              goto bad;
            }
            break;
            fprintf(_coverage_fout, "566\n");
            fflush(_coverage_fout);
            default: 
            __assert_fail("0", "tif_dirwrite.c", 623U, "TIFFWriteDirectorySec");
            break;
            }
          } else {
            fprintf(_coverage_fout, "567\n");
            fflush(_coverage_fout);

          }
        } else {
          fprintf(_coverage_fout, "569\n");
          fflush(_coverage_fout);

        }
        fprintf(_coverage_fout, "573\n");
        fflush(_coverage_fout);
        n ++;
      }
    } else {
      fprintf(_coverage_fout, "609\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "688\n");
    fflush(_coverage_fout);
    m = 0U;
    fprintf(_coverage_fout, "689\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "660\n");
      fflush(_coverage_fout);
      if (m < (unsigned int )tif->tif_dir.td_customValueCount) {
        fprintf(_coverage_fout, "610\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      switch ((int )((tif->tif_dir.td_customValues + m)->info)->field_type) {
      fprintf(_coverage_fout, "627\n");
      fflush(_coverage_fout);
      case 2: 
      tmp___45 = TIFFWriteDirectoryTagAscii(tif, & ndir, dir,
                                            (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                            (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                            (char *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "628\n");
      fflush(_coverage_fout);
      if (tmp___45) {
        fprintf(_coverage_fout, "611\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "629\n");
      fflush(_coverage_fout);
      case 7: 
      tmp___46 = TIFFWriteDirectoryTagUndefinedArray(tif, & ndir, dir,
                                                     (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                     (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                     (uint8 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "630\n");
      fflush(_coverage_fout);
      if (tmp___46) {
        fprintf(_coverage_fout, "612\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "631\n");
      fflush(_coverage_fout);
      case 1: 
      tmp___47 = TIFFWriteDirectoryTagByteArray(tif, & ndir, dir,
                                                (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                (uint8 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "632\n");
      fflush(_coverage_fout);
      if (tmp___47) {
        fprintf(_coverage_fout, "613\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "633\n");
      fflush(_coverage_fout);
      case 6: 
      tmp___48 = TIFFWriteDirectoryTagSbyteArray(tif, & ndir, dir,
                                                 (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                 (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                 (int8 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "634\n");
      fflush(_coverage_fout);
      if (tmp___48) {
        fprintf(_coverage_fout, "614\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "635\n");
      fflush(_coverage_fout);
      case 3: 
      tmp___49 = TIFFWriteDirectoryTagShortArray(tif, & ndir, dir,
                                                 (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                 (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                 (uint16 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "636\n");
      fflush(_coverage_fout);
      if (tmp___49) {
        fprintf(_coverage_fout, "615\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "637\n");
      fflush(_coverage_fout);
      case 8: 
      tmp___50 = TIFFWriteDirectoryTagSshortArray(tif, & ndir, dir,
                                                  (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                  (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                  (int16 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "638\n");
      fflush(_coverage_fout);
      if (tmp___50) {
        fprintf(_coverage_fout, "616\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "639\n");
      fflush(_coverage_fout);
      case 4: 
      tmp___51 = TIFFWriteDirectoryTagLongArray(tif, & ndir, dir,
                                                (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                (uint32 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "640\n");
      fflush(_coverage_fout);
      if (tmp___51) {
        fprintf(_coverage_fout, "617\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "641\n");
      fflush(_coverage_fout);
      case 9: 
      tmp___52 = TIFFWriteDirectoryTagSlongArray(tif, & ndir, dir,
                                                 (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                 (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                 (int32 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "642\n");
      fflush(_coverage_fout);
      if (tmp___52) {
        fprintf(_coverage_fout, "618\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "643\n");
      fflush(_coverage_fout);
      case 16: 
      tmp___53 = TIFFWriteDirectoryTagLong8Array(tif, & ndir, dir,
                                                 (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                 (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                 (uint64 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "644\n");
      fflush(_coverage_fout);
      if (tmp___53) {
        fprintf(_coverage_fout, "619\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "645\n");
      fflush(_coverage_fout);
      case 17: 
      tmp___54 = TIFFWriteDirectoryTagSlong8Array(tif, & ndir, dir,
                                                  (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                  (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                  (int64 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "646\n");
      fflush(_coverage_fout);
      if (tmp___54) {
        fprintf(_coverage_fout, "620\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "647\n");
      fflush(_coverage_fout);
      case 5: 
      tmp___55 = TIFFWriteDirectoryTagRationalArray(tif, & ndir, dir,
                                                    (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                    (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                    (float *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "648\n");
      fflush(_coverage_fout);
      if (tmp___55) {
        fprintf(_coverage_fout, "621\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "649\n");
      fflush(_coverage_fout);
      case 10: 
      tmp___56 = TIFFWriteDirectoryTagSrationalArray(tif, & ndir, dir,
                                                     (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                     (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                     (float *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "650\n");
      fflush(_coverage_fout);
      if (tmp___56) {
        fprintf(_coverage_fout, "622\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "651\n");
      fflush(_coverage_fout);
      case 11: 
      tmp___57 = TIFFWriteDirectoryTagFloatArray(tif, & ndir, dir,
                                                 (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                 (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                 (float *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "652\n");
      fflush(_coverage_fout);
      if (tmp___57) {
        fprintf(_coverage_fout, "623\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "653\n");
      fflush(_coverage_fout);
      case 12: 
      tmp___58 = TIFFWriteDirectoryTagDoubleArray(tif, & ndir, dir,
                                                  (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                  (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                  (double *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "654\n");
      fflush(_coverage_fout);
      if (tmp___58) {
        fprintf(_coverage_fout, "624\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "655\n");
      fflush(_coverage_fout);
      case 13: 
      tmp___59 = TIFFWriteDirectoryTagIfdArray(tif, & ndir, dir,
                                               (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                               (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                               (uint32 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "656\n");
      fflush(_coverage_fout);
      if (tmp___59) {
        fprintf(_coverage_fout, "625\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "657\n");
      fflush(_coverage_fout);
      case 18: 
      tmp___60 = TIFFWriteDirectoryTagIfd8Array(tif, & ndir, dir,
                                                (unsigned short )((tif->tif_dir.td_customValues + m)->info)->field_tag,
                                                (unsigned int )(tif->tif_dir.td_customValues + m)->count,
                                                (uint64 *)(tif->tif_dir.td_customValues + m)->value);
      fprintf(_coverage_fout, "658\n");
      fflush(_coverage_fout);
      if (tmp___60) {
        fprintf(_coverage_fout, "626\n");
        fflush(_coverage_fout);

      } else {
        goto bad;
      }
      break;
      fprintf(_coverage_fout, "659\n");
      fflush(_coverage_fout);
      default: 
      __assert_fail("0", "tif_dirwrite.c", 699U, "TIFFWriteDirectorySec");
      break;
      }
      fprintf(_coverage_fout, "661\n");
      fflush(_coverage_fout);
      m ++;
    }
    fprintf(_coverage_fout, "690\n");
    fflush(_coverage_fout);
    if ((unsigned int )dir != (unsigned int )((void *)0)) {
      break;
    } else {
      fprintf(_coverage_fout, "662\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "691\n");
    fflush(_coverage_fout);
    tmp___61 = _TIFFmalloc((long )(ndir * sizeof(TIFFDirEntry )));
    fprintf(_coverage_fout, "692\n");
    fflush(_coverage_fout);
    dir = (TIFFDirEntry *)tmp___61;
    fprintf(_coverage_fout, "693\n");
    fflush(_coverage_fout);
    if ((unsigned int )dir == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "663\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___0, "Out of memory");
      goto bad;
    } else {
      fprintf(_coverage_fout, "664\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "694\n");
    fflush(_coverage_fout);
    if (isimage) {
      fprintf(_coverage_fout, "669\n");
      fflush(_coverage_fout);
      if (tif->tif_diroff == 0ULL) {
        fprintf(_coverage_fout, "666\n");
        fflush(_coverage_fout);
        tmp___62 = TIFFLinkDirectory(tif);
        fprintf(_coverage_fout, "667\n");
        fflush(_coverage_fout);
        if (tmp___62) {
          fprintf(_coverage_fout, "665\n");
          fflush(_coverage_fout);

        } else {
          goto bad;
        }
      } else {
        fprintf(_coverage_fout, "668\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "670\n");
      fflush(_coverage_fout);
      tmp___63 = (*(tif->tif_seekproc))(tif->tif_clientdata, 0ULL, 2);
      fprintf(_coverage_fout, "671\n");
      fflush(_coverage_fout);
      tif->tif_diroff = (tmp___63 + 1ULL) & 0xfffffffffffffffeULL;
    }
    fprintf(_coverage_fout, "695\n");
    fflush(_coverage_fout);
    if ((unsigned int )pdiroff != (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "672\n");
      fflush(_coverage_fout);
      *pdiroff = tif->tif_diroff;
    } else {
      fprintf(_coverage_fout, "673\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "696\n");
    fflush(_coverage_fout);
    if (! (tif->tif_flags & 524288U)) {
      fprintf(_coverage_fout, "674\n");
      fflush(_coverage_fout);
      dirsize = (2U + ndir * 12U) + 4U;
    } else {
      fprintf(_coverage_fout, "675\n");
      fflush(_coverage_fout);
      dirsize = (8U + ndir * 20U) + 8U;
    }
    fprintf(_coverage_fout, "697\n");
    fflush(_coverage_fout);
    tif->tif_dataoff = tif->tif_diroff + (uint64 )dirsize;
    fprintf(_coverage_fout, "698\n");
    fflush(_coverage_fout);
    if (! (tif->tif_flags & 524288U)) {
      fprintf(_coverage_fout, "676\n");
      fflush(_coverage_fout);
      tif->tif_dataoff = (unsigned long long )((unsigned int )tif->tif_dataoff);
    } else {
      fprintf(_coverage_fout, "677\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "699\n");
    fflush(_coverage_fout);
    if (tif->tif_dataoff < tif->tif_diroff) {
      fprintf(_coverage_fout, "678\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___0,
                   "Maximum TIFF file size exceeded");
      goto bad;
    } else {
      fprintf(_coverage_fout, "681\n");
      fflush(_coverage_fout);
      if (tif->tif_dataoff < (unsigned long long )dirsize) {
        fprintf(_coverage_fout, "679\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___0,
                     "Maximum TIFF file size exceeded");
        goto bad;
      } else {
        fprintf(_coverage_fout, "680\n");
        fflush(_coverage_fout);

      }
    }
    fprintf(_coverage_fout, "700\n");
    fflush(_coverage_fout);
    if (tif->tif_dataoff & 1ULL) {
      fprintf(_coverage_fout, "682\n");
      fflush(_coverage_fout);
      (tif->tif_dataoff) ++;
    } else {
      fprintf(_coverage_fout, "683\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "701\n");
    fflush(_coverage_fout);
    if (isimage) {
      fprintf(_coverage_fout, "684\n");
      fflush(_coverage_fout);
      tif->tif_curdir = (uint16 )((int )tif->tif_curdir + 1);
    } else {
      fprintf(_coverage_fout, "685\n");
      fflush(_coverage_fout);

    }
  }
  fprintf(_coverage_fout, "803\n");
  fflush(_coverage_fout);
  if (isimage) {
    fprintf(_coverage_fout, "718\n");
    fflush(_coverage_fout);
    if (tif->tif_dir.td_fieldsset[1] & (1UL << 17)) {
      fprintf(_coverage_fout, "716\n");
      fflush(_coverage_fout);
      if (tif->tif_subifdoff == 0ULL) {
        fprintf(_coverage_fout, "711\n");
        fflush(_coverage_fout);
        na___0 = 0U;
        fprintf(_coverage_fout, "712\n");
        fflush(_coverage_fout);
        nb___0 = dir;
        fprintf(_coverage_fout, "713\n");
        fflush(_coverage_fout);
        while (1) {
          fprintf(_coverage_fout, "705\n");
          fflush(_coverage_fout);
          if (na___0 < ndir) {
            fprintf(_coverage_fout, "702\n");
            fflush(_coverage_fout);

          } else {
            fprintf(_coverage_fout, "703\n");
            fflush(_coverage_fout);
            __assert_fail("na<ndir", "tif_dirwrite.c", 745U,
                          "TIFFWriteDirectorySec");
          }
          fprintf(_coverage_fout, "706\n");
          fflush(_coverage_fout);
          if ((int )nb___0->tdir_tag == 330) {
            break;
          } else {
            fprintf(_coverage_fout, "704\n");
            fflush(_coverage_fout);

          }
          fprintf(_coverage_fout, "707\n");
          fflush(_coverage_fout);
          na___0 ++;
          fprintf(_coverage_fout, "708\n");
          fflush(_coverage_fout);
          nb___0 ++;
        }
        fprintf(_coverage_fout, "714\n");
        fflush(_coverage_fout);
        if (! (tif->tif_flags & 524288U)) {
          fprintf(_coverage_fout, "709\n");
          fflush(_coverage_fout);
          tif->tif_subifdoff = ((tif->tif_diroff + 2ULL) + (uint64 )(na___0 * 12U)) + 8ULL;
        } else {
          fprintf(_coverage_fout, "710\n");
          fflush(_coverage_fout);
          tif->tif_subifdoff = ((tif->tif_diroff + 8ULL) + (uint64 )(na___0 * 20U)) + 12ULL;
        }
      } else {
        fprintf(_coverage_fout, "715\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "717\n");
      fflush(_coverage_fout);

    }
  } else {
    fprintf(_coverage_fout, "719\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "804\n");
  fflush(_coverage_fout);
  dirmem = _TIFFmalloc((long )dirsize);
  fprintf(_coverage_fout, "805\n");
  fflush(_coverage_fout);
  if ((unsigned int )dirmem == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "720\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___0, "Out of memory");
    goto bad;
  } else {
    fprintf(_coverage_fout, "721\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "806\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "745\n");
    fflush(_coverage_fout);
    n___0 = (uint8 *)dirmem;
    fprintf(_coverage_fout, "746\n");
    fflush(_coverage_fout);
    *((uint16 *)n___0) = (unsigned short )ndir;
    fprintf(_coverage_fout, "747\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "722\n");
      fflush(_coverage_fout);
      TIFFSwabShort((uint16 *)n___0);
    } else {
      fprintf(_coverage_fout, "723\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "748\n");
    fflush(_coverage_fout);
    n___0 += 2;
    fprintf(_coverage_fout, "749\n");
    fflush(_coverage_fout);
    o___0 = dir;
    fprintf(_coverage_fout, "750\n");
    fflush(_coverage_fout);
    m = 0U;
    fprintf(_coverage_fout, "751\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "731\n");
      fflush(_coverage_fout);
      if (m < ndir) {
        fprintf(_coverage_fout, "724\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "732\n");
      fflush(_coverage_fout);
      *((uint16 *)n___0) = o___0->tdir_tag;
      fprintf(_coverage_fout, "733\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "725\n");
        fflush(_coverage_fout);
        TIFFSwabShort((uint16 *)n___0);
      } else {
        fprintf(_coverage_fout, "726\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "734\n");
      fflush(_coverage_fout);
      n___0 += 2;
      fprintf(_coverage_fout, "735\n");
      fflush(_coverage_fout);
      *((uint16 *)n___0) = o___0->tdir_type;
      fprintf(_coverage_fout, "736\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "727\n");
        fflush(_coverage_fout);
        TIFFSwabShort((uint16 *)n___0);
      } else {
        fprintf(_coverage_fout, "728\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "737\n");
      fflush(_coverage_fout);
      n___0 += 2;
      fprintf(_coverage_fout, "738\n");
      fflush(_coverage_fout);
      *((uint32 *)n___0) = (unsigned int )o___0->tdir_count;
      fprintf(_coverage_fout, "739\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "729\n");
        fflush(_coverage_fout);
        TIFFSwabLong((uint32 *)n___0);
      } else {
        fprintf(_coverage_fout, "730\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "740\n");
      fflush(_coverage_fout);
      n___0 += 4;
      fprintf(_coverage_fout, "741\n");
      fflush(_coverage_fout);
      _TIFFmemcpy((void *)n___0, (void const   *)(& o___0->tdir_offset), 4L);
      fprintf(_coverage_fout, "742\n");
      fflush(_coverage_fout);
      n___0 += 4;
      fprintf(_coverage_fout, "743\n");
      fflush(_coverage_fout);
      o___0 ++;
      fprintf(_coverage_fout, "744\n");
      fflush(_coverage_fout);
      m ++;
    }
    fprintf(_coverage_fout, "752\n");
    fflush(_coverage_fout);
    *((uint32 *)n___0) = (unsigned int )tif->tif_nextdiroff;
  } else {
    fprintf(_coverage_fout, "776\n");
    fflush(_coverage_fout);
    n___1 = (uint8 *)dirmem;
    fprintf(_coverage_fout, "777\n");
    fflush(_coverage_fout);
    *((uint64 *)n___1) = (unsigned long long )ndir;
    fprintf(_coverage_fout, "778\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "753\n");
      fflush(_coverage_fout);
      TIFFSwabLong8((uint64 *)n___1);
    } else {
      fprintf(_coverage_fout, "754\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "779\n");
    fflush(_coverage_fout);
    n___1 += 8;
    fprintf(_coverage_fout, "780\n");
    fflush(_coverage_fout);
    o___1 = dir;
    fprintf(_coverage_fout, "781\n");
    fflush(_coverage_fout);
    m = 0U;
    fprintf(_coverage_fout, "782\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "762\n");
      fflush(_coverage_fout);
      if (m < ndir) {
        fprintf(_coverage_fout, "755\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "763\n");
      fflush(_coverage_fout);
      *((uint16 *)n___1) = o___1->tdir_tag;
      fprintf(_coverage_fout, "764\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "756\n");
        fflush(_coverage_fout);
        TIFFSwabShort((uint16 *)n___1);
      } else {
        fprintf(_coverage_fout, "757\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "765\n");
      fflush(_coverage_fout);
      n___1 += 2;
      fprintf(_coverage_fout, "766\n");
      fflush(_coverage_fout);
      *((uint16 *)n___1) = o___1->tdir_type;
      fprintf(_coverage_fout, "767\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "758\n");
        fflush(_coverage_fout);
        TIFFSwabShort((uint16 *)n___1);
      } else {
        fprintf(_coverage_fout, "759\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "768\n");
      fflush(_coverage_fout);
      n___1 += 2;
      fprintf(_coverage_fout, "769\n");
      fflush(_coverage_fout);
      *((uint64 *)n___1) = o___1->tdir_count;
      fprintf(_coverage_fout, "770\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "760\n");
        fflush(_coverage_fout);
        TIFFSwabLong8((uint64 *)n___1);
      } else {
        fprintf(_coverage_fout, "761\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "771\n");
      fflush(_coverage_fout);
      n___1 += 8;
      fprintf(_coverage_fout, "772\n");
      fflush(_coverage_fout);
      _TIFFmemcpy((void *)n___1, (void const   *)(& o___1->tdir_offset), 8L);
      fprintf(_coverage_fout, "773\n");
      fflush(_coverage_fout);
      n___1 += 8;
      fprintf(_coverage_fout, "774\n");
      fflush(_coverage_fout);
      o___1 ++;
      fprintf(_coverage_fout, "775\n");
      fflush(_coverage_fout);
      m ++;
    }
    fprintf(_coverage_fout, "783\n");
    fflush(_coverage_fout);
    *((uint64 *)n___1) = tif->tif_nextdiroff;
  }
  fprintf(_coverage_fout, "807\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)dir);
  fprintf(_coverage_fout, "808\n");
  fflush(_coverage_fout);
  dir = (TIFFDirEntry *)((void *)0);
  fprintf(_coverage_fout, "809\n");
  fflush(_coverage_fout);
  tmp___64 = (*(tif->tif_seekproc))(tif->tif_clientdata, tif->tif_diroff, 0);
  fprintf(_coverage_fout, "810\n");
  fflush(_coverage_fout);
  if (tmp___64 == tif->tif_diroff) {
    fprintf(_coverage_fout, "784\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "785\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___0, "IO error writing directory");
    goto bad;
  }
  fprintf(_coverage_fout, "811\n");
  fflush(_coverage_fout);
  tmp___65 = (*(tif->tif_writeproc))(tif->tif_clientdata, dirmem, (long )dirsize);
  fprintf(_coverage_fout, "812\n");
  fflush(_coverage_fout);
  if (tmp___65 == (long )dirsize) {
    fprintf(_coverage_fout, "786\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "787\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___0, "IO error writing directory");
    goto bad;
  }
  fprintf(_coverage_fout, "813\n");
  fflush(_coverage_fout);
  _TIFFfree(dirmem);
  fprintf(_coverage_fout, "814\n");
  fflush(_coverage_fout);
  if (imagedone) {
    fprintf(_coverage_fout, "788\n");
    fflush(_coverage_fout);
    TIFFFreeDirectory(tif);
    fprintf(_coverage_fout, "789\n");
    fflush(_coverage_fout);
    tif->tif_flags &= 4294967287U;
    fprintf(_coverage_fout, "790\n");
    fflush(_coverage_fout);
    (*(tif->tif_cleanup))(tif);
    fprintf(_coverage_fout, "791\n");
    fflush(_coverage_fout);
    TIFFCreateDirectory(tif);
  } else {
    fprintf(_coverage_fout, "792\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "815\n");
  fflush(_coverage_fout);
  return (1);
  fprintf(_coverage_fout, "816\n");
  fflush(_coverage_fout);
  bad: 
  if ((unsigned int )dir != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "793\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)dir);
  } else {
    fprintf(_coverage_fout, "794\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "817\n");
  fflush(_coverage_fout);
  if ((unsigned int )dirmem != (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "795\n");
    fflush(_coverage_fout);
    _TIFFfree(dirmem);
  } else {
    fprintf(_coverage_fout, "796\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "818\n");
  fflush(_coverage_fout);
  return (0);
}
}
static int TIFFWriteDirectoryTagSampleformatPerSample(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag , double value ) 
{ int tmp ;
  int tmp___0 ;
  int tmp___1 ;
  int tmp___2 ;
  int tmp___3 ;
  int tmp___4 ;
  int tmp___5 ;
  int tmp___6 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  switch ((int )tif->tif_dir.td_sampleformat) {
  fprintf(_coverage_fout, "837\n");
  fflush(_coverage_fout);
  case 3: 
  if ((int )tif->tif_dir.td_bitspersample <= 32) {
    fprintf(_coverage_fout, "819\n");
    fflush(_coverage_fout);
    tmp = TIFFWriteDirectoryTagFloatPerSample(tif, ndir, dir, tag, (float )value);
    fprintf(_coverage_fout, "820\n");
    fflush(_coverage_fout);
    return (tmp);
  } else {
    fprintf(_coverage_fout, "821\n");
    fflush(_coverage_fout);
    tmp___0 = TIFFWriteDirectoryTagDoublePerSample(tif, ndir, dir, tag, value);
    fprintf(_coverage_fout, "822\n");
    fflush(_coverage_fout);
    return (tmp___0);
  }
  fprintf(_coverage_fout, "838\n");
  fflush(_coverage_fout);
  case 2: 
  if ((int )tif->tif_dir.td_bitspersample <= 8) {
    fprintf(_coverage_fout, "823\n");
    fflush(_coverage_fout);
    tmp___1 = TIFFWriteDirectoryTagSbytePerSample(tif, ndir, dir, tag,
                                                  (signed char )value);
    fprintf(_coverage_fout, "824\n");
    fflush(_coverage_fout);
    return (tmp___1);
  } else {
    fprintf(_coverage_fout, "829\n");
    fflush(_coverage_fout);
    if ((int )tif->tif_dir.td_bitspersample <= 16) {
      fprintf(_coverage_fout, "825\n");
      fflush(_coverage_fout);
      tmp___2 = TIFFWriteDirectoryTagSshortPerSample(tif, ndir, dir, tag,
                                                     (short )value);
      fprintf(_coverage_fout, "826\n");
      fflush(_coverage_fout);
      return (tmp___2);
    } else {
      fprintf(_coverage_fout, "827\n");
      fflush(_coverage_fout);
      tmp___3 = TIFFWriteDirectoryTagSlongPerSample(tif, ndir, dir, tag,
                                                    (int )value);
      fprintf(_coverage_fout, "828\n");
      fflush(_coverage_fout);
      return (tmp___3);
    }
  }
  fprintf(_coverage_fout, "839\n");
  fflush(_coverage_fout);
  case 1: 
  if ((int )tif->tif_dir.td_bitspersample <= 8) {
    fprintf(_coverage_fout, "830\n");
    fflush(_coverage_fout);
    tmp___4 = TIFFWriteDirectoryTagBytePerSample(tif, ndir, dir, tag,
                                                 (unsigned char )value);
    fprintf(_coverage_fout, "831\n");
    fflush(_coverage_fout);
    return (tmp___4);
  } else {
    fprintf(_coverage_fout, "836\n");
    fflush(_coverage_fout);
    if ((int )tif->tif_dir.td_bitspersample <= 16) {
      fprintf(_coverage_fout, "832\n");
      fflush(_coverage_fout);
      tmp___5 = TIFFWriteDirectoryTagShortPerSample(tif, ndir, dir, tag,
                                                    (unsigned short )value);
      fprintf(_coverage_fout, "833\n");
      fflush(_coverage_fout);
      return (tmp___5);
    } else {
      fprintf(_coverage_fout, "834\n");
      fflush(_coverage_fout);
      tmp___6 = TIFFWriteDirectoryTagLongPerSample(tif, ndir, dir, tag,
                                                   (unsigned int )value);
      fprintf(_coverage_fout, "835\n");
      fflush(_coverage_fout);
      return (tmp___6);
    }
  }
  fprintf(_coverage_fout, "840\n");
  fflush(_coverage_fout);
  default: ;
  fprintf(_coverage_fout, "841\n");
  fflush(_coverage_fout);
  return (1);
  }
}
}
static int TIFFWriteDirectoryTagAscii(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      uint32 count , char *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "845\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "842\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "843\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "844\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "846\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedAscii(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "847\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagUndefinedArray(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , uint8 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "851\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "848\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "849\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "850\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "852\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedUndefinedArray(tif, ndir, dir, tag, count,
                                                   value);
  fprintf(_coverage_fout, "853\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagByte(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint8 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "857\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "854\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "855\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "856\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "858\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedByte(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "859\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagByteArray(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint8 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "863\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "860\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "861\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "862\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "864\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedByteArray(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "865\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagBytePerSample(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint8 value ) ;
static char const   module___1[35]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'B',      (char const   )'y',      (char const   )'t', 
        (char const   )'e',      (char const   )'P',      (char const   )'e',      (char const   )'r', 
        (char const   )'S',      (char const   )'a',      (char const   )'m',      (char const   )'p', 
        (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagBytePerSample(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint8 value ) 
{ uint8 *m ;
  uint8 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "877\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "866\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "867\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "868\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "878\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_samplesperpixel * sizeof(uint8 )));
  fprintf(_coverage_fout, "879\n");
  fflush(_coverage_fout);
  m = (uint8 *)tmp;
  fprintf(_coverage_fout, "880\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "869\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___1, "Out of memory");
    fprintf(_coverage_fout, "870\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "871\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "881\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "882\n");
  fflush(_coverage_fout);
  nb = (unsigned short)0;
  fprintf(_coverage_fout, "883\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "873\n");
    fflush(_coverage_fout);
    if ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
      fprintf(_coverage_fout, "872\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "874\n");
    fflush(_coverage_fout);
    *na = value;
    fprintf(_coverage_fout, "875\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "876\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb + 1);
  }
  fprintf(_coverage_fout, "884\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedByteArray(tif, ndir, dir, tag,
                                            (unsigned int )tif->tif_dir.td_samplesperpixel,
                                            m);
  fprintf(_coverage_fout, "885\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "886\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagSbyte(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      int8 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "890\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "887\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "888\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "889\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "891\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSbyte(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "892\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSbyteArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , int8 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "896\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "893\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "894\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "895\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "897\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSbyteArray(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "898\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSbytePerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               int8 value ) ;
static char const   module___2[36]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'S',      (char const   )'b',      (char const   )'y', 
        (char const   )'t',      (char const   )'e',      (char const   )'P',      (char const   )'e', 
        (char const   )'r',      (char const   )'S',      (char const   )'a',      (char const   )'m', 
        (char const   )'p',      (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagSbytePerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               int8 value ) 
{ int8 *m ;
  int8 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "910\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "899\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "900\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "901\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "911\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_samplesperpixel * sizeof(int8 )));
  fprintf(_coverage_fout, "912\n");
  fflush(_coverage_fout);
  m = (int8 *)tmp;
  fprintf(_coverage_fout, "913\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "902\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___2, "Out of memory");
    fprintf(_coverage_fout, "903\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "904\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "914\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "915\n");
  fflush(_coverage_fout);
  nb = (unsigned short)0;
  fprintf(_coverage_fout, "916\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "906\n");
    fflush(_coverage_fout);
    if ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
      fprintf(_coverage_fout, "905\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "907\n");
    fflush(_coverage_fout);
    *na = value;
    fprintf(_coverage_fout, "908\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "909\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb + 1);
  }
  fprintf(_coverage_fout, "917\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedSbyteArray(tif, ndir, dir, tag,
                                             (unsigned int )tif->tif_dir.td_samplesperpixel,
                                             m);
  fprintf(_coverage_fout, "918\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "919\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagShort(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      uint16 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "923\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "920\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "921\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "922\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "924\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedShort(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "925\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagShortArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , uint16 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "929\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "926\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "927\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "928\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "930\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedShortArray(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "931\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagShortPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint16 value ) ;
static char const   module___3[36]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'S',      (char const   )'h',      (char const   )'o', 
        (char const   )'r',      (char const   )'t',      (char const   )'P',      (char const   )'e', 
        (char const   )'r',      (char const   )'S',      (char const   )'a',      (char const   )'m', 
        (char const   )'p',      (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagShortPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint16 value ) 
{ uint16 *m ;
  uint16 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "943\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "932\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "933\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "934\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "944\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_samplesperpixel * sizeof(uint16 )));
  fprintf(_coverage_fout, "945\n");
  fflush(_coverage_fout);
  m = (uint16 *)tmp;
  fprintf(_coverage_fout, "946\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "935\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___3, "Out of memory");
    fprintf(_coverage_fout, "936\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "937\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "947\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "948\n");
  fflush(_coverage_fout);
  nb = (unsigned short)0;
  fprintf(_coverage_fout, "949\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "939\n");
    fflush(_coverage_fout);
    if ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
      fprintf(_coverage_fout, "938\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "940\n");
    fflush(_coverage_fout);
    *na = value;
    fprintf(_coverage_fout, "941\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "942\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb + 1);
  }
  fprintf(_coverage_fout, "950\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedShortArray(tif, ndir, dir, tag,
                                             (unsigned int )tif->tif_dir.td_samplesperpixel,
                                             m);
  fprintf(_coverage_fout, "951\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "952\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagSshort(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir , uint16 tag ,
                                       int16 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "956\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "953\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "954\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "955\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "957\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSshort(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "958\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSshortArray(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , int16 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "962\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "959\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "960\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "961\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "963\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSshortArray(tif, ndir, dir, tag, count,
                                                value);
  fprintf(_coverage_fout, "964\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSshortPerSample(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                int16 value ) ;
static char const   module___4[37]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'S',      (char const   )'s',      (char const   )'h', 
        (char const   )'o',      (char const   )'r',      (char const   )'t',      (char const   )'P', 
        (char const   )'e',      (char const   )'r',      (char const   )'S',      (char const   )'a', 
        (char const   )'m',      (char const   )'p',      (char const   )'l',      (char const   )'e', 
        (char const   )'\000'};
static int TIFFWriteDirectoryTagSshortPerSample(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                int16 value ) 
{ int16 *m ;
  int16 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "976\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "965\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "966\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "967\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "977\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_samplesperpixel * sizeof(int16 )));
  fprintf(_coverage_fout, "978\n");
  fflush(_coverage_fout);
  m = (int16 *)tmp;
  fprintf(_coverage_fout, "979\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "968\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___4, "Out of memory");
    fprintf(_coverage_fout, "969\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "970\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "980\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "981\n");
  fflush(_coverage_fout);
  nb = (unsigned short)0;
  fprintf(_coverage_fout, "982\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "972\n");
    fflush(_coverage_fout);
    if ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
      fprintf(_coverage_fout, "971\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "973\n");
    fflush(_coverage_fout);
    *na = value;
    fprintf(_coverage_fout, "974\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "975\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb + 1);
  }
  fprintf(_coverage_fout, "983\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedSshortArray(tif, ndir, dir, tag,
                                              (unsigned int )tif->tif_dir.td_samplesperpixel,
                                              m);
  fprintf(_coverage_fout, "984\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "985\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagLong(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint32 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "989\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "986\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "987\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "988\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "990\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedLong(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "991\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagLongArray(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint32 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "995\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "992\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "993\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "994\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "996\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedLongArray(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "997\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagLongPerSample(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint32 value ) ;
static char const   module___5[35]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'L',      (char const   )'o',      (char const   )'n', 
        (char const   )'g',      (char const   )'P',      (char const   )'e',      (char const   )'r', 
        (char const   )'S',      (char const   )'a',      (char const   )'m',      (char const   )'p', 
        (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagLongPerSample(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint32 value ) 
{ uint32 *m ;
  uint32 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1009\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "998\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "999\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1000\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1010\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_samplesperpixel * sizeof(uint32 )));
  fprintf(_coverage_fout, "1011\n");
  fflush(_coverage_fout);
  m = (uint32 *)tmp;
  fprintf(_coverage_fout, "1012\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1001\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___5, "Out of memory");
    fprintf(_coverage_fout, "1002\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "1003\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1013\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "1014\n");
  fflush(_coverage_fout);
  nb = (unsigned short)0;
  fprintf(_coverage_fout, "1015\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1005\n");
    fflush(_coverage_fout);
    if ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
      fprintf(_coverage_fout, "1004\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1006\n");
    fflush(_coverage_fout);
    *na = value;
    fprintf(_coverage_fout, "1007\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "1008\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb + 1);
  }
  fprintf(_coverage_fout, "1016\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedLongArray(tif, ndir, dir, tag,
                                            (unsigned int )tif->tif_dir.td_samplesperpixel,
                                            m);
  fprintf(_coverage_fout, "1017\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "1018\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagSlong(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      int32 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1022\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1019\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1020\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1021\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1023\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSlong(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "1024\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSlongArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , int32 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1028\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1025\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1026\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1027\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1029\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSlongArray(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "1030\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSlongPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               int32 value ) ;
static char const   module___6[36]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'S',      (char const   )'l',      (char const   )'o', 
        (char const   )'n',      (char const   )'g',      (char const   )'P',      (char const   )'e', 
        (char const   )'r',      (char const   )'S',      (char const   )'a',      (char const   )'m', 
        (char const   )'p',      (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagSlongPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               int32 value ) 
{ int32 *m ;
  int32 *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1042\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1031\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1032\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1033\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1043\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_samplesperpixel * sizeof(int32 )));
  fprintf(_coverage_fout, "1044\n");
  fflush(_coverage_fout);
  m = (int32 *)tmp;
  fprintf(_coverage_fout, "1045\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1034\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___6, "Out of memory");
    fprintf(_coverage_fout, "1035\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "1036\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1046\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "1047\n");
  fflush(_coverage_fout);
  nb = (unsigned short)0;
  fprintf(_coverage_fout, "1048\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1038\n");
    fflush(_coverage_fout);
    if ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
      fprintf(_coverage_fout, "1037\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1039\n");
    fflush(_coverage_fout);
    *na = value;
    fprintf(_coverage_fout, "1040\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "1041\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb + 1);
  }
  fprintf(_coverage_fout, "1049\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedSlongArray(tif, ndir, dir, tag,
                                             (unsigned int )tif->tif_dir.td_samplesperpixel,
                                             m);
  fprintf(_coverage_fout, "1050\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "1051\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagLong8(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      uint64 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1055\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1052\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1053\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1054\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1056\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedLong8(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "1057\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagLong8Array(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , uint64 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1061\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1058\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1059\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1060\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1062\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedLong8Array(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "1063\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSlong8(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir , uint16 tag ,
                                       int64 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1067\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1064\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1065\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1066\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1068\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSlong8(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "1069\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSlong8Array(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , int64 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1073\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1070\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1071\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1072\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1074\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSlong8Array(tif, ndir, dir, tag, count,
                                                value);
  fprintf(_coverage_fout, "1075\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagRational(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir , uint16 tag ,
                                         double value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1079\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1076\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1077\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1078\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1080\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedRational(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "1081\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagRationalArray(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              uint32 count , float *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1085\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1082\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1083\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1084\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1086\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedRationalArray(tif, ndir, dir, tag, count,
                                                  value);
  fprintf(_coverage_fout, "1087\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagSrationalArray(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , float *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1091\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1088\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1089\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1090\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1092\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedSrationalArray(tif, ndir, dir, tag, count,
                                                   value);
  fprintf(_coverage_fout, "1093\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagFloat(TIFF *tif , uint32 *ndir ,
                                      TIFFDirEntry *dir , uint16 tag ,
                                      float value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1097\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1094\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1095\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1096\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1098\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedFloat(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "1099\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagFloatArray(TIFF *tif , uint32 *ndir ,
                                           TIFFDirEntry *dir , uint16 tag ,
                                           uint32 count , float *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1103\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1100\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1101\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1102\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1104\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedFloatArray(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "1105\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagFloatPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               float value ) ;
static char const   module___7[36]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'F',      (char const   )'l',      (char const   )'o', 
        (char const   )'a',      (char const   )'t',      (char const   )'P',      (char const   )'e', 
        (char const   )'r',      (char const   )'S',      (char const   )'a',      (char const   )'m', 
        (char const   )'p',      (char const   )'l',      (char const   )'e',      (char const   )'\000'};
static int TIFFWriteDirectoryTagFloatPerSample(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               float value ) 
{ float *m ;
  float *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1117\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1106\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1107\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1108\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1118\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_samplesperpixel * sizeof(float )));
  fprintf(_coverage_fout, "1119\n");
  fflush(_coverage_fout);
  m = (float *)tmp;
  fprintf(_coverage_fout, "1120\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1109\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___7, "Out of memory");
    fprintf(_coverage_fout, "1110\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "1111\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1121\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "1122\n");
  fflush(_coverage_fout);
  nb = (unsigned short)0;
  fprintf(_coverage_fout, "1123\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1113\n");
    fflush(_coverage_fout);
    if ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
      fprintf(_coverage_fout, "1112\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1114\n");
    fflush(_coverage_fout);
    *na = value;
    fprintf(_coverage_fout, "1115\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "1116\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb + 1);
  }
  fprintf(_coverage_fout, "1124\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedFloatArray(tif, ndir, dir, tag,
                                             (unsigned int )tif->tif_dir.td_samplesperpixel,
                                             m);
  fprintf(_coverage_fout, "1125\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "1126\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagDouble(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir , uint16 tag ,
                                       double value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1130\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1127\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1128\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1129\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1131\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedDouble(tif, ndir, dir, tag, value);
  fprintf(_coverage_fout, "1132\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagDoubleArray(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 count , double *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1136\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1133\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1134\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1135\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1137\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedDoubleArray(tif, ndir, dir, tag, count,
                                                value);
  fprintf(_coverage_fout, "1138\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagDoublePerSample(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                double value ) ;
static char const   module___8[37]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'D',      (char const   )'o',      (char const   )'u', 
        (char const   )'b',      (char const   )'l',      (char const   )'e',      (char const   )'P', 
        (char const   )'e',      (char const   )'r',      (char const   )'S',      (char const   )'a', 
        (char const   )'m',      (char const   )'p',      (char const   )'l',      (char const   )'e', 
        (char const   )'\000'};
static int TIFFWriteDirectoryTagDoublePerSample(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                double value ) 
{ double *m ;
  double *na ;
  uint16 nb ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1150\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1139\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1140\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1141\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1151\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_samplesperpixel * sizeof(double )));
  fprintf(_coverage_fout, "1152\n");
  fflush(_coverage_fout);
  m = (double *)tmp;
  fprintf(_coverage_fout, "1153\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1142\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___8, "Out of memory");
    fprintf(_coverage_fout, "1143\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "1144\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1154\n");
  fflush(_coverage_fout);
  na = m;
  fprintf(_coverage_fout, "1155\n");
  fflush(_coverage_fout);
  nb = (unsigned short)0;
  fprintf(_coverage_fout, "1156\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1146\n");
    fflush(_coverage_fout);
    if ((int )nb < (int )tif->tif_dir.td_samplesperpixel) {
      fprintf(_coverage_fout, "1145\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1147\n");
    fflush(_coverage_fout);
    *na = value;
    fprintf(_coverage_fout, "1148\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "1149\n");
    fflush(_coverage_fout);
    nb = (uint16 )((int )nb + 1);
  }
  fprintf(_coverage_fout, "1157\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedDoubleArray(tif, ndir, dir, tag,
                                              (unsigned int )tif->tif_dir.td_samplesperpixel,
                                              m);
  fprintf(_coverage_fout, "1158\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "1159\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagIfdArray(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir , uint16 tag ,
                                         uint32 count , uint32 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1163\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1160\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1161\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1162\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1164\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedIfdArray(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "1165\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagIfd8Array(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 count , uint64 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1169\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1166\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1167\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1168\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1170\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagCheckedIfd8Array(tif, ndir, dir, tag, count, value);
  fprintf(_coverage_fout, "1171\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagShortLong(TIFF *tif , uint32 *ndir ,
                                          TIFFDirEntry *dir , uint16 tag ,
                                          uint32 value ) 
{ int tmp ;
  int tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1179\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1172\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1173\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1174\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1180\n");
  fflush(_coverage_fout);
  if (value <= 65535U) {
    fprintf(_coverage_fout, "1175\n");
    fflush(_coverage_fout);
    tmp = TIFFWriteDirectoryTagCheckedShort(tif, ndir, dir, tag,
                                            (unsigned short )value);
    fprintf(_coverage_fout, "1176\n");
    fflush(_coverage_fout);
    return (tmp);
  } else {
    fprintf(_coverage_fout, "1177\n");
    fflush(_coverage_fout);
    tmp___0 = TIFFWriteDirectoryTagCheckedLong(tif, ndir, dir, tag, value);
    fprintf(_coverage_fout, "1178\n");
    fflush(_coverage_fout);
    return (tmp___0);
  }
}
}
static int TIFFWriteDirectoryTagLongLong8Array(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , uint64 *value ) ;
static char const   module___9[36]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'L',      (char const   )'o',      (char const   )'n', 
        (char const   )'g',      (char const   )'L',      (char const   )'o',      (char const   )'n', 
        (char const   )'g',      (char const   )'8',      (char const   )'A',      (char const   )'r', 
        (char const   )'r',      (char const   )'a',      (char const   )'y',      (char const   )'\000'};
static int TIFFWriteDirectoryTagLongLong8Array(TIFF *tif , uint32 *ndir ,
                                               TIFFDirEntry *dir , uint16 tag ,
                                               uint32 count , uint64 *value ) 
{ uint64 *ma ;
  uint32 mb ;
  uint32 *p ;
  uint32 *q ;
  int o ;
  int tmp ;
  void *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1201\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1181\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1182\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1183\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1202\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 524288U) {
    fprintf(_coverage_fout, "1184\n");
    fflush(_coverage_fout);
    tmp = TIFFWriteDirectoryTagCheckedLong8Array(tif, ndir, dir, tag, count,
                                                 value);
    fprintf(_coverage_fout, "1185\n");
    fflush(_coverage_fout);
    return (tmp);
  } else {
    fprintf(_coverage_fout, "1186\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1203\n");
  fflush(_coverage_fout);
  tmp___0 = _TIFFmalloc((long )(count * sizeof(uint32 )));
  fprintf(_coverage_fout, "1204\n");
  fflush(_coverage_fout);
  p = (uint32 *)tmp___0;
  fprintf(_coverage_fout, "1205\n");
  fflush(_coverage_fout);
  if ((unsigned int )p == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1187\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___9, "Out of memory");
    fprintf(_coverage_fout, "1188\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "1189\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1206\n");
  fflush(_coverage_fout);
  q = p;
  fprintf(_coverage_fout, "1207\n");
  fflush(_coverage_fout);
  ma = value;
  fprintf(_coverage_fout, "1208\n");
  fflush(_coverage_fout);
  mb = 0U;
  fprintf(_coverage_fout, "1209\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1195\n");
    fflush(_coverage_fout);
    if (mb < count) {
      fprintf(_coverage_fout, "1190\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1196\n");
    fflush(_coverage_fout);
    if (*ma > 4294967295ULL) {
      fprintf(_coverage_fout, "1191\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___9,
                   "Attempt to write value larger than 0xFFFFFFFF in Classic TIFF file.");
      fprintf(_coverage_fout, "1192\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)p);
      fprintf(_coverage_fout, "1193\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "1194\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1197\n");
    fflush(_coverage_fout);
    *q = (unsigned int )*ma;
    fprintf(_coverage_fout, "1198\n");
    fflush(_coverage_fout);
    ma ++;
    fprintf(_coverage_fout, "1199\n");
    fflush(_coverage_fout);
    mb ++;
    fprintf(_coverage_fout, "1200\n");
    fflush(_coverage_fout);
    q ++;
  }
  fprintf(_coverage_fout, "1210\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedLongArray(tif, ndir, dir, tag, count, p);
  fprintf(_coverage_fout, "1211\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)p);
  fprintf(_coverage_fout, "1212\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagShortLongLong8Array(TIFF *tif , uint32 *ndir ,
                                                    TIFFDirEntry *dir ,
                                                    uint16 tag , uint32 count ,
                                                    uint64 *value ) ;
static char const   module___10[41]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'S',      (char const   )'h',      (char const   )'o', 
        (char const   )'r',      (char const   )'t',      (char const   )'L',      (char const   )'o', 
        (char const   )'n',      (char const   )'g',      (char const   )'L',      (char const   )'o', 
        (char const   )'n',      (char const   )'g',      (char const   )'8',      (char const   )'A', 
        (char const   )'r',      (char const   )'r',      (char const   )'a',      (char const   )'y', 
        (char const   )'\000'};
static int TIFFWriteDirectoryTagShortLongLong8Array(TIFF *tif , uint32 *ndir ,
                                                    TIFFDirEntry *dir ,
                                                    uint16 tag , uint32 count ,
                                                    uint64 *value ) 
{ uint64 *ma ;
  uint32 mb ;
  uint8 n ;
  int o ;
  uint16 *p ;
  uint16 *q ;
  void *tmp ;
  uint32 *p___0 ;
  uint32 *q___0 ;
  void *tmp___0 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1271\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1213\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1214\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1215\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1272\n");
  fflush(_coverage_fout);
  n = (unsigned char)0;
  fprintf(_coverage_fout, "1273\n");
  fflush(_coverage_fout);
  ma = value;
  fprintf(_coverage_fout, "1274\n");
  fflush(_coverage_fout);
  mb = 0U;
  fprintf(_coverage_fout, "1275\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1225\n");
    fflush(_coverage_fout);
    if (mb < count) {
      fprintf(_coverage_fout, "1216\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1226\n");
    fflush(_coverage_fout);
    if ((int )n == 0) {
      fprintf(_coverage_fout, "1219\n");
      fflush(_coverage_fout);
      if (*ma > 65535ULL) {
        fprintf(_coverage_fout, "1217\n");
        fflush(_coverage_fout);
        n = (unsigned char)1;
      } else {
        fprintf(_coverage_fout, "1218\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "1220\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1227\n");
    fflush(_coverage_fout);
    if ((int )n == 1) {
      fprintf(_coverage_fout, "1223\n");
      fflush(_coverage_fout);
      if (*ma > 4294967295ULL) {
        fprintf(_coverage_fout, "1221\n");
        fflush(_coverage_fout);
        n = (unsigned char)2;
        break;
      } else {
        fprintf(_coverage_fout, "1222\n");
        fflush(_coverage_fout);

      }
    } else {
      fprintf(_coverage_fout, "1224\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1228\n");
    fflush(_coverage_fout);
    ma ++;
    fprintf(_coverage_fout, "1229\n");
    fflush(_coverage_fout);
    mb ++;
  }
  fprintf(_coverage_fout, "1276\n");
  fflush(_coverage_fout);
  if ((int )n == 0) {
    fprintf(_coverage_fout, "1239\n");
    fflush(_coverage_fout);
    tmp = _TIFFmalloc((long )(count * sizeof(uint16 )));
    fprintf(_coverage_fout, "1240\n");
    fflush(_coverage_fout);
    p = (uint16 *)tmp;
    fprintf(_coverage_fout, "1241\n");
    fflush(_coverage_fout);
    if ((unsigned int )p == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "1230\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___10, "Out of memory");
      fprintf(_coverage_fout, "1231\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "1232\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1242\n");
    fflush(_coverage_fout);
    ma = value;
    fprintf(_coverage_fout, "1243\n");
    fflush(_coverage_fout);
    mb = 0U;
    fprintf(_coverage_fout, "1244\n");
    fflush(_coverage_fout);
    q = p;
    fprintf(_coverage_fout, "1245\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "1234\n");
      fflush(_coverage_fout);
      if (mb < count) {
        fprintf(_coverage_fout, "1233\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "1235\n");
      fflush(_coverage_fout);
      *q = (unsigned short )*ma;
      fprintf(_coverage_fout, "1236\n");
      fflush(_coverage_fout);
      ma ++;
      fprintf(_coverage_fout, "1237\n");
      fflush(_coverage_fout);
      mb ++;
      fprintf(_coverage_fout, "1238\n");
      fflush(_coverage_fout);
      q ++;
    }
    fprintf(_coverage_fout, "1246\n");
    fflush(_coverage_fout);
    o = TIFFWriteDirectoryTagCheckedShortArray(tif, ndir, dir, tag, count, p);
    fprintf(_coverage_fout, "1247\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)p);
  } else {
    fprintf(_coverage_fout, "1270\n");
    fflush(_coverage_fout);
    if ((int )n == 1) {
      fprintf(_coverage_fout, "1257\n");
      fflush(_coverage_fout);
      tmp___0 = _TIFFmalloc((long )(count * sizeof(uint32 )));
      fprintf(_coverage_fout, "1258\n");
      fflush(_coverage_fout);
      p___0 = (uint32 *)tmp___0;
      fprintf(_coverage_fout, "1259\n");
      fflush(_coverage_fout);
      if ((unsigned int )p___0 == (unsigned int )((void *)0)) {
        fprintf(_coverage_fout, "1248\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___10, "Out of memory");
        fprintf(_coverage_fout, "1249\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "1250\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1260\n");
      fflush(_coverage_fout);
      ma = value;
      fprintf(_coverage_fout, "1261\n");
      fflush(_coverage_fout);
      mb = 0U;
      fprintf(_coverage_fout, "1262\n");
      fflush(_coverage_fout);
      q___0 = p___0;
      fprintf(_coverage_fout, "1263\n");
      fflush(_coverage_fout);
      while (1) {
        fprintf(_coverage_fout, "1252\n");
        fflush(_coverage_fout);
        if (mb < count) {
          fprintf(_coverage_fout, "1251\n");
          fflush(_coverage_fout);

        } else {
          break;
        }
        fprintf(_coverage_fout, "1253\n");
        fflush(_coverage_fout);
        *q___0 = (unsigned int )*ma;
        fprintf(_coverage_fout, "1254\n");
        fflush(_coverage_fout);
        ma ++;
        fprintf(_coverage_fout, "1255\n");
        fflush(_coverage_fout);
        mb ++;
        fprintf(_coverage_fout, "1256\n");
        fflush(_coverage_fout);
        q___0 ++;
      }
      fprintf(_coverage_fout, "1264\n");
      fflush(_coverage_fout);
      o = TIFFWriteDirectoryTagCheckedLongArray(tif, ndir, dir, tag, count,
                                                p___0);
      fprintf(_coverage_fout, "1265\n");
      fflush(_coverage_fout);
      _TIFFfree((void *)p___0);
    } else {
      fprintf(_coverage_fout, "1268\n");
      fflush(_coverage_fout);
      if ((int )n == 2) {
        fprintf(_coverage_fout, "1266\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "1267\n");
        fflush(_coverage_fout);
        __assert_fail("n==2", "tif_dirwrite.c", 1511U,
                      "TIFFWriteDirectoryTagShortLongLong8Array");
      }
      fprintf(_coverage_fout, "1269\n");
      fflush(_coverage_fout);
      o = TIFFWriteDirectoryTagCheckedLong8Array(tif, ndir, dir, tag, count,
                                                 value);
    }
  }
  fprintf(_coverage_fout, "1277\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagColormap(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir ) ;
static char const   module___11[30]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'C',      (char const   )'o',      (char const   )'l', 
        (char const   )'o',      (char const   )'r',      (char const   )'m',      (char const   )'a', 
        (char const   )'p',      (char const   )'\000'};
static int TIFFWriteDirectoryTagColormap(TIFF *tif , uint32 *ndir ,
                                         TIFFDirEntry *dir ) 
{ uint32 m ;
  uint16 *n ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1284\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1278\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1279\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1280\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1285\n");
  fflush(_coverage_fout);
  m = (unsigned int )(1 << (int )tif->tif_dir.td_bitspersample);
  fprintf(_coverage_fout, "1286\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((3U * m) * sizeof(uint16 )));
  fprintf(_coverage_fout, "1287\n");
  fflush(_coverage_fout);
  n = (uint16 *)tmp;
  fprintf(_coverage_fout, "1288\n");
  fflush(_coverage_fout);
  if ((unsigned int )n == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1281\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___11, "Out of memory");
    fprintf(_coverage_fout, "1282\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "1283\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1289\n");
  fflush(_coverage_fout);
  _TIFFmemcpy((void *)(n + 0), (void const   *)tif->tif_dir.td_colormap[0],
              (long )(m * sizeof(uint16 )));
  fprintf(_coverage_fout, "1290\n");
  fflush(_coverage_fout);
  _TIFFmemcpy((void *)(n + m), (void const   *)tif->tif_dir.td_colormap[1],
              (long )(m * sizeof(uint16 )));
  fprintf(_coverage_fout, "1291\n");
  fflush(_coverage_fout);
  _TIFFmemcpy((void *)(n + 2U * m), (void const   *)tif->tif_dir.td_colormap[2],
              (long )(m * sizeof(uint16 )));
  fprintf(_coverage_fout, "1292\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagCheckedShortArray(tif, ndir, dir,
                                             (unsigned short)320, 3U * m, n);
  fprintf(_coverage_fout, "1293\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)n);
  fprintf(_coverage_fout, "1294\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagTransferfunction(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ) ;
static char const   module___12[38]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'T',      (char const   )'r',      (char const   )'a', 
        (char const   )'n',      (char const   )'s',      (char const   )'f',      (char const   )'e', 
        (char const   )'r',      (char const   )'f',      (char const   )'u',      (char const   )'n', 
        (char const   )'c',      (char const   )'t',      (char const   )'i',      (char const   )'o', 
        (char const   )'n',      (char const   )'\000'};
static int TIFFWriteDirectoryTagTransferfunction(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ) 
{ uint32 m ;
  uint16 n ;
  uint16 *o ;
  int p ;
  int tmp ;
  int tmp___0 ;
  void *tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1319\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1295\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1296\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1297\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1320\n");
  fflush(_coverage_fout);
  m = (unsigned int )(1 << (int )tif->tif_dir.td_bitspersample);
  fprintf(_coverage_fout, "1321\n");
  fflush(_coverage_fout);
  n = (unsigned short )((int )tif->tif_dir.td_samplesperpixel - (int )tif->tif_dir.td_extrasamples);
  fprintf(_coverage_fout, "1322\n");
  fflush(_coverage_fout);
  if ((int )n > 3) {
    fprintf(_coverage_fout, "1298\n");
    fflush(_coverage_fout);
    n = (unsigned short)3;
  } else {
    fprintf(_coverage_fout, "1299\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1323\n");
  fflush(_coverage_fout);
  if ((int )n == 3) {
    fprintf(_coverage_fout, "1302\n");
    fflush(_coverage_fout);
    tmp = _TIFFmemcmp((void const   *)tif->tif_dir.td_transferfunction[0],
                      (void const   *)tif->tif_dir.td_transferfunction[2],
                      (long )(m * sizeof(uint16 )));
    fprintf(_coverage_fout, "1303\n");
    fflush(_coverage_fout);
    if (tmp) {
      fprintf(_coverage_fout, "1300\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "1301\n");
      fflush(_coverage_fout);
      n = (unsigned short)2;
    }
  } else {
    fprintf(_coverage_fout, "1304\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1324\n");
  fflush(_coverage_fout);
  if ((int )n == 2) {
    fprintf(_coverage_fout, "1307\n");
    fflush(_coverage_fout);
    tmp___0 = _TIFFmemcmp((void const   *)tif->tif_dir.td_transferfunction[0],
                          (void const   *)tif->tif_dir.td_transferfunction[1],
                          (long )(m * sizeof(uint16 )));
    fprintf(_coverage_fout, "1308\n");
    fflush(_coverage_fout);
    if (tmp___0) {
      fprintf(_coverage_fout, "1305\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "1306\n");
      fflush(_coverage_fout);
      n = (unsigned short)1;
    }
  } else {
    fprintf(_coverage_fout, "1309\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1325\n");
  fflush(_coverage_fout);
  if ((int )n == 0) {
    fprintf(_coverage_fout, "1310\n");
    fflush(_coverage_fout);
    n = (unsigned short)1;
  } else {
    fprintf(_coverage_fout, "1311\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1326\n");
  fflush(_coverage_fout);
  tmp___1 = _TIFFmalloc((long )(((uint32 )n * m) * sizeof(uint16 )));
  fprintf(_coverage_fout, "1327\n");
  fflush(_coverage_fout);
  o = (uint16 *)tmp___1;
  fprintf(_coverage_fout, "1328\n");
  fflush(_coverage_fout);
  if ((unsigned int )o == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1312\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___12, "Out of memory");
    fprintf(_coverage_fout, "1313\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "1314\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1329\n");
  fflush(_coverage_fout);
  _TIFFmemcpy((void *)(o + 0),
              (void const   *)tif->tif_dir.td_transferfunction[0],
              (long )(m * sizeof(uint16 )));
  fprintf(_coverage_fout, "1330\n");
  fflush(_coverage_fout);
  if ((int )n > 1) {
    fprintf(_coverage_fout, "1315\n");
    fflush(_coverage_fout);
    _TIFFmemcpy((void *)(o + m),
                (void const   *)tif->tif_dir.td_transferfunction[1],
                (long )(m * sizeof(uint16 )));
  } else {
    fprintf(_coverage_fout, "1316\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1331\n");
  fflush(_coverage_fout);
  if ((int )n > 2) {
    fprintf(_coverage_fout, "1317\n");
    fflush(_coverage_fout);
    _TIFFmemcpy((void *)(o + 2U * m),
                (void const   *)tif->tif_dir.td_transferfunction[2],
                (long )(m * sizeof(uint16 )));
  } else {
    fprintf(_coverage_fout, "1318\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1332\n");
  fflush(_coverage_fout);
  p = TIFFWriteDirectoryTagCheckedShortArray(tif, ndir, dir,
                                             (unsigned short)301,
                                             (uint32 )n * m, o);
  fprintf(_coverage_fout, "1333\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)o);
  fprintf(_coverage_fout, "1334\n");
  fflush(_coverage_fout);
  return (p);
}
}
static int TIFFWriteDirectoryTagSubifd(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir ) ;
static char const   module___13[28]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'S',      (char const   )'u',      (char const   )'b', 
        (char const   )'i',      (char const   )'f',      (char const   )'d',      (char const   )'\000'};
static int TIFFWriteDirectoryTagSubifd(TIFF *tif , uint32 *ndir ,
                                       TIFFDirEntry *dir ) 
{ uint64 m ;
  int n ;
  uint32 *o ;
  uint64 *pa ;
  uint32 *pb ;
  uint16 p ;
  void *tmp ;
  uint32 *tmp___0 ;
  uint64 *tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1368\n");
  fflush(_coverage_fout);
  if ((int )tif->tif_dir.td_nsubifd == 0) {
    fprintf(_coverage_fout, "1335\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1336\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1369\n");
  fflush(_coverage_fout);
  if ((unsigned int )dir == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1337\n");
    fflush(_coverage_fout);
    (*ndir) ++;
    fprintf(_coverage_fout, "1338\n");
    fflush(_coverage_fout);
    return (1);
  } else {
    fprintf(_coverage_fout, "1339\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1370\n");
  fflush(_coverage_fout);
  m = tif->tif_dataoff;
  fprintf(_coverage_fout, "1371\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "1354\n");
    fflush(_coverage_fout);
    tmp = _TIFFmalloc((long )((unsigned int )tif->tif_dir.td_nsubifd * sizeof(uint32 )));
    fprintf(_coverage_fout, "1355\n");
    fflush(_coverage_fout);
    o = (uint32 *)tmp;
    fprintf(_coverage_fout, "1356\n");
    fflush(_coverage_fout);
    if ((unsigned int )o == (unsigned int )((void *)0)) {
      fprintf(_coverage_fout, "1340\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___13, "Out of memory");
      fprintf(_coverage_fout, "1341\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "1342\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1357\n");
    fflush(_coverage_fout);
    pa = tif->tif_dir.td_subifd;
    fprintf(_coverage_fout, "1358\n");
    fflush(_coverage_fout);
    pb = o;
    fprintf(_coverage_fout, "1359\n");
    fflush(_coverage_fout);
    p = (unsigned short)0;
    fprintf(_coverage_fout, "1360\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "1346\n");
      fflush(_coverage_fout);
      if ((int )p < (int )tif->tif_dir.td_nsubifd) {
        fprintf(_coverage_fout, "1343\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "1347\n");
      fflush(_coverage_fout);
      if (*pa <= 4294967295ULL) {
        fprintf(_coverage_fout, "1344\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "1345\n");
        fflush(_coverage_fout);
        __assert_fail("*pa<=0xFFFFFFFFUL", "tif_dirwrite.c", 1625U,
                      "TIFFWriteDirectoryTagSubifd");
      }
      fprintf(_coverage_fout, "1348\n");
      fflush(_coverage_fout);
      tmp___0 = pb;
      fprintf(_coverage_fout, "1349\n");
      fflush(_coverage_fout);
      pb ++;
      fprintf(_coverage_fout, "1350\n");
      fflush(_coverage_fout);
      tmp___1 = pa;
      fprintf(_coverage_fout, "1351\n");
      fflush(_coverage_fout);
      pa ++;
      fprintf(_coverage_fout, "1352\n");
      fflush(_coverage_fout);
      *tmp___0 = (unsigned int )*tmp___1;
      fprintf(_coverage_fout, "1353\n");
      fflush(_coverage_fout);
      p = (uint16 )((int )p + 1);
    }
    fprintf(_coverage_fout, "1361\n");
    fflush(_coverage_fout);
    n = TIFFWriteDirectoryTagCheckedIfdArray(tif, ndir, dir,
                                             (unsigned short)330,
                                             (unsigned int )tif->tif_dir.td_nsubifd,
                                             o);
    fprintf(_coverage_fout, "1362\n");
    fflush(_coverage_fout);
    _TIFFfree((void *)o);
  } else {
    fprintf(_coverage_fout, "1363\n");
    fflush(_coverage_fout);
    n = TIFFWriteDirectoryTagCheckedIfd8Array(tif, ndir, dir,
                                              (unsigned short)330,
                                              (unsigned int )tif->tif_dir.td_nsubifd,
                                              tif->tif_dir.td_subifd);
  }
  fprintf(_coverage_fout, "1372\n");
  fflush(_coverage_fout);
  if (! n) {
    fprintf(_coverage_fout, "1364\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "1365\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1373\n");
  fflush(_coverage_fout);
  tif->tif_flags |= 8192U;
  fprintf(_coverage_fout, "1374\n");
  fflush(_coverage_fout);
  tif->tif_nsubifd = tif->tif_dir.td_nsubifd;
  fprintf(_coverage_fout, "1375\n");
  fflush(_coverage_fout);
  if ((int )tif->tif_dir.td_nsubifd == 1) {
    fprintf(_coverage_fout, "1366\n");
    fflush(_coverage_fout);
    tif->tif_subifdoff = 0ULL;
  } else {
    fprintf(_coverage_fout, "1367\n");
    fflush(_coverage_fout);
    tif->tif_subifdoff = m;
  }
  fprintf(_coverage_fout, "1376\n");
  fflush(_coverage_fout);
  return (1);
}
}
static int TIFFWriteDirectoryTagCheckedAscii(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             uint32 count , char *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1379\n");
  fflush(_coverage_fout);
  if (sizeof(char ) == 1U) {
    fprintf(_coverage_fout, "1377\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1378\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(char)==1", "tif_dirwrite.c", 1655U,
                  "TIFFWriteDirectoryTagCheckedAscii");
  }
  fprintf(_coverage_fout, "1380\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)2, count,
                                  count, (void *)value);
  fprintf(_coverage_fout, "1381\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedUndefinedArray(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag ,
                                                      uint32 count ,
                                                      uint8 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1384\n");
  fflush(_coverage_fout);
  if (sizeof(uint8 ) == 1U) {
    fprintf(_coverage_fout, "1382\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1383\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint8)==1", "tif_dirwrite.c", 1662U,
                  "TIFFWriteDirectoryTagCheckedUndefinedArray");
  }
  fprintf(_coverage_fout, "1385\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)7, count,
                                  count, (void *)value);
  fprintf(_coverage_fout, "1386\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedByte(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint8 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1389\n");
  fflush(_coverage_fout);
  if (sizeof(uint8 ) == 1U) {
    fprintf(_coverage_fout, "1387\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1388\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint8)==1", "tif_dirwrite.c", 1669U,
                  "TIFFWriteDirectoryTagCheckedByte");
  }
  fprintf(_coverage_fout, "1390\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)1, 1U,
                                  1U, (void *)(& value));
  fprintf(_coverage_fout, "1391\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedByteArray(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint8 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1394\n");
  fflush(_coverage_fout);
  if (sizeof(uint8 ) == 1U) {
    fprintf(_coverage_fout, "1392\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1393\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint8)==1", "tif_dirwrite.c", 1676U,
                  "TIFFWriteDirectoryTagCheckedByteArray");
  }
  fprintf(_coverage_fout, "1395\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)1, count,
                                  count, (void *)value);
  fprintf(_coverage_fout, "1396\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSbyte(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             int8 value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1399\n");
  fflush(_coverage_fout);
  if (sizeof(int8 ) == 1U) {
    fprintf(_coverage_fout, "1397\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1398\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int8)==1", "tif_dirwrite.c", 1683U,
                  "TIFFWriteDirectoryTagCheckedSbyte");
  }
  fprintf(_coverage_fout, "1400\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)6, 1U,
                                  1U, (void *)(& value));
  fprintf(_coverage_fout, "1401\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSbyteArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  int8 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1404\n");
  fflush(_coverage_fout);
  if (sizeof(int8 ) == 1U) {
    fprintf(_coverage_fout, "1402\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1403\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int8)==1", "tif_dirwrite.c", 1690U,
                  "TIFFWriteDirectoryTagCheckedSbyteArray");
  }
  fprintf(_coverage_fout, "1405\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)6, count,
                                  count, (void *)value);
  fprintf(_coverage_fout, "1406\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedShort(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             uint16 value ) 
{ uint16 m ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1411\n");
  fflush(_coverage_fout);
  if (sizeof(uint16 ) == 2U) {
    fprintf(_coverage_fout, "1407\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1408\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint16)==2", "tif_dirwrite.c", 1698U,
                  "TIFFWriteDirectoryTagCheckedShort");
  }
  fprintf(_coverage_fout, "1412\n");
  fflush(_coverage_fout);
  m = value;
  fprintf(_coverage_fout, "1413\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1409\n");
    fflush(_coverage_fout);
    TIFFSwabShort(& m);
  } else {
    fprintf(_coverage_fout, "1410\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1414\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)3, 1U,
                                  2U, (void *)(& m));
  fprintf(_coverage_fout, "1415\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedShortArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  uint16 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1422\n");
  fflush(_coverage_fout);
  if (count < 0x80000000) {
    fprintf(_coverage_fout, "1416\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1417\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x80000000", "tif_dirwrite.c", 1708U,
                  "TIFFWriteDirectoryTagCheckedShortArray");
  }
  fprintf(_coverage_fout, "1423\n");
  fflush(_coverage_fout);
  if (sizeof(uint16 ) == 2U) {
    fprintf(_coverage_fout, "1418\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1419\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint16)==2", "tif_dirwrite.c", 1709U,
                  "TIFFWriteDirectoryTagCheckedShortArray");
  }
  fprintf(_coverage_fout, "1424\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1420\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfShort(value, (long )count);
  } else {
    fprintf(_coverage_fout, "1421\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1425\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)3, count,
                                  count * 2U, (void *)value);
  fprintf(_coverage_fout, "1426\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSshort(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              int16 value ) 
{ int16 m ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1431\n");
  fflush(_coverage_fout);
  if (sizeof(int16 ) == 2U) {
    fprintf(_coverage_fout, "1427\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1428\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int16)==2", "tif_dirwrite.c", 1719U,
                  "TIFFWriteDirectoryTagCheckedSshort");
  }
  fprintf(_coverage_fout, "1432\n");
  fflush(_coverage_fout);
  m = value;
  fprintf(_coverage_fout, "1433\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1429\n");
    fflush(_coverage_fout);
    TIFFSwabShort((uint16 *)(& m));
  } else {
    fprintf(_coverage_fout, "1430\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1434\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)8, 1U,
                                  2U, (void *)(& m));
  fprintf(_coverage_fout, "1435\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSshortArray(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   int16 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1442\n");
  fflush(_coverage_fout);
  if (count < 0x80000000) {
    fprintf(_coverage_fout, "1436\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1437\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x80000000", "tif_dirwrite.c", 1729U,
                  "TIFFWriteDirectoryTagCheckedSshortArray");
  }
  fprintf(_coverage_fout, "1443\n");
  fflush(_coverage_fout);
  if (sizeof(int16 ) == 2U) {
    fprintf(_coverage_fout, "1438\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1439\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int16)==2", "tif_dirwrite.c", 1730U,
                  "TIFFWriteDirectoryTagCheckedSshortArray");
  }
  fprintf(_coverage_fout, "1444\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1440\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfShort((uint16 *)value, (long )count);
  } else {
    fprintf(_coverage_fout, "1441\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1445\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)8, count,
                                  count * 2U, (void *)value);
  fprintf(_coverage_fout, "1446\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedLong(TIFF *tif , uint32 *ndir ,
                                            TIFFDirEntry *dir , uint16 tag ,
                                            uint32 value ) 
{ uint32 m ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1451\n");
  fflush(_coverage_fout);
  if (sizeof(uint32 ) == 4U) {
    fprintf(_coverage_fout, "1447\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1448\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint32)==4", "tif_dirwrite.c", 1740U,
                  "TIFFWriteDirectoryTagCheckedLong");
  }
  fprintf(_coverage_fout, "1452\n");
  fflush(_coverage_fout);
  m = value;
  fprintf(_coverage_fout, "1453\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1449\n");
    fflush(_coverage_fout);
    TIFFSwabLong(& m);
  } else {
    fprintf(_coverage_fout, "1450\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1454\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)4, 1U,
                                  4U, (void *)(& m));
  fprintf(_coverage_fout, "1455\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedLongArray(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint32 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1462\n");
  fflush(_coverage_fout);
  if (count < 1073741824U) {
    fprintf(_coverage_fout, "1456\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1457\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x40000000", "tif_dirwrite.c", 1750U,
                  "TIFFWriteDirectoryTagCheckedLongArray");
  }
  fprintf(_coverage_fout, "1463\n");
  fflush(_coverage_fout);
  if (sizeof(uint32 ) == 4U) {
    fprintf(_coverage_fout, "1458\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1459\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint32)==4", "tif_dirwrite.c", 1751U,
                  "TIFFWriteDirectoryTagCheckedLongArray");
  }
  fprintf(_coverage_fout, "1464\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1460\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong(value, (long )count);
  } else {
    fprintf(_coverage_fout, "1461\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1465\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)4, count,
                                  count * 4U, (void *)value);
  fprintf(_coverage_fout, "1466\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSlong(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             int32 value ) 
{ int32 m ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1471\n");
  fflush(_coverage_fout);
  if (sizeof(int32 ) == 4U) {
    fprintf(_coverage_fout, "1467\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1468\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int32)==4", "tif_dirwrite.c", 1761U,
                  "TIFFWriteDirectoryTagCheckedSlong");
  }
  fprintf(_coverage_fout, "1472\n");
  fflush(_coverage_fout);
  m = value;
  fprintf(_coverage_fout, "1473\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1469\n");
    fflush(_coverage_fout);
    TIFFSwabLong((uint32 *)(& m));
  } else {
    fprintf(_coverage_fout, "1470\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1474\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)9, 1U,
                                  4U, (void *)(& m));
  fprintf(_coverage_fout, "1475\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSlongArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  int32 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1482\n");
  fflush(_coverage_fout);
  if (count < 1073741824U) {
    fprintf(_coverage_fout, "1476\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1477\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x40000000", "tif_dirwrite.c", 1771U,
                  "TIFFWriteDirectoryTagCheckedSlongArray");
  }
  fprintf(_coverage_fout, "1483\n");
  fflush(_coverage_fout);
  if (sizeof(int32 ) == 4U) {
    fprintf(_coverage_fout, "1478\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1479\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int32)==4", "tif_dirwrite.c", 1772U,
                  "TIFFWriteDirectoryTagCheckedSlongArray");
  }
  fprintf(_coverage_fout, "1484\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1480\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong((uint32 *)value, (long )count);
  } else {
    fprintf(_coverage_fout, "1481\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1485\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)9, count,
                                  count * 4U, (void *)value);
  fprintf(_coverage_fout, "1486\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedLong8(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             uint64 value ) 
{ uint64 m ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1493\n");
  fflush(_coverage_fout);
  if (sizeof(uint64 ) == 8U) {
    fprintf(_coverage_fout, "1487\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1488\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint64)==8", "tif_dirwrite.c", 1782U,
                  "TIFFWriteDirectoryTagCheckedLong8");
  }
  fprintf(_coverage_fout, "1494\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 524288U) {
    fprintf(_coverage_fout, "1489\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1490\n");
    fflush(_coverage_fout);
    __assert_fail("tif->tif_flags&0x80000", "tif_dirwrite.c", 1783U,
                  "TIFFWriteDirectoryTagCheckedLong8");
  }
  fprintf(_coverage_fout, "1495\n");
  fflush(_coverage_fout);
  m = value;
  fprintf(_coverage_fout, "1496\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1491\n");
    fflush(_coverage_fout);
    TIFFSwabLong8(& m);
  } else {
    fprintf(_coverage_fout, "1492\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1497\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)16, 1U,
                                  8U, (void *)(& m));
  fprintf(_coverage_fout, "1498\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedLong8Array(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  uint64 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1507\n");
  fflush(_coverage_fout);
  if (count < 536870912U) {
    fprintf(_coverage_fout, "1499\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1500\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x20000000", "tif_dirwrite.c", 1793U,
                  "TIFFWriteDirectoryTagCheckedLong8Array");
  }
  fprintf(_coverage_fout, "1508\n");
  fflush(_coverage_fout);
  if (sizeof(uint64 ) == 8U) {
    fprintf(_coverage_fout, "1501\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1502\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint64)==8", "tif_dirwrite.c", 1794U,
                  "TIFFWriteDirectoryTagCheckedLong8Array");
  }
  fprintf(_coverage_fout, "1509\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 524288U) {
    fprintf(_coverage_fout, "1503\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1504\n");
    fflush(_coverage_fout);
    __assert_fail("tif->tif_flags&0x80000", "tif_dirwrite.c", 1795U,
                  "TIFFWriteDirectoryTagCheckedLong8Array");
  }
  fprintf(_coverage_fout, "1510\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1505\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong8(value, (long )count);
  } else {
    fprintf(_coverage_fout, "1506\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1511\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)16,
                                  count, count * 8U, (void *)value);
  fprintf(_coverage_fout, "1512\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSlong8(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              int64 value ) 
{ int64 m ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1519\n");
  fflush(_coverage_fout);
  if (sizeof(int64 ) == 8U) {
    fprintf(_coverage_fout, "1513\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1514\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int64)==8", "tif_dirwrite.c", 1805U,
                  "TIFFWriteDirectoryTagCheckedSlong8");
  }
  fprintf(_coverage_fout, "1520\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 524288U) {
    fprintf(_coverage_fout, "1515\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1516\n");
    fflush(_coverage_fout);
    __assert_fail("tif->tif_flags&0x80000", "tif_dirwrite.c", 1806U,
                  "TIFFWriteDirectoryTagCheckedSlong8");
  }
  fprintf(_coverage_fout, "1521\n");
  fflush(_coverage_fout);
  m = value;
  fprintf(_coverage_fout, "1522\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1517\n");
    fflush(_coverage_fout);
    TIFFSwabLong8((uint64 *)(& m));
  } else {
    fprintf(_coverage_fout, "1518\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1523\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)17, 1U,
                                  8U, (void *)(& m));
  fprintf(_coverage_fout, "1524\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedSlong8Array(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   int64 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1533\n");
  fflush(_coverage_fout);
  if (count < 536870912U) {
    fprintf(_coverage_fout, "1525\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1526\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x20000000", "tif_dirwrite.c", 1816U,
                  "TIFFWriteDirectoryTagCheckedSlong8Array");
  }
  fprintf(_coverage_fout, "1534\n");
  fflush(_coverage_fout);
  if (sizeof(int64 ) == 8U) {
    fprintf(_coverage_fout, "1527\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1528\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int64)==8", "tif_dirwrite.c", 1817U,
                  "TIFFWriteDirectoryTagCheckedSlong8Array");
  }
  fprintf(_coverage_fout, "1535\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 524288U) {
    fprintf(_coverage_fout, "1529\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1530\n");
    fflush(_coverage_fout);
    __assert_fail("tif->tif_flags&0x80000", "tif_dirwrite.c", 1818U,
                  "TIFFWriteDirectoryTagCheckedSlong8Array");
  }
  fprintf(_coverage_fout, "1536\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1531\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong8((uint64 *)value, (long )count);
  } else {
    fprintf(_coverage_fout, "1532\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1537\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)17,
                                  count, count * 8U, (void *)value);
  fprintf(_coverage_fout, "1538\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedRational(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                double value ) 
{ uint32 m[2] ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1556\n");
  fflush(_coverage_fout);
  if (value >= 0.0) {
    fprintf(_coverage_fout, "1539\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1540\n");
    fflush(_coverage_fout);
    __assert_fail("value>=0.0", "tif_dirwrite.c", 1828U,
                  "TIFFWriteDirectoryTagCheckedRational");
  }
  fprintf(_coverage_fout, "1557\n");
  fflush(_coverage_fout);
  if (sizeof(uint32 ) == 4U) {
    fprintf(_coverage_fout, "1541\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1542\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint32)==4", "tif_dirwrite.c", 1829U,
                  "TIFFWriteDirectoryTagCheckedRational");
  }
  fprintf(_coverage_fout, "1558\n");
  fflush(_coverage_fout);
  if (value <= 0.0) {
    fprintf(_coverage_fout, "1543\n");
    fflush(_coverage_fout);
    m[0] = 0U;
    fprintf(_coverage_fout, "1544\n");
    fflush(_coverage_fout);
    m[1] = 1U;
  } else {
    fprintf(_coverage_fout, "1552\n");
    fflush(_coverage_fout);
    if (value == (double )((unsigned int )value)) {
      fprintf(_coverage_fout, "1545\n");
      fflush(_coverage_fout);
      m[0] = (unsigned int )value;
      fprintf(_coverage_fout, "1546\n");
      fflush(_coverage_fout);
      m[1] = 1U;
    } else {
      fprintf(_coverage_fout, "1551\n");
      fflush(_coverage_fout);
      if (value < 1.0) {
        fprintf(_coverage_fout, "1547\n");
        fflush(_coverage_fout);
        m[0] = (unsigned int )(value * (double )0xFFFFFFFF);
        fprintf(_coverage_fout, "1548\n");
        fflush(_coverage_fout);
        m[1] = 0xFFFFFFFF;
      } else {
        fprintf(_coverage_fout, "1549\n");
        fflush(_coverage_fout);
        m[0] = 0xFFFFFFFF;
        fprintf(_coverage_fout, "1550\n");
        fflush(_coverage_fout);
        m[1] = (unsigned int )((double )0xFFFFFFFF / value);
      }
    }
  }
  fprintf(_coverage_fout, "1559\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1553\n");
    fflush(_coverage_fout);
    TIFFSwabLong(& m[0]);
    fprintf(_coverage_fout, "1554\n");
    fflush(_coverage_fout);
    TIFFSwabLong(& m[1]);
  } else {
    fprintf(_coverage_fout, "1555\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1560\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)5, 1U,
                                  8U, (void *)(& m[0]));
  fprintf(_coverage_fout, "1561\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedRationalArray(TIFF *tif , uint32 *ndir ,
                                                     TIFFDirEntry *dir ,
                                                     uint16 tag , uint32 count ,
                                                     float *value ) ;
static char const   module___14[42]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'C',      (char const   )'h',      (char const   )'e', 
        (char const   )'c',      (char const   )'k',      (char const   )'e',      (char const   )'d', 
        (char const   )'R',      (char const   )'a',      (char const   )'t',      (char const   )'i', 
        (char const   )'o',      (char const   )'n',      (char const   )'a',      (char const   )'l', 
        (char const   )'A',      (char const   )'r',      (char const   )'r',      (char const   )'a', 
        (char const   )'y',      (char const   )'\000'};
static int TIFFWriteDirectoryTagCheckedRationalArray(TIFF *tif , uint32 *ndir ,
                                                     TIFFDirEntry *dir ,
                                                     uint16 tag , uint32 count ,
                                                     float *value ) 
{ uint32 *m ;
  float *na ;
  uint32 *nb ;
  uint32 nc ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1585\n");
  fflush(_coverage_fout);
  if (sizeof(uint32 ) == 4U) {
    fprintf(_coverage_fout, "1562\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1563\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint32)==4", "tif_dirwrite.c", 1867U,
                  "TIFFWriteDirectoryTagCheckedRationalArray");
  }
  fprintf(_coverage_fout, "1586\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((count * 2U) * sizeof(uint32 )));
  fprintf(_coverage_fout, "1587\n");
  fflush(_coverage_fout);
  m = (uint32 *)tmp;
  fprintf(_coverage_fout, "1588\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1564\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___14, "Out of memory");
    fprintf(_coverage_fout, "1565\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "1566\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1589\n");
  fflush(_coverage_fout);
  na = value;
  fprintf(_coverage_fout, "1590\n");
  fflush(_coverage_fout);
  nb = m;
  fprintf(_coverage_fout, "1591\n");
  fflush(_coverage_fout);
  nc = 0U;
  fprintf(_coverage_fout, "1592\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1578\n");
    fflush(_coverage_fout);
    if (nc < count) {
      fprintf(_coverage_fout, "1567\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1579\n");
    fflush(_coverage_fout);
    if ((double )*na <= 0.0) {
      fprintf(_coverage_fout, "1568\n");
      fflush(_coverage_fout);
      *(nb + 0) = 0U;
      fprintf(_coverage_fout, "1569\n");
      fflush(_coverage_fout);
      *(nb + 1) = 1U;
    } else {
      fprintf(_coverage_fout, "1577\n");
      fflush(_coverage_fout);
      if (*na == (float )((unsigned int )*na)) {
        fprintf(_coverage_fout, "1570\n");
        fflush(_coverage_fout);
        *(nb + 0) = (unsigned int )*na;
        fprintf(_coverage_fout, "1571\n");
        fflush(_coverage_fout);
        *(nb + 1) = 1U;
      } else {
        fprintf(_coverage_fout, "1576\n");
        fflush(_coverage_fout);
        if ((double )*na < 1.0) {
          fprintf(_coverage_fout, "1572\n");
          fflush(_coverage_fout);
          *(nb + 0) = (unsigned int )(*na * (float )0xFFFFFFFF);
          fprintf(_coverage_fout, "1573\n");
          fflush(_coverage_fout);
          *(nb + 1) = 0xFFFFFFFF;
        } else {
          fprintf(_coverage_fout, "1574\n");
          fflush(_coverage_fout);
          *(nb + 0) = 0xFFFFFFFF;
          fprintf(_coverage_fout, "1575\n");
          fflush(_coverage_fout);
          *(nb + 1) = (unsigned int )((float )0xFFFFFFFF / *na);
        }
      }
    }
    fprintf(_coverage_fout, "1580\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "1581\n");
    fflush(_coverage_fout);
    nb += 2;
    fprintf(_coverage_fout, "1582\n");
    fflush(_coverage_fout);
    nc ++;
  }
  fprintf(_coverage_fout, "1593\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1583\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong(m, (long )(count * 2U));
  } else {
    fprintf(_coverage_fout, "1584\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1594\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)5, count,
                                count * 8U, (void *)(m + 0));
  fprintf(_coverage_fout, "1595\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "1596\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagCheckedSrationalArray(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag ,
                                                      uint32 count ,
                                                      float *value ) ;
static char const   module___15[43]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'C',      (char const   )'h',      (char const   )'e', 
        (char const   )'c',      (char const   )'k',      (char const   )'e',      (char const   )'d', 
        (char const   )'S',      (char const   )'r',      (char const   )'a',      (char const   )'t', 
        (char const   )'i',      (char const   )'o',      (char const   )'n',      (char const   )'a', 
        (char const   )'l',      (char const   )'A',      (char const   )'r',      (char const   )'r', 
        (char const   )'a',      (char const   )'y',      (char const   )'\000'};
static int TIFFWriteDirectoryTagCheckedSrationalArray(TIFF *tif , uint32 *ndir ,
                                                      TIFFDirEntry *dir ,
                                                      uint16 tag ,
                                                      uint32 count ,
                                                      float *value ) 
{ int32 *m ;
  float *na ;
  int32 *nb ;
  uint32 nc ;
  int o ;
  void *tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1626\n");
  fflush(_coverage_fout);
  if (sizeof(int32 ) == 4U) {
    fprintf(_coverage_fout, "1597\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1598\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(int32)==4", "tif_dirwrite.c", 1913U,
                  "TIFFWriteDirectoryTagCheckedSrationalArray");
  }
  fprintf(_coverage_fout, "1627\n");
  fflush(_coverage_fout);
  tmp = _TIFFmalloc((long )((count * 2U) * sizeof(int32 )));
  fprintf(_coverage_fout, "1628\n");
  fflush(_coverage_fout);
  m = (int32 *)tmp;
  fprintf(_coverage_fout, "1629\n");
  fflush(_coverage_fout);
  if ((unsigned int )m == (unsigned int )((void *)0)) {
    fprintf(_coverage_fout, "1599\n");
    fflush(_coverage_fout);
    TIFFErrorExt(tif->tif_clientdata, module___15, "Out of memory");
    fprintf(_coverage_fout, "1600\n");
    fflush(_coverage_fout);
    return (0);
  } else {
    fprintf(_coverage_fout, "1601\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1630\n");
  fflush(_coverage_fout);
  na = value;
  fprintf(_coverage_fout, "1631\n");
  fflush(_coverage_fout);
  nb = m;
  fprintf(_coverage_fout, "1632\n");
  fflush(_coverage_fout);
  nc = 0U;
  fprintf(_coverage_fout, "1633\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1619\n");
    fflush(_coverage_fout);
    if (nc < count) {
      fprintf(_coverage_fout, "1602\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1620\n");
    fflush(_coverage_fout);
    if ((double )*na < 0.0) {
      fprintf(_coverage_fout, "1610\n");
      fflush(_coverage_fout);
      if (*na == (float )((int )*na)) {
        fprintf(_coverage_fout, "1603\n");
        fflush(_coverage_fout);
        *(nb + 0) = (int )*na;
        fprintf(_coverage_fout, "1604\n");
        fflush(_coverage_fout);
        *(nb + 1) = 1;
      } else {
        fprintf(_coverage_fout, "1609\n");
        fflush(_coverage_fout);
        if ((double )*na > - 1.0) {
          fprintf(_coverage_fout, "1605\n");
          fflush(_coverage_fout);
          *(nb + 0) = - ((int )(- *na * (float )0x7FFFFFFF));
          fprintf(_coverage_fout, "1606\n");
          fflush(_coverage_fout);
          *(nb + 1) = 0x7FFFFFFF;
        } else {
          fprintf(_coverage_fout, "1607\n");
          fflush(_coverage_fout);
          *(nb + 0) = -2147483647;
          fprintf(_coverage_fout, "1608\n");
          fflush(_coverage_fout);
          *(nb + 1) = (int )((float )0x7FFFFFFF / - *na);
        }
      }
    } else {
      fprintf(_coverage_fout, "1618\n");
      fflush(_coverage_fout);
      if (*na == (float )((int )*na)) {
        fprintf(_coverage_fout, "1611\n");
        fflush(_coverage_fout);
        *(nb + 0) = (int )*na;
        fprintf(_coverage_fout, "1612\n");
        fflush(_coverage_fout);
        *(nb + 1) = 1;
      } else {
        fprintf(_coverage_fout, "1617\n");
        fflush(_coverage_fout);
        if ((double )*na < 1.0) {
          fprintf(_coverage_fout, "1613\n");
          fflush(_coverage_fout);
          *(nb + 0) = (int )(*na * (float )0x7FFFFFFF);
          fprintf(_coverage_fout, "1614\n");
          fflush(_coverage_fout);
          *(nb + 1) = 0x7FFFFFFF;
        } else {
          fprintf(_coverage_fout, "1615\n");
          fflush(_coverage_fout);
          *(nb + 0) = 0x7FFFFFFF;
          fprintf(_coverage_fout, "1616\n");
          fflush(_coverage_fout);
          *(nb + 1) = (int )((float )0x7FFFFFFF / *na);
        }
      }
    }
    fprintf(_coverage_fout, "1621\n");
    fflush(_coverage_fout);
    na ++;
    fprintf(_coverage_fout, "1622\n");
    fflush(_coverage_fout);
    nb += 2;
    fprintf(_coverage_fout, "1623\n");
    fflush(_coverage_fout);
    nc ++;
  }
  fprintf(_coverage_fout, "1634\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1624\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong((uint32 *)m, (long )(count * 2U));
  } else {
    fprintf(_coverage_fout, "1625\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1635\n");
  fflush(_coverage_fout);
  o = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)10, count,
                                count * 8U, (void *)(m + 0));
  fprintf(_coverage_fout, "1636\n");
  fflush(_coverage_fout);
  _TIFFfree((void *)m);
  fprintf(_coverage_fout, "1637\n");
  fflush(_coverage_fout);
  return (o);
}
}
static int TIFFWriteDirectoryTagCheckedFloat(TIFF *tif , uint32 *ndir ,
                                             TIFFDirEntry *dir , uint16 tag ,
                                             float value ) 
{ float m ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1642\n");
  fflush(_coverage_fout);
  if (sizeof(float ) == 4U) {
    fprintf(_coverage_fout, "1638\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1639\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(float)==4", "tif_dirwrite.c", 1970U,
                  "TIFFWriteDirectoryTagCheckedFloat");
  }
  fprintf(_coverage_fout, "1643\n");
  fflush(_coverage_fout);
  m = value;
  fprintf(_coverage_fout, "1644\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1640\n");
    fflush(_coverage_fout);
    TIFFSwabFloat(& m);
  } else {
    fprintf(_coverage_fout, "1641\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1645\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)11, 1U,
                                  4U, (void *)(& m));
  fprintf(_coverage_fout, "1646\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedFloatArray(TIFF *tif , uint32 *ndir ,
                                                  TIFFDirEntry *dir ,
                                                  uint16 tag , uint32 count ,
                                                  float *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1653\n");
  fflush(_coverage_fout);
  if (count < 1073741824U) {
    fprintf(_coverage_fout, "1647\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1648\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x40000000", "tif_dirwrite.c", 1981U,
                  "TIFFWriteDirectoryTagCheckedFloatArray");
  }
  fprintf(_coverage_fout, "1654\n");
  fflush(_coverage_fout);
  if (sizeof(float ) == 4U) {
    fprintf(_coverage_fout, "1649\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1650\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(float)==4", "tif_dirwrite.c", 1982U,
                  "TIFFWriteDirectoryTagCheckedFloatArray");
  }
  fprintf(_coverage_fout, "1655\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1651\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfFloat(value, (long )count);
  } else {
    fprintf(_coverage_fout, "1652\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1656\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)11,
                                  count, count * 4U, (void *)value);
  fprintf(_coverage_fout, "1657\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedDouble(TIFF *tif , uint32 *ndir ,
                                              TIFFDirEntry *dir , uint16 tag ,
                                              double value ) 
{ double m ;
  int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1662\n");
  fflush(_coverage_fout);
  if (sizeof(double ) == 8U) {
    fprintf(_coverage_fout, "1658\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1659\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(double)==8", "tif_dirwrite.c", 1993U,
                  "TIFFWriteDirectoryTagCheckedDouble");
  }
  fprintf(_coverage_fout, "1663\n");
  fflush(_coverage_fout);
  m = value;
  fprintf(_coverage_fout, "1664\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1660\n");
    fflush(_coverage_fout);
    TIFFSwabDouble(& m);
  } else {
    fprintf(_coverage_fout, "1661\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1665\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)12, 1U,
                                  8U, (void *)(& m));
  fprintf(_coverage_fout, "1666\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedDoubleArray(TIFF *tif , uint32 *ndir ,
                                                   TIFFDirEntry *dir ,
                                                   uint16 tag , uint32 count ,
                                                   double *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1673\n");
  fflush(_coverage_fout);
  if (count < 536870912U) {
    fprintf(_coverage_fout, "1667\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1668\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x20000000", "tif_dirwrite.c", 2004U,
                  "TIFFWriteDirectoryTagCheckedDoubleArray");
  }
  fprintf(_coverage_fout, "1674\n");
  fflush(_coverage_fout);
  if (sizeof(double ) == 8U) {
    fprintf(_coverage_fout, "1669\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1670\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(double)==8", "tif_dirwrite.c", 2005U,
                  "TIFFWriteDirectoryTagCheckedDoubleArray");
  }
  fprintf(_coverage_fout, "1675\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1671\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfDouble(value, (long )count);
  } else {
    fprintf(_coverage_fout, "1672\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1676\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)12,
                                  count, count * 8U, (void *)value);
  fprintf(_coverage_fout, "1677\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedIfdArray(TIFF *tif , uint32 *ndir ,
                                                TIFFDirEntry *dir , uint16 tag ,
                                                uint32 count , uint32 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1684\n");
  fflush(_coverage_fout);
  if (count < 1073741824U) {
    fprintf(_coverage_fout, "1678\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1679\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x40000000", "tif_dirwrite.c", 2015U,
                  "TIFFWriteDirectoryTagCheckedIfdArray");
  }
  fprintf(_coverage_fout, "1685\n");
  fflush(_coverage_fout);
  if (sizeof(uint32 ) == 4U) {
    fprintf(_coverage_fout, "1680\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1681\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint32)==4", "tif_dirwrite.c", 2016U,
                  "TIFFWriteDirectoryTagCheckedIfdArray");
  }
  fprintf(_coverage_fout, "1686\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1682\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong(value, (long )count);
  } else {
    fprintf(_coverage_fout, "1683\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1687\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)13,
                                  count, count * 4U, (void *)value);
  fprintf(_coverage_fout, "1688\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagCheckedIfd8Array(TIFF *tif , uint32 *ndir ,
                                                 TIFFDirEntry *dir ,
                                                 uint16 tag , uint32 count ,
                                                 uint64 *value ) 
{ int tmp ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1697\n");
  fflush(_coverage_fout);
  if (count < 536870912U) {
    fprintf(_coverage_fout, "1689\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1690\n");
    fflush(_coverage_fout);
    __assert_fail("count<0x20000000", "tif_dirwrite.c", 2025U,
                  "TIFFWriteDirectoryTagCheckedIfd8Array");
  }
  fprintf(_coverage_fout, "1698\n");
  fflush(_coverage_fout);
  if (sizeof(uint64 ) == 8U) {
    fprintf(_coverage_fout, "1691\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1692\n");
    fflush(_coverage_fout);
    __assert_fail("sizeof(uint64)==8", "tif_dirwrite.c", 2026U,
                  "TIFFWriteDirectoryTagCheckedIfd8Array");
  }
  fprintf(_coverage_fout, "1699\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 524288U) {
    fprintf(_coverage_fout, "1693\n");
    fflush(_coverage_fout);

  } else {
    fprintf(_coverage_fout, "1694\n");
    fflush(_coverage_fout);
    __assert_fail("tif->tif_flags&0x80000", "tif_dirwrite.c", 2027U,
                  "TIFFWriteDirectoryTagCheckedIfd8Array");
  }
  fprintf(_coverage_fout, "1700\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 128U) {
    fprintf(_coverage_fout, "1695\n");
    fflush(_coverage_fout);
    TIFFSwabArrayOfLong8(value, (long )count);
  } else {
    fprintf(_coverage_fout, "1696\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1701\n");
  fflush(_coverage_fout);
  tmp = TIFFWriteDirectoryTagData(tif, ndir, dir, tag, (unsigned short)18,
                                  count, count * 8U, (void *)value);
  fprintf(_coverage_fout, "1702\n");
  fflush(_coverage_fout);
  return (tmp);
}
}
static int TIFFWriteDirectoryTagData(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint16 datatype , uint32 count ,
                                     uint32 datalength , void *data ) ;
static char const   module___16[26]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'W',      (char const   )'r',      (char const   )'i',      (char const   )'t', 
        (char const   )'e',      (char const   )'D',      (char const   )'i',      (char const   )'r', 
        (char const   )'e',      (char const   )'c',      (char const   )'t',      (char const   )'o', 
        (char const   )'r',      (char const   )'y',      (char const   )'T',      (char const   )'a', 
        (char const   )'g',      (char const   )'D',      (char const   )'a',      (char const   )'t', 
        (char const   )'a',      (char const   )'\000'};
static int TIFFWriteDirectoryTagData(TIFF *tif , uint32 *ndir ,
                                     TIFFDirEntry *dir , uint16 tag ,
                                     uint16 datatype , uint32 count ,
                                     uint32 datalength , void *data ) 
{ uint32 m ;
  uint32 n ;
  uint64 na ;
  uint64 nb ;
  uint64 tmp ;
  tmsize_t tmp___0 ;
  uint32 o ;
  unsigned int tmp___1 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1760\n");
  fflush(_coverage_fout);
  m = 0U;
  fprintf(_coverage_fout, "1761\n");
  fflush(_coverage_fout);
  while (1) {
    fprintf(_coverage_fout, "1707\n");
    fflush(_coverage_fout);
    if (m < *ndir) {
      fprintf(_coverage_fout, "1703\n");
      fflush(_coverage_fout);

    } else {
      break;
    }
    fprintf(_coverage_fout, "1708\n");
    fflush(_coverage_fout);
    if ((int )(dir + m)->tdir_tag != (int )tag) {
      fprintf(_coverage_fout, "1704\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "1705\n");
      fflush(_coverage_fout);
      __assert_fail("dir[m].tdir_tag!=tag", "tif_dirwrite.c", 2041U,
                    "TIFFWriteDirectoryTagData");
    }
    fprintf(_coverage_fout, "1709\n");
    fflush(_coverage_fout);
    if ((int )(dir + m)->tdir_tag > (int )tag) {
      break;
    } else {
      fprintf(_coverage_fout, "1706\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1710\n");
    fflush(_coverage_fout);
    m ++;
  }
  fprintf(_coverage_fout, "1762\n");
  fflush(_coverage_fout);
  if (m < *ndir) {
    fprintf(_coverage_fout, "1715\n");
    fflush(_coverage_fout);
    n = *ndir;
    fprintf(_coverage_fout, "1716\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "1712\n");
      fflush(_coverage_fout);
      if (n > m) {
        fprintf(_coverage_fout, "1711\n");
        fflush(_coverage_fout);

      } else {
        break;
      }
      fprintf(_coverage_fout, "1713\n");
      fflush(_coverage_fout);
      *(dir + n) = *(dir + (n - 1U));
      fprintf(_coverage_fout, "1714\n");
      fflush(_coverage_fout);
      n --;
    }
  } else {
    fprintf(_coverage_fout, "1717\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1763\n");
  fflush(_coverage_fout);
  (dir + m)->tdir_tag = tag;
  fprintf(_coverage_fout, "1764\n");
  fflush(_coverage_fout);
  (dir + m)->tdir_type = datatype;
  fprintf(_coverage_fout, "1765\n");
  fflush(_coverage_fout);
  (dir + m)->tdir_count = (unsigned long long )count;
  fprintf(_coverage_fout, "1766\n");
  fflush(_coverage_fout);
  (dir + m)->tdir_offset = 0ULL;
  fprintf(_coverage_fout, "1767\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 524288U) {
    fprintf(_coverage_fout, "1718\n");
    fflush(_coverage_fout);
    tmp___1 = 0x8U;
  } else {
    fprintf(_coverage_fout, "1719\n");
    fflush(_coverage_fout);
    tmp___1 = 0x4U;
  }
  fprintf(_coverage_fout, "1768\n");
  fflush(_coverage_fout);
  if (datalength <= tmp___1) {
    fprintf(_coverage_fout, "1720\n");
    fflush(_coverage_fout);
    _TIFFmemcpy((void *)(& (dir + m)->tdir_offset), (void const   *)data,
                (long )datalength);
  } else {
    fprintf(_coverage_fout, "1748\n");
    fflush(_coverage_fout);
    na = tif->tif_dataoff;
    fprintf(_coverage_fout, "1749\n");
    fflush(_coverage_fout);
    nb = na + (uint64 )datalength;
    fprintf(_coverage_fout, "1750\n");
    fflush(_coverage_fout);
    if (! (tif->tif_flags & 524288U)) {
      fprintf(_coverage_fout, "1721\n");
      fflush(_coverage_fout);
      nb = (unsigned long long )((unsigned int )nb);
    } else {
      fprintf(_coverage_fout, "1722\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1751\n");
    fflush(_coverage_fout);
    if (nb < na) {
      fprintf(_coverage_fout, "1723\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___16,
                   "Maximum TIFF file size exceeded");
      fprintf(_coverage_fout, "1724\n");
      fflush(_coverage_fout);
      return (0);
    } else {
      fprintf(_coverage_fout, "1728\n");
      fflush(_coverage_fout);
      if (nb < (uint64 )datalength) {
        fprintf(_coverage_fout, "1725\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___16,
                     "Maximum TIFF file size exceeded");
        fprintf(_coverage_fout, "1726\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "1727\n");
        fflush(_coverage_fout);

      }
    }
    fprintf(_coverage_fout, "1752\n");
    fflush(_coverage_fout);
    tmp = (*(tif->tif_seekproc))(tif->tif_clientdata, na, 0);
    fprintf(_coverage_fout, "1753\n");
    fflush(_coverage_fout);
    if (tmp == na) {
      fprintf(_coverage_fout, "1729\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "1730\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___16, "IO error writing tag data");
      fprintf(_coverage_fout, "1731\n");
      fflush(_coverage_fout);
      return (0);
    }
    fprintf(_coverage_fout, "1754\n");
    fflush(_coverage_fout);
    if ((unsigned long )datalength < 0x80000000UL) {
      fprintf(_coverage_fout, "1732\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "1733\n");
      fflush(_coverage_fout);
      __assert_fail("datalength<0x80000000UL", "tif_dirwrite.c", 2075U,
                    "TIFFWriteDirectoryTagData");
    }
    fprintf(_coverage_fout, "1755\n");
    fflush(_coverage_fout);
    tmp___0 = (*(tif->tif_writeproc))(tif->tif_clientdata, data,
                                      (long )datalength);
    fprintf(_coverage_fout, "1756\n");
    fflush(_coverage_fout);
    if (tmp___0 == (long )datalength) {
      fprintf(_coverage_fout, "1734\n");
      fflush(_coverage_fout);

    } else {
      fprintf(_coverage_fout, "1735\n");
      fflush(_coverage_fout);
      TIFFErrorExt(tif->tif_clientdata, module___16, "IO error writing tag data");
      fprintf(_coverage_fout, "1736\n");
      fflush(_coverage_fout);
      return (0);
    }
    fprintf(_coverage_fout, "1757\n");
    fflush(_coverage_fout);
    tif->tif_dataoff = nb;
    fprintf(_coverage_fout, "1758\n");
    fflush(_coverage_fout);
    if (tif->tif_dataoff & 1ULL) {
      fprintf(_coverage_fout, "1737\n");
      fflush(_coverage_fout);
      (tif->tif_dataoff) ++;
    } else {
      fprintf(_coverage_fout, "1738\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1759\n");
    fflush(_coverage_fout);
    if (! (tif->tif_flags & 524288U)) {
      fprintf(_coverage_fout, "1741\n");
      fflush(_coverage_fout);
      o = (unsigned int )na;
      fprintf(_coverage_fout, "1742\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "1739\n");
        fflush(_coverage_fout);
        TIFFSwabLong(& o);
      } else {
        fprintf(_coverage_fout, "1740\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1743\n");
      fflush(_coverage_fout);
      _TIFFmemcpy((void *)(& (dir + m)->tdir_offset), (void const   *)(& o), 4L);
    } else {
      fprintf(_coverage_fout, "1746\n");
      fflush(_coverage_fout);
      (dir + m)->tdir_offset = na;
      fprintf(_coverage_fout, "1747\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "1744\n");
        fflush(_coverage_fout);
        TIFFSwabLong8(& (dir + m)->tdir_offset);
      } else {
        fprintf(_coverage_fout, "1745\n");
        fflush(_coverage_fout);

      }
    }
  }
  fprintf(_coverage_fout, "1769\n");
  fflush(_coverage_fout);
  (*ndir) ++;
  fprintf(_coverage_fout, "1770\n");
  fflush(_coverage_fout);
  return (1);
}
}
static int TIFFLinkDirectory(TIFF *tif ) ;
static char const   module___17[18]  = 
  {      (char const   )'T',      (char const   )'I',      (char const   )'F',      (char const   )'F', 
        (char const   )'L',      (char const   )'i',      (char const   )'n',      (char const   )'k', 
        (char const   )'D',      (char const   )'i',      (char const   )'r',      (char const   )'e', 
        (char const   )'c',      (char const   )'t',      (char const   )'o',      (char const   )'r', 
        (char const   )'y',      (char const   )'\000'};
static int TIFFLinkDirectory(TIFF *tif ) 
{ uint64 tmp ;
  uint32 m ;
  tmsize_t tmp___0 ;
  uint64 m___0 ;
  tmsize_t tmp___1 ;
  uint32 m___1 ;
  uint32 nextdir ;
  tmsize_t tmp___2 ;
  uint16 dircount ;
  uint32 nextnextdir ;
  uint64 tmp___3 ;
  tmsize_t tmp___4 ;
  tmsize_t tmp___5 ;
  tmsize_t tmp___6 ;
  uint64 m___2 ;
  uint64 nextdir___0 ;
  tmsize_t tmp___7 ;
  uint64 dircount64 ;
  uint16 dircount___0 ;
  uint64 nextnextdir___0 ;
  uint64 tmp___8 ;
  tmsize_t tmp___9 ;
  tmsize_t tmp___10 ;
  tmsize_t tmp___11 ;

  {
  if (_coverage_fout == 0) {
    _coverage_fout = fopen("/root/mountpoint-genprog/genprog-many-bugs/libtiff-bug-0661f81-ac6a583/coverage/coverage.path",
                           "wb");
  }
  fprintf(_coverage_fout, "1900\n");
  fflush(_coverage_fout);
  tmp = (*(tif->tif_seekproc))(tif->tif_clientdata, 0ULL, 2);
  fprintf(_coverage_fout, "1901\n");
  fflush(_coverage_fout);
  tif->tif_diroff = (tmp + 1ULL) & 0xfffffffffffffffeULL;
  fprintf(_coverage_fout, "1902\n");
  fflush(_coverage_fout);
  if (tif->tif_flags & 8192U) {
    fprintf(_coverage_fout, "1801\n");
    fflush(_coverage_fout);
    if (! (tif->tif_flags & 524288U)) {
      fprintf(_coverage_fout, "1778\n");
      fflush(_coverage_fout);
      m = (unsigned int )tif->tif_diroff;
      fprintf(_coverage_fout, "1779\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "1771\n");
        fflush(_coverage_fout);
        TIFFSwabLong(& m);
      } else {
        fprintf(_coverage_fout, "1772\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1780\n");
      fflush(_coverage_fout);
      (*(tif->tif_seekproc))(tif->tif_clientdata, tif->tif_subifdoff, 0);
      fprintf(_coverage_fout, "1781\n");
      fflush(_coverage_fout);
      tmp___0 = (*(tif->tif_writeproc))(tif->tif_clientdata, (void *)(& m), 4L);
      fprintf(_coverage_fout, "1782\n");
      fflush(_coverage_fout);
      if (tmp___0 == 4L) {
        fprintf(_coverage_fout, "1773\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "1774\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error writing SubIFD directory link");
        fprintf(_coverage_fout, "1775\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "1783\n");
      fflush(_coverage_fout);
      tif->tif_nsubifd = (uint16 )((int )tif->tif_nsubifd - 1);
      fprintf(_coverage_fout, "1784\n");
      fflush(_coverage_fout);
      if (tif->tif_nsubifd) {
        fprintf(_coverage_fout, "1776\n");
        fflush(_coverage_fout);
        tif->tif_subifdoff += 4ULL;
      } else {
        fprintf(_coverage_fout, "1777\n");
        fflush(_coverage_fout);
        tif->tif_flags &= 4294959103U;
      }
      fprintf(_coverage_fout, "1785\n");
      fflush(_coverage_fout);
      return (1);
    } else {
      fprintf(_coverage_fout, "1793\n");
      fflush(_coverage_fout);
      m___0 = tif->tif_diroff;
      fprintf(_coverage_fout, "1794\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "1786\n");
        fflush(_coverage_fout);
        TIFFSwabLong8(& m___0);
      } else {
        fprintf(_coverage_fout, "1787\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1795\n");
      fflush(_coverage_fout);
      (*(tif->tif_seekproc))(tif->tif_clientdata, tif->tif_subifdoff, 0);
      fprintf(_coverage_fout, "1796\n");
      fflush(_coverage_fout);
      tmp___1 = (*(tif->tif_writeproc))(tif->tif_clientdata, (void *)(& m___0),
                                        8L);
      fprintf(_coverage_fout, "1797\n");
      fflush(_coverage_fout);
      if (tmp___1 == 8L) {
        fprintf(_coverage_fout, "1788\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "1789\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error writing SubIFD directory link");
        fprintf(_coverage_fout, "1790\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "1798\n");
      fflush(_coverage_fout);
      tif->tif_nsubifd = (uint16 )((int )tif->tif_nsubifd - 1);
      fprintf(_coverage_fout, "1799\n");
      fflush(_coverage_fout);
      if (tif->tif_nsubifd) {
        fprintf(_coverage_fout, "1791\n");
        fflush(_coverage_fout);
        tif->tif_subifdoff += 8ULL;
      } else {
        fprintf(_coverage_fout, "1792\n");
        fflush(_coverage_fout);
        tif->tif_flags &= 4294959103U;
      }
      fprintf(_coverage_fout, "1800\n");
      fflush(_coverage_fout);
      return (1);
    }
  } else {
    fprintf(_coverage_fout, "1802\n");
    fflush(_coverage_fout);

  }
  fprintf(_coverage_fout, "1903\n");
  fflush(_coverage_fout);
  if (! (tif->tif_flags & 524288U)) {
    fprintf(_coverage_fout, "1844\n");
    fflush(_coverage_fout);
    m___1 = (unsigned int )tif->tif_diroff;
    fprintf(_coverage_fout, "1845\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "1803\n");
      fflush(_coverage_fout);
      TIFFSwabLong(& m___1);
    } else {
      fprintf(_coverage_fout, "1804\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1846\n");
    fflush(_coverage_fout);
    if (tif->tif_header.classic.tiff_diroff == 0U) {
      fprintf(_coverage_fout, "1808\n");
      fflush(_coverage_fout);
      tif->tif_header.classic.tiff_diroff = (unsigned int )tif->tif_diroff;
      fprintf(_coverage_fout, "1809\n");
      fflush(_coverage_fout);
      (*(tif->tif_seekproc))(tif->tif_clientdata, 4ULL, 0);
      fprintf(_coverage_fout, "1810\n");
      fflush(_coverage_fout);
      tmp___2 = (*(tif->tif_writeproc))(tif->tif_clientdata, (void *)(& m___1),
                                        4L);
      fprintf(_coverage_fout, "1811\n");
      fflush(_coverage_fout);
      if (tmp___2 == 4L) {
        fprintf(_coverage_fout, "1805\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "1806\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                     "Error writing TIFF header");
        fprintf(_coverage_fout, "1807\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "1812\n");
      fflush(_coverage_fout);
      return (1);
    } else {
      fprintf(_coverage_fout, "1813\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1847\n");
    fflush(_coverage_fout);
    nextdir = tif->tif_header.classic.tiff_diroff;
    fprintf(_coverage_fout, "1848\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "1835\n");
      fflush(_coverage_fout);
      tmp___3 = (*(tif->tif_seekproc))(tif->tif_clientdata,
                                       (unsigned long long )nextdir, 0);
      fprintf(_coverage_fout, "1836\n");
      fflush(_coverage_fout);
      if (tmp___3 == (uint64 )nextdir) {
        fprintf(_coverage_fout, "1817\n");
        fflush(_coverage_fout);
        tmp___4 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                         (void *)(& dircount), 2L);
        fprintf(_coverage_fout, "1818\n");
        fflush(_coverage_fout);
        if (tmp___4 == 2L) {
          fprintf(_coverage_fout, "1814\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "1815\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___17,
                       "Error fetching directory count");
          fprintf(_coverage_fout, "1816\n");
          fflush(_coverage_fout);
          return (0);
        }
      } else {
        fprintf(_coverage_fout, "1819\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error fetching directory count");
        fprintf(_coverage_fout, "1820\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "1837\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "1821\n");
        fflush(_coverage_fout);
        TIFFSwabShort(& dircount);
      } else {
        fprintf(_coverage_fout, "1822\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1838\n");
      fflush(_coverage_fout);
      (*(tif->tif_seekproc))(tif->tif_clientdata,
                             (unsigned long long )((nextdir + 2U) + (uint32 )((int )dircount * 12)),
                             0);
      fprintf(_coverage_fout, "1839\n");
      fflush(_coverage_fout);
      tmp___5 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                       (void *)(& nextnextdir), 4L);
      fprintf(_coverage_fout, "1840\n");
      fflush(_coverage_fout);
      if (tmp___5 == 4L) {
        fprintf(_coverage_fout, "1823\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "1824\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error fetching directory link");
        fprintf(_coverage_fout, "1825\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "1841\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "1826\n");
        fflush(_coverage_fout);
        TIFFSwabLong(& nextnextdir);
      } else {
        fprintf(_coverage_fout, "1827\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1842\n");
      fflush(_coverage_fout);
      if (nextnextdir == 0U) {
        fprintf(_coverage_fout, "1831\n");
        fflush(_coverage_fout);
        (*(tif->tif_seekproc))(tif->tif_clientdata,
                               (unsigned long long )((nextdir + 2U) + (uint32 )((int )dircount * 12)),
                               0);
        fprintf(_coverage_fout, "1832\n");
        fflush(_coverage_fout);
        tmp___6 = (*(tif->tif_writeproc))(tif->tif_clientdata,
                                          (void *)(& m___1), 4L);
        fprintf(_coverage_fout, "1833\n");
        fflush(_coverage_fout);
        if (tmp___6 == 4L) {
          fprintf(_coverage_fout, "1828\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "1829\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___17,
                       "Error writing directory link");
          fprintf(_coverage_fout, "1830\n");
          fflush(_coverage_fout);
          return (0);
        }
        break;
      } else {
        fprintf(_coverage_fout, "1834\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1843\n");
      fflush(_coverage_fout);
      nextdir = nextnextdir;
    }
  } else {
    fprintf(_coverage_fout, "1895\n");
    fflush(_coverage_fout);
    m___2 = tif->tif_diroff;
    fprintf(_coverage_fout, "1896\n");
    fflush(_coverage_fout);
    if (tif->tif_flags & 128U) {
      fprintf(_coverage_fout, "1849\n");
      fflush(_coverage_fout);
      TIFFSwabLong8(& m___2);
    } else {
      fprintf(_coverage_fout, "1850\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1897\n");
    fflush(_coverage_fout);
    if (tif->tif_header.big.tiff_diroff == 0ULL) {
      fprintf(_coverage_fout, "1854\n");
      fflush(_coverage_fout);
      tif->tif_header.big.tiff_diroff = tif->tif_diroff;
      fprintf(_coverage_fout, "1855\n");
      fflush(_coverage_fout);
      (*(tif->tif_seekproc))(tif->tif_clientdata, 8ULL, 0);
      fprintf(_coverage_fout, "1856\n");
      fflush(_coverage_fout);
      tmp___7 = (*(tif->tif_writeproc))(tif->tif_clientdata, (void *)(& m___2),
                                        8L);
      fprintf(_coverage_fout, "1857\n");
      fflush(_coverage_fout);
      if (tmp___7 == 8L) {
        fprintf(_coverage_fout, "1851\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "1852\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, (char const   *)tif->tif_name,
                     "Error writing TIFF header");
        fprintf(_coverage_fout, "1853\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "1858\n");
      fflush(_coverage_fout);
      return (1);
    } else {
      fprintf(_coverage_fout, "1859\n");
      fflush(_coverage_fout);

    }
    fprintf(_coverage_fout, "1898\n");
    fflush(_coverage_fout);
    nextdir___0 = tif->tif_header.big.tiff_diroff;
    fprintf(_coverage_fout, "1899\n");
    fflush(_coverage_fout);
    while (1) {
      fprintf(_coverage_fout, "1884\n");
      fflush(_coverage_fout);
      tmp___8 = (*(tif->tif_seekproc))(tif->tif_clientdata, nextdir___0, 0);
      fprintf(_coverage_fout, "1885\n");
      fflush(_coverage_fout);
      if (tmp___8 == nextdir___0) {
        fprintf(_coverage_fout, "1863\n");
        fflush(_coverage_fout);
        tmp___9 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                         (void *)(& dircount64), 8L);
        fprintf(_coverage_fout, "1864\n");
        fflush(_coverage_fout);
        if (tmp___9 == 8L) {
          fprintf(_coverage_fout, "1860\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "1861\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___17,
                       "Error fetching directory count");
          fprintf(_coverage_fout, "1862\n");
          fflush(_coverage_fout);
          return (0);
        }
      } else {
        fprintf(_coverage_fout, "1865\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error fetching directory count");
        fprintf(_coverage_fout, "1866\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "1886\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "1867\n");
        fflush(_coverage_fout);
        TIFFSwabLong8(& dircount64);
      } else {
        fprintf(_coverage_fout, "1868\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1887\n");
      fflush(_coverage_fout);
      if (dircount64 > 65535ULL) {
        fprintf(_coverage_fout, "1869\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Sanity check on tag count failed, likely corrupt TIFF");
        fprintf(_coverage_fout, "1870\n");
        fflush(_coverage_fout);
        return (0);
      } else {
        fprintf(_coverage_fout, "1871\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1888\n");
      fflush(_coverage_fout);
      dircount___0 = (unsigned short )dircount64;
      fprintf(_coverage_fout, "1889\n");
      fflush(_coverage_fout);
      (*(tif->tif_seekproc))(tif->tif_clientdata,
                             (nextdir___0 + 8ULL) + (uint64 )((int )dircount___0 * 20),
                             0);
      fprintf(_coverage_fout, "1890\n");
      fflush(_coverage_fout);
      tmp___10 = (*(tif->tif_readproc))(tif->tif_clientdata,
                                        (void *)(& nextnextdir___0), 8L);
      fprintf(_coverage_fout, "1891\n");
      fflush(_coverage_fout);
      if (tmp___10 == 8L) {
        fprintf(_coverage_fout, "1872\n");
        fflush(_coverage_fout);

      } else {
        fprintf(_coverage_fout, "1873\n");
        fflush(_coverage_fout);
        TIFFErrorExt(tif->tif_clientdata, module___17,
                     "Error fetching directory link");
        fprintf(_coverage_fout, "1874\n");
        fflush(_coverage_fout);
        return (0);
      }
      fprintf(_coverage_fout, "1892\n");
      fflush(_coverage_fout);
      if (tif->tif_flags & 128U) {
        fprintf(_coverage_fout, "1875\n");
        fflush(_coverage_fout);
        TIFFSwabLong8(& nextnextdir___0);
      } else {
        fprintf(_coverage_fout, "1876\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1893\n");
      fflush(_coverage_fout);
      if (nextnextdir___0 == 0ULL) {
        fprintf(_coverage_fout, "1880\n");
        fflush(_coverage_fout);
        (*(tif->tif_seekproc))(tif->tif_clientdata,
                               (nextdir___0 + 8ULL) + (uint64 )((int )dircount___0 * 20),
                               0);
        fprintf(_coverage_fout, "1881\n");
        fflush(_coverage_fout);
        tmp___11 = (*(tif->tif_writeproc))(tif->tif_clientdata,
                                           (void *)(& m___2), 8L);
        fprintf(_coverage_fout, "1882\n");
        fflush(_coverage_fout);
        if (tmp___11 == 8L) {
          fprintf(_coverage_fout, "1877\n");
          fflush(_coverage_fout);

        } else {
          fprintf(_coverage_fout, "1878\n");
          fflush(_coverage_fout);
          TIFFErrorExt(tif->tif_clientdata, module___17,
                       "Error writing directory link");
          fprintf(_coverage_fout, "1879\n");
          fflush(_coverage_fout);
          return (0);
        }
        break;
      } else {
        fprintf(_coverage_fout, "1883\n");
        fflush(_coverage_fout);

      }
      fprintf(_coverage_fout, "1894\n");
      fflush(_coverage_fout);
      nextdir___0 = nextnextdir___0;
    }
  }
  fprintf(_coverage_fout, "1904\n");
  fflush(_coverage_fout);
  return (1);
}
}
