<?php

	define( 'CFG_DB_NAME',		'' );
	define( 'CFG_DB_HOST',		'' );
	define( 'CFG_DB_USER',		'' );
	define( 'CFG_DB_PWD',		'' );
	
	define( 'CFG_PATH_HTML', 	'html' );

?>