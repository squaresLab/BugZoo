
/* Declarations for the fast random functions */

extern void   SeedRandom(Uint32 seed);
extern Uint16 FastRandom(Uint16 range);
extern Uint32 GetRandSeed(void);

