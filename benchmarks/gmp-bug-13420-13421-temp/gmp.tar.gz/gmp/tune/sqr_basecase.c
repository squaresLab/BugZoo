/* not sure that an empty file can compile, so put in a dummy */
int sqr_basecase_dummy;
