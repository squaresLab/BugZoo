###################################
  Python Frequently Asked Questions
###################################

:Release: |version|
:Date: |today|

.. toctree::
   :maxdepth: 1

   general.rst
   programming.rst
   design.rst
   library.rst
   extending.rst
   windows.rst
   gui.rst
   installed.rst
